# Quyền riêng tư của WP Pocket Server

> **Bản nháp mang tính thông tin, KHÔNG phải tư vấn pháp lý.** Mọi câu dưới đây được đối chiếu với mã nguồn hiện tại;
> nếu bạn sửa mã (thêm SDK, thêm điểm gọi mạng) thì tài liệu này phải được sửa theo. Người vận hành website chạy trên
> app là **bên chịu trách nhiệm** với dữ liệu của khách truy cập website đó (xem mục 5).

## 1. Ứng dụng KHÔNG làm gì

- **Không có tài khoản, không có máy chủ của nhà phát triển.** App không gửi dữ liệu nào về nhà phát triển.
- **Không có SDK phân tích, quảng cáo hay báo cáo sự cố từ xa.** Thư viện phụ thuộc chỉ gồm AndroidX, Material Components,
  WorkManager (xem `app/build.gradle.kts`). Nhật ký sự cố (`CrashLogger`) **chỉ ghi vào bộ nhớ riêng của app** trên máy bạn.
- **Không xin quyền đọc danh bạ, vị trí, camera, micro, hay bộ nhớ chung.** Quyền được khai báo: `INTERNET`,
  `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `FOREGROUND_SERVICE` (+ `SPECIAL_USE`), `WAKE_LOCK`, `POST_NOTIFICATIONS`,
  `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`, `RECEIVE_BOOT_COMPLETED`.
- `allowBackup="false"`: dữ liệu app không được sao lưu lên đám mây của Android.

## 2. Dữ liệu lưu TRÊN MÁY (bộ nhớ riêng của app)

Toàn bộ nằm trong thư mục riêng của app (`filesDir` / `cacheDir`), các app khác không đọc được trên máy chưa root:

| Dữ liệu | Ghi chú |
|---|---|
| Mã nguồn website, uploads, cơ sở dữ liệu MariaDB/SQLite | Là nội dung website của bạn, có thể chứa dữ liệu cá nhân của khách (bình luận, đơn hàng…) |
| `admin-password.txt` | Mật khẩu `_admin/` ở dạng văn bản thường trong thư mục riêng của app |
| Cấu hình: Bot Token Telegram, Chat ID, webhook, URL heartbeat, mật khẩu mã hoá backup | Lưu ở SharedPreferences **không mã hoá thêm** — an toàn tương đương bộ nhớ riêng của app, **không an toàn** nếu máy bị root/chiếm quyền |
| Nhật ký truy cập nginx (IP khách, URL, User-Agent), nhật ký đăng nhập `_admin/` (IP, thời điểm), danh sách phiên đăng nhập (IP, trình duyệt) | Được cắt/rotate theo kích thước; xem `admin-audit.log`, `admin-sessions.json` |
| Nhật ký bảo mật (vòng 1br): `nginx-security.log` (IP, URL, User-Agent của request lỗi 4xx và request đăng nhập), `security-state.json`/`ban-list.conf` (IP bị chặn, điểm vi phạm), `security-events.log` (sự kiện như tài khoản quản trị mới, tên đăng nhập, tên tệp nghi mã độc), `security-scan.json` (đường dẫn tệp nghi ngờ), `quarantine/` (bản sao tệp bị cách ly), `shield-login.json` (khoá mạng đã **băm HMAC**, không lưu IP thô) | Chỉ trên máy bạn; log được cắt/rotate. Cảnh báo Telegram (nếu bạn bật) chỉ gửi loại sự kiện và số lượng, không gửi nội dung tệp. Xem `docs/SECURITY.md` |
| Đăng nhập hai bước WordPress (vòng 31): bí mật TOTP **mã hoá** trong bảng `usermeta` của site (khoá dẫn xuất từ `AUTH_KEY`/`SECURE_AUTH_KEY` — ai có `wp-config.php` + CSDL giải mã được), mã khôi phục lưu dạng băm; kết quả kiểm lỗ hổng đã biết (`security-vuln.json`, `vuln-cache.json`, `vuln-seen.json`) | Chỉ trên máy bạn; xoá được bằng cách xoá file / gỡ mu-plugin |
| Ngưỡng và quy tắc cảnh báo bạn đặt, trạng thái từng quy tắc, dấu "đang khôi phục" (`restore-in-progress`, chứa tên tệp backup) | Chỉ trên máy bạn; không gửi đi |
| Bản sao lưu (`backups/`) | Chứa cả database và `wp-config.php` (mật khẩu DB, salt). Có thể mã hoá AES-256-GCM nếu bạn bật tuỳ chọn |

## 3. Dữ liệu RỜI KHỎI máy — chỉ khi bạn cấu hình

| Điểm đến | Khi nào | Nội dung | Ai nhận |
|---|---|---|---|
| **Cloudflare** (Cloudflare Tunnel, `cloudflared`) | Khi bật tunnel (Quick Tunnel hoặc Named Tunnel) | **Toàn bộ lưu lượng của khách truy cập website** đi qua hạ tầng Cloudflare (TLS kết thúc tại Cloudflare) | Cloudflare — áp dụng chính sách của Cloudflare |
| **Telegram** (`api.telegram.org`) | Nếu bạn nhập Bot Token + Chat ID | Cảnh báo vận hành (địa chỉ IP đăng nhập sai, mức dùng bộ nhớ/pin…), cảnh báo từ **quy tắc tuỳ chỉnh** bạn tự viết (kèm giá trị chỉ số máy như % RAM, nhiệt độ pin), cảnh báo **khôi phục bị gián đoạn**, phản hồi lệnh, và **file backup** nếu bật gửi backup | Telegram và mọi người trong cuộc trò chuyện đó |
| **Webhook** do bạn đặt | Nếu bạn nhập URL | File backup (tuỳ cấu hình) | Bên vận hành URL đó — **có thể là `http://` không mã hoá nếu bạn tự nhập vậy** |
| **URL heartbeat** (vd healthchecks.io) | Nếu bạn nhập URL | Một yêu cầu `GET` rỗng định kỳ; app **không ghi URL này vào log** (URL thường chứa mã bí mật) | Dịch vụ giám sát bạn chọn |
| **GitHub** (`api.github.com`) | **Chỉ khi bạn bấm** nút *Kiểm tra bản mới* | Một yêu cầu `GET` tới `/repos/<repo của app>/releases/latest`; không gửi định danh, token hay dữ liệu của bạn (GitHub vẫn thấy địa chỉ IP như mọi kết nối) | GitHub |
| **`www.wpvulnerability.net`** (hoặc địa chỉ tương thích bạn đặt) | **Chỉ khi bạn bật** công tắc `vuln-check-on` (mặc định TẮT); mỗi giờ + khi bấm "Kiểm ngay" | *Tên thư mục plugin/theme, phiên bản của chúng, phiên bản WordPress* — **không** gửi tên miền, nội dung site hay IP riêng của site; dịch vụ vẫn thấy địa chỉ IP công khai của kết nối | Bên vận hành dịch vụ đó (dữ liệu lỗ hổng nguồn mở) |
| **`api.wordpress.org`** (checksum lõi WordPress) | Khi quét mã độc (tự động khoảng mỗi 6 giờ, hoặc bấm "Quét ngay") với site WordPress | Phiên bản và ngôn ngữ (locale) của WordPress — giống hệt hành vi cập nhật chuẩn của WordPress | WordPress.org |
| **WordPress.org** | Khi dùng "1-Click Install" và khi WordPress tự kiểm tra cập nhật/plugin | Hành vi chuẩn của WordPress (địa chỉ site, phiên bản) | WordPress.org |
| **Nhà cung cấp SMTP** | Nếu bạn cấu hình WP Mail SMTP | Nội dung email website gửi | Nhà cung cấp bạn chọn |

**Backup chứa dữ liệu nhạy cảm.** Nếu gửi qua Telegram/webhook, hãy bật mã hoá backup (AES-256-GCM, khoá dẫn xuất từ
cụm mật khẩu của bạn bằng PBKDF2). Không mã hoá = bất kỳ ai đọc được cuộc trò chuyện/webhook đều đọc được toàn bộ site.
Backup đã gửi lên Telegram/webhook **không tự bị xoá** khi bạn xoá app.

## 4. Thời điểm BUILD (không phải lúc chạy trên điện thoại)

Pipeline build tải gói từ Termux, binary cloudflared, Adminer, Tiny File Manager, WP-CLI, bộ CA, WordPress — mỗi tệp được
đối chiếu mã băm hoặc ghi nhận trong báo cáo (`build-inputs`). Không dữ liệu người dùng nào tham gia bước này.

## 5. Trách nhiệm của người vận hành website

Website bạn chạy trên app có thể thu thập dữ liệu khách (cookie, bình luận, biểu mẫu, log IP). Tuỳ nơi khách ở
(ví dụ EU/UK: GDPR; nơi khác: luật bảo vệ dữ liệu cá nhân tương ứng) bạn có thể cần: chính sách riêng tư và thông báo
cookie **cho website của bạn**, căn cứ pháp lý xử lý, thời hạn lưu giữ, và quy trình đáp ứng yêu cầu của chủ thể dữ liệu.
App không làm các việc đó thay bạn. Cloudflare Tunnel cho khách IP của Cloudflare ở lớp trên cùng, còn IP thật của khách
được chuyển cho website qua header `CF-Connecting-IP` (xem cấu hình nginx).

## 5b. Giai đoạn thử nghiệm và công cụ dòng lệnh

- **Thử nghiệm miễn phí**: app vẫn **không gửi gì** về chủ dự án. Chỉ khi **bạn tự chọn** gửi phản hồi (nhật ký, ảnh chụp màn hình) thì chủ dự án mới nhận dữ liệu đó — hãy che IP, token, mật khẩu trước (`docs/BETA_PROGRAM.md`).
- **`wppocket`** (công cụ dòng lệnh, chạy trên máy tính của bạn): đọc API trạng thái chỉ đọc trong mạng LAN; token lưu trong tệp cấu hình của bạn (quyền 0600); không gửi dữ liệu tới ai khác.
- Ghi chú pháp lý tham khảo (dữ liệu cá nhân ở Việt Nam, mật mã): `docs/LEGAL_NOTES_VN.md` — không phải tư vấn pháp lý.

## 6. Xoá dữ liệu

Gỡ cài đặt app, hoặc Cài đặt Android → Ứng dụng → WP Pocket Server → Bộ nhớ → **Xoá dữ liệu**, sẽ xoá toàn bộ mục 2 khỏi
máy. Bản sao lưu đã gửi ra ngoài (mục 3) phải được xoá thủ công ở nơi nhận.

## API trạng thái (tuỳ chọn, mặc định tắt)
Nếu bạn tự bật, máy chủ trên điện thoại trả về JSON gồm: server có đang chạy, % pin và đang sạc, % bộ nhớ đã dùng, giờ backup cuối, số backup và phiên bản app. Chỉ máy trong mạng LAN (dải riêng) và biết token mới đọc được; dữ liệu **không** được gửi tới chủ dự án hay bất kỳ dịch vụ nào. Token được lưu mã hoá bằng Android Keystore. Tắt hộp kiểm thì tệp trạng thái bị xoá.
