plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.wppocket.server"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.wppocket.server"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    // signingConfigs.debug: TRUOC BAN NAY khong khai bao gi, nen dung
    // keystore debug MAC DINH cua Android Gradle Plugin - plugin nay tu SINH
    // "~/.android/debug.keystore" NEU CHUA CO TREN MAY. GitHub Actions la
    // may ao MOI HOAN TOAN moi lan chay (khong cache "~/.android/"), nen MOI
    // LAN BUILD CI deu sinh 1 certificate NGAU NHIEN KHAC NHAU du alias/mat
    // khau quy uoc giong nhau ("androiddebugkey"/"android") - Android CHAN
    // cai de len ban co san neu certificate khac nhau, hien thi loi chung
    // chung "Ung dung chua duoc cai dat" (khong noi ro ly do), day chinh la
    // nguyen nhan gap phai khi cai app-debug.apk cua lan build sau de len
    // ban da cai tu lan build truoc (xem HANDOFF.md muc 1l). Khai bao thang
    // 1 file "debug.keystore" COMMIT SAN trong repo (cung thu muc voi file
    // nay) de MOI lan build CI - qua khu, hien tai, tuong lai - deu ky BANG
    // CHINH XAC 1 certificate, cai de truc tiep len ban cu binh thuong,
    // khong con gap loi nay nua VE SAU (chi lan nay, chuyen tu certificate
    // ngau nhien cu sang certificate co dinh moi, buoc phai GO CAI DAT ban
    // dang co tren dien thoai 1 LAN DUY NHAT truoc khi cai ban moi).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    // QUAN TRỌNG: không nén file .so trong APK — bắt buộc để có thể mmap/thực thi
    // trực tiếp file php binary được đóng gói dưới dạng "thư viện native" (libphpsrv.so)
    packaging {
        jniLibs {
            useLegacyPackaging = false
            keepDebugSymbols += "**/*.so"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Backup tu dong dinh ky + watchdog "chua lanh tu dong" (BackupWorker,
    // HealthCheckWorker) - de xuat tu PDF, xem HANDOFF.md muc 1e. Chon ban
    // 2.9.1 (khong phai ban moi nhat) de khop an toan voi compileSdk 34 /
    // AGP 8.5.2 / Kotlin 1.9.24 dang dung trong repo nay - CHUA build-test
    // that (moi truong tao project nay khong co Android SDK, xem HANDOFF.md
    // muc 2), neu Gradle bao xung dot phien ban, day la cho dau tien can sua.
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
