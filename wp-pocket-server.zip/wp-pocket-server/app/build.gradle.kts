plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.wppocket.server"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.wppocket.server"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        // CI truyen -PappVersionName=<tag bo chu v> khi build theo tag vX.Y.Z (HANDOFF.md muc 1bg); build thuong giu 0.1.0.
        versionName = (project.findProperty("appVersionName") as String?) ?: "0.1.0"
    }

    // signingConfigs.debug: TRUOC BAN NAY khong khai bao gi, nen dung
    // keystore debug MAC DINH cua Android Gradle Plugin - plugin nay tu SINH
    // "~/.android/debug.keystore" NEU CHUA CO TREN MAY. GitHub Actions la
    // may ao MOI HOAN TOAN moi lan chay (khong cache "~/.android/"), nen MOI
    // LAN BUILD CI deu sinh 1 certificate NGAU NHIEN KHAC NHAU du alias/mat
    // khau quy uoc giong nhau ("androiddebugkey"/"android") - Android CHAN
    // cai de len ban co san neu certificate khac nhau, hien thi loi chung
    // chung "Ung dung chua duoc cai dat" (khong noi ro ly do), day chinh la
    // nguyen nhan gap phai khi cai app-debug.apk cua lan build sau de len
    // ban da cai tu lan build truoc (xem HANDOFF.md muc 1l). Khai bao thang
    // 1 file "debug.keystore" COMMIT SAN trong repo (cung thu muc voi file
    // nay) de MOI lan build CI - qua khu, hien tai, tuong lai - deu ky BANG
    // CHINH XAC 1 certificate, cai de truc tiep len ban cu binh thuong,
    // khong con gap loi nay nua VE SAU (chi lan nay, chuyen tu certificate
    // ngau nhien cu sang certificate co dinh moi, buoc phai GO CAI DAT ban
    // dang co tren dien thoai 1 LAN DUY NHAT truoc khi cai ban moi).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    // QUAN TRỌNG: không nén file .so trong APK — bắt buộc để có thể mmap/thực thi
    // trực tiếp file php binary được đóng gói dưới dạng "thư viện native" (libphpsrv.so)
    packaging {
        jniLibs {
            useLegacyPackaging = false
            keepDebugSymbols += "**/*.so"
        }
    }

    // De xuat DeepSeek muc L1 (xem HANDOFF.md muc 10 + muc 1at) - "Split
    // APK theo ABI de giam size". CI (build-apk.yml) da dong goi CA
    // arm64-v8a LAN armeabi-v7a vao jniLibs/ TU TRUOC (khong phai moi lam -
    // claim "L1 chua lam" o vong 1as la SAI, da dinh chinh) - nhung mac
    // dinh Gradle se gop CA 2 kien truc vao 1 APK DUY NHAT ("fat APK"),
    // nang hon can thiet cho nguoi chi can 1 kien truc. Bat "splits" de
    // Gradle XUAT THEM 2 APK rieng, nho hon (1 cho moi ABI) CUNG LUC VOI 1
    // ban "universal" (gop ca 2, cho ai khong chac may minh la ABI nao) -
    // nguoi dung TU CHON file nao de cai, khong bat buoc phai doi gi khac.
    // "reset()" xoa danh sach ABI mac dinh (rong) truoc khi "include" - theo
    // dung tai lieu AGP, khong phai goi thua.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = true
        }
    }
}

// De xuat DeepSeek muc L5 (xem HANDOFF.md muc 10 + muc 1at) - "Reproducible
// builds". Gradle dependency locking la 1 tinh nang CHUAN, duoc tai lieu
// chinh thuc cua Gradle mo ta (khong phai tu che) - ghi lai CHINH XAC phien
// ban (ke ca phu thuoc GIAN TIEP/transitive) cua moi thu vien da duoc
// resolve vao file "gradle.lockfile", dam bao 2 lan build CUNG 1 commit
// LUON dung CUNG 1 bo phu thuoc (khong tu "troi" len ban moi hon neu upstream
// phat hanh ban moi giua luc build) - day la 1 phan CUA "reproducible build",
// khong phai toan bo (con can pin phien ban Termux rieng - xem P1, VAN
// CHUA lam duoc vi khong truy cap duoc packages.termux.dev tu moi truong
// soan file nay de biet chinh xac so phien ban nao dang co that).
//
// QUAN TRONG - CHUA tao duoc file khoa THAT: can 1 lan build Gradle
// that (./gradlew dependencies --write-locks) de SINH RA "gradle.lockfile" -
// moi truong soan file nay KHONG co Android SDK/Gradle day du (xem HANDOFF.md
// muc 2) nen CHUA tu sinh duoc file do. Bat tinh nang o day la dieu kien
// CAN, nguoi build lan dau tren may/CI that co Gradle day du se thay Gradle
// tu nhac chay lenh tren khi file khoa chua ton tai.
dependencyLocking {
    lockAllConfigurations()
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Backup tu dong dinh ky + watchdog "chua lanh tu dong" (BackupWorker,
    // HealthCheckWorker) - de xuat tu PDF, xem HANDOFF.md muc 1e. Chon ban
    // 2.9.1 (khong phai ban moi nhat) de khop an toan voi compileSdk 34 /
    // AGP 8.5.2 / Kotlin 1.9.24 dang dung trong repo nay - CHUA build-test
    // that (moi truong tao project nay khong co Android SDK, xem HANDOFF.md
    // muc 2), neu Gradle bao xung dot phien ban, day la cho dau tien can sua.
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    // S8 (PDF 2, HANDOFF.md muc 1bp-K): can de PROFILE trong app/src/main/baseline-prof.txt co hieu luc voi APK cai ngoai Google Play
    // (sideload) - Play tu cai profile, con APK cai tay thi chinh thu vien nay nap profile o lan chay dau. 1.3.1 (khong phai ban moi
    // nhat) vi cung ly do voi work-runtime o tren: khop an toan voi compileSdk 34 / AGP 8.5.2.
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
}
