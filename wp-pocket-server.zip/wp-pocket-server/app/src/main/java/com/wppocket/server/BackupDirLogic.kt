package com.wppocket.server

import java.io.File

/**
 * Noi luu backup: bo nho chinh hoac THE NHO (PDF 2 muc Q11; HANDOFF.md muc 1bp-K). Chi java.io (khong Android) de test duoc.
 *
 * PHAM VI CO Y HEP: chi cac tep zip BACKUP duoc phep sang the nho. KHONG dua CSDL MariaDB, tep thuc thi, socket hay thu muc website sang
 * the nho (the thuong la exFAT/FAT: khong co quyen Unix/symlink - thiet ke khong dua vao viec do co dung duoc hay khong).
 * Mac dinh KHONG doi gi (bo nho chinh). Bat tuy chon thi ghi vao the nho NEU co the do va ghi duoc; rut the giua chung -> lan sau tu ve bo nho
 * chinh (khong bao gio that bai chi vi the nho). Liet ke/khoi phuc/giu 5 ban/xoa du lieu gop CA HAI noi.
 */
object BackupDirLogic {
    fun isBackupFile(name: String): Boolean =
        name.startsWith("backup-") && (name.endsWith(".zip") || name.endsWith(".zip.enc"))

    /**
     * [candidates] = ket qua `getExternalFilesDirs(null)` (phan tu dau la bo nho chinh; phan tu null = the chua gan).
     * [preferRemovable] false -> luon bo nho chinh (hanh vi cu). True -> the nho dau tien thoa [isRemovable] va [isUsable], khong co thi bo nho chinh.
     */
    fun pickWriteDir(
        candidates: List<File?>,
        preferRemovable: Boolean,
        isRemovable: (File) -> Boolean,
        isUsable: (File) -> Boolean
    ): File? {
        val present = ArrayList<File>()
        for (c in candidates) if (c != null) present.add(c)
        if (preferRemovable) {
            for (c in present) if (isRemovable(c) && isUsable(c)) return c
        }
        return if (present.isEmpty()) null else present[0]
    }

    /** Gop cac ban backup tu moi thu muc, moi nhat truoc (chi tep dung ten backup-*.zip / .zip.enc). */
    fun listAll(dirs: List<File>): List<File> {
        val all = ArrayList<File>()
        for (d in dirs) {
            val fs = d.listFiles() ?: continue
            for (f in fs) if (f.isFile && isBackupFile(f.name)) all.add(f)
        }
        return all.sortedByDescending { it.lastModified() }
    }

    /** Cac tep vuot [keep] ban moi nhat TINH TREN TAT CA thu muc - can xoa. */
    fun excess(all: List<File>, keep: Int): List<File> = all.sortedByDescending { it.lastModified() }.drop(keep)
}
