package com.wppocket.server

import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gui file backup toi 1 webhook HTTPS BAT KY do nguoi dung tu dien URL -
 * de xuat tu PDF "dong bo backup len Google Drive/AWS S3/FTP" (xem
 * HANDOFF.md muc 1e/1g), nhung KHONG lam OAuth Google that.
 *
 * LY DO chon huong nay thay vi Google Sign-In/Drive API chinh thong (xem
 * HANDOFF.md muc 1g de biet chi tiet day du):
 *  1) Can them Google Play Services (`com.google.android.gms:play-services-auth`)
 *     - phu thuoc NANG hon han moi thu da co trong du an, va khong dam bao
 *     co san tren MOI dien thoai Android (vd may khong co dich vu Google).
 *  2) OAuth Client ID kieu "Android" BAT BUOC khop SHA-1 chu ky APK - du an
 *     nay hien CHUA co code signing on dinh (chi assembleDebug, xem
 *     HANDOFF.md muc 7.6), nen SHA-1 co the doi MOI LAN build lai qua
 *     GitHub Actions -> OAuth se hong lien tuc neu lam luc nay.
 *  3) Google yeu cau xac minh ung dung (App Verification) cho scope Drive
 *     nhay cam neu vuot qua so luong nho "test users" - qua nhieu rao can
 *     cho 1 app ca nhan chay tren dien thoai cua chinh minh.
 *
 * Webhook tong quat giai quyet DUNG nhu cau "day backup ra ngoai dien
 * thoai" ma KHONG dinh vao 3 rao can tren - nguoi dung co the tro no toi:
 *  - Google Apps Script Web App (doPost() + DriveApp.createFile() - mau
 *    rat pho bien, script chay duoi quyen TAI KHOAN GOOGLE CUA NGUOI DUNG,
 *    hoan toan KHONG can OAuth phia Android) -> luu duoc vao Google Drive
 *    that ma khong dinh 3 rao can tren.
 *  - Bat ky webhook nao khac: n8n/Make.com/Zapier (roi noi tiep sang Drive/
 *    S3/Dropbox...), server rieng, v.v.
 */
object WebhookUploader {
    private const val TAG = "WebhookUploader"

    fun isConfigured(url: String?): Boolean = !url.isNullOrBlank() && (url.startsWith("http://") || url.startsWith("https://"))

    /** Gui file qua multipart/form-data POST, field ten "file". Tra ve true neu server tra ve 2xx. */
    fun uploadFile(webhookUrl: String, file: File): Boolean {
        return try {
            val boundary = "----WPPocketBoundary${System.currentTimeMillis()}"
            val conn = (URL(webhookUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 15_000
                readTimeout = 120_000 // file co the vai chuc MB, mang di dong can nhieu thoi gian
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            conn.outputStream.use { out ->
                out.write("--$boundary\r\n".toByteArray())
                out.write(
                    "Content-Disposition: form-data; name=\"file\"; filename=\"${file.name}\"\r\n"
                        .toByteArray()
                )
                out.write("Content-Type: application/zip\r\n\r\n".toByteArray())
                file.inputStream().use { it.copyTo(out) }
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }

            val ok = conn.responseCode in 200..299
            if (!ok) Log.w(TAG, "Webhook tra ve ma ${conn.responseCode}")
            conn.disconnect()
            ok
        } catch (e: Exception) {
            Log.e(TAG, "Gui backup qua webhook loi (file van luu tren may, khong mat)", e)
            false
        }
    }
}
