package com.wppocket.server

import android.content.Context

/**
 * Dam bao cac WorkManager job dinh ky (backup tu dong, dieu khien Telegram)
 * duoc dang ky/huy DUNG theo Prefs da luu - tach rieng de goi duoc tu CA 2
 * noi: MainActivity.onCreate() (nguoi dung mo app) VA
 * ServerForegroundService.onCreate() (server tu khoi dong qua BootReceiver).
 *
 * LY DO can goi tu ca 2 noi (khong chi MainActivity): Android "Buoc dung"
 * (Force Stop, trong Cai dat > Ung dung) se HUY HET cac WorkManager job da
 * dang ky cho app do - neu sau do thiet bi khoi dong lai (auto-start bat
 * server qua BootReceiver) MA nguoi dung CHUA mo lai app, backup tu dong/
 * dieu khien Telegram se khong duoc dang ky lai neu logic nay chi nam trong
 * MainActivity.onCreate(). Goi ham nay trong
 * ServerForegroundService.onCreate() (chay o CA 2 truong hop mo app lan
 * BootReceiver) dam bao khong con lo hong nay.
 */
object WorkScheduler {
    fun ensureScheduledFromPrefs(context: Context) {
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)

        HealthCheckWorker.ensureScheduled(context)

        if (prefs.getBoolean(Prefs.KEY_BACKUP_AUTO_ENABLED, false)) {
            val hours = prefs.getInt(Prefs.KEY_BACKUP_INTERVAL_HOURS, Prefs.DEFAULT_BACKUP_INTERVAL_HOURS.toInt())
            BackupWorker.schedule(context, hours.toLong())
        } else {
            BackupWorker.cancel(context)
        }

        val botToken = prefs.getString(Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
        if (TelegramNotifier.isConfigured(botToken, chatId)) {
            TelegramCommandWorker.schedule(context)
        } else {
            TelegramCommandWorker.cancel(context)
        }
    }
}
