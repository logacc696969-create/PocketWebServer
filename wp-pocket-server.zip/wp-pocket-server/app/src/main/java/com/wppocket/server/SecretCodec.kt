package com.wppocket.server

import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Dong goi/mo goi bi mat bang AES-256-GCM (PDF 2 muc AC1; HANDOFF.md muc 1bp-I). Chi javax.crypto/java.util (khong Android) nen
 * test duoc tren JDK that. Khoa do [SecretStore] cung cap (Android Keystore) - o day chi la thuat toan.
 * Dinh dang luu: "enc1:" + Base64( IV(12 byte) + ban ma + the xac thuc GCM(16 byte) ). IV do nha cung cap sinh (Keystore bat buoc
 * ma hoa ngau nhien, khong cho tu dat IV), nen moi lan ma hoa ra chuoi khac nhau.
 * `EncryptedSharedPreferences` cua Jetpack da bi danh dau loi thoi nen tu viet lop mong nay (khong them phu thuoc).
 */
object SecretCodec {
    const val PREFIX = "enc1:"
    private const val TAG_BITS = 128
    private const val IV_BYTES = 12

    fun isSealed(s: String?): Boolean = s != null && s.startsWith(PREFIX)

    fun seal(key: SecretKey, plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key)
        val iv = c.iv
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        val out = ByteArray(iv.size + ct.size)
        System.arraycopy(iv, 0, out, 0, iv.size)
        System.arraycopy(ct, 0, out, iv.size, ct.size)
        return PREFIX + Base64.getEncoder().encodeToString(out)
    }

    /** Chuoi chua ma hoa duoc tra nguyen. Sai khoa / du lieu bi sua / hong dinh dang -> null (KHONG nem loi, KHONG tra rac). */
    fun open(key: SecretKey, stored: String): String? {
        if (!isSealed(stored)) return stored
        return try {
            val raw = Base64.getDecoder().decode(stored.substring(PREFIX.length))
            if (raw.size < IV_BYTES + TAG_BITS / 8) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_BITS, raw, 0, IV_BYTES))
            String(c.doFinal(raw, IV_BYTES, raw.size - IV_BYTES), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}
