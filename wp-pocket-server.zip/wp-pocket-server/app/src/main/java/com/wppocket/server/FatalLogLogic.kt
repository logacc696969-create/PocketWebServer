package com.wppocket.server

import java.io.File
import java.io.RandomAccessFile

/**
 * Theo doi loi PHP nghiem trong (PDF 2 muc H6; HANDOFF.md muc 1bp). Chi java.* (khong Android) de test duoc.
 *
 * CACH LAM KHONG CAN VIET THEM DONG PHP NAO: PHP DA ghi moi loi vao `lamp-run/php-error.log` (php-fpm.conf.template:
 * `php_admin_value[error_log]` + `log_errors = On`). Chi can doc PHAN MOI cua file do (theo vi tri byte, cung khuon voi
 * `checkAdminAudit`), nhan dien dong "PHP Fatal error:" / "PHP Parse error:", gom nhom theo "chu ky" (bo so/thoi gian) va
 * phan loai: het bo nho (memory_limit), qua thoi gian (max_execution_time), loi cu phap, loi khong duoc xu ly. Truoc day mot plugin
 * lam trang web trang tron (HTTP 500) chi co trong file log ma khong ai duoc bao.
 */
object FatalLogLogic {
    /** Moi lan chi doc toi da phan CUOI nay cua file (file log co the rat lon). */
    const val MAX_READ_BYTES: Long = 256L * 1024L

    class Group(val kind: String, val count: Int, val sample: String)

    private val FATAL_MARK = Regex("PHP (Fatal error|Parse error):")
    private val DIGITS = Regex("[0-9]+")

    fun isFatalLine(line: String): Boolean = FATAL_MARK.containsMatchIn(line)

    fun classify(line: String): String {
        if (line.contains("Allowed memory size of")) return "memory"
        if (line.contains("Maximum execution time of")) return "timeout"
        if (line.contains("PHP Parse error:")) return "parse"
        if (line.contains("Uncaught")) return "uncaught"
        return "other"
    }

    /** Bo tien to "[thoi gian] " cua PHP, doi moi day chu so thanh '#', cat 160 ky tu -> cac loi cung loai gom lam mot. */
    fun signature(line: String): String = line.substringAfter("] ", line).replace(DIGITS, "#").trim().take(160)

    fun scan(lines: List<String>): List<Group> {
        val counts = LinkedHashMap<String, IntArray>()
        val kinds = HashMap<String, String>()
        val samples = HashMap<String, String>()
        for (l in lines) {
            if (!isFatalLine(l)) continue
            val sig = signature(l)
            val c = counts[sig]
            if (c == null) {
                counts[sig] = intArrayOf(1)
                kinds[sig] = classify(l)
                samples[sig] = l.substringAfter("] ", l).trim().take(200)
            } else {
                c[0] = c[0] + 1
            }
        }
        val out = ArrayList<Group>()
        for (e in counts.entries) out.add(Group(kinds[e.key] ?: "other", e.value[0], samples[e.key] ?: ""))
        return out
    }

    /**
     * Doc phan MOI cua [file] ke tu [fromOffset]; tra ve (cac dong, vi tri moi). File bi cat/xoay vong (nho hon offset da luu)
     * -> doc lai tu dau. Toi da [MAX_READ_BYTES] cuoi cung.
     */
    fun readNew(file: File, fromOffset: Long): Pair<List<String>, Long> {
        if (!file.isFile) return Pair(emptyList(), 0L)
        val len = file.length()
        var start = if (fromOffset in 0L..len) fromOffset else 0L
        if (len - start > MAX_READ_BYTES) start = len - MAX_READ_BYTES
        if (len == start) return Pair(emptyList(), len)
        return RandomAccessFile(file, "r").use { raf ->
            raf.seek(start)
            val buf = ByteArray((len - start).toInt())
            raf.readFully(buf)
            Pair(String(buf, Charsets.UTF_8).split('\n'), len)
        }
    }

    fun kindLabel(kind: String): String = when (kind) {
        "memory" -> "het bo nho PHP (memory_limit) - plugin/trang qua nang"
        "timeout" -> "vuot thoi gian thuc thi toi da (max_execution_time) - tac vu qua lau"
        "parse" -> "loi cu phap PHP (plugin/theme sua do hoac khong tuong thich)"
        "uncaught" -> "loi PHP khong duoc xu ly (thuong do plugin/theme)"
        else -> "loi PHP nghiem trong"
    }

    /** Noi dung canh bao (khong dau, cung phong cach thong bao khac); null neu khong co loi nao. */
    fun alertText(groups: List<Group>): String? {
        if (groups.isEmpty()) return null
        var total = 0
        for (g in groups) total += g.count
        val sb = StringBuilder("WP Pocket Server: $total loi PHP nghiem trong moi (${groups.size} loai).")
        for (g in groups.take(3)) {
            sb.append("\n- ").append(g.count).append("x ").append(kindLabel(g.kind)).append(": ").append(g.sample.take(120))
        }
        sb.append("\nXem chi tiet: muc Log, chon PHP - loi.")
        return sb.toString()
    }

    fun cooledDown(now: Long, lastAlertAt: Long, cooldownMs: Long): Boolean = now - lastAlertAt >= cooldownMs
}
