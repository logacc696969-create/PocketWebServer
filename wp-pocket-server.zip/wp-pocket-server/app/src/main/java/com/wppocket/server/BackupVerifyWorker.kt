package com.wppocket.server

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * H1 (PDF 2, HANDOFF.md muc 1bm): moi tuan khoi phuc THU backup moi nhat vao database tam (xem [BackupVerifier]). Chi lap lich khi
 * nguoi dung bat backup tu dong (WorkScheduler). Luon tra success() - ket qua nam o Prefs.KEY_VERIFY_LAST_* va tin Telegram/webhook
 * (retry se chi nap lai database lan nua ma khong sua duoc loi cua backup).
 */
class BackupVerifyWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        try {
            BackupVerifier.record(applicationContext, BackupVerifier.verifyLatest(applicationContext))
        } catch (e: Exception) {
            Log.w("BackupVerifyWorker", "loi: ${e.javaClass.simpleName}")
        }
        return Result.success()
    }

    companion object {
        private const val UNIQUE_NAME = "wp_pocket_backup_verify"
        private const val UNIQUE_NOW = "wp_pocket_backup_verify_now"

        /** Moi 7 ngay, tre 6 gio dau (khong nap DB ngay luc vua mo app/khoi dong server). KEEP: khong dat lai dong ho moi lan mo app. */
        fun schedule(context: Context) {
            val constraints = Constraints.Builder().setRequiresBatteryNotLow(true).build()
            val request = PeriodicWorkRequestBuilder<BackupVerifyWorker>(7, TimeUnit.DAYS)
                .setConstraints(constraints)
                .setInitialDelay(6, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
        }

        /** Chay 1 lan NGAY (lenh /verify cua Telegram). KEEP: dang chay roi thi khong xep them. */
        fun runNow(context: Context) {
            WorkManager.getInstance(context).enqueueUniqueWork(
                UNIQUE_NOW, ExistingWorkPolicy.KEEP, OneTimeWorkRequestBuilder<BackupVerifyWorker>().build()
            )
        }
    }
}
