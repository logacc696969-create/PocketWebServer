package com.wppocket.server

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Dieu khien tu xa qua Telegram (/status, /backup, /restart) - de xuat tu
 * PDF "Tien loi hoa quan ly qua Telegram Bot: dieu khien tu xa co ban" (xem
 * HANDOFF.md muc 1h).
 *
 * AN TOAN HON webhook 2 chieu ma HANDOFF.md muc 1e da TU CHOI truoc do (ly
 * do luc do: webhook can 1 tien trinh lang nghe lien tuc HOAC 1 URL cong
 * khai them be mat tan cong): worker nay dung LONG-POLLING (phone chu dong
 * HOI Telegram dinh ky qua getUpdates, KHONG mo port/URL nao ca) - day la
 * cach CHINH THUC Telegram Bot API khuyen dung cho bot khong co server rieng.
 *
 * Bao mat: CHI thuc thi lenh tu DUNG chatId da cau hinh trong app (so sanh
 * bang so, khong phai chuoi - tranh nguoi la biet duoc Bot Token (vd token
 * bi lo) roi tu nhan tin gia mao chi so - van khong lam gi duoc neu chatId
 * khong khop). Lenh tu nguoi KHONG dung chatId bi bo qua HOAN TOAN (khong
 * tra loi gi, tranh lo thong tin server co ton tai/dang chay cho nguoi la).
 */
class TelegramCommandWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val botToken = prefs.getString(Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val configuredChatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)?.trim()?.toLongOrNull()
        if (botToken.isNullOrBlank() || configuredChatId == null) {
            return Result.success() // chua cau hinh Telegram - khong co gi de lam
        }

        val offset = prefs.getLong(Prefs.KEY_TELEGRAM_UPDATE_OFFSET, 0L)
        val commands = TelegramNotifier.getUpdates(botToken, offset)
        if (commands.isEmpty()) return Result.success()

        var maxUpdateId = offset - 1
        for (cmd in commands) {
            if (cmd.updateId > maxUpdateId) maxUpdateId = cmd.updateId
            if (cmd.chatId != configuredChatId) continue // khong dung nguoi - bo qua hoan toan, khong tra loi
            handleCommand(botToken, configuredChatId, cmd.text)
        }

        // Luu offset = update_id lon nhat + 1, DU co lenh tu nguoi la hay khong
        // (Telegram tinh "da xu ly" theo update_id, khong phai theo chatId).
        prefs.edit().putLong(Prefs.KEY_TELEGRAM_UPDATE_OFFSET, maxUpdateId + 1).apply()
        return Result.success()
    }

    private fun handleCommand(botToken: String, chatId: Long, rawText: String) {
        val text = rawText.substringBefore('@').lowercase() // bo "@tenbot" neu nhan tin trong group
        when {
            text == "/status" -> replyStatus(botToken, chatId)
            text == "/backup" -> replyBackup(botToken, chatId)
            text == "/restart" || text == "/restart_service" -> replyRestart(botToken, chatId)
            text == "/help" || text == "/start" -> TelegramNotifier.sendMessage(
                botToken, chatId.toString(),
                "Cac lenh ho tro:\n/status - xem tai nguyen may\n/backup - backup ngay + gui file\n/restart - khoi dong lai server"
            )
            else -> TelegramNotifier.sendMessage(botToken, chatId.toString(), "Khong hieu lenh. Go /help de xem danh sach.")
        }
    }

    private fun replyStatus(botToken: String, chatId: Long) {
        val am = applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val freeMb = mem.availMem / (1024 * 1024)
        val totalMb = mem.totalMem / (1024 * 1024)

        val dataDir = applicationContext.filesDir
        val freeDiskMb = dataDir.usableSpace / (1024 * 1024)
        val totalDiskMb = dataDir.totalSpace / (1024 * 1024)

        val running = ServerForegroundService.isRunning
        val battery = try {
            val bm = applicationContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (_: Exception) {
            -1
        }

        val text = buildString {
            appendLine("Trang thai WP Pocket Server:")
            appendLine("- Server: ${if (running) "dang chay" else "KHONG chay"}")
            appendLine("- RAM: con trong ${freeMb}MB / tong ${totalMb}MB")
            appendLine("- Dung luong: con trong ${freeDiskMb}MB / tong ${totalDiskMb}MB")
            if (battery >= 0) appendLine("- Pin: $battery%")
        }
        TelegramNotifier.sendMessage(botToken, chatId.toString(), text.trim())
    }

    private fun replyBackup(botToken: String, chatId: Long) {
        try {
            val result = BackupManager.performBackup(applicationContext)
            val dbNote = if (result.dbDumped) "kem database" else "chi file website"
            TelegramNotifier.sendDocument(botToken, chatId.toString(), result.file, "Backup theo yeu cau ($dbNote)")
        } catch (e: Exception) {
            TelegramNotifier.sendMessage(botToken, chatId.toString(), "Backup that bai: ${e.message}")
        }
    }

    private fun replyRestart(botToken: String, chatId: Long) {
        TelegramNotifier.sendMessage(botToken, chatId.toString(), "Dang khoi dong lai server...")
        val intent = Intent(applicationContext, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_STOP
        }
        applicationContext.startService(intent)
        // Doi 1 chut cho tien trinh cu thoat han truoc khi bat lai, tranh dung
        // do socket/port con giu boi tien trinh vua bi kill.
        Thread.sleep(3000)
        val startIntent = Intent(applicationContext, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_START
        }
        ContextCompat.startForegroundService(applicationContext, startIntent)
    }

    companion object {
        private const val UNIQUE_NAME = "wp_pocket_telegram_commands"

        /** Chi nen goi khi Telegram DA cau hinh (kiem tra o noi goi, vd
         * MainActivity sau khi luu Bot Token/Chat ID) - goi vo ich (nhung vo
         * hai, doWork() se tu return som) neu chua cau hinh. */
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<TelegramCommandWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
        }
    }
}
