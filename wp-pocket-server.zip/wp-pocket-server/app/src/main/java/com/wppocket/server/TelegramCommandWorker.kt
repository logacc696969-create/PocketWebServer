package com.wppocket.server

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Dieu khien tu xa qua Telegram (/status, /backup, /restart) - de xuat tu
 * PDF "Tien loi hoa quan ly qua Telegram Bot: dieu khien tu xa co ban" (xem
 * HANDOFF.md muc 1h).
 *
 * AN TOAN HON webhook 2 chieu ma HANDOFF.md muc 1e da TU CHOI truoc do (ly
 * do luc do: webhook can 1 tien trinh lang nghe lien tuc HOAC 1 URL cong
 * khai them be mat tan cong): worker nay dung LONG-POLLING (phone chu dong
 * HOI Telegram dinh ky qua getUpdates, KHONG mo port/URL nao ca) - day la
 * cach CHINH THUC Telegram Bot API khuyen dung cho bot khong co server rieng.
 *
 * Bao mat: CHI thuc thi lenh tu DUNG chatId da cau hinh trong app (so sanh
 * bang so, khong phai chuoi - tranh nguoi la biet duoc Bot Token (vd token
 * bi lo) roi tu nhan tin gia mao chi so - van khong lam gi duoc neu chatId
 * khong khop). Lenh tu nguoi KHONG dung chatId bi bo qua HOAN TOAN (khong
 * tra loi gi, tranh lo thong tin server co ton tai/dang chay cho nguoi la).
 */
class TelegramCommandWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        // De xuat DeepSeek muc B5 (xem HANDOFF.md muc 10 + muc 1aq) - long-
        // poll Telegram la 1 trong 2 "worker nang" PDF nhac toi (cung voi
        // backup, xem BackupWorker.kt) - hoan 1 chu ky khi RAM dang cang
        // thang, tu nhien thu lai o chu ky dinh ky ke tiep (khoang cach giua
        // 2 lan chay worker nay ngan hon nhieu BackupWorker, nen "bo lo 1
        // chu ky" o day gan nhu khong nguoi dung nao nhan ra, khac voi backup
        // dinh ky thua hon).
        if (Prefs.isUnderMemoryPressure(applicationContext)) {
            Log.w("TelegramCommandWorker", "May dang thieu RAM (canh bao gan day) - hoan poll Telegram sang chu ky sau")
            return Result.success()
        }

        // De xuat DeepSeek muc B1 (xem HANDOFF.md muc 1au): pin < 15% va khong
        // sac -> bo qua chu ky poll nay (giu pin cho chinh website). Mac dinh
        // BAT, tat duoc trong app ("Giu poll Telegram du pin yeu").
        if (Monitoring.shouldPauseForLowBattery(applicationContext)) {
            Log.w("TelegramCommandWorker", "Pin yeu (<15%, khong sac) - hoan poll Telegram sang chu ky sau")
            return Result.success()
        }

        val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val botToken = SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val configuredChatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)?.trim()?.toLongOrNull()
        if (botToken.isNullOrBlank() || configuredChatId == null) {
            return Result.success() // chua cau hinh Telegram - khong co gi de lam
        }

        val offset = prefs.getLong(Prefs.KEY_TELEGRAM_UPDATE_OFFSET, 0L)
        val commands = TelegramNotifier.getUpdates(botToken, offset)
        if (commands.isEmpty()) return Result.success()

        var maxUpdateId = offset - 1
        for (cmd in commands) {
            if (cmd.updateId > maxUpdateId) maxUpdateId = cmd.updateId
            if (cmd.chatId != configuredChatId) continue // khong dung nguoi - bo qua hoan toan, khong tra loi
            handleCommand(botToken, configuredChatId, cmd.text)
        }

        // Luu offset = update_id lon nhat + 1, DU co lenh tu nguoi la hay khong
        // (Telegram tinh "da xu ly" theo update_id, khong phai theo chatId).
        prefs.edit().putLong(Prefs.KEY_TELEGRAM_UPDATE_OFFSET, maxUpdateId + 1).apply()
        return Result.success()
    }

    private fun handleCommand(botToken: String, chatId: Long, rawText: String) {
        val text = rawText.substringBefore('@').lowercase() // bo "@tenbot" neu nhan tin trong group
        when {
            text == "/status" -> replyStatus(botToken, chatId)
            text == "/backup" -> replyBackup(botToken, chatId)
            text == "/restart" || text == "/restart_service" -> replyRestart(botToken, chatId)
            text == "/verify" -> {
                BackupVerifyWorker.runNow(applicationContext)
                TelegramNotifier.sendMessage(botToken, chatId.toString(), "Da xep lich khoi phuc thu backup moi nhat vao database tam. Ket qua xem o /status (co the mat vai phut).")
            }
            text == "/help" || text == "/start" -> TelegramNotifier.sendMessage(
                botToken, chatId.toString(),
                "Cac lenh ho tro:\n/status - xem tai nguyen may\n/backup - backup ngay + gui file\n/verify - khoi phuc thu backup moi nhat\n/restart - khoi dong lai server"
            )
            else -> TelegramNotifier.sendMessage(botToken, chatId.toString(), "Khong hieu lenh. Go /help de xem danh sach.")
        }
    }

    private fun replyStatus(botToken: String, chatId: Long) {
        val am = applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val freeMb = mem.availMem / (1024 * 1024)
        val totalMb = mem.totalMem / (1024 * 1024)

        val dataDir = applicationContext.filesDir
        val freeDiskMb = dataDir.usableSpace / (1024 * 1024)
        val totalDiskMb = dataDir.totalSpace / (1024 * 1024)

        val running = ServerForegroundService.isRunning
        val battery = try {
            val bm = applicationContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (_: Exception) {
            -1
        }

        val text = buildString {
            appendLine("Trang thai WP Pocket Server:")
            appendLine("- Server: ${if (running) "dang chay" else "KHONG chay"}")
            appendLine("- RAM: con trong ${freeMb}MB / tong ${totalMb}MB")
            appendLine("- Dung luong: con trong ${freeDiskMb}MB / tong ${totalDiskMb}MB")
            if (battery >= 0) appendLine("- Pin: $battery%")
            Monitoring.monthlyDataSummary(applicationContext)?.let { appendLine(it) }
            Monitoring.uptimeSummary(applicationContext)?.let { appendLine(it) }
            BackupVerifier.summary(applicationContext)?.let { appendLine(it) }
        }
        TelegramNotifier.sendMessage(botToken, chatId.toString(), text.trim())
    }

    private fun replyBackup(botToken: String, chatId: Long) {
        // PDF (phan "Con gi nua"): "Rate limit Telegram commands - spam /backup" - moi lan backup ton CPU, pin va du lieu 4G
        // (gui file qua Telegram). Toi da 1 lan / 2 phut; dong ho may bi chinh lui (now < last) thi coi nhu khong con cho.
        val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong(Prefs.KEY_TELEGRAM_LAST_BACKUP_CMD, 0L)
        if (now >= last && now - last < BACKUP_COOLDOWN_MS) {
            val waitSec = (BACKUP_COOLDOWN_MS - (now - last)) / 1000 + 1
            TelegramNotifier.sendMessage(botToken, chatId.toString(), "Vua backup cach day chua den 2 phut - doi khoang $waitSec giay nua roi thu lai.")
            return
        }
        prefs.edit().putLong(Prefs.KEY_TELEGRAM_LAST_BACKUP_CMD, now).apply()
        try {
            val result = BackupManager.performBackup(applicationContext)
            val dbNote = if (result.dbDumped) "kem database" else "chi file website"
            // result.encrypted phan anh DUNG cau hinh ma hoa cua nguoi dung
            // (performBackup tu doc qua BackupManager.effectivePassphrase) -
            // ghi ro de ho biet ban gui di la ban DA/CHUA ma hoa.
            val encNote = if (result.encrypted) ", DA MA HOA" else ", CHUA ma hoa"
            val sent = TelegramNotifier.sendDocument(botToken, chatId.toString(), result.file, "Backup theo yeu cau ($dbNote$encNote)")
            // HANDOFF 1bo-F: bao ro khi file KHONG toi noi (vd > 50 MB) thay vi im lang.
            val failNote = UploadLogic.failureNote(true, sent, false, true, result.file.length())
            if (failNote != null) TelegramNotifier.sendMessage(botToken, chatId.toString(), "WP Pocket Server - $failNote")
        } catch (e: Exception) {
            TelegramNotifier.sendMessage(botToken, chatId.toString(), "Backup that bai: ${e.message}")
        }
    }

    private fun replyRestart(botToken: String, chatId: Long) {
        TelegramNotifier.sendMessage(botToken, chatId.toString(), "Dang khoi dong lai server...")
        val intent = Intent(applicationContext, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_STOP
        }
        applicationContext.startService(intent)
        // Doi 1 chut cho tien trinh cu thoat han truoc khi bat lai, tranh dung
        // do socket/port con giu boi tien trinh vua bi kill.
        Thread.sleep(3000)
        val startIntent = Intent(applicationContext, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_START
        }
        ContextCompat.startForegroundService(applicationContext, startIntent)
    }

    companion object {
        /** Khoang cach toi thieu giua 2 lenh /backup duoc thuc hien. */
        private const val BACKUP_COOLDOWN_MS = 120_000L

        private const val UNIQUE_NAME = "wp_pocket_telegram_commands"

        /** Chi nen goi khi Telegram DA cau hinh (kiem tra o noi goi, vd
         * MainActivity sau khi luu Bot Token/Chat ID) - goi vo ich (nhung vo
         * hai, doWork() se tu return som) neu chua cau hinh. */
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<TelegramCommandWorker>(15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
        }
    }
}
