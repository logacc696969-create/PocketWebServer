package com.wppocket.server

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetworkUtils {

    /**
     * Lấy địa chỉ IPv4 nội bộ (LAN) hiện tại của thiết bị — hoạt động cho cả
     * WiFi lẫn hotspot/ethernet, không phụ thuộc WifiManager (vốn hạn chế dần
     * qua các bản Android). Trả về null nếu không có kết nối nào.
     */
    fun getLocalIpAddress(): String? {
        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                if (!intf.isUp || intf.isLoopback) continue
                val addresses = Collections.list(intf.inetAddresses)
                for (addr in addresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        return addr.hostAddress
                    }
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}
