package com.wppocket.server

import java.security.SecureRandom
import java.util.Random

/**
 * Chinh sach mat khau quan tri _admin/ (HANDOFF.md muc 1bc; PDF "chat luong tinh phi" G3) - LOGIC THUAN (khong import
 * android.*) de kiem thu that tren JVM (scripts/tests/PasswordPolicyTest.kt).
 *
 * TRUOC 1bc chi kiem "do dai >= 6": "123456", "password", "aaaaaa" deu duoc chap nhan; trang _admin/ chi vao duoc qua LAN
 * nhung bo dem khoa theo TUNG IP nen ke trong LAN doi IP van do duoc.
 *
 * DAY LA "SAN" CHU KHONG PHAI DONG HO DO DO MANH: chan mat khau hien nhien yeu va 2 loi KHOA DANG NHAP THAT, khong thay the
 * mat khau ngau nhien (mac dinh app sinh 16 ky tu) hay 2FA. Nho: "Admin2024xyz" van qua; muon an toan that thi dung mat khau
 * ngau nhien/2FA.
 *
 * LOI THAT can chan (da tai hien bang PHP that, xem admin-session-test.py muc 10): admin-auth.php doc mat khau bang
 * `trim(file_get_contents(...))` nhung so voi chuoi form GUI NGUYEN VAN => mat khau co dau cach/xuong dong o DAU/CUOI duoc
 * luu "co dau cach" nhung PHP so sanh voi ban da trim => KHONG BAO GIO dang nhap duoc nua (tu khoa minh).
 */
object PasswordPolicy {

    const val MIN_LENGTH = 8

    /** Thu tu = thu tu uu tien bao loi (loi dau tien tim thay duoc tra ve). */
    enum class Problem { WHITESPACE_OR_CONTROL, TOO_SHORT, TOO_COMMON, SEQUENCE_OR_REPEAT, LOW_VARIETY }

    /** Bang ky tu bo "de nham" (I, l, O, 0, 1) - dung chung cho ServerForegroundService + MainActivity. */
    const val GENERATED_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    const val GENERATED_LENGTH = 16

    private val COMMON: Set<String> = setOf(
        // pho bien toan cau
        "password", "passw0rd", "pass", "passwd", "admin", "administrator", "root", "toor", "user", "guest", "login", "welcome",
        "letmein", "master", "secret", "qwerty", "qwertyuiop", "qwert", "asdfgh", "asdfghjkl", "zxcvbn", "zxcvbnm", "azerty",
        "iloveyou", "monkey", "dragon", "football", "baseball", "superman", "batman", "sunshine", "princess", "shadow",
        "trustno1", "abc", "abcd", "abcde", "abcdef", "abcdefg", "abcdefgh", "test", "testing", "demo", "default", "changeme",
        "change", "temp", "temporary", "hello", "hunter", "freedom", "whatever", "starwars", "access", "flower", "mustang",
        "696969", "internet", "computer", "google", "facebook", "mypass", "mypassword", "pa55word", "p4ssword",
        // dac thu du an / thiet bi / web
        "wordpress", "wppocket", "wpadmin", "wpocket", "pocket", "pocketserver", "server", "webserver", "localhost", "adminer",
        "mariadb", "mysql", "nginx", "android", "samsung", "iphone", "xiaomi", "oppo", "vivo", "sharp", "sony", "pixel", "phone",
        // tieng Viet khong dau
        "matkhau", "mat khau", "matkhau123", "vietnam", "hanoi", "saigon", "hochiminh", "yeuem", "anhyeuem", "emyeuanh",
        "yeuanh", "thienthan", "daiphat", "chucmung", "xinchao", "quantri", "quantrivien",
        // chuoi so/ban phim
        "123456", "1234567", "12345678", "123456789", "1234567890", "12345", "1234", "123123", "112233", "000000", "111111",
        "121212", "654321", "987654321", "123321", "666666", "888888", "999999", "1q2w3e", "1q2w3e4r", "1qaz2wsx", "qazwsx",
        "q1w2e3r4", "zaq12wsx"
    )

    private val SEQUENCES: List<String> = listOf(
        "abcdefghijklmnopqrstuvwxyz", "0123456789", "qwertyuiopasdfghjklzxcvbnm", "qwertyuiop", "asdfghjkl", "zxcvbnm"
    ).flatMap { listOf(it, it.reversed()) }

    /** Doi cac ky tu "leet" pho bien ve chu: p@ssw0rd -> password. Chi dung de so voi danh sach pho bien. */
    private fun deLeet(s: String): String = buildString {
        for (c in s) append(when (c) { '@' -> 'a'; '0' -> 'o'; '$' -> 's'; '3' -> 'e'; '4' -> 'a'; '5' -> 's'; '7' -> 't'; else -> c })
    }

    private fun stripTail(s: String): String = s.trimEnd { it.isDigit() || it in "!@#$%^&*()._-+=?" }

    private fun isCommon(lower: String): Boolean {
        for (v in listOf(lower, deLeet(lower))) {
            if (v in COMMON) return true
            val stripped = stripTail(v)
            if (stripped.length >= 3 && stripped in COMMON) return true   // "admin2024", "password123!", "p@ssw0rd99"
        }
        return false
    }

    /** Ca chuoi la 1 doan lien tiep cua day so/chu/ban phim (xuoi hoac nguoc): "12345678", "abcdefgh", "qwertyui". */
    private fun isSequence(lower: String): Boolean = SEQUENCES.any { it.contains(lower) }

    /** Ca chuoi la 1 don vi ngan (1-4 ky tu) lap lai: "aaaaaaaa", "abababab", "abcabcabc", "12341234". */
    private fun isRepeat(s: String): Boolean {
        for (u in 1..4) {
            if (s.length >= 2 * u && s.length % u == 0 && s == s.substring(0, u).repeat(s.length / u)) return true
        }
        return false
    }

    /** null = dat chinh sach; con lai = ly do dau tien khong dat. */
    fun check(pw: String): Problem? {
        if (pw != pw.trim() || pw.any { it.isISOControl() }) return Problem.WHITESPACE_OR_CONTROL
        if (pw.length < MIN_LENGTH) return Problem.TOO_SHORT
        val lower = pw.lowercase()
        if (isCommon(lower)) return Problem.TOO_COMMON
        if (isSequence(lower) || isRepeat(lower)) return Problem.SEQUENCE_OR_REPEAT
        if (pw.toSet().size < 4) return Problem.LOW_VARIETY
        return null
    }

    /** Sinh mat khau ngau nhien (SecureRandom mac dinh) - CHAC CHAN dat [check] (lap lai den khi dat; thuc te lan dau da dat). */
    fun generate(random: Random = SecureRandom()): String {
        while (true) {
            val pw = (1..GENERATED_LENGTH).map { GENERATED_ALPHABET[random.nextInt(GENERATED_ALPHABET.length)] }.joinToString("")
            if (check(pw) == null) return pw
        }
    }
}
