package com.wppocket.server

import java.io.File
import java.util.Locale

/**
 * Vong doi du lieu (PDF 2 muc AB1 + AB3; HANDOFF.md muc 1bo). Chi java.io - khong Android - de test JVM duoc.
 *
 * AB1: nguoi dung khong biet du lieu nam dau va chiem bao nhieu -> hop thoai "Du lieu tren may".
 * AB3: "Xoa toan bo du lieu" trong app. Truoc day chi co Cai dat Android > Bo nho > Xoa du lieu (khong ai nhan ra
 * de dung, va o che do chuyen dung 24/7 nguoi dung it khi vao cai dat he thong). Thao tac KHONG hoan tac nen
 * bat nguoi dung GO LAI mot tu ([wipeConfirmed]) thay vi chi bam "OK".
 *
 * Duong dan (cung nguon voi start-lamp.sh: DATA=$HOME=filesDir; docroot "www" o MOI runtime - xem php.sh,
 * generic_runtime.sh; backup o getExternalFilesDir(null)/backups - xem BackupManager).
 */
object DataLifecycle {
    const val SITE_DIR = "www"
    const val DB_DIR = "mysql-data"
    const val RUN_DIR = "lamp-run"

    class Report(val site: Long, val db: Long, val run: Long, val backups: Long, val other: Long)

    /** Dung luong tung nhom (bo qua symlink - cung quy tac voi uoc luong dung luong backup). */
    fun collect(filesDir: File, backupsDir: File?): Report = collectAll(filesDir, if (backupsDir == null) emptyList() else listOf(backupsDir))

    /** Nhu [collect] nhung backup nam o NHIEU noi (bo nho chinh + the nho, Q11) - cong don. */
    fun collectAll(filesDir: File, backupsDirs: List<File>): Report {
        val site = BackupLogic.dirSize(File(filesDir, SITE_DIR))
        val db = BackupLogic.dirSize(File(filesDir, DB_DIR))
        val run = BackupLogic.dirSize(File(filesDir, RUN_DIR))
        var backups = 0L
        for (d in backupsDirs) backups += BackupLogic.dirSize(d)
        val other = (BackupLogic.dirSize(filesDir) - site - db - run).coerceAtLeast(0L)
        return Report(site, db, run, backups, other)
    }

    /** 1024-co so, 1 chu so thap phan tu KB tro len ("0 B", "512 B", "1.5 KB", "3.2 GB"). Am -> "0 B". */
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        if (bytes < 1024L) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = bytes.toDouble() / 1024.0
        var i = 0
        while (v >= 1024.0 && i < units.size - 1) { v /= 1024.0; i++ }
        return String.format(Locale.US, "%.1f %s", v, units[i])
    }

    /** Chi dung khi nguoi dung go DUNG tu xac nhan (khong phan biet hoa thuong, bo khoang trang dau/cuoi). */
    fun wipeConfirmed(typed: String?, word: String): Boolean {
        val w = word.trim()
        return typed != null && w.isNotEmpty() && typed.trim().equals(w, ignoreCase = true)
    }
}
