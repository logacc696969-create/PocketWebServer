package com.wppocket.server

import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Log
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * Bi mat trong SharedPreferences duoc MA HOA bang khoa Android Keystore (PDF 2 muc AC1; HANDOFF.md muc 1bp-I).
 *
 * Truoc day token Telegram/Cloudflare, URL webhook/heartbeat va cum mat khau ma hoa backup luu DANG RO trong shared_prefs: may da root
 * hoac ung dung co quyen cao doc duoc. Nay luu `enc1:...` (SecretCodec). Quy tac thiet ke:
 *  - FAIL-OPEN: Keystore khong dung duoc (mot so may/ROM loi) -> luu dang ro nhu truoc, KHONG bao gio chan nguoi dung dung app.
 *  - Tuong thich nguoc: gia tri cu dang ro doc binh thuong va duoc TU DONG ma hoa ghi lai o lan doc dau ([get]).
 *  - Khoa mat (khoi phuc may/ROM xoa Keystore) -> gia tri khong giai ma duoc -> tra gia tri mac dinh (nhu chua cau hinh); nguoi dung nhap lai.
 *  - MOI cho doc/ghi 6 khoa trong [SECRET_KEYS] PHAI di qua day (scripts/tests/secret-store-test.py canh gac).
 * Gioi han (noi that): `admin-password.txt` va `wp-config.php` van dang ro vi PHP/MariaDB doc truc tiep. Ha cap xuong ban cu se KHONG doc duoc token da ma hoa.
 */
object SecretStore {
    private const val TAG = "SecretStore"
    private const val ALIAS = "wppocket_secret_v1"
    private const val PROVIDER = "AndroidKeyStore"

    val SECRET_KEYS: Set<String> = setOf(
        Prefs.KEY_TUNNEL_TOKEN, Prefs.KEY_BACKUP_ENCRYPT_PASSPHRASE, Prefs.KEY_TELEGRAM_BOT_TOKEN,
        Prefs.KEY_BACKUP_WEBHOOK_URL, Prefs.KEY_ALERT_WEBHOOK_URL, Prefs.KEY_HEARTBEAT_URL, Prefs.KEY_API_TOKEN
    )

    @Volatile private var cachedKey: SecretKey? = null
    @Volatile private var keyUnavailable = false

    private fun key(): SecretKey? {
        val cached = cachedKey
        if (cached != null) return cached
        if (keyUnavailable) return null
        return try {
            val ks = KeyStore.getInstance(PROVIDER)
            ks.load(null)
            var k = ks.getKey(ALIAS, null) as? SecretKey
            if (k == null) {
                val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
                gen.init(
                    KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build()
                )
                k = gen.generateKey()
            }
            cachedKey = k
            k
        } catch (e: Exception) {
            Log.w(TAG, "Keystore khong dung duoc (${e.javaClass.simpleName}) - luu bi mat dang ro (fail-open)")
            keyUnavailable = true
            null
        }
    }

    /** Ma hoa truoc khi ghi vao prefs. Rong/da ma hoa/Keystore loi -> tra nguyen gia tri (fail-open). */
    fun encode(plain: String?): String? {
        if (plain.isNullOrEmpty() || SecretCodec.isSealed(plain)) return plain
        val k = key() ?: return plain
        return try {
            SecretCodec.seal(k, plain)
        } catch (e: Exception) {
            Log.w(TAG, "Ma hoa loi (${e.javaClass.simpleName}) - luu dang ro")
            plain
        }
    }

    /** Giai ma gia tri doc tu prefs. Gia tri dang ro tra nguyen; khong giai ma duoc -> null. */
    fun decode(stored: String?): String? {
        if (stored == null || !SecretCodec.isSealed(stored)) return stored
        val k = key() ?: return null
        return SecretCodec.open(k, stored)
    }

    /** Doc 1 bi mat; gia tri cu dang ro duoc TU DONG ma hoa ghi lai (di tru) khi Keystore dung duoc. */
    fun get(prefs: SharedPreferences, key: String, default: String?): String? {
        val stored = prefs.getString(key, null) ?: return default
        if (!SecretCodec.isSealed(stored)) {
            val sealed = encode(stored)
            if (sealed != null && sealed != stored) prefs.edit().putString(key, sealed).apply()
            return stored
        }
        return decode(stored) ?: default
    }
}
