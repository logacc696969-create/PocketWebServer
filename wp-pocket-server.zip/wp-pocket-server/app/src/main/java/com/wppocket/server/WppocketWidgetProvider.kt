package com.wppocket.server

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.core.content.ContextCompat

/**
 * Widget màn hình chính (đề xuất DeepSeek mục K2, xem HANDOFF.md mục 10 +
 * mục 1ap) - 1 ô hiện trạng thái + bấm để bật/tắt server, không cần mở app.
 * Cùng logic bật/tắt hệt QuickToggleTileService.kt (Quick Settings Tile) -
 * 2 lớp UI khác nhau nhưng gọi chung 1 cách duy nhất tới
 * ServerForegroundService, không lặp lại logic quyết định trạng thái.
 *
 * AppWidgetProvider TỰ NÓ là 1 BroadcastReceiver (không phải Activity/
 * Service) - override onReceive() để bắt riêng action tùy chỉnh
 * ACTION_TOGGLE TRƯỚC KHI giao lại cho super.onReceive() xử lý các action
 * chuẩn của vòng đời widget (ACTION_APPWIDGET_UPDATE...).
 */
class WppocketWidgetProvider : AppWidgetProvider() {

    companion object {
        private const val ACTION_TOGGLE = "com.wppocket.server.widget.ACTION_TOGGLE"

        private fun buildRemoteViews(context: Context): RemoteViews {
            val running = ServerForegroundService.isRunning
            val views = RemoteViews(context.packageName, R.layout.widget_toggle)
            views.setTextViewText(
                R.id.widgetStatus,
                context.getString(if (running) R.string.widget_status_running else R.string.widget_status_stopped)
            )
            val toggleIntent = Intent(context, WppocketWidgetProvider::class.java).setAction(ACTION_TOGGLE)
            val pendingIntent = PendingIntent.getBroadcast(
                context, 0, toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent)
            return views
        }

        /**
         * Gọi từ ServerForegroundService MỖI KHI trạng thái server thật sự
         * đổi (xem updateNotification()/stopServerInternal()) - để widget
         * trên màn hình chính LUÔN khớp với thông báo/app, không phải đợi
         * tới chu kỳ updatePeriodMillis (tối thiểu 30 phút, quá chậm cho 1
         * hành động người dùng vừa bấm). An toàn khi gọi dù KHÔNG có widget
         * nào đang được ghim (getAppWidgetIds trả về mảng rỗng, vòng lặp
         * for không chạy lần nào, không lỗi gì).
         */
        fun updateAll(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, WppocketWidgetProvider::class.java))
                if (ids.isEmpty()) return
                val views = buildRemoteViews(context)
                for (id in ids) mgr.updateAppWidget(id, views)
            } catch (_: Exception) {
                // Khong lam gi them - widget se tu dung lai o chu ky
                // updatePeriodMillis ke tiep, khong anh huong website chinh.
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = buildRemoteViews(context)
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, views)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_TOGGLE) {
            val turningOn = !ServerForegroundService.isRunning
            val svcIntent = Intent(context, ServerForegroundService::class.java).apply {
                action = if (turningOn) ServerForegroundService.ACTION_START else ServerForegroundService.ACTION_STOP
            }
            try {
                if (turningOn) {
                    ContextCompat.startForegroundService(context, svcIntent)
                } else {
                    context.startService(svcIntent)
                }
            } catch (_: Exception) {
                // Giong het QuickToggleTileService.kt - im lang, widget se tu
                // cap nhat dung trang thai that o lan updateAll() ke tiep.
            }
            updateAll(context)
            return
        }
        super.onReceive(context, intent)
    }
}
