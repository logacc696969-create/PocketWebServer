package com.wppocket.server

object Prefs {
    const val NAME = "wp_pocket_server_prefs"
    const val KEY_AUTO_START = "auto_start_on_boot"

    /** AJ4 (1bm): che do may chu chuyen dung - xem MainActivity.setDedicatedMode / ServerForegroundService.channelId / BootReceiver. */
    const val KEY_DEDICATED_MODE = "dedicated_server_mode"
    const val KEY_TUNNEL_TOKEN = "cloudflare_tunnel_token"

    // --- Bo sung tu de xuat PDF (backup tu dong + Telegram Bot + tu chua
    // lanh) - xem HANDOFF.md muc 1e ---

    /** true tu luc bam "Bat server", false tu luc bam "Tat server". Dung boi
     * HealthCheckWorker de biet nguoi dung CO MUON server dang chay hay
     * khong (khac KEY_AUTO_START, von chi anh huong luc may vua khoi dong
     * lai - KEY_SERVER_WANTED phan anh y dinh HIEN TAI, moi luc). */
    const val KEY_SERVER_WANTED = "server_wanted"

    const val KEY_BACKUP_AUTO_ENABLED = "backup_auto_enabled"
    const val KEY_BACKUP_INTERVAL_HOURS = "backup_interval_hours"
    const val DEFAULT_BACKUP_INTERVAL_HOURS = 24L
    /** De xuat DeepSeek muc B1/B6 (xem HANDOFF.md muc 10) - tuy chon RIENG,
     * TAT theo mac dinh (khac setRequiresBatteryNotLow da BAT san tu truoc -
     * xem chu thich trong BackupWorker.kt): "yeu cau dang sac" la 1 danh doi
     * THAT (neu may khong bao gio duoc sac trong luc bat server, bat tuy chon
     * nay dong nghia KHONG BAO GIO backup tu dong), nen de nguoi dung tu
     * quyet dinh thay vi ap dat mac dinh, dung tinh than "User co option
     * override" da ghi trong PDF phan tich. */
    const val KEY_BACKUP_REQUIRE_CHARGING = "backup_require_charging"
    /** B6 (HANDOFF.md muc 1az): hoan cac viec NANG khac ngoai backup (bao tri DB hang tuan
     * OPTIMIZE TABLE, tu dong cap nhat WordPress) cho toi khi may DANG SAC. Mac dinh TAT. */
    const val KEY_HEAVY_ONLY_CHARGING = "heavy_jobs_only_charging"

    /** De xuat DeepSeek muc F6 (xem HANDOFF.md muc 10) - ma hoa AES-256-GCM
     * backup TRUOC khi gui qua Telegram/webhook, vi backup chua wp-config.php
     * (mat khau database that, WordPress salts, co the ca SMTP credentials).
     * Mac dinh TAT (giu nguyen hanh vi cu). LUU Y: passphrase luu trong
     * SharedPreferences GIONG CACH KEY_TELEGRAM_BOT_TOKEN da luu tu truoc -
     * khong tao rui ro MOI so voi cach cac key nhay cam khac dang duoc luu,
     * chi la 1 lop bao ve THEM cho noi dung backup khi no RA KHOI may (qua
     * Telegram/webhook), khong phai bao ve chinh SharedPreferences tren may. */
    const val KEY_BACKUP_ENCRYPT_ENABLED = "backup_encrypt_enabled"
    const val KEY_BACKUP_ENCRYPT_PASSPHRASE = "backup_encrypt_passphrase"

    const val KEY_TELEGRAM_BOT_TOKEN = "telegram_bot_token"
    const val KEY_TELEGRAM_CHAT_ID = "telegram_chat_id"

    /** Webhook tong quat (xem HANDOFF.md muc 1g) - thay cho OAuth Google Drive that. */
    const val KEY_BACKUP_WEBHOOK_URL = "backup_webhook_url"

    /** Webhook nhan CANH BAO dang JSON (site_down/backup_ok/backup_failed) - khac webhook backup o tren (multipart, gui FILE). HANDOFF 1bl. */
    const val KEY_ALERT_WEBHOOK_URL = "alert_webhook_url"

    /** offset cua update_id Telegram da xu ly gan nhat (xem TelegramCommandWorker, muc 1h). */
    const val KEY_TELEGRAM_UPDATE_OFFSET = "telegram_update_offset"

    /** Thoi diem (ms) lenh /backup Telegram gan nhat DUOC thuc hien - chong spam /backup (HANDOFF.md muc 1bg). */
    const val KEY_TELEGRAM_LAST_BACKUP_CMD = "telegram_last_backup_cmd"

    /** Kenh cap nhat: true = nhan ca ban pre-release (beta) - HANDOFF.md muc 1bh. Mac dinh false (chi ban on dinh). */
    const val KEY_UPDATE_INCLUDE_BETA = "update_include_beta"

    /** Dual-Mode PHP-Lite (xem HANDOFF.md muc 1e) - nguoi dung TU chon ep,
     * mac dinh la Auto (de start-lamp.sh tu quyet dinh dua theo DEVICE_RAM_MB). */
    const val KEY_PHP_LITE_MODE = "php_lite_mode_override"
    const val LITE_MODE_AUTO = "auto"
    const val LITE_MODE_FORCE_ON = "on"
    const val LITE_MODE_FORCE_OFF = "off"

    /**
     * Auto-Sleep MariaDB khi ranh (de xuat "Co che Ngu dong thong minh" trong
     * PDF, vong 2 - xem cuoc hoi thoai). MAC DINH TAT (opt-in, khong phai
     * opt-out): day la thay doi HANH VI that (them do tre vai giay cho
     * request DAU TIEN sau khi ranh lau), khong nen tu bat ngam cho nguoi
     * dung chua biet. Khi tat (mac dinh), start-lamp.sh chay dung 100% nhu
     * truoc - khong dung code moi nao ca, khong rui ro gi them cho nguoi
     * khong bat.
     */
    const val KEY_AUTO_SLEEP_ENABLED = "auto_sleep_enabled"
    const val KEY_AUTO_SLEEP_IDLE_MINUTES = "auto_sleep_idle_minutes"
    const val DEFAULT_AUTO_SLEEP_IDLE_MINUTES = 30

    /** De xuat DeepSeek muc B5 (xem HANDOFF.md muc 10) - moc thoi gian gan
     * nhat he thong bao RAM thap (ghi boi ServerForegroundService.onTrimMemory()).
     * TelegramCommandWorker/BackupWorker doc gia tri nay de TAM HOAN 1 chu
     * ky (khong phai huy han) neu con trong "thoi gian nguoi lanh" ngan sau
     * canh bao - xem MEMORY_PRESSURE_COOLDOWN_MS ben duoi. */
    const val KEY_LAST_MEMORY_PRESSURE_AT = "last_memory_pressure_at_ms"
    const val MEMORY_PRESSURE_COOLDOWN_MS = 5 * 60 * 1000L


    /** De xuat DeepSeek muc B7 (xem HANDOFF.md muc 10) - snapshot Rx/Tx
     * (byte) CUA RIENG APP NAY (qua TrafficStats.getUidRxBytes/TxBytes,
     * khong can quyen gi them) tai thoi diem BAM "Bat server" gan nhat,
     * dung de tinh "da dung bao nhieu du lieu ke tu khi bat server". LUU Y
     * THAT (ghi trong tai lieu chinh thuc cua Android, khong phai doan):
     * gia tri TrafficStats la TICH LUY TU LUC THIET BI KHOI DONG (boot),
     * KHONG PHAI tu luc cai app - neu dien thoai tu khoi dong lai (mat
     * dien, crash he thong...) trong luc server dang chay, gia tri hien tai
     * co the NHO HON baseline da luu (bi "reset" ve gan 0) -> hieu delta ra
     * so AM. Code doc gia tri nay (xem
     * ServerForegroundService.sessionDataUsageBytes()) PHAI tu kep ve 0 khi
     * gap truong hop nay, khong duoc hien so am ra UI. Luu vao
     * SharedPreferences (khong phai bien Kotlin thuan) de SONG SOT qua viec
     * Android tu kill tien trinh nen roi tu khoi dong lai Service (khoi
     * dong lai KHONG duoc tinh la "bam Bat server lai" doi voi so lieu nay -
     * nguoi dung khong lam gi ca, khong nen thay so nhay ve 0 vo ly do). */
    const val KEY_DATA_USAGE_BASELINE_RX = "data_usage_baseline_rx"
    const val KEY_DATA_USAGE_BASELINE_TX = "data_usage_baseline_tx"

    /** De xuat DeepSeek muc B5 - ham DUNG CHUNG cho TelegramCommandWorker/
     * BackupWorker (xem 2 file do) tu kiem tra TRUOC khi lam viec nang, tranh
     * lap lai logic doc timestamp + so sanh cooldown o 2 noi. Tra ve true
     * CHI khi CON trong khoang MEMORY_PRESSURE_COOLDOWN_MS ke tu lan gan
     * nhat he thong bao RAM thap (xem
     * ServerForegroundService.onTrimMemory()) - qua khoang do la tu dong
     * tro ve false, KHONG can ai "xoa co" thu cong. */
    /** De xuat DeepSeek muc K5 (xem HANDOFF.md muc 10 + muc 1at) - da hien
     * dialog "Bat dau nhanh" (onboarding) cho nguoi dung lan nao chua. Chi
     * hien 1 LAN DUY NHAT (lan mo app dau tien) - nguoi dung da quen giao
     * dien thi khong can nhac lai moi lan mo app, gay phien. */
    const val KEY_ONBOARDING_SHOWN = "onboarding_shown"

    // --- Giam sat & canh bao (xem HANDOFF.md muc 1au, Monitoring.kt) ---
    /** URL heartbeat ngoai (healthchecks.io / Uptime Kuma push...): HealthCheckWorker
     * GET toi day MOI KHI website phan hoi tot. Neu dien thoai chet han (het pin,
     * mat mang, bi kill) thi KHONG ai ping nua -> dich vu ben ngoai bao cho chu
     * may - dieu ma Telegram tu may khong the lam (may chet thi khong gui duoc). */
    const val KEY_HEARTBEAT_URL = "heartbeat_url"
    /** Ngan sach data di dong moi thang (MB). 0 = tat. */
    const val KEY_DATA_BUDGET_MB = "data_budget_mb"
    /** Co giam toc nginx (limit_rate) khi da vuot ngan sach khong. */
    const val KEY_DATA_BUDGET_THROTTLE = "data_budget_throttle"
    const val KEY_DATA_MONTH_KEY = "data_month_key"
    const val KEY_DATA_MONTH_CELL_BYTES = "data_month_cell_bytes"
    const val KEY_DATA_LAST_TOTAL = "data_last_total_bytes"
    /** Nguon bo dem dang dung ("mobile" = TrafficStats di dong toan may, "uid" = theo UID app).
     * Doi nguon thi dat lai moc lastTotal (2 nguon KHONG cung thang do, so sanh se sai). */
    const val KEY_DATA_SOURCE = "data_source"
    const val KEY_DATA_ALERT_LEVEL = "data_alert_level"
    /** Tam dung poll Telegram khi pin < 15% va khong sac (mac dinh BAT). */
    const val KEY_LOW_BATTERY_PAUSE = "low_battery_pause"
    const val KEY_DISK_ALERT_AT = "disk_alert_at_ms"
    /** H6 (1bp): vi tri byte da doc cua lamp-run/php-error.log va thoi diem canh bao loi PHP gan nhat. */
    const val KEY_PHP_FATAL_OFFSET = "php_fatal_read_offset"
    /** R15-R18 (1bp): ho so hieu nang PHP 0/1/2 (PhpTuning); mac dinh 0 = khong doi gi. */
    const val KEY_PHP_PROFILE = "php_perf_profile"
    /** Q11 (1bp): ghi backup moi len THE NHO khi co (mac dinh false = bo nho chinh nhu truoc). */
    const val KEY_BACKUP_ON_SD = "backup_on_removable"
    /** T1 (1bp-L): API trang thai chi doc cho LAN. TOKEN la BI MAT -> phai di qua SecretStore (da dang ky trong SECRET_KEYS). */
    const val KEY_API_ENABLED = "api_status_enabled"
    const val KEY_API_TOKEN = "api_status_token"
    const val KEY_PHP_FATAL_ALERT_AT = "php_fatal_alert_at_ms"
    /** Vi tri byte da doc cua admin-audit.log (-1 = chua khoi tao). */
    const val KEY_AUDIT_OFFSET = "audit_read_offset"
    const val KEY_AUDIT_ALERT_AT = "audit_alert_at_ms"
    /** Vi tri byte da doc cua security-events.log (-1 = chua khoi tao) + thoi diem canh bao gan nhat (HANDOFF.md muc 1br). */
    const val KEY_SECEVT_OFFSET = "secevt_read_offset"
    const val KEY_SECEVT_ALERT_AT = "secevt_alert_at_ms"
    /** 1bc: thoi diem canh bao moi truong gan nhat, theo TUNG van de (hau to = ten MonitorLogic.EnvIssue). */
    const val KEY_ENV_ALERT_PREFIX = "env_alert_at_"

    /** H1 (1bm): ket qua kiem tra khoi phuc thu backup gan nhat (BackupVerifier.record). */
    const val KEY_VERIFY_LAST_AT = "backup_verify_last_at"
    const val KEY_VERIFY_LAST_STATUS = "backup_verify_last_status"
    const val KEY_VERIFY_LAST_MSG = "backup_verify_last_msg"

    /** So chu ky backup tu dong da bi hoan LIEN TIEP vi may nong >= 45 C (reset ve 0 khi chay duoc) - xem MonitorLogic.shouldDeferBackupForHeat. */
    const val KEY_HEAT_DEFER_COUNT = "heat_backup_defer_count"

    // ----- H5 / AE5 (HANDOFF.md muc 1bq-B): nguong canh bao chinh duoc + quy tac canh bao tu dinh nghia. Gia tri qua AlertThresholds.sanitize. -----
    const val KEY_ALERT_DISK_PCT = "alert_disk_pct"
    const val KEY_ALERT_BATT_CRIT_PCT = "alert_batt_crit_pct"
    const val KEY_ALERT_WARM_C = "alert_warm_c"
    const val KEY_ALERT_HOT_C = "alert_hot_c"
    /** thoi diem bat dau cua dau danh dau khoi phuc bi gian doan DA bao Telegram (bao 1 lan cho moi dau danh dau; xem RestoreMarker). */
    const val KEY_RESTORE_ALERTED_AT = "restore_interrupted_alerted_at"
    /** Van ban quy tac (moi dong 1 quy tac, xem AlertRules). */
    const val KEY_ALERT_RULES = "alert_rules_text"
    /** Trang thai tung quy tac: khoa = tien to + ten quy tac, gia tri "firstTrueAtMs,lastAlertAtMs" (AlertRules.encodeState). */
    const val KEY_ALERT_RULE_STATE_PREFIX = "alert_rule_state_"

    fun isUnderMemoryPressure(context: android.content.Context): Boolean {
        val prefs = context.getSharedPreferences(NAME, android.content.Context.MODE_PRIVATE)
        val lastAt = prefs.getLong(KEY_LAST_MEMORY_PRESSURE_AT, 0L)
        if (lastAt == 0L) return false
        return (System.currentTimeMillis() - lastAt) < MEMORY_PRESSURE_COOLDOWN_MS
    }
}
