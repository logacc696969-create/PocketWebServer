package com.wppocket.server

object Prefs {
    const val NAME = "wp_pocket_server_prefs"
    const val KEY_AUTO_START = "auto_start_on_boot"
    const val KEY_TUNNEL_TOKEN = "cloudflare_tunnel_token"

    // --- Bo sung tu de xuat PDF (backup tu dong + Telegram Bot + tu chua
    // lanh) - xem HANDOFF.md muc 1e ---

    /** true tu luc bam "Bat server", false tu luc bam "Tat server". Dung boi
     * HealthCheckWorker de biet nguoi dung CO MUON server dang chay hay
     * khong (khac KEY_AUTO_START, von chi anh huong luc may vua khoi dong
     * lai - KEY_SERVER_WANTED phan anh y dinh HIEN TAI, moi luc). */
    const val KEY_SERVER_WANTED = "server_wanted"

    const val KEY_BACKUP_AUTO_ENABLED = "backup_auto_enabled"
    const val KEY_BACKUP_INTERVAL_HOURS = "backup_interval_hours"
    const val DEFAULT_BACKUP_INTERVAL_HOURS = 24L
    /** De xuat DeepSeek muc B1/B6 (xem HANDOFF.md muc 10) - tuy chon RIENG,
     * TAT theo mac dinh (khac setRequiresBatteryNotLow da BAT san tu truoc -
     * xem chu thich trong BackupWorker.kt): "yeu cau dang sac" la 1 danh doi
     * THAT (neu may khong bao gio duoc sac trong luc bat server, bat tuy chon
     * nay dong nghia KHONG BAO GIO backup tu dong), nen de nguoi dung tu
     * quyet dinh thay vi ap dat mac dinh, dung tinh than "User co option
     * override" da ghi trong PDF phan tich. */
    const val KEY_BACKUP_REQUIRE_CHARGING = "backup_require_charging"

    const val KEY_TELEGRAM_BOT_TOKEN = "telegram_bot_token"
    const val KEY_TELEGRAM_CHAT_ID = "telegram_chat_id"

    /** Webhook tong quat (xem HANDOFF.md muc 1g) - thay cho OAuth Google Drive that. */
    const val KEY_BACKUP_WEBHOOK_URL = "backup_webhook_url"

    /** offset cua update_id Telegram da xu ly gan nhat (xem TelegramCommandWorker, muc 1h). */
    const val KEY_TELEGRAM_UPDATE_OFFSET = "telegram_update_offset"

    /** Dual-Mode PHP-Lite (xem HANDOFF.md muc 1e) - nguoi dung TU chon ep,
     * mac dinh la Auto (de start-lamp.sh tu quyet dinh dua theo DEVICE_RAM_MB). */
    const val KEY_PHP_LITE_MODE = "php_lite_mode_override"
    const val LITE_MODE_AUTO = "auto"
    const val LITE_MODE_FORCE_ON = "on"
    const val LITE_MODE_FORCE_OFF = "off"

    /**
     * Auto-Sleep MariaDB khi ranh (de xuat "Co che Ngu dong thong minh" trong
     * PDF, vong 2 - xem cuoc hoi thoai). MAC DINH TAT (opt-in, khong phai
     * opt-out): day la thay doi HANH VI that (them do tre vai giay cho
     * request DAU TIEN sau khi ranh lau), khong nen tu bat ngam cho nguoi
     * dung chua biet. Khi tat (mac dinh), start-lamp.sh chay dung 100% nhu
     * truoc - khong dung code moi nao ca, khong rui ro gi them cho nguoi
     * khong bat.
     */
    const val KEY_AUTO_SLEEP_ENABLED = "auto_sleep_enabled"
    const val KEY_AUTO_SLEEP_IDLE_MINUTES = "auto_sleep_idle_minutes"
    const val DEFAULT_AUTO_SLEEP_IDLE_MINUTES = 30
}
