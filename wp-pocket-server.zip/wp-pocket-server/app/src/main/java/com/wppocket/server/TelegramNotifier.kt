package com.wppocket.server

import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Goi Telegram Bot API bang HttpURLConnection thuan (khong them thu vien
 * ngoai nhu OkHttp/Retrofit - giu APK nhe, chi can dung 2 API: gui tin nhan
 * text va gui file dinh kem). Nguoi dung tu tao bot rieng MIEN PHI qua
 * @BotFather tren Telegram (khong can server ngoai nao khac) roi dan
 * "Bot Token" + "Chat ID" vao app - xem PDF "Tien loi hoa quan ly qua
 * Telegram/Discord Bot" (HANDOFF.md muc 1e). Chi lam Discord/Telegram MOT
 * chieu (app -> Telegram, bao cao tu dong) - KHONG lam webhook nhan lenh
 * nguoc lai (/status, /backup...) nhu PDF de xuat them, vi can 1 tien trinh
 * lang nghe rieng (long-polling hoac webhook cong khai) - qua nhieu rui ro/
 * cong suc cho 1 lan bo sung, xem HANDOFF.md muc 1e phan "chua lam".
 *
 * CHUA verify goi API that qua mang di dong VN - chi viet dung theo dac ta
 * chinh thuc cua Telegram Bot API (https://core.telegram.org/bots/api). Loi
 * (neu co) khong lam sap server chinh - moi ham o day tu bat Exception va
 * tra ve false, chi log canh bao.
 */
object TelegramNotifier {
    private const val TAG = "TelegramNotifier"

    fun isConfigured(botToken: String?, chatId: String?): Boolean =
        !botToken.isNullOrBlank() && !chatId.isNullOrBlank()

    /** Gui tin nhan text don gian (vd bao URL cong khai luc server vua len). */
    fun sendMessage(botToken: String, chatId: String, text: String): Boolean {
        return try {
            val url = URL("https://api.telegram.org/bot$botToken/sendMessage")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 15_000
                readTimeout = 15_000
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
            }
            val body = "chat_id=${urlEncode(chatId)}&text=${urlEncode(text)}"
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val ok = conn.responseCode in 200..299
            if (!ok) Log.w(TAG, "Telegram sendMessage tra ve ma ${conn.responseCode}")
            conn.disconnect()
            ok
        } catch (e: Exception) {
            Log.e(TAG, "Gui tin nhan Telegram loi (khong anh huong server chinh)", e)
            false
        }
    }

    /** Gui file dinh kem (vd file zip backup) qua sendDocument - tu dung
     * multipart/form-data bang tay (khong dung thu vien HTTP nao ngoai
     * chuan JDK, giu APK nhe dung nguyen tac cua du an). */
    fun sendDocument(botToken: String, chatId: String, file: File, caption: String = ""): Boolean {
        return try {
            val boundary = "----WPPocketBoundary${System.currentTimeMillis()}"
            val url = URL("https://api.telegram.org/bot$botToken/sendDocument")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 15_000
                // File backup co the vai chuc MB, tren mang di dong can nhieu
                // thoi gian hon tin nhan text thuong.
                readTimeout = 120_000
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            conn.outputStream.use { out ->
                fun writeField(name: String, value: String) {
                    out.write("--$boundary\r\n".toByteArray())
                    out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
                    out.write("$value\r\n".toByteArray())
                }
                writeField("chat_id", chatId)
                if (caption.isNotBlank()) writeField("caption", caption)

                out.write("--$boundary\r\n".toByteArray())
                out.write(
                    "Content-Disposition: form-data; name=\"document\"; filename=\"${file.name}\"\r\n"
                        .toByteArray()
                )
                out.write("Content-Type: application/zip\r\n\r\n".toByteArray())
                file.inputStream().use { it.copyTo(out) }
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }

            val ok = conn.responseCode in 200..299
            if (!ok) Log.w(TAG, "Telegram sendDocument tra ve ma ${conn.responseCode}")
            conn.disconnect()
            ok
        } catch (e: Exception) {
            Log.e(TAG, "Gui file backup qua Telegram loi (file van luu tren may, khong mat)", e)
            false
        }
    }

    private fun urlEncode(s: String): String = URLEncoder.encode(s, "UTF-8")

    data class TelegramCommand(val updateId: Long, val chatId: Long, val text: String)

    /**
     * Long-polling MOT CHIEU (phone -> Telegram, phone chu dong hoi "co tin
     * nhan moi khong?") - AN TOAN hon webhook (khong mo port/dia chi cong
     * khai nao ca, khong co be mat tan cong moi). Day la cach dung PHO BIEN,
     * CHINH THUC cua Telegram Bot API cho bot khong co server rieng
     * (https://core.telegram.org/bots/api#getupdates) - khac voi webhook 2
     * chieu ma HANDOFF.md muc 1e da tu choi vi ly do bao mat, xem muc 1h de
     * biet ly do cach nay AN TOAN va lam duoc.
     *
     * @param offset update_id CUOI CUNG da xu ly + 1 (Telegram tu xoa cac
     *   update cu hon offset nay khoi hang doi, tranh xu ly trung).
     * @return danh sach lenh MOI (chi lay tu dung 1 chatId da cau hinh -
     *   loc nguoi la o TelegramCommandWorker, ham nay chi lay tho ve).
     */
    fun getUpdates(botToken: String, offset: Long): List<TelegramCommand> {
        return try {
            val url = URL("https://api.telegram.org/bot$botToken/getUpdates?offset=$offset&timeout=0")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 20_000
            }
            if (conn.responseCode !in 200..299) {
                Log.w(TAG, "Telegram getUpdates tra ve ma ${conn.responseCode}")
                conn.disconnect()
                return emptyList()
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()

            val root = org.json.JSONObject(body)
            if (!root.optBoolean("ok", false)) return emptyList()
            val results = root.optJSONArray("result") ?: return emptyList()

            val out = ArrayList<TelegramCommand>()
            for (i in 0 until results.length()) {
                val item = results.getJSONObject(i)
                val updateId = item.optLong("update_id", -1L)
                val message = item.optJSONObject("message") ?: continue
                val chat = message.optJSONObject("chat") ?: continue
                val chatId = chat.optLong("id", Long.MIN_VALUE)
                val text = message.optString("text", "")
                if (updateId >= 0 && text.isNotBlank()) {
                    out.add(TelegramCommand(updateId, chatId, text.trim()))
                }
            }
            out
        } catch (e: Exception) {
            Log.e(TAG, "Telegram getUpdates loi (khong anh huong server chinh)", e)
            emptyList()
        }
    }
}
