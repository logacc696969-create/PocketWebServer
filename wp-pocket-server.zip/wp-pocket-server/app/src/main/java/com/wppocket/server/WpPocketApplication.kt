package com.wppocket.server

import android.app.Application

/**
 * Application class rieng - truoc day du an KHONG co lop nay (dung
 * Application mac dinh cua Android, khong khai bao "android:name" trong
 * AndroidManifest.xml). Them vao DUY NHAT de co 1 diem chay SOM NHAT co
 * the, TRUOC ca MainActivity/ServerForegroundService/moi Worker - noi DUY
 * NHAT dam bao bat duoc crash tu BAT KY thanh phan nao cua app (xem
 * CrashLogger.kt, de xuat DeepSeek muc K8), khong chi 1 man hinh don le.
 *
 * KHONG them logic gi khac vao day - moi thu con lai cua app van giu
 * nguyen kien truc cu (moi Activity/Service/Worker tu quan ly rieng), tranh
 * bien lop nay thanh 1 "God object" ngoai y dinh ban dau.
 */
class WpPocketApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLogger.install(this)
    }
}
