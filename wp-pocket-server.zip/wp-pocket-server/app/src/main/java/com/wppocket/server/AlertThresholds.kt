package com.wppocket.server

/**
 * H5 (PDF 2; HANDOFF.md muc 1bq-B): NGUONG CANH BAO CHO NGUOI DUNG CHINH. Truoc day 4 nguong nay la hang so trong ma
 * (dia 85%, pin can 5%, nong 40 C, qua nong 45 C). THUAN Kotlin (khong import android.*) de kiem tren JVM; Monitoring doc SharedPreferences roi goi [sanitize].
 *
 * Quy tac an toan: moi gia tri bi KEP vao khoang hop ly (khong ai dat duoc "canh bao khi dia 1%" lam spam, hay "qua nong 200 C" lam tat
 * canh bao), va nguong qua-nong luon > nguong nong. Gia tri hong/ngoai khoang -> ve mac dinh hoac kep, khong bao gio nem loi.
 */
object AlertThresholds {
    const val DISK_MIN = 50
    const val DISK_MAX = 99
    const val DISK_DEFAULT = 85

    const val BATT_CRIT_MIN = 1
    const val BATT_CRIT_MAX = 30
    const val BATT_CRIT_DEFAULT = 5

    const val WARM_MIN = 30
    const val WARM_MAX = 55
    const val WARM_DEFAULT = 40

    const val HOT_MIN = 35
    const val HOT_MAX = 65
    const val HOT_DEFAULT = 45

    data class Values(val diskPct: Int, val batteryCriticalPct: Int, val warmC: Int, val hotC: Int) {
        /** Nhiet do theo 1/10 do C (cung don vi voi BatteryManager.EXTRA_TEMPERATURE). */
        val warmTenths: Int get() = warmC * 10
        val hotTenths: Int get() = hotC * 10
    }

    val DEFAULTS = Values(DISK_DEFAULT, BATT_CRIT_DEFAULT, WARM_DEFAULT, HOT_DEFAULT)

    fun clamp(v: Int, min: Int, max: Int): Int = if (v < min) min else if (v > max) max else v

    /** Kep tung gia tri vao khoang cua no; bao dam nguong qua-nong > nguong nong (neu khong thi nang qua-nong len warm+1, toi da HOT_MAX). */
    fun sanitize(disk: Int, battCritical: Int, warmC: Int, hotC: Int): Values {
        val d = clamp(disk, DISK_MIN, DISK_MAX)
        val b = clamp(battCritical, BATT_CRIT_MIN, BATT_CRIT_MAX)
        val w = clamp(warmC, WARM_MIN, WARM_MAX)
        var h = clamp(hotC, HOT_MIN, HOT_MAX)
        if (h <= w) h = Math.min(HOT_MAX, w + 1)
        return Values(d, b, w, h)
    }

    /** So nguyen duong 1-3 chu so trong [min, max]; null neu rong/khong phai so/ngoai khoang (giao dien bao loi, KHONG luu). */
    fun parseField(raw: String?, min: Int, max: Int): Int? {
        val t = raw?.trim() ?: return null
        if (t.isEmpty() || t.length > 3) return null
        for (c in t) if (c < '0' || c > '9') return null
        val v = t.toInt()
        return if (v in min..max) v else null
    }
}
