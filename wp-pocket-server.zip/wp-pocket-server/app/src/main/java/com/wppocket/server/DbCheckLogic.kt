package com.wppocket.server

/**
 * Kiem tra toan ven CSDL (PDF 2 muc R12; HANDOFF.md muc 1bp). Chi java.* (khong Android) de test duoc.
 *
 * Dung CHINH `libmysqlcli.so` da dong goi (cung cach BackupManager chay no): mot lan liet ke bang that cua CSDL, mot lan
 * `CHECK TABLE ... QUICK` (nhanh, khong khoa lau, khong sua gi). Khong dung REPAIR: InnoDB khong ho tro, va sua tu dong
 * co the lam hong them - chi BAO de nguoi dung backup/khoi phuc.
 */
object DbCheckLogic {
    class Outcome(val total: Int, val ok: Int, val skipped: Int, val problems: List<String>, val parsedRows: Int)

    private const val CHUNK = 100

    fun quoteIdent(s: String): String = "`" + s.replace("`", "``") + "`"

    /** [db] PHAI da qua BackupLogic.sanitizeDbName; van doi ' thanh '' cho chac. */
    fun listTablesSql(db: String): String =
        "SELECT table_name FROM information_schema.tables WHERE table_schema='" + db.replace("'", "''") +
            "' AND table_type='BASE TABLE' ORDER BY table_name;\n"

    fun checkSql(db: String, tables: List<String>): String {
        val sb = StringBuilder()
        var i = 0
        while (i < tables.size) {
            val chunk = tables.subList(i, Math.min(i + CHUNK, tables.size))
            val names = ArrayList<String>()
            for (t in chunk) names.add(quoteIdent(db) + "." + quoteIdent(t))
            sb.append("CHECK TABLE ").append(names.joinToString(", ")).append(" QUICK;\n")
            i += CHUNK
        }
        return sb.toString()
    }

    fun parseTableList(out: String): List<String> {
        val r = ArrayList<String>()
        for (raw in out.split('\n')) {
            val l = raw.trim('\r')
            if (l.isNotEmpty() && !l.startsWith("ERROR")) r.add(l)
        }
        return r
    }

    /** Doc ket qua `CHECK TABLE` che do batch (-N -B): moi dong "csdl.bang<TAB>check<TAB>loai<TAB>noi dung". */
    fun parseCheck(out: String): Outcome {
        val rows = LinkedHashMap<String, ArrayList<Array<String>>>()
        var parsed = 0
        for (raw in out.split('\n')) {
            val c = raw.trim('\r').split('\t')
            if (c.size < 4) continue
            parsed++
            var list = rows[c[0]]
            if (list == null) { list = ArrayList(); rows[c[0]] = list }
            list.add(arrayOf(c[2].lowercase(), c[3]))
        }
        var ok = 0
        var skipped = 0
        val problems = ArrayList<String>()
        for (e in rows.entries) {
            val r = e.value
            val unsupported = r.any { it[1].contains("doesn't support check") }
            val hasErr = r.any { it[0] == "error" }
            val hasWarn = r.any { it[0] == "warning" }
            var lastStatus = ""
            for (x in r) if (x[0] == "status") lastStatus = x[1]
            if (unsupported && !hasErr) { skipped++; continue }
            if (!hasErr && !hasWarn && (lastStatus == "OK" || lastStatus == "Table is already up to date")) { ok++; continue }
            val msgs = ArrayList<String>()
            for (x in r) if (x[0] != "note" && x[1] != "OK" && !msgs.contains(x[1])) msgs.add(x[1])
            problems.add(e.key + ": " + (if (msgs.isEmpty()) lastStatus else msgs.take(2).joinToString("; ")))
        }
        return Outcome(rows.size, ok, skipped, problems, parsed)
    }
}
