package com.wppocket.server

import java.io.File

/**
 * Danh dau "dang khoi phuc" (AA2 - kiem thu hon loan, HANDOFF.md muc 1bq-E). THUAN Kotlin (chi java.io, khong import android.*).
 *
 * Khoang trong tim thay khi kiem toan "tat app giua luc restore": BackupLogic.extract ghi tung tep NGUYEN VEN (tep tam + doi ten) nhung CA TAP
 * khong nguyen tu, va co so du lieu duoc nap SAU khi giai nen - tat app/mat dien giua chung de lai website NUA CU NUA MOI, trong khi truoc day
 * khong co dau vet nao de biet dieu do da xay ra. Dau danh dau nay duoc ghi truoc khi dung vao du lieu (sau khi kiem tra toan ven that bai se
 * KHONG ghi) va xoa khi performRestore tra ve binh thuong; neu con ton tai sau [STALE_AFTER_MS] thi khoi phuc truoc bi gian doan va
 * Monitoring.checkInterruptedRestore bao nguoi dung chay lai khoi phuc tu cung ban backup.
 *
 * Dinh dang tep: "v1\n<startedAtMs>\n<ten backup da loc>\n", ghi qua tep tam + doi ten (khong bao gio doc duoc tep ghi do).
 */
object RestoreMarker {
    const val FILE_NAME = "restore-in-progress"
    const val STALE_AFTER_MS = 15L * 60_000L
    private const val MAX_NAME = 100

    data class Marker(val backupName: String, val startedAtMs: Long)

    fun file(filesDir: File): File = File(filesDir, FILE_NAME)

    private fun tmpFile(filesDir: File): File = File(filesDir, "$FILE_NAME.tmp")

    /** Chi giu [A-Za-z0-9._-], doi ky tu khac thanh '_', toi da 100 ky tu (ten tep tu nguoi dung/he thong khong duoc lam hong tep danh dau). */
    fun sanitizeName(name: String): String {
        val sb = StringBuilder()
        for (c in name) {
            if (sb.length >= MAX_NAME) break
            sb.append(if ((c in 'a'..'z') || (c in 'A'..'Z') || (c in '0'..'9') || c == '.' || c == '_' || c == '-') c else '_')
        }
        return sb.toString()
    }

    /** Ghi dau danh dau. Tra ve false khi khong ghi duoc (khong bao gio nem loi; khoi phuc van tiep tuc, chi mat kha nang phat hien). */
    fun begin(filesDir: File, backupName: String, nowMs: Long): Boolean {
        return try {
            val f = file(filesDir)
            val tmp = tmpFile(filesDir)
            tmp.writeText("v1\n" + nowMs + "\n" + sanitizeName(backupName) + "\n")
            if (!tmp.renameTo(f)) {
                f.delete()
                if (!tmp.renameTo(f)) {
                    tmp.delete()
                    return false
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Xoa dau danh dau (khoi phuc ket thuc binh thuong). */
    fun finish(filesDir: File) {
        try { file(filesDir).delete() } catch (_: Exception) { }
        try { tmpFile(filesDir).delete() } catch (_: Exception) { }
    }

    /** null = khong co; tep co nhung hong -> Marker("?", 0) (van la dau hieu khoi phuc bi gian doan). */
    fun read(filesDir: File): Marker? {
        val f = file(filesDir)
        if (!f.exists()) return null
        return try {
            val lines = f.readText().split('\n')
            val started = lines.getOrNull(1)?.trim()?.toLongOrNull()
            if (lines.getOrNull(0) != "v1" || started == null || started < 0L) Marker("?", 0L)
            else Marker(lines.getOrNull(2)?.trim().orEmpty().ifEmpty { "?" }, started)
        } catch (e: Exception) {
            Marker("?", 0L)
        }
    }

    /** Khoi phuc coi la bi gian doan khi dau danh dau con do da >= [STALE_AFTER_MS] (hoac khong doc duoc thoi diem). Dong ho lui -> chua ket luan. */
    fun isInterrupted(m: Marker, nowMs: Long): Boolean {
        if (m.startedAtMs <= 0L) return true
        if (nowMs < m.startedAtMs) return false
        return nowMs - m.startedAtMs >= STALE_AFTER_MS
    }

    /** Noi dung Telegram (khong dau, giong cac canh bao khac). */
    fun describe(m: Marker): String =
        "Lan khoi phuc truoc (" + m.backupName + ") bi gian doan giua chung (tat app/mat dien/het pin?) - website co the dang o trang thai do dang " +
            "(mot so tep moi, mot so tep cu; co so du lieu co the chua duoc khoi phuc). Hay chay lai Khoi phuc tu CUNG ban backup do."
}
