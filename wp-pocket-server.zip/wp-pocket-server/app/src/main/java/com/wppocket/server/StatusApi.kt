package com.wppocket.server

import android.content.Context
import android.os.StatFs
import java.io.File

/**
 * Ghi `lamp-run/api-status.json` cho API trang thai chi doc (T1, HANDOFF.md muc 1bp-L). Chi ghi khi nguoi dung BAT API
 * (Prefs.KEY_API_ENABLED); tat thi XOA tep. Ghi nguyen tu (tep tam roi doi ten) de nginx khong bao gio doc nua chung.
 * Goi tu Monitoring.runPeriodic (moi chu ky suc khoe ~15 phut) va luc server khoi dong -> du lieu cu toi da ~15 phut, kem `generated_at`.
 */
object StatusApi {
    private const val REL = "lamp-run/api-status.json"

    fun write(context: Context) {
        val f = File(context.filesDir, REL)
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(Prefs.KEY_API_ENABLED, false)) {
            f.delete()
            return
        }
        val dev = Monitoring.deviceStatus(context)
        val backups = BackupManager.listBackups(context)
        val st = StatFs(context.filesDir.absolutePath)
        val total = st.blockCountLong
        val usedPct = if (total > 0L) (100L - st.availableBlocksLong * 100L / total).toInt() else -1
        val version = try { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
        val newest = backups.firstOrNull()
        val json = ApiLogic.buildStatusJson(
            System.currentTimeMillis() / 1000L, ServerForegroundService.isRunning, dev.first, dev.second, usedPct,
            if (newest != null) newest.lastModified() / 1000L else 0L, backups.size, version
        )
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, "api-status.json.tmp")
        tmp.writeText(json, Charsets.UTF_8)
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
    }
}
