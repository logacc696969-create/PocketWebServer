package com.wppocket.server

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable

/**
 * Ve ma QR (K4/A3, HANDOFF.md muc 1bq) bang Canvas - sac net o moi kich thuoc (khong Bitmap co dan, khong lam mo), khong them phu thuoc.
 * LUON nen TRANG + module DEN, bat ke giao dien toi/sang: may quet can tuong phan that, khong doc duoc ma dao mau.
 * [quietModules] = vung yen xung quanh; dac ta yeu cau >= 4 module.
 */
class QrDrawable(private val qr: QrCode, private val quietModules: Int = 4) : Drawable() {

    private val dark = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = false
    }
    private val light = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val side = Math.min(b.width(), b.height())
        if (side <= 0) return
        val total = qr.size + 2 * quietModules
        val cell = side.toFloat() / total
        val ox = b.left + (b.width() - side) / 2
        val oy = b.top + (b.height() - side) / 2
        canvas.drawRect(ox.toFloat(), oy.toFloat(), (ox + side).toFloat(), (oy + side).toFloat(), light)
        for (y in 0 until qr.size) {
            var x = 0
            while (x < qr.size) {
                if (!qr.isDark(x, y)) {
                    x++
                    continue
                }
                val start = x
                while (x < qr.size && qr.isDark(x, y)) x++
                // Lam tron CA HAI bien ve cung mot cong thuc de hai o lien ke khong ho khe/chong lan.
                val left = ox + Math.round((start + quietModules) * cell)
                val right = ox + Math.round((x + quietModules) * cell)
                val top = oy + Math.round((y + quietModules) * cell)
                val bottom = oy + Math.round((y + quietModules + 1) * cell)
                canvas.drawRect(left.toFloat(), top.toFloat(), right.toFloat(), bottom.toFloat(), dark)
            }
        }
    }

    override fun setAlpha(alpha: Int) {
        dark.alpha = alpha
        light.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        dark.colorFilter = colorFilter
        light.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
