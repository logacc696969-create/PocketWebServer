package com.wppocket.server

import android.content.Context
import android.os.StatFs
import android.util.Log
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * H1 (PDF 2 muc H1, HANDOFF.md muc 1bm): "backup chua duoc thu khoi phuc thi chua phai backup". Moi tuan (BackupVerifyWorker) lay file
 * backup MOI NHAT, nap database cua no vao 1 DATABASE TAM (`wordpress_verify`) tren CHINH MariaDB dang chay (khong can may chu thu hai),
 * kiem tra co bang/du lieu WordPress that (co bang ...posts, ...options va dong siteurl), roi XOA database tam.
 *
 * AN TOAN (khong duoc dung vao database that):
 *  1. Nap bang MOT USER RIENG (`wpp_verify`) CHI co quyen tren database tam. Day la lop bao ve THAT: du dump co "USE wordpress" hay
 *     "DROP ..." thi CHINH MariaDB tu choi (Access denied), mysql client dung ngay o loi dau tien.
 *  2. Dump duoc doi ten database sang ten database tam va bi tu choi neu chua lenh nguy hiem (BackupLogic.rewriteDumpForVerify) - lop thu hai.
 *  3. Moi dung cu (database tam, user, file tam) luon bi don trong `finally` va TRUOC khi bat dau (don ton du cua lan crash truoc).
 *  4. Mat khau cua user tam la ngau nhien, dung 1 lan, truyen qua bien moi truong MYSQL_PWD cua tien trinh con.
 * Ket qua gom 3 loai: OK, FAILED (backup co van de - can bao dong), SKIPPED (khong the kiem tra luc nay: MariaDB ngu, het cho, may nong,
 * backup ma hoa chua co mat khau, trigger/view khong nap duoc bang user han che...) - SKIPPED KHONG bao dong de tranh bao dong gia.
 */
object BackupVerifier {
    private const val TAG = "BackupVerifier"
    const val VERIFY_DB = "wordpress_verify"
    private const val VERIFY_USER = "wpp_verify"
    private const val IMPORT_TIMEOUT_MIN = 45L
    private const val MIN_FREE_EXTRA_BYTES = 100L * 1024 * 1024

    enum class Status { OK, FAILED, SKIPPED }
    data class Outcome(val status: Status, val message: String)

    private data class Run(val code: Int, val out: String, val timedOut: Boolean)

    private fun cliBin(context: Context) = File(context.applicationInfo.nativeLibraryDir, "libmysqlcli.so")
    private fun sockFile(context: Context) = File(context.filesDir, "lamp-run/mysql.sock")

    private fun builder(context: Context, password: String?, vararg args: String): ProcessBuilder {
        val pb = ProcessBuilder(cliBin(context).absolutePath, "--socket=${sockFile(context).absolutePath}", *args)
        val compatDir = File(context.filesDir, "lamp-run/compat-libs")
        pb.environment()["LD_LIBRARY_PATH"] = "${compatDir.absolutePath}:${context.applicationInfo.nativeLibraryDir}"
        if (password != null) pb.environment()["MYSQL_PWD"] = password
        return pb
    }

    private fun run(pb: ProcessBuilder, timeoutMin: Long, stdin: File? = null): Run {
        pb.redirectErrorStream(true)
        if (stdin != null) pb.redirectInput(stdin)
        val proc = pb.start()
        val sb = StringBuilder()
        // Doc dau ra o luong rieng de ong dan khong day khi nap in nhieu loi; chi giu ~4000 ky tu dau (co the chua cau thong bao loi).
        val reader = Thread {
            try {
                proc.inputStream.bufferedReader().use { r ->
                    val buf = CharArray(4096)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        if (sb.length < 4000) sb.append(buf, 0, n)
                    }
                }
            } catch (_: Exception) {
            }
        }
        reader.start()
        val finished = proc.waitFor(timeoutMin, TimeUnit.MINUTES)
        if (!finished) {
            proc.destroyForcibly()
            proc.waitFor(10, TimeUnit.SECONDS)
        }
        reader.join(2000)
        return Run(if (finished) proc.exitValue() else -1, sb.toString().trim(), !finished)
    }

    private fun admin(context: Context, sql: String, timeoutMin: Long = 3): Run =
        run(builder(context, null, "-uroot", "-N", "-B", "-e", sql), timeoutMin)

    /** Xoa database tam + user tam (idempotent). Goi truoc khi bat dau (don ton du) va trong finally. */
    private fun cleanup(context: Context) {
        try {
            admin(context, "DROP DATABASE IF EXISTS `$VERIFY_DB`; DROP USER IF EXISTS '$VERIFY_USER'@'localhost';")
        } catch (e: Exception) {
            Log.w(TAG, "don database tam: ${e.javaClass.simpleName}")
        }
    }

    fun verifyLatest(context: Context): Outcome {
        val filesDir = context.filesDir
        val latest = BackupManager.listBackups(context).firstOrNull()
            ?: return Outcome(Status.SKIPPED, "Chua co file backup nao")
        if (System.currentTimeMillis() - latest.lastModified() < 5 * 60_000L) {
            return Outcome(Status.SKIPPED, "Backup moi nhat vua duoc ghi (< 5 phut) - de lan sau")
        }
        val temps = ArrayList<File>()
        try {
            var zip = latest
            if (latest.name.endsWith(".zip.enc")) {
                val pass = BackupManager.effectivePassphrase(context)
                    ?: return Outcome(Status.SKIPPED, "Backup moi nhat da ma hoa nhung chua co mat khau de giai ma")
                val decrypted = File(context.cacheDir, "verify-${System.currentTimeMillis()}.zip")
                temps.add(decrypted)
                try {
                    BackupManager.decryptBackupFile(latest, pass, decrypted)
                } catch (e: Exception) {
                    return Outcome(Status.FAILED, "Khong giai ma duoc ${latest.name} (mat khau hien tai khac luc backup, hoac file hong)")
                }
                zip = decrypted
            }

            val insp = BackupLogic.inspect(zip, maxEntries = Int.MAX_VALUE)
            if (!insp.ok) return Outcome(Status.FAILED, "${latest.name}: ${insp.reason}")
            if (!insp.hasDb) return Outcome(Status.SKIPPED, "Backup khong co database (che do Lite/SQLite hoac runtime khac)")
            val hasConfig = BackupLogic.zipHasEntry(zip, "www/wp-config.php")
            if (!hasConfig && !BackupLogic.zipHasEntry(zip, "www/wp-includes/version.php")) {
                return Outcome(Status.SKIPPED, "Khong phai site WordPress - chua ho tro khoi phuc thu")
            }
            if (!hasConfig) return Outcome(Status.FAILED, "Backup WordPress thieu www/wp-config.php")

            if (!sockFile(context).exists() || !cliBin(context).exists()) return Outcome(Status.SKIPPED, "MariaDB khong chay (hoac thieu mysql client)")
            if (File(filesDir, "lamp-run/mariadb-asleep").exists()) return Outcome(Status.SKIPPED, "MariaDB dang ngu (Auto-Sleep) - khong danh thuc chi de kiem tra")
            val hotC = Monitoring.thresholds(context).hotC
            if (MonitorLogic.isHot(Monitoring.batteryTempTenths(context), hotC * 10)) return Outcome(Status.SKIPPED, "May dang nong >= $hotC do C - de lan sau")
            val (pct, charging, _) = Monitoring.deviceStatus(context)
            if (!charging && pct in 0..39) return Outcome(Status.SKIPPED, "Pin duoi 40% va khong sac - de lan sau")

            val stamp = System.currentTimeMillis()
            val dumpFile = File(context.cacheDir, "verify-dump-$stamp.sql")
            val rewritten = File(context.cacheDir, "verify-dump-rw-$stamp.sql")
            temps.add(dumpFile)
            temps.add(rewritten)
            if (!BackupLogic.extractDbDump(zip, dumpFile)) return Outcome(Status.FAILED, "Khong lay duoc database.sql ra tu backup")
            val free = try { StatFs(filesDir.absolutePath).availableBytes } catch (_: Exception) { 0L }
            if (free < dumpFile.length() * 4 + MIN_FREE_EXTRA_BYTES) {
                return Outcome(Status.SKIPPED, "Khong du dung luong trong de nap thu (can ~4 lan kich thuoc dump)")
            }
            val rw = BackupLogic.rewriteDumpForVerify(dumpFile, rewritten, VERIFY_DB)
            dumpFile.delete()
            if (!rw.ok) return Outcome(if (rw.unsupported) Status.SKIPPED else Status.FAILED, rw.reason)

            cleanup(context)
            val pw = UUID.randomUUID().toString().replace("-", "")
            val setup = admin(
                context,
                "CREATE DATABASE `$VERIFY_DB` CHARACTER SET utf8mb4; " +
                    "CREATE USER '$VERIFY_USER'@'localhost' IDENTIFIED BY '$pw'; " +
                    "GRANT ALL PRIVILEGES ON `$VERIFY_DB`.* TO '$VERIFY_USER'@'localhost';"
            )
            if (setup.code != 0) {
                cleanup(context)
                return Outcome(Status.SKIPPED, "Khong tao duoc database tam: ${setup.out.take(200)}")
            }
            try {
                val imp = run(builder(context, pw, "-u$VERIFY_USER", VERIFY_DB), IMPORT_TIMEOUT_MIN, stdin = rewritten)
                if (imp.timedOut) return Outcome(Status.FAILED, "Nap thu backup qua $IMPORT_TIMEOUT_MIN phut - da huy")
                if (imp.code != 0) return Outcome(Status.FAILED, "Nap thu ${latest.name} vao database tam THAT BAI: ${imp.out.take(300)}")

                val names = admin(context, "SELECT table_name FROM information_schema.tables WHERE table_schema='$VERIFY_DB'")
                    .out.lines().map { it.trim() }.filter { it.isNotEmpty() }
                val prefix = BackupLogic.pickWpPrefix(names)
                    ?: return Outcome(Status.FAILED, "Nap duoc nhung khong co bang ...options/...posts cua WordPress (${names.size} bang)")
                val posts = admin(context, "SELECT COUNT(*) FROM `$VERIFY_DB`.`${prefix}posts`").out.trim().toLongOrNull()
                val siteurl = admin(context, "SELECT COUNT(*) FROM `$VERIFY_DB`.`${prefix}options` WHERE option_name='siteurl'").out.trim().toLongOrNull()
                if (siteurl == null || siteurl < 1L) {
                    return Outcome(Status.FAILED, "Nap duoc nhung thieu dong 'siteurl' trong bang ${prefix}options - du lieu khong day du")
                }
                return Outcome(Status.OK, "Khoi phuc thu OK: ${names.size} bang, ${posts ?: -1} bai/trang (${latest.name})")
            } finally {
                cleanup(context)
            }
        } catch (e: Exception) {
            Log.w(TAG, "kiem tra backup: ${e.javaClass.simpleName}")
            return Outcome(Status.SKIPPED, "Khong kiem tra duoc luc nay (${e.javaClass.simpleName})")
        } finally {
            for (f in temps) try { f.delete() } catch (_: Exception) { }
        }
    }

    /** Luu ket qua gan nhat (hien o /status cua Telegram) va bao dong khi FAILED. */
    fun record(context: Context, outcome: Outcome) {
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putLong(Prefs.KEY_VERIFY_LAST_AT, System.currentTimeMillis())
            .putString(Prefs.KEY_VERIFY_LAST_STATUS, outcome.status.name)
            .putString(Prefs.KEY_VERIFY_LAST_MSG, outcome.message)
            .apply()
        if (outcome.status == Status.FAILED) {
            val text = "WP Pocket Server - KIEM TRA KHOI PHUC BACKUP THAT BAI: ${outcome.message}. Hay backup lai va kiem tra ngay."
            val token = SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
            val chat = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
            if (TelegramNotifier.isConfigured(token, chat)) {
                try { TelegramNotifier.sendMessage(token!!, chat!!, "\u26A0\uFE0F $text") } catch (e: Exception) { Log.w(TAG, "telegram: ${e.javaClass.simpleName}") }
            }
            AlertWebhook.notify(context, "backup_verify_failed", text)
        }
    }

    /** 1 dong cho /status: "- Kiem tra khoi phuc backup: OK - ... (3 ngay truoc)"; null neu chua tung chay. */
    fun summary(context: Context): String? {
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val at = prefs.getLong(Prefs.KEY_VERIFY_LAST_AT, 0L)
        val status = prefs.getString(Prefs.KEY_VERIFY_LAST_STATUS, null) ?: return null
        if (at <= 0L) return null
        val days = (System.currentTimeMillis() - at) / 86_400_000L
        val msg = prefs.getString(Prefs.KEY_VERIFY_LAST_MSG, "") ?: ""
        return "- Kiem tra khoi phuc backup: $status - $msg (${if (days <= 0L) "hom nay" else "$days ngay truoc"})"
    }
}
