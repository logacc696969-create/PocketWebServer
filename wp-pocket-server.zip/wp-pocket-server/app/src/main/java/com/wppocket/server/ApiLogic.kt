package com.wppocket.server

import java.security.SecureRandom

/**
 * API trang thai CHI DOC cho mang LAN (PDF 2 muc T1; HANDOFF.md muc 1bp-L). Chi java.* (khong Android) de test duoc.
 * Thiet ke KHONG viet them PHP xac thuc moi: Kotlin ghi `lamp-run/api-status.json` (truong KHONG nhay cam), start-lamp.sh chen vao nginx.conf mot
 * `location = /api/v1/status` co `Authorization: Bearer <token>`, chi cho dai mang RIENG (tuyet doi khong 127.0.0.1 - tunnel Cloudflare noi tu day).
 */
object ApiLogic {
    const val TOKEN_BYTES = 32            // 256 bit -> 64 ky tu hex
    const val MIN_TOKEN_LEN = 32          // PHAI khop api_token_valid trong start-lamp.sh
    const val MAX_TOKEN_LEN = 64
    private const val HEX = "0123456789abcdef"

    fun generateToken(rnd: SecureRandom): String {
        val b = ByteArray(TOKEN_BYTES)
        rnd.nextBytes(b)
        val sb = StringBuilder()
        for (x in b) {
            sb.append(HEX[(x.toInt() shr 4) and 0xF])
            sb.append(HEX[x.toInt() and 0xF])
        }
        return sb.toString()
    }

    /** 32..64 ky tu [0-9a-f] - cung quy tac voi start-lamp.sh (neu khong hop le, nginx khong mo cong API). */
    fun isValidToken(t: String?): Boolean {
        if (t == null || t.length < MIN_TOKEN_LEN || t.length > MAX_TOKEN_LEN) return false
        for (c in t) if (!((c in '0'..'9') || (c in 'a'..'f'))) return false
        return true
    }

    fun jsonEscape(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c.code < 0x20 -> sb.append(String.format("\\u%04x", c.code))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** Gia tri khong biet -> null (khong bia so): pin ngoai 0..100, dia ngoai 0..100, chua tung backup (<= 0). */
    fun buildStatusJson(
        nowSec: Long, running: Boolean, batteryPct: Int, charging: Boolean, diskUsedPct: Int,
        lastBackupAtSec: Long, backupCount: Int, appVersion: String
    ): String {
        val sb = StringBuilder()
        sb.append("{\"schema\":\"wp-pocket-status/1\"")
        sb.append(",\"generated_at\":").append(nowSec)
        sb.append(",\"server_running\":").append(if (running) "true" else "false")
        sb.append(",\"battery_pct\":").append(if (batteryPct in 0..100) batteryPct.toString() else "null")
        sb.append(",\"charging\":").append(if (charging) "true" else "false")
        sb.append(",\"disk_used_pct\":").append(if (diskUsedPct in 0..100) diskUsedPct.toString() else "null")
        sb.append(",\"last_backup_at\":").append(if (lastBackupAtSec > 0L) lastBackupAtSec.toString() else "null")
        sb.append(",\"backup_count\":").append(if (backupCount >= 0) backupCount.toString() else "0")
        sb.append(",\"app_version\":\"").append(jsonEscape(appVersion)).append("\"}")
        return sb.toString()
    }
}
