package com.wppocket.server

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL

/**
 * Hoi GitHub ban phat hanh moi nhat. CHI chay khi nguoi dung BAM nut "Kiem tra ban moi" (khong chay nen, khong hen gio) va chi lien
 * he api.github.com, khong gui gi cua nguoi dung (khong dinh danh, khong token). Ten repo do CI ghi vao assets luc build
 * (xem workflow, buoc "Ghi ten repo") - nen app tu biet minh den tu repo nao ma khong can nguoi dung cau hinh. HANDOFF.md muc 1bg.
 */
object UpdateChecker {
    /** "owner/repo" CI ghi vao assets/update-repo.txt; null neu ban build khong co (vd build o may rieng). */
    fun readRepo(context: Context): String? = try {
        context.assets.open("update-repo.txt").bufferedReader().use { it.readText() }.trim().takeIf { UpdateLogic.isValidRepo(it) }
    } catch (_: Exception) {
        null
    }

    /** Chay tren luong NEN. Tra ve tag_name; nem IllegalStateException voi thong bao doc duoc neu loi. */
    fun fetchLatestTag(repo: String, includePre: Boolean = false): String {
        val conn = URL(UpdateLogic.latestApiUrl(repo, includePre)).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "WPPocketServer-UpdateCheck")
            val code = conn.responseCode
            if (code == 404) throw IllegalStateException("Repo chua co ban phat hanh (Release) nao")
            if (code !in 200..299) throw IllegalStateException("GitHub tra ve HTTP $code")
            val body = conn.inputStream.bufferedReader().use { it.readText() }.take(300_000)
            return UpdateLogic.parseTag(body) ?: throw IllegalStateException("Khong doc duoc tag_name")
        } finally {
            conn.disconnect()
        }
    }
}
