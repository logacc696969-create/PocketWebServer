package com.wppocket.server

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * J5/J6 (PDF 2, HANDOFF.md muc 1bn): dich den cua APP SHORTCUTS (nhan giu bieu tuong app tren man hinh chinh): Bat server / Tat server /
 * Backup ngay. Thay cho "thanh dieu huong duoi" va "nut noi (FAB)" ma PDF de xuat: man hinh chinh la MOT man cuon doc, khong co cac man
 * de chuyen, con phim tat cua launcher moi la dang truy cap nhanh dung cua Android.
 *
 * AN TOAN: activity nay KHONG exported (manifest) nen app khac KHONG goi duoc de tat server cua ban. Static shortcut van chay duoc activity
 * khong exported vi launcher khoi chay no qua LauncherApps.startShortcut voi tu cach CHINH app nay (tai lieu Android: "a shortcut can launch an
 * unexported activity within the publisher app"). Theme NoDisplay: bat buoc finish() truoc khi onCreate tra ve.
 */
class ShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            when (intent?.action) {
                ACTION_START -> {
                    // Giong HET QuickToggleTileService/MainActivity.startServer(): khoi dong tu nen PHAI dung startForegroundService.
                    ContextCompat.startForegroundService(
                        this, Intent(this, ServerForegroundService::class.java).apply { action = ServerForegroundService.ACTION_START }
                    )
                    Toast.makeText(this, R.string.shortcut_toast_start, Toast.LENGTH_SHORT).show()
                }
                ACTION_STOP -> {
                    startService(Intent(this, ServerForegroundService::class.java).apply { action = ServerForegroundService.ACTION_STOP })
                    Toast.makeText(this, R.string.shortcut_toast_stop, Toast.LENGTH_SHORT).show()
                }
                ACTION_BACKUP -> {
                    BackupWorker.runNow(applicationContext)
                    Toast.makeText(this, R.string.toast_backup_started, Toast.LENGTH_SHORT).show()
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, R.string.shortcut_toast_failed, Toast.LENGTH_LONG).show()
        }
        finish()
    }

    companion object {
        const val ACTION_START = "com.wppocket.server.shortcut.START"
        const val ACTION_STOP = "com.wppocket.server.shortcut.STOP"
        const val ACTION_BACKUP = "com.wppocket.server.shortcut.BACKUP"
    }
}
