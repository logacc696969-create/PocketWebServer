package com.wppocket.server

/**
 * Bo ma hoa ma QR (PDF 1 muc K4, PDF 2 muc A3) - THUAN Kotlin (khong import android.*, khong them phu thuoc nao), che do BYTE
 * (UTF-8), phien ban 1..40, 4 muc sua loi L/M/Q/H, tu chon mat na theo diem phat (penalty) cua dac ta ISO/IEC 18004.
 *
 * Vi sao TU VIET thay vi dung thu vien: du an tranh them phu thuoc moi (chuoi cung ung, xem THIRD_PARTY_NOTICES.md). Ly do cu de
 * khong lam ("khong kiem chung duoc anh QR co QUET duoc that khong") da het hieu luc: ban Java sat nguyen ban cua file nay
 * (scripts/tests/java/QrCodePort.java) duoc CI/test KIEM CHUNG bang bo giai ma QR that (OpenCV QRCodeDetector) tren hang tram
 * chuoi, du 40 phien ban x 4 muc sua loi - xem scripts/tests/qr-code-test.py.
 *
 * Cau truc theo cach trinh bay pho bien cua cac cai dat tham chieu (ma tran module, vung chuc nang, Reed-Solomon tren GF(256)
 * da thuc 0x11D). Tra ve null (khong nem loi) khi du lieu qua dai de giao dien tu rut ve "chi sao chep".
 */
class QrCode private constructor(val version: Int, val ecc: Ecc, dataCodewords: ByteArray) {

    enum class Ecc(val formatBits: Int) { LOW(1), MEDIUM(0), QUARTILE(3), HIGH(2) }

    /** Canh ma tran (so module), 21 (v1) .. 177 (v40). */
    val size: Int = version * 4 + 17

    private val modules: Array<BooleanArray> = Array(size) { BooleanArray(size) }
    private val isFunction: Array<BooleanArray> = Array(size) { BooleanArray(size) }

    /** Mat na (0..7) duoc chon. */
    var mask: Int = 0
        private set

    init {
        drawFunctionPatterns()
        val all = addEccAndInterleave(dataCodewords)
        drawCodewords(all)
        var best = 0
        var bestPenalty = Int.MAX_VALUE
        for (m in 0 until 8) {
            applyMask(m)
            drawFormatBits(m)
            val p = penaltyScore()
            if (p < bestPenalty) {
                best = m
                bestPenalty = p
            }
            applyMask(m) // XOR lan 2 = hoan tac
        }
        mask = best
        applyMask(best)
        drawFormatBits(best)
    }

    /** true = module toi. Toa do ngoai ma tran = sang (vung yen tinh). */
    fun isDark(x: Int, y: Int): Boolean = x in 0 until size && y in 0 until size && modules[y][x]

    /** Ban sao ma tran [hang][cot], true = toi. */
    fun toMatrix(): Array<BooleanArray> = Array(size) { modules[it].copyOf() }

    // ----------------------------------------------------------------- ve vung chuc nang

    private fun setFunction(x: Int, y: Int, dark: Boolean) {
        modules[y][x] = dark
        isFunction[y][x] = true
    }

    private fun drawFunctionPatterns() {
        for (i in 0 until size) {
            setFunction(6, i, i % 2 == 0)
            setFunction(i, 6, i % 2 == 0)
        }
        drawFinder(3, 3)
        drawFinder(size - 4, 3)
        drawFinder(3, size - 4)
        val align = alignmentPositions(version)
        val n = align.size
        for (i in 0 until n) {
            for (j in 0 until n) {
                if (!((i == 0 && j == 0) || (i == 0 && j == n - 1) || (i == n - 1 && j == 0))) {
                    drawAlignment(align[i], align[j])
                }
            }
        }
        drawFormatBits(0) // giu cho, se ve lai dung sau khi chon mat na
        drawVersion()
    }

    private fun drawFinder(cx: Int, cy: Int) {
        for (dy in -4..4) {
            for (dx in -4..4) {
                val dist = Math.max(Math.abs(dx), Math.abs(dy))
                val x = cx + dx
                val y = cy + dy
                if (x in 0 until size && y in 0 until size) setFunction(x, y, dist != 2 && dist != 4)
            }
        }
    }

    private fun drawAlignment(cx: Int, cy: Int) {
        for (dy in -2..2) {
            for (dx in -2..2) {
                setFunction(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1)
            }
        }
    }

    private fun drawFormatBits(m: Int) {
        val data = (ecc.formatBits shl 3) or m
        var rem = data
        for (i in 0 until 10) rem = (rem shl 1) xor ((rem ushr 9) * 0x537)
        val bits = ((data shl 10) or rem) xor 0x5412
        for (i in 0..5) setFunction(8, i, getBit(bits, i))
        setFunction(8, 7, getBit(bits, 6))
        setFunction(8, 8, getBit(bits, 7))
        setFunction(7, 8, getBit(bits, 8))
        for (i in 9 until 15) setFunction(14 - i, 8, getBit(bits, i))
        for (i in 0 until 8) setFunction(size - 1 - i, 8, getBit(bits, i))
        for (i in 8 until 15) setFunction(8, size - 15 + i, getBit(bits, i))
        setFunction(8, size - 8, true) // module toi co dinh
    }

    private fun drawVersion() {
        if (version < 7) return
        var rem = version
        for (i in 0 until 12) rem = (rem shl 1) xor ((rem ushr 11) * 0x1F25)
        val bits = (version shl 12) or rem
        for (i in 0 until 18) {
            val dark = getBit(bits, i)
            val a = size - 11 + i % 3
            val b = i / 3
            setFunction(a, b, dark)
            setFunction(b, a, dark)
        }
    }

    // ----------------------------------------------------------------- Reed-Solomon + xep ma tu

    private fun addEccAndInterleave(data: ByteArray): ByteArray {
        val numBlocks = NUM_ERROR_CORRECTION_BLOCKS[ecc.ordinal][version]
        val blockEccLen = ECC_CODEWORDS_PER_BLOCK[ecc.ordinal][version]
        val rawCodewords = numRawDataModules(version) / 8
        val numShortBlocks = numBlocks - rawCodewords % numBlocks
        val shortBlockLen = rawCodewords / numBlocks
        val blocks = ArrayList<IntArray>()
        val div = rsComputeDivisor(blockEccLen)
        var k = 0
        for (i in 0 until numBlocks) {
            val datLen = shortBlockLen - blockEccLen + (if (i < numShortBlocks) 0 else 1)
            val dat = IntArray(datLen) { data[k + it].toInt() and 0xFF }
            k += datLen
            val e = rsComputeRemainder(dat, div)
            val block = IntArray(shortBlockLen + 1)
            System.arraycopy(dat, 0, block, 0, datLen) // block ngan: o cuoi phan du lieu giu 0 (bi bo qua khi xen ke)
            System.arraycopy(e, 0, block, shortBlockLen + 1 - blockEccLen, blockEccLen)
            blocks.add(block)
        }
        val result = ByteArray(rawCodewords)
        var r = 0
        for (i in 0 until shortBlockLen + 1) {
            for (j in 0 until numBlocks) {
                if (i != shortBlockLen - blockEccLen || j >= numShortBlocks) {
                    result[r++] = blocks[j][i].toByte()
                }
            }
        }
        return result
    }

    private fun drawCodewords(data: ByteArray) {
        var i = 0
        var right = size - 1
        while (right >= 1) {
            if (right == 6) right = 5
            for (vert in 0 until size) {
                for (j in 0 until 2) {
                    val x = right - j
                    val upward = ((right + 1) and 2) == 0
                    val y = if (upward) size - 1 - vert else vert
                    if (!isFunction[y][x] && i < data.size * 8) {
                        modules[y][x] = getBit(data[i ushr 3].toInt() and 0xFF, 7 - (i and 7))
                        i++
                    }
                }
            }
            right -= 2
        }
    }

    private fun applyMask(m: Int) {
        for (y in 0 until size) {
            for (x in 0 until size) {
                val invert = when (m) {
                    0 -> (x + y) % 2 == 0
                    1 -> y % 2 == 0
                    2 -> x % 3 == 0
                    3 -> (x + y) % 3 == 0
                    4 -> (x / 3 + y / 2) % 2 == 0
                    5 -> x * y % 2 + x * y % 3 == 0
                    6 -> (x * y % 2 + x * y % 3) % 2 == 0
                    else -> ((x + y) % 2 + x * y % 3) % 2 == 0
                }
                if (!isFunction[y][x] && invert) modules[y][x] = !modules[y][x]
            }
        }
    }

    // ----------------------------------------------------------------- diem phat (chon mat na)

    private fun penaltyScore(): Int {
        var result = 0
        // N1: day >= 5 module cung mau (hang va cot).
        for (y in 0 until size) {
            var run = 1
            for (x in 1 until size) {
                if (modules[y][x] == modules[y][x - 1]) {
                    run++
                } else {
                    if (run >= 5) result += run - 2
                    run = 1
                }
            }
            if (run >= 5) result += run - 2
        }
        for (x in 0 until size) {
            var run = 1
            for (y in 1 until size) {
                if (modules[y][x] == modules[y - 1][x]) {
                    run++
                } else {
                    if (run >= 5) result += run - 2
                    run = 1
                }
            }
            if (run >= 5) result += run - 2
        }
        // N2: khoi 2x2 cung mau.
        for (y in 0 until size - 1) {
            for (x in 0 until size - 1) {
                val c = modules[y][x]
                if (c == modules[y][x + 1] && c == modules[y + 1][x] && c == modules[y + 1][x + 1]) result += 3
            }
        }
        // N3: mau giong bo dinh vi 1:1:3:1:1, co 4 module sang o mot ben.
        for (y in 0 until size) result += finderLikePenalty(BooleanArray(size) { modules[y][it] })
        for (x in 0 until size) result += finderLikePenalty(BooleanArray(size) { modules[it][x] })
        // N4: ty le module toi lech khoi 50%.
        var dark = 0
        for (y in 0 until size) for (x in 0 until size) if (modules[y][x]) dark++
        val total = size * size
        val k = (Math.abs(dark * 20 - total * 10) + total - 1) / total - 1
        result += k * 10
        return result
    }

    private fun finderLikePenalty(line: BooleanArray): Int {
        var result = 0
        val pat = booleanArrayOf(true, false, true, true, true, false, true)
        var i = 0
        while (i + 7 <= line.size) {
            var match = true
            for (p in 0 until 7) if (line[i + p] != pat[p]) { match = false; break }
            if (match) {
                var before = i >= 4
                if (before) for (p in 1..4) if (line[i - p]) { before = false; break }
                var after = i + 7 + 4 <= line.size
                if (after) for (p in 0 until 4) if (line[i + 7 + p]) { after = false; break }
                if (before) result += 40
                if (after) result += 40
            }
            i++
        }
        return result
    }

    companion object {
        const val MIN_VERSION = 1
        const val MAX_VERSION = 40

        // Chi so [muc sua loi theo thu tu enum: L, M, Q, H][phien ban]; phan tu 0 la dem (khong dung).
        private val ECC_CODEWORDS_PER_BLOCK: Array<IntArray> = arrayOf(
            intArrayOf(-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
            intArrayOf(-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28),
            intArrayOf(-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
            intArrayOf(-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30)
        )
        private val NUM_ERROR_CORRECTION_BLOCKS: Array<IntArray> = arrayOf(
            intArrayOf(-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25),
            intArrayOf(-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49),
            intArrayOf(-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68),
            intArrayOf(-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81)
        )

        /** Ma hoa [text] (UTF-8, che do byte). Tra ve null neu khong vua phien ban 40 o muc [ecc] yeu cau. [boost]: nang muc sua loi khi con du cho trong cung phien ban. */
        fun encodeText(text: String, ecc: Ecc = Ecc.MEDIUM, boost: Boolean = true): QrCode? =
            encodeBytes(text.toByteArray(Charsets.UTF_8), ecc, boost)

        fun encodeBytes(data: ByteArray, ecc: Ecc = Ecc.MEDIUM, boost: Boolean = true): QrCode? {
            var version = MIN_VERSION
            var usedBits = 0
            while (true) {
                val cap = numDataCodewords(version, ecc) * 8
                val used = dataBits(data.size, version)
                if (used != -1 && used <= cap) {
                    usedBits = used
                    break
                }
                if (version >= MAX_VERSION) return null
                version++
            }
            var e = ecc
            if (boost) {
                for (cand in arrayOf(Ecc.MEDIUM, Ecc.QUARTILE, Ecc.HIGH)) {
                    if (usedBits <= numDataCodewords(version, cand) * 8) e = cand
                }
            }
            val capBits = numDataCodewords(version, e) * 8
            val bits = ArrayList<Int>()
            appendBits(bits, 0x4, 4) // che do byte
            appendBits(bits, data.size, charCountBits(version))
            for (b in data) appendBits(bits, b.toInt() and 0xFF, 8)
            appendBits(bits, 0, Math.min(4, capBits - bits.size)) // ky tu ket thuc
            appendBits(bits, 0, (8 - bits.size % 8) % 8)
            var pad = 0xEC
            while (bits.size < capBits) {
                appendBits(bits, pad, 8)
                pad = pad xor 0xEC xor 0x11
            }
            val dataCodewords = ByteArray(bits.size / 8)
            for (i in bits.indices) {
                if (bits[i] == 1) dataCodewords[i ushr 3] = (dataCodewords[i ushr 3].toInt() or (1 shl (7 - (i and 7)))).toByte()
            }
            return QrCode(version, e, dataCodewords)
        }

        /** So byte du lieu toi da o phien ban [version], muc [ecc] (che do byte). Dung de test doi chieu bang dung luong chuan. */
        fun byteCapacity(version: Int, ecc: Ecc): Int {
            val bits = numDataCodewords(version, ecc) * 8 - 4 - charCountBits(version)
            val cap = bits / 8
            val maxByCount = (1 shl charCountBits(version)) - 1
            return Math.min(cap, maxByCount)
        }

        fun charCountBits(version: Int): Int = if (version <= 9) 8 else 16

        private fun dataBits(len: Int, version: Int): Int {
            val cc = charCountBits(version)
            if (len >= (1 shl cc)) return -1
            return 4 + cc + 8 * len
        }

        private fun appendBits(bits: ArrayList<Int>, value: Int, len: Int) {
            for (i in len - 1 downTo 0) bits.add((value ushr i) and 1)
        }

        fun numRawDataModules(ver: Int): Int {
            var result = (16 * ver + 128) * ver + 64
            if (ver >= 2) {
                val numAlign = ver / 7 + 2
                result -= (25 * numAlign - 10) * numAlign - 55
                if (ver >= 7) result -= 36
            }
            return result
        }

        fun numDataCodewords(ver: Int, ecc: Ecc): Int =
            numRawDataModules(ver) / 8 - ECC_CODEWORDS_PER_BLOCK[ecc.ordinal][ver] * NUM_ERROR_CORRECTION_BLOCKS[ecc.ordinal][ver]

        fun alignmentPositions(ver: Int): IntArray {
            if (ver == 1) return IntArray(0)
            val numAlign = ver / 7 + 2
            val step = if (ver == 32) 26 else ((ver * 4 + 4) + (numAlign * 2 - 2) - 1) / (numAlign * 2 - 2) * 2
            val result = IntArray(numAlign)
            result[0] = 6
            var pos = ver * 4 + 17 - 7
            for (i in numAlign - 1 downTo 1) {
                result[i] = pos
                pos -= step
            }
            return result
        }

        private fun getBit(x: Int, i: Int): Boolean = ((x ushr i) and 1) != 0

        private fun rsMultiply(x: Int, y: Int): Int {
            var z = 0
            for (i in 7 downTo 0) {
                z = (z shl 1) xor ((z ushr 7) * 0x11D)
                z = z xor (((y ushr i) and 1) * x)
            }
            return z
        }

        private fun rsComputeDivisor(degree: Int): IntArray {
            val result = IntArray(degree)
            result[degree - 1] = 1
            var root = 1
            for (i in 0 until degree) {
                for (j in 0 until degree) {
                    result[j] = rsMultiply(result[j], root)
                    if (j + 1 < degree) result[j] = result[j] xor result[j + 1]
                }
                root = rsMultiply(root, 0x02)
            }
            return result
        }

        private fun rsComputeRemainder(data: IntArray, divisor: IntArray): IntArray {
            val result = IntArray(divisor.size)
            for (b in data) {
                val factor = b xor result[0]
                System.arraycopy(result, 1, result, 0, result.size - 1)
                result[result.size - 1] = 0
                for (i in divisor.indices) result[i] = result[i] xor rsMultiply(divisor[i], factor)
            }
            return result
        }
    }
}
