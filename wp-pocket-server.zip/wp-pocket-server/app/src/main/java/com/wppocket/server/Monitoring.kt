package com.wppocket.server

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.app.usage.UsageStatsManager
import android.os.BatteryManager
import android.os.Build
import android.os.StatFs
import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phan "keo dinh" Android cua cac tinh nang giam sat (xem HANDOFF.md muc
 * 1au). Moi phep tinh nam o MonitorLogic (da kiem thu JVM); file nay chi doc
 * trang thai he thong (pin, dung luong, TrafficStats, mang), luu SharedPreferences
 * va gui Telegram. Moi ham NUOT loi (ghi Logcat): mot canh bao hong KHONG
 * duoc lam hong HealthCheckWorker (watchdog) - day moi la viec song con.
 */
object Monitoring {
    private const val TAG = "Monitoring"
    private const val DISK_ALERT_COOLDOWN_MS = 24L * 60 * 60 * 1000
    private const val AUDIT_ALERT_COOLDOWN_MS = 30L * 60 * 1000
    private const val SECURITY_ALERT_COOLDOWN_MS = 10L * 60 * 1000
    private const val BIG_LOG_BYTES = 1L * 1024 * 1024

    private fun prefs(context: Context) =
        context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)

    /** Gui 1 tin Telegram neu da cau hinh; false neu chua cau hinh/that bai. */
    private fun notifyTelegram(context: Context, text: String): Boolean {
        val p = prefs(context)
        val token = SecretStore.get(p, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val chat = p.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
        if (!TelegramNotifier.isConfigured(token, chat)) return false
        return TelegramNotifier.sendMessage(token!!, chat!!, text)
    }

    /** Goi dinh ky tu HealthCheckWorker (~15 phut). Moi viec doc lap, loi cua
     * viec nay khong chan viec kia. */
    fun runPeriodic(context: Context) {
        try { updateDataBudget(context) } catch (e: Exception) { Log.w(TAG, "data budget", e) }
        try { checkDisk(context) } catch (e: Exception) { Log.w(TAG, "disk", e) }
        try { checkAdminAudit(context) } catch (e: Exception) { Log.w(TAG, "audit", e) }
        try { checkSecurityEvents(context) } catch (e: Exception) { Log.w(TAG, "security events", e) }
        try { checkPhpFatals(context) } catch (e: Exception) { Log.w(TAG, "php fatal", e) }
        try { StatusApi.write(context) } catch (e: Exception) { Log.w(TAG, "api status", e) }
        try { syncHeavyJobsFlag(context) } catch (e: Exception) { Log.w(TAG, "heavy flag", e) }
        try { checkEnvironment(context) } catch (e: Exception) { Log.w(TAG, "environment", e) }
        try { checkAlertRules(context) } catch (e: Exception) { Log.w(TAG, "alert rules", e) }
        try { checkInterruptedRestore(context) } catch (e: Exception) { Log.w(TAG, "interrupted restore", e) }
    }

    /**
     * 1bq-E: khoi phuc bi gian doan (xem RestoreMarker): bao Telegram DUNG 1 lan cho moi dau danh dau (nho thoi diem bat dau); khong gui duoc
     * thi lan sau thu lai. Khong bao khi khoi phuc co the dang chay that (dau danh dau chua du 15 phut tuoi).
     */
    fun checkInterruptedRestore(context: Context) {
        val m = RestoreMarker.read(context.filesDir) ?: return
        if (!RestoreMarker.isInterrupted(m, System.currentTimeMillis())) return
        val p = prefs(context)
        if (p.getLong(Prefs.KEY_RESTORE_ALERTED_AT, -1L) == m.startedAtMs) return
        if (notifyTelegram(context, "\u26A0\uFE0F WP Pocket Server: " + RestoreMarker.describe(m))) {
            p.edit().putLong(Prefs.KEY_RESTORE_ALERTED_AT, m.startedAtMs).apply()
        }
    }

    // ------------------------- Uptime 24h/7d/30d (PDF 2 muc H4) -------------------------

    /** File mau uptime: moi dong "epoch_giay,1|0" (xem MonitorLogic.parseUptimeCsv). _admin/metrics.php doc cung file nay. */
    private fun uptimeFile(context: Context): File = File(File(context.filesDir, "lamp-run"), "uptime.csv")

    /**
     * Ghi 1 mau uptime. Goi tu HealthCheckWorker (~15 phut/lan): up=true khi website tra loi, up=false khi khong tra loi hoac khi
     * dich vu bi he dieu hanh giet trong luc nguoi dung van muon chay. KHONG ghi mau khi nguoi dung chu dong tat server (khong
     * phai su co). Loi ghi (dia day...) KHONG duoc lam hong worker nen nuot loi va chi log.
     */
    fun recordUptimeSample(context: Context, up: Boolean) {
        try {
            val f = uptimeFile(context)
            f.parentFile?.mkdirs()
            val old = if (f.exists()) MonitorLogic.parseUptimeCsv(f.readText()) else emptyList()
            val updated = MonitorLogic.appendUptimeSample(old, System.currentTimeMillis() / 1000, up)
            val tmp = File(f.parentFile, "uptime.csv.tmp")
            tmp.writeText(MonitorLogic.formatUptimeCsv(updated))
            if (!tmp.renameTo(f)) {
                f.writeText(MonitorLogic.formatUptimeCsv(updated))
                tmp.delete()
            }
        } catch (e: Exception) {
            Log.w(TAG, "uptime", e)
        }
    }

    /** 3 dong "24 gio / 7 ngay / 30 ngay" cho /status cua Telegram; null neu chua co file mau nao. */
    fun uptimeSummary(context: Context): String? {
        return try {
            val f = uptimeFile(context)
            if (!f.exists()) return null
            val samples = MonitorLogic.parseUptimeCsv(f.readText())
            if (samples.isEmpty()) return null
            val now = System.currentTimeMillis() / 1000
            listOf(
                "24 gio" to 24L * 3600,
                "7 ngay" to 7L * 24 * 3600,
                "30 ngay" to MonitorLogic.UPTIME_KEEP_SEC
            ).joinToString("\n") { (label, win) ->
                "- Uptime " + MonitorLogic.formatUptimeLine(label, MonitorLogic.uptimeStats(samples, now, win))
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------- Heartbeat (A3) -------------------------

    /** GET toi URL heartbeat da cau hinh. KHONG ghi URL/thong diep loi vao log:
     * URL kieu healthchecks.io CHUA MA BI MAT, ai doc log (da share de debug)
     * se ping gia duoc. */
    fun pingHeartbeat(context: Context) {
        val url = SecretStore.get(prefs(context), Prefs.KEY_HEARTBEAT_URL, null)?.trim()
        if (url.isNullOrEmpty() || !(url.startsWith("https://") || url.startsWith("http://"))) return
        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 10_000
                requestMethod = "GET"
            }
            conn.responseCode
            conn.disconnect()
        } catch (e: Exception) {
            Log.w(TAG, "Heartbeat that bai (${e.javaClass.simpleName})")
        }
    }

    // ------------------------- Data di dong theo thang (B7/B3) -------------------------

    private fun monthKey(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

    private fun isOnCellular(context: Context): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    /** Cap nhat bo dem data di dong cua thang, gui canh bao 80%/100% (moi muc
     * 1 lan/thang) va bat/tat co giam toc. [cellularNow] = null thi tu do loai
     * mang hien tai; ServerForegroundService truyen loai mang CU khi vua doi
     * mang de gan phan data tich luy cho DUNG mang da dung no. synchronized vi
     * 2 noi goi co the chay dong thoi (worker 15 phut + callback doi mang). */
    @Synchronized
    fun updateDataBudget(context: Context, cellularNow: Boolean? = null) {
        // NGUON BO DEM (xem HANDOFF.md muc 1aw): uu tien bo dem interface DI DONG TOAN MAY
        // (getMobileRx/TxBytes). Ly do (tra cuu tai lieu + ma nguon AOSP): bo dem theo UID
        // "dem qua MOI interface" (tai lieu TrafficStats) va dumpsys netd cho thay interface
        // "lo" co bo dem rieng theo UID -> khong loai tru duoc viec tinh them luu luong
        // loopback nginx<->cloudflared; con bo dem toan may chi tinh cac interface di dong
        // (ma nguon TrafficStats loai "lo" tuong minh) va CHI tang khi dung 4G/5G, nen khong
        // can UOC LUONG "luc nay dang o mang nao". Dien thoai chay server chuyen dung nen
        // data toan may chinh la thu nha mang tinh tien. Neu may khong ho tro (-1) thi lui ve
        // bo dem theo UID + uoc luong loai mang nhu truoc.
        val mobileRx = TrafficStats.getMobileRxBytes()
        val mobileTx = TrafficStats.getMobileTxBytes()
        val source: String
        val total: Long
        val counterIsCellularOnly: Boolean
        if (mobileRx >= 0 && mobileTx >= 0) {
            source = "mobile"; total = mobileRx + mobileTx; counterIsCellularOnly = true
        } else {
            val uid = android.os.Process.myUid()
            val rx = TrafficStats.getUidRxBytes(uid)
            val tx = TrafficStats.getUidTxBytes(uid)
            if (rx < 0 || tx < 0) return // TrafficStats.UNSUPPORTED (-1) o ca 2 nguon
            source = "uid"; total = rx + tx; counterIsCellularOnly = false
        }
        val p = prefs(context)
        val oldSource = p.getString(Prefs.KEY_DATA_SOURCE, "") ?: ""
        val prev0 = MonitorLogic.BudgetState(
            p.getString(Prefs.KEY_DATA_MONTH_KEY, "") ?: "",
            p.getLong(Prefs.KEY_DATA_MONTH_CELL_BYTES, 0L),
            p.getLong(Prefs.KEY_DATA_LAST_TOTAL, -1L),
            p.getInt(Prefs.KEY_DATA_ALERT_LEVEL, 0)
        )
        val prev = MonitorLogic.rebaseIfSourceChanged(prev0, oldSource, source)
        var next = MonitorLogic.applyUsage(
            prev, monthKey(), total,
            if (counterIsCellularOnly) true else (cellularNow ?: isOnCellular(context))
        )

        val budgetBytes = p.getInt(Prefs.KEY_DATA_BUDGET_MB, 0).toLong() * 1024 * 1024
        val level = MonitorLogic.budgetLevel(next.cellBytes, budgetBytes)
        if (level > next.alertLevel) {
            val usedMb = next.cellBytes / (1024 * 1024)
            val budgetMb = budgetBytes / (1024 * 1024)
            val throttle = p.getBoolean(Prefs.KEY_DATA_BUDGET_THROTTLE, false)
            val msg = if (level >= 100) {
                "\u26A0\uFE0F WP Pocket Server: da VUOT ngan sach data di dong thang nay " +
                    "(${usedMb}MB / ${budgetMb}MB, uoc tinh, toan may)." +
                    if (throttle) " Dang giam toc do tai ve de tiet kiem data." else ""
            } else {
                "\u26A0\uFE0F WP Pocket Server: da dung ${usedMb}MB / ${budgetMb}MB data di dong thang nay " +
                    "(uoc tinh, toan may, tu 80% ngan sach)."
            }
            // Chi nang muc da bao khi GUI THANH CONG - neu Telegram chua cau
            // hinh/that bai thi lan sau (15 phut) con co co hoi bao lai.
            if (notifyTelegram(context, msg)) next = next.copy(alertLevel = level)
        }

        p.edit()
            .putString(Prefs.KEY_DATA_MONTH_KEY, next.monthKey)
            .putLong(Prefs.KEY_DATA_MONTH_CELL_BYTES, next.cellBytes)
            .putLong(Prefs.KEY_DATA_LAST_TOTAL, next.lastTotal)
            .putInt(Prefs.KEY_DATA_ALERT_LEVEL, next.alertLevel)
            .putString(Prefs.KEY_DATA_SOURCE, source)
            .apply()

        // Co giam toc: nginx doc "-f lamp-run/bandwidth-limited" (xem
        // nginx.conf.template). Bat khi DA VUOT ngan sach VA nguoi dung bat tuy
        // chon; tat ngay khi khong con dung (sang thang moi / doi ngan sach).
        val flag = File(context.filesDir, "lamp-run/bandwidth-limited")
        val wantThrottle = budgetBytes > 0 && level >= 100 && p.getBoolean(Prefs.KEY_DATA_BUDGET_THROTTLE, false)
        try {
            if (wantThrottle) {
                flag.parentFile?.mkdirs()
                if (!flag.exists()) flag.writeText("1")
            } else if (flag.exists()) {
                flag.delete()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Khong cap nhat duoc co giam toc", e)
        }
    }

    /** Dong tom tat cho lenh /status cua Telegram; null neu chua bat ngan sach. */
    fun monthlyDataSummary(context: Context): String? {
        val p = prefs(context)
        val budgetMb = p.getInt(Prefs.KEY_DATA_BUDGET_MB, 0)
        if (budgetMb <= 0) return null
        val usedMb = p.getLong(Prefs.KEY_DATA_MONTH_CELL_BYTES, 0L) / (1024 * 1024)
        return "- Data di dong thang nay: ${usedMb}MB / ${budgetMb}MB (toan may, uoc tinh)"
    }

    // ------------------------- Dung luong dia (B4) -------------------------

    /** Khi dung luong >= 85%: tu don cac file .log lon (KHONG dong vao backup,
     * khong dong vao nhat ky dang nhap) roi bao Telegram toi da 1 lan/24 gio. */
    fun checkDisk(context: Context) {
        val dir = context.filesDir
        var st = StatFs(dir.absolutePath)
        var pct = MonitorLogic.usedPercent(st.totalBytes, st.availableBytes)
        val diskAlertPct = thresholds(context).diskPct
        if (pct < diskAlertPct) return
        var freed = MonitorLogic.truncateBigLogs(File(dir, "lamp-run"), BIG_LOG_BYTES, setOf("admin-audit.log"))
        freed += MonitorLogic.truncateBigLogs(dir, BIG_LOG_BYTES)
        if (freed > 0) {
            st = StatFs(dir.absolutePath)
            pct = MonitorLogic.usedPercent(st.totalBytes, st.availableBytes)
        }
        val p = prefs(context)
        val now = System.currentTimeMillis()
        if (MonitorLogic.shouldAlertDisk(pct, diskAlertPct, p.getLong(Prefs.KEY_DISK_ALERT_AT, 0L), now, DISK_ALERT_COOLDOWN_MS)) {
            val freeMb = st.availableBytes / (1024 * 1024)
            val msg = "\u26A0\uFE0F WP Pocket Server: bo nho may da dung $pct% (con trong ${freeMb}MB)" +
                (if (freed > 0) ". Da tu don ${freed / (1024 * 1024)}MB file log." else ".") +
                " Neu van day, hay xoa bot backup cu hoac du lieu khac tren may."
            if (notifyTelegram(context, msg)) p.edit().putLong(Prefs.KEY_DISK_ALERT_AT, now).apply()
        }
    }

    // ------------------------- Loi PHP nghiem trong (PDF 2 muc H6, HANDOFF.md muc 1bp) -------------------------

    private const val PHP_FATAL_ALERT_COOLDOWN_MS = 60L * 60 * 1000

    /**
     * Doc phan MOI cua lamp-run/php-error.log (PHP da tu ghi san), gom nhom + phan loai (FatalLogLogic) va bao Telegram toi da
     * 1 lan/gio. Chi tien vi tri doc khi DA bao duoc (hoac khong co loi): dang trong thoi gian cho hay Telegram loi thi lan sau
     * doc lai cung doan do - khong mat canh bao.
     */
    fun checkPhpFatals(context: Context) {
        val p = prefs(context)
        val log = File(context.filesDir, "lamp-run/php-error.log")
        val res = FatalLogLogic.readNew(log, p.getLong(Prefs.KEY_PHP_FATAL_OFFSET, 0L))
        val text = FatalLogLogic.alertText(FatalLogLogic.scan(res.first))
        if (text == null) {
            p.edit().putLong(Prefs.KEY_PHP_FATAL_OFFSET, res.second).apply()
            return
        }
        val now = System.currentTimeMillis()
        if (!FatalLogLogic.cooledDown(now, p.getLong(Prefs.KEY_PHP_FATAL_ALERT_AT, 0L), PHP_FATAL_ALERT_COOLDOWN_MS)) return
        Log.w(TAG, text)
        if (notifyTelegram(context, "\u26A0\uFE0F " + text)) {
            p.edit().putLong(Prefs.KEY_PHP_FATAL_OFFSET, res.second).putLong(Prefs.KEY_PHP_FATAL_ALERT_AT, now).apply()
        }
    }

    // ------------------------- Moi truong Android/mang (1bc: Q3/Q4/Q5/Q7/R1) -------------------------

    /** Doc trang thai he thong. Moi gia tri doc loi/khong co quyen -> -1/false (KHONG bao dong gia, xem MonitorLogic.envIssues). */
    private fun readEnvSnapshot(context: Context): MonitorLogic.EnvSnapshot {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val restrict = try { cm?.restrictBackgroundStatus ?: -1 } catch (e: Exception) { -1 }
        val caps = try { cm?.activeNetwork?.let { cm.getNetworkCapabilities(it) } } catch (e: Exception) { null }
        val vpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val cellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true && !vpn
        // NET_CAPABILITY_NOT_ROAMING vang mat = dang roaming. VPN che mang that nen khong ket luan duoc -> khong bao roaming khi co VPN.
        val roaming = cellular && caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING) == false
        val bucket = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { (context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager)?.appStandbyBucket ?: -1 } catch (e: Exception) { -1 }
        } else -1
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val charging = if (i == null) true else MonitorLogic.isCharging(i.getIntExtra(BatteryManager.EXTRA_STATUS, -1), i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0))
        val temp = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, MonitorLogic.TEMP_UNKNOWN) ?: MonitorLogic.TEMP_UNKNOWN
        return MonitorLogic.EnvSnapshot(restrict, vpn, cellular, roaming, bucket, pct, charging, temp)
    }

    private fun envMessage(issue: MonitorLogic.EnvIssue, e: MonitorLogic.EnvSnapshot, th: AlertThresholds.Values): String = when (issue) {
        MonitorLogic.EnvIssue.DATA_SAVER ->
            "\u26A0\uFE0F WP Pocket Server: che do Tiet kiem du lieu (Data Saver) cua Android dang BAT va app chua duoc mien. " +
                "Khi tat man hinh Android co the chan mang nen => tunnel/website bi dut. Vao Cai dat > Ung dung > WP Pocket Server > " +
                "Du lieu di dong (hoac Su dung du lieu) > bat \"Du lieu khong han che\"/cho phep khi Tiet kiem du lieu."
        MonitorLogic.EnvIssue.VPN_ACTIVE ->
            "\u2139\uFE0F WP Pocket Server: may dang dung VPN. Cloudflare Tunnel di qua VPN co the cham/de dut va doi duong ra mang. " +
                "Neu website chap chon, thu tat VPN (hoac loai tru app nay khoi VPN)."
        MonitorLogic.EnvIssue.ROAMING ->
            "\u26A0\uFE0F WP Pocket Server: may dang CHUYEN VUNG (roaming) tren mang di dong - moi luot khach vao website la cuoc data quoc te. " +
                "Nen chuyen sang WiFi hoac tam dung server."
        MonitorLogic.EnvIssue.STANDBY_RESTRICTED ->
            "\u26A0\uFE0F WP Pocket Server: Android xep app vao nhom tiet kiem pin muc cao (RARE/RESTRICTED) vi it duoc mo. " +
                "Health-check, backup va cron co the bi tri hoan hang gio. Mo app thuong xuyen hon va chon \"Khong han che\" cho app trong Cai dat > Pin (nhu huong dan o tren man hinh chinh)."
        MonitorLogic.EnvIssue.BATTERY_CRITICAL ->
            "\uD83D\uDD0B WP Pocket Server: pin con ${e.batteryPct}% va KHONG sac - may co the tat nguon dot ngot trong it phut " +
                "(MariaDB phai phuc hoi khi khoi dong lai). Cam sac ngay."
        MonitorLogic.EnvIssue.DEVICE_WARM ->
            "\uD83C\uDF21\uFE0F WP Pocket Server: nhiet do pin ${MonitorLogic.formatTempC(e.batteryTempTenthsC)}\u00B0C (>= ${th.warmC}\u00B0C). " +
                "Dat may noi thoang mat, tranh vo day/anh nang, sac cham (khong sac nhanh), thao op lung neu co. Qua ${th.hotC}\u00B0C app se tu hoan viec nang."
        MonitorLogic.EnvIssue.DEVICE_HOT ->
            "\uD83D\uDD25 WP Pocket Server: nhiet do pin ${MonitorLogic.formatTempC(e.batteryTempTenthsC)}\u00B0C (>= ${th.hotC}\u00B0C) - QUA NONG, hai pin va lam CPU bi ha xung. " +
                "App DA tu dong hoan viec nang (toi uu DB hang tuan, tu cap nhat WordPress) va hoan backup dinh ky toi da ${MonitorLogic.HEAT_MAX_BACKUP_DEFERRALS} chu ky lien tiep. " +
                "Hay lam mat may ngay (de noi thoang, quat nho, thao vo)."
    }

    /** Kiem tra cac dieu kien moi truong an va gui Telegram (toi da 1 lan / cooldown cua TUNG van de - xem EnvIssue).
     * Chi bao khi Telegram da cau hinh; moi hoa kho xu ly nam o MonitorLogic (da kiem thu JVM). */
    fun checkEnvironment(context: Context) {
        val snap = readEnvSnapshot(context)
        val th = thresholds(context)
        val p = prefs(context)
        val now = System.currentTimeMillis()
        for (issue in MonitorLogic.envIssues(snap, th)) {
            val key = Prefs.KEY_ENV_ALERT_PREFIX + issue.name
            if (!MonitorLogic.shouldAlertEnv(issue, p.getLong(key, 0L), now)) continue
            if (notifyTelegram(context, envMessage(issue, snap, th))) p.edit().putLong(key, now).apply()
        }
    }

    // ------------------------- Nhat ky dang nhap _admin/ (A6) -------------------------

    /** Doc cac dong audit MOI tu lan kiem tra truoc; bao Telegram khi co IP bi
     * khoa hoac nhieu lan dang nhap sai (toi da 1 lan/30 phut). Lan DAU chi dat
     * moc - khong bao lai toan bo lich su cu. */
    fun checkAdminAudit(context: Context) {
        val f = File(context.filesDir, "lamp-run/admin-audit.log")
        if (!f.exists()) return
        val p = prefs(context)
        val offset = p.getLong(Prefs.KEY_AUDIT_OFFSET, -1L)
        if (offset < 0) {
            p.edit().putLong(Prefs.KEY_AUDIT_OFFSET, f.length()).apply()
            return
        }
        // Chua cau hinh Telegram -> khong co noi de bao: bo qua lich su, KHONG de
        // offset ket lai (se doc lai cung doan moi 15 phut vo ich).
        val tgToken = SecretStore.get(p, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val tgChat = p.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
        if (!TelegramNotifier.isConfigured(tgToken, tgChat)) {
            p.edit().putLong(Prefs.KEY_AUDIT_OFFSET, f.length()).apply()
            return
        }
        val (lines, newOffset) = MonitorLogic.readNewLines(f, offset)
        val summary = MonitorLogic.scanAudit(lines)
        val now = System.currentTimeMillis()
        val cooledDown = now - p.getLong(Prefs.KEY_AUDIT_ALERT_AT, 0L) >= AUDIT_ALERT_COOLDOWN_MS
        if (MonitorLogic.shouldAlertAudit(summary)) {
            if (!cooledDown) return // GIU offset cu: lan sau (het cooldown) doc lai, khong mat su kien
            val msg = "\uD83D\uDD12 WP Pocket Server: co dau hieu do mat khau _admin/ - " +
                "${summary.failures} lan dang nhap sai, ${summary.lockouts} lan bi khoa tam" +
                (summary.topIp?.let { ", nhieu nhat tu IP $it (${summary.topIpFailures} su kien)" } ?: "") +
                ". Xem tab nhat ky dang nhap trong _admin/logs.php."
            if (!notifyTelegram(context, msg)) return // chua gui duoc -> chua tien offset
            p.edit().putLong(Prefs.KEY_AUDIT_ALERT_AT, now).apply()
        }
        p.edit().putLong(Prefs.KEY_AUDIT_OFFSET, newOffset).apply()
    }

    // ------------------------- Su kien bao mat (HANDOFF.md muc 1br) -------------------------

    /** Doc cac dong MOI cua lamp-run/security-events.log (do security-guard / security-scan / Shield ghi) va bao Telegram khi co ma doc, admin moi,
     * plugin moi kich hoat... Cung mau voi [checkAdminAudit]: lan DAU chi dat moc; chua cau hinh Telegram thi bo qua lich su; cooldown 10 phut,
     * chua gui duoc thi GIU offset de lan sau doc lai (khong mat su kien). */
    fun checkSecurityEvents(context: Context) {
        val f = File(context.filesDir, "lamp-run/security-events.log")
        if (!f.exists()) return
        val p = prefs(context)
        val offset = p.getLong(Prefs.KEY_SECEVT_OFFSET, -1L)
        if (offset < 0) {
            p.edit().putLong(Prefs.KEY_SECEVT_OFFSET, f.length()).apply()
            return
        }
        val tgToken = SecretStore.get(p, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val tgChat = p.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
        if (!TelegramNotifier.isConfigured(tgToken, tgChat)) {
            p.edit().putLong(Prefs.KEY_SECEVT_OFFSET, f.length()).apply()
            return
        }
        val (lines, newOffset) = MonitorLogic.readNewLines(f, offset)
        val summary = MonitorLogic.scanSecurityEvents(lines)
        val now = System.currentTimeMillis()
        if (MonitorLogic.shouldAlertSecurity(summary)) {
            if (now - p.getLong(Prefs.KEY_SECEVT_ALERT_AT, 0L) < SECURITY_ALERT_COOLDOWN_MS) return // GIU offset cu
            val head = if (summary.urgent > 0) "🚨 WP Pocket Server: CAN XEM NGAY" else "🔒 WP Pocket Server: canh bao bao mat"
            val msg = head + " - ${summary.urgent} su kien nghiem trong, ${summary.notices} luu y" +
                (if (summary.autoBans > 0) ", ${summary.autoBans} IP bi tu dong chan" else "") + ".\n" +
                summary.samples.joinToString("\n") { "• $it" } +
                "\nXem _admin/security.php (Trung tam bao mat)."
            if (!notifyTelegram(context, msg)) return
            p.edit().putLong(Prefs.KEY_SECEVT_ALERT_AT, now).apply()
        }
        p.edit().putLong(Prefs.KEY_SECEVT_OFFSET, newOffset).apply()
    }

    // ------------------------- Viec nang chi khi sac (B6) -------------------------

    /** Cap nhat co "lamp-run/defer-heavy-jobs" cho phia PHP (mu-plugin wppocket-maintenance.php
     * doc qua getenv('APP_HOME')): co ton tai & moi (<2 gio) = hoan OPTIMIZE TABLE hang tuan
     * va tu dong cap nhat WordPress. Goi moi ~15 phut (runPeriodic), khi bam "Luu" va truoc
     * khi bat server. Khong anh huong backup (da co tuy chon rieng) va khong anh huong
     * website/uptime. */
    fun syncHeavyJobsFlag(context: Context) {
        val enabled = prefs(context).getBoolean(Prefs.KEY_HEAVY_ONLY_CHARGING, false)
        // AJ3 (1bm): may >= 45 C -> hoan viec nang KE CA khi nguoi dung chua bat tuy chon "chi khi sac" (cung co dung de giam tai).
        val hot = MonitorLogic.isHot(batteryTempTenths(context), thresholds(context).hotTenths)
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val charging = if (i == null) true // khong doc duoc pin -> coi nhu sac (khong hoan viec) - an toan
        else MonitorLogic.isCharging(
            i.getIntExtra(BatteryManager.EXTRA_STATUS, -1),
            i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0),
        )
        MonitorLogic.syncFlagFile(
            File(context.filesDir, "lamp-run/defer-heavy-jobs"),
            MonitorLogic.wantDeferHeavyJobs(enabled, charging, hot),
            System.currentTimeMillis(),
        )
    }

    // ------------------------- Nguong canh bao chinh duoc + quy tac tu dinh nghia (H5, AE5 - 1br) -------------------------

    /** Nguong dang dung: doc tu cai dat roi KEP vao khoang hop ly (AlertThresholds.sanitize) - gia tri hong khong lam hong canh bao. */
    fun thresholds(context: Context): AlertThresholds.Values {
        val p = prefs(context)
        return AlertThresholds.sanitize(
            p.getInt(Prefs.KEY_ALERT_DISK_PCT, AlertThresholds.DISK_DEFAULT),
            p.getInt(Prefs.KEY_ALERT_BATT_CRIT_PCT, AlertThresholds.BATT_CRIT_DEFAULT),
            p.getInt(Prefs.KEY_ALERT_WARM_C, AlertThresholds.WARM_DEFAULT),
            p.getInt(Prefs.KEY_ALERT_HOT_C, AlertThresholds.HOT_DEFAULT),
        )
    }

    /** Doc cac chi so cho quy tac. Moi chi so doc loi/khong co -> null (KHONG BAO GIO gay canh bao gia). */
    private fun readRuleMetrics(context: Context): Map<AlertRules.Metric, Double?> {
        val out = HashMap<AlertRules.Metric, Double?>()
        out[AlertRules.Metric.DISK_PERCENT] = try {
            val st = StatFs(context.filesDir.absolutePath)
            val pct = MonitorLogic.usedPercent(st.totalBytes, st.availableBytes)
            if (pct in 0..100) pct.toDouble() else null
        } catch (e: Exception) { null }
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        out[AlertRules.Metric.BATTERY_PERCENT] = if (level >= 0 && scale > 0) level * 100.0 / scale else null
        val temp = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, MonitorLogic.TEMP_UNKNOWN) ?: MonitorLogic.TEMP_UNKNOWN
        out[AlertRules.Metric.BATTERY_TEMP_C] = if (MonitorLogic.batteryTempKnown(temp)) temp / 10.0 else null
        out[AlertRules.Metric.RAM_PERCENT] = try {
            val mi = android.app.ActivityManager.MemoryInfo()
            (context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
            AlertRules.ramPercent(mi.totalMem, mi.availMem)
        } catch (e: Exception) { null }
        // Android 8+ co the chan doc /proc/loadavg voi ung dung thuong -> null (quy tac theo load_avg_1m khong bao gio kich hoat tren may do).
        out[AlertRules.Metric.LOAD_AVG_1M] = try { AlertRules.parseLoadAvg(File("/proc/loadavg").readText()) } catch (e: Exception) { null }
        val p = prefs(context)
        val monthNow = monthKey()
        out[AlertRules.Metric.DATA_MONTH_MB] = if (p.getString(Prefs.KEY_DATA_MONTH_KEY, "") == monthNow) p.getLong(Prefs.KEY_DATA_MONTH_CELL_BYTES, 0L) / 1048576.0 else 0.0
        return out
    }

    /**
     * AE5: danh gia cac quy tac nguoi dung tu dinh nghia (Prefs.KEY_ALERT_RULES), bao Telegram khi dieu kien dung du lau va het cooldown.
     * Chi danh dau "da bao" khi Telegram gui THANH CONG. Don trang thai cua quy tac da bi xoa/doi ten. Logic thuan: AlertRules (kiem tren JVM).
     */
    fun checkAlertRules(context: Context) {
        val p = prefs(context)
        val rules = AlertRules.parse(p.getString(Prefs.KEY_ALERT_RULES, "") ?: "").rules
        val live = rules.map { Prefs.KEY_ALERT_RULE_STATE_PREFIX + it.name }.toSet()
        val stale = p.all.keys.filter { it.startsWith(Prefs.KEY_ALERT_RULE_STATE_PREFIX) && it !in live }
        if (stale.isNotEmpty()) p.edit().apply { stale.forEach { remove(it) } }.apply()
        if (rules.isEmpty()) return
        val metrics = readRuleMetrics(context)
        val now = System.currentTimeMillis()
        for (rule in rules) {
            val key = Prefs.KEY_ALERT_RULE_STATE_PREFIX + rule.name
            val st = AlertRules.decodeState(p.getString(key, null))
            val value = metrics[rule.metric]
            val ev = AlertRules.evaluate(rule, value, now, st)
            var next = ev.state
            if (ev.fire && value != null) {
                if (notifyTelegram(context, "\u26A0\uFE0F WP Pocket Server: " + AlertRules.describe(rule, value, ev.heldMinutes))) {
                    next = AlertRules.markAlerted(next, now)
                }
            }
            if (next != st) p.edit().putString(key, AlertRules.encodeState(next)).apply()
        }
    }

    // ------------------------- Nhiet do / trang thai pin (AJ2, AJ3 - 1bm) -------------------------

    /** Nhiet do pin theo 1/10 do C; [MonitorLogic.TEMP_UNKNOWN] neu khong doc duoc. Doc intent dinh (sticky) - khong ton pin. */
    fun batteryTempTenths(context: Context): Int {
        val i: Intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return MonitorLogic.TEMP_UNKNOWN
        return i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, MonitorLogic.TEMP_UNKNOWN)
    }

    /** Trang thai pin cho man hinh chinh: (phan tram hoac -1, dang sac, nhiet do 1/10 do C hoac TEMP_UNKNOWN). */
    fun deviceStatus(context: Context): Triple<Int, Boolean, Int> {
        val i: Intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return Triple(-1, true, MonitorLogic.TEMP_UNKNOWN)
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val charging = MonitorLogic.isCharging(i.getIntExtra(BatteryManager.EXTRA_STATUS, -1), i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0))
        return Triple(pct, charging, i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, MonitorLogic.TEMP_UNKNOWN))
    }

    // ------------------------- Pin (B1) -------------------------

    /** true neu NEN tam dung viec nen khong khan cap (hien: poll Telegram):
     * bat tuy chon (mac dinh BAT) + pin < 15% + khong sac. KHONG ap dung cho
     * HealthCheckWorker/website - uptime la muc dich chinh. */
    fun shouldPauseForLowBattery(context: Context): Boolean {
        if (!prefs(context).getBoolean(Prefs.KEY_LOW_BATTERY_PAUSE, true)) return false
        val i: Intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        // 1bc: dung MonitorLogic.isCharging (EXTRA_PLUGGED > 0 la chinh) nhu syncHeavyJobsFlag - truoc day chi xet status nen may
        // DANG CAM SAC nhung bao NOT_CHARGING/DISCHARGING (qua nong) bi coi la "khong sac" va tam dung poll Telegram oan.
        val charging = MonitorLogic.isCharging(
            i.getIntExtra(BatteryManager.EXTRA_STATUS, -1),
            i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0),
        )
        return MonitorLogic.isLowBattery(pct, charging)
    }
}
