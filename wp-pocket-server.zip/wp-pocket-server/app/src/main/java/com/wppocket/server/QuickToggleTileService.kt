package com.wppocket.server

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat

/**
 * Quick Settings Tile (ô gạt nhanh trong khay thông báo Android, kéo xuống
 * từ trên cùng màn hình) - bật/tắt server không cần mở app. Đề xuất
 * DeepSeek mục K1 (xem HANDOFF.md mục 10).
 *
 * minSdk của dự án là 26 (xem app/build.gradle.kts) - CAO HƠN mức API
 * TileService yêu cầu (24), nên KHÔNG cần bọc `Build.VERSION.SDK_INT` như
 * PowerManager.OnThermalStatusChangedListener (yêu cầu API 29, cao hơn
 * minSdk, xem ServerForegroundService.kt) - tính năng này hoạt động vô
 * điều kiện trên MỌI máy chạy được app.
 *
 * KHÔNG dùng `startActivityAndCollapse(Intent)` (mở app khi bấm) - ô gạt
 * này CHỈ bật/tắt server tại chỗ, giống hệt cách ô "Đèn pin"/"Xoay màn
 * hình" mặc định của Android hoạt động (không mở app nào cả).
 */
class QuickToggleTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTileState()
    }

    override fun onClick() {
        super.onClick()
        val turningOn = !ServerForegroundService.isRunning
        val intent = Intent(this, ServerForegroundService::class.java).apply {
            action = if (turningOn) ServerForegroundService.ACTION_START else ServerForegroundService.ACTION_STOP
        }
        try {
            if (turningOn) {
                // Giống HET MainActivity.startServer() - bat buoc dung
                // startForegroundService() (khong phai startService() thuong)
                // khi khoi dong TU NEN, neu khong Android nem
                // ForegroundServiceStartNotAllowedException tren API moi.
                ContextCompat.startForegroundService(this, intent)
            } else {
                startService(intent)
            }
        } catch (_: Exception) {
            // He thong tam thoi tu choi khoi dong (hiem, vd may dang trong
            // trang thai gioi han nen ngam) - khong lam gi them, o gat se tu
            // hien lai dung trang thai THAT o lan onStartListening() ke tiep,
            // khong "ket" o trang thai sai vi ban than qsTile chua doi.
        }
        // Cap nhat TAM THOI ngay khi bam (phan hoi tuc thi, UX tot hon doi
        // Service bao cao ve) - se duoc lam DUNG LAI o onStartListening()
        // ke tiep neu vi ly do gi khac voi thuc te (vd startForegroundService
        // that bai o tren).
        refreshTileStateOptimistic(turningOn)
    }

    private fun refreshTileState() {
        val tile = qsTile ?: return
        tile.state = if (ServerForegroundService.isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }

    private fun refreshTileStateOptimistic(turningOn: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (turningOn) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
