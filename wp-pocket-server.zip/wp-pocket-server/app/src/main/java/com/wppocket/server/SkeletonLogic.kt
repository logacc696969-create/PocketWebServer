package com.wppocket.server

/**
 * J4 (PDF 2 "skeleton loading"; HANDOFF.md muc 1bq-I). THUAN Kotlin (khong import android.*).
 *
 * Pham vi THAT: man hinh chinh doc trang thai tu bien tinh cua service moi giay nen KHONG co trang thai "dang tai" nao khac ngoai MOT cho
 * that su cho doi vai giay -> hang chuc giay: dong dia chi cong khai trong luc ham Cloudflare dang duoc tao ("dang tao duong ham cong khai...").
 * Cho do nhap nhay do trong (alpha) thay vi chu dung im, de nguoi dung biet app dang lam viec. Khong them view/layout moi (khong co gi de mo layout hong).
 * TON TRONG cai dat "Xoa/tat hoat anh" cua he thong: Settings.Global.ANIMATOR_DURATION_SCALE = 0 -> khong nhap nhay.
 */
object SkeletonLogic {
    const val PERIOD_MS = 900L
    const val ALPHA_MIN = 0.35f

    /** Chi nhap nhay khi dang tai VA he thong cho phep hoat anh (scale > 0, khong NaN/vo cuc). */
    fun shouldAnimate(animatorScale: Float, loading: Boolean): Boolean =
        loading && !animatorScale.isNaN() && !animatorScale.isInfinite() && animatorScale > 0f
}
