package com.wppocket.server

import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Bat toan bo crash (uncaught exception) CUA CA APP - khong chi 1 Activity/
 * Service rieng le - va ghi ra "crash-log.txt" trong filesDir, xem duoc
 * ngay trong LogViewerActivity (danh sach 9 log, xem class do) MA KHONG CAN
 * adb/may tinh. De xuat DeepSeek muc K8: "Neu app crash (Kotlin), nguoi
 * dung khong biet tai sao - can Thread.setDefaultUncaughtExceptionHandler
 * -> ghi log ra file -> xem trong LogViewerActivity. Quan trong vi nguoi
 * dung khong co adb."
 *
 * QUAN TRONG - KHONG duoc "nuot" crash: sau khi ghi xong, PHAI goi lai
 * handler mac dinh CU cua he thong (da luu lai luc install()) de tien
 * trinh van chet/khoi dong lai dung nhu Android mong doi. Neu bo qua buoc
 * nay, ung dung co the roi vao trang thai "nua song nua chet" (thread chinh
 * da hong nhung tien trinh khong bi don dep) - te hon la khong bat gi ca.
 * Day CHI la 1 lop QUAN SAT ("chen vao giua roi chuyen tiep"), KHONG PHAI
 * lop thay the co che crash mac dinh cua Android.
 */
object CrashLogger {
    private const val FILE_NAME = "crash-log.txt"

    // Gioi han file (giong tinh than "rotation don gian" da lam cho log
    // LAMP trong start-lamp.sh, xem HANDOFF.md muc 10 de xuat DeepSeek muc
    // F1) - crash HY VONG la hiem, nhung khong the gia dinh CHAC CHAN 0 lan
    // trong suot vong doi cai dat (co the vai nam) - can 1 tran tren de
    // khong phinh vo han. 256KB du chua rat nhieu lan crash (moi lan
    // thuong chi vai KB) ma van nho hon nhieu so voi cac log LAMP khac.
    private const val MAX_BYTES = 256 * 1024L

    private var installed = false

    fun install(context: Context) {
        // An toan neu lo goi 2 lan (Android dam bao Application.onCreate()
        // chi goi 1 lan/tien trinh, nhung kiem tra re tien nay tranh nguy
        // co bao boc CHONG bao boc handler nhieu lop neu co code sau nay vo
        // tinh goi lai).
        if (installed) return
        installed = true

        val appContext = context.applicationContext
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrash(appContext, thread, throwable)
            } catch (_: Throwable) {
                // Ghi log that bai (vd het dung luong may - xem HANDOFF.md
                // nhom B ve tinh trang dia day tren dien thoai) KHONG duoc
                // phep nem tiep 1 loi MOI o day - se che mat throwable GOC
                // (ly do that gay crash) khoi handler mac dinh ben duoi.
            }
            // Luon chuyen tiep cho handler CU (co the la handler mac dinh
            // cua he thong, hoac cua thu vien theo doi crash khac neu co
            // sau nay) - xem chu thich lop class o tren, day la phan BAT
            // BUOC de tien trinh xu ly dung nhu Android mong doi.
            previousHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeCrash(context: Context, thread: Thread, throwable: Throwable) {
        val file = File(context.filesDir, FILE_NAME)

        // Cat bot neu file da qua to TRUOC khi ghi them (giong huong tiep
        // can "head/tail" da dung cho metrics.csv trong start-lamp.sh -
        // giu ban ghi GAN DAY nhat, bo ban ghi cu nhat).
        if (file.exists() && file.length() > MAX_BYTES) {
            val existing = file.readText(Charsets.UTF_8)
            val trimmed = existing.takeLast((MAX_BYTES / 2).toInt())
            file.writeText(trimmed, Charsets.UTF_8)
        }

        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = buildString {
            append("=== CRASH luc $time (thread=${thread.name}) ===\n")
            append("App: ${BuildConfigCompat.versionInfo()}\n")
            append("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), may: ${Build.MANUFACTURER} ${Build.MODEL}\n")
            append(throwable.stackTraceToString())
            append("\n\n")
        }
        file.appendText(entry, Charsets.UTF_8)
    }
}

/**
 * Tach rieng 1 object nho de doc "BuildConfig" AN TOAN qua reflection -
 * KHONG import thang "com.wppocket.server.BuildConfig" tu module nay vi
 * lop do do Android Gradle Plugin TU SINH luc build (khong ton tai luc chi
 * doc source code tinh/bien dich rieng le tung file .kt), tranh phu thuoc
 * thu tu sinh code gay loi bien dich kho hieu. Neu vi ly do gi khong doc
 * duoc (vd ten field doi khac ban Gradle Plugin moi hon), tra ve chuoi rong
 * an toan - day chi la thong tin THAM KHAO them trong crash log, khong anh
 * huong chuc nang bat crash chinh.
 */
private object BuildConfigCompat {
    fun versionInfo(): String = try {
        val cls = Class.forName("com.wppocket.server.BuildConfig")
        val versionName = cls.getField("VERSION_NAME").get(null)
        val versionCode = cls.getField("VERSION_CODE").get(null)
        "$versionName ($versionCode)"
    } catch (_: Throwable) {
        "(khong doc duoc BuildConfig)"
    }
}
