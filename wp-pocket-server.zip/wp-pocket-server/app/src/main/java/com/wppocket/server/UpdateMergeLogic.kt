package com.wppocket.server

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes
import java.util.zip.ZipInputStream

/**
 * Cap nhat APK KHONG DUOC xoa du lieu nguoi dung (PDF 2 muc AD3; HANDOFF.md muc 1bo).
 *
 * LOI THAT truoc ban nay: moi lan cai de APK moi, `ServerForegroundService.prepareRuntimeIfNeeded`
 * goi `docRoot.deleteRecursively()` roi giai nen lai `www.zip`. Nhung `docRoot` (= filesDir/www) la
 * noi nguoi dung co du lieu THAT: `wp-content/uploads` (anh/video), plugin/theme ho tu cai,
 * `wp-content/database/.ht.sqlite` (TOAN BO noi dung site o che do Lite!), file ho tai len bang
 * File Manager. Du lieu MariaDB nam rieng (`mysql-data`) nen KHONG mat - site chay tiep nhung
 * anh/plugin bien mat, con che do Lite mat sach bai viet.
 *
 * CACH SUA (gop de, khong xoa): giai nen goi moi DE LEN thu muc hien co.
 *   - Tep cung duong dan voi tep trong goi  -> bi ghi de bang ban moi (cap nhat code, nhu truoc).
 *   - Tep/thu muc nguoi dung them vao       -> GIU NGUYEN (khong co trong goi nen khong bi dung toi).
 *   - [REPLACED_DIRS] la ma nguon cua CHUONG TRINH (trang quan tri, giam sat, loi WordPress, ...):
 *     xoa han roi giai nen lai de khong con tep cu bi go bo o phien ban moi nam lai.
 *   - [REGENERATED_FILES] do start-lamp.sh sinh lai tu mau moi lan khoi dong -> xoa de sinh lai.
 * Tep bi go khoi goi o phien ban moi (ngoai REPLACED_DIRS) van con tren may: danh doi co chu dich -
 * khong bao gio mat du lieu; nguoi dung xoa bang File Manager neu muon.
 *
 * File nay chi dung java.io/java.nio/java.util.zip (khong Android) de test JVM bang kotlinc duoc.
 */
object UpdateMergeLogic {

    /** Thu muc thuoc ve chuong trinh, KHONG chua du lieu nguoi dung: xoa han roi giai nen lai. */
    val REPLACED_DIRS: List<String> = listOf("_admin", "_supervisor", "mariadb-share", "wp-admin", "wp-includes")

    /** Tep do start-lamp.sh sinh tu mau (wp-config.php) - xoa de duoc sinh lai tu mau cua ban moi. */
    val REGENERATED_FILES: List<String> = listOf("wp-config.php")

    class Result(val written: Int, val skippedLinks: Int, val skippedConflicts: Int)

    /**
     * Chuan hoa ten entry zip thanh duong dan tuong doi an toan ('/' lam dau phan cach).
     * null = KHONG an toan (co NUL, tuyet doi, hoac co thanh phan ".."); "" = chinh thu muc goc (bo qua).
     */
    fun safeRelPath(name: String): String? {
        if (name.indexOf('\u0000') >= 0) return null
        if (name.startsWith("/")) return null
        val parts = ArrayList<String>()
        for (seg in name.split('/')) {
            if (seg.isEmpty() || seg == ".") continue
            if (seg == "..") return null
            parts.add(seg)
        }
        return parts.joinToString("/")
    }

    /**
     * Xoa tep/thu muc MA KHONG THEO symlink (symlink bi xoa chinh no, khong dong vao noi no tro toi).
     * `File.deleteRecursively()` cua Kotlin di xuyen vao thu muc dich cua symlink nen khong dung o day.
     * Loi xoa tung muc (vd tep chi doc) bi bo qua - cham toi muc nao hay muc do.
     */
    fun deleteNoFollow(target: File) {
        val root: Path = target.toPath()
        if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) return
        Files.walkFileTree(root, object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                try { Files.deleteIfExists(file) } catch (_: IOException) {}
                return FileVisitResult.CONTINUE
            }

            override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult {
                return FileVisitResult.CONTINUE
            }

            override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                try { Files.deleteIfExists(dir) } catch (_: IOException) {}
                return FileVisitResult.CONTINUE
            }
        })
    }

    /** Buoc 1 cua cap nhat: don phan thuoc ve chuong trinh, TUYET DOI khong cham du lieu nguoi dung. */
    fun prepareForMerge(docRoot: File) {
        for (d in REPLACED_DIRS) deleteNoFollow(File(docRoot, d))
        for (f in REGENERATED_FILES) deleteNoFollow(File(docRoot, f))
    }

    /**
     * Buoc 2: giai nen [input] (www.zip) DE LEN [targetDir]. Idempotent - chay lai sau khi dang do
     * (mat dien/bi kill giua chung) cho cung ket qua, nen co the thu lai an toan o lan khoi dong sau.
     *
     * - Ten entry co ".." / tuyet doi -> nem IOException (Zip Slip), nhu truoc.
     * - Entry nam duoi 1 SYMLINK tro ra NGOAI targetDir (vd wp-content/cache -> cacheDir) -> BO QUA,
     *   khong ghi xuyen qua link (truoc day se nem loi va khong the khoi dong server).
     * - Tep goi trung ten voi thu muc nguoi dung -> bo qua (giu thu muc, khong xoa du lieu).
     * - Thu muc goi trung ten voi TEP nguoi dung (hiem) -> xoa tep do de nhuong cho thu muc.
     */
    fun extractMerge(input: InputStream, targetDir: File): Result {
        targetDir.mkdirs()
        val rootCanon: String = targetDir.canonicalPath
        var written = 0
        var skippedLinks = 0
        var skippedConflicts = 0
        ZipInputStream(input).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val rel: String = safeRelPath(entry.name)
                    ?: throw IOException("Zip entry khong hop le (Zip Slip): ${entry.name}")
                if (rel.isNotEmpty()) {
                    val out = File(targetDir, rel)
                    val parent: File = out.parentFile ?: targetDir
                    if (!isInside(rootCanon, parent)) {
                        skippedLinks++
                    } else if (entry.isDirectory) {
                        if (Files.isSymbolicLink(out.toPath())) {
                            skippedLinks++
                        } else {
                            if (out.exists() && !out.isDirectory) out.delete()
                            out.mkdirs()
                        }
                    } else {
                        var skip = false
                        if (Files.isSymbolicLink(out.toPath())) {
                            Files.delete(out.toPath())
                        } else if (out.isDirectory) {
                            skippedConflicts++
                            skip = true
                        }
                        if (!skip) {
                            ensureParentDirs(targetDir, parent)
                            FileOutputStream(out).use { fos -> zis.copyTo(fos) }
                            written++
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return Result(written, skippedLinks, skippedConflicts)
    }

    private fun isInside(rootCanon: String, f: File): Boolean {
        val c: String = try { f.canonicalPath } catch (_: IOException) { return false }
        return c == rootCanon || c.startsWith(rootCanon + File.separator)
    }

    /** Tao thu muc cha; thanh phan nao tren duong di dang la TEP thuong thi xoa de nhuong cho thu muc. */
    private fun ensureParentDirs(targetDir: File, parent: File) {
        val rel: String = parent.relativeTo(targetDir).path
        var cur: File = targetDir
        if (rel.isNotEmpty()) {
            for (seg in rel.split(File.separatorChar)) {
                if (seg.isEmpty()) continue
                cur = File(cur, seg)
                if (cur.exists() && !cur.isDirectory) cur.delete()
            }
        }
        parent.mkdirs()
    }
}
