package com.wppocket.server

import java.net.URI
import java.net.URL

/**
 * Chinh sach URL di RA cua app: webhook sao luu, webhook canh bao, heartbeat (HANDOFF.md muc 1br-H, "han che cleartext").
 *
 * Vi sao: cac URL nay mang du lieu NHAY CAM (ban sao luu chua wp-config.php + co so du lieu, ma bi mat trong duong dan webhook/heartbeat). Gui bang
 * http:// la de ai tren cung mang doc/sua duoc. Chinh sach: CHI https://; http:// chi cho may nay (127.0.0.1, localhost, [::1] - vd mot dich vu nhan
 * canh bao chay ngay tren dien thoai). Khop voi res/xml/network_security_config.xml: he dieu hanh cung chan cleartext tu moi ma trong app, ke ca loi
 * sau nay; lop kiem tra nay chi de bao loi SOM va ro rang thay vi de yeu cau that bai am tham luc chay.
 *
 * Cung la ham THUAN (khong dung android.*) de kiem thu tren JVM: scripts/tests/UrlPolicyTest.kt.
 */
object UrlPolicy {
    /** Cac host duoc phep dung http:// - phai KHOP network_security_config.xml (kiem boi test). Dung so khop chinh xac, khong "chua"/"bat dau bang". */
    val LOOPBACK_HOSTS: Set<String> = setOf("127.0.0.1", "localhost", "[::1]")

    private const val MAX_LENGTH = 2048

    /**
     * true neu [url] la https://host/... hoac http:// toi may nay. Tu choi: rong, co khoang trang/ky tu dieu khien, qua dai, khong co host, scheme khac
     * (ftp:, file:, javascript:...), http:// toi host khong phai loopback. Host duoc doc BANG HAI bo phan tich (java.net.URI va java.net.URL - cai sau
     * la cai HttpURLConnection dung that) va phai trung nhau: URL kieu "http://127.0.0.1@evil.com/" hay "http://evil.com\@127.0.0.1/" ma hai bo doc
     * ra hai host khac nhau la cach quen thuoc de qua mat kiem tra "chi loopback".
     */
    fun isAllowedOutbound(url: String?): Boolean {
        val s = url?.trim() ?: return false
        if (s.isEmpty() || s.length > MAX_LENGTH || s.any { it.isWhitespace() || it.isISOControl() }) return false
        val uri = try { URI(s) } catch (_: Exception) { return false }
        val parsed = try { URL(s) } catch (_: Exception) { return false }
        val scheme = uri.scheme?.lowercase() ?: return false
        val host = uri.host?.lowercase() ?: return false
        val host2 = parsed.host?.lowercase() ?: return false
        if (host.isEmpty() || host != host2 || parsed.protocol.lowercase() != scheme) return false
        return when (scheme) {
            "https" -> true
            "http" -> host in LOOPBACK_HOSTS
            else -> false
        }
    }
}
