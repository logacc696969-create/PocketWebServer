package com.wppocket.server

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * "Chua lanh tu dong" (Self-Healing) - de xuat tu PDF "He thong Chua lanh tu
 * dong khong ton RAM" (xem HANDOFF.md muc 1e).
 *
 * ServerForegroundService.runSiteLoop()/runTunnelLoop() DA TU restart tien
 * trinh con (website/tunnel) neu CHINH SERVICE con song - xem vong lap
 * waitFor()+backoff trong file do, khong can viet lai (HANDOFF.md muc 8).
 * Cai CHUA co la: neu he dieu hanh Android giet chet TOAN BO Foreground
 * Service (vd may qua yeu bi OOM killer, hoac nguoi dung lo vuot app khoi
 * Recent Apps lam he thong dep tien trinh), khong co gi tu khoi dong lai
 * NGOAI viec nguoi dung tu mo lai app. Worker nay dong vai tro "watchdog"
 * BEN NGOAI service, kiem tra dinh ky: neu Prefs.KEY_SERVER_WANTED=true
 * (nguoi dung da bam "Bat server", CHUA bam "Tat") nhung
 * ServerForegroundService.isRunning dang false, tu goi lai
 * startForegroundService() - Service.onStartCommand co san co "if (shouldRun)
 * return" nen goi lap lai khi service DA chay la vo hai, khong tao tien
 * trinh trung.
 *
 * GIOI HAN THAT: WorkManager KHONG dam bao chay dung gio (co the tre vai
 * phut den vai chuc phut tuy Doze mode) va khoang cach kiem tra toi thieu la
 * 15 phut (gioi han cua PeriodicWorkRequest tren Android, khong the thap
 * hon) - day la ban chat cua chinh API, khong phai gioi han rieng cua cach
 * lam nay.
 *
 * THEM (xem HANDOFF.md muc 10, de xuat DeepSeek muc A3): ngoai watchdog
 * "Service con song hay khong" o tren, worker nay GIO CON tu goi HTTP THAT
 * toi chinh may (khong qua tunnel) de xac nhan website CO TRA LOI hay
 * khong - va bao qua Telegram (neu da cau hinh) neu khong phan hoi qua
 * nhieu lan lien tiep. Khac voi vong tu-phuc-hoi noi bo (dong 20-22 tren) -
 * cai do tu SUA (restart tien trinh chet), con cai nay chi BAO CHO BIET
 * (khong tu sua them gi), vi tu-phuc-hoi da co san roi, thu that su can la
 * "biet som" khi no khong an hieu qua.
 */
class HealthCheckWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val wanted = prefs.getBoolean(Prefs.KEY_SERVER_WANTED, false)
        if (wanted && !ServerForegroundService.isRunning) {
            val intent = Intent(applicationContext, ServerForegroundService::class.java).apply {
                action = ServerForegroundService.ACTION_START
            }
            ContextCompat.startForegroundService(applicationContext, intent)
        } else if (wanted && ServerForegroundService.isRunning) {
            // (xem HANDOFF.md muc 10, de xuat DeepSeek muc A3) Kiem tra o
            // TREN chi biet "Service Android con song hay khong" - KHONG
            // biet website co THAT SU tra loi dung khong (vd php-fpm/nginx
            // ben trong bi treo/loop loi nhung tien trinh chinh van con) -
            // day la khoang trong lon nhat ve "cam giac hosting tra phi":
            // server "chet im lang" la trai nghiem te nhat, khong ai biet
            // cho toi khi tu minh vao kiem tra. Them self-check HTTP THAT.
            checkSiteRespondingAndAlert(prefs)
        }
        return Result.success()
    }

    /** Goi HTTP that toi chinh may (127.0.0.1) - KHONG qua Cloudflare Tunnel
     * (tranh nham lan loi mang/tunnel voi loi server that). Chi coi la "khong
     * phan hoi" neu KET NOI THAT BAI/HET GIO (vd nginx khong lang nghe,
     * hoac php-fpm treo khong bao gio tra loi) - BAT KY ma HTTP nao tra ve
     * duoc (ke ca 500/404) van tinh la "co phan hoi", vi do la loi TANG UNG
     * DUNG (WordPress/plugin loi), khac han "server chet han" ma tinh nang
     * nay nham canh bao. Doi du FAIL_THRESHOLD lan KIEM TRA LIEN TIEP (moi
     * lan cach nhau toi thieu 15 phut - gioi han WorkManager) moi canh bao,
     * tranh bao dong gia do 1 lan mang chap chon/may vua ngu day sau Doze. */
    private fun checkSiteRespondingAndAlert(prefs: SharedPreferences) {
        val responding = try {
            val url = URL("http://127.0.0.1:${ServerForegroundService.currentPort}/")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 8_000
                requestMethod = "GET"
            }
            conn.responseCode // chi can khong nem Exception la coi nhu "co phan hoi"
            conn.disconnect()
            true
        } catch (_: Exception) {
            false
        }

        val failCount = prefs.getInt(KEY_FAIL_COUNT, 0)
        if (responding) {
            if (failCount != 0) prefs.edit().putInt(KEY_FAIL_COUNT, 0).apply()
            return
        }

        val newCount = failCount + 1
        prefs.edit().putInt(KEY_FAIL_COUNT, newCount).apply()
        // Chi bao DUNG 1 LAN khi vua cham nguong (khong bao lap lai moi 15
        // phut sau do - tranh spam Telegram lien tuc khi nguoi dung da biet
        // va dang tu xu ly) - dem se tu reset ve 0 khi site phan hoi lai.
        if (newCount == FAIL_THRESHOLD) {
            val botToken = prefs.getString(Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
            val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
            if (TelegramNotifier.isConfigured(botToken, chatId)) {
                val minutesDown = FAIL_THRESHOLD * 15
                TelegramNotifier.sendMessage(
                    botToken!!, chatId!!,
                    "\u26A0\uFE0F WP Pocket Server: website khong phan hoi qua $FAIL_THRESHOLD lan kiem tra lien tiep " +
                        "(khoang $minutesDown phut). Vao app kiem tra lai giup minh."
                )
            }
        }
    }

    companion object {
        private const val UNIQUE_NAME = "wp_pocket_health_check"
        private const val KEY_FAIL_COUNT = "health_check_fail_count"
        private const val FAIL_THRESHOLD = 2 // ~30 phut khong phan hoi lien tuc moi canh bao

        /** Idempotent - goi bao nhieu lan cung duoc (KEEP: khong huy lich cu
         * neu da dang ky roi). Nen goi moi khi app mo (MainActivity.onCreate)
         * va moi khi tu bat luc khoi dong may (BootReceiver) de dam bao luon
         * co watchdog chay ben duoi du nguoi dung co mo lai app hay khong. */
        fun ensureScheduled(context: Context) {
            val request = PeriodicWorkRequestBuilder<HealthCheckWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }
    }
}
