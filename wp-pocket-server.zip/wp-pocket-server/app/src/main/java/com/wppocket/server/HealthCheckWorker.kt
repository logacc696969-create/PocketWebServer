package com.wppocket.server

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * "Chua lanh tu dong" (Self-Healing) - de xuat tu PDF "He thong Chua lanh tu
 * dong khong ton RAM" (xem HANDOFF.md muc 1e).
 *
 * ServerForegroundService.runSiteLoop()/runTunnelLoop() DA TU restart tien
 * trinh con (website/tunnel) neu CHINH SERVICE con song - xem vong lap
 * waitFor()+backoff trong file do, khong can viet lai (HANDOFF.md muc 8).
 * Cai CHUA co la: neu he dieu hanh Android giet chet TOAN BO Foreground
 * Service (vd may qua yeu bi OOM killer, hoac nguoi dung lo vuot app khoi
 * Recent Apps lam he thong dep tien trinh), khong co gi tu khoi dong lai
 * NGOAI viec nguoi dung tu mo lai app. Worker nay dong vai tro "watchdog"
 * BEN NGOAI service, kiem tra dinh ky: neu Prefs.KEY_SERVER_WANTED=true
 * (nguoi dung da bam "Bat server", CHUA bam "Tat") nhung
 * ServerForegroundService.isRunning dang false, tu goi lai
 * startForegroundService() - Service.onStartCommand co san co "if (shouldRun)
 * return" nen goi lap lai khi service DA chay la vo hai, khong tao tien
 * trinh trung.
 *
 * GIOI HAN THAT: WorkManager KHONG dam bao chay dung gio (co the tre vai
 * phut den vai chuc phut tuy Doze mode) va khoang cach kiem tra toi thieu la
 * 15 phut (gioi han cua PeriodicWorkRequest tren Android, khong the thap
 * hon) - day la ban chat cua chinh API, khong phai gioi han rieng cua cach
 * lam nay.
 */
class HealthCheckWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val wanted = prefs.getBoolean(Prefs.KEY_SERVER_WANTED, false)
        if (wanted && !ServerForegroundService.isRunning) {
            val intent = Intent(applicationContext, ServerForegroundService::class.java).apply {
                action = ServerForegroundService.ACTION_START
            }
            ContextCompat.startForegroundService(applicationContext, intent)
        }
        return Result.success()
    }

    companion object {
        private const val UNIQUE_NAME = "wp_pocket_health_check"

        /** Idempotent - goi bao nhieu lan cung duoc (KEEP: khong huy lich cu
         * neu da dang ky roi). Nen goi moi khi app mo (MainActivity.onCreate)
         * va moi khi tu bat luc khoi dong may (BootReceiver) de dam bao luon
         * co watchdog chay ben duoi du nguoi dung co mo lai app hay khong. */
        fun ensureScheduled(context: Context) {
            val request = PeriodicWorkRequestBuilder<HealthCheckWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }
    }
}
