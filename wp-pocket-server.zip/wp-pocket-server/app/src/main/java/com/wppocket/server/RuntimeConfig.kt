package com.wppocket.server

import org.json.JSONObject
import java.io.File

/**
 * Mô tả cách khởi chạy website - hoàn toàn tổng quát, không biết gì về
 * PHP/Node/Python/Go. Được nạp từ assets/runtime.json, file này do CI sinh ra
 * dựa trên site.config.json + script tương ứng trong scripts/runtimes/.
 *
 * Nhờ vậy ServerForegroundService không hardcode bất kỳ lệnh chạy cụ thể nào -
 * đổi backend chỉ cần đổi site.config.json, không đụng vào code Kotlin.
 */
data class RuntimeConfig(
    val port: Int,
    val binary: String,
    val docroot: String,
    val exec: List<String>,
    val env: Map<String, String>
) {
    companion object {
        fun loadFromJson(json: String): RuntimeConfig {
            val obj = JSONObject(json)
            val execArr = obj.getJSONArray("exec")
            val exec = (0 until execArr.length()).map { execArr.getString(it) }
            val envObj = obj.optJSONObject("env") ?: JSONObject()
            val env = envObj.keys().asSequence().associateWith { key -> envObj.getString(key) }
            return RuntimeConfig(
                port = obj.optInt("port", 8080),
                binary = obj.optString("binary", "libruntimesrv.so"),
                docroot = obj.optString("docroot", "www"),
                exec = exec,
                env = env
            )
        }
    }

    /** Danh sách lệnh + tham số đã thay các placeholder ${BIN} ${PORT} ${DOCROOT} ${FILESDIR}. */
    fun resolvedExec(nativeLibDir: String, filesDirPath: String): List<String> {
        val map = placeholderMap(nativeLibDir, filesDirPath)
        return exec.map { substitute(it, map) }
    }

    /** Biến môi trường tuỳ chỉnh (khai báo trong runtime.json) đã thay placeholder. */
    fun resolvedEnv(nativeLibDir: String, filesDirPath: String): Map<String, String> {
        val map = placeholderMap(nativeLibDir, filesDirPath)
        return env.mapValues { (_, v) -> substitute(v, map) }
    }

    fun docrootPath(filesDirPath: String): String =
        File(filesDirPath, docroot).absolutePath

    private fun placeholderMap(nativeLibDir: String, filesDirPath: String): Map<String, String> = mapOf(
        "\${BIN}" to File(nativeLibDir, binary).absolutePath,
        "\${PORT}" to port.toString(),
        "\${DOCROOT}" to docrootPath(filesDirPath),
        "\${FILESDIR}" to filesDirPath
    )

    private fun substitute(input: String, map: Map<String, String>): String {
        var result = input
        for ((k, v) in map) result = result.replace(k, v)
        return result
    }
}
