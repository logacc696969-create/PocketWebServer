package com.wppocket.server

import java.io.File
import java.io.RandomAccessFile

/**
 * Logic THUAN (khong import android.*) cua cac tinh nang giam sat (xem
 * HANDOFF.md muc 1au) - tach rieng khoi Monitoring.kt (phan dinh Android:
 * Context/Prefs/Telegram) de CO THE KIEM THU THAT tren JVM voi kotlinc: toan
 * bo cac phep tinh "an tien" (cong don data theo thang, nguong 80%/100%,
 * doc audit tang dan, cat log lon) deu o day.
 */
object MonitorLogic {

    // ----------------------- Ngan sach data theo thang (PDF B7/B3) -----------------------

    /** Trang thai ke toan data: [cellBytes] = byte da dung khi o mang di dong
     * TRONG THANG [monthKey] (uoc tinh - xem applyUsage), [lastTotal] = tong
     * Rx+Tx cua UID app o lan doc truoc (-1 = chua co moc), [alertLevel] =
     * muc canh bao cao nhat da gui trong thang (0/80/100) de khong gui lap. */
    data class BudgetState(
        val monthKey: String,
        val cellBytes: Long,
        val lastTotal: Long,
        val alertLevel: Int
    )

    /** Cong don phan data tang them tu lan doc truoc vao thang hien tai.
     *  - Sang thang moi: dat lai bo dem + muc canh bao, GIU moc lastTotal (neu
     *    khong, toan bo tong tich luy tu truoc se bi tinh het vao thang moi).
     *  - Chua co moc (lastTotal<0): chi dat moc, KHONG tinh gi (khong biet bao
     *    nhieu la cua "bay gio", bao nhieu la tu truoc).
     *  - Bo dem the he moi nho hon moc cu (may khoi dong lai -> counter ve 0):
     *    coi toan bo gia tri hien tai la phan tang them.
     * Phan tang them chi tinh vao cellBytes khi [onCellular] (mang di dong) -
     * la UOC TINH vi chi biet loai mang TAI THOI DIEM doc, khong biet chinh xac
     * luc nao trong khoang giua 2 lan doc da doi mang (xem Monitoring: cung
     * duoc goi ngay luc doi mang de thu hep sai so). */
    fun applyUsage(prev: BudgetState, nowMonthKey: String, curTotal: Long, onCellular: Boolean): BudgetState {
        var st = prev
        if (st.monthKey != nowMonthKey) {
            st = BudgetState(nowMonthKey, 0L, st.lastTotal, 0)
        }
        val delta = when {
            st.lastTotal < 0 -> 0L
            curTotal >= st.lastTotal -> curTotal - st.lastTotal
            else -> curTotal
        }
        return st.copy(
            cellBytes = st.cellBytes + if (onCellular) delta else 0L,
            lastTotal = curTotal
        )
    }

    /** Doi nguon bo dem (vd tu "uid" sang "mobile") -> bo moc cu: tong tich luy cua 2
     * nguon KHONG cung thang do, neu giu moc cu thi phan chenh lech bi tinh het thanh
     * "data da dung" (hoac am -> bi coi la reset). Chi cap nhat moc, giu nguyen
     * bo dem thang va muc canh bao. */
    fun rebaseIfSourceChanged(prev: BudgetState, oldSource: String, newSource: String): BudgetState =
        if (oldSource.isNotEmpty() && oldSource != newSource) prev.copy(lastTotal = -1L) else prev

    /** 0 = chua toi nguong, 80 = tu 80% tro len, 100 = da vuot ngan sach.
     * budgetBytes<=0 nghia la TAT tinh nang -> luon 0. So sanh bang nhan
     * (used*100 >= budget*80) thay vi chia de tranh sai so lam tron so nguyen. */
    fun budgetLevel(usedBytes: Long, budgetBytes: Long): Int = when {
        budgetBytes <= 0L -> 0
        usedBytes >= budgetBytes -> 100
        usedBytes * 100 >= budgetBytes * 80 -> 80
        else -> 0
    }

    // ----------------------- Dung luong dia (PDF B4) -----------------------

    /** % da dung (0..100), -1 neu so lieu khong hop le. */
    fun usedPercent(totalBytes: Long, availBytes: Long): Int {
        if (totalBytes <= 0L || availBytes < 0L || availBytes > totalBytes) return -1
        return (((totalBytes - availBytes) * 100) / totalBytes).toInt()
    }

    /** Chong spam: chi canh bao khi >= nguong VA da qua [cooldownMs] ke tu lan
     * canh bao truoc (lastAlertAtMs=0 nghia la chua tung canh bao). */
    fun shouldAlertDisk(usedPct: Int, thresholdPct: Int, lastAlertAtMs: Long, nowMs: Long, cooldownMs: Long): Boolean =
        usedPct >= thresholdPct && (lastAlertAtMs <= 0L || nowMs - lastAlertAtMs >= cooldownMs)

    /** Cat ve 0 byte cac file .log LON HON [minBytes] trong [dir] (khong de
     * quy), tru ten trong [skip] (vd nhat ky dang nhap quan tri - la bang
     * chung bao mat, khong duoc xoa de tiet kiem cho). Tra ve tong byte da
     * giai phong. setLength(0) AN TOAN khi nginx/php-fpm/mariadbd dang mo file
     * o che do O_APPEND (chung tu ghi tiep tu dau, giong cach start-lamp.sh
     * da cat log tu truoc). */
    fun truncateBigLogs(dir: File, minBytes: Long, skip: Set<String> = emptySet()): Long {
        var freed = 0L
        dir.listFiles { f -> f.isFile && f.name.endsWith(".log") && f.name !in skip && f.length() > minBytes }
            ?.forEach { f ->
                val size = f.length()
                try {
                    RandomAccessFile(f, "rw").use { it.setLength(0) }
                    freed += size
                } catch (_: Exception) {
                    // Khong cat duoc 1 file khong duoc lam hong ca dot don dep.
                }
            }
        return freed
    }

    // ----------------------- Nhat ky dang nhap _admin/ (PDF A6) -----------------------

    data class AuditSummary(
        val failures: Int,
        val lockouts: Int,
        val topIp: String?,
        val topIpFailures: Int
    )

    /** Phan tich cac dong audit MOI (dinh dang cua admin-auth.php:
     * "YYYY-MM-DD HH:MM:SS ip=<ip> <su kien>"). "Sai" = dong bat dau bang
     * "dang nhap sai" hoac "sai ma 2FA"; "khoa" = co "BI KHOA TAM". Dong
     * khong dung dinh dang bi bo qua (khong nem loi). */
    fun scanAudit(lines: List<String>): AuditSummary {
        var failures = 0
        var lockouts = 0
        val perIp = HashMap<String, Int>()
        val re = Regex("""ip=(\S+)\s+(.*)""")
        for (line in lines) {
            val m = re.find(line) ?: continue
            val ip = m.groupValues[1]
            val ev = m.groupValues[2]
            when {
                ev.contains("BI KHOA TAM") -> {
                    lockouts += 1
                    perIp[ip] = (perIp[ip] ?: 0) + 1
                }
                ev.startsWith("dang nhap sai") || ev.startsWith("sai ma 2FA") -> {
                    failures += 1
                    perIp[ip] = (perIp[ip] ?: 0) + 1
                }
            }
        }
        val top = perIp.maxByOrNull { it.value }
        return AuditSummary(failures, lockouts, top?.key, top?.value ?: 0)
    }

    /** Canh bao khi co IP bi KHOA (admin-auth.php da chan, nhung chu may nen
     * biet co nguoi do mat khau) HOAC so lan sai trong 1 dot doc >= nguong. */
    fun shouldAlertAudit(s: AuditSummary, failThreshold: Int = 5): Boolean =
        s.lockouts > 0 || s.failures >= failThreshold

    // ----------------------- Su kien bao mat (security-events.log, HANDOFF.md muc 1br) -----------------------

    data class SecuritySummary(
        /** Can xem NGAY: phat hien ma doc/file la (security-scan), tai khoan quan tri MOI / cap quyen quan tri / doi email quan tri (Shield). */
        val urgent: Int,
        /** Nen biet: plugin vua kich hoat, admin dang nhap tu mang la, tai khoan bi do mat khau tu nhieu IP (Shield tam khoa). */
        val notices: Int,
        /** So IP bi security-guard tu dong chan (chi bao khi la dot tan cong lon - thuong ngay nao cung co vai ke quet). */
        val autoBans: Int,
        /** Toi da 3 dong dai dien (urgent truoc), da loai ky tu dieu khien va cat gon - noi dung do ke tan cong dieu khien (ten file/tai khoan). */
        val samples: List<String>
    )

    // LO HONG (security-vuln.php, 1br-H, tuy chon): plugin/theme/loi DANG CAI nam trong pham vi phien ban bi anh huong cua lo hong da cong bo - muc cao/nghiem trong la KHAN
    // (khai thac hang loat bat dau sau vai gio), trung binh la luu y. Muc thap khong co su kien.
    // 2FA (mu-plugin dang nhap hai buoc, 1br-H): "KHONG DOC DUOC" = bi mat hai buoc hong/bi sua nen tai khoan do dang nhap KHONG can ma; "BI DAT LAI" = quan tri khac
    // xoa hai buoc cua nguoi dung (mat dien thoai that hay ke chiem admin go lop bao ve?). Bat/tat/dung ma khoi phuc la thong tin can biet (ke chiem phien cung co the BAT hai buoc de khoa chu).
    private val SECURITY_URGENT = listOf("PHAT HIEN MA DOC", "TAI KHOAN QUAN TRI MOI", "QUYEN QUAN TRI DUOC CAP", "EMAIL QUAN TRI DA DOI", "2FA KHONG DOC DUOC", "2FA BI DAT LAI", "LO HONG NGHIEM TRONG")
    private val SECURITY_NOTICE = listOf("PLUGIN VUA DUOC KICH HOAT", "DANG NHAP QUAN TRI TU MANG MOI", "TAM KHOA DANG NHAP", "2FA DA BAT", "2FA DA TAT", "2FA MA KHOI PHUC DA", "LO HONG PLUGIN")

    /** Phan tich cac dong MOI cua lamp-run/security-events.log (dinh dang giong admin-audit.log: "YYYY-MM-DD HH:MM:SS ip=<ip> <su kien>"; do
     * security-guard.php / security-scan.php / mu-plugin Shield ghi). Dong khong dung dinh dang hoac su kien la bi bo qua. */
    fun scanSecurityEvents(lines: List<String>): SecuritySummary {
        var urgent = 0
        var notices = 0
        var bans = 0
        val urgentSamples = ArrayList<String>()
        val noticeSamples = ArrayList<String>()
        val re = Regex("""ip=(\S+)\s+(.*)""")
        for (line in lines) {
            val ev = re.find(line)?.groupValues?.get(2) ?: continue
            val clean = ev.filter { it >= ' ' && it != '\u007f' }.take(140)
            when {
                SECURITY_URGENT.any { ev.startsWith(it) } -> { urgent += 1; urgentSamples.add(clean) }
                SECURITY_NOTICE.any { ev.startsWith(it) } -> { notices += 1; noticeSamples.add(clean) }
                ev.startsWith("IP bi tu dong chan") -> bans += 1
            }
        }
        return SecuritySummary(urgent, notices, bans, (urgentSamples + noticeSamples).take(3))
    }

    /** Bao khi co su kien urgent/notice, hoac dot tan cong lon (>= [banThreshold] IP bi chan trong 1 dot doc). */
    fun shouldAlertSecurity(s: SecuritySummary, banThreshold: Int = 20): Boolean =
        s.urgent > 0 || s.notices > 0 || s.autoBans >= banThreshold

    /** Doc cac dong MOI cua [file] ke tu byte [offset]. Tra ve (cac dong, offset
     * moi). Neu file nho hon offset (da bi cat/xoay vong) -> doc lai tu 0. Gioi
     * han toi da [maxBytes] cuoi file moi lan (khong doc ca file khong lo neu bi
     * tan cong dong IP). Dong cuoi chua ket thuc bang '\n' (dang ghi do) KHONG
     * duoc tinh, de lan sau doc lai nguyen ven thay vi cat doi 1 dong. */
    fun readNewLines(file: File, offset: Long, maxBytes: Long = 256L * 1024): Pair<List<String>, Long> {
        if (!file.exists()) return Pair(emptyList(), 0L)
        val len = file.length()
        var start = if (len < offset) 0L else offset
        if (len - start > maxBytes) start = len - maxBytes
        if (len == start) return Pair(emptyList(), len)
        val buf = ByteArray((len - start).toInt())
        RandomAccessFile(file, "r").use {
            it.seek(start)
            it.readFully(buf)
        }
        val text = String(buf, Charsets.UTF_8)
        val lastNl = text.lastIndexOf('\n')
        if (lastNl < 0) return Pair(emptyList(), start) // chua co dong tron ven nao
        val complete = text.substring(0, lastNl)
        val consumedBytes = complete.toByteArray(Charsets.UTF_8).size + 1
        // Neu dot doc bi cat dau (start dich len do maxBytes), dong dau co the
        // cut dau - bo no di.
        val lines = complete.split('\n').let { if (start != offset && start > 0) it.drop(1) else it }
        return Pair(lines.filter { it.isNotBlank() }, start + consumedBytes)
    }

    // ----------------------- Pin (PDF B1) -----------------------

    /** Pin yeu = % pin hop le (>=0) nho hon nguong VA khong dang sac. */
    fun isLowBattery(levelPct: Int, charging: Boolean, thresholdPct: Int = 15): Boolean =
        levelPct in 0 until thresholdPct && !charging

    // ----------------------- 1bc: canh bao MOI TRUONG (PDF "chat luong tinh phi" Q3/Q4/Q5/Q7/R1) -----------------------
    // Nhung dieu kien cua Android/mang ma nguoi van hanh khong thay nhung am tham lam server cham/dut. Giu THUAN (int/boolean)
    // de test JVM khong can android.jar; Monitoring.checkEnvironment doc he thong roi goi ham o day.

    enum class EnvIssue(val cooldownMs: Long) {
        /** Data Saver BAT va app chua duoc cho phep dung du lieu nen -> Android chan mang nen khi tat man hinh => tunnel co the dut. */
        DATA_SAVER(7L * 24 * 3600 * 1000),
        /** VPN dang la mang chinh: cloudflared di qua VPN (cham/dut, IP doi). Thong tin - nhieu nguoi chu y dung VPN nen nhac thua. */
        VPN_ACTIVE(7L * 24 * 3600 * 1000),
        /** Dang chuyen vung (roaming) tren mang di dong: moi request cua khach la cuoc data dat. */
        ROAMING(24L * 3600 * 1000),
        /** Android xep app vao nhom RARE/RESTRICTED: viec nen (health-check, backup, cron) bi tri hoan hang gio. */
        STANDBY_RESTRICTED(7L * 24 * 3600 * 1000),
        /** Pin gan can va KHONG sac: may sap tat nguon dot ngot (MariaDB phai phuc hoi khi khoi dong lai). */
        BATTERY_CRITICAL(6L * 3600 * 1000),
        /** AJ3 (PDF 2): nhiet do pin >= 40 C - nong nhung chua nguy hiem; nhac thoang (2 gio) de nguoi van hanh chinh cach dat/sac may. */
        DEVICE_WARM(2L * 3600 * 1000),
        /** AJ3: nhiet do pin >= 45 C - app tu hoan viec nang (xem wantDeferHeavyJobs / shouldDeferBackupForHeat); nhac moi 30 phut. */
        DEVICE_HOT(30L * 60 * 1000),
    }

    /** ConnectivityManager.RESTRICT_BACKGROUND_STATUS_*: 1 DISABLED, 2 WHITELISTED (app duoc mien), 3 ENABLED (bi chan). -1 = khong ro. */
    const val RESTRICT_BACKGROUND_ENABLED = 3
    /** UsageStatsManager.STANDBY_BUCKET_*: 10 ACTIVE, 20 WORKING_SET, 30 FREQUENT, 40 RARE, 45 RESTRICTED. -1 = khong ro (API < 28). */
    const val STANDBY_BUCKET_RARE = 40
    const val BATTERY_CRITICAL_PCT = 5

    // ----- AJ2/AJ3 (PDF 2, HANDOFF 1bm): nhiet do pin. BatteryManager.EXTRA_TEMPERATURE tinh bang 1/10 do C (365 = 36.5 C). -----
    /** Gia tri "khong doc duoc" (khong lay -1: mot so may bao -1/0 khi loi, va nhiet do am la hop le o vung lanh). */
    const val TEMP_UNKNOWN: Int = Int.MIN_VALUE
    const val TEMP_WARM_TENTHS: Int = 400
    const val TEMP_HOT_TENTHS: Int = 450
    /** Toi da so chu ky backup tu dong bi hoan vi nong LIEN TIEP - qua so nay van chay (may o xu nong thuong xuyen >= 45 C khong duoc
     * "khong bao gio backup": mat du lieu nguy hiem hon mot lan chay hoi nong). */
    const val HEAT_MAX_BACKUP_DEFERRALS: Int = 3

    /** Cam bien tra rac (0, -1, gia tri rat lon) tren mot so may khi loi -> chi tin khoang -30.0 .. 150.0 do C. */
    fun batteryTempKnown(tenths: Int): Boolean = tenths in -300..1500
    /** [warmTenths]/[hotTenths]: nguong do nguoi dung chinh (H5, AlertThresholds); mac dinh = hang so TEMP_*_TENTHS (nguon duy nhat cua gia tri mac dinh: AlertThresholds). */
    fun isWarm(tenths: Int, warmTenths: Int = TEMP_WARM_TENTHS): Boolean = batteryTempKnown(tenths) && tenths >= warmTenths
    fun isHot(tenths: Int, hotTenths: Int = TEMP_HOT_TENTHS): Boolean = batteryTempKnown(tenths) && tenths >= hotTenths

    /** "36.5" (1 chu so thap phan, dau cham co dinh); "?" khi khong doc duoc. */
    fun formatTempC(tenths: Int): String {
        if (!batteryTempKnown(tenths)) return "?"
        val a = if (tenths < 0) -tenths else tenths
        return (if (tenths < 0) "-" else "") + (a / 10) + "." + (a % 10)
    }

    /** Hoan 1 chu ky backup tu dong vi nong, nhung toi da [maxDeferrals] lan lien tiep (xem [HEAT_MAX_BACKUP_DEFERRALS]). */
    fun shouldDeferBackupForHeat(hot: Boolean, consecutiveDeferrals: Int, maxDeferrals: Int = HEAT_MAX_BACKUP_DEFERRALS): Boolean =
        hot && consecutiveDeferrals < maxDeferrals

    data class EnvSnapshot(
        val restrictBackgroundStatus: Int,
        val vpnActive: Boolean,
        val onCellular: Boolean,
        val roaming: Boolean,
        val standbyBucket: Int,
        val batteryPct: Int,
        val charging: Boolean,
        val batteryTempTenthsC: Int = TEMP_UNKNOWN,
    )

    /** Danh sach van de dang xay ra (theo thu tu khai bao cua [EnvIssue]). Gia tri khong ro (-1) KHONG bao dong gia. */
    fun envIssues(e: EnvSnapshot, th: AlertThresholds.Values = AlertThresholds.DEFAULTS): List<EnvIssue> = buildList {
        if (e.restrictBackgroundStatus == RESTRICT_BACKGROUND_ENABLED) add(EnvIssue.DATA_SAVER)
        if (e.vpnActive) add(EnvIssue.VPN_ACTIVE)
        if (e.roaming && e.onCellular) add(EnvIssue.ROAMING)             // roaming chi co nghia khi dang dung mang di dong
        if (e.standbyBucket >= STANDBY_BUCKET_RARE) add(EnvIssue.STANDBY_RESTRICTED)
        if (e.batteryPct in 0..th.batteryCriticalPct && !e.charging) add(EnvIssue.BATTERY_CRITICAL)
        if (isHot(e.batteryTempTenthsC, th.hotTenths)) add(EnvIssue.DEVICE_HOT)          // qua nong thi KHONG bao them "am" (cung 1 nguyen nhan); mac dinh 45 / 40 C
        else if (isWarm(e.batteryTempTenthsC, th.warmTenths)) add(EnvIssue.DEVICE_WARM)
    }

    /** Chong spam theo TUNG van de: chi bao khi chua tung bao (<=0) hoac da qua cooldown cua chinh van de do. */
    fun shouldAlertEnv(issue: EnvIssue, lastAlertAtMs: Long, nowMs: Long): Boolean =
        lastAlertAtMs <= 0L || nowMs - lastAlertAtMs >= issue.cooldownMs

    // ----------------------- B6: viec nang chi khi sac -----------------------

    /** BatteryManager: BATTERY_STATUS_CHARGING=2, BATTERY_STATUS_FULL=5; EXTRA_PLUGGED>0
     * (AC=1, USB=2, khong day=4) nghia la dang cam nguon. Dung EXTRA_PLUGGED la chinh vi
     * may dang cam sac van co the bao DISCHARGING/NOT_CHARGING khi qua nong. Giu thuan
     * (int) de test JVM khong can android.jar. */
    fun isCharging(status: Int, plugged: Int): Boolean = plugged > 0 || status == 2 || status == 5

    /** Co "hoan viec nang" can BAT khi nguoi dung bat tuy chon VA may khong sac. */
    fun wantDeferHeavyJobs(optionEnabled: Boolean, charging: Boolean, hot: Boolean = false): Boolean =
        (optionEnabled && !charging) || hot

    /**
     * Dong bo file co voi trang thai mong muon. Bat: tao file VA cap nhat mtime moi lan goi
     * (phia PHP coi co co mtime cu hon ~2 gio la HET HIEU LUC - neu app chet/khong cap nhat
     * duoc thi viec nang tu chay lai thay vi bi hoan vo han, "fail-open"). Tat: xoa file.
     * Tra ve true neu file ton tai sau khi dong bo.
     */
    fun syncFlagFile(flag: File, want: Boolean, nowMs: Long): Boolean {
        if (want) {
            flag.parentFile?.mkdirs()
            if (!flag.exists()) flag.writeText("1")
            flag.setLastModified(nowMs)
            return flag.exists()
        }
        if (flag.exists()) flag.delete()
        return flag.exists()
    }

    // ----------------------- H4: ty le uptime 24h/7d/30d (PDF 2 muc H4) -----------------------

    /** 1 lan tu-kiem-tra: [tsSec] = giay epoch, [up] = website CO TRA LOI (bat ky ma HTTP nao, giong HealthCheckWorker) -
     * hoac dich vu bi he dieu hanh giet trong luc nguoi dung van muon chay (tinh la "xuong"). */
    data class UptimeSample(val tsSec: Long, val up: Boolean)

    /** Thong ke 1 cua so thoi gian. */
    data class UptimeStats(val samples: Int, val upCount: Int) {
        /** % mau "len"; null neu chua co mau nao (khong bao "100%" khi chua co du lieu). */
        val percent: Double? get() = if (samples == 0) null else upCount * 100.0 / samples
    }

    const val UPTIME_KEEP_SEC: Long = 30L * 24 * 3600
    /** 30 ngay x 96 mau/ngay (moi 15 phut) = 2880; du dia cho lan kiem tra thua. */
    const val UPTIME_MAX_SAMPLES: Int = 4000

    /** Doc file uptime.csv (moi dong "epoch_giay,1|0"); dong hong bi BO QUA chu khong lam hong ca file. */
    fun parseUptimeCsv(text: String): List<UptimeSample> {
        val out = ArrayList<UptimeSample>()
        for (line in text.lineSequence()) {
            val parts = line.trim().split(',')
            if (parts.size != 2) continue
            val ts = parts[0].trim().toLongOrNull() ?: continue
            val flag = parts[1].trim()
            if (flag != "0" && flag != "1") continue
            out.add(UptimeSample(ts, flag == "1"))
        }
        return out
    }

    fun formatUptimeCsv(samples: List<UptimeSample>): String =
        samples.joinToString("") { (if (it.up) "${it.tsSec},1" else "${it.tsSec},0") + "\n" }

    /**
     * Them 1 mau, bo mau cu hon [keepSec], giu toi da [maxSamples] mau MOI NHAT. Mau co moc o TUONG LAI (dong ho may bi
     * chinh lui) bi bo - neu khong chung nam trong moi cua so va bop meo ti le.
     */
    fun appendUptimeSample(
        existing: List<UptimeSample>, nowSec: Long, up: Boolean,
        keepSec: Long = UPTIME_KEEP_SEC, maxSamples: Int = UPTIME_MAX_SAMPLES
    ): List<UptimeSample> {
        val all = existing.filter { it.tsSec <= nowSec && nowSec - it.tsSec <= keepSec } + UptimeSample(nowSec, up)
        return if (all.size > maxSamples) all.takeLast(maxSamples) else all
    }

    /** Dem mau trong [nowSec - windowSec, nowSec]. */
    fun uptimeStats(samples: List<UptimeSample>, nowSec: Long, windowSec: Long): UptimeStats {
        var n = 0
        var u = 0
        for (s in samples) {
            if (s.tsSec > nowSec || nowSec - s.tsSec > windowSec) continue
            n++
            if (s.up) u++
        }
        return UptimeStats(n, u)
    }

    /** "24 gio: 99.1% (95/96 lan kiem tra)" hoac "24 gio: chua co du lieu". Lam tron 1 chu so, dau cham thap phan co dinh. */
    fun formatUptimeLine(label: String, st: UptimeStats): String {
        val p = st.percent ?: return "$label: chua co du lieu"
        return "$label: ${Math.round(p * 10.0) / 10.0}% (${st.upCount}/${st.samples} lan kiem tra)"
    }

    // ----------------------- T2: webhook canh bao RA NGOAI (PDF 2 muc T2; HANDOFF 1bl) -----------------------

    /** Ten su kien gui ra webhook (Zapier/Make/n8n loc theo truong "event"). Ten la -> "unknown" (khong bao gio gui chuoi tuy y vao truong nay). */
    val ALERT_EVENTS: Set<String> = setOf("site_down", "backup_ok", "backup_failed", "backup_verify_failed")

    /** Toi da so ky tu cua truong "text" (cat o ranh gioi ky tu, khong de dut doi cap thay the UTF-16). */
    const val ALERT_TEXT_MAX: Int = 1000

    /** Escape chuoi theo JSON (RFC 8259): dau nhay kep, gach cheo nguoc, ky tu dieu khien < 0x20 -> \\u00XX; ky tu khac giu nguyen (gui UTF-8). */
    fun jsonEscape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append("\\u").append(String.format("%04x", c.code))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** Than JSON gui webhook: {"app":"wp-pocket-server","event":"site_down","ts":<giay epoch>,"text":"..."} - LUON la JSON hop le. */
    fun buildAlertJson(event: String, text: String, tsSec: Long): String {
        val ev = if (event in ALERT_EVENTS) event else "unknown"
        var t = if (text.length > ALERT_TEXT_MAX) text.substring(0, ALERT_TEXT_MAX) else text
        if (t.isNotEmpty() && t.last().isHighSurrogate()) t = t.dropLast(1)
        return "{\"app\":\"wp-pocket-server\",\"event\":\"$ev\",\"ts\":$tsSec,\"text\":\"${jsonEscape(t)}\"}"
    }
}
