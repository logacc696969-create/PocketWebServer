package com.wppocket.server

/**
 * Ho so hieu nang PHP chon trong app (PDF 2 muc R15-R18; HANDOFF.md muc 1bp). Chi gia tri hang so (khong Android) de test duoc.
 * Cac con so PHAI khop khoi `case` trong start-lamp.sh (php_profile_values) - scripts/tests/php-tuning-test.py doi chieu ca hai.
 * Mac dinh 0 = khong doi gi so voi truoc day (128 MB / 60 giay / 32 MB). Ho so 1-2 dung NHIEU RAM hon (toi da 3 tien trinh PHP
 * x memory_limit), chi nen bat khi site that su can.
 */
object PhpTuning {
    class Profile(val id: Int, val memoryMb: Int, val execSeconds: Int, val uploadMb: Int)

    val PROFILES: List<Profile> = listOf(
        Profile(0, 128, 60, 32),
        Profile(1, 256, 120, 64),
        Profile(2, 192, 300, 128)
    )

    /** Gia tri la (hong prefs...) -> 0 (mac dinh an toan). */
    fun clamp(id: Int): Int = if (id in 0..2) id else 0
}
