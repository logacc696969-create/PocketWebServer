package com.wppocket.server

import android.content.Context
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL

/**
 * T2 (PDF 2, HANDOFF.md muc 1bl): gui su kien canh bao DANG JSON toi 1 URL do nguoi dung tu cau hinh (Zapier / Make / n8n / Discord...),
 * song song voi Telegram. Khac [WebhookUploader] (gui FILE backup multipart). Chi 3 su kien (xem MonitorLogic.ALERT_EVENTS):
 * site_down (website khong phan hoi lien tiep), backup_ok, backup_failed. Than JSON do MonitorLogic.buildAlertJson dung (co test JVM).
 *
 * QUY UOC: goi tu luong worker (co mang), KHONG goi tren main thread. NUOT moi loi - 1 canh bao hong khong duoc lam hong worker goi no.
 * KHONG ghi message loi vao log (co the chua URL, ma URL webhook thuong la bi mat) - chi ten lop loi.
 * Rieng tu: noi dung gui chi la cau canh bao + ten file backup (khong co mat khau, token hay URL tunnel); URL webhook nam trong
 * SharedPreferences cua app (private) giong Bot Token.
 */
object AlertWebhook {
    private const val TAG = "AlertWebhook"

    fun isConfigured(url: String?): Boolean = WebhookUploader.isConfigured(url)

    /** Gui 1 su kien neu da cau hinh URL. Tra ve true khi server tra 2xx; false khi chua cau hinh / that bai. */
    fun notify(context: Context, event: String, text: String): Boolean {
        val raw = SecretStore.get(context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE), Prefs.KEY_ALERT_WEBHOOK_URL, null)
        val target = raw?.trim().orEmpty()
        if (!isConfigured(target)) return false
        return try {
            val body = MonitorLogic.buildAlertJson(event, text, System.currentTimeMillis() / 1000).toByteArray(Charsets.UTF_8)
            val conn = (URL(target).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 10_000
                readTimeout = 15_000
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setFixedLengthStreamingMode(body.size)
            }
            conn.outputStream.use { it.write(body) }
            val ok = conn.responseCode in 200..299
            if (!ok) Log.w(TAG, "Webhook canh bao tra ve ma ${conn.responseCode}")
            conn.disconnect()
            ok
        } catch (e: Exception) {
            Log.w(TAG, "Gui webhook canh bao loi: ${e.javaClass.simpleName}")
            false
        }
    }
}
