package com.wppocket.server

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Backup tu dong dinh ky - de xuat tu PDF "He thong Backup tu dong va Cloud
 * Sync" (xem HANDOFF.md muc 1e). Chay logic giong het nut "Backup ngay"
 * (dung chung BackupManager), khac o cho: chay dinh ky khong can mo app +
 * gui file qua Telegram Bot neu nguoi dung da cau hinh (xem TelegramNotifier).
 *
 * GIOI HAN THAT (khac PDF de xuat "chay dung 3 gio sang"): WorkManager tren
 * Android KHONG ho tro lich theo GIO CU THE trong ngay - chi ho tro
 * "moi N tieng ke tu luc dang ky" (PeriodicWorkRequest), va thoi diem chay
 * thuc te co the tre vai phut den vai chuc phut tuy Doze mode cua may. Day
 * la gioi han cua chinh API Android, khong phai chua lam dung.
 */
class BackupWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        return try {
            val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
            // J5 (1bn): "Backup ngay" tu phim tat man hinh chinh -> nguoi dung CHU DONG yeu cau nen KHONG hoan vi RAM thap / may nong
            // (cac nhanh hoan o duoi chi danh cho chu ky TU DONG).
            val manual = inputData.getBoolean(KEY_MANUAL, false)

            // De xuat DeepSeek muc B5 (xem HANDOFF.md muc 10 + muc 1aq) - neu
            // he thong VUA bao RAM thap (xem
            // ServerForegroundService.onTrimMemory()), hoan 1 chu ky backup -
            // tra ve success() (KHONG PHAI retry()/failure()) de WorkManager
            // coi day la "da lam xong binh thuong", tu nhien cho chu ky DINH
            // KY tiep theo chay, khong tao vong lap retry don don them tai.
            if (!manual && Prefs.isUnderMemoryPressure(applicationContext)) {
                Log.w("BackupWorker", "May dang thieu RAM (canh bao gan day) - hoan backup dinh ky sang chu ky sau")
                return Result.success()
            }

            // AJ3 (1bm): may >= 45 C -> hoan chu ky backup nay (nen/zip/ma hoa/mysqldump deu ton CPU, lam may nong them) NHUNG toi da
            // HEAT_MAX_BACKUP_DEFERRALS lan lien tiep de may nong thuong xuyen khong bao gio backup. Tra success() nhu nhanh RAM thap o tren.
            val heatDeferred = prefs.getInt(Prefs.KEY_HEAT_DEFER_COUNT, 0)
            if (!manual && MonitorLogic.shouldDeferBackupForHeat(MonitorLogic.isHot(Monitoring.batteryTempTenths(applicationContext), Monitoring.thresholds(applicationContext).hotTenths), heatDeferred)) {
                prefs.edit().putInt(Prefs.KEY_HEAT_DEFER_COUNT, heatDeferred + 1).apply()
                Log.w("BackupWorker", "May dang nong >= 45 C - hoan backup dinh ky (lan ${heatDeferred + 1}/${MonitorLogic.HEAT_MAX_BACKUP_DEFERRALS})")
                return Result.success()
            }
            if (heatDeferred != 0) prefs.edit().putInt(Prefs.KEY_HEAT_DEFER_COUNT, 0).apply()

            // De xuat DeepSeek muc F6 (xem HANDOFF.md muc 10) - doc PREFS
            // TRUOC khi goi performBackup() (khac thu tu cu, doc prefs SAU),
            // vi can passphrase de truyen vao ngay tu dau neu da bat ma hoa.
            val effectivePassphrase = BackupManager.effectivePassphrase(applicationContext)

            val result = BackupManager.performBackup(applicationContext, effectivePassphrase)

            val dbNote = if (result.dbDumped) "kem database" else "chi co file website, chua co database"
            val encNote = if (result.encrypted) ", DA MA HOA - can mat khau da dat de mo lai" else ""
            val caption = "WP Pocket Server - backup ${if (manual) "thu cong (phim tat)" else "tu dong"}: ${result.file.name} ($dbNote$encNote)"

            val botToken = SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
            val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
            val tgConfigured = TelegramNotifier.isConfigured(botToken, chatId)
            val tgOk = if (tgConfigured) TelegramNotifier.sendDocument(botToken!!, chatId!!, result.file, caption) else true

            val webhookUrl = SecretStore.get(prefs, Prefs.KEY_BACKUP_WEBHOOK_URL, null)
            val whConfigured = WebhookUploader.isConfigured(webhookUrl)
            val whOk = if (whConfigured) WebhookUploader.uploadFile(webhookUrl!!, result.file) else true

            // HANDOFF 1bo-F: truoc day ket qua gui BI BO QUA va luon bao "backup_ok" - ban sao ngoai may khong ton tai ma khong ai biet.
            val failNote = UploadLogic.failureNote(tgConfigured, tgOk, whConfigured, whOk, result.file.length())
            if (failNote == null) {
                AlertWebhook.notify(applicationContext, "backup_ok", caption)   // T2 (1bl): bao cho webhook canh bao (neu da cau hinh)
            } else {
                Log.w("BackupWorker", failNote)
                if (tgConfigured) TelegramNotifier.sendMessage(botToken!!, chatId!!, "WP Pocket Server - $failNote")
                AlertWebhook.notify(applicationContext, "backup_failed", "WP Pocket Server - $failNote")
            }
            Result.success()
        } catch (e: Exception) {
            Log.e("BackupWorker", "Backup tu dong that bai, se thu lai", e)
            // Bao cho nguoi dung biet NGAY thay vi de ho tu nhan ra "sao lau
            // khong thay tin nhan backup" (de xuat DeepSeek muc A2/A3, xem
            // HANDOFF.md muc 10: khong de loi bi nuot am tham). Chi bao 1 tin
            // nhan ngan, khong kem file (khac nhanh thanh cong o tren) - neu
            // WorkManager retry roi thanh cong, tin nhan thanh cong binh
            // thuong se tu gui, khong can noi lai "da het loi".
            try {
                val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
                val botToken = SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
                val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
                if (TelegramNotifier.isConfigured(botToken, chatId)) {
                    TelegramNotifier.sendMessage(
                        botToken!!, chatId!!,
                        "WP Pocket Server - backup tu dong THAT BAI: ${e.message}. Se tu thu lai."
                    )
                }
                AlertWebhook.notify(applicationContext, "backup_failed", "WP Pocket Server - backup tu dong THAT BAI: ${e.message}. Se tu thu lai.")
            } catch (_: Exception) {
                // Gui canh bao that bai cung khong duoc (vd mat mang) - khong
                // lam gi them, ban than viec backup that bai da duoc log +
                // WorkManager se tu retry, khong de 1 loi phu lam mat ca ket
                // qua chinh (Result.retry() van phai tra ve o duoi).
            }
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE_NAME = "wp_pocket_auto_backup"
        private const val UNIQUE_NOW = "wp_pocket_backup_now"
        const val KEY_MANUAL = "manual"

        /** Chay 1 backup NGAY qua WorkManager (song sot khi tien trinh bi giet, khong gan voi vong doi Activity) - dung cho phim tat man hinh chinh. */
        fun runNow(context: Context) {
            val request = androidx.work.OneTimeWorkRequestBuilder<BackupWorker>()
                .setInputData(androidx.work.workDataOf(KEY_MANUAL to true))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE_NOW, androidx.work.ExistingWorkPolicy.KEEP, request)
        }

        /** Dang ky (hoac cap nhat lich neu da dang ky) backup dinh ky moi
         * intervalHours tieng. Goi lai ham nay bat ky luc nao nguoi dung doi
         * gia tri trong app - ExistingPeriodicWorkPolicy.UPDATE se ap dung
         * lich moi ma khong mat lich su cong viec cu.
         *
         * requireCharging (de xuat DeepSeek muc B1/B6, xem HANDOFF.md muc 10):
         * mac dinh false - GIU NGUYEN hanh vi tu truoc (khong doi hanh vi cu
         * cho nguoi dung da dung tinh nang backup tu dong tu truoc ban nay).
         * Nguoi dung tu bat qua 1 cong tac rieng trong app neu muon uu tien
         * an toan pin/on dinh hon la "chac chan co backup dung gio". */
        fun schedule(context: Context, intervalHours: Long, requireCharging: Boolean = false) {
            val safeInterval = intervalHours.coerceAtLeast(1L)
            val constraints = Constraints.Builder()
                // Uu tien chay luc pin khong yeu - giam rui ro backup dot ngung
                // giua chung lam hong file zip.
                .setRequiresBatteryNotLow(true)
                // Tuy chon rieng, TAT theo mac dinh - xem chu thich requireCharging
                // o tren va Prefs.KEY_BACKUP_REQUIRE_CHARGING. Neu may khong bao
                // gio duoc cam sac luc chay server, bat co nay dong nghia KHONG
                // BAO GIO backup tu dong duoc - nguoi dung PHAI tu y thuc duoc
                // danh doi nay truoc khi bat (xem checkbox trong MainActivity).
                .setRequiresCharging(requireCharging)
                .build()
            val request = PeriodicWorkRequestBuilder<BackupWorker>(safeInterval, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
        }
    }
}
