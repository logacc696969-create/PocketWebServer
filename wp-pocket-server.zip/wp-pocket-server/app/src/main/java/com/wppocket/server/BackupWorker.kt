package com.wppocket.server

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Backup tu dong dinh ky - de xuat tu PDF "He thong Backup tu dong va Cloud
 * Sync" (xem HANDOFF.md muc 1e). Chay logic giong het nut "Backup ngay"
 * (dung chung BackupManager), khac o cho: chay dinh ky khong can mo app +
 * gui file qua Telegram Bot neu nguoi dung da cau hinh (xem TelegramNotifier).
 *
 * GIOI HAN THAT (khac PDF de xuat "chay dung 3 gio sang"): WorkManager tren
 * Android KHONG ho tro lich theo GIO CU THE trong ngay - chi ho tro
 * "moi N tieng ke tu luc dang ky" (PeriodicWorkRequest), va thoi diem chay
 * thuc te co the tre vai phut den vai chuc phut tuy Doze mode cua may. Day
 * la gioi han cua chinh API Android, khong phai chua lam dung.
 */
class BackupWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        return try {
            val result = BackupManager.performBackup(applicationContext)
            val prefs = applicationContext.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)

            val dbNote = if (result.dbDumped) "kem database" else "chi co file website, chua co database"
            val caption = "WP Pocket Server - backup tu dong: ${result.file.name} ($dbNote)"

            val botToken = prefs.getString(Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
            val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
            if (TelegramNotifier.isConfigured(botToken, chatId)) {
                TelegramNotifier.sendDocument(botToken!!, chatId!!, result.file, caption)
            }

            val webhookUrl = prefs.getString(Prefs.KEY_BACKUP_WEBHOOK_URL, null)
            if (WebhookUploader.isConfigured(webhookUrl)) {
                WebhookUploader.uploadFile(webhookUrl!!, result.file)
            }
            Result.success()
        } catch (e: Exception) {
            Log.e("BackupWorker", "Backup tu dong that bai, se thu lai", e)
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE_NAME = "wp_pocket_auto_backup"

        /** Dang ky (hoac cap nhat lich neu da dang ky) backup dinh ky moi
         * intervalHours tieng. Goi lai ham nay bat ky luc nao nguoi dung doi
         * gia tri trong app - ExistingPeriodicWorkPolicy.UPDATE se ap dung
         * lich moi ma khong mat lich su cong viec cu. */
        fun schedule(context: Context, intervalHours: Long) {
            val safeInterval = intervalHours.coerceAtLeast(1L)
            val constraints = Constraints.Builder()
                // Uu tien chay luc pin khong yeu - giam rui ro backup dot ngung
                // giua chung lam hong file zip. KHONG bat setRequiresCharging vi
                // dien thoai lam server co the khong luon cam sac, se khien
                // backup khong bao gio chay duoc neu bat buoc.
                .setRequiresBatteryNotLow(true)
                .build()
            val request = PeriodicWorkRequestBuilder<BackupWorker>(safeInterval, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
        }
    }
}
