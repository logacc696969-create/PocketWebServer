package com.wppocket.server

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val autoStart = prefs.getBoolean(Prefs.KEY_AUTO_START, false)
        if (!autoStart) return

        val serviceIntent = Intent(context, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_START
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
