package com.wppocket.server

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        // AJ4 (1bm): che do chuyen dung LUON khoi dong cung may, ke ca khi nguoi dung bo tich "tu khoi dong" sau do.
        val autoStart = prefs.getBoolean(Prefs.KEY_AUTO_START, false) || prefs.getBoolean(Prefs.KEY_DEDICATED_MODE, false)
        if (!autoStart) return

        val serviceIntent = Intent(context, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_START
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
