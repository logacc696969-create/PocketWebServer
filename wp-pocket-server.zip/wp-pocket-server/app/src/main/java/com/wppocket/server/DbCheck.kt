package com.wppocket.server

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit

/** Chay kiem tra CSDL bang libmysqlcli.so (R12, HANDOFF.md muc 1bp). Phan phan tich nam o DbCheckLogic (test duoc). */
object DbCheck {
    class RunResult(val outcome: DbCheckLogic.Outcome?, val reason: String?)   // reason: "no_server" | "failed"

    fun run(context: Context): RunResult {
        val sock = File(context.filesDir, "lamp-run/mysql.sock")
        val cli = File(context.applicationInfo.nativeLibraryDir, "libmysqlcli.so")
        if (!sock.exists() || !cli.exists()) return RunResult(null, "no_server")
        val db = BackupManager.dbName(context)
        val listed = exec(context, cli, sock, DbCheckLogic.listTablesSql(db)) ?: return RunResult(null, "failed")
        if (listed.first != 0) return RunResult(null, "failed")
        val tables = DbCheckLogic.parseTableList(listed.second)
        if (tables.isEmpty()) return RunResult(DbCheckLogic.Outcome(0, 0, 0, emptyList(), 0), null)
        val checked = exec(context, cli, sock, DbCheckLogic.checkSql(db, tables)) ?: return RunResult(null, "failed")
        val outcome = DbCheckLogic.parseCheck(checked.second)
        return if (outcome.parsedRows == 0) RunResult(null, "failed") else RunResult(outcome, null)
    }

    /** Tra ve (ma thoat, stdout) hoac null neu loi/qua 120 giay. SQL di qua stdin - cung khuon BackupManager (compat-libs). */
    private fun exec(context: Context, cli: File, sock: File, sql: String): Pair<Int, String>? {
        return try {
            val pb = ProcessBuilder(cli.absolutePath, "--socket=${sock.absolutePath}", "-uroot", "-N", "-B", "-f")
            val compatDir = File(context.filesDir, "lamp-run/compat-libs")
            pb.environment()["LD_LIBRARY_PATH"] = "${compatDir.absolutePath}:${context.applicationInfo.nativeLibraryDir}"
            val proc = pb.start()
            proc.outputStream.use { it.write(sql.toByteArray(Charsets.UTF_8)) }
            val out = StringBuilder()
            val outReader = Thread {
                try { proc.inputStream.bufferedReader().use { out.append(it.readText()) } } catch (_: Exception) {}
            }
            val errDrain = Thread {
                try { proc.errorStream.use { s -> val b = ByteArray(4096); while (s.read(b) >= 0) { } } } catch (_: Exception) {}
            }
            outReader.start()
            errDrain.start()
            if (!proc.waitFor(120, TimeUnit.SECONDS)) { proc.destroyForcibly(); return null }
            outReader.join(5000)
            Pair(proc.exitValue(), out.toString())
        } catch (_: Exception) { null }
    }
}
