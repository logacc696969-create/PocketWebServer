package com.wppocket.server

import android.content.Context
import android.os.StatFs
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Logic backup (zip thu muc www/ + mysqldump database neu dang chay MariaDB
 * that) - tach rieng khoi MainActivity de dung CHUNG duoc cho ca 2 noi goi:
 *
 *  1) Nut "Backup ngay" trong MainActivity (bam tay).
 *  2) BackupWorker (WorkManager, chay dinh ky tu dong).
 *
 * De xuat tu PDF "He thong Backup tu dong va Cloud Sync" (xem HANDOFF.md
 * muc 1e). Truoc ban nay, logic nay nam thang trong MainActivity va CHI co
 * o dang bam tay - gio tach ra de tai su dung, khong doi hanh vi backup tay
 * (van zip + dump y het cu), chi them phan don dep ban cu (xem
 * cleanupOldBackups) vi backup TU DONG chay dinh ky se nhanh chong lam day
 * bo nho dien thoai neu khong ai xoa bot - dien thoai khong co dung luong
 * lon nhu server that.
 */
object BackupManager {

    /** Giu lai toi da bao nhieu ban backup gan nhat - ap dung cho CA backup
     * tay lan tu dong, ban cu hon se tu xoa sau moi lan backup moi thanh
     * cong. Dien thoai khong co dung luong lon nhu VPS/server that nen can
     * gioi han nay, khac voi hanh vi cu (giu mai khong xoa). */
    private const val KEEP_BACKUPS = 5

    class BackupException(message: String, cause: Throwable? = null) : Exception(message, cause)

    data class BackupResult(val file: File, val dbDumped: Boolean)

    /** Uoc tinh dung luong (byte) cua 1 thu muc bang cach cong don kich thuoc
     * tung file - dung de so sanh voi dung luong trong con truoc khi backup
     * (xem checkEnoughDiskSpace). Chi la UOC LUONG (chua tinh nen zip lam
     * nho lai, hoac file dump SQL them vao) - co chu ky an toan (buffer x2)
     * o noi goi de bu lai. */
    private fun estimateDirSize(dir: File): Long {
        if (!dir.exists()) return 0L
        var total = 0L
        dir.listFiles()?.forEach { f ->
            total += if (f.isDirectory) estimateDirSize(f) else f.length()
        }
        return total
    }

    /** Kiem tra dung luong trong TRUOC khi backup (xem HANDOFF.md muc 10, de
     * xuat DeepSeek muc F7). Truoc day KHONG kiem tra gi ca - neu may gan
     * day bo nho, qua trinh zip/dump co the THAT BAI GIUA CHUNG, de lai 1
     * file zip CUT (khong mo duoc, hoac mo duoc nhung thieu du lieu) ma
     * nguoi dung tuong la 1 ban backup binh thuong cho toi luc can khoi
     * phuc moi phat hien ra hong - luc do thi da qua muon. Dung he so an
     * toan x2 (nhan doi uoc luong) vi zip nen it, dump SQL them vao, va de
     * du cho THAO TAC KHAC dang dien ra dong thoi tren may (khong the biet
     * truoc chinh xac). */
    private fun checkEnoughDiskSpace(context: Context, filesDir: File, outDir: File) {
        val estimated = estimateDirSize(File(filesDir, "www"))
        val needed = (estimated * 2).coerceAtLeast(10L * 1024 * 1024) // toi thieu 10MB du cho site rong/moi
        val stat = StatFs(outDir.absolutePath)
        val available = stat.availableBytes
        if (available < needed) {
            val neededMb = needed / (1024 * 1024)
            val availableMb = available / (1024 * 1024)
            throw BackupException(
                "Khong du dung luong trong de backup an toan (can khoang ${neededMb}MB, " +
                    "may con trong ${availableMb}MB) - xoa bot du lieu roi thu lai."
            )
        }
    }

    /** Zip thu muc www/ (+ dump database neu co the) ra file zip moi trong
     * Android/data/<package>/files/backups/. Chay tren luong hien tai - noi
     * goi (MainActivity, BackupWorker) tu lo viec chay o background thread. */
    fun performBackup(context: Context): BackupResult {
        val outDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val outZip = File(outDir, "backup-$stamp.zip")

        val filesDir = context.filesDir
        checkEnoughDiskSpace(context, filesDir, outDir)
        val mysqlSock = File(filesDir, "lamp-run/mysql.sock")
        val mysqldumpBin = File(context.applicationInfo.nativeLibraryDir, "libmysqldump.so")
        val dumpFile = File(context.cacheDir, "backup-dump-$stamp.sql")
        var dumped = false

        if (mysqlSock.exists() && mysqldumpBin.exists()) {
            try {
                val pb = ProcessBuilder(
                    mysqldumpBin.absolutePath,
                    "--socket=${mysqlSock.absolutePath}", "-uroot",
                    // --single-transaction: chup 1 "anh chup" nhat quan cua du
                    // lieu InnoDB ma KHONG khoa bang (theo dung de xuat DeepSeek
                    // muc O4, xem HANDOFF.md muc 2). Neu khong co co nay,
                    // mysqldump se khoa doc toan bo bang trong luc dump - voi
                    // site dang co khach truy cap dong thoi, co the gay dung
                    // hinh vai giay/vai chuc giay, va neu co ghi du lieu xen
                    // giua luc dump, ban backup co the KHONG NHAT QUAN (post co
                    // nhung meta chua kip ghi). --quick: doc tung dong thay vi
                    // nap ca bang vao RAM truoc (quan trong tren dien thoai RAM
                    // han che). --lock-tables=false: khong can khoa kieu
                    // MyISAM cu, tranh xung dot voi --single-transaction.
                    "--single-transaction", "--quick", "--lock-tables=false",
                    "--databases", "wordpress"
                )
                val env = pb.environment()
                // SUA LOI THAT (xem HANDOFF.md muc 2): truoc day CHI set
                // LD_LIBRARY_PATH = nativeLibraryDir, THIEU thu muc
                // "compat-libs" (xem HANDOFF.md muc 1u/1v) - mysqldump la
                // binary ELF that, RAT CO THE can cung cac thu vien SONAME
                // (libz.so.1, libssl.so.X...) nhu mariadbd/php-fpm da tung
                // thieu. Khong co compat-libs, mysqldump co the CHET NGAY khi
                // thuc thi (linker bao "library X not found") - loi nay bi
                // nuot am tham boi catch(Exception) ben duoi, hien thi y het
                // truong hop binh thuong "khong co mariadb" - nghia la backup
                // CSDL co the DA TUNG am tham that bai ngay ca khi MariaDB
                // dang chay binh thuong, ma khong ai biet. Dung DUNG 1 bien
                // COMPAT_DIR thay vi tinh lai duong dan de tranh 2 noi lech
                // nhau ve sau (start-lamp.sh dinh nghia goc).
                val compatDir = File(filesDir, "lamp-run/compat-libs")
                env["LD_LIBRARY_PATH"] = "${compatDir.absolutePath}:${context.applicationInfo.nativeLibraryDir}"
                pb.redirectOutput(dumpFile)
                pb.redirectErrorStream(false)
                val process = pb.start()
                process.waitFor()
                dumped = dumpFile.exists() && dumpFile.length() > 0
            } catch (_: Exception) {
                // khong co mariadb (vd runtime=node/python) - bo qua, van backup file website
            }
        }

        try {
            ZipOutputStream(FileOutputStream(outZip)).use { zos ->
                val wwwDir = File(filesDir, "www")
                if (wwwDir.exists()) zipDir(wwwDir, "www", zos)
                if (dumped) {
                    zos.putNextEntry(ZipEntry("database.sql"))
                    dumpFile.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        } catch (e: Exception) {
            outZip.delete()
            throw BackupException("Khong tao duoc file zip backup", e)
        } finally {
            dumpFile.delete()
        }

        cleanupOldBackups(outDir)

        return BackupResult(outZip, dumped)
    }

    private fun zipDir(dir: File, base: String, zos: ZipOutputStream) {
        dir.listFiles()?.forEach { f ->
            val entryName = "$base/${f.name}"
            if (f.isDirectory) {
                zipDir(f, entryName, zos)
            } else {
                zos.putNextEntry(ZipEntry(entryName))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun cleanupOldBackups(dir: File) {
        val files = dir.listFiles { f -> f.isFile && f.name.startsWith("backup-") && f.name.endsWith(".zip") }
            ?.sortedByDescending { it.lastModified() }
            ?: return
        if (files.size > KEEP_BACKUPS) {
            files.drop(KEEP_BACKUPS).forEach { it.delete() }
        }
    }

    class RestoreException(message: String, cause: Throwable? = null) : Exception(message, cause)

    data class RestoreResult(val filesRestored: Int, val dbRestored: Boolean, val dbAttempted: Boolean)

    /** Liet ke cac ban backup hien co (Android/data/<package>/files/backups/),
     * moi nhat truoc. Dung cho UI chon file de khoi phuc. */
    fun listBackups(context: Context): List<File> {
        val dir = File(context.getExternalFilesDir(null), "backups")
        return dir.listFiles { f -> f.isFile && f.name.startsWith("backup-") && f.name.endsWith(".zip") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    /**
     * Khoi phuc file website (www/) + database (neu ban backup co dump) tu 1
     * file zip do performBackup() tao ra. GHI DE truc tiep len du lieu hien
     * tai - noi GOI (MainActivity) phai tu canh bao nguoi dung day la hanh
     * dong KHONG THE HOAN TAC truoc khi goi ham nay, va nen dung server
     * truoc khi khoi phuc de tranh ghi de file dang duoc nginx/php-fpm doc
     * dung luc (khong fatal neu quen dung, nhung an toan hon neu dung truoc).
     *
     * Neu ban backup co "database.sql" nhung MariaDB khong dang chay (vd
     * runtime khac PHP, hoac server dang dung), phan file van duoc khoi phuc
     * binh thuong - chi rieng phan database bi bo qua (dbAttempted=false),
     * KHONG coi la loi toan bo qua trinh.
     */
    fun performRestore(context: Context, backupZip: File): RestoreResult {
        val filesDir = context.filesDir
        val wwwDir = File(filesDir, "www")
        var filesRestored = 0
        var dbSqlTemp: File? = null

        try {
            java.util.zip.ZipInputStream(backupZip.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    when {
                        entry.name == "database.sql" -> {
                            val tmp = File(context.cacheDir, "restore-dump-${System.currentTimeMillis()}.sql")
                            FileOutputStream(tmp).use { out -> zis.copyTo(out) }
                            dbSqlTemp = tmp
                        }
                        entry.name.startsWith("www/") && !entry.isDirectory -> {
                            val relativePath = entry.name.removePrefix("www/")
                            if (relativePath.isNotEmpty()) {
                                val destFile = File(wwwDir, relativePath)
                                destFile.parentFile?.mkdirs()
                                FileOutputStream(destFile).use { out -> zis.copyTo(out) }
                                filesRestored++
                            }
                        }
                        // Entry nao khac (vd thu muc rong) - bo qua, khong can xu ly.
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        } catch (e: Exception) {
            throw RestoreException("Khong doc duoc file backup (co the file bi hong)", e)
        }

        val sqlFile = dbSqlTemp
        var dbAttempted = false
        var dbRestored = false
        if (sqlFile != null && sqlFile.exists() && sqlFile.length() > 0) {
            val mysqlSock = File(filesDir, "lamp-run/mysql.sock")
            val mysqlCliBin = File(context.applicationInfo.nativeLibraryDir, "libmysqlcli.so")
            if (mysqlSock.exists() && mysqlCliBin.exists()) {
                dbAttempted = true
                try {
                    val pb = ProcessBuilder(
                        mysqlCliBin.absolutePath,
                        "--socket=${mysqlSock.absolutePath}", "-uroot"
                    )
                    // Cung loi/cung fix nhu mysqldump o performBackup() phia
                    // tren (xem chu thich day du o do) - mysqlCliBin cung la
                    // binary ELF that, can compat-libs de tim dung thu vien
                    // SONAME luc chay.
                    val compatDir = File(filesDir, "lamp-run/compat-libs")
                    pb.environment()["LD_LIBRARY_PATH"] = "${compatDir.absolutePath}:${context.applicationInfo.nativeLibraryDir}"
                    pb.redirectInput(sqlFile)
                    val proc = pb.start()
                    dbRestored = proc.waitFor() == 0
                } catch (_: Exception) {
                    // MariaDB khong nhan ket noi duoc dung luc nay - file van
                    // duoc khoi phuc, chi rieng DB khong (dbRestored=false).
                }
            }
            sqlFile.delete()
        }

        return RestoreResult(filesRestored, dbRestored, dbAttempted)
    }
}
