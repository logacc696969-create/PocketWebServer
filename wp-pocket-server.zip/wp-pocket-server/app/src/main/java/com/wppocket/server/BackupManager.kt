package com.wppocket.server

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Logic backup (zip thu muc www/ + mysqldump database neu dang chay MariaDB
 * that) - tach rieng khoi MainActivity de dung CHUNG duoc cho ca 2 noi goi:
 *
 *  1) Nut "Backup ngay" trong MainActivity (bam tay).
 *  2) BackupWorker (WorkManager, chay dinh ky tu dong).
 *
 * De xuat tu PDF "He thong Backup tu dong va Cloud Sync" (xem HANDOFF.md
 * muc 1e). Truoc ban nay, logic nay nam thang trong MainActivity va CHI co
 * o dang bam tay - gio tach ra de tai su dung, khong doi hanh vi backup tay
 * (van zip + dump y het cu), chi them phan don dep ban cu (xem
 * cleanupOldBackups) vi backup TU DONG chay dinh ky se nhanh chong lam day
 * bo nho dien thoai neu khong ai xoa bot - dien thoai khong co dung luong
 * lon nhu server that.
 */
object BackupManager {

    /** Giu lai toi da bao nhieu ban backup gan nhat - ap dung cho CA backup
     * tay lan tu dong, ban cu hon se tu xoa sau moi lan backup moi thanh
     * cong. Dien thoai khong co dung luong lon nhu VPS/server that nen can
     * gioi han nay, khac voi hanh vi cu (giu mai khong xoa). */
    private const val KEEP_BACKUPS = 5

    class BackupException(message: String, cause: Throwable? = null) : Exception(message, cause)

    data class BackupResult(val file: File, val dbDumped: Boolean)

    /** Zip thu muc www/ (+ dump database neu co the) ra file zip moi trong
     * Android/data/<package>/files/backups/. Chay tren luong hien tai - noi
     * goi (MainActivity, BackupWorker) tu lo viec chay o background thread. */
    fun performBackup(context: Context): BackupResult {
        val outDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val outZip = File(outDir, "backup-$stamp.zip")

        val filesDir = context.filesDir
        val mysqlSock = File(filesDir, "lamp-run/mysql.sock")
        val mysqldumpBin = File(context.applicationInfo.nativeLibraryDir, "libmysqldump.so")
        val dumpFile = File(context.cacheDir, "backup-dump-$stamp.sql")
        var dumped = false

        if (mysqlSock.exists() && mysqldumpBin.exists()) {
            try {
                val pb = ProcessBuilder(
                    mysqldumpBin.absolutePath,
                    "--socket=${mysqlSock.absolutePath}", "-uroot", "--databases", "wordpress"
                )
                pb.environment()["LD_LIBRARY_PATH"] = context.applicationInfo.nativeLibraryDir
                pb.redirectOutput(dumpFile)
                pb.start().waitFor()
                dumped = dumpFile.exists() && dumpFile.length() > 0
            } catch (_: Exception) {
                // khong co mariadb (vd runtime=node/python) - bo qua, van backup file website
            }
        }

        try {
            ZipOutputStream(FileOutputStream(outZip)).use { zos ->
                val wwwDir = File(filesDir, "www")
                if (wwwDir.exists()) zipDir(wwwDir, "www", zos)
                if (dumped) {
                    zos.putNextEntry(ZipEntry("database.sql"))
                    dumpFile.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        } catch (e: Exception) {
            outZip.delete()
            throw BackupException("Khong tao duoc file zip backup", e)
        } finally {
            dumpFile.delete()
        }

        cleanupOldBackups(outDir)

        return BackupResult(outZip, dumped)
    }

    private fun zipDir(dir: File, base: String, zos: ZipOutputStream) {
        dir.listFiles()?.forEach { f ->
            val entryName = "$base/${f.name}"
            if (f.isDirectory) {
                zipDir(f, entryName, zos)
            } else {
                zos.putNextEntry(ZipEntry(entryName))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun cleanupOldBackups(dir: File) {
        val files = dir.listFiles { f -> f.isFile && f.name.startsWith("backup-") && f.name.endsWith(".zip") }
            ?.sortedByDescending { it.lastModified() }
            ?: return
        if (files.size > KEEP_BACKUPS) {
            files.drop(KEEP_BACKUPS).forEach { it.delete() }
        }
    }

    class RestoreException(message: String, cause: Throwable? = null) : Exception(message, cause)

    data class RestoreResult(val filesRestored: Int, val dbRestored: Boolean, val dbAttempted: Boolean)

    /** Liet ke cac ban backup hien co (Android/data/<package>/files/backups/),
     * moi nhat truoc. Dung cho UI chon file de khoi phuc. */
    fun listBackups(context: Context): List<File> {
        val dir = File(context.getExternalFilesDir(null), "backups")
        return dir.listFiles { f -> f.isFile && f.name.startsWith("backup-") && f.name.endsWith(".zip") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    /**
     * Khoi phuc file website (www/) + database (neu ban backup co dump) tu 1
     * file zip do performBackup() tao ra. GHI DE truc tiep len du lieu hien
     * tai - noi GOI (MainActivity) phai tu canh bao nguoi dung day la hanh
     * dong KHONG THE HOAN TAC truoc khi goi ham nay, va nen dung server
     * truoc khi khoi phuc de tranh ghi de file dang duoc nginx/php-fpm doc
     * dung luc (khong fatal neu quen dung, nhung an toan hon neu dung truoc).
     *
     * Neu ban backup co "database.sql" nhung MariaDB khong dang chay (vd
     * runtime khac PHP, hoac server dang dung), phan file van duoc khoi phuc
     * binh thuong - chi rieng phan database bi bo qua (dbAttempted=false),
     * KHONG coi la loi toan bo qua trinh.
     */
    fun performRestore(context: Context, backupZip: File): RestoreResult {
        val filesDir = context.filesDir
        val wwwDir = File(filesDir, "www")
        var filesRestored = 0
        var dbSqlTemp: File? = null

        try {
            java.util.zip.ZipInputStream(backupZip.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    when {
                        entry.name == "database.sql" -> {
                            val tmp = File(context.cacheDir, "restore-dump-${System.currentTimeMillis()}.sql")
                            FileOutputStream(tmp).use { out -> zis.copyTo(out) }
                            dbSqlTemp = tmp
                        }
                        entry.name.startsWith("www/") && !entry.isDirectory -> {
                            val relativePath = entry.name.removePrefix("www/")
                            if (relativePath.isNotEmpty()) {
                                val destFile = File(wwwDir, relativePath)
                                destFile.parentFile?.mkdirs()
                                FileOutputStream(destFile).use { out -> zis.copyTo(out) }
                                filesRestored++
                            }
                        }
                        // Entry nao khac (vd thu muc rong) - bo qua, khong can xu ly.
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        } catch (e: Exception) {
            throw RestoreException("Khong doc duoc file backup (co the file bi hong)", e)
        }

        val sqlFile = dbSqlTemp
        var dbAttempted = false
        var dbRestored = false
        if (sqlFile != null && sqlFile.exists() && sqlFile.length() > 0) {
            val mysqlSock = File(filesDir, "lamp-run/mysql.sock")
            val mysqlCliBin = File(context.applicationInfo.nativeLibraryDir, "libmysqlcli.so")
            if (mysqlSock.exists() && mysqlCliBin.exists()) {
                dbAttempted = true
                try {
                    val pb = ProcessBuilder(
                        mysqlCliBin.absolutePath,
                        "--socket=${mysqlSock.absolutePath}", "-uroot"
                    )
                    pb.environment()["LD_LIBRARY_PATH"] = context.applicationInfo.nativeLibraryDir
                    pb.redirectInput(sqlFile)
                    val proc = pb.start()
                    dbRestored = proc.waitFor() == 0
                } catch (_: Exception) {
                    // MariaDB khong nhan ket noi duoc dung luc nay - file van
                    // duoc khoi phuc, chi rieng DB khong (dbRestored=false).
                }
            }
            sqlFile.delete()
        }

        return RestoreResult(filesRestored, dbRestored, dbAttempted)
    }
}
