package com.wppocket.server

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Logic backup (zip thu muc www/ + mysqldump database neu dang chay MariaDB
 * that) - tach rieng khoi MainActivity de dung CHUNG duoc cho ca 2 noi goi:
 *
 *  1) Nut "Backup ngay" trong MainActivity (bam tay).
 *  2) BackupWorker (WorkManager, chay dinh ky tu dong).
 *
 * De xuat tu PDF "He thong Backup tu dong va Cloud Sync" (xem HANDOFF.md
 * muc 1e). Truoc ban nay, logic nay nam thang trong MainActivity va CHI co
 * o dang bam tay - gio tach ra de tai su dung, khong doi hanh vi backup tay
 * (van zip + dump y het cu), chi them phan don dep ban cu (xem
 * cleanupOldBackups) vi backup TU DONG chay dinh ky se nhanh chong lam day
 * bo nho dien thoai neu khong ai xoa bot - dien thoai khong co dung luong
 * lon nhu server that.
 */
object BackupManager {

    /** Giu lai toi da bao nhieu ban backup gan nhat - ap dung cho CA backup
     * tay lan tu dong, ban cu hon se tu xoa sau moi lan backup moi thanh
     * cong. Dien thoai khong co dung luong lon nhu VPS/server that nen can
     * gioi han nay, khac voi hanh vi cu (giu mai khong xoa). */
    private const val KEEP_BACKUPS = 5

    class BackupException(message: String, cause: Throwable? = null) : Exception(message, cause)

    data class BackupResult(val file: File, val dbDumped: Boolean, val encrypted: Boolean = false)

    /** Uoc tinh dung luong (byte) cua 1 thu muc bang cach cong don kich thuoc
     * tung file - dung de so sanh voi dung luong trong con truoc khi backup
     * (xem checkEnoughDiskSpace). Chi la UOC LUONG (chua tinh nen zip lam
     * nho lai, hoac file dump SQL them vao) - co chu ky an toan (buffer x2)
     * o noi goi de bu lai. */
    private fun estimateDirSize(dir: File): Long = BackupLogic.dirSize(dir)

    /** Kiem tra dung luong trong TRUOC khi backup (xem HANDOFF.md muc 10, de
     * xuat DeepSeek muc F7). Truoc day KHONG kiem tra gi ca - neu may gan
     * day bo nho, qua trinh zip/dump co the THAT BAI GIUA CHUNG, de lai 1
     * file zip CUT (khong mo duoc, hoac mo duoc nhung thieu du lieu) ma
     * nguoi dung tuong la 1 ban backup binh thuong cho toi luc can khoi
     * phuc moi phat hien ra hong - luc do thi da qua muon. Dung he so an
     * toan x2 (nhan doi uoc luong) vi zip nen it, dump SQL them vao, va de
     * du cho THAO TAC KHAC dang dien ra dong thoi tren may (khong the biet
     * truoc chinh xac). */
    private fun checkEnoughDiskSpace(context: Context, filesDir: File, outDir: File) {
        val estimated = estimateDirSize(File(filesDir, "www"))
        val needed = (estimated * 2).coerceAtLeast(10L * 1024 * 1024) // toi thieu 10MB du cho site rong/moi
        val stat = StatFs(outDir.absolutePath)
        val available = stat.availableBytes
        if (available < needed) {
            val neededMb = needed / (1024 * 1024)
            val availableMb = available / (1024 * 1024)
            throw BackupException(
                "Khong du dung luong trong de backup an toan (can khoang ${neededMb}MB, " +
                    "may con trong ${availableMb}MB) - xoa bot du lieu roi thu lai."
            )
        }
    }

    /** Zip thu muc www/ (+ dump database neu co the) ra file zip moi trong
     * Android/data/<package>/files/backups/. Chay tren luong hien tai - noi
     * goi (MainActivity, BackupWorker) tu lo viec chay o background thread. */
    /**
     * @param encryptPassphrase De xuat DeepSeek muc F6 (xem HANDOFF.md muc
     * 10): backup chua "wp-config.php" (mat khau database That, salt
     * WordPress, co the ca SMTP credentials) - gui qua Telegram/webhook o
     * dang KHONG mã hoá nghia la neu Bot Token bi lo (vd log, chia se
     * nham), toan bo credentials lo theo. Null/rong = KHONG mã hoá (mac
     * dinh, giu nguyen hanh vi cu). Neu co gia tri, backup se duoc mã hoá
     * AES-256-GCM (xem encryptBackupFile) ngay sau khi xac minh xong, TRUOC
     * khi gui di - file zip goc (chua mã hoá) bi XOA, khong luu song song.
     */
    /** Khoa toan tien trinh: nut "Backup ngay" (MainActivity), BackupWorker (dinh
     * ky) va lenh Telegram /backup chay tren cac thread KHAC NHAU va co the
     * chong nhau. Khong tuan tu hoa thi cleanupStaleLeftovers() cua lan chay
     * sau se xoa file ".partial" DANG GHI DO cua lan chay truoc (lan truoc se
     * that bai gia: verify khong thay file). Chay lan luot an toan va don gian
     * hon nhieu so voi phan biet "partial dang ghi" voi "partial mo coi". */
    private val backupLock = Any()

    fun performBackup(context: Context, encryptPassphrase: String? = effectivePassphrase(context)): BackupResult =
        synchronized(backupLock) {
            // PDF 2 muc B6 (HANDOFF 1bl): ha do uu tien luong dang backup xuong BACKGROUND (nice ~10) de nen/zip/ma hoa KHONG gianh CPU
            // cua nginx/php-fpm/MariaDB dang phuc vu khach. Tien trinh con (mysqldump) duoc fork tu CHINH luong nay nen ke thua muc nice
            // (hanh vi fork cua Linux; chua do tren thiet bi that). Luon khoi phuc muc cu - luong goi co the la luong dung chung.
            val oldPriority: Int? = try { android.os.Process.getThreadPriority(android.os.Process.myTid()) } catch (_: Exception) { null }
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Exception) { }
            try {
                performBackupLocked(context, encryptPassphrase)
            } finally {
                if (oldPriority != null) {
                    try { android.os.Process.setThreadPriority(oldPriority) } catch (_: Exception) { }
                }
            }
        }

    private fun performBackupLocked(context: Context, encryptPassphrase: String?): BackupResult {
        val outDir = File(writeVolume(context), "backups").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        // Ghi vao file TAM ".partial" truoc, chi doi ten thanh ".zip" SAU khi
        // da xac minh hop le (xem verifyBackupZip). Truoc day ghi thang vao
        // "backup-<ts>.zip": neu Android kill app giua luc dang zip (RAM thap,
        // het pin...) thi 1 file zip CUT van mang ten hop le - hien trong danh
        // sach khoi phuc VA con dem vao KEEP_BACKUPS, day ban backup TOT cu ra
        // khoi vong xoay. File ".partial" khong khop bo loc nao cua
        // listBackups/cleanupOldBackups nen khong bao gio bi nham la backup.
        val outZip = File(outDir, "backup-$stamp.zip")
        val partialZip = File(outDir, "backup-$stamp.zip.partial")
        cleanupStaleLeftovers(context, outDir)

        val filesDir = context.filesDir
        checkEnoughDiskSpace(context, filesDir, outDir)
        val mysqlSock = File(filesDir, "lamp-run/mysql.sock")
        val mysqldumpBin = File(context.applicationInfo.nativeLibraryDir, "libmysqldump.so")
        val dumpFile = File(context.cacheDir, "backup-dump-$stamp.sql")
        var dumped = false

        if (mysqlSock.exists() && mysqldumpBin.exists()) {
            try {
                val pb = ProcessBuilder(
                    mysqldumpBin.absolutePath,
                    "--socket=${mysqlSock.absolutePath}", "-uroot",
                    // --single-transaction: chup 1 "anh chup" nhat quan cua du
                    // lieu InnoDB ma KHONG khoa bang (theo dung de xuat DeepSeek
                    // muc O4, xem HANDOFF.md muc 2). Neu khong co co nay,
                    // mysqldump se khoa doc toan bo bang trong luc dump - voi
                    // site dang co khach truy cap dong thoi, co the gay dung
                    // hinh vai giay/vai chuc giay, va neu co ghi du lieu xen
                    // giua luc dump, ban backup co the KHONG NHAT QUAN (post co
                    // nhung meta chua kip ghi). --quick: doc tung dong thay vi
                    // nap ca bang vao RAM truoc (quan trong tren dien thoai RAM
                    // han che). --lock-tables=false: khong can khoa kieu
                    // MyISAM cu, tranh xung dot voi --single-transaction.
                    "--single-transaction", "--quick", "--lock-tables=false",
                    "--databases", dbName(context)
                )
                val env = pb.environment()
                // SUA LOI THAT (xem HANDOFF.md muc 2): truoc day CHI set
                // LD_LIBRARY_PATH = nativeLibraryDir, THIEU thu muc
                // "compat-libs" (xem HANDOFF.md muc 1u/1v) - mysqldump la
                // binary ELF that, RAT CO THE can cung cac thu vien SONAME
                // (libz.so.1, libssl.so.X...) nhu mariadbd/php-fpm da tung
                // thieu. Khong co compat-libs, mysqldump co the CHET NGAY khi
                // thuc thi (linker bao "library X not found") - loi nay bi
                // nuot am tham boi catch(Exception) ben duoi, hien thi y het
                // truong hop binh thuong "khong co mariadb" - nghia la backup
                // CSDL co the DA TUNG am tham that bai ngay ca khi MariaDB
                // dang chay binh thuong, ma khong ai biet. Dung DUNG 1 bien
                // COMPAT_DIR thay vi tinh lai duong dan de tranh 2 noi lech
                // nhau ve sau (start-lamp.sh dinh nghia goc).
                val compatDir = File(filesDir, "lamp-run/compat-libs")
                env["LD_LIBRARY_PATH"] = "${compatDir.absolutePath}:${context.applicationInfo.nativeLibraryDir}"
                pb.redirectOutput(dumpFile)
                pb.redirectErrorStream(false)
                val process = pb.start()
                val exitCode = process.waitFor()
                // SUA LOI THAT (de xuat DeepSeek muc A2, xem HANDOFF.md muc
                // 10): truoc day KHONG kiem tra exitCode ti nao, chi nhin
                // "file dump co rong khong" - mysqldump co the CHET GIUA
                // CHUNG (vd mat ket noi socket, het bo nho) va van de lai 1
                // file .sql khong rong nhung THIEU DU LIEU, ma code cu se
                // coi la "dump thanh cong". Gio doi hoi CA HAI: exitCode=0
                // VA file khong rong - buoc kiem tra sau (verifyBackupZip)
                // con kiem tra sau hon nua (dong "-- Dump completed" o cuoi).
                dumped = exitCode == 0 && dumpFile.exists() && dumpFile.length() > 0
            } catch (_: Exception) {
                // khong co mariadb (vd runtime=node/python) - bo qua, van backup file website
            }
        }

        try {
            ZipOutputStream(FileOutputStream(partialZip)).use { zos ->
                val wwwDir = File(filesDir, "www")
                if (wwwDir.exists()) zipDir(wwwDir, "www", zos)
                if (dumped) {
                    zos.putNextEntry(ZipEntry("database.sql"))
                    dumpFile.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        } catch (e: Exception) {
            partialZip.delete()
            throw BackupException("Khong tao duoc file zip backup", e)
        } finally {
            dumpFile.delete()
        }

        // Xac minh backup vua tao THAT SU dung duoc (de xuat DeepSeek muc A2,
        // xem HANDOFF.md muc 10: "Backup chua test = chua co backup"). Neu
        // xac minh that bai, XOA file hong roi nem loi - giong het cach cac
        // loi khac trong ham nay xu ly (khong bao gio de lai 1 file backup
        // TUONG nhu binh thuong nhung thuc ra hong/thieu du lieu ma khong ai
        // biet cho toi luc can khoi phuc that su).
        val verify = verifyBackupZip(partialZip, expectDbDump = dumped)
        if (!verify.ok) {
            partialZip.delete()
            throw BackupException("Backup vua tao KHONG hop le, da xoa: ${verify.reason}")
        }
        // Hop le roi moi cong nhan: doi ten .partial -> .zip (cung thu muc nen
        // la thao tac nguyen tu tren cung 1 filesystem, khong bi "nua chung").
        if (!partialZip.renameTo(outZip)) {
            partialZip.delete()
            throw BackupException("Khong doi ten duoc file backup tam sang ten chinh thuc")
        }

        // Mã hoá (tuy chon, xem chu thich tham so encryptPassphrase o tren) -
        // lam SAU KHI xac minh OK (khong ma hoa 1 file co the da hong), va
        // TRUOC khi cleanupOldBackups/gui di - ca BackupWorker (Telegram/
        // webhook) VA nut "Backup ngay" deu dung chung duong nay nen khong
        // co cho nao khac vo tinh gui ban CHUA mã hoá di.
        var finalFile = outZip
        var encrypted = false
        if (!encryptPassphrase.isNullOrEmpty()) {
            try {
                finalFile = encryptBackupFile(outZip, encryptPassphrase)
                outZip.delete() // KHONG luu song song ban chua mã hoá
                encrypted = true
            } catch (e: Exception) {
                outZip.delete()
                throw BackupException("Ma hoa backup that bai, da xoa file goc (khong gui ban chua ma hoa)", e)
            }
        }

        cleanupOldBackups(context)

        return BackupResult(finalFile, dumped, encrypted)
    }

    /**
     * Mã hoá 1 file bang AES-256-GCM (co san trong javax.crypto cua chinh
     * JDK/Android, KHONG can thu vien ngoai). Dinh dang file ket qua:
     * [16 byte salt][12 byte IV][ciphertext + 16 byte GCM tag]. Salt dung
     * de "derive" khoa AES tu passphrase nguoi dung nhap qua PBKDF2WithHmacSHA256
     * (100,000 vong lap - muc hop ly cho dien thoai, khong qua cham nhung
     * du kho brute-force hon nhieu so voi 1 vong don).
     *
     * QUAN TRONG - khong luu passphrase gieng bat ky dau trong file ket qua:
     * neu quen passphrase, KHONG CO CACH NAO khoi phuc lai duoc (dung y
     * dinh cua ma hoa that - khac voi mat khau _admin/ co the tu doi lai
     * duoc vi chi la 1 lop bao ve truy cap, day la ma hoa NOI DUNG THAT).
     */
    private fun encryptBackupFile(input: File, passphrase: String): File {
        val random = java.security.SecureRandom()
        val salt = ByteArray(16).also { random.nextBytes(it) }
        val iv = ByteArray(12).also { random.nextBytes(it) }

        val keySpec = javax.crypto.spec.PBEKeySpec(passphrase.toCharArray(), salt, 100_000, 256)
        val keyFactory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = keyFactory.generateSecret(keySpec).encoded
        val secretKey = javax.crypto.spec.SecretKeySpec(keyBytes, "AES")

        val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, secretKey, javax.crypto.spec.GCMParameterSpec(128, iv))

        val output = File(input.parentFile, input.name + ".enc")
        output.outputStream().use { out ->
            out.write(salt)
            out.write(iv)
            input.inputStream().use { ins ->
                javax.crypto.CipherOutputStream(out, cipher).use { cout ->
                    ins.copyTo(cout)
                }
            }
        }
        return output
    }

    data class BackupVerifyResult(val ok: Boolean, val reason: String)

    /** Xac minh 1 file backup vua tao (de xuat DeepSeek muc A2, xem
     * HANDOFF.md muc 10: "Backup chua test = chua co backup").
     *
     * SUA o vong 21 (HANDOFF.md muc 1az): ban cu doc het entry qua
     * java.util.zip.ZipFile va KHANG DINH "tu dong nem loi neu CRC sai" - SAI:
     * thuc nghiem tren JDK cho thay ZipFile KHONG kiem CRC (chi ZipInputStream
     * moi kiem), nen backup bi lat bit van "xac minh OK". Gio dung
     * BackupLogic.inspect(): TU TINH CRC32 + kich thuoc cua tung entry va doi
     * chieu voi central directory, kiem ten entry, co www/, va dong ket thuc
     * "-- Dump completed" cua mysqldump (test JVM: scripts/tests/BackupLogicTest.kt).
     * maxEntries khong gioi han: day la backup do CHINH app tao, khong the tu choi
     * vi site co nhieu file. */
    private fun verifyBackupZip(zipFile: File, expectDbDump: Boolean): BackupVerifyResult {
        val r = BackupLogic.inspect(zipFile, maxEntries = Int.MAX_VALUE)
        if (!r.ok) return BackupVerifyResult(false, r.reason)
        if (expectDbDump && !r.hasDb) {
            return BackupVerifyResult(false, "Dang cho co ban dump database trong zip nhung khong thay database.sql")
        }
        return BackupVerifyResult(true, "OK")
    }

    /** Uy quyen cho BackupLogic.zipDir (thuan, co test JVM; KHONG theo symlink - xem HANDOFF.md muc 1bj). */
    private fun zipDir(dir: File, base: String, zos: ZipOutputStream) = BackupLogic.zipDir(dir, base, zos)

    /** Passphrase mã hoá backup HIEN HANH theo cau hinh nguoi dung, hoac null
     * neu chua bat/chua nhap. Gom ve 1 cho duy nhat - lam GIA TRI MAC DINH cua
     * performBackup() de KHONG co call site nao co the quen truyen (loi that
     * da xay ra: lenh Telegram "/backup" goi performBackup() khong tham so va
     * am tham gui ban CHUA ma hoa du nguoi dung da bat ma hoa). */
    fun effectivePassphrase(context: Context): String? {
        val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(Prefs.KEY_BACKUP_ENCRYPT_ENABLED, false)
        val pass = SecretStore.get(prefs, Prefs.KEY_BACKUP_ENCRYPT_PASSPHRASE, null)
        return if (enabled && !pass.isNullOrEmpty()) pass else null
    }

    /** Don rac do lan backup truoc bi kill giua chung: file ".partial" (zip
     * dang ghi do) va "backup-dump-*.sql" trong cacheDir. Chay dau moi lan
     * performBackup(); an toan vi 2 loai file nay KHONG BAO GIO la ban backup
     * hoan chinh, va performBackup() duoc tuan tu hoa bang backupLock (khong co
     * lan chay nao khac dang ghi file .partial luc ham nay chay). */
    private fun cleanupStaleLeftovers(context: Context, outDir: File) {
        outDir.listFiles { f -> f.isFile && f.name.endsWith(".zip.partial") }?.forEach { it.delete() }
        context.cacheDir.listFiles { f -> f.isFile && f.name.startsWith("backup-dump-") && f.name.endsWith(".sql") }
            ?.forEach { it.delete() }
    }

    /**
     * Giu KEEP_BACKUPS ban moi nhat TINH TREN TAT CA noi luu (bo nho chinh + the nho) - truoc 1bp-K chi co mot thu muc. Nhan dien CA ".zip"
     * LAN ".zip.enc" (de xuat DeepSeek muc F6): neu chi loc ".zip", backup MA HOA se khong bao gio bi rotation quan ly va tich luy mai mai
     * (cung van de A1 da giai quyet cho ban chua ma hoa). Bo loc nam o BackupDirLogic.isBackupFile.
     */
    private fun cleanupOldBackups(context: Context) {
        BackupDirLogic.excess(listBackups(context), KEEP_BACKUPS).forEach { it.delete() }
    }

    /** Cac thu muc `backups` o MOI noi luu dang gan (bo nho chinh + the nho neu co). */
    fun backupRoots(context: Context): List<File> {
        val roots = ArrayList<File>()
        for (v in context.getExternalFilesDirs(null)) if (v != null) roots.add(File(v, "backups"))
        if (roots.isEmpty()) roots.add(File(context.getExternalFilesDir(null), "backups"))
        return roots
    }

    /** Noi GHI backup moi: the nho neu nguoi dung bat Prefs.KEY_BACKUP_ON_SD va the do ghi duoc, con lai bo nho chinh (BackupDirLogic). */
    private fun writeVolume(context: Context): File? {
        val prefer = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE).getBoolean(Prefs.KEY_BACKUP_ON_SD, false)
        val picked = BackupDirLogic.pickWriteDir(
            context.getExternalFilesDirs(null).toList(), prefer,
            { f -> try { android.os.Environment.isExternalStorageRemovable(f) } catch (_: Exception) { false } },
            { f ->
                try {
                    android.os.Environment.getExternalStorageState(f) == android.os.Environment.MEDIA_MOUNTED &&
                        (f.isDirectory || f.mkdirs()) && f.canWrite()
                } catch (_: Exception) { false }
            }
        )
        return picked ?: context.getExternalFilesDir(null)
    }

    class RestoreException(message: String, cause: Throwable? = null) : Exception(message, cause)

    data class RestoreResult(val filesRestored: Int, val dbRestored: Boolean, val dbAttempted: Boolean)

    /** Liet ke cac ban backup hien co (Android/data/<package>/files/backups/),
     * moi nhat truoc. Dung cho UI chon file de khoi phuc - nhan dien CA
     * ".zip.enc" (backup da ma hoa, de xuat DeepSeek muc F6): neu chi liet
     * ke ".zip" nhu truoc khi them F6, nguoi dung bat ma hoa se KHONG THAY
     * backup nao de chon khoi phuc qua app nua (tinh nang khoi phuc co san
     * tro thanh vo dung voi ho) - MainActivity.showRestorePicker() tu hoi
     * passphrase truoc khi giai ma neu file ket thuc ".enc". */
    fun listBackups(context: Context): List<File> = BackupDirLogic.listAll(backupRoots(context))

    class DecryptException(message: String, cause: Throwable? = null) : Exception(message, cause)

    /** Giai ma 1 file da tao boi encryptBackupFile() - doi xung voi ham do,
     * doc lai [salt][iv][ciphertext+tag] theo dung thu tu da ghi. Passphrase
     * SAI se khien GCM tag khong khop, nem AEADBadTagException (boc lai
     * thanh DecryptException voi thong bao ro rang "sai mat khau", KHONG de
     * loi ky thuat kho hieu lot ra ngoai). Ghi ra file tam trong cacheDir -
     * nguoi goi (MainActivity) chiu trach nhiem xoa file tam sau khi dung
     * xong (thanh cong hay that bai deu phai xoa, tranh de lai ban ZIP
     * CHUA MA HOA tren dia lau hon can thiet). */
    fun decryptBackupFile(input: File, passphrase: String, outFile: File): File {
        input.inputStream().use { ins ->
            val salt = ByteArray(16)
            val iv = ByteArray(12)
            if (ins.read(salt) != 16 || ins.read(iv) != 12) {
                throw DecryptException("File backup ma hoa khong dung dinh dang (thieu du lieu dau file)")
            }

            val keySpec = javax.crypto.spec.PBEKeySpec(passphrase.toCharArray(), salt, 100_000, 256)
            val keyFactory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val keyBytes = keyFactory.generateSecret(keySpec).encoded
            val secretKey = javax.crypto.spec.SecretKeySpec(keyBytes, "AES")

            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            try {
                cipher.init(javax.crypto.Cipher.DECRYPT_MODE, secretKey, javax.crypto.spec.GCMParameterSpec(128, iv))
                outFile.outputStream().use { out ->
                    javax.crypto.CipherInputStream(ins, cipher).use { cin -> cin.copyTo(out) }
                }
            } catch (e: Exception) {
                outFile.delete()
                // AEADBadTagException (tag GCM khong khop) la nguyen nhan
                // PHO BIEN NHAT: passphrase sai. Cac loi Cipher khac hiem
                // hon nhieu (file hong...) nhung gop chung 1 thong bao de
                // don gian, khong doan sai nguyen nhan cu the voi nguoi dung.
                throw DecryptException("Giai ma that bai - sai mat khau hoac file backup bi hong", e)
            }
        }
        return outFile
    }

    /**
     * Khoi phuc file website (www/) + database (neu ban backup co dump) tu 1
     * file zip do performBackup() tao ra. GHI DE truc tiep len du lieu hien
     * tai - noi GOI (MainActivity) phai tu canh bao nguoi dung day la hanh
     * dong KHONG THE HOAN TAC truoc khi goi ham nay, va nen dung server
     * truoc khi khoi phuc de tranh ghi de file dang duoc nginx/php-fpm doc
     * dung luc (khong fatal neu quen dung, nhung an toan hon neu dung truoc).
     *
     * Neu ban backup co "database.sql" nhung MariaDB khong dang chay (vd
     * runtime khac PHP, hoac server dang dung), phan file van duoc khoi phuc
     * binh thuong - chi rieng phan database bi bo qua (dbAttempted=false),
     * KHONG coi la loi toan bo qua trinh.
     */
    /** Chua toi thieu bay nhieu dung luong trong sau khi khoi phuc (bien an toan). */
    private const val RESTORE_SAFETY_MARGIN_BYTES = 50L * 1024 * 1024

    fun performRestore(context: Context, backupZip: File): RestoreResult {
        val filesDir = context.filesDir
        val wwwDir = File(filesDir, "www")

        // BUOC 0 (vong 21, HANDOFF.md muc 1az) - kiem tra TOAN VEN truoc khi dung vao
        // du lieu that: truoc day ghi de tung file ngay khi doc, nen 1 file hong/
        // thieu giua chung de lai website khoi phuc DO DANG; va ten entry khong
        // duoc kiem tra (Zip Slip). Gio tu choi som, chua ghi gi ca. Gioi han dung
        // luong = cho trong hien co + dung luong www/ hien tai (se bi thay the)
        // - bien an toan.
        val free = try { StatFs(filesDir.absolutePath).availableBytes } catch (_: Exception) { 0L }
        val limit = if (free > 0) (free + estimateDirSize(wwwDir) - RESTORE_SAFETY_MARGIN_BYTES).coerceAtLeast(1L) else 0L
        val inspection = BackupLogic.inspect(backupZip, maxUncompressedBytes = limit)
        if (!inspection.ok) {
            throw RestoreException("Backup khong hop le, CHUA khoi phuc gi ca: ${inspection.reason}")
        }

        // 1bq-E: dau danh dau "dang khoi phuc" - GHI SAU khi kiem tra toan ven (tu choi som thi chua dung vao du lieu nen khong ghi), XOA khi
        // performRestore tra ve binh thuong. Con ton tai > 15 phut (tat app/mat dien giua chung, hoac extract nem loi) = khoi phuc dang do
        // -> Monitoring.checkInterruptedRestore bao Telegram. Xem RestoreMarker.kt.
        RestoreMarker.begin(filesDir, backupZip.name, System.currentTimeMillis())
        val sqlTemp = File(context.cacheDir, "restore-dump-${System.currentTimeMillis()}.sql")
        val extracted = try {
            BackupLogic.extract(backupZip, wwwDir, sqlTemp)
        } catch (e: Exception) {
            sqlTemp.delete()
            throw RestoreException("Khong khoi phuc duoc file (${e.message ?: e.javaClass.simpleName})", e)
        }
        val filesRestored = extracted.filesRestored
        val dbSqlTemp: File? = extracted.dbDumpFile

        val sqlFile = dbSqlTemp
        var dbAttempted = false
        var dbRestored = false
        if (sqlFile != null && sqlFile.exists() && sqlFile.length() > 0) {
            val mysqlSock = File(filesDir, "lamp-run/mysql.sock")
            val mysqlCliBin = File(context.applicationInfo.nativeLibraryDir, "libmysqlcli.so")
            if (mysqlSock.exists() && mysqlCliBin.exists()) {
                dbAttempted = true
                try {
                    val pb = ProcessBuilder(
                        mysqlCliBin.absolutePath,
                        "--socket=${mysqlSock.absolutePath}", "-uroot"
                    )
                    // Cung loi/cung fix nhu mysqldump o performBackup() phia
                    // tren (xem chu thich day du o do) - mysqlCliBin cung la
                    // binary ELF that, can compat-libs de tim dung thu vien
                    // SONAME luc chay.
                    val compatDir = File(filesDir, "lamp-run/compat-libs")
                    pb.environment()["LD_LIBRARY_PATH"] = "${compatDir.absolutePath}:${context.applicationInfo.nativeLibraryDir}"
                    pb.redirectInput(sqlFile)
                    val proc = pb.start()
                    dbRestored = proc.waitFor() == 0
                } catch (_: Exception) {
                    // MariaDB khong nhan ket noi duoc dung luc nay - file van
                    // duoc khoi phuc, chi rieng DB khong (dbRestored=false).
                }
            }
            sqlFile.delete()
        }

        // 1bd: khoi phuc vua ghi DB (SQL nhap thang vao MariaDB dang chay) va ghi de tep, nhung cache APCu cua php-fpm
        // (object-cache.php) khong biet => site hien du lieu CU sau khi "khoi phuc xong". Bao hieu de xoa cache (xem
        // object-cache.php::syncEpoch va HANDOFF.md muc 1bd). Chay ca khi DB khong khoi phuc duoc (tep van doi).
        BackupLogic.bumpObjectCacheEpoch(filesDir)

        RestoreMarker.finish(filesDir)
        return RestoreResult(filesRestored, dbRestored, dbAttempted)
    }

    // ==================================================================
    // Nhap backup tu trinh chon file + xuat ra ngoai (J1-J3, vong 21,
    // HANDOFF.md muc 1az). Dung Storage Access Framework: KHONG can quyen
    // luu tru nao - he thong chi cap quyen doc/ghi dung Uri nguoi dung chon.
    // ==================================================================

    /** Ten CSDL cua site: start-lamp.sh ghi lamp-run/db-name (site "generic" co the khong dung ten "wordpress"). Thieu/khong hop le -> "wordpress". */
    fun dbName(context: Context): String =
        BackupLogic.sanitizeDbName(try { File(context.filesDir, "lamp-run/db-name").readText() } catch (_: Exception) { null })

    data class PickedInfo(val displayName: String?, val sizeBytes: Long)

    /** Ten + kich thuoc file tu Uri (neu provider cung cap); khong co thi (null, -1). */
    fun queryPicked(context: Context, uri: Uri): PickedInfo {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (!c.moveToFirst()) return PickedInfo(null, -1L)
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                PickedInfo(
                    if (ni >= 0 && !c.isNull(ni)) c.getString(ni) else null,
                    if (si >= 0 && !c.isNull(si)) c.getLong(si) else -1L,
                )
            } ?: PickedInfo(null, -1L)
        } catch (_: Exception) {
            PickedInfo(null, -1L)
        }
    }

    /** Chep noi dung Uri vao 1 file tam trong cacheDir (restore can File de doc zip
     * truy cap ngau nhien). Nguoi goi PHAI xoa file tra ve khi xong (ca khi loi).
     * Kiem tra dung luong truoc neu biet kich thuoc; het cho giua chung thi xoa
     * file tam va nem BackupException. */
    fun copyUriToCache(context: Context, uri: Uri, knownSize: Long): File {
        if (knownSize > 0) {
            val avail = try { StatFs(context.cacheDir.absolutePath).availableBytes } catch (_: Exception) { Long.MAX_VALUE }
            if (avail < knownSize + RESTORE_SAFETY_MARGIN_BYTES) {
                throw BackupException("Khong du dung luong trong de nhap file (can ~${knownSize / (1024 * 1024)}MB, con ${avail / (1024 * 1024)}MB)")
            }
        }
        val out = File(context.cacheDir, "import-${System.currentTimeMillis()}.tmp")
        try {
            val ins = context.contentResolver.openInputStream(uri)
                ?: throw BackupException("Khong mo duoc file da chon")
            ins.use { i -> FileOutputStream(out).use { o -> i.copyTo(o) } }
        } catch (e: BackupException) {
            out.delete(); throw e
        } catch (e: Exception) {
            out.delete()
            throw BackupException("Khong doc duoc file da chon (${e.message ?: e.javaClass.simpleName})", e)
        }
        return out
    }

    /** Ghi [source] ra Uri (do ACTION_CREATE_DOCUMENT tao). Thu che do "wt" (cat ngan
     * file) roi lui ve mac dinh neu provider khong ho tro. */
    fun copyFileToUri(context: Context, source: File, uri: Uri) {
        val os = try {
            context.contentResolver.openOutputStream(uri, "wt")
        } catch (_: Exception) {
            context.contentResolver.openOutputStream(uri)
        } ?: throw BackupException("Khong ghi duoc vao noi da chon")
        try {
            os.use { o -> FileInputStream(source).use { it.copyTo(o) } }
        } catch (e: Exception) {
            throw BackupException("Ghi file that bai (${e.message ?: e.javaClass.simpleName})", e)
        }
    }

    // ------------------------------------------------------------------
    // Goi "di chuyen" (portable): wp-content + database.sql + huong dan
    // ------------------------------------------------------------------

    /**
     * Tao goi di chuyen trong cacheDir va tra ve file zip; nguoi goi copy ra Uri roi XOA.
     * Khac backup thuong: (1) dump KHONG co CREATE DATABASE/USE (khong --databases) nen
     * nap duoc vao database ten bat ky; (2) chi wp-content da loc (khong wp-config.php,
     * khong loi WP, khong drop-in dac thu cua nen tang - xem BackupLogic.isPortableIncluded);
     * (3) khong ma hoa (de dung tay o noi khac - README noi ro day la du lieu nhay cam).
     * Dinh dang CHUAN thu cong, KHONG phai .wpress/Duplicator (khong kiem chung duoc
     * tuong thich nen khong gia vo - HANDOFF.md muc 1az).
     */
    fun buildPortableExport(context: Context): File = synchronized(backupLock) { buildPortableExportLocked(context) }

    private fun buildPortableExportLocked(context: Context): File {
        val filesDir = context.filesDir
        val wwwDir = File(filesDir, "www")
        if (!File(wwwDir, "wp-content").isDirectory) {
            throw BackupException("Chua co WordPress (thu muc wp-content) de xuat - goi di chuyen chi danh cho site WordPress")
        }
        val cache = context.cacheDir
        checkEnoughDiskSpace(context, filesDir, cache)
        cache.listFiles { f -> f.isFile && f.name.startsWith("portable-") }?.forEach { it.delete() }

        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val dumpFile = File(cache, "portable-dump-$stamp.sql")
        val outZip = File(cache, "portable-$stamp.zip")
        val mysqlSock = File(filesDir, "lamp-run/mysql.sock")
        val mysqldumpBin = File(context.applicationInfo.nativeLibraryDir, "libmysqldump.so")

        var dumped = false
        if (mysqlSock.exists() && mysqldumpBin.exists()) {
            try {
                val pb = ProcessBuilder(
                    mysqldumpBin.absolutePath,
                    "--socket=${mysqlSock.absolutePath}", "-uroot",
                    // Giong performBackup (xem chu thich o do) NHUNG khong "--databases":
                    // ten database la tham so vi tri cuoi -> dump khong co CREATE DATABASE/USE.
                    // utf8mb4 tuong minh de emoji/tieng Viet khong bi doi charset (bai hoc 1ay).
                    "--single-transaction", "--quick", "--lock-tables=false",
                    "--default-character-set=utf8mb4",
                    dbName(context)
                )
                val compatDir = File(filesDir, "lamp-run/compat-libs")
                pb.environment()["LD_LIBRARY_PATH"] = "${compatDir.absolutePath}:${context.applicationInfo.nativeLibraryDir}"
                pb.redirectOutput(dumpFile)
                pb.redirectErrorStream(false)
                val code = pb.start().waitFor()
                dumped = code == 0 && BackupLogic.dumpLooksComplete(dumpFile)
            } catch (_: Exception) {
                // khong chay duoc mysqldump -> goi khong co database.sql, README se noi ro
            }
        }

        try {
            val sqliteMode = !dumped && File(wwwDir, "wp-content/db.php").exists()
            val prefix = try { BackupLogic.parseTablePrefix(File(wwwDir, "wp-config.php").readText()) } catch (_: Exception) { null }
            val siteUrl = if (dumped) try { BackupLogic.findOptionInDump(dumpFile, "siteurl") } catch (_: Exception) { null } else null
            val homeUrl = if (dumped) try { BackupLogic.findOptionInDump(dumpFile, "home") } catch (_: Exception) { null } else null
            val info = BackupLogic.PortableInfo(
                generatedAt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                siteUrl = siteUrl, homeUrl = homeUrl, tablePrefix = prefix,
                dbIncluded = dumped, sqliteMode = sqliteMode, wordpressFiles = 0,
            )
            BackupLogic.buildPortableZip(wwwDir, if (dumped) dumpFile else null, outZip, info)
        } catch (e: Exception) {
            outZip.delete()
            throw BackupException("Khong tao duoc goi di chuyen (${e.message ?: e.javaClass.simpleName})", e)
        } finally {
            dumpFile.delete()
        }
        return outZip
    }
}
