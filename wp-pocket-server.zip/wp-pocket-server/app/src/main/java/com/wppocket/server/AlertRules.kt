package com.wppocket.server

/**
 * AE5 (PDF 2; HANDOFF.md muc 1bq-B): BO QUY TAC CANH BAO nguoi dung tu dinh nghia. THUAN Kotlin (khong import android.*) de kiem tren JVM.
 *
 * PDF de xuat tep alerts.yaml. Khong dung YAML (them bo phan tich = them phu thuoc + be mat loi tren dien thoai): dung MOT DONG MOT QUY TAC,
 * cu phap co dinh, nguoi dung go ngay trong app, co bao loi theo dong:
 *     ten_quy_tac: chi_so  toan_tu  gia_tri  [for N(m|h|d)]  [cooldown N(m|h|d)]
 *     high_ram: ram_percent > 90 for 5m
 *     disk_full: disk_percent >= 90 cooldown 24h
 * Chi so: xem [Metric]. Toan tu: > >= < <=. "for" = dieu kien phai DUNG LIEN TUC it nhat chung do (kiem tra moi ~15 phut nen do phan giai
 * thuc te la 15 phut). "cooldown" = khoang toi thieu giua hai lan bao (mac dinh 60 phut, toi thieu 15). Dong trong va dong bat dau bang # bi bo qua.
 *
 * Bat bien an toan: gia tri KHONG DOC DUOC (null/NaN) khong bao gio gay canh bao; chi danh dau "da bao" khi tin nhan DA GUI THANH CONG
 * (caller goi [markAlerted]) nen Telegram loi thi lan sau con co co hoi bao lai.
 */
object AlertRules {
    const val MAX_RULES = 20
    const val MAX_TEXT_CHARS = 4000
    const val DEFAULT_COOLDOWN_MIN = 60
    const val MIN_COOLDOWN_MIN = 15
    const val MAX_COOLDOWN_MIN = 10080 // 7 ngay
    const val MAX_FOR_MIN = 1440        // 24 gio

    enum class Metric(val key: String, val min: Double, val max: Double) {
        DISK_PERCENT("disk_percent", 0.0, 100.0),
        BATTERY_PERCENT("battery_percent", 0.0, 100.0),
        BATTERY_TEMP_C("battery_temp_c", -20.0, 100.0),
        RAM_PERCENT("ram_percent", 0.0, 100.0),
        LOAD_AVG_1M("load_avg_1m", 0.0, 64.0),
        DATA_MONTH_MB("data_month_mb", 0.0, 10000000.0);

        companion object {
            fun byKey(k: String): Metric? {
                for (m in values()) if (m.key == k) return m
                return null
            }
        }
    }

    enum class Op(val symbol: String) {
        GT(">"), GE(">="), LT("<"), LE("<=");

        fun test(v: Double, t: Double): Boolean = when (this) {
            GT -> v > t
            GE -> v >= t
            LT -> v < t
            LE -> v <= t
        }

        companion object {
            fun bySymbol(s: String): Op? {
                for (o in values()) if (o.symbol == s) return o
                return null
            }
        }
    }

    data class Rule(
        val name: String,
        val metric: Metric,
        val op: Op,
        val threshold: Double,
        val forMinutes: Int,
        val cooldownMinutes: Int
    )

    enum class ErrorCode {
        BAD_FORMAT, BAD_NAME, DUP_NAME, UNKNOWN_METRIC, BAD_OP, BAD_NUMBER, OUT_OF_RANGE,
        BAD_DURATION, DURATION_RANGE, TOO_MANY, TOO_LONG, UNKNOWN_WORD
    }

    /** [line] la so dong (tu 1); 0 = loi toan van ban. [detail] la doan gay loi (hoac khoang hop le) de giao dien hien. */
    data class ParseError(val line: Int, val code: ErrorCode, val detail: String)

    data class ParseResult(val rules: List<Rule>, val errors: List<ParseError>)

    private val NAME_RE = Regex("[a-z0-9_]{1,32}")
    private val LINE_RE = Regex("^([^:\\s]*)\\s*:\\s*([A-Za-z0-9_]+)\\s*([<>=]{1,2})\\s*(\\S+)\\s*(.*)$")
    private val NUMBER_RE = Regex("-?[0-9]+(\\.[0-9]+)?")
    private val DUR_RE = Regex("([0-9]{1,5})([mhd])")

    fun parse(text: String): ParseResult {
        val rules = ArrayList<Rule>()
        val errors = ArrayList<ParseError>()
        if (text.length > MAX_TEXT_CHARS) {
            errors.add(ParseError(0, ErrorCode.TOO_LONG, MAX_TEXT_CHARS.toString()))
            return ParseResult(rules, errors)
        }
        val seen = HashSet<String>()
        var lineNo = 0
        for (raw in text.split('\n')) {
            lineNo++
            var body = raw.trim()
            val hash = body.indexOf('#')
            if (hash >= 0) body = body.substring(0, hash).trim()
            if (body.isEmpty()) continue
            val m = LINE_RE.matchEntire(body)
            if (m == null) {
                errors.add(ParseError(lineNo, ErrorCode.BAD_FORMAT, body))
                continue
            }
            val name = m.groupValues[1]
            val metricKey = m.groupValues[2]
            val opSym = m.groupValues[3]
            val numRaw = m.groupValues[4]
            val rest = m.groupValues[5].trim()
            if (!NAME_RE.matches(name)) {
                errors.add(ParseError(lineNo, ErrorCode.BAD_NAME, name))
                continue
            }
            if (!seen.add(name)) {
                errors.add(ParseError(lineNo, ErrorCode.DUP_NAME, name))
                continue
            }
            val metric = Metric.byKey(metricKey)
            if (metric == null) {
                errors.add(ParseError(lineNo, ErrorCode.UNKNOWN_METRIC, metricKey))
                continue
            }
            val op = Op.bySymbol(opSym)
            if (op == null) {
                errors.add(ParseError(lineNo, ErrorCode.BAD_OP, opSym))
                continue
            }
            if (!NUMBER_RE.matches(numRaw)) {
                errors.add(ParseError(lineNo, ErrorCode.BAD_NUMBER, numRaw))
                continue
            }
            val value = numRaw.toDouble()
            if (value < metric.min || value > metric.max) {
                errors.add(ParseError(lineNo, ErrorCode.OUT_OF_RANGE, formatNumber(metric.min) + ".." + formatNumber(metric.max)))
                continue
            }
            var forMin = 0
            var coolMin = DEFAULT_COOLDOWN_MIN
            var sawFor = false
            var sawCool = false
            var bad = false
            if (rest.isNotEmpty()) {
                val toks = rest.split(Regex("\\s+"))
                var i = 0
                while (i < toks.size) {
                    val word = toks[i]
                    if (word != "for" && word != "cooldown") {
                        errors.add(ParseError(lineNo, ErrorCode.UNKNOWN_WORD, word)); bad = true; break
                    }
                    if ((word == "for" && sawFor) || (word == "cooldown" && sawCool)) {
                        errors.add(ParseError(lineNo, ErrorCode.BAD_FORMAT, word)); bad = true; break
                    }
                    if (i + 1 >= toks.size) {
                        errors.add(ParseError(lineNo, ErrorCode.BAD_DURATION, word)); bad = true; break
                    }
                    val d = DUR_RE.matchEntire(toks[i + 1])
                    if (d == null) {
                        errors.add(ParseError(lineNo, ErrorCode.BAD_DURATION, toks[i + 1])); bad = true; break
                    }
                    val n = d.groupValues[1].toInt()
                    val unit = d.groupValues[2]
                    val minutes = if (unit == "m") n else if (unit == "h") n * 60 else n * 1440
                    if (word == "for") {
                        if (minutes < 0 || minutes > MAX_FOR_MIN) {
                            errors.add(ParseError(lineNo, ErrorCode.DURATION_RANGE, "0.." + MAX_FOR_MIN + "m")); bad = true; break
                        }
                        forMin = minutes; sawFor = true
                    } else {
                        if (minutes < MIN_COOLDOWN_MIN || minutes > MAX_COOLDOWN_MIN) {
                            errors.add(ParseError(lineNo, ErrorCode.DURATION_RANGE, MIN_COOLDOWN_MIN.toString() + ".." + MAX_COOLDOWN_MIN + "m")); bad = true; break
                        }
                        coolMin = minutes; sawCool = true
                    }
                    i += 2
                }
            }
            if (bad) continue
            if (rules.size >= MAX_RULES) {
                errors.add(ParseError(lineNo, ErrorCode.TOO_MANY, MAX_RULES.toString()))
                continue
            }
            rules.add(Rule(name, metric, op, value, forMin, coolMin))
        }
        return ParseResult(rules, errors)
    }

    // ----------------------------------------------------------------- danh gia

    /** [firstTrueAtMs] = luc dieu kien bat dau dung LIEN TUC (0 = dang khong dung), [lastAlertAtMs] = lan bao gan nhat (0 = chua tung). */
    data class State(val firstTrueAtMs: Long, val lastAlertAtMs: Long)

    val EMPTY_STATE = State(0L, 0L)

    data class Eval(val fire: Boolean, val state: State, val heldMinutes: Long)

    fun evaluate(rule: Rule, value: Double?, nowMs: Long, st: State): Eval {
        if (value == null || value.isNaN() || value.isInfinite()) return Eval(false, State(0L, st.lastAlertAtMs), 0L)
        if (!rule.op.test(value, rule.threshold)) return Eval(false, State(0L, st.lastAlertAtMs), 0L)
        // Moc bat dau o TUONG LAI (dong ho may bi chinh lui) -> coi nhu vua bat dau, khong bao nham.
        val first = if (st.firstTrueAtMs in 1L..nowMs) st.firstTrueAtMs else nowMs
        val held = (nowMs - first) / 60000L
        val holdOk = held >= rule.forMinutes
        val last = st.lastAlertAtMs
        val coolOk = last <= 0L || nowMs < last || nowMs - last >= rule.cooldownMinutes * 60000L
        return Eval(holdOk && coolOk, State(first, last), held)
    }

    fun markAlerted(st: State, nowMs: Long): State = State(st.firstTrueAtMs, nowMs)

    fun encodeState(st: State): String = st.firstTrueAtMs.toString() + "," + st.lastAlertAtMs

    /** "first,last"; hong/thieu -> EMPTY_STATE (khong nem loi). */
    fun decodeState(raw: String?): State {
        if (raw == null) return EMPTY_STATE
        val parts = raw.split(',')
        if (parts.size != 2) return EMPTY_STATE
        val a = parts[0].trim().toLongOrNull() ?: return EMPTY_STATE
        val b = parts[1].trim().toLongOrNull() ?: return EMPTY_STATE
        if (a < 0L || b < 0L) return EMPTY_STATE
        return State(a, b)
    }

    // ----------------------------------------------------------------- doc chi so (thuan, de kiem)

    /** Dong dau cua /proc/loadavg ("0.52 0.58 0.59 1/345 12345"): so thu nhat; null neu khong phai so hop le. */
    fun parseLoadAvg(text: String?): Double? {
        val first = text?.trim()?.split(Regex("\\s+"))?.firstOrNull() ?: return null
        val v = first.toDoubleOrNull() ?: return null
        return if (v.isNaN() || v.isInfinite() || v < 0.0) null else v
    }

    /** % RAM dang dung = (tong - con trong) / tong; null neu so lieu vo ly. */
    fun ramPercent(totalBytes: Long, availBytes: Long): Double? {
        if (totalBytes <= 0L || availBytes < 0L || availBytes > totalBytes) return null
        return (totalBytes - availBytes) * 100.0 / totalBytes
    }

    // ----------------------------------------------------------------- dinh dang

    /** 1 chu so thap phan, dau cham co dinh, khong dung ky hieu khoa hoc (1.0E7) - khong phu thuoc locale. */
    fun formatNumber(v: Double): String {
        val r = Math.round(v * 10.0)
        val neg = r < 0
        val a = if (neg) -r else r
        val s = (a / 10).toString() + "." + (a % 10)
        return if (neg) "-$s" else s
    }

    /** Noi dung Telegram (khong dau, giong cac canh bao khac). */
    fun describe(rule: Rule, value: Double, heldMinutes: Long): String =
        "quy tac canh bao '" + rule.name + "': " + rule.metric.key + " = " + formatNumber(value) +
            " (dieu kien " + rule.op.symbol + " " + formatNumber(rule.threshold) +
            (if (rule.forMinutes > 0) ", keo dai " + heldMinutes + " phut" else "") + ")."
}
