package com.wppocket.server

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log

/**
 * Mo man hinh "Tu khoi dong" / "Quan ly pin nen" RIENG cua tung hang may
 * (Xiaomi/MIUI, Oppo/ColorOS, Vivo/FuntouchOS, Huawei/EMUI, Honor,
 * Samsung/OneUI, OnePlus/OxygenOS...).
 *
 * BOI CANH: nut "Bo qua toi uu hoa pin" (Settings.ACTION_REQUEST_IGNORE_
 * BATTERY_OPTIMIZATIONS) da co san trong MainActivity CHI tat Doze/App
 * Standby cua CHINH Android goc - nhung nhieu hang tuy bien sau (MIUI,
 * ColorOS, FuntouchOS, EMUI...) co THEM 1 lop "trinh quan ly pin" RIENG cua
 * hang, nam NGOAI pham vi cua API do, van co the giet Foreground Service du
 * da duoc Android goc mien tru Doze. Khong co API chinh thuc nao cua Google
 * de tat lop nay - cac ComponentName duoi day la quy uoc KHONG CHINH THUC,
 * duoc cong dong dev Android xac nhan qua nhieu nam (vd thu vien mo
 * github.com/csq20081052/AutoStarter, github.com/juanamd/react-native-
 * battery-whitelist) - CO THE gay ActivityNotFoundException tren mot so
 * phien ban ROM cu the (hang doi ten package/activity giua cac ban cap
 * nhat) nen PHAI thu tung Intent trong try/catch, khong duoc gia dinh
 * chac chan hoat dong tren MOI may cung 1 hang.
 *
 * Day la "best-effort": khong tim thay man hinh rieng thi tu rot ve man
 * hinh chi tiet ung dung chuan cua Android (luon ton tai, luon mo duoc) roi
 * bao cho nguoi dung tu tim muc Pin/Tu khoi dong - KHONG BAO GIO de nguoi
 * dung gap crash hay man hinh trang.
 */
object OemBattery {
    private const val TAG = "WPPocketServer"

    /**
     * Danh sach (co the >1) ComponentName ung vien cho tung hang - thu lan
     * luot tu tren xuong, dung Intent dau tien mo duoc. Nhieu hang co >1
     * dong bien the (doi ten package/activity giua cac ban EMUI/ColorOS/
     * FuntouchOS khac nhau qua cac nam) nen liet ke du phong thay vi 1 dong
     * duy nhat.
     */
    private val candidatesByManufacturer: Map<String, List<Pair<String, String>>> = mapOf(
        "xiaomi" to listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity"
        ),
        "redmi" to listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity"
        ),
        "oppo" to listOf(
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity"
        ),
        "realme" to listOf(
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity"
        ),
        "vivo" to listOf(
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager",
            "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"
        ),
        "huawei" to listOf(
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.optimize.process.ProtectActivity"
        ),
        "honor" to listOf(
            // Honor tach khoi Huawei tu 2020 - vai may Honor doi (moi hon)
            // dung package "com.hihonor.systemmanager" thay vi cua Huawei,
            // nen thu ca 2. CHUA verify tren thiet bi Honor that.
            "com.hihonor.systemmanager" to "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.optimize.process.ProtectActivity"
        ),
        "samsung" to listOf(
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity",
            "com.samsung.android.lool" to "com.samsung.android.sm.battery.ui.BatteryActivity",
            "com.samsung.android.sm" to "com.samsung.android.sm.ui.battery.BatteryActivity"
        ),
        "oneplus" to listOf(
            "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"
        ),
        "letv" to listOf(
            "com.letv.android.letvsafe" to "com.letv.android.letvsafe.AutobootManageActivity"
        )
    )

    /**
     * Thu mo man hinh rieng cua hang. Tra ve true neu mo duoc 1 Intent bat
     * ky trong danh sach ung vien; false neu khong tim thay hang nay trong
     * danh sach HOAC tat ca Intent ung vien deu khong mo duoc (may nay
     * khong co app do, hoac hang da doi ten package/activity) - luc do noi
     * goi (MainActivity) nen tu rot ve openAppDetailsSettings() ben duoi.
     */
    fun tryOpenManufacturerAutostartSettings(context: Context): Boolean {
        val manufacturer = Build.MANUFACTURER?.lowercase() ?: return false
        val candidates = candidatesByManufacturer.entries
            .firstOrNull { (key, _) -> manufacturer.contains(key) }
            ?.value ?: return false

        for ((pkg, cls) in candidates) {
            try {
                val intent = Intent().apply {
                    component = ComponentName(pkg, cls)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return true
            } catch (e: ActivityNotFoundException) {
                Log.d(TAG, "OEM autostart intent khong ton tai: $pkg/$cls, thu ung vien tiep theo")
            } catch (e: SecurityException) {
                Log.d(TAG, "OEM autostart intent bi tu choi quyen: $pkg/$cls, thu ung vien tiep theo")
            }
        }
        return false
    }

    /**
     * Du phong CUOI CUNG - man hinh chi tiet ung dung chuan cua Android,
     * hang nao cung co, khong bao gio ActivityNotFoundException. Nguoi
     * dung tu tim muc Pin/Battery trong nay (ten muc khac nhau tuy hang,
     * khong the mo thang duoc bang code).
     */
    fun openAppDetailsSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
