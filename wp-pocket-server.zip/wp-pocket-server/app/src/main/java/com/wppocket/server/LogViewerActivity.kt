package com.wppocket.server

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.wppocket.server.databinding.ActivityLogViewerBinding
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Xem log NGAY TRONG APP, doc thang tu file tren dia - KHONG can nginx/
 * php-fpm dang chay (khac han _admin/logs.php, von la trang WEB nen can
 * chinh web server con song moi mo duoc - vo tac dung dung luc can chan
 * doan NHAT la luc web server khong len duoc).
 *
 * Sinh ra tu phan hoi nguoi dung that: bam "Bat server" xong "im lim",
 * khong co cach nao trong app tu xem duoc ly do - man hinh nay lap dung
 * lo hong do. 8/9 log dau dong bo voi _admin/logs.php (xem admin-logs.php)
 * de nguoi dung quen 1 trong 2 khong bi lac - rieng "crash-log.txt" (xem
 * CrashLogger.kt) CHI co o day, vi la crash cua chinh app Kotlin, khong
 * lien quan LAMP stack nen trang web _admin/ khong doc duoc.
 */
class LogViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLogViewerBinding

    /** Noi dung log THO vua doc tu file (chua loc) - o loc chi doi phan hien thi. */
    private var rawLog: String = ""

    /** (nhan hien thi, duong dan TUONG DOI so voi filesDir) - dung dung thu
     * tu va duong dan nhu admin-logs.php de 2 noi luon khop nhau. */
    private val logEntries = listOf(
        "start-lamp.sh (tong quan khoi dong - xem DAU TIEN neu server khong len)" to "start-lamp-stdout.log",
        "Nginx - loi" to "lamp-run/nginx-error.log",
        "Nginx - truy cap" to "lamp-run/nginx-access.log",
        "PHP-FPM" to "lamp-run/php-fpm.log",
        "PHP - loi" to "lamp-run/php-error.log",
        "MariaDB" to "lamp-run/mysqld.log",
        "MariaDB - truy van cham (> 2 giay)" to "lamp-run/mysql-slow.log",
        "nginx phia truoc - loi (Node/Python/static)" to "generic-run/nginx-front-error.log",
        "MariaDB - cai dat (chi co lan dau)" to "lamp-run/mysql-install.log",
        // Them cung luc voi tinh nang chong do mat khau trang quan tri (xem
        // admin-auth.php, HANDOFF.md muc 10) - ghi ai dang nhap dung/sai/bi
        // khoa tam luc nao. Giu dong bo voi admin-logs.php (_admin/logs.php)
        // dung theo comment class nay da ghi ("cung danh sach 7 log" - gio
        // thanh 8).
        "Dang nhap trang quan tri" to "lamp-run/admin-audit.log",
        // Them cung CrashLogger.kt (de xuat DeepSeek muc K8) - RIENG log nay
        // KHONG nam trong "lamp-run/" nhu 7 log con lai (do khong lien quan
        // LAMP stack - la crash cua CHINH app Kotlin) nen KHONG dong bo voi
        // admin-logs.php (trang do chay TRONG web server, khong doc duoc
        // file cua tien trinh app Android chua no). "8 log" o comment tren
        // gio thanh 9, nhung chi 8 cai con lai dong bo 2 ben.
        "App bi crash (Kotlin) - chi co neu tung xay ra" to "crash-log.txt"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        title = getString(R.string.log_viewer_title)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            logEntries.map { it.first }
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerLogType.adapter = adapter

        binding.spinnerLogType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                loadLog(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnRefreshLog.setOnClickListener {
            loadLog(binding.spinnerLogType.selectedItemPosition)
        }

        binding.etLogFilter.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                applyFilter()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnShareLog.setOnClickListener { shareLog() }
        binding.btnReportIssue.setOnClickListener { reportIssue() }

        binding.btnCopyLog.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", binding.tvLogContent.text))
            Toast.makeText(this, R.string.toast_log_copied, Toast.LENGTH_SHORT).show()
        }

        loadLog(0)
    }

    private fun loadLog(position: Int) {
        if (position < 0 || position >= logEntries.size) return
        val (_, relativePath) = logEntries[position]
        val file = File(filesDir, relativePath)
        rawLog = tailFile(file)
        applyFilter()
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        binding.tvLogMeta.text = getString(R.string.log_viewer_meta, file.absolutePath, time)
    }

    /** Chi hien cac dong CO CHUA tu khoa (khong phan biet hoa thuong); de trong thi hien het. */
    private fun applyFilter() {
        val q = binding.etLogFilter.text.toString().trim()
        if (q.isEmpty()) {
            binding.tvLogContent.text = rawLog
            return
        }
        val matched = rawLog.lines().filter { it.contains(q, ignoreCase = true) }
        binding.tvLogContent.text =
            if (matched.isEmpty()) getString(R.string.log_filter_none, q) else matched.joinToString("\n")
    }

    /** Chia se noi dung DANG HIEN THI (da loc) qua Intent.ACTION_SEND chuan - giong nut chia se URL o MainActivity. */
    /**
     * K5 (HANDOFF.md muc 1br): mo form Issue GitHub dien san phien ban app + mau may. KHONG gui nhat ky/IP/token (xem IssueLink); nguoi dung tu dan nhat ky da che.
     * Kho lay tu assets/update-repo.txt (CI ghi); build tay khong co -> bao ro, khong doan URL.
     */
    private fun reportIssue() {
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
        val device = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + ", Android " + android.os.Build.VERSION.RELEASE
        val url = IssueLink.url(UpdateChecker.readRepo(this), version, device)
        if (url == null) {
            Toast.makeText(this, R.string.report_issue_no_repo, Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, R.string.report_issue_redact_hint, Toast.LENGTH_LONG).show()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
        } catch (_: Exception) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("issue_url", url))
            Toast.makeText(this, R.string.report_issue_copied, Toast.LENGTH_LONG).show()
        }
    }

    private fun shareLog() {
        val shown = binding.tvLogContent.text.toString()
        // Gioi han de tranh TransactionTooLargeException khi file log co dong rat dai (Binder ~1MB).
        val body = if (shown.length > 200_000) shown.takeLast(200_000) else shown
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, getString(R.string.log_share_subject))
            putExtra(Intent.EXTRA_TEXT, body)
        }
        try {
            startActivity(Intent.createChooser(intent, getString(R.string.btn_share_log)))
        } catch (_: Exception) {
            // Khong mo duoc bang chon ung dung (hiem): chep vao clipboard de nguoi dung van gui duoc - thong bao "da chep" khi do dung su that.
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", body))
            Toast.makeText(this, R.string.toast_log_copied, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Doc toi da 300 dong CUOI CUNG cua file, gioi han doc toi da 512KB tu
     * cuoi file len (dung RandomAccessFile.seek() - tranh phai nap ca file
     * vao RAM neu file nao do lo phinh to bat thuong, vd log truy cap chay
     * lau ngay khong dung Auto-Sleep).
     */
    private fun tailFile(file: File, maxLines: Int = 300, maxBytes: Long = 512 * 1024): String {
        if (!file.exists()) {
            return getString(R.string.log_viewer_missing_file)
        }
        return try {
            val length = file.length()
            if (length == 0L) return getString(R.string.log_viewer_empty_file)
            val readFrom = (length - maxBytes).coerceAtLeast(0L)
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(readFrom)
                val bytes = ByteArray((length - readFrom).toInt())
                raf.readFully(bytes)
                val text = String(bytes, Charsets.UTF_8)
                val lines = text.lines()
                val tail = if (lines.size > maxLines) lines.takeLast(maxLines) else lines
                tail.joinToString("\n")
            }
        } catch (e: Exception) {
            getString(R.string.log_viewer_read_error, e.message ?: e.toString())
        }
    }
}
