package com.wppocket.server

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.wppocket.server.databinding.ActivityLogViewerBinding
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Xem log NGAY TRONG APP, doc thang tu file tren dia - KHONG can nginx/
 * php-fpm dang chay (khac han _admin/logs.php, von la trang WEB nen can
 * chinh web server con song moi mo duoc - vo tac dung dung luc can chan
 * doan NHAT la luc web server khong len duoc).
 *
 * Sinh ra tu phan hoi nguoi dung that: bam "Bat server" xong "im lim",
 * khong co cach nao trong app tu xem duoc ly do - man hinh nay lap dung
 * lo hong do. Cung danh sach 7 log y het _admin/logs.php (xem
 * admin-logs.php) de nguoi dung quen 1 trong 2 khong bi lac.
 */
class LogViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLogViewerBinding

    /** (nhan hien thi, duong dan TUONG DOI so voi filesDir) - dung dung thu
     * tu va duong dan nhu admin-logs.php de 2 noi luon khop nhau. */
    private val logEntries = listOf(
        "start-lamp.sh (tong quan khoi dong - xem DAU TIEN neu server khong len)" to "start-lamp-stdout.log",
        "Nginx - loi" to "lamp-run/nginx-error.log",
        "Nginx - truy cap" to "lamp-run/nginx-access.log",
        "PHP-FPM" to "lamp-run/php-fpm.log",
        "PHP - loi" to "lamp-run/php-error.log",
        "MariaDB" to "lamp-run/mysqld.log",
        "MariaDB - cai dat (chi co lan dau)" to "lamp-run/mysql-install.log",
        // Them cung luc voi tinh nang chong do mat khau trang quan tri (xem
        // admin-auth.php, HANDOFF.md muc 10) - ghi ai dang nhap dung/sai/bi
        // khoa tam luc nao. Giu dong bo voi admin-logs.php (_admin/logs.php)
        // dung theo comment class nay da ghi ("cung danh sach 7 log" - gio
        // thanh 8).
        "Dang nhap trang quan tri" to "lamp-run/admin-audit.log"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        title = getString(R.string.log_viewer_title)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            logEntries.map { it.first }
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerLogType.adapter = adapter

        binding.spinnerLogType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                loadLog(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnRefreshLog.setOnClickListener {
            loadLog(binding.spinnerLogType.selectedItemPosition)
        }

        binding.btnCopyLog.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", binding.tvLogContent.text))
            Toast.makeText(this, R.string.toast_log_copied, Toast.LENGTH_SHORT).show()
        }

        loadLog(0)
    }

    private fun loadLog(position: Int) {
        if (position < 0 || position >= logEntries.size) return
        val (_, relativePath) = logEntries[position]
        val file = File(filesDir, relativePath)
        binding.tvLogContent.text = tailFile(file)
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        binding.tvLogMeta.text = getString(R.string.log_viewer_meta, file.absolutePath, time)
    }

    /**
     * Doc toi da 300 dong CUOI CUNG cua file, gioi han doc toi da 512KB tu
     * cuoi file len (dung RandomAccessFile.seek() - tranh phai nap ca file
     * vao RAM neu file nao do lo phinh to bat thuong, vd log truy cap chay
     * lau ngay khong dung Auto-Sleep).
     */
    private fun tailFile(file: File, maxLines: Int = 300, maxBytes: Long = 512 * 1024): String {
        if (!file.exists()) {
            return getString(R.string.log_viewer_missing_file)
        }
        return try {
            val length = file.length()
            if (length == 0L) return getString(R.string.log_viewer_empty_file)
            val readFrom = (length - maxBytes).coerceAtLeast(0L)
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(readFrom)
                val bytes = ByteArray((length - readFrom).toInt())
                raf.readFully(bytes)
                val text = String(bytes, Charsets.UTF_8)
                val lines = text.lines()
                val tail = if (lines.size > maxLines) lines.takeLast(maxLines) else lines
                tail.joinToString("\n")
            }
        } catch (e: Exception) {
            getString(R.string.log_viewer_read_error, e.message ?: e.toString())
        }
    }
}
