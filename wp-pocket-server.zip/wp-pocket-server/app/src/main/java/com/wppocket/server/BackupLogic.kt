package com.wppocket.server

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.Files
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Phan LOGIC THUAN (khong import android.*) cua nhap/xuat/khoi phuc backup -
 * tach rieng de kiem thu that tren JVM (scripts/tests/BackupLogicTest.kt),
 * giong cach MonitorLogic duoc tach khoi Monitoring (HANDOFF.md muc 1au).
 * Phan keo Android (mo Uri, goi mysqldump, hop thoai) van nam o
 * BackupManager / MainActivity.
 *
 * Ra doi tu 2 LOI THAT tim thay khi doc code o vong 21 (HANDOFF.md muc 1az):
 *
 *  1) ZIP SLIP: performRestore() ghep thang ten entry trong zip vao thu muc
 *     www/ (File(wwwDir, relativePath)) ma khong kiem tra - entry ten
 *     "www/../../x" ghi duoc RA NGOAI www/. Truoc day chi restore file do
 *     CHINH APP tao nen rui ro thap; nhung khi cho nguoi dung CHON ZIP TUY Y
 *     tu trinh chon file (J1-J3) thi day la lo hong that.
 *
 *  2) verifyBackupZip() KHONG bat duoc du lieu hong: chu thich cu khang dinh
 *     doc het entry qua java.util.zip.ZipFile "tu dong nem loi CRC", nhung
 *     thuc nghiem (JDK 21) cho thay ZipFile KHONG kiem CRC - chi
 *     ZipInputStream moi kiem. Backup bi lat bit van "xac minh OK". Ở day CRC
 *     duoc TU TINH va doi chieu voi CRC trong central directory.
 */
object BackupLogic {

    // ------------------------------------------------------------------
    // Zip thu muc www/ KHONG THEO SYMLINK (HANDOFF.md muc 1bj)
    // ------------------------------------------------------------------

    /** true neu [f] chinh la symlink (khong phai thu muc/tep that). */
    fun isSymlink(f: File): Boolean = Files.isSymbolicLink(f.toPath())

    /**
     * Zip de quy [dir] vao [zos] voi tien to [base], BO QUA symlink. Hai ly do:
     *  1) AN TOAN: plugin/theme (hoac nguoi dung) tao symlink toi tep NGOAI www/ (vd filesDir/admin-password.txt) - neu theo symlink, backup
     *     (co the duoc gui qua Telegram/webhook) chua noi dung tep do. Theo symlink = doc tep ngoai pham vi site.
     *  2) start-generic.sh dung symlink lib-dynload/<ten>.so -> nativeLibDir/libpydyn_<ten>.so (runtime Python; khong viet dau sao-gach cheo vi Kotlin cho chu thich long nhau): theo symlink se nuot hang chuc MB
     *     thu vien vao moi ban backup. Symlink do duoc dung lai moi lan khoi dong nen khong can sao luu.
     */
    fun zipDir(dir: File, base: String, zos: ZipOutputStream) {
        dir.listFiles()?.forEach { f ->
            if (isSymlink(f)) return@forEach
            val entryName = "$base/${f.name}"
            if (f.isDirectory) {
                zipDir(f, entryName, zos)
            } else {
                zos.putNextEntry(ZipEntry(entryName))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    /** Tong dung luong tep that trong [dir] (cung quy tac: bo qua symlink) - dung de uoc luong dung luong can cho backup. */
    fun dirSize(dir: File): Long {
        if (!dir.exists()) return 0L
        var total = 0L
        dir.listFiles()?.forEach { f ->
            if (isSymlink(f)) return@forEach
            total += if (f.isDirectory) dirSize(f) else f.length()
        }
        return total
    }

    // ------------------------------------------------------------------
    // Nhan dien loai file (khong tin duoi file: nguoi dung co the doi ten)
    // ------------------------------------------------------------------

    enum class FileKind { PLAIN_ZIP, ENCRYPTED_OR_UNKNOWN, TOO_SMALL }

    /** Dinh dang ma hoa cua BackupManager.encryptBackupFile:
     * [16 salt][12 iv][ciphertext + 16 tag GCM] -> toi thieu 44 byte. */
    const val MIN_ENCRYPTED_BYTES = 16 + 12 + 16

    fun sniffKind(head: ByteArray, length: Long): FileKind {
        if (length < 4) return FileKind.TOO_SMALL
        // Chu ky local file header cua zip: "PK\u0003\u0004"
        if (head.size >= 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte() &&
            head[2] == 0x03.toByte() && head[3] == 0x04.toByte()
        ) return FileKind.PLAIN_ZIP
        if (length < MIN_ENCRYPTED_BYTES) return FileKind.TOO_SMALL
        return FileKind.ENCRYPTED_OR_UNKNOWN
    }

    fun sniffKind(file: File): FileKind {
        val head = ByteArray(4)
        val n = FileInputStream(file).use { it.read(head) }
        return sniffKind(if (n < 0) ByteArray(0) else head.copyOf(n), file.length())
    }

    // ------------------------------------------------------------------
    // Chong Zip Slip
    // ------------------------------------------------------------------

    /** Ten entry zip co "an toan" khong: khong rong, khong byte null, khong
     * tuyet doi, khong co thanh phan "..", khong ky tu dieu khien. Kiem tra
     * theo CA '/' LAN '\\' (zip tao tren Windows). */
    fun isSafeEntryName(name: String): Boolean {
        if (name.isEmpty() || name.length > 4096) return false
        if (name.any { it.code < 0x20 }) return false
        if (name.startsWith("/") || name.startsWith("\\")) return false
        if (name.length >= 2 && name[1] == ':') return false // "C:..."
        return name.split('/', '\\').none { it == ".." }
    }

    /**
     * Ghep [relative] vao [base] va tra ve file DA CHUAN HOA chi khi ket qua
     * nam TRONG [base]; nguoc lai null. Dung canonicalFile nen cung chan
     * ca duong ra ngoai qua symlink co san trong cay thu muc dich.
     */
    fun resolveInside(base: File, relative: String): File? {
        if (!isSafeEntryName(relative)) return null
        val baseCanon = base.canonicalFile
        val dest = File(baseCanon, relative).canonicalFile
        val b = baseCanon.path
        return if (dest.path == b || dest.path.startsWith(b + File.separator)) dest else null
    }

    // ------------------------------------------------------------------
    // Kiem tra backup TRUOC KHI dung vao du lieu that
    // ------------------------------------------------------------------

    data class Inspection(
        val ok: Boolean,
        val reason: String,
        val wwwFiles: Int = 0,
        val hasDb: Boolean = false,
        val uncompressedBytes: Long = 0L,
    )

    private const val DB_TAIL_BYTES = 2048
    private const val DB_TRAILER = "-- Dump completed"

    // ======================================================================================================
    // H1 (PDF 2 muc H1, HANDOFF 1bm): KHOI PHUC THU backup vao database TAM de biet backup co dung duoc that khong.
    // Phan thuan (khong android) o day: lay database.sql ra, DOI TEN database trong dump sang ten database tam, TU CHOI dump chua lenh
    // nguy hiem. Lop bao ve CHINH khong nam o day ma o MariaDB: BackupVerifier nap bang 1 user chi co quyen tren database tam, nen du dump
    // co "USE wordpress"/"DROP ..." thi chinh server tu choi. Lop loc nay la lop thu hai (bat som, giai thich ly do cho nguoi dung).
    // ======================================================================================================

    enum class DumpLineKind { PASS, USE_DB, CREATE_DB, DANGEROUS, UNSUPPORTED }

    data class VerifyRewrite(val ok: Boolean, val reason: String = "", val rewritten: Int = 0, val unsupported: Boolean = false)

    private const val VERIFY_HEAD_BYTES = 160
    private val COND_COMMENT_PREFIX = Regex("^/\\*M?!\\d*\\s*")
    private val DANGEROUS_PREFIXES = listOf(
        "DROP DATABASE", "DROP SCHEMA", "ALTER DATABASE", "ALTER SCHEMA", "CREATE USER", "DROP USER", "ALTER USER", "GRANT ", "REVOKE ",
        "SET PASSWORD", "SHUTDOWN", "KILL ", "LOAD DATA", "RENAME ", "INSTALL ", "UNINSTALL ", "FLUSH ", "CREATE SERVER", "DROP SERVER",
        "SYSTEM ", "SOURCE ", "CREATE FUNCTION", "CREATE AGGREGATE",
    )

    /** Ten database tam hop le: 1..40 ky tu ASCII chu/so/gach duoi (dung de ghep vao cau lenh nen phai chat). */
    fun isSafeDbIdent(s: String): Boolean = s.isNotEmpty() && s.length <= 40 && s.all { (it in 'a'..'z') || (it in 'A'..'Z') || (it in '0'..'9') || it == '_' }

    /**
     * Phan loai 1 dong dump theo DAU DONG (toi da 160 byte dau). Chi xet tien to nen dong du lieu "INSERT INTO ..." chua chu "DROP
     * DATABASE" trong noi dung bai viet van la PASS. Lenh cua CLIENT mysql (bat dau bang dau gach cheo nguoc: \! chay shell, \. nap file)
     * coi la nguy hiem. DELIMITER / CREATE ... DEFINER= (trigger, view) -> UNSUPPORTED: user han che khong dat duoc DEFINER nen nap
     * se hong; khong phai loi cua backup -> bao "bo qua" chu khong bao "that bai".
     */
    fun classifyDumpHead(head: String): DumpLineKind {
        val t = head.trimStart()
        if (t.startsWith("\\")) return DumpLineKind.DANGEROUS
        val u = COND_COMMENT_PREFIX.replaceFirst(t, "").trimStart().uppercase()
        if (u.startsWith("USE ")) return DumpLineKind.USE_DB
        if (u.startsWith("CREATE DATABASE") || u.startsWith("CREATE SCHEMA")) return DumpLineKind.CREATE_DB
        if (DANGEROUS_PREFIXES.any { u.startsWith(it) }) return DumpLineKind.DANGEROUS
        if (u.startsWith("DELIMITER") || (u.startsWith("CREATE") && u.contains("DEFINER="))) return DumpLineKind.UNSUPPORTED
        return DumpLineKind.PASS
    }

    /**
     * Tien to bang WordPress tu danh sach ten bang: tien to p sao cho CA "${p}options" LAN "${p}posts" cung ton tai (chon tien to NGAN
     * nhat de bang cua plugin kieu "wp_woo_options" khong danh lua). null neu khong co cap nao hoac tien to khong an toan de ghep vao SQL.
     */
    fun pickWpPrefix(tables: Collection<String>): String? {
        val set = tables.toHashSet()
        return tables.filter { it.endsWith("options") }
            .map { it.removeSuffix("options") }
            .filter { set.contains(it + "posts") && (it.isEmpty() || isSafeDbIdent(it)) }
            .minByOrNull { it.length }
    }

    /** Ghi database.sql trong [zip] ra [out]; false neu zip khong co dump. */
    fun extractDbDump(zip: File, out: File): Boolean {
        ZipFile(zip).use { zf ->
            val e = zf.getEntry("database.sql") ?: return false
            zf.getInputStream(e).use { ins -> FileOutputStream(out).use { ins.copyTo(it) } }
            return true
        }
    }

    fun zipHasEntry(zip: File, name: String): Boolean = ZipFile(zip).use { it.getEntry(name) != null }

    /**
     * Chep [input] sang [output] THEO LUONG (khong nap ca file; dong "INSERT" dai hang MB di thang qua), chi thay 2 loai dong NGAN:
     * "USE `x`;" -> "USE `verifyDb`;" va "CREATE DATABASE ... `x` ...;" -> "CREATE DATABASE IF NOT EXISTS `verifyDb`;". Moi byte khac
     * giu nguyen (kể ca UTF-8). Gap lenh nguy hiem -> ok=false; gap DELIMITER/DEFINER -> ok=false + unsupported=true.
     */
    fun rewriteDumpForVerify(input: File, output: File, verifyDb: String): VerifyRewrite {
        if (!isSafeDbIdent(verifyDb)) return VerifyRewrite(false, "Ten database tam khong hop le")
        var rewritten = 0
        BufferedInputStream(FileInputStream(input), 1 shl 16).use { ins ->
            BufferedOutputStream(FileOutputStream(output), 1 shl 16).use { outs ->
                val head = ByteArray(VERIFY_HEAD_BYTES)
                while (true) {
                    var n = 0
                    var complete = false          // da gap \n hoac het file trong khoang dau dong
                    while (n < head.size) {
                        val b = ins.read()
                        if (b < 0) { complete = true; break }
                        head[n++] = b.toByte()
                        if (b == '\n'.code) { complete = true; break }
                    }
                    if (n == 0) break
                    when (classifyDumpHead(String(head, 0, n, Charsets.ISO_8859_1))) {
                        DumpLineKind.DANGEROUS -> return VerifyRewrite(false, "Dump chua lenh nguy hiem (DROP DATABASE/GRANT/lenh client...) - khong nap thu")
                        DumpLineKind.UNSUPPORTED -> return VerifyRewrite(false, "Dump co trigger/view/DELIMITER - khong nap thu duoc bang user han che", rewritten, unsupported = true)
                        DumpLineKind.USE_DB -> {
                            if (!complete) return VerifyRewrite(false, "Dong USE bat thuong (qua dai)")
                            outs.write("USE `$verifyDb`;\n".toByteArray(Charsets.ISO_8859_1)); rewritten++
                        }
                        DumpLineKind.CREATE_DB -> {
                            if (!complete) return VerifyRewrite(false, "Dong CREATE DATABASE bat thuong (qua dai)")
                            outs.write("CREATE DATABASE IF NOT EXISTS `$verifyDb`;\n".toByteArray(Charsets.ISO_8859_1)); rewritten++
                        }
                        DumpLineKind.PASS -> {
                            outs.write(head, 0, n)
                            val endedWithNewline = n > 0 && head[n - 1] == '\n'.code.toByte()
                            if (!endedWithNewline && n == head.size) {
                                // dong dai: chuyen tiep phan con lai den het dong ma KHONG gom vao bo nho
                                while (true) {
                                    val b = ins.read()
                                    if (b < 0) break
                                    outs.write(b)
                                    if (b == '\n'.code) break
                                }
                            }
                        }
                    }
                }
            }
        }
        return VerifyRewrite(true, "", rewritten)
    }

    /**
     * H1 (PDF 2, HANDOFF 1bl): quet database.sql THEO LUONG (khong nap ca file) de biet no co cau truc cua WordPress hay khong -
     * "co dong Dump completed" chi chung minh mysqldump chay den cuoi, KHONG chung minh dump khong rong/khong sai database.
     * Ghi nhan ten bang tu "CREATE TABLE `x`" va viec co "INSERT INTO `...options`" (WordPress luon co dong trong bang options).
     * Doc byte theo ISO-8859-1 (1 byte = 1 ky tu, khong bao gio hong o ranh gioi khoi) va giu [CARRY] ky tu cuoi cua khoi
     * truoc de bat ca mau bi cat doi giua 2 khoi doc.
     */
    class DumpScanner {
        val tables = HashSet<String>()
        var optionsInserted = false
            private set
        private var carry = ""

        fun feed(buf: ByteArray, len: Int) {
            if (len <= 0) return
            val text = carry + String(buf, 0, len, Charsets.ISO_8859_1)
            for (m in CREATE_TABLE_RE.findAll(text)) tables.add(m.groupValues[1])
            if (!optionsInserted && INSERT_OPTIONS_RE.containsMatchIn(text)) optionsInserted = true
            carry = if (text.length > CARRY) text.substring(text.length - CARRY) else text
        }

        /** Co du bang loi cua WordPress (...options VA ...posts) va it nhat 1 dong du lieu trong options khong. */
        fun looksLikeWordPress(): Boolean =
            tables.any { it.endsWith("options") } && tables.any { it.endsWith("posts") } && optionsInserted

        private companion object {
            const val CARRY = 300
            val CREATE_TABLE_RE = Regex("CREATE TABLE (?:IF NOT EXISTS )?`([^`\\r\\n]{1,64})`")
            val INSERT_OPTIONS_RE = Regex("INSERT INTO `[^`\\r\\n]{0,60}options`")
        }
    }
    const val DEFAULT_MAX_ENTRIES = 300_000

    /**
     * Doc HET tung entry, TU TINH CRC32 + kich thuoc roi doi chieu voi central
     * directory (xem muc 2 o dau file). Tu choi neu:
     *  - khong mo duoc / khong phai zip;
     *  - co ten entry khong an toan (Zip Slip) - tu choi CA FILE;
     *  - qua nhieu entry (chong zip-bomb dang "hang trieu file nho");
     *  - CRC/kich thuoc khong khop;
     *  - khong co file nao duoi www/ (khong phai backup cua app nay);
     *  - co database.sql nhung thieu dong ket thuc chuan cua mysqldump.
     * [maxUncompressedBytes] > 0: tu choi neu tong dung luong sau giai nen
     * vuot nguong (nguoi goi dat = dung luong trong con lai, tru bien an toan).
     */
    fun inspect(zip: File, maxUncompressedBytes: Long = 0L, maxEntries: Int = DEFAULT_MAX_ENTRIES): Inspection {
        if (!zip.exists() || zip.length() == 0L) return Inspection(false, "File khong ton tai hoac rong")
        var wwwFiles = 0
        var hasDb = false
        var dbTrailerOk = true
        var isWordPress = false
        var dbScan: DumpScanner? = null
        var total = 0L
        var count = 0
        try {
            ZipFile(zip).use { zf ->
                val buf = ByteArray(64 * 1024)
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    count++
                    if (count > maxEntries) return Inspection(false, "Zip co qua nhieu muc (>$maxEntries)")
                    if (!isSafeEntryName(e.name)) {
                        return Inspection(false, "Zip chua duong dan KHONG AN TOAN (co the nham ghi ra ngoai thu muc website), tu choi")
                    }
                    if (e.isDirectory) continue
                    val crc = CRC32()
                    var size = 0L
                    var tail = ByteArray(0)
                    val isDb = e.name == "database.sql"
                    if (e.name == "www/wp-config.php" || e.name == "www/wp-includes/version.php") isWordPress = true
                    val scanner = if (isDb) DumpScanner() else null
                    zf.getInputStream(e).use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            crc.update(buf, 0, n)
                            size += n
                            if (maxUncompressedBytes > 0 && total + size > maxUncompressedBytes) {
                                return Inspection(false, "Giai nen se vuot dung luong trong con lai tren may")
                            }
                            if (isDb) {
                                scanner?.feed(buf, n)
                                val merged = tail + buf.copyOfRange(0, n)
                                tail = if (merged.size > DB_TAIL_BYTES) merged.copyOfRange(merged.size - DB_TAIL_BYTES, merged.size) else merged
                            }
                        }
                    }
                    if (e.crc != -1L && crc.value != e.crc) {
                        return Inspection(false, "Du lieu bi hong (sai CRC o muc '${e.name}')")
                    }
                    if (e.size >= 0 && size != e.size) {
                        return Inspection(false, "Du lieu bi hong (sai kich thuoc o muc '${e.name}')")
                    }
                    total += size
                    if (isDb) {
                        hasDb = true
                        dbTrailerOk = String(tail, Charsets.UTF_8).contains(DB_TRAILER)
                        dbScan = scanner
                    } else if (e.name.startsWith("www/")) {
                        wwwFiles++
                    }
                }
            }
        } catch (e: java.util.zip.ZipException) {
            return Inspection(false, "Khong phai file zip hop le hoac bi hong (${e.message ?: e.javaClass.simpleName})")
        } catch (e: IOException) {
            return Inspection(false, "Khong doc duoc file (${e.javaClass.simpleName})")
        }
        if (wwwFiles == 0) return Inspection(false, "Khong phai backup cua WP Pocket Server (khong co thu muc www/)")
        if (hasDb && !dbTrailerOk) return Inspection(false, "Ban dump database bi cut giua chung (thieu dong ket thuc cua mysqldump)")
        if (hasDb && isWordPress && dbScan?.looksLikeWordPress() != true) {
            return Inspection(false, "Ban dump database khong co bang WordPress co ban (...options/...posts) hoac rong - dump sai database hoac loi, KHONG dung duoc de khoi phuc")
        }
        return Inspection(true, "OK", wwwFiles, hasDb, total)
    }

    /** File .sql roi (khong nam trong zip) co dong ket thuc chuan cua mysqldump o cuoi khong
     * (mysqldump bi kill giua chung se thieu dong nay). Chi doc ~2KB cuoi. */
    fun dumpLooksComplete(dump: File): Boolean {
        if (!dump.isFile || dump.length() == 0L) return false
        java.io.RandomAccessFile(dump, "r").use { raf ->
            val n = minOf(raf.length(), DB_TAIL_BYTES.toLong()).toInt()
            val b = ByteArray(n)
            raf.seek(raf.length() - n)
            raf.readFully(b)
            return String(b, Charsets.UTF_8).contains(DB_TRAILER)
        }
    }

    // ------------------------------------------------------------------
    // Trich xuat AN TOAN
    // ------------------------------------------------------------------

    class UnsafeEntryException(message: String) : Exception(message)

    data class Extracted(val filesRestored: Int, val dbDumpFile: File?)

    /**
     * Giai nen toan bo www/... vao [wwwDir] va database.sql ra [sqlOut]. Moi file ghi vao
     * ".wpp-tmp" cung thu muc roi doi ten -> neu ZipInputStream phat hien CRC sai
     * o cuoi entry thi file do KHONG bao gio thay the ban dang co. Nen goi
     * [inspect] truoc; ham nay van tu bao ve (phong thu 2 lop).
     */
    fun extract(zip: File, wwwDir: File, sqlOut: File): Extracted {
        var restored = 0
        var db: File? = null
        ZipInputStream(FileInputStream(zip)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                when {
                    name == "database.sql" && !entry.isDirectory -> {
                        sqlOut.parentFile?.mkdirs()
                        FileOutputStream(sqlOut).use { zis.copyTo(it) }
                        db = sqlOut
                    }
                    name.startsWith("www/") && !entry.isDirectory -> {
                        val rel = name.removePrefix("www/")
                        if (rel.isNotEmpty()) {
                            val dest = resolveInside(wwwDir, rel)
                                ?: throw UnsafeEntryException("Duong dan khong an toan trong zip: $name")
                            dest.parentFile?.mkdirs()
                            val tmp = File(dest.parentFile, dest.name + ".wpp-tmp")
                            try {
                                FileOutputStream(tmp).use { zis.copyTo(it) }
                                zis.closeEntry() // ZipInputStream kiem CRC o day -> nem neu sai
                                if (dest.exists() && dest.isDirectory) throw IOException("Dich la thu muc: $name")
                                if (!tmp.renameTo(dest)) {
                                    dest.delete()
                                    if (!tmp.renameTo(dest)) throw IOException("Khong doi ten duoc: $name")
                                }
                            } finally {
                                if (tmp.exists()) tmp.delete()
                            }
                            restored++
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return Extracted(restored, db)
    }

    // ------------------------------------------------------------------
    // Goi "di chuyen" (portable) - chuyen sang hosting khac KHONG qua app
    // ------------------------------------------------------------------

    /** Thu muc/tep trong wp-content KHONG dem sang: dac thu cua nen tang nay
     * (se lam hong hoac vo ich o host khac) hoac don rac. So khop theo THANH
     * PHAN DAU TIEN sau "wp-content/" (hoac ten tep goc cho drop-in). */
    private val PORTABLE_EXCLUDED_TOP = setOf(
        "cache",                         // bo nho dem (host moi tu tao)
        "upgrade", "upgrade-temp-backup", // thu muc tam cua trinh cap nhat
        "database",                      // SQLite o che do PHP-Lite (xem README goi)
        "object-cache.php",              // drop-in APCu cua nen tang nay
        "db.php",                        // drop-in SQLite cua che do Lite
        "debug.log",
    )
    private val PORTABLE_EXCLUDED_PLUGINS = setOf("sqlite-database-integration")
    // wppocket-pagecache(.php): mu-plugin xoa page cache nginx (HANDOFF.md muc 1bg) - vo ich o host khac (khong co thu muc cache cua nen tang nay).
    private val PORTABLE_EXCLUDED_MU = setOf("wppocket-maintenance.php", "wppocket-pagecache.php", "wppocket-pagecache")

    /** [rel] la duong dan TINH TU www/ (vd "wp-content/uploads/a.jpg"). */
    fun isPortableIncluded(rel: String): Boolean {
        if (!isSafeEntryName(rel)) return false
        val parts = rel.split('/').filter { it.isNotEmpty() }
        if (parts.size < 2 || parts[0] != "wp-content") return false
        val top = parts[1]
        if (top in PORTABLE_EXCLUDED_TOP) return false
        if (top.startsWith("wppocket-")) return false           // vd wppocket-core-rollback
        if (top == "plugins" && parts.size >= 3 && parts[2] in PORTABLE_EXCLUDED_PLUGINS) return false
        if (top == "mu-plugins" && parts.size >= 3 && parts[2] in PORTABLE_EXCLUDED_MU) return false
        if (rel.endsWith(".partial") || rel.endsWith(".wpp-tmp")) return false
        return true
    }

    // ------------------------------------------------------------------
    // Ten CSDL cua site (HANDOFF.md muc 1bb): start-lamp.sh ghi lamp-run/db-name; truoc day "wordpress" bi co dinh trong backup.
    // ------------------------------------------------------------------

    const val DEFAULT_DB_NAME = "wordpress"
    private val DB_NAME_RE = Regex("^[A-Za-z][A-Za-z0-9_]{0,31}$")

    /** Noi dung file db-name -> ten CSDL hop le, nguoc lai "wordpress". File la DU LIEU, khong tin cay: ten duoc dua vao doi so
     * cua mysqldump nen chi nhan [A-Za-z][A-Za-z0-9_]{0,31} (khong khoang trang, khong dau '-', khong '/'): chan chen tuy chon. */
    fun sanitizeDbName(raw: String?): String {
        val t = raw?.trim() ?: return DEFAULT_DB_NAME
        return if (DB_NAME_RE.matches(t)) t else DEFAULT_DB_NAME
    }

    /** Doc `$table_prefix = 'xx_';` tu noi dung wp-config.php; null neu khong thay. */
    fun parseTablePrefix(wpConfig: String): String? =
        Regex("""\${'$'}table_prefix\s*=\s*['"]([A-Za-z0-9_]+)['"]""").find(wpConfig)?.groupValues?.get(1)

    /** Tim gia tri 1 option (siteurl/home) trong file dump, doc theo dong, khong nap het vao RAM.
     * Dong INSERT cua mysqldump co dang `(12,'siteurl','https://x','yes')`. */
    fun findOptionInDump(dump: File, optionName: String): String? {
        val needle = "'${optionName}','"
        val rx = Regex("""'${Regex.escape(optionName)}','((?:[^'\\]|\\.|'')*)'""")
        dump.bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                if (!line.contains(needle)) continue
                val m = rx.find(line) ?: continue
                return m.groupValues[1].replace("\\'", "'").replace("''", "'").replace("\\\\", "\\")
            }
        }
        return null
    }

    data class PortableInfo(
        val generatedAt: String,
        val siteUrl: String?,
        val homeUrl: String?,
        val tablePrefix: String?,
        val dbIncluded: Boolean,
        val sqliteMode: Boolean,
        val wordpressFiles: Int,
    )

    fun buildPortableReadme(info: PortableInfo): String {
        val old = info.siteUrl ?: info.homeUrl ?: "<URL-CU>"
        val prefix = info.tablePrefix ?: "wp_"
        val sb = StringBuilder()
        sb.appendLine("GOI DI CHUYEN WORDPRESS - tao boi WP Pocket Server (${info.generatedAt})")
        sb.appendLine("PORTABLE WORDPRESS EXPORT (see English summary at the bottom)")
        sb.appendLine("=".repeat(70))
        sb.appendLine()
        sb.appendLine("NOI DUNG GOI NAY")
        sb.appendLine("  wp-content/        theme, plugin, uploads cua ban (${info.wordpressFiles} tep)")
        if (info.dbIncluded) {
            sb.appendLine("  database.sql       toan bo co so du lieu (KHONG co lenh CREATE DATABASE/USE,")
            sb.appendLine("                     nen nap duoc vao bat ky ten database nao)")
        } else if (info.sqliteMode) {
            sb.appendLine("  (khong co database.sql) - site dang chay che do PHP-Lite (SQLite), khong the")
            sb.appendLine("  xuat SQL cho MySQL. Hay dung wp-admin > Cong cu > Xuat de lay noi dung,")
            sb.appendLine("  hoac bat che do Full (MariaDB) roi xuat lai goi nay.")
        } else {
            sb.appendLine("  (khong co database.sql) - MariaDB khong chay luc xuat. Bat server, doi MariaDB")
            sb.appendLine("  san sang roi xuat lai.")
        }
        sb.appendLine("  wp-pocket-export.json   thong tin site cu (URL, tien to bang)")
        sb.appendLine()
        sb.appendLine("CO Y KHONG DUA VAO GOI: wp-config.php (chua duong dan/mat khau rieng cua dien thoai),")
        sb.appendLine("  loi WordPress (cai ban moi tu wordpress.org), bo nho dem, drop-in rieng cua nen tang")
        sb.appendLine("  (object-cache.php, db.php), mu-plugin bao tri cua WP Pocket Server.")
        sb.appendLine()
        sb.appendLine("CACH CHUYEN SANG HOSTING / MAY CHU KHAC (theo quy trinh thu cong chuan)")
        sb.appendLine("  1. Cai WordPress moi (cung phien ban chinh neu duoc) tren noi den.")
        sb.appendLine("  2. Chep thu muc wp-content/ cua goi nay de len wp-content/ cua site moi.")
        if (info.dbIncluded) {
            sb.appendLine("  3. Nap database.sql vao database cua site moi:")
            sb.appendLine("       wp db import database.sql          (hoac phpMyAdmin > Import,")
            sb.appendLine("       hoac: mysql -u USER -p TEN_DB < database.sql)")
            sb.appendLine("  4. QUAN TRONG - dat \$table_prefix trong wp-config.php cua site moi la '$prefix'")
            sb.appendLine("     de khop voi cac bang vua nap.")
            sb.appendLine("  5. Doi URL cu sang URL moi (neu khac):")
            sb.appendLine("       wp search-replace '$old' 'https://ten-mien-moi.example' --all-tables")
        } else {
            sb.appendLine("  3. Xem phan 'khong co database.sql' o tren.")
        }
        sb.appendLine("  6. Vao wp-admin > Cai dat > Lien ket tinh > Luu thay doi; kiem tra plugin/theme.")
        sb.appendLine()
        sb.appendLine("Luu y: ten nguoi dung, mat khau bam va noi dung nam trong database.sql - giu goi")
        sb.appendLine("nay nhu du lieu nhay cam, xoa sau khi chuyen xong.")
        sb.appendLine()
        sb.appendLine("-".repeat(70))
        sb.appendLine("ENGLISH SUMMARY: install a fresh WordPress on the new host, copy wp-content/ over it,")
        sb.appendLine("import database.sql (it has no CREATE DATABASE/USE, so any DB name works), set")
        sb.appendLine("\$table_prefix = '$prefix' in the new wp-config.php, then run:")
        sb.appendLine("  wp search-replace '$old' '<new-url>' --all-tables")
        sb.appendLine("wp-config.php is intentionally NOT included. This is a standard manual-migration package;")
        sb.appendLine("it is NOT an All-in-One WP Migration (.wpress) or Duplicator archive.")
        return sb.toString()
    }

    fun buildPortableInfoJson(info: PortableInfo): String {
        fun q(s: String?): String = if (s == null) "null" else
            "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""
        return "{\n" +
            "  \"generator\": \"WP Pocket Server\",\n" +
            "  \"format\": \"portable-wordpress-v1\",\n" +
            "  \"generated_at\": ${q(info.generatedAt)},\n" +
            "  \"siteurl\": ${q(info.siteUrl)},\n" +
            "  \"home\": ${q(info.homeUrl)},\n" +
            "  \"table_prefix\": ${q(info.tablePrefix)},\n" +
            "  \"database_included\": ${info.dbIncluded},\n" +
            "  \"sqlite_mode\": ${info.sqliteMode},\n" +
            "  \"wp_content_files\": ${info.wordpressFiles}\n" +
            "}\n"
    }

    /**
     * Dong goi [out] = cay wp-content/ (da loc) + database.sql (neu co) + README + JSON.
     * Ghi truc tiep vao [out] (nguoi goi dung ten .partial roi doi ten khi xong).
     * Tra ve so tep trong wp-content da dua vao.
     */
    fun buildPortableZip(wwwDir: File, dbDump: File?, out: File, infoBase: PortableInfo): Int {
        var count = 0
        val wpContent = File(wwwDir, "wp-content")
        ZipOutputStream(FileOutputStream(out)).use { zos ->
            fun walk(dir: File, relBase: String) {
                dir.listFiles()?.sortedBy { it.name }?.forEach { f ->
                    val rel = "$relBase/${f.name}"
                    // Bo qua symlink: tranh dua tep ngoai website vao goi.
                    if (java.nio.file.Files.isSymbolicLink(f.toPath())) return@forEach
                    if (f.isDirectory) {
                        // Cat nhanh som: neu thu muc bi loai thi khong di vao.
                        if (isPortableIncluded("$rel/x")) walk(f, rel)
                    } else if (isPortableIncluded(rel)) {
                        zos.putNextEntry(ZipEntry(rel))
                        FileInputStream(f).use { it.copyTo(zos) }
                        zos.closeEntry()
                        count++
                    }
                }
            }
            if (wpContent.isDirectory) walk(wpContent, "wp-content")

            if (dbDump != null && dbDump.exists()) {
                zos.putNextEntry(ZipEntry("database.sql"))
                FileInputStream(dbDump).use { it.copyTo(zos) }
                zos.closeEntry()
            }
            val info = infoBase.copy(wordpressFiles = count)
            zos.putNextEntry(ZipEntry("README-MIGRATION.txt"))
            zos.write(buildPortableReadme(info).toByteArray(Charsets.UTF_8))
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("wp-pocket-export.json"))
            zos.write(buildPortableInfoJson(info).toByteArray(Charsets.UTF_8))
            zos.closeEntry()
        }
        return count
    }

    /**
     * Ghi 1 chuoi DUY NHAT moi vao lamp-run/object-cache-epoch (nguyen tu: tep tam + doi ten) - hop dong chung voi
     * admin-auth.php::wp_pocket_bump_object_cache_epoch() va object-cache.php::syncEpoch() (HANDOFF.md muc 1bd): bao
     * cache APCu cua php-fpm "du lieu WordPress vua doi tu ngoai, hay xoa". Khong nem loi - day chi la toi uu tinh nhat
     * quan cache, khong duoc lam hong ket qua khoi phuc. Tra true neu da ghi. Thu muc lamp-run chua co (server chua tung
     * chay) -> khong lam gi, tra false.
     */
    fun bumpObjectCacheEpoch(filesDir: File): Boolean {
        return try {
            val dir = File(filesDir, "lamp-run")
            if (!dir.isDirectory) return false
            val tmp = File(dir, "object-cache-epoch.tmp")
            tmp.writeText("${System.nanoTime()}-${System.currentTimeMillis()}-android")
            if (tmp.renameTo(File(dir, "object-cache-epoch"))) true else { tmp.delete(); false }
        } catch (_: Exception) {
            false
        }
    }
}
