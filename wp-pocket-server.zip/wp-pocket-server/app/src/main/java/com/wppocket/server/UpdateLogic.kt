package com.wppocket.server

/**
 * Logic THUAN (khong phu thuoc Android) cua tinh nang "Kiem tra ban moi" - de kiem thu bang JVM (scripts/tests/UpdateLogicTest.kt).
 * De xuat PDF (phan "Nhom khac"): "Auto-update APK (tu check GitHub release moi)". Chi KIEM TRA va mo trang tai - KHONG tu cai
 * (tu cai can quyen REQUEST_INSTALL_PACKAGES va la be mat tan cong lon). HANDOFF.md muc 1bg.
 */
object UpdateLogic {
    private val REPO = Regex("^[A-Za-z0-9._-]{1,100}/[A-Za-z0-9._-]{1,100}$")
    private val SAFE_TAG = Regex("^[A-Za-z0-9._+-]{1,100}$")
    private val TAG_NAME = Regex("\"tag_name\"\\s*:\\s*\"([^\"]{1,100})\"")

    /** "owner/repo" hop le (chi ky tu an toan, de khong the chen duong dan/ky tu la vao URL). */
    fun isValidRepo(s: String?): Boolean {
        val t = s?.trim() ?: return false
        if (!REPO.matches(t)) return false
        // "." va ".." la ky tu hop le o tren nhung la duong dan tuong doi ("../x") - tu choi moi doan chi gom dau cham.
        return t.split('/').none { part -> part.all { it == '.' } }
    }

    /**
     * includePre=false: /releases/latest (ban on dinh moi nhat; GitHub bo qua pre-release va draft).
     * includePre=true (kenh beta): /releases?per_page=1 = ban phat hanh MOI NHAT ke ca pre-release (khong gom draft khi khong dang nhap).
     * Ca hai deu co tag_name dau tien la ban can tim nen dung chung parseTag.
     */
    fun latestApiUrl(repo: String, includePre: Boolean = false): String =
        if (includePre) "https://api.github.com/repos/${repo.trim()}/releases?per_page=1"
        else "https://api.github.com/repos/${repo.trim()}/releases/latest"

    /** Trang phat hanh de nguoi dung tu tai APK ve. Tag da duoc loc ky tu an toan o parseTag. */
    fun releasePageUrl(repo: String, tag: String): String = "https://github.com/${repo.trim()}/releases/tag/$tag"

    /** Lay tag_name dau tien trong JSON /releases/latest; null neu khong co hoac chua ky tu la. */
    fun parseTag(json: String): String? {
        val t = TAG_NAME.find(json)?.groupValues?.get(1) ?: return null
        return if (SAFE_TAG.matches(t)) t else null
    }

    private class Ver(val nums: List<Int>, val preName: String?, val preNum: Int)

    /** "v1.2.3-beta2+build" -> nums [1,2,3], pre "beta" so 2. Null neu khong doc duoc so nao (hoac so qua dai, vd ngay thang). */
    private fun parse(v: String): Ver? {
        val t = v.trim().trimStart('v', 'V').substringBefore('+')
        val core = t.substringBefore('-')
        val nums = ArrayList<Int>()
        for (part in core.split('.')) {
            val n = part.takeWhile { it.isDigit() }
            if (n.isEmpty() || n.length > 6) break
            nums.add(n.toInt())
            if (n.length != part.length) break
        }
        if (nums.isEmpty()) return null
        if (!t.contains('-')) return Ver(nums, null, 0)
        val pre = t.substringAfter('-')
        val name = pre.takeWhile { !it.isDigit() }.trim('.', '-', '_').lowercase()
        val num = pre.dropWhile { !it.isDigit() }.takeWhile { it.isDigit() }.take(6).toIntOrNull() ?: 0
        return Ver(nums, name, num)
    }

    /**
     * true neu tag moi hon phien ban dang chay. So sanh: cac so truoc ("1.10.0" > "1.9.0"); neu bang nhau thi ban ON DINH moi hon
     * pre-release cua chinh no (1.2.3 > 1.2.3-beta2); hai pre-release so theo ten ("alpha" < "beta" < "rc") roi theo so (beta10 > beta2).
     * Khong doc duoc 1 trong 2 ben -> false (khong bao nham).
     */
    fun isNewer(latestTag: String, currentVersion: String): Boolean {
        val a = parse(latestTag) ?: return false
        val b = parse(currentVersion) ?: return false
        for (i in 0 until maxOf(a.nums.size, b.nums.size)) {
            val x = a.nums.getOrElse(i) { 0 }; val y = b.nums.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        val ap = a.preName; val bp = b.preName
        if (ap == null && bp == null) return false
        if (ap == null) return true
        if (bp == null) return false
        if (ap != bp) return ap > bp
        return a.preNum > b.preNum
    }
}
