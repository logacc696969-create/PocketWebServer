package com.wppocket.server

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.wppocket.server.databinding.ActivityMainBinding
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: android.content.SharedPreferences

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        binding.switchAutoStart.isChecked = prefs.getBoolean(Prefs.KEY_AUTO_START, false)

        binding.btnStart.setOnClickListener { startServer() }
        binding.btnStop.setOnClickListener { stopServer() }
        binding.btnBatteryOptimization.setOnClickListener { requestIgnoreBatteryOptimizations() }
        binding.btnOemAutostart.setOnClickListener { openOemAutostartSettings() }
        binding.btnBackupNow.setOnClickListener { backupNow() }
        binding.btnRestore.setOnClickListener { showRestorePicker() }
        binding.btnOpenAdmin.setOnClickListener { openAdminPanel() }
        binding.btnViewLog.setOnClickListener {
            startActivity(Intent(this, LogViewerActivity::class.java))
        }
        binding.switchAutoStart.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_AUTO_START, checked).apply()
        }

        binding.etTunnelToken.setText(prefs.getString(Prefs.KEY_TUNNEL_TOKEN, "") ?: "")
        binding.btnSaveToken.setOnClickListener {
            val token = binding.etTunnelToken.text.toString().trim()
            prefs.edit().putString(Prefs.KEY_TUNNEL_TOKEN, token).apply()
            Toast.makeText(this, R.string.toast_token_saved, Toast.LENGTH_SHORT).show()
        }

        setupAutomationUi()
        setupLiteModeUi()
        setupAutoSleepUi()
        maybeRequestNotificationPermission()
        refreshStatusLoop()

        // Idempotent - an toan goi lai moi lan mo app (xem WorkScheduler.kt).
        WorkScheduler.ensureScheduledFromPrefs(this)
    }

    /**
     * Uu tien tu dong hoa: bat/tat backup dinh ky + cau hinh Telegram Bot -
     * de xuat tu PDF "He thong Backup tu dong va Cloud Sync" + "Tien loi hoa
     * quan ly qua Telegram Bot" (xem HANDOFF.md muc 1e).
     */
    private fun setupAutomationUi() {
        binding.switchAutoBackup.isChecked = prefs.getBoolean(Prefs.KEY_BACKUP_AUTO_ENABLED, false)
        val savedHours = prefs.getInt(Prefs.KEY_BACKUP_INTERVAL_HOURS, Prefs.DEFAULT_BACKUP_INTERVAL_HOURS.toInt())
        binding.etBackupIntervalHours.setText(savedHours.toString())
        binding.etTelegramBotToken.setText(prefs.getString(Prefs.KEY_TELEGRAM_BOT_TOKEN, "") ?: "")
        binding.etTelegramChatId.setText(prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, "") ?: "")
        binding.etBackupWebhookUrl.setText(prefs.getString(Prefs.KEY_BACKUP_WEBHOOK_URL, "") ?: "")

        binding.btnSaveAutomation.setOnClickListener {
            val enabled = binding.switchAutoBackup.isChecked
            val hours = binding.etBackupIntervalHours.text.toString().toIntOrNull()
                ?.coerceAtLeast(1) ?: Prefs.DEFAULT_BACKUP_INTERVAL_HOURS.toInt()
            binding.etBackupIntervalHours.setText(hours.toString())

            val botToken = binding.etTelegramBotToken.text.toString().trim()
            val chatId = binding.etTelegramChatId.text.toString().trim()
            val webhookUrl = binding.etBackupWebhookUrl.text.toString().trim()

            prefs.edit()
                .putBoolean(Prefs.KEY_BACKUP_AUTO_ENABLED, enabled)
                .putInt(Prefs.KEY_BACKUP_INTERVAL_HOURS, hours)
                .putString(Prefs.KEY_TELEGRAM_BOT_TOKEN, botToken)
                .putString(Prefs.KEY_TELEGRAM_CHAT_ID, chatId)
                .putString(Prefs.KEY_BACKUP_WEBHOOK_URL, webhookUrl)
                .apply()

            if (enabled) {
                BackupWorker.schedule(this, hours.toLong())
            } else {
                BackupWorker.cancel(this)
            }

            if (TelegramNotifier.isConfigured(botToken, chatId)) {
                TelegramCommandWorker.schedule(this)
            } else {
                TelegramCommandWorker.cancel(this)
            }

            Toast.makeText(this, R.string.toast_automation_saved, Toast.LENGTH_SHORT).show()
        }
    }

    private fun startServer() {
        val intent = Intent(this, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, R.string.toast_starting, Toast.LENGTH_SHORT).show()
    }

    private fun stopServer() {
        val intent = Intent(this, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_STOP
        }
        startService(intent)
    }

    private fun maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            Toast.makeText(this, R.string.toast_battery_already_ignored, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Nut rieng cho "lop pin thu 2" cua cac hang tuy bien sau (xem
     * OemBattery.kt) - KHAC voi requestIgnoreBatteryOptimizations() o tren
     * (do la API CHUNG cua Android goc, cai nay la man hinh RIENG cua tung
     * hang, khong chinh thuc, best-effort). Neu khong tim/mo duoc man hinh
     * rieng, rot ve man hinh chi tiet ung dung chuan + toast huong dan.
     */
    private fun openOemAutostartSettings() {
        val opened = OemBattery.tryOpenManufacturerAutostartSettings(this)
        if (!opened) {
            OemBattery.openAppDetailsSettings(this)
            Toast.makeText(this, R.string.toast_oem_autostart_fallback, Toast.LENGTH_LONG).show()
        }
    }

    /** Cập nhật UI mỗi giây để phản ánh trạng thái thật của service (đang chạy / dừng). */
    private fun refreshStatusLoop() {
        val runnable = object : Runnable {
            override fun run() {
                val running = ServerForegroundService.isRunning
                val restartCount = ServerForegroundService.restartCount
                binding.tvStatus.text = when {
                    running -> getString(R.string.status_running)
                    restartCount > 0 -> getString(R.string.status_crash_looping, restartCount)
                    ServerForegroundService.lastErrorMessage != null ->
                        getString(R.string.status_error, ServerForegroundService.lastErrorMessage)
                    else -> getString(R.string.status_stopped)
                }
                val ip = NetworkUtils.getLocalIpAddress()
                val port = ServerForegroundService.currentPort
                binding.tvUrl.text = if (running && ip != null) {
                    "http://$ip:$port"
                } else if (running) {
                    getString(R.string.url_no_network)
                } else {
                    ""
                }

                val publicUrl = ServerForegroundService.publicUrl
                binding.tvPublicUrl.text = publicUrl ?: if (running) {
                    getString(R.string.notif_tunnel_connecting)
                } else {
                    ""
                }

                // Che do THAT dang chay (khac RadioGroup - do chi la LUA CHON,
                // ket qua thuc te o che do Auto phai doc file nay moi biet).
                // Xem HANDOFF.md muc 1i.
                val liteMarker = File(filesDir, "lamp-run/lite-mode")
                binding.tvRuntimeMode.text = when {
                    !running -> ""
                    liteMarker.exists() -> getString(R.string.runtime_mode_lite)
                    else -> getString(R.string.runtime_mode_full)
                }

                val pwFile = File(filesDir, "admin-password.txt")
                binding.tvAdminPassword.text = if (pwFile.exists()) pwFile.readText().trim() else ""

                handler.postDelayed(this, 1000)
            }
        }
        handler.post(runnable)
    }

    /** Mở trang quản trị (Adminer + File Manager) bằng trình duyệt qua IP LAN. */
    private fun openAdminPanel() {
        val pwFile = File(filesDir, "admin-password.txt")
        if (!pwFile.exists()) {
            Toast.makeText(this, R.string.toast_no_admin_password, Toast.LENGTH_SHORT).show()
            return
        }
        val ip = NetworkUtils.getLocalIpAddress()
        if (ip == null) {
            Toast.makeText(this, R.string.toast_no_lan_ip, Toast.LENGTH_SHORT).show()
            return
        }
        val url = "http://$ip:${ServerForegroundService.currentPort}/_admin/"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    /**
     * Dual-Mode PHP-Lite (xem HANDOFF.md muc 1e) - luu lua chon vao Prefs
     * NGAY khi nguoi dung bam radio (khong can nut Luu rieng, vi day la 1
     * lua chon don gian, khac voi cac o nhap lieu backup/telegram o tren).
     * Gia tri duoc doc lai boi ServerForegroundService.runSiteLoop() moi
     * lan khoi dong server, truyen xuong start-lamp.sh qua env FORCE_LITE_MODE.
     */
    /**
     * Auto-Sleep MariaDB khi ranh - de xuat PDF "Co che Ngu dong thong minh"
     * (vong 2). MAC DINH TAT (xem Prefs.KEY_AUTO_SLEEP_ENABLED). Chi luu
     * Prefs o day - logic that (tat/bat lai MariaDB) nam trong start-lamp.sh
     * + wake-mariadb.php, doc lai gia tri nay qua env AUTO_SLEEP_ENABLED/
     * AUTO_SLEEP_IDLE_MINUTES moi lan ServerForegroundService khoi dong server.
     */
    private fun setupAutoSleepUi() {
        binding.switchAutoSleep.isChecked = prefs.getBoolean(Prefs.KEY_AUTO_SLEEP_ENABLED, false)
        binding.edtAutoSleepMinutes.setText(
            prefs.getInt(Prefs.KEY_AUTO_SLEEP_IDLE_MINUTES, Prefs.DEFAULT_AUTO_SLEEP_IDLE_MINUTES).toString()
        )
        binding.switchAutoSleep.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_AUTO_SLEEP_ENABLED, checked).apply()
        }
        binding.edtAutoSleepMinutes.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val minutes = binding.edtAutoSleepMinutes.text.toString().toIntOrNull()
                    ?.coerceIn(5, 240) // duoi 5 phut de nhay cam, tren 4 tieng thi lam mat y nghia "auto"
                    ?: Prefs.DEFAULT_AUTO_SLEEP_IDLE_MINUTES
                binding.edtAutoSleepMinutes.setText(minutes.toString())
                prefs.edit().putInt(Prefs.KEY_AUTO_SLEEP_IDLE_MINUTES, minutes).apply()
            }
        }
    }

    private fun setupLiteModeUi() {
        when (prefs.getString(Prefs.KEY_PHP_LITE_MODE, Prefs.LITE_MODE_AUTO)) {
            Prefs.LITE_MODE_FORCE_ON -> binding.radioLiteOn.isChecked = true
            Prefs.LITE_MODE_FORCE_OFF -> binding.radioLiteOff.isChecked = true
            else -> binding.radioLiteAuto.isChecked = true
        }
        binding.radioGroupLiteMode.setOnCheckedChangeListener { _, checkedId ->
            val value = when (checkedId) {
                binding.radioLiteOn.id -> Prefs.LITE_MODE_FORCE_ON
                binding.radioLiteOff.id -> Prefs.LITE_MODE_FORCE_OFF
                else -> Prefs.LITE_MODE_AUTO
            }
            prefs.edit().putString(Prefs.KEY_PHP_LITE_MODE, value).apply()
        }
    }

    /**
     * Backup thu cong: goi chung BackupManager.performBackup() voi
     * BackupWorker (chay tu dong) - xem BackupManager.kt. Giu nguyen UX cu
     * (Toast bat dau/xong/loi), chi khac o cho logic zip/dump gio nam o 1
     * noi duy nhat thay vi lap lai (HANDOFF.md muc 1e).
     */
    private fun backupNow() {
        Toast.makeText(this, R.string.toast_backup_started, Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val result = BackupManager.performBackup(this)
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.toast_backup_done, result.file.name), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this, getString(R.string.toast_backup_failed, e.message ?: "unknown"), Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    /**
     * Khoi phuc du lieu tu 1 ban backup da co - truoc day CHUA CO tinh nang
     * nay (chi co backup, khong co restore - phan hoi that tu nguoi dung).
     * Luon canh bao + bat nguoi dung xac nhan truoc khi ghi de, vi day la
     * hanh dong KHONG THE HOAN TAC (ghi de website + database hien tai).
     */
    private fun showRestorePicker() {
        val backups = BackupManager.listBackups(this)
        if (backups.isEmpty()) {
            Toast.makeText(this, R.string.toast_no_backups, Toast.LENGTH_SHORT).show()
            return
        }
        val dateFmt = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
        val labels = backups.map { f ->
            "${dateFmt.format(java.util.Date(f.lastModified()))}  (${f.length() / 1024} KB)"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle(R.string.restore_pick_title)
            .setItems(labels) { _, which -> confirmRestore(backups[which]) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun confirmRestore(backupFile: File) {
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_confirm_title)
            .setMessage(R.string.restore_confirm_message)
            .setPositiveButton(R.string.restore_confirm_yes) { _, _ -> runRestore(backupFile) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun runRestore(backupFile: File) {
        Toast.makeText(this, R.string.toast_restore_started, Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val result = BackupManager.performRestore(this, backupFile)
                runOnUiThread {
                    val msg = when {
                        result.dbAttempted && result.dbRestored ->
                            getString(R.string.toast_restore_done_with_db, result.filesRestored)
                        result.dbAttempted && !result.dbRestored ->
                            getString(R.string.toast_restore_done_db_failed, result.filesRestored)
                        else ->
                            getString(R.string.toast_restore_done_files_only, result.filesRestored)
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this, getString(R.string.toast_restore_failed, e.message ?: "unknown"), Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }
}
