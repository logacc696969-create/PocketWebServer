package com.wppocket.server

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.wppocket.server.databinding.ActivityMainBinding
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    /** J4 (SkeletonLogic): nhap nhay dong dia chi cong khai trong luc ham dang duoc tao. */
    private var tunnelPulse: android.animation.ObjectAnimator? = null
    private lateinit var prefs: android.content.SharedPreferences

    private val notifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op */ }

    // J1-J3 (HANDOFF.md muc 1az) - Storage Access Framework bang StartActivityForResult + intent
    // nen tang (ACTION_OPEN_DOCUMENT / ACTION_CREATE_DOCUMENT): khong phu thuoc phien ban
    // androidx.activity, khong can quyen luu tru.
    private val importPickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uri = if (r.resultCode == RESULT_OK) r.data?.data else null
            if (uri != null) onImportPicked(uri)
        }

    private class PendingExport(val file: File, val deleteAfter: Boolean)
    private var pendingExport: PendingExport? = null

    private val exportTargetLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val pending = pendingExport
            pendingExport = null
            val uri = if (r.resultCode == RESULT_OK) r.data?.data else null
            if (pending == null) {
                // Activity bi tao lai (vd tien trinh bi he thong giet) giua luc chon noi luu.
                if (uri != null) Toast.makeText(this, R.string.toast_export_expired, Toast.LENGTH_LONG).show()
                return@registerForActivityResult
            }
            if (uri == null) { // nguoi dung huy
                if (pending.deleteAfter) pending.file.delete()
                return@registerForActivityResult
            }
            Toast.makeText(this, R.string.toast_export_preparing, Toast.LENGTH_SHORT).show()
            busyBegin(R.string.busy_export)
            Thread {
                try {
                    BackupManager.copyFileToUri(this, pending.file, uri)
                    runOnUiThread { Toast.makeText(this, R.string.toast_export_done, Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this, getString(R.string.toast_export_failed, e.message ?: "unknown"), Toast.LENGTH_LONG).show()
                    }
                } finally {
                    if (pending.deleteAfter) pending.file.delete()
                    runOnUiThread { busyEnd() }
                }
            }.start()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // S11 (PDF 2, 1bn): StrictMode CHI o ban debug (FLAG_DEBUGGABLE) va CHI ghi log (khong bao gio lam sap app): bao thao tac dia/mang
        // tren luong chinh va roi dong/Activity trong logcat. Dat o DAY chu khong o WpPocketApplication (lop do ghi ro "khong them logic khac").
        if ((applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            android.os.StrictMode.setThreadPolicy(android.os.StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build())
            android.os.StrictMode.setVmPolicy(
                android.os.StrictMode.VmPolicy.Builder().detectLeakedClosableObjects().detectLeakedSqlLiteObjects().detectActivityLeaks().penaltyLog().build()
            )
        }
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        binding.switchAutoStart.isChecked = prefs.getBoolean(Prefs.KEY_AUTO_START, false)

        binding.btnStart.setOnClickListener { haptic(it); startServer() }
        binding.btnStop.setOnClickListener { haptic(it); stopServer() }
        binding.btnBatteryOptimization.setOnClickListener { requestIgnoreBatteryOptimizations() }
        binding.btnOemAutostart.setOnClickListener { openOemAutostartSettings() }
        binding.btnBackupNow.setOnClickListener { haptic(it); backupNow() }
        binding.btnRestore.setOnClickListener { showRestorePicker() }
        binding.btnImportBackup.setOnClickListener { launchImportPicker() }
        binding.btnExportBackup.setOnClickListener { showExportPicker() }
        binding.btnDataInfo.setOnClickListener { showDataInfo() }
        binding.btnDbCheck.setOnClickListener { runDbCheck() }
        binding.btnPhpProfile.setOnClickListener { showPhpProfileDialog() }
        binding.cbApi.isChecked = prefs.getBoolean(Prefs.KEY_API_ENABLED, false)
        binding.cbApi.setOnCheckedChangeListener { _, checked -> onApiToggled(checked) }
        binding.btnApiInfo.setOnClickListener { showApiInfo() }
        binding.cbBackupOnSd.isChecked = prefs.getBoolean(Prefs.KEY_BACKUP_ON_SD, false)
        binding.cbBackupOnSd.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(Prefs.KEY_BACKUP_ON_SD, checked).apply() }
        binding.btnOpenAdmin.setOnClickListener { openAdminPanel() }
        binding.btnCopyAdminPassword.setOnClickListener { copyAdminPassword() }
        binding.btnChangeAdminPassword.setOnClickListener { showChangeAdminPasswordDialog() }
        binding.btnEmergencyDisable2fa.setOnClickListener { emergencyDisable2fa() }
        binding.btnEmergencyClearIpRules.setOnClickListener { emergencyClearIpRules() }
        binding.btnShareUrl.setOnClickListener { shareUrl() }
        binding.btnAlertSettings.setOnClickListener { showAlertSettings() }
        binding.btnViewLog.setOnClickListener {
            // J7 (1bn): chuyen canh mo dan thay vi cat ngang (androidx.core - khong them phu thuoc, chay moi API).
            startActivity(
                Intent(this, LogViewerActivity::class.java),
                androidx.core.app.ActivityOptionsCompat.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
            )
        }
        binding.btnHelp.setOnClickListener { showHelp() }
        binding.btnCheckUpdate.setOnClickListener { checkForUpdate() }
        binding.cbUpdateBeta.isChecked = prefs.getBoolean(Prefs.KEY_UPDATE_INCLUDE_BETA, false)
        binding.cbUpdateBeta.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_UPDATE_INCLUDE_BETA, checked).apply()
        }
        binding.switchAutoStart.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_AUTO_START, checked).apply()
        }

        // AJ4 (1bm): che do may chu chuyen dung. Dung OnClickListener (khong phai OnCheckedChange) de hoan tac cong tac ma KHONG kich hoat
        // lai chinh no: bat = hien hop thoai xac nhan kem huong dan van hanh (AJ1) roi moi that su bat.
        binding.switchDedicatedMode.isChecked = prefs.getBoolean(Prefs.KEY_DEDICATED_MODE, false)
        applyDedicatedUi(binding.switchDedicatedMode.isChecked)
        binding.switchDedicatedMode.setOnClickListener {
            if (binding.switchDedicatedMode.isChecked) {
                binding.switchDedicatedMode.isChecked = false
                AlertDialog.Builder(this)
                    .setTitle(R.string.dialog_dedicated_title)
                    .setMessage(R.string.dialog_dedicated_message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> setDedicatedMode(true) }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            } else {
                setDedicatedMode(false)
            }
        }

        binding.etTunnelToken.setText(SecretStore.get(prefs, Prefs.KEY_TUNNEL_TOKEN, "") ?: "")
        binding.btnSaveToken.setOnClickListener {
            val token = binding.etTunnelToken.text.toString().trim()
            prefs.edit().putString(Prefs.KEY_TUNNEL_TOKEN, SecretStore.encode(token)).apply()
            Toast.makeText(this, R.string.toast_token_saved, Toast.LENGTH_SHORT).show()
        }

        setupAutomationUi()
        setupLiteModeUi()
        setupAutoSleepUi()
        maybeRequestNotificationPermission()
        refreshStatusLoop()

        // De xuat DeepSeek muc K7 (xem HANDOFF.md muc 10 + muc 1at) - xu ly
        // deep link/share intent CA luc app vua mo moi (qua onCreate o day)
        // LAN luc app DANG MO SAN nhan them 1 intent moi (qua onNewIntent()
        // ben duoi, nho launchMode="singleTop" da co san trong Manifest).
        handleIncomingIntent(intent)

        // Idempotent - an toan goi lai moi lan mo app (xem WorkScheduler.kt).
        WorkScheduler.ensureScheduledFromPrefs(this)

        maybeShowOnboarding()
    }

    /**
     * De xuat DeepSeek muc K5 (xem HANDOFF.md muc 10 + muc 1at) - "Nguoi
     * dung moi mo app lan dau: chua biet bat server, chua biet _admin/,
     * chua biet backup... Wizard 3-4 buoc huong dan. Giam support
     * request." PHAM VI DA THU HEP (khong lam Activity/wizard nhieu man
     * hinh rieng - rui ro/cong suc cao hon can thiet cho 1 dialog thong
     * tin) - 1 AlertDialog TOM TAT dung thu tu thao tac chinh, hien DUY
     * NHAT 1 lan. Cho phep dismiss bang MOI cach (bam nut, bam ra ngoai,
     * bam Back) deu tinh la "da xem" - khong ep nguoi dung phai bam dung 1
     * nut cu the, ton trong thao tac tu nhien cua ho.
     */
    private fun maybeShowOnboarding() {
        if (prefs.getBoolean(Prefs.KEY_ONBOARDING_SHOWN, false)) return
        val markShown = { prefs.edit().putBoolean(Prefs.KEY_ONBOARDING_SHOWN, true).apply() }
        AlertDialog.Builder(this)
            .setTitle(R.string.onboarding_title)
            .setMessage(R.string.onboarding_message)
            .setPositiveButton(R.string.onboarding_got_it) { _, _ -> markShown() }
            .setOnDismissListener { markShown() }
            .setCancelable(true)
            .show()
    }

    /**
     * De xuat DeepSeek muc K7 - Android goi ham nay (KHONG PHAI onCreate())
     * khi app DANG MO SAN (o dau stack, "singleTop") ma nhan them 1 intent
     * moi - vd nguoi dung bam lai vao 1 deep link "wppocket://open-admin"
     * trong khi app van dang chay. BAT BUOC goi setIntent(intent) truoc -
     * neu khong, intent CU (luc onCreate) se bi doc nham o cac lan sau du
     * nguoi dung da thao tac khac.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    /**
     * De xuat DeepSeek muc K7 (xem HANDOFF.md muc 10 + muc 1at) - xu ly 2
     * loai intent tu BEN NGOAI app: deep link "wppocket://open-admin", va
     * nhan "chia se" (Share) van ban tu app khac (dien vao o Cloudflare
     * Tunnel Token, KHONG tu dong luu - de nguoi dung tu xem lai va bam
     * "Luu token" nhu binh thuong, tranh luu nham van ban nguoi dung chi
     * dinh chia se nham/thu).
     */
    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                val uri = intent.data ?: return
                if (uri.scheme == "wppocket" && uri.host == "open-admin") {
                    openAdminPanel()
                }
            }
            Intent.ACTION_SEND -> {
                if (intent.type != "text/plain") return
                val shared = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim()
                if (shared.isNullOrEmpty()) return
                binding.etTunnelToken.setText(shared)
                Toast.makeText(
                    this,
                    getString(R.string.toast_shared_text_filled_token),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /**
     * Uu tien tu dong hoa: bat/tat backup dinh ky + cau hinh Telegram Bot -
     * de xuat tu PDF "He thong Backup tu dong va Cloud Sync" + "Tien loi hoa
     * quan ly qua Telegram Bot" (xem HANDOFF.md muc 1e).
     */
    private fun setupAutomationUi() {
        binding.switchAutoBackup.isChecked = prefs.getBoolean(Prefs.KEY_BACKUP_AUTO_ENABLED, false)
        val savedHours = prefs.getInt(Prefs.KEY_BACKUP_INTERVAL_HOURS, Prefs.DEFAULT_BACKUP_INTERVAL_HOURS.toInt())
        binding.etBackupIntervalHours.setText(savedHours.toString())
        binding.switchBackupRequireCharging.isChecked = prefs.getBoolean(Prefs.KEY_BACKUP_REQUIRE_CHARGING, false)
        binding.switchBackupEncrypt.isChecked = prefs.getBoolean(Prefs.KEY_BACKUP_ENCRYPT_ENABLED, false)
        binding.etBackupEncryptPassphrase.setText(SecretStore.get(prefs, Prefs.KEY_BACKUP_ENCRYPT_PASSPHRASE, "") ?: "")
        binding.etTelegramBotToken.setText(SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, "") ?: "")
        binding.etTelegramChatId.setText(prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, "") ?: "")
        binding.etBackupWebhookUrl.setText(SecretStore.get(prefs, Prefs.KEY_BACKUP_WEBHOOK_URL, "") ?: "")
        binding.etAlertWebhookUrl.setText(SecretStore.get(prefs, Prefs.KEY_ALERT_WEBHOOK_URL, "") ?: "")
        binding.etHeartbeatUrl.setText(SecretStore.get(prefs, Prefs.KEY_HEARTBEAT_URL, "") ?: "")
        // URL da luu tu ban cu bang http:// (khong con duoc dung - xem UrlPolicy): bao ro thay vi de webhook/heartbeat ngung am tham.
        if (listOf(binding.etBackupWebhookUrl, binding.etAlertWebhookUrl, binding.etHeartbeatUrl)
                .any { val t = it.text.toString().trim(); t.isNotEmpty() && !UrlPolicy.isAllowedOutbound(t) }) {
            Toast.makeText(this, R.string.toast_url_https_only, Toast.LENGTH_LONG).show()
        }
        val savedBudget = prefs.getInt(Prefs.KEY_DATA_BUDGET_MB, 0)
        binding.etDataBudgetMb.setText(if (savedBudget > 0) savedBudget.toString() else "")
        binding.switchBudgetThrottle.isChecked = prefs.getBoolean(Prefs.KEY_DATA_BUDGET_THROTTLE, false)
        binding.switchLowBatteryPause.isChecked = prefs.getBoolean(Prefs.KEY_LOW_BATTERY_PAUSE, true)
        binding.switchHeavyOnlyCharging.isChecked = prefs.getBoolean(Prefs.KEY_HEAVY_ONLY_CHARGING, false)

        binding.btnSaveAutomation.setOnClickListener {
            val enabled = binding.switchAutoBackup.isChecked
            val hours = binding.etBackupIntervalHours.text.toString().toIntOrNull()
                ?.coerceAtLeast(1) ?: Prefs.DEFAULT_BACKUP_INTERVAL_HOURS.toInt()
            binding.etBackupIntervalHours.setText(hours.toString())
            val requireCharging = binding.switchBackupRequireCharging.isChecked
            // De xuat DeepSeek muc F6 (xem HANDOFF.md muc 10) - chi coi la
            // "da bat ma hoa" khi CA switch bat LAN passphrase khong rong,
            // tranh truong hop bat switch nhung quen nhap passphrase khien
            // nguoi dung tuong da ma hoa nhung thuc ra khong (performBackup
            // coi passphrase rong/null la "khong ma hoa").
            val encryptPassphraseInput = binding.etBackupEncryptPassphrase.text.toString()
            val encryptEnabled = binding.switchBackupEncrypt.isChecked && encryptPassphraseInput.isNotEmpty()
            if (binding.switchBackupEncrypt.isChecked && encryptPassphraseInput.isEmpty()) {
                Toast.makeText(this, R.string.toast_backup_encrypt_needs_passphrase, Toast.LENGTH_LONG).show()
            }

            val botToken = binding.etTelegramBotToken.text.toString().trim()
            val chatId = binding.etTelegramChatId.text.toString().trim()
            val webhookUrl = binding.etBackupWebhookUrl.text.toString().trim()
            val alertWebhookUrl = binding.etAlertWebhookUrl.text.toString().trim()

            // Giam sat & canh bao (xem Monitoring.kt). URL heartbeat sai dinh dang
            // -> bao loi va GIU gia tri cu (khong luu rac).
            val heartbeatInput = binding.etHeartbeatUrl.text.toString().trim()
            val heartbeatValid = heartbeatInput.isEmpty() || UrlPolicy.isAllowedOutbound(heartbeatInput)
            if (!heartbeatValid) {
                Toast.makeText(this, R.string.toast_heartbeat_invalid, Toast.LENGTH_LONG).show()
            }
            // URL webhook (backup + canh bao): cung chinh sach - chi https:// (http:// chi toi may nay). Sai -> bao loi, GIU gia tri cu.
            val webhookValid = webhookUrl.isEmpty() || UrlPolicy.isAllowedOutbound(webhookUrl)
            val alertWebhookValid = alertWebhookUrl.isEmpty() || UrlPolicy.isAllowedOutbound(alertWebhookUrl)
            if (!webhookValid || !alertWebhookValid) {
                Toast.makeText(this, R.string.toast_url_https_only, Toast.LENGTH_LONG).show()
            }
            val budgetMb = (binding.etDataBudgetMb.text.toString().trim().toIntOrNull() ?: 0).coerceIn(0, 10_000_000)

            val monitoringEdit = prefs.edit()
                .putInt(Prefs.KEY_DATA_BUDGET_MB, budgetMb)
                .putBoolean(Prefs.KEY_DATA_BUDGET_THROTTLE, binding.switchBudgetThrottle.isChecked)
                .putBoolean(Prefs.KEY_LOW_BATTERY_PAUSE, binding.switchLowBatteryPause.isChecked)
                .putBoolean(Prefs.KEY_HEAVY_ONLY_CHARGING, binding.switchHeavyOnlyCharging.isChecked)
            if (heartbeatValid) monitoringEdit.putString(Prefs.KEY_HEARTBEAT_URL, SecretStore.encode(heartbeatInput))
            monitoringEdit.apply()

            // Ap dung NGAY ngan sach/co giam toc moi (khong doi chu ky 15 phut cua
            // HealthCheckWorker) - chay thread rieng vi co the goi Telegram (mang).
            Thread({
                try { Monitoring.updateDataBudget(applicationContext) } catch (_: Exception) {}
                // B6: ap dung NGAY tuy chon "viec nang chi khi sac" (khong doi 15 phut).
                try { Monitoring.syncHeavyJobsFlag(applicationContext) } catch (_: Exception) {}
            }, "wp-pocket-budget-apply").start()

            val autoEdit = prefs.edit()
                .putBoolean(Prefs.KEY_BACKUP_AUTO_ENABLED, enabled)
                .putInt(Prefs.KEY_BACKUP_INTERVAL_HOURS, hours)
                .putBoolean(Prefs.KEY_BACKUP_REQUIRE_CHARGING, requireCharging)
                .putBoolean(Prefs.KEY_BACKUP_ENCRYPT_ENABLED, encryptEnabled)
                .putString(Prefs.KEY_BACKUP_ENCRYPT_PASSPHRASE, SecretStore.encode(encryptPassphraseInput))
                .putString(Prefs.KEY_TELEGRAM_BOT_TOKEN, SecretStore.encode(botToken))
                .putString(Prefs.KEY_TELEGRAM_CHAT_ID, chatId)
            if (webhookValid) autoEdit.putString(Prefs.KEY_BACKUP_WEBHOOK_URL, SecretStore.encode(webhookUrl))
            if (alertWebhookValid) autoEdit.putString(Prefs.KEY_ALERT_WEBHOOK_URL, SecretStore.encode(alertWebhookUrl))
            autoEdit.apply()

            if (enabled) {
                BackupWorker.schedule(this, hours.toLong(), requireCharging)
            } else {
                BackupWorker.cancel(this)
            }

            if (TelegramNotifier.isConfigured(botToken, chatId)) {
                TelegramCommandWorker.schedule(this)
            } else {
                TelegramCommandWorker.cancel(this)
            }

            Toast.makeText(this, R.string.toast_automation_saved, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * PDF 2 muc J1: rung nhe khi bam hanh dong quan trong (bat/tat server, backup) de biet chac lenh da nhan - huu ich khi
     * man hinh khong nhin ro / dang cam may. performHapticFeedback TON TRONG cai dat "rung khi cham" cua he thong (nguoi dung tat
     * thi khong rung), CONTEXT_CLICK co tu API 23 (< minSdk 26) nen khong can kiem phien ban.
     */
    private fun haptic(v: android.view.View) {
        v.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
    }

    private fun startServer() {
        val intent = Intent(this, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, R.string.toast_starting, Toast.LENGTH_SHORT).show()
    }

    private fun stopServer() {
        val intent = Intent(this, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_STOP
        }
        startService(intent)
    }

    private fun maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            Toast.makeText(this, R.string.toast_battery_already_ignored, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Nut rieng cho "lop pin thu 2" cua cac hang tuy bien sau (xem
     * OemBattery.kt) - KHAC voi requestIgnoreBatteryOptimizations() o tren
     * (do la API CHUNG cua Android goc, cai nay la man hinh RIENG cua tung
     * hang, khong chinh thuc, best-effort). Neu khong tim/mo duoc man hinh
     * rieng, rot ve man hinh chi tiet ung dung chuan + toast huong dan.
     */
    private fun openOemAutostartSettings() {
        val opened = OemBattery.tryOpenManufacturerAutostartSettings(this)
        if (!opened) {
            OemBattery.openAppDetailsSettings(this)
            Toast.makeText(this, R.string.toast_oem_autostart_fallback, Toast.LENGTH_LONG).show()
        }
    }

    /**
     * J4: bat/tat nhap nhay do trong cua dong dia chi cong khai. Goi moi giay (idempotent: da chay thi khong tao them). Ton trong cai dat he thong
     * "xoa hoat anh" (ANIMATOR_DURATION_SCALE = 0) - xem SkeletonLogic.shouldAnimate.
     */
    private fun updateTunnelSkeleton(loading: Boolean) {
        val scale = try {
            android.provider.Settings.Global.getFloat(contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        } catch (e: Exception) { 1f }
        if (SkeletonLogic.shouldAnimate(scale, loading)) {
            if (tunnelPulse == null) {
                tunnelPulse = android.animation.ObjectAnimator.ofFloat(binding.tvPublicUrl, "alpha", SkeletonLogic.ALPHA_MIN, 1f).apply {
                    duration = SkeletonLogic.PERIOD_MS
                    repeatCount = android.animation.ObjectAnimator.INFINITE
                    repeatMode = android.animation.ObjectAnimator.REVERSE
                    start()
                }
            }
        } else if (tunnelPulse != null) {
            tunnelPulse?.cancel()
            tunnelPulse = null
            binding.tvPublicUrl.alpha = 1f
        }
    }

    override fun onDestroy() {
        tunnelPulse?.cancel()
        tunnelPulse = null
        handler.removeCallbacksAndMessages(null) // vong cap nhat 1 giay khong con giu Activity sau khi bi huy
        super.onDestroy()
    }

    /** Cập nhật UI mỗi giây để phản ánh trạng thái thật của service (đang chạy / dừng). */
    private fun refreshStatusLoop() {
        val runnable = object : Runnable {
            override fun run() {
                val running = ServerForegroundService.isRunning
                val restartCount = ServerForegroundService.restartCount
                // J6 (PDF 2, HANDOFF.md muc 1bp-K): khoa nut Bat khi server dang chay (bam lai vo nghia). Nut TAT LUON bat: khi server dang
                // crash-loop hoac dang khoi dong, running = false nhung nguoi dung van phai dung duoc no.
                binding.btnStart.isEnabled = !running
                binding.tvStatus.text = when {
                    running -> getString(R.string.status_running)
                    restartCount > 0 -> getString(R.string.status_crash_looping, restartCount)
                    ServerForegroundService.lastErrorMessage != null ->
                        getString(R.string.status_error, ServerForegroundService.lastErrorMessage)
                    else -> getString(R.string.status_stopped)
                }
                val ip = NetworkUtils.getLocalIpAddress()
                val port = ServerForegroundService.currentPort
                binding.tvUrl.text = if (running && ip != null) {
                    "http://$ip:$port"
                } else if (running) {
                    getString(R.string.url_no_network)
                } else {
                    ""
                }

                val publicUrl = ServerForegroundService.publicUrl
                binding.tvPublicUrl.text = publicUrl ?: if (running) {
                    getString(R.string.notif_tunnel_connecting)
                } else {
                    ""
                }
                updateTunnelSkeleton(running && publicUrl == null)
                // De xuat DeepSeek muc K4 - chi hien nut Chia se khi CO URL
                // that de chia se (khong hien luc dang "dang tao duong ham"
                // hay luc server tat han - bam vao se chia se chuoi rong,
                // vo nghia).
                binding.btnShareUrl.visibility =
                    if (publicUrl != null) android.view.View.VISIBLE else android.view.View.GONE

                // Che do THAT dang chay (khac RadioGroup - do chi la LUA CHON,
                // ket qua thuc te o che do Auto phai doc file nay moi biet).
                // Xem HANDOFF.md muc 1i.
                val liteMarker = File(filesDir, "lamp-run/lite-mode")
                binding.tvRuntimeMode.text = when {
                    !running -> ""
                    liteMarker.exists() -> getString(R.string.runtime_mode_lite)
                    else -> getString(R.string.runtime_mode_full)
                }

                // De xuat DeepSeek muc B7 (xem HANDOFF.md muc 10 + muc 1ap).
                // Rong khi chua tung bam "Bat server" lan nao (running=false
                // VA chua co baseline) - khong hien "0 B" gay hieu lam la
                // "da do dat", chi la CHUA CO DU LIEU.
                val dataUsed = ServerForegroundService.sessionDataUsageBytes(applicationContext)
                binding.tvDataUsage.text = if (running && dataUsed != null) {
                    getString(R.string.data_usage_label, formatBytesShort(dataUsed))
                } else {
                    ""
                }

                // AJ2/AJ3 (1bm): pin + nhiet do - thong tin cua CHIEC MAY nen hien ca khi server dung.
                val (battPct, battCharging, battTemp) = Monitoring.deviceStatus(applicationContext)
                binding.tvDeviceStatus.text = getString(
                    R.string.device_status_line,
                    if (battPct >= 0) "$battPct%" else "?",
                    if (battCharging) getString(R.string.device_status_charging) else "",
                    MonitorLogic.formatTempC(battTemp)
                )
                binding.tvDeviceStatus.setTextColor(
                    when {
                        MonitorLogic.isHot(battTemp, Monitoring.thresholds(this@MainActivity).hotTenths) -> 0xFFD32F2F.toInt()
                        MonitorLogic.isWarm(battTemp, Monitoring.thresholds(this@MainActivity).warmTenths) -> 0xFFF57C00.toInt()
                        else -> 0xFF888888.toInt()
                    }
                )

                val pwFile = File(filesDir, "admin-password.txt")
                binding.tvAdminPassword.text = if (pwFile.exists()) pwFile.readText().trim() else ""

                // Chi hien nut "Tat 2FA khan cap" khi 2FA THAT SU dang bat -
                // xem chu thich day du trong layout XML va trong
                // showEmergencyDisable2faDialog() ben duoi.
                val totpEnabledFlag = File(filesDir, "admin-totp-enabled.flag")
                binding.btnEmergencyDisable2fa.visibility =
                    if (totpEnabledFlag.exists()) android.view.View.VISIBLE else android.view.View.GONE
                // G7 (1bl): chi hien nut go luat IP khi file luat that su ton tai (cung quy uoc voi nut 2FA o tren).
                binding.btnEmergencyClearIpRules.visibility =
                    if (File(filesDir, "lamp-run/admin-ip-rules.json").exists()) android.view.View.VISIBLE else android.view.View.GONE

                handler.postDelayed(this, 1000)
            }
        }
        handler.post(runnable)
    }

    /** (xem HANDOFF.md muc 10) "Cua thoat hiem" cho 2FA - xoa THANG file co
     * "admin-totp-enabled.flag" bang quyen ghi file cua chinh app (khong di
     * qua web/mat khau/ma TOTP nao ca). Day la cach DUY NHAT khoi bi khoa
     * VINH VIEN neu lo/hong dien thoai chua san app Authenticator - nguoi
     * dang cam dien thoai nay (da mo duoc app) la du tin cay de lam viec
     * nay, khong can xac thuc them. KHONG xoa admin-totp-secret.txt (giu
     * lai secret cu, phong truong hop nguoi dung muon bat lai ngay ma
     * khong can quet lai QR/nhap lai tay tu dau - _admin/2fa.php se tu sinh
     * secret MOI neu bam "Bat 2FA" lan nua nen khong sao ke ca khong giu). */
    private fun emergencyDisable2fa() {
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_emergency_disable_2fa)
            .setMessage("Tat 2FA ngay? Tu do chi can mat khau la dang nhap duoc trang quan tri.")
            .setPositiveButton(android.R.string.ok) { _, _ ->
                File(filesDir, "admin-totp-enabled.flag").delete()
                Toast.makeText(this, R.string.toast_2fa_disabled, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }


    /** AJ4: bat/tat che do chuyen dung - bat se bat luon "tu khoi dong"; kenh thong bao doi o lan cap nhat thong bao ke tiep cua service. */
    private fun setDedicatedMode(on: Boolean) {
        val e = prefs.edit().putBoolean(Prefs.KEY_DEDICATED_MODE, on)
        if (on) e.putBoolean(Prefs.KEY_AUTO_START, true)
        e.apply()
        binding.switchDedicatedMode.isChecked = on
        if (on) binding.switchAutoStart.isChecked = true
        applyDedicatedUi(on)
        Toast.makeText(this, if (on) R.string.toast_dedicated_on else R.string.toast_dedicated_off, Toast.LENGTH_SHORT).show()
    }

    /** An hai nhom cai dat cau hinh (che do Lite/ngu/cache/backup va tunnel token/tu dong hoa) khi o che do chuyen dung. */
    private fun applyDedicatedUi(on: Boolean) {
        val vis = if (on) android.view.View.GONE else android.view.View.VISIBLE
        binding.layoutAdvancedSetup.visibility = vis
        binding.layoutAdvancedAutomation.visibility = vis
    }

    /** G7 (HANDOFF.md muc 1bl): go luat IP cua _admin/ (admin-ip-rules.json) bang quyen ghi file cua chinh app - khong can vao duoc
     * _admin/. admin-auth.php doc file nay MOI request (khong cache) nen co hieu luc ngay. */
    private fun emergencyClearIpRules() {
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_emergency_clear_ip_rules)
            .setMessage(R.string.dialog_clear_ip_rules_message)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                File(filesDir, "lamp-run/admin-ip-rules.json").delete()
                Toast.makeText(this, R.string.toast_ip_rules_cleared, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Nút copy riêng cho mật khẩu quản trị, thay vì để người dùng tự
     * long-press chọn text trên tvAdminPassword, vì TextView đó tự làm mới
     * mỗi 1 giây (vòng lặp trạng thái server) nên dễ bị huỷ vùng đã chọn
     * ngay giữa lúc người dùng đang thao tác copy. */
    private fun copyAdminPassword() {
        val pwFile = File(filesDir, "admin-password.txt")
        if (!pwFile.exists()) {
            Toast.makeText(this, R.string.toast_no_admin_password, Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("admin_password", pwFile.readText().trim()))
        Toast.makeText(this, R.string.toast_admin_password_copied, Toast.LENGTH_SHORT).show()
    }

    /** (xem HANDOFF.md muc 1z) Cho phep nguoi dung tu doi mat khau quan tri
     * - nguoi dung hoi "mat khau co doi duoc khong", truoc day KHONG co
     * cach nao doi ngoai viec tu xoa file admin-password.txt qua may tinh.
     * Ghi de THANG vao admin-password.txt - _admin/auth.php doc file nay
     * MOI LAN co request (khong cache), nen ap dung NGAY, khong can khoi
     * dong lai server.
     * SUA 1bc: truoc day ghi chu o day noi "phien dang nhap CU van con hieu luc ... khong phai loi" - THUC RA LA LOI
     * (phien truot 30 phut moi request nen ke da dang nhap o lai vo thoi han du da doi mat khau vi nghi lo). Nay
     * admin-auth.php gan moi phien voi DAU VAN TAY mat khau => doi mat khau o day huy MOI phien cu o request ke tiep.
     * Mat khau tu dat phai qua PasswordPolicy (>= 8 ky tu, khong pho bien/day/lap, khong dau cach dau-cuoi). */
    private fun showChangeAdminPasswordDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.dialog_change_admin_password_hint)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_change_admin_password_title)
            .setView(input)
            .setPositiveButton(R.string.btn_set_password) { _, _ ->
                val typed = input.text.toString()
                if (typed.isNotEmpty()) {
                    val problem = PasswordPolicy.check(typed)
                    if (problem != null) {
                        Toast.makeText(this, passwordProblemMessage(problem), Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                }
                val newPassword = typed.ifEmpty { PasswordPolicy.generate() }
                writeAdminPassword(newPassword)
                Toast.makeText(this, R.string.toast_admin_password_changed, Toast.LENGTH_LONG).show()
            }
            .setNeutralButton(R.string.btn_generate_random_password) { _, _ ->
                writeAdminPassword(PasswordPolicy.generate())
                Toast.makeText(this, R.string.toast_admin_password_changed, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun passwordProblemMessage(p: PasswordPolicy.Problem): Int = when (p) {
        PasswordPolicy.Problem.WHITESPACE_OR_CONTROL -> R.string.toast_pw_whitespace
        PasswordPolicy.Problem.TOO_SHORT -> R.string.toast_admin_password_too_short
        PasswordPolicy.Problem.TOO_COMMON -> R.string.toast_pw_too_common
        PasswordPolicy.Problem.SEQUENCE_OR_REPEAT -> R.string.toast_pw_sequence
        PasswordPolicy.Problem.LOW_VARIETY -> R.string.toast_pw_low_variety
    }

    /** Ghi NGUYEN TU (tep tam + doi ten cung thu muc): admin-auth.php doc file nay moi request, neu doc dung luc dang ghi do
     * se thay mat khau rong/cut => dau van tay phien (HANDOFF.md muc 1bc) lech va huy nham phien dang nhap hop le. */
    private fun writeAdminPassword(password: String) {
        val target = File(filesDir, "admin-password.txt")
        val tmp = File(filesDir, "admin-password.txt.tmp")
        tmp.writeText(password)
        if (!tmp.renameTo(target)) {   // hiem: renameTo that bai -> ghi de truc tiep (hanh vi cu) roi don tep tam
            target.writeText(password)
            tmp.delete()
        }
    }


    /** Mở trang quản trị (Adminer + File Manager) bằng trình duyệt qua IP LAN. */
    private fun openAdminPanel() {
        val pwFile = File(filesDir, "admin-password.txt")
        if (!pwFile.exists()) {
            Toast.makeText(this, R.string.toast_no_admin_password, Toast.LENGTH_SHORT).show()
            return
        }
        val ip = NetworkUtils.getLocalIpAddress()
        if (ip == null) {
            Toast.makeText(this, R.string.toast_no_lan_ip, Toast.LENGTH_SHORT).show()
            return
        }
        val url = "http://$ip:${ServerForegroundService.currentPort}/_admin/"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    /**
     * Dual-Mode PHP-Lite (xem HANDOFF.md muc 1e) - luu lua chon vao Prefs
     * NGAY khi nguoi dung bam radio (khong can nut Luu rieng, vi day la 1
     * lua chon don gian, khac voi cac o nhap lieu backup/telegram o tren).
     * Gia tri duoc doc lai boi ServerForegroundService.runSiteLoop() moi
     * lan khoi dong server, truyen xuong start-lamp.sh qua env FORCE_LITE_MODE.
     */
    /**
     * Auto-Sleep MariaDB khi ranh - de xuat PDF "Co che Ngu dong thong minh"
     * (vong 2). MAC DINH TAT (xem Prefs.KEY_AUTO_SLEEP_ENABLED). Chi luu
     * Prefs o day - logic that (tat/bat lai MariaDB) nam trong start-lamp.sh
     * + wake-mariadb.php, doc lai gia tri nay qua env AUTO_SLEEP_ENABLED/
     * AUTO_SLEEP_IDLE_MINUTES moi lan ServerForegroundService khoi dong server.
     */
    private fun setupAutoSleepUi() {
        // Page cache (fastcgi_cache) - MAC DINH TAT (HANDOFF.md muc 1bf). nginx doc "-f lamp-run/page-cache-on" cho MOI request,
        // nen bat/tat co hieu luc trong vai giay (open_file_cache_valid 2s: bat tuc thi, tat toi da ~2s), khong can khoi dong lai server (cung co che voi co bandwidth-limited cua Monitoring.kt).
        val pageCacheFlag = File(filesDir, "lamp-run/page-cache-on")
        binding.switchPageCache.isChecked = pageCacheFlag.exists()
        binding.switchPageCache.setOnCheckedChangeListener { _, checked ->
            try {
                if (checked) {
                    pageCacheFlag.parentFile?.mkdirs()
                    pageCacheFlag.writeText("1")
                } else {
                    pageCacheFlag.delete()
                }
            } catch (_: Exception) {
                Toast.makeText(this, R.string.toast_page_cache_error, Toast.LENGTH_LONG).show()
            }
        }
        binding.btnPurgePageCache.setOnClickListener {
            // Chi xoa NOI DUNG thu muc, khong xoa chinh thu muc: nginx dang giu no.
            val ok = try {
                File(filesDir, "lamp-run/page-cache").listFiles()?.forEach { it.deleteRecursively() }
                true
            } catch (_: Exception) {
                false
            }
            Toast.makeText(
                this,
                if (ok) R.string.toast_page_cache_purged else R.string.toast_page_cache_error,
                Toast.LENGTH_SHORT
            ).show()
        }
        binding.switchAutoSleep.isChecked = prefs.getBoolean(Prefs.KEY_AUTO_SLEEP_ENABLED, false)
        binding.edtAutoSleepMinutes.setText(
            prefs.getInt(Prefs.KEY_AUTO_SLEEP_IDLE_MINUTES, Prefs.DEFAULT_AUTO_SLEEP_IDLE_MINUTES).toString()
        )
        binding.switchAutoSleep.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_AUTO_SLEEP_ENABLED, checked).apply()
        }
        binding.edtAutoSleepMinutes.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val minutes = binding.edtAutoSleepMinutes.text.toString().toIntOrNull()
                    ?.coerceIn(5, 240) // duoi 5 phut de nhay cam, tren 4 tieng thi lam mat y nghia "auto"
                    ?: Prefs.DEFAULT_AUTO_SLEEP_IDLE_MINUTES
                binding.edtAutoSleepMinutes.setText(minutes.toString())
                prefs.edit().putInt(Prefs.KEY_AUTO_SLEEP_IDLE_MINUTES, minutes).apply()
            }
        }
    }

    private fun setupLiteModeUi() {
        when (prefs.getString(Prefs.KEY_PHP_LITE_MODE, Prefs.LITE_MODE_AUTO)) {
            Prefs.LITE_MODE_FORCE_ON -> binding.radioLiteOn.isChecked = true
            Prefs.LITE_MODE_FORCE_OFF -> binding.radioLiteOff.isChecked = true
            else -> binding.radioLiteAuto.isChecked = true
        }
        binding.radioGroupLiteMode.setOnCheckedChangeListener { _, checkedId ->
            val value = when (checkedId) {
                binding.radioLiteOn.id -> Prefs.LITE_MODE_FORCE_ON
                binding.radioLiteOff.id -> Prefs.LITE_MODE_FORCE_OFF
                else -> Prefs.LITE_MODE_AUTO
            }
            prefs.edit().putString(Prefs.KEY_PHP_LITE_MODE, value).apply()
        }
    }

    /**
     * Backup thu cong: goi chung BackupManager.performBackup() voi
     * BackupWorker (chay tu dong) - xem BackupManager.kt. Giu nguyen UX cu
     * (Toast bat dau/xong/loi), chi khac o cho logic zip/dump gio nam o 1
     * noi duy nhat thay vi lap lai (HANDOFF.md muc 1e).
     */
    private fun backupNow() {
        Toast.makeText(this, R.string.toast_backup_started, Toast.LENGTH_SHORT).show()
        // Dung CHUNG cau hinh ma hoa voi backup tu dong (de xuat DeepSeek
        // muc F6) - tranh nham lan "sao luc tu dong thi ma hoa, luc bam tay
        // lai khong" du cung 1 nguoi dung, cung 1 muc dich.
        val effectivePassphrase = BackupManager.effectivePassphrase(this)
        busyBegin(R.string.busy_backup)
        Thread {
            try {
                val result = BackupManager.performBackup(this, effectivePassphrase)
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.toast_backup_done, result.file.name), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this, getString(R.string.toast_backup_failed, e.message ?: "unknown"), Toast.LENGTH_LONG
                    ).show()
                }
            } finally {
                runOnUiThread { busyEnd() }
            }
        }.start()
    }

    /**
     * Khoi phuc du lieu tu 1 ban backup da co - truoc day CHUA CO tinh nang
     * nay (chi co backup, khong co restore - phan hoi that tu nguoi dung).
     * Luon canh bao + bat nguoi dung xac nhan truoc khi ghi de, vi day la
     * hanh dong KHONG THE HOAN TAC (ghi de website + database hien tai).
     */
    private fun showRestorePicker() {
        val backups = BackupManager.listBackups(this)
        if (backups.isEmpty()) {
            Toast.makeText(this, R.string.toast_no_backups, Toast.LENGTH_SHORT).show()
            return
        }
        val dateFmt = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
        val labels = backups.map { f ->
            "${dateFmt.format(java.util.Date(f.lastModified()))}  (${f.length() / 1024} KB)"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle(R.string.restore_pick_title)
            .setItems(labels) { _, which -> confirmRestore(backups[which]) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun confirmRestore(backupFile: File) {
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_confirm_title)
            .setMessage(R.string.restore_confirm_message)
            .setPositiveButton(R.string.restore_confirm_yes) { _, _ ->
                // De xuat DeepSeek muc F6 (xem HANDOFF.md muc 10) - backup
                // da ma hoa (".enc") can hoi passphrase TRUOC khi giai ma +
                // khoi phuc; backup thuong (".zip") giu nguyen hanh vi cu,
                // khong hoi gi them.
                if (backupFile.name.endsWith(".enc")) {
                    val input = EditText(this).apply {
                        hint = getString(R.string.dialog_restore_passphrase_hint)
                        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    AlertDialog.Builder(this)
                        .setTitle(R.string.dialog_restore_passphrase_title)
                        .setView(input)
                        .setPositiveButton(R.string.btn_continue) { _, _ ->
                            runRestore(backupFile, input.text.toString())
                        }
                        .setNegativeButton(R.string.dialog_cancel, null)
                        .show()
                } else {
                    runRestore(backupFile, null)
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun runRestore(backupFile: File, passphrase: String?) {
        Toast.makeText(this, R.string.toast_restore_started, Toast.LENGTH_SHORT).show()
        busyBegin(R.string.busy_restore)
        Thread {
            // De xuat DeepSeek muc F6 - neu la file ".enc", giai ma ra 1
            // file TAM trong cacheDir TRUOC (Android tu don cacheDir khi
            // can, nhung van XOA THU CONG o finally de khong de lai ban ZIP
            // CHUA MA HOA lau hon can thiet), roi moi goi performRestore
            // NHU BINH THUONG voi file tam do - performRestore hoan toan
            // khong biet/khong can biet nguon la file ma hoa hay khong.
            var actualFile = backupFile
            var tempDecrypted: File? = null
            try {
                if (passphrase != null) {
                    val tmp = File(cacheDir, "restore-decrypted-${System.currentTimeMillis()}.zip")
                    BackupManager.decryptBackupFile(backupFile, passphrase, tmp)
                    tempDecrypted = tmp
                    actualFile = tmp
                }
                val result = BackupManager.performRestore(this, actualFile)
                runOnUiThread { showRestoreResult(result) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this, getString(R.string.toast_restore_failed, e.message ?: "unknown"), Toast.LENGTH_LONG
                    ).show()
                }
            } finally {
                // Luon xoa file tam DA GIAI MA (du thanh cong hay that bai)
                // - day la ban ZIP THUAN (khong con mã hoá bao ve nua), chi
                // nen ton tai dung khoang thoi gian performRestore can dung.
                tempDecrypted?.delete()
                runOnUiThread { busyEnd() }
            }
        }.start()
    }

    private fun showRestoreResult(result: BackupManager.RestoreResult) {
        val msg = when {
            result.dbAttempted && result.dbRestored ->
                getString(R.string.toast_restore_done_with_db, result.filesRestored)
            result.dbAttempted && !result.dbRestored ->
                getString(R.string.toast_restore_done_db_failed, result.filesRestored)
            else ->
                getString(R.string.toast_restore_done_files_only, result.filesRestored)
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------------
    // A8 (PDF 2, HANDOFF.md muc 1bo): chi bao tien trinh cho tac vu nen dai
    // ------------------------------------------------------------------

    /** So tac vu nen dang chay (chi doc/ghi tren luong UI). >0 -> hien thanh tien trinh va khoa cac nut tac vu. */
    private var busyCount = 0

    private fun busyBegin(labelRes: Int) {
        busyCount++
        binding.tvBusy.setText(labelRes)
        binding.layoutBusy.visibility = android.view.View.VISIBLE
        setBusyButtonsEnabled(false)
    }

    private fun busyEnd() {
        if (busyCount > 0) busyCount--
        if (busyCount == 0) {
            binding.layoutBusy.visibility = android.view.View.GONE
            setBusyButtonsEnabled(true)
        }
    }

    private fun setBusyButtonsEnabled(enabled: Boolean) {
        binding.btnBackupNow.isEnabled = enabled
        binding.btnRestore.isEnabled = enabled
        binding.btnImportBackup.isEnabled = enabled
        binding.btnExportBackup.isEnabled = enabled
        binding.btnDataInfo.isEnabled = enabled
        binding.btnDbCheck.isEnabled = enabled
        binding.btnPhpProfile.isEnabled = enabled
    }

    // ------------------------------------------------------------------
    // T1 (PDF 2, HANDOFF.md muc 1bp-L): API trang thai chi doc cho LAN
    // ------------------------------------------------------------------

    private fun newApiToken(): String = ApiLogic.generateToken(java.security.SecureRandom())

    private fun onApiToggled(enabled: Boolean) {
        prefs.edit().putBoolean(Prefs.KEY_API_ENABLED, enabled).apply()
        if (enabled && !ApiLogic.isValidToken(SecretStore.get(prefs, Prefs.KEY_API_TOKEN, null))) {
            prefs.edit().putString(Prefs.KEY_API_TOKEN, SecretStore.encode(newApiToken())).apply()
        }
        Thread { try { StatusApi.write(this) } catch (_: Exception) {} }.start()
        Toast.makeText(this, R.string.api_saved_restart, Toast.LENGTH_LONG).show()
    }

    private fun showApiInfo() {
        val token = SecretStore.get(prefs, Prefs.KEY_API_TOKEN, null)
        if (!prefs.getBoolean(Prefs.KEY_API_ENABLED, false) || token == null || !ApiLogic.isValidToken(token)) {
            Toast.makeText(this, R.string.api_not_enabled, Toast.LENGTH_SHORT).show()
            return
        }
        val ip = NetworkUtils.getLocalIpAddress() ?: "IP-may"
        val url = "http://$ip:${ServerForegroundService.currentPort}/api/v1/status"
        AlertDialog.Builder(this)
            .setTitle(R.string.api_title)
            .setMessage(getString(R.string.api_info, url, token))
            .setPositiveButton(R.string.api_btn_copy_token) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("api_token", token))
                Toast.makeText(this, R.string.api_token_copied, Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(R.string.api_btn_rotate) { _, _ ->
                prefs.edit().putString(Prefs.KEY_API_TOKEN, SecretStore.encode(newApiToken())).apply()
                Toast.makeText(this, R.string.api_token_rotated, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(R.string.data_btn_close, null)
            .show()
    }

    // ------------------------------------------------------------------
    // R15-R18 (PDF 2, HANDOFF.md muc 1bp): ho so hieu nang PHP
    // ------------------------------------------------------------------

    private fun showPhpProfileDialog() {
        val labels = arrayOf(
            getString(R.string.php_profile_0),
            getString(R.string.php_profile_1),
            getString(R.string.php_profile_2)
        )
        val current = PhpTuning.clamp(prefs.getInt(Prefs.KEY_PHP_PROFILE, 0))
        AlertDialog.Builder(this)
            .setTitle(R.string.php_profile_title)
            .setSingleChoiceItems(labels, current) { d, which ->
                prefs.edit().putInt(Prefs.KEY_PHP_PROFILE, PhpTuning.clamp(which)).apply()
                d.dismiss()
                Toast.makeText(this, R.string.php_profile_saved, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    // ------------------------------------------------------------------
    // R12 (PDF 2, HANDOFF.md muc 1bp): kiem tra toan ven CSDL (chi doc, khong tu sua)
    // ------------------------------------------------------------------

    private fun runDbCheck() {
        busyBegin(R.string.busy_dbcheck)
        Thread {
            val r = try { DbCheck.run(this) } catch (_: Exception) { DbCheck.RunResult(null, "failed") }
            runOnUiThread {
                busyEnd()
                if (isFinishing || isDestroyed) return@runOnUiThread
                val o = r.outcome
                val msg = if (o == null) {
                    if (r.reason == "no_server") getString(R.string.dbcheck_no_server) else getString(R.string.dbcheck_failed)
                } else if (o.problems.isEmpty()) {
                    getString(R.string.dbcheck_ok, o.ok, o.skipped)
                } else {
                    getString(R.string.dbcheck_problems, o.problems.size, o.total, o.problems.take(8).joinToString("\n"))
                }
                AlertDialog.Builder(this)
                    .setTitle(R.string.dbcheck_title)
                    .setMessage(msg)
                    .setPositiveButton(R.string.data_btn_close, null)
                    .show()
            }
        }.start()
    }

    // ------------------------------------------------------------------
    // AB1/AB3 (PDF 2, HANDOFF.md muc 1bo): du lieu tren may + xoa toan bo
    // ------------------------------------------------------------------

    /** Tinh dung luong o luong nen (www/mysql-data co the rat lon) roi hien hop thoai; tu do moi di toi buoc xoa. */
    private fun showDataInfo() {
        Thread {
            val r = DataLifecycle.collectAll(filesDir, BackupManager.backupRoots(this))
            val free = try { filesDir.usableSpace } catch (_: Exception) { 0L }
            val msg = getString(
                R.string.data_report,
                DataLifecycle.formatBytes(r.site), DataLifecycle.formatBytes(r.db), DataLifecycle.formatBytes(r.run),
                DataLifecycle.formatBytes(r.backups), DataLifecycle.formatBytes(r.other), DataLifecycle.formatBytes(free)
            )
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                AlertDialog.Builder(this)
                    .setTitle(R.string.data_title)
                    .setMessage(msg)
                    .setPositiveButton(R.string.data_btn_close, null)
                    .setNegativeButton(R.string.data_btn_wipe) { _, _ -> askWipeAllData() }
                    .show()
            }
        }.start()
    }

    /** Thao tac KHONG hoan tac: nut xac nhan chi bat khi nguoi dung go DUNG tu xac nhan (DataLifecycle.wipeConfirmed). */
    private fun askWipeAllData() {
        val word = getString(R.string.wipe_word)
        val input = EditText(this)
        input.hint = word
        input.isSingleLine = true
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.wipe_title)
            .setMessage(getString(R.string.wipe_message, word))
            .setView(input)
            .setPositiveButton(R.string.wipe_confirm_btn, null) // listener that gan o onShow de khong tu dong dong hop thoai
            .setNegativeButton(R.string.dialog_cancel, null)
            .create()
        dialog.setOnShowListener {
            val ok = dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE)
            ok.isEnabled = false
            input.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    ok.isEnabled = DataLifecycle.wipeConfirmed(s?.toString(), word)
                }
            })
            ok.setOnClickListener {
                if (!DataLifecycle.wipeConfirmed(input.text?.toString(), word)) return@setOnClickListener
                dialog.dismiss()
                wipeAllData()
            }
        }
        dialog.show()
    }

    /**
     * Yeu cau dung server roi nho he thong xoa du lieu ung dung (ActivityManager.clearApplicationUserData, API 19+):
     * xoa filesDir, thu muc backup trong may, SharedPreferences, WorkManager va DONG tien trinh (ke ca tien trinh con
     * nginx/php-fpm/mariadbd cung UID). Khong cho tat sach - du lieu sap bi xoa nen khong can bao toan CSDL.
     */
    private fun wipeAllData() {
        Toast.makeText(this, R.string.toast_wiping, Toast.LENGTH_LONG).show()
        stopServer()
        Thread {
            // Xoa RO RANG thu muc backup trong may (khong gia dinh he thong tu don bo nho ngoai cua app) - khong theo symlink.
            try { for (d in BackupManager.backupRoots(this)) UpdateMergeLogic.deleteNoFollow(d) } catch (_: Exception) {}
            runOnUiThread {
                Handler(Looper.getMainLooper()).postDelayed({
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                    val ok = try { am.clearApplicationUserData() } catch (_: Exception) { false }
                    if (!ok) Toast.makeText(this, R.string.toast_wipe_failed, Toast.LENGTH_LONG).show()
                }, 1500L)
            }
        }.start()
    }

    // ------------------------------------------------------------------
    // Nhap backup tu file bat ky (J1-J3, HANDOFF.md muc 1az)
    // ------------------------------------------------------------------

    private fun launchImportPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        try {
            importPickerLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(this, R.string.toast_no_file_picker, Toast.LENGTH_LONG).show()
        }
    }

    /** File duoc chon -> chep vao cacheDir -> nhan dien theo NOI DUNG (khong theo duoi file):
     * zip thuong thi kiem tra toan ven roi hoi xac nhan; con lai coi la ban ma hoa va hoi mat khau. */
    private fun onImportPicked(uri: Uri) {
        Toast.makeText(this, R.string.toast_import_reading, Toast.LENGTH_SHORT).show()
        busyBegin(R.string.busy_import)
        Thread {
            var tmp: File? = null
            try {
                val info = BackupManager.queryPicked(this, uri)
                val copied = BackupManager.copyUriToCache(this, uri, info.sizeBytes)
                tmp = copied
                when (BackupLogic.sniffKind(copied)) {
                    BackupLogic.FileKind.TOO_SMALL -> {
                        copied.delete(); tmp = null
                        runOnUiThread { Toast.makeText(this, R.string.toast_file_too_small, Toast.LENGTH_LONG).show() }
                    }
                    BackupLogic.FileKind.PLAIN_ZIP -> {
                        tmp = null // quyen xoa file chuyen cho checkAndConfirmImport
                        checkAndConfirmImport(copied)
                    }
                    BackupLogic.FileKind.ENCRYPTED_OR_UNKNOWN -> {
                        tmp = null
                        runOnUiThread { askImportPassphrase(copied) }
                    }
                }
            } catch (e: Exception) {
                tmp?.delete()
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.toast_import_invalid, e.message ?: "unknown"), Toast.LENGTH_LONG).show()
                }
            } finally {
                runOnUiThread { busyEnd() }
            }
        }.start()
    }

    private fun askImportPassphrase(encFile: File) {
        val input = EditText(this).apply {
            hint = getString(R.string.dialog_restore_passphrase_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_restore_passphrase_title)
            .setView(input)
            .setPositiveButton(R.string.btn_continue) { _, _ ->
                val pass = input.text.toString()
                Toast.makeText(this, R.string.toast_import_reading, Toast.LENGTH_SHORT).show()
                Thread {
                    val dec = File(cacheDir, "import-decrypted-${System.currentTimeMillis()}.zip")
                    try {
                        BackupManager.decryptBackupFile(encFile, pass, dec)
                        encFile.delete()
                        checkAndConfirmImport(dec)
                    } catch (e: Exception) {
                        dec.delete(); encFile.delete()
                        runOnUiThread {
                            Toast.makeText(this, getString(R.string.toast_import_invalid, e.message ?: "unknown"), Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> encFile.delete() }
            .setOnCancelListener { encFile.delete() }
            .show()
    }

    /** Chay tren luong nen. Kiem tra toan ven (CRC tu tinh, ten entry, co www/...) TRUOC khi hoi
     * xac nhan - file khong hop le bi tu choi ngay, KHONG ghi de gi. */
    private fun checkAndConfirmImport(zipFile: File) {
        val r = BackupLogic.inspect(zipFile)
        if (!r.ok) {
            zipFile.delete()
            runOnUiThread {
                Toast.makeText(this, getString(R.string.toast_import_invalid, r.reason), Toast.LENGTH_LONG).show()
            }
            return
        }
        runOnUiThread {
            AlertDialog.Builder(this)
                .setTitle(R.string.restore_confirm_title)
                .setMessage(R.string.restore_confirm_message)
                .setPositiveButton(R.string.restore_confirm_yes) { _, _ -> runImportRestore(zipFile) }
                .setNegativeButton(R.string.dialog_cancel) { _, _ -> zipFile.delete() }
                .setOnCancelListener { zipFile.delete() }
                .show()
        }
    }

    private fun runImportRestore(zipFile: File) {
        Toast.makeText(this, R.string.toast_restore_started, Toast.LENGTH_SHORT).show()
        busyBegin(R.string.busy_restore)
        Thread {
            try {
                val result = BackupManager.performRestore(this, zipFile)
                runOnUiThread { showRestoreResult(result) }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.toast_restore_failed, e.message ?: "unknown"), Toast.LENGTH_LONG).show()
                }
            } finally {
                zipFile.delete() // file tam trong cacheDir (ban zip da giai ma neu la ban ma hoa)
                runOnUiThread { busyEnd() }
            }
        }.start()
    }

    // ------------------------------------------------------------------
    // Xuat backup ra ngoai / goi di chuyen (J1-J3)
    // ------------------------------------------------------------------

    private fun showExportPicker() {
        val backups = BackupManager.listBackups(this)
        val dateFmt = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
        val labels = ArrayList<String>()
        labels.add(getString(R.string.export_option_portable))
        backups.forEach { f ->
            labels.add("${dateFmt.format(java.util.Date(f.lastModified()))}  (${f.length() / 1024} KB)" +
                if (f.name.endsWith(".enc")) "  .enc" else "")
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.export_pick_title)
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) confirmPortableExport() else exportExistingBackup(backups[which - 1])
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun exportExistingBackup(f: File) {
        // Ban ma hoa (.enc) duoc xuat NGUYEN VEN (van ma hoa) - de mang sang may khac roi nhap lai.
        launchCreateDocument(f, false, f.name, if (f.name.endsWith(".enc")) "application/octet-stream" else "application/zip")
    }

    private fun confirmPortableExport() {
        AlertDialog.Builder(this)
            .setTitle(R.string.export_option_portable)
            .setMessage(R.string.export_portable_warning)
            .setPositiveButton(R.string.btn_continue) { _, _ ->
                Toast.makeText(this, R.string.toast_export_preparing, Toast.LENGTH_SHORT).show()
                Thread {
                    try {
                        val zip = BackupManager.buildPortableExport(this)
                        val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date())
                        runOnUiThread { launchCreateDocument(zip, true, "wordpress-portable-$stamp.zip", "application/zip") }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, getString(R.string.toast_export_failed, e.message ?: "unknown"), Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun launchCreateDocument(file: File, deleteAfter: Boolean, suggestedName: String, mime: String) {
        pendingExport = PendingExport(file, deleteAfter)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, suggestedName)
        }
        try {
            exportTargetLauncher.launch(intent)
        } catch (_: Exception) {
            pendingExport = null
            if (deleteAfter) file.delete()
            Toast.makeText(this, R.string.toast_no_file_picker, Toast.LENGTH_LONG).show()
        }
    }

    /** De xuat DeepSeek muc A5/B7 (dung chung logic voi format_bytes_short()
     * trong admin-analytics.php, chi khac ngon ngu) - hien so byte ngan gon
     * de doc (KB/MB/GB) thay vi hang tram nghin/trieu so 0. */
    private fun formatBytesShort(bytes: Long): String {
        val units = arrayOf("B", "KB", "MB", "GB")
        var value = bytes.toDouble()
        var i = 0
        while (value >= 1024 && i < units.size - 1) {
            value /= 1024
            i++
        }
        return "%.1f %s".format(value, units[i])
    }

    /**
     * Kiem tra ban phat hanh moi tren GitHub - CHI khi nguoi dung bam (khong chay nen). Ten repo do CI ghi vao assets luc build;
     * khong co thi bao ro. Chi mo trang tai, KHONG tu cai. HANDOFF.md muc 1bg.
     */
    private fun checkForUpdate() {
        val repo = UpdateChecker.readRepo(this)
        if (repo == null) {
            Toast.makeText(this, R.string.toast_update_no_repo, Toast.LENGTH_LONG).show()
            return
        }
        val current = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (_: Exception) {
            ""
        }
        val includePre = prefs.getBoolean(Prefs.KEY_UPDATE_INCLUDE_BETA, false)
        Toast.makeText(this, R.string.toast_update_checking, Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val tag = UpdateChecker.fetchLatestTag(repo, includePre)
                runOnUiThread {
                    if (UpdateLogic.isNewer(tag, current)) {
                        showUpdateDialog(repo, tag, current)
                    } else {
                        Toast.makeText(this, getString(R.string.toast_update_current, current), Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.toast_update_error, e.message ?: "unknown"), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showUpdateDialog(repo: String, tag: String, current: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_update_title)
            .setMessage(getString(R.string.dialog_update_msg, tag, current))
            .setPositiveButton(R.string.btn_open_download_page) { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(UpdateLogic.releasePageUrl(repo, tag))))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Tro giup (FAQ) + "Co gi moi" - de xuat DeepSeek "Nhom khac" (HANDOFF.md muc 1bf). Hop thoai cuon duoc nen noi dung dai khong sao. */
    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle(R.string.help_title)
            .setMessage(getString(R.string.help_faq) + "\n\n" + getString(R.string.help_changelog))
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    /**
     * K4 / A3 (PDF; HANDOFF.md muc 1bq): hop thoai chia se dia chi website - co MA QR de khach quet bang may anh, nut Sao chep va nut Chia se
     * (Intent.ACTION_SEND chuan cua Android). Ma QR do [QrCode] tu ve (khong them thu vien) - da duoc kiem bang bo giai ma QR that, xem
     * scripts/tests/qr-code-test.py. URL qua dai de ma hoa (> 2953 byte) thi chi con sao chep/chia se, khong bao gio hien ma hong.
     */
    private fun shareUrl() {
        val url = ServerForegroundService.publicUrl ?: return
        val qr = QrCode.encodeText(url, QrCode.Ecc.MEDIUM)
        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, 0)
        }
        if (qr != null) {
            val side = Math.min((resources.displayMetrics.widthPixels * 0.7f).toInt(), (320 * density).toInt())
            val img = android.widget.ImageView(this).apply {
                setImageDrawable(QrDrawable(qr))
                contentDescription = getString(R.string.qr_content_desc, url)
                layoutParams = android.widget.LinearLayout.LayoutParams(side, side)
            }
            box.addView(img)
        } else {
            box.addView(android.widget.TextView(this).apply { setText(R.string.qr_too_long) })
        }
        box.addView(android.widget.TextView(this).apply {
            text = url
            setTextIsSelectable(true)
            gravity = android.view.Gravity.CENTER
            setPadding(0, (12 * density).toInt(), 0, 0)
        })
        AlertDialog.Builder(this)
            .setTitle(R.string.qr_dialog_title)
            .setView(box)
            .setPositiveButton(R.string.btn_copy_link) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("public_url", url))
                Toast.makeText(this, R.string.toast_link_copied, Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(R.string.btn_share_url_send) { _, _ -> sendLink(url) }
            .setNegativeButton(android.R.string.ok, null)
            .show()
    }

    /**
     * H5 + AE5 (HANDOFF.md muc 1bq-B): hop thoai "Nguong va quy tac canh bao". 4 nguong (dia, pin can, am, qua nong) + van ban quy tac moi dong 1 quy tac.
     * LUU chi khi TAT CA hop le (AlertThresholds.parseField / AlertRules.parse) - loi hien ngay tai o nhap, hop thoai khong dong. Logic thuan duoc kiem tren JVM.
     */
    private fun showAlertSettings() {
        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()
        val th = Monitoring.thresholds(this)
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        box.addView(android.widget.TextView(this).apply { setText(R.string.alert_rules_help); textSize = 13f })
        fun field(label: String, value: Int): EditText {
            box.addView(android.widget.TextView(this).apply { text = label; setPadding(0, (12 * density).toInt(), 0, 0) })
            val et = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                filters = arrayOf(android.text.InputFilter.LengthFilter(3))
                setText(value.toString())
                setSelectAllOnFocus(true)
                contentDescription = label
            }
            box.addView(et)
            return et
        }
        val lblDisk = getString(R.string.alert_field_disk, AlertThresholds.DISK_MIN, AlertThresholds.DISK_MAX)
        val lblBatt = getString(R.string.alert_field_batt, AlertThresholds.BATT_CRIT_MIN, AlertThresholds.BATT_CRIT_MAX)
        val lblWarm = getString(R.string.alert_field_warm, AlertThresholds.WARM_MIN, AlertThresholds.WARM_MAX)
        val lblHot = getString(R.string.alert_field_hot, AlertThresholds.HOT_MIN, AlertThresholds.HOT_MAX)
        val etDisk = field(lblDisk, th.diskPct)
        val etBatt = field(lblBatt, th.batteryCriticalPct)
        val etWarm = field(lblWarm, th.warmC)
        val etHot = field(lblHot, th.hotC)
        box.addView(android.widget.TextView(this).apply {
            text = getString(R.string.alert_rules_label, AlertRules.MAX_RULES)
            setPadding(0, (16 * density).toInt(), 0, 0)
        })
        val etRules = EditText(this).apply {
            setText(prefs.getString(Prefs.KEY_ALERT_RULES, "") ?: "")
            hint = getString(R.string.alert_rules_hint)
            minLines = 5
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 13f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        box.addView(etRules)
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.alert_dialog_title)
            .setView(android.widget.ScrollView(this).apply { addView(box) })
            .setPositiveButton(R.string.btn_save, null)
            .setNeutralButton(R.string.btn_reset_defaults, null)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dialog.setOnShowListener {
            // Gan lai nut o day de hop thoai KHONG tu dong dong khi nhap sai.
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val d = AlertThresholds.DEFAULTS
                etDisk.setText(d.diskPct.toString())
                etBatt.setText(d.batteryCriticalPct.toString())
                etWarm.setText(d.warmC.toString())
                etHot.setText(d.hotC.toString())
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val disk = AlertThresholds.parseField(etDisk.text?.toString(), AlertThresholds.DISK_MIN, AlertThresholds.DISK_MAX)
                val batt = AlertThresholds.parseField(etBatt.text?.toString(), AlertThresholds.BATT_CRIT_MIN, AlertThresholds.BATT_CRIT_MAX)
                val warm = AlertThresholds.parseField(etWarm.text?.toString(), AlertThresholds.WARM_MIN, AlertThresholds.WARM_MAX)
                val hot = AlertThresholds.parseField(etHot.text?.toString(), AlertThresholds.HOT_MIN, AlertThresholds.HOT_MAX)
                val bad = when {
                    disk == null -> Pair(etDisk, lblDisk)
                    batt == null -> Pair(etBatt, lblBatt)
                    warm == null -> Pair(etWarm, lblWarm)
                    hot == null -> Pair(etHot, lblHot)
                    else -> null
                }
                if (bad != null) {
                    bad.first.error = getString(R.string.alert_err_field, bad.second)
                    bad.first.requestFocus()
                    return@setOnClickListener
                }
                if (hot!! <= warm!!) {
                    etHot.error = getString(R.string.alert_err_hot_le_warm)
                    etHot.requestFocus()
                    return@setOnClickListener
                }
                val rulesText = etRules.text?.toString()?.trim() ?: ""
                val parsed = AlertRules.parse(rulesText)
                if (parsed.errors.isNotEmpty()) {
                    val first = parsed.errors[0]
                    val msg = ruleErrorText(first)
                    etRules.error = if (first.line > 0) getString(R.string.alert_err_rule_line, first.line, msg) else msg
                    etRules.requestFocus()
                    return@setOnClickListener
                }
                prefs.edit()
                    .putInt(Prefs.KEY_ALERT_DISK_PCT, disk!!)
                    .putInt(Prefs.KEY_ALERT_BATT_CRIT_PCT, batt!!)
                    .putInt(Prefs.KEY_ALERT_WARM_C, warm)
                    .putInt(Prefs.KEY_ALERT_HOT_C, hot)
                    .putString(Prefs.KEY_ALERT_RULES, rulesText)
                    .apply()
                Toast.makeText(this, R.string.alert_saved, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun ruleErrorText(e: AlertRules.ParseError): String = getString(
        when (e.code) {
            AlertRules.ErrorCode.BAD_FORMAT -> R.string.alert_err_bad_format
            AlertRules.ErrorCode.BAD_NAME -> R.string.alert_err_bad_name
            AlertRules.ErrorCode.DUP_NAME -> R.string.alert_err_dup_name
            AlertRules.ErrorCode.UNKNOWN_METRIC -> R.string.alert_err_unknown_metric
            AlertRules.ErrorCode.BAD_OP -> R.string.alert_err_bad_op
            AlertRules.ErrorCode.BAD_NUMBER -> R.string.alert_err_bad_number
            AlertRules.ErrorCode.OUT_OF_RANGE -> R.string.alert_err_out_of_range
            AlertRules.ErrorCode.BAD_DURATION -> R.string.alert_err_bad_duration
            AlertRules.ErrorCode.DURATION_RANGE -> R.string.alert_err_duration_range
            AlertRules.ErrorCode.TOO_MANY -> R.string.alert_err_too_many
            AlertRules.ErrorCode.TOO_LONG -> R.string.alert_err_too_long
            AlertRules.ErrorCode.UNKNOWN_WORD -> R.string.alert_err_unknown_word
        },
        e.detail
    )

    private fun sendLink(url: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        try {
            startActivity(Intent.createChooser(intent, getString(R.string.btn_share_url)))
        } catch (_: Exception) {
            Toast.makeText(this, url, Toast.LENGTH_LONG).show()
        }
    }
}
