package com.wppocket.server

import java.nio.charset.StandardCharsets

/**
 * Gui backup RA NGOAI may (Telegram / webhook) - HANDOFF.md muc 1bo-F. Chi java.* (khong Android) de test JVM duoc.
 *
 * HAI LOI THAT (doc code, vong 28; PDF 2 muc AA3 "RTO/RPO ro rang"):
 *  1. `HttpURLConnection` KHONG dat che do streaming se DEM TOAN BO than yeu cau trong RAM truoc khi gui. Code cu ghi ca file backup
 *     (co the hang tram MB) vao `outputStream` -> `OutOfMemoryError` (la Error, `catch (e: Exception)` KHONG bat) co the lam sap
 *     ca tien trinh app, keo theo server. Sua: dung bo dung multipart o day de BIET TRUOC tong do dai va goi
 *     `setFixedLengthStreamingMode(total)` (chay voi moi may chu, khac chunked co the bi tu choi).
 *  2. Ket qua gui bi BO QUA: Telegram tu choi tep > 50 MB (may chu Bot API chinh thuc) nhung `BackupWorker` van bao "backup_ok" va
 *     `Result.success()` - nguoi dung tin rang co ban sao ngoai may trong khi KHONG co (RPO that bai im lang). Sua: [failureNote].
 */
object UploadLogic {
    /** Gioi han tai tep len qua Bot API chinh thuc (multipart): 50 MB. */
    const val TELEGRAM_MAX_BYTES: Long = 50L * 1024L * 1024L

    fun telegramTooLarge(fileBytes: Long): Boolean = fileBytes > TELEGRAM_MAX_BYTES

    /** Than multipart = [header] + noi dung tep + [footer]. */
    class Multipart(val header: ByteArray, val footer: ByteArray) {
        fun totalLength(fileBytes: Long): Long = header.size.toLong() + fileBytes + footer.size.toLong()
    }

    fun buildMultipart(
        boundary: String,
        fields: List<Pair<String, String>>,
        fileField: String,
        fileName: String,
        contentType: String
    ): Multipart {
        val sb = StringBuilder()
        for (f in fields) {
            sb.append("--").append(boundary).append("\r\n")
            sb.append("Content-Disposition: form-data; name=\"").append(clean(f.first)).append("\"\r\n\r\n")
            sb.append(f.second).append("\r\n")
        }
        sb.append("--").append(boundary).append("\r\n")
        sb.append("Content-Disposition: form-data; name=\"").append(clean(fileField))
            .append("\"; filename=\"").append(clean(fileName)).append("\"\r\n")
        sb.append("Content-Type: ").append(contentType).append("\r\n\r\n")
        val footer = "\r\n--" + boundary + "--\r\n"
        return Multipart(sb.toString().toByteArray(StandardCharsets.UTF_8), footer.toByteArray(StandardCharsets.UTF_8))
    }

    /** Bo dau nhay kep va CR/LF khoi ten truong/ten tep de khong pha cau truc header. */
    fun clean(s: String): String = s.replace("\"", "'").replace("\r", " ").replace("\n", " ")

    private fun mbCeil(bytes: Long): Long = (bytes + 1024L * 1024L - 1L) / (1024L * 1024L)

    /**
     * Sau khi backup tao xong: noi nao DA CAU HINH ma gui that bai thi tra ve cau canh bao (khong dau, cung phong cach thong bao
     * khac trong app); null = khong co gi that bai (ke ca khi chua cau hinh noi nao - backup van nam trong may nhu thiet ke).
     */
    fun failureNote(
        telegramConfigured: Boolean,
        telegramOk: Boolean,
        webhookConfigured: Boolean,
        webhookOk: Boolean,
        fileBytes: Long
    ): String? {
        val parts = ArrayList<String>()
        if (telegramConfigured && !telegramOk) {
            if (telegramTooLarge(fileBytes)) {
                parts.add("Telegram khong nhan tep " + mbCeil(fileBytes) + " MB (gioi han " + mbCeil(TELEGRAM_MAX_BYTES) + " MB)")
            } else {
                parts.add("gui qua Telegram that bai")
            }
        }
        if (webhookConfigured && !webhookOk) parts.add("gui qua webhook that bai")
        if (parts.isEmpty()) return null
        return "backup da tao xong va van nam trong may nhung CHUA co ban sao ngoai may: " + parts.joinToString("; ")
    }
}
