package com.wppocket.server

import java.net.URLEncoder

/**
 * K5 (PDF 1; HANDOFF.md muc 1br): lien ket "Bao loi" mo form Issue GitHub DIEN SAN phien ban app + mau dien thoai, de nguoi thu nghiem khoi go tay
 * (xem docs/BETA_PROGRAM.md). THUAN Kotlin (chi java.net.URLEncoder, khong import android.*).
 *
 * AN TOAN/RIENG TU: URL CHI mang phien ban app + mau may/ban Android + ten mau (khong co nhat ky, IP, token, duong dan, dinh danh). App KHONG tu gui gi:
 * no chi MO trinh duyet toi trang soan Issue; nguoi dung tu dan nhat ky (da che) va tu bam gui. Kho ma nguon lay tu assets/update-repo.txt do CI ghi
 * (cung nguon voi kiem tra cap nhat) nen KHONG can chu du an quyet them URL; chua co (ban build tay) -> tra null, giao dien bao ro.
 * Truong dien san phai trung `id` trong .github/ISSUE_TEMPLATE/beta-report.yml (GitHub dien san form theo `id` cua truong).
 */
object IssueLink {
    const val TEMPLATE = "beta-report.yml"
    const val LABEL = "beta"
    const val TITLE_PREFIX = "[beta] "
    private const val MAX_VALUE = 100

    /** Bo xuong dong/ky tu dieu khien, gop khoang trang, cat con 100 ky tu: gia tri tu he thong van khong duoc phep pha cau truc URL hay form. */
    fun clean(raw: String?): String {
        val sb = StringBuilder()
        var lastSpace = false
        for (c in raw ?: "") {
            val ch = if (c.isISOControl()) ' ' else c
            if (ch == ' ') {
                if (!lastSpace && sb.isNotEmpty()) sb.append(' ')
                lastSpace = true
            } else {
                sb.append(ch)
                lastSpace = false
            }
            if (sb.length >= MAX_VALUE) break
        }
        return sb.toString().trim()
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** null khi [repo] khong hop le (UpdateLogic.isValidRepo: chi "owner/name" an toan) - khong bao gio dung chuoi la de dung URL. */
    fun url(repo: String?, version: String?, device: String?): String? {
        if (!UpdateLogic.isValidRepo(repo)) return null
        val params = listOf(
            "template" to TEMPLATE,
            "labels" to LABEL,
            "title" to TITLE_PREFIX,
            "version" to clean(version),
            "device" to clean(device)
        )
        return "https://github.com/" + repo!!.trim() + "/issues/new?" + params.joinToString("&") { it.first + "=" + enc(it.second) }
    }
}
