package com.wppocket.server

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import java.security.SecureRandom
import java.util.regex.Pattern
import java.util.zip.ZipInputStream

/**
 * Foreground Service chạy 2 tiến trình con song song:
 *
 *  1) Website của bạn - lệnh khởi chạy KHÔNG hardcode trong file này, mà đọc
 *     từ assets/runtime.json (sinh ra bởi CI dựa trên site.config.json +
 *     scripts/runtimes/<runtime>.sh). Nhờ vậy service này chạy được PHP,
 *     Node, Python, hay bất kỳ binary nào miễn có exec command hợp lệ -
 *     xem RuntimeConfig.kt.
 *
 *  2) Cloudflare Quick Tunnel (`cloudflared`) - tạo đường hầm OUTBOUND-ONLY
 *     ra Cloudflare edge, cho một URL https công khai mà KHÔNG cần mở port
 *     router hay có IP tĩnh - giải quyết đúng vấn đề CGNAT của mạng di
 *     động/cáp quang hộ gia đình.
 *
 * Cả 2 được Android quản lý như mọi foreground service (nhạc, VPN, tải
 * file...): notification cố định + PARTIAL_WAKE_LOCK để không bị kill khi
 * tắt màn hình, tự khởi động lại nếu crash.
 */
class ServerForegroundService : Service() {

    companion object {
        private const val TAG = "WPPocketServer"
        const val CHANNEL_ID = "wp_pocket_server_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.wppocket.server.action.START"
        const val ACTION_STOP = "com.wppocket.server.action.STOP"

        @Volatile var isRunning: Boolean = false
        @Volatile var currentPort: Int = 8080
            private set
        @Volatile var publicUrl: String? = null
            private set

        // Them de UI phan biet duoc "chua bam Start" / "dang crash-loop lien
        // tuc" / "dang chay that" - truoc day tvStatus chi co 2 trang thai
        // (dang chay/da dung) nen khi website crash-loop ngam (vd thieu file
        // .so, MariaDB loi...) nguoi dung thay y het nhu chua bam gi ca,
        // khong biet la app dang AM THAM thu lai lien tuc phia sau. Phan
        // hoi nguoi dung that: "bam bat server chi hien dang khoi dong roi
        // im lim". Reset ve 0/null moi lan ACTION_START.
        @Volatile var restartCount: Int = 0
            private set
        @Volatile var lastExitCode: Int? = null
            private set
        @Volatile var lastErrorMessage: String? = null
            private set

        private val TUNNEL_URL_PATTERN: Pattern =
            Pattern.compile("https://[a-zA-Z0-9-]+\\.trycloudflare\\.com")
    }

    private var siteProcess: Process? = null
    private var tunnelProcess: Process? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var siteThread: Thread? = null
    private var tunnelThread: Thread? = null

    // Tranh gui trung 1 URL nhieu lan qua Telegram (log cloudflared co the
    // khop pattern URL o nhieu dong khac nhau trong cung 1 lan chay).
    @Volatile private var lastTelegramNotifiedUrl: String? = null

    @Volatile private var shouldRun = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Dang ky watchdog + backup tu dong + dieu khien Telegram (xem
        // WorkScheduler.kt de biet ly do can goi o day, KHONG chi trong
        // MainActivity.onCreate() - lien quan Android "Buoc dung" huy het
        // WorkManager job).
        WorkScheduler.ensureScheduledFromPrefs(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
                .putBoolean(Prefs.KEY_SERVER_WANTED, false).apply()
            stopServerInternal()
            stopSelf()
            return START_NOT_STICKY
        }
        getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
            .putBoolean(Prefs.KEY_SERVER_WANTED, true).apply()
        startServerInternal()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopServerInternal()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------

    private fun startServerInternal() {
        if (shouldRun) return
        shouldRun = true
        publicUrl = null
        restartCount = 0
        lastExitCode = null
        lastErrorMessage = null

        val notification = buildNotification(getString(R.string.notif_starting))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        acquireWakeLock()

        siteThread = Thread({
            try {
                prepareRuntimeIfNeeded()
                runSiteLoop()
            } catch (e: Exception) {
                Log.e(TAG, "Loi khoi chay website", e)
                updateNotification(getString(R.string.notif_error, e.message ?: "unknown"))
            }
        }, "wp-pocket-site-worker").apply { isDaemon = true; start() }

        tunnelThread = Thread({
            try {
                Thread.sleep(1500) // cho website vai giay de bind cong truoc
                runTunnelLoop()
            } catch (e: Exception) {
                Log.e(TAG, "Loi khoi chay Cloudflare Tunnel", e)
            }
        }, "wp-pocket-tunnel-worker").apply { isDaemon = true; start() }
    }

    private fun stopServerInternal() {
        shouldRun = false
        isRunning = false
        publicUrl = null
        try { siteProcess?.destroy() } catch (_: Exception) {}
        try { tunnelProcess?.destroy() } catch (_: Exception) {}
        siteProcess = null
        tunnelProcess = null
        releaseWakeLock()
    }

    /**
     * Giải nén website từ assets/www.zip ra bộ nhớ riêng của app. www.zip
     * được CI đóng gói sẵn theo đúng site_source đã khai báo trong
     * site.config.json (WordPress, git repo, thư mục local, hoặc zip URL).
     *
     * LOI THAT tung gap (xem HANDOFF.md muc 1q): marker truoc day chi la
     * "da giai nen hay chua" (File tồn tại hay không, khong mang thong tin
     * PHIEN BAN nao) - nen MOI lan cai APK MOI DE LEN ban cu (khong xoa du
     * lieu app), www.zip KHONG BAO GIO duoc giai nen lai, vi marker cu van
     * con nguyen trong filesDir (Android chi xoa filesDir khi GO CAI DAT
     * hoac "Xoa du lieu", KHONG xoa khi cai de/update). Hau qua: MOI thay
     * doi trong www.zip (nginx.conf.template, mariadb-share/, cac fix
     * MariaDB o HANDOFF.md muc 1k-1p...) co the DA KHONG BAO GIO thuc su
     * duoc ap dung tren may that qua nhieu vong build/cai de lien tiep - chi
     * co hieu luc neu nguoi dung tinh co "Xoa du lieu" giua chung.
     * SUA: dung `packageManager.getPackageInfo(...).lastUpdateTime` (moc
     * thoi gian Android tu cap nhat MOI LAN cai/cai de APK, kha ca khi
     * versionCode khong doi - du an nay chua chac da tang versionCode moi
     * build debug) lam noi dung marker thay vi chi "co/khong". Lech gia tri
     * -> giai nen lai; giong het -> giu nguyen (van chi giai nen 1 lan cho
     * MOI ban cai, khong giai nen lai moi lan bat server nhu truoc gio).
     */
    private fun prepareRuntimeIfNeeded() {
        val config = loadRuntimeConfig()
        val docRoot = File(config.docrootPath(filesDir.absolutePath))
        val marker = File(filesDir, ".www_extracted")
        val currentUpdateTime = try {
            packageManager.getPackageInfo(packageName, 0).lastUpdateTime
        } catch (e: Exception) { 0L }
        val markerUpdateTime = if (marker.exists()) marker.readText().trim().toLongOrNull() else null
        if (markerUpdateTime != currentUpdateTime) {
            updateNotification(getString(R.string.notif_extracting))
            docRoot.deleteRecursively()
            docRoot.mkdirs()
            assets.open("www.zip").use { input -> unzip(input, docRoot) }
            marker.writeText(currentUpdateTime.toString())
        }
        ensureAdminPassword()
    }

    /**
     * Sinh mật khẩu quản trị ngẫu nhiên (16 ký tự, SecureRandom) NẾU chưa có
     * - mỗi máy 1 mật khẩu riêng, không có giá trị mặc định nào. File này
     * được _admin/auth.php (PHP) đọc qua biến môi trường APP_HOME
     * (xem php-fpm.conf.template) để xác thực trang quản trị (Adminer +
     * File Manager) - trang này CHỈ vào được qua LAN, không qua tunnel
     * public (chặn ở nginx.conf), cộng thêm lớp mật khẩu này.
     */
    private fun ensureAdminPassword() {
        val pwFile = File(filesDir, "admin-password.txt")
        if (pwFile.exists()) return
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
        val random = SecureRandom()
        val password = (1..16).map { chars[random.nextInt(chars.length)] }.joinToString("")
        pwFile.writeText(password)
    }

    private fun unzip(input: java.io.InputStream, targetDir: File) {
        ZipInputStream(input).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { fos -> zis.copyTo(fos) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    private fun loadRuntimeConfig(): RuntimeConfig {
        val json = assets.open("runtime.json").bufferedReader().use { it.readText() }
        return RuntimeConfig.loadFromJson(json)
    }

    private fun cloudflaredBinaryPath(): String =
        File(applicationInfo.nativeLibraryDir, "libcfd.so").absolutePath

    /**
     * Vòng lặp chạy website - KHÔNG biết đó là PHP, Node hay Python. Toàn bộ
     * lệnh + biến môi trường đến từ runtime.json (RuntimeConfig).
     */
    private fun runSiteLoop() {
        val config = loadRuntimeConfig()
        currentPort = config.port
        var backoffMs = 2000L

        while (shouldRun) {
            try {
                updateNotification(getString(R.string.notif_running, config.port))

                val nativeLibDir = applicationInfo.nativeLibraryDir
                val filesDirPath = filesDir.absolutePath
                val execArgs = config.resolvedExec(nativeLibDir, filesDirPath)

                val pb = ProcessBuilder(execArgs)
                pb.redirectErrorStream(true)
                pb.directory(File(config.docrootPath(filesDirPath)))

                val env = pb.environment()
                env["LD_LIBRARY_PATH"] = nativeLibDir
                env["HOME"] = filesDirPath
                env["TMPDIR"] = cacheDir.absolutePath
                env["PORT"] = config.port.toString() // tiện cho Node/Python doc process.env.PORT
                // Thong tin THIET BI thuan tuy (khong biet gi ve PHP/Node/...) - giong
                // PORT/HOME/TMPDIR o tren, chi la 1 SU KIEN cua may, khong phai quyet
                // dinh cua Kotlin. Script build-time (runtime cu the, vd start-lamp.sh)
                // tu quyet dinh co dung hay khong - xem "Dual-Mode PHP-Lite" HANDOFF.md
                // muc 1e. Gia tri Prefs.KEY_PHP_LITE_MODE la nguoi dung TU chon ép
                // (Auto/Luon bat/Luon tat) qua app, khong phai app tu quyet dinh logic.
                env["DEVICE_RAM_MB"] = getDeviceTotalRamMb().toString()
                val liteOverride = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                    .getString(Prefs.KEY_PHP_LITE_MODE, Prefs.LITE_MODE_AUTO)
                if (liteOverride != Prefs.LITE_MODE_AUTO) env["FORCE_LITE_MODE"] = liteOverride

                // Auto-Sleep MariaDB khi ranh (xem Prefs.KEY_AUTO_SLEEP_ENABLED) - CHI
                // truyen "AUTO_SLEEP_ENABLED=1" khi nguoi dung TU bat trong app; neu
                // khong co bien nay, start-lamp.sh chay nhanh y het truoc day (xem chu
                // thich trong start-lamp.sh de biet vi sao lam vay - giam rui ro cho
                // nguoi khong dung tinh nang nay).
                val sleepPrefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                if (sleepPrefs.getBoolean(Prefs.KEY_AUTO_SLEEP_ENABLED, false)) {
                    env["AUTO_SLEEP_ENABLED"] = "1"
                    env["AUTO_SLEEP_IDLE_MINUTES"] = sleepPrefs
                        .getInt(Prefs.KEY_AUTO_SLEEP_IDLE_MINUTES, Prefs.DEFAULT_AUTO_SLEEP_IDLE_MINUTES)
                        .toString()
                }
                env.putAll(config.resolvedEnv(nativeLibDir, filesDirPath))

                siteProcess = pb.start()
                isRunning = true
                // Ghi CA vao Logcat (nhu truoc) LAN vao file ma _admin/logs.php da
                // tro toi san (tab "start-lamp") - truoc ban vay tab nay LUON TRONG
                // vi khong ai ghi ra file ca, chi co Log.d vao Logcat (loi da phat
                // hien khi ra soat toan bo du an, xem HANDOFF.md). Append (khong
                // truncate) de dong bo cach cac log khac (nginx/php-fpm/mariadb)
                // cung chi noi tiep, khong tu xoa - xem start-lamp.sh: khong file
                // log nao trong du an nay bi truncate/xoay vong ca, chap nhan don
                // gian cho 1 may micro-hosting ca nhan.
                try {
                    java.io.FileOutputStream(File(filesDir, "start-lamp-stdout.log"), true)
                        .bufferedWriter().use { writer ->
                            siteProcess?.inputStream?.bufferedReader()?.forEachLine { line ->
                                Log.d("site", line)
                                try {
                                    writer.write(line)
                                    writer.newLine()
                                    writer.flush()
                                } catch (_: Exception) {
                                    // Loi ghi file KHONG duoc lam dut vong forEachLine - van
                                    // phai tiep tuc doc het stdout cua tien trinh con, neu
                                    // khong buffer stdout day len co the treo tien trinh do.
                                }
                            }
                        }
                } catch (e: Exception) {
                    // Khong mo duoc file (vd het dung luong) - rot ve CHI Logcat, khong
                    // lam hong viec doc/cho website chay.
                    Log.w(TAG, "Khong ghi duoc start-lamp-stdout.log, chi con Logcat", e)
                    siteProcess?.inputStream?.bufferedReader()?.forEachLine { line -> Log.d("site", line) }
                }

                val exitCode = siteProcess?.waitFor() ?: -1
                isRunning = false
                lastExitCode = exitCode
                if (!shouldRun) break

                restartCount += 1
                Log.w(TAG, "Website thoat voi ma $exitCode, thu lai sau ${backoffMs}ms (lan thu $restartCount)")
                updateNotification(getString(R.string.notif_restarting))
                Thread.sleep(backoffMs)
                backoffMs = (backoffMs * 2).coerceAtMost(30_000L)
            } catch (e: Exception) {
                isRunning = false
                lastErrorMessage = e.message ?: e.toString()
                Log.e(TAG, "Khong the khoi chay website (kiem tra runtime.json / exec)", e)
                updateNotification(getString(R.string.notif_error, e.message ?: "unknown"))
                break
            }
        }
    }

    /**
     * Cloudflare Tunnel - có 2 chế độ:
     *  - Nếu người dùng đã lưu token (Cài đặt trong app, lấy từ dashboard
     *    Cloudflare Zero Trust) -> chạy "named tunnel", cho domain CỐ ĐỊNH,
     *    không đổi mỗi lần restart.
     *  - Nếu chưa có token -> "Quick Tunnel" mặc định, không cần tài khoản,
     *    nhưng URL ngẫu nhiên và đổi mỗi lần khởi động lại.
     */
    private fun runTunnelLoop() {
        var backoffMs = 3000L
        while (shouldRun) {
            try {
                val binPath = cloudflaredBinaryPath()
                if (!File(binPath).exists()) {
                    Log.w(TAG, "Khong tim thay libcfd.so, bo qua Cloudflare Tunnel (van chay tot o LAN)")
                    return
                }

                val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                val token = prefs.getString(Prefs.KEY_TUNNEL_TOKEN, null)?.trim()

                val pb = if (!token.isNullOrEmpty()) {
                    ProcessBuilder(binPath, "tunnel", "run", "--token", token, "--no-autoupdate")
                } else {
                    ProcessBuilder(binPath, "tunnel", "--url", "http://127.0.0.1:$currentPort", "--no-autoupdate")
                }
                pb.redirectErrorStream(true)
                pb.environment()["LD_LIBRARY_PATH"] = applicationInfo.nativeLibraryDir
                pb.environment()["HOME"] = filesDir.absolutePath

                tunnelProcess = pb.start()
                updateTunnelNotification(getString(R.string.notif_tunnel_connecting))

                if (!token.isNullOrEmpty()) {
                    // Named tunnel: domain do nguoi dung tu cau hinh tren dashboard
                    // Cloudflare, khong doc duoc tu log nhu Quick Tunnel.
                    publicUrl = getString(R.string.tunnel_named_active)
                    updateTunnelNotification(getString(R.string.notif_tunnel_named_ready))
                    maybeNotifyTelegram(publicUrl!!)
                }

                tunnelProcess?.inputStream?.bufferedReader()?.forEachLine { line ->
                    Log.d("cloudflared", line)
                    if (token.isNullOrEmpty()) {
                        val matcher = TUNNEL_URL_PATTERN.matcher(line)
                        if (matcher.find()) {
                            publicUrl = matcher.group()
                            updateTunnelNotification(getString(R.string.notif_tunnel_ready, publicUrl))
                            maybeNotifyTelegram(publicUrl!!)
                        }
                    }
                }

                val exitCode = tunnelProcess?.waitFor() ?: -1
                publicUrl = null
                if (!shouldRun) break

                Log.w(TAG, "cloudflared thoat voi ma $exitCode, thu lai sau ${backoffMs}ms")
                Thread.sleep(backoffMs)
                backoffMs = (backoffMs * 2).coerceAtMost(30_000L)
            } catch (e: Exception) {
                Log.e(TAG, "Khong the khoi chay cloudflared (khong anh huong website chinh)", e)
                return
            }
        }
    }

    /**
     * Bao cao tu dong qua Telegram Bot khi server vua co URL cong khai - de
     * xuat tu PDF "Tien loi hoa quan ly qua Telegram Bot: Nhan bao cao tu
     * dong" (xem HANDOFF.md muc 1e). Chi gui NEU nguoi dung da dien Bot
     * Token + Chat ID trong app (mac dinh KHONG gui gi ca). Chay tren thread
     * rieng (KHONG tren tunnelThread dang doc log) de khong lam cham/nghen
     * viec doc output cua cloudflared neu mang cham.
     */
    private fun maybeNotifyTelegram(url: String) {
        if (url == lastTelegramNotifiedUrl) return
        lastTelegramNotifiedUrl = url
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val botToken = prefs.getString(Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
        if (!TelegramNotifier.isConfigured(botToken, chatId)) return
        Thread({
            val text = "WP Pocket Server da khoi dong.\nURL: $url"
            TelegramNotifier.sendMessage(botToken!!, chatId!!, text)
        }, "wp-pocket-telegram-notify").apply { isDaemon = true }.start()
    }

    /**
     * RAM VAT LY TONG cua thiet bi (khong phai RAM con trong) - dung
     * ActivityManager.MemoryInfo chinh thuc cua Android (khong doc
     * /proc/meminfo tu Kotlin - de _admin/index.php lam rieng, tranh trung
     * lap 2 co che khac nhau trong 1 du an). API nay luon truy cap duoc,
     * khong can quyen dac biet. Dung cho "Dual-Mode PHP-Lite" (xem
     * HANDOFF.md muc 1e).
     */
    private fun getDeviceTotalRamMb(): Long {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.totalMem / (1024 * 1024)
    }

    // --------------------------- Wake lock ---------------------------

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WPPocketServer::ServerWakeLock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // ------------------------- Notification -------------------------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun updateTunnelNotification(text: String) {
        val siteText = if (isRunning) getString(R.string.notif_running, currentPort) else getString(R.string.notif_starting)
        updateNotification("$siteText — $text")
    }
}
