package com.wppocket.server

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.regex.Pattern

/**
 * Foreground Service chạy 2 tiến trình con song song:
 *
 *  1) Website của bạn - lệnh khởi chạy KHÔNG hardcode trong file này, mà đọc
 *     từ assets/runtime.json (sinh ra bởi CI dựa trên site.config.json +
 *     scripts/runtimes/<runtime>.sh). Nhờ vậy service này chạy được PHP,
 *     Node, Python, hay bất kỳ binary nào miễn có exec command hợp lệ -
 *     xem RuntimeConfig.kt.
 *
 *  2) Cloudflare Quick Tunnel (`cloudflared`) - tạo đường hầm OUTBOUND-ONLY
 *     ra Cloudflare edge, cho một URL https công khai mà KHÔNG cần mở port
 *     router hay có IP tĩnh - giải quyết đúng vấn đề CGNAT của mạng di
 *     động/cáp quang hộ gia đình.
 *
 * Cả 2 được Android quản lý như mọi foreground service (nhạc, VPN, tải
 * file...): notification cố định + PARTIAL_WAKE_LOCK để không bị kill khi
 * tắt màn hình, tự khởi động lại nếu crash.
 */
class ServerForegroundService : Service() {

    companion object {
        private const val TAG = "WPPocketServer"
        const val CHANNEL_ID = "wp_pocket_server_channel"
        /** AJ4 (1bm): kenh IMPORTANCE_MIN (khong bieu tuong tren thanh trang thai) cho che do chuyen dung. Android KHONG cho NANG muc quan
         * trong cua kenh da tao, nen dung kenh THU HAI thay vi doi kenh cu (tat che do chuyen dung lai quay ve kenh LOW binh thuong). */
        const val CHANNEL_ID_QUIET = "wp_pocket_server_channel_quiet"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.wppocket.server.action.START"
        const val ACTION_STOP = "com.wppocket.server.action.STOP"
        // De xuat DeepSeek muc K3 (xem HANDOFF.md muc 10) - nut "Backup
        // ngay" bam THANG tu khay thong bao, khong can mo app. Dung
        // PendingIntent.getService() (khong phai getActivity()) de chay
        // NGAM, khong keo app len man hinh - dung UX hon cho 1 hanh dong
        // nhanh nguoi dung chi muon "bam roi thoi".
        const val ACTION_BACKUP_NOW = "com.wppocket.server.action.BACKUP_NOW"

        /** B6: chu ky lam moi co "viec nang chi khi sac" (PHP coi co cu hon 2 gio la het hieu luc). */
        const val HEAVY_FLAG_REFRESH_MS = 10 * 60 * 1000L

        @Volatile var isRunning: Boolean = false
        @Volatile var currentPort: Int = 8080
            private set
        @Volatile var publicUrl: String? = null
            private set

        // Them de UI phan biet duoc "chua bam Start" / "dang crash-loop lien
        // tuc" / "dang chay that" - truoc day tvStatus chi co 2 trang thai
        // (dang chay/da dung) nen khi website crash-loop ngam (vd thieu file
        // .so, MariaDB loi...) nguoi dung thay y het nhu chua bam gi ca,
        // khong biet la app dang AM THAM thu lai lien tuc phia sau. Phan
        // hoi nguoi dung that: "bam bat server chi hien dang khoi dong roi
        // im lim". Reset ve 0/null moi lan ACTION_START.
        @Volatile var restartCount: Int = 0
            private set
        @Volatile var lastExitCode: Int? = null
            private set
        @Volatile var lastErrorMessage: String? = null
            private set

        /** Thoi gian toi da cho start-lamp.sh tu tat SACH qua file co (xem
         * stop-requested trong start-lamp.sh) truoc khi Kotlin buoc phai
         * destroy(). Phai LON HON tong timeout trong script (nginx 5s + php-fpm
         * 5s + MariaDB 20s + do tre vong giam sat 3s ~ 33s). */
        private const val GRACEFUL_STOP_TIMEOUT_MS = 40_000L

        /** Gioi han kich thuoc start-lamp-stdout.log (che do Lite "php -S" in
         * MOI request vao day nen phinh vo han neu khong gioi han). */
        private const val STDOUT_LOG_MAX_BYTES = 2L * 1024 * 1024

        /** Thread dang tat sach website (neu co). De o companion (TINH) thay vi
         * truong cua Service vi instance Service CU co the bi huy trong khi
         * instance MOI da khoi dong (vd lenh Telegram /restart: stopSelf roi
         * startService) - instance moi phai doi tien trinh cu thoat han truoc
         * khi tao start-lamp.sh moi (script moi xoa socket/PID - se pha MariaDB
         * cu dang flush). */
        @Volatile private var shutdownThread: Thread? = null

        private fun awaitPreviousShutdown() {
            val t = shutdownThread ?: return
            try { t.join(GRACEFUL_STOP_TIMEOUT_MS + 6_000L) } catch (_: InterruptedException) {}
        }

        private val TUNNEL_URL_PATTERN: Pattern =
            Pattern.compile("https://[a-zA-Z0-9-]+\\.trycloudflare\\.com")

        /**
         * De xuat DeepSeek muc B7 (xem HANDOFF.md muc 10, Prefs.kt) - so
         * byte app nay da dung ke tu lan "Bat server" gan nhat (KHONG phai
         * tu luc cai app). Doc TRUC TIEP qua SharedPreferences (khong qua
         * bien Kotlin thuan) vi ham nay co the duoc goi tu MainActivity
         * (tien trinh UI) trong khi baseline duoc ghi tu Service - 2 THANH
         * PHAN Android KHAC NHAU nhung CUNG 1 tien trinh (Service khong
         * chay o tien trinh rieng trong AndroidManifest.xml cua du an nay),
         * nen bien Kotlin thuan (companion var) THUC RA van dung duoc, chi
         * la dung SharedPreferences van AN TOAN HON (song sot qua viec
         * Android tu kill roi khoi dong lai Service - xem chu thich Prefs.kt).
         *
         * Tra ve null neu thiet bi khong ho tro TrafficStats theo UID (API
         * co tra ve TrafficStats.UNSUPPORTED cho truong hop nay - CO THAT,
         * ghi trong tai lieu Android, khong phai suy doan) - UI PHAI tu xu
         * ly truong hop null (an so lieu nay di) thay vi hien "-1 byte" vo
         * nghia.
         */
        fun sessionDataUsageBytes(context: android.content.Context): Long? {
            val uid = android.os.Process.myUid()
            val rx = TrafficStats.getUidRxBytes(uid)
            val tx = TrafficStats.getUidTxBytes(uid)
            if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) return null

            val prefs = context.getSharedPreferences(Prefs.NAME, android.content.Context.MODE_PRIVATE)
            val baseRx = prefs.getLong(Prefs.KEY_DATA_USAGE_BASELINE_RX, rx)
            val baseTx = prefs.getLong(Prefs.KEY_DATA_USAGE_BASELINE_TX, tx)
            // Kep ve 0 (KHONG tra so am) - xem chu thich that ve truong hop
            // thiet bi khoi dong lai giua chung trong Prefs.kt.
            val used = (rx - baseRx) + (tx - baseTx)
            return if (used < 0) 0L else used
        }
    }

    private var siteProcess: Process? = null
    private var tunnelProcess: Process? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var siteThread: Thread? = null
    private var tunnelThread: Thread? = null

    // --- De xuat DeepSeek muc B3 (network-aware) + B2 (thermal-aware) - xem
    // HANDOFF.md muc 10. Ca 2 deu la listener CHUAN cua he thong Android
    // (khong phai polling tu viet), dang ky luc onCreate(), go dang ky luc
    // onDestroy() - dung cap doi voi acquireWakeLock()/releaseWakeLock() da
    // co san ngay ben duoi.
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var lastNetworkTransport: Int? = null
    private var thermalListener: PowerManager.OnThermalStatusChangedListener? = null
    @Volatile private var lastThermalAlertAtMs: Long = 0L

    // Tranh gui trung 1 URL nhieu lan qua Telegram (log cloudflared co the
    // khop pattern URL o nhieu dong khac nhau trong cung 1 lan chay).
    @Volatile private var lastTelegramNotifiedUrl: String? = null

    @Volatile private var shouldRun = false

    /** Token phien hien tai, truyen cho start-lamp.sh qua env WPP_SESSION va
     * ghi vao file stop-requested khi dung (xem stopServerInternal). */
    @Volatile private var currentSessionToken: String? = null

    /** Tang moi lan startServerInternal. runSiteLoop nho "doi" cua minh va tu
     * thoat neu da bi thay the - khong dung chi shouldRun vi shouldRun lai
     * thanh true khi nguoi dung bat lai, trong luc luong cu con dang cho script
     * cu tat sach (co the toi ~30s) -> luong cu se vo tinh bat THEM 1 script. */
    @Volatile private var generation = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Dang ky watchdog + backup tu dong + dieu khien Telegram (xem
        // WorkScheduler.kt de biet ly do can goi o day, KHONG chi trong
        // MainActivity.onCreate() - lien quan Android "Buoc dung" huy het
        // WorkManager job).
        WorkScheduler.ensureScheduledFromPrefs(applicationContext)
        registerNetworkCallback()
        registerThermalListener()
        heavyFlagHandler.post(heavyFlagTick) // B6, xem ben duoi
    }

    /**
     * B6 (HANDOFF.md muc 1az): lam moi co lamp-run/defer-heavy-jobs moi 10 phut TRONG LUC service con song. Khong chi dua
     * vao HealthCheckWorker (WorkManager, ~15 phut) vi Doze co the tri hoan no qua 2 gio khi may chay pin -> co bi coi la
     * "cu" -> viec nang tu chay tren pin du nguoi dung da bat tuy chon. Service la foreground + giu wake lock nen Handler
     * chay duoc. Viec doc pin/ghi co chay tren luong rieng, khong chan luong chinh.
     */
    private val heavyFlagHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val heavyFlagTick = object : Runnable {
        override fun run() {
            Thread({
                try { Monitoring.syncHeavyJobsFlag(applicationContext) } catch (_: Exception) {}
            }, "wp-pocket-heavyflag").apply { isDaemon = true; start() }
            heavyFlagHandler.postDelayed(this, HEAVY_FLAG_REFRESH_MS)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
                .putBoolean(Prefs.KEY_SERVER_WANTED, false).apply()
            stopServerInternal()
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_BACKUP_NOW) {
            // KHONG dong den Prefs.KEY_SERVER_WANTED - hanh dong nay chi
            // chay 1 lan backup NGAY, khong lam thay doi y dinh "may co
            // dang muon server chay hay khong" cua nguoi dung.
            runBackupFromNotification()
            return START_STICKY
        }
        getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
            .putBoolean(Prefs.KEY_SERVER_WANTED, true).apply()
        startServerInternal()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        heavyFlagHandler.removeCallbacksAndMessages(null)
        stopServerInternal()
        unregisterNetworkCallback()
        unregisterThermalListener()
        super.onDestroy()
    }

    /**
     * De xuat DeepSeek muc B5 (xem HANDOFF.md muc 10) - callback CHUAN cua
     * Android (ComponentCallbacks2, Service la 1 trong so cac lop triem
     * khai no) bao khi HE THONG (khong phai app nay) dang thieu RAM. KHONG
     * tu y "chuyen sang Lite mode" (dung ly do da ghi o HANDOFF.md - quyet
     * dinh Dual-Mode chi 1 lan luc setup, khong doi giua chung) - chi ghi
     * lai thoi diem de TelegramCommandWorker/BackupWorker tu doc va TAM
     * HOAN 1 chu ky (xem Prefs.KEY_LAST_MEMORY_PRESSURE_AT), giam bot viec
     * lam THEM dung luc may dang cang thang RAM nhat.
     */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            Log.w(TAG, "He thong bao RAM thap (level=$level) - tam hoan cac tac vu nen khong khan cap")
            try {
                getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
                    .putLong(Prefs.KEY_LAST_MEMORY_PRESSURE_AT, System.currentTimeMillis())
                    .apply()
            } catch (_: Exception) {
                // Ghi Prefs that bai khong duoc lam crash callback he thong nay.
            }
        }
    }

    // ---------------------------------------------------------------------

    private fun startServerInternal() {
        if (shouldRun) return
        shouldRun = true
        generation += 1
        val gen = generation
        publicUrl = null
        restartCount = 0
        lastExitCode = null
        lastErrorMessage = null

        // De xuat DeepSeek muc B7 - dat "moc 0" cho so lieu du lieu da dung
        // TU LUC NAY, xem sessionDataUsageBytes() o companion object phia
        // tren. Ghi ca 2 gia tri CUNG 1 luc (khong phai 2 lenh apply() rieng)
        // de tranh truong hop hiem gap tien trinh bi kill dung giua 2 lenh
        // ghi, de lai Rx/Tx mocnhau khong dong bo.
        try {
            val uid = android.os.Process.myUid()
            getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit()
                .putLong(Prefs.KEY_DATA_USAGE_BASELINE_RX, TrafficStats.getUidRxBytes(uid))
                .putLong(Prefs.KEY_DATA_USAGE_BASELINE_TX, TrafficStats.getUidTxBytes(uid))
                .apply()
        } catch (_: Exception) {
            // Khong doc duoc TrafficStats luc nay - sessionDataUsageBytes()
            // se tu dung gia tri HIEN TAI lam baseline mac dinh (xem ham do),
            // khong lam hong luong khoi dong server chinh.
        }

        val notification = buildNotification(getString(R.string.notif_starting))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        acquireWakeLock()

        siteThread = Thread({
            try {
                // Doi lan tat sach TRUOC (neu co) xong han - xem shutdownThread.
                awaitPreviousShutdown()
                if (!shouldRun || generation != gen) return@Thread
                prepareRuntimeIfNeeded()
                runSiteLoop(gen)
            } catch (e: Exception) {
                Log.e(TAG, "Loi khoi chay website", e)
                updateNotification(getString(R.string.notif_error, e.message ?: "unknown"))
            }
        }, "wp-pocket-site-worker").apply { isDaemon = true; start() }

        tunnelThread = Thread({
            try {
                Thread.sleep(1500) // cho website vai giay de bind cong truoc
                runTunnelLoop()
            } catch (e: Exception) {
                Log.e(TAG, "Loi khoi chay Cloudflare Tunnel", e)
            }
        }, "wp-pocket-tunnel-worker").apply { isDaemon = true; start() }
    }

    private fun stopServerInternal() {
        shouldRun = false
        isRunning = false
        publicUrl = null
        val site = siteProcess
        val tunnel = tunnelProcess
        siteProcess = null
        tunnelProcess = null
        // Tunnel khong co du lieu nao can flush -> tat ngay nhu cu.
        try { tunnel?.destroy() } catch (_: Exception) {}
        // Tach wake lock RIENG de giu CPU thuc cho den khi MariaDB flush xong
        // (truoc day nha ngay -> CPU co the ngu giua luc dang tat sach). Dung
        // ban sao cuc bo, khong dung truong wakeLock: neu nguoi dung bat lai
        // ngay, acquireWakeLock() cua phien MOI se thay the truong do - tha
        // nham no se thao wake lock cua phien moi.
        val wl = wakeLock
        wakeLock = null
        beginSiteShutdown(site, wl)
        // updateNotification() (xem ham do) KHONG duoc goi tren duong dung
        // server (notification se bi he thong tu xoa/thay the boi
        // stopForeground() ngay sau day) - nen can goi RIENG o day de widget
        // (neu co ghim) van kip cap nhat sang "Da tat" thay vi dung "cu"
        // mai o trang thai "Dang chay" cho toi chu ky 30 phut tiep theo.
        WppocketWidgetProvider.updateAll(applicationContext)
    }

    private fun releaseDetachedWakeLock(wl: PowerManager.WakeLock?) {
        try { wl?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
    }

    /**
     * Tat website SACH (xem HANDOFF.md muc 1au). Truoc day chi
     * siteProcess.destroy() - HANDOFF muc 1ab gia dinh "chi gui SIGTERM" nen
     * trap trong start-lamp.sh se chay, nhung tai lieu Android noi hanh vi
     * destroy() la "tuy implementation": neu thuc te la SIGKILL thi trap KHONG
     * BAO GIO chay va MariaDB bi giet cung moi lan bam "Tat server".
     * Cach lam khong phu thuoc loai tin hieu: ghi TOKEN PHIEN vao file
     * lamp-run/stop-requested, start-lamp.sh (vong giam sat) thay token khop
     * thi tu tat nginx/php-fpm/MariaDB sach roi thoat. Kotlin cho toi da
     * GRACEFUL_STOP_TIMEOUT_MS tren thread RIENG (khong chan main thread - ham
     * nay chay tren main thread), het gio moi destroy()/destroyForcibly().
     * Chi doi khi script CHO PHEP (marker graceful-stop-ready khop token: che do
     * Full da vao vong giam sat); Lite ("exec php -S", SQLite khong can flush)
     * hoac dang khoi dong -> destroy() ngay nhu cu, khong cho vo ich.
     */
    private fun beginSiteShutdown(site: Process?, wl: PowerManager.WakeLock?) {
        if (site == null) {
            releaseDetachedWakeLock(wl)
            return
        }
        val token = currentSessionToken
        val runDir = File(filesDir, "lamp-run")
        val gracefulReady = try {
            token != null && File(runDir, "graceful-stop-ready").readText().trim() == token
        } catch (_: Exception) { false }
        val stopFlag = File(runDir, "stop-requested")
        val flagWritten = gracefulReady && try {
            runDir.mkdirs()
            stopFlag.writeText(token!!)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Khong ghi duoc stop-requested, rot ve destroy()", e)
            false
        }
        if (!flagWritten) {
            try { site.destroy() } catch (_: Exception) {}
            releaseDetachedWakeLock(wl)
            return
        }
        val t = Thread({
            try {
                val exited = try {
                    site.waitFor(GRACEFUL_STOP_TIMEOUT_MS, java.util.concurrent.TimeUnit.MILLISECONDS)
                } catch (_: InterruptedException) { false }
                if (!exited) {
                    Log.w(TAG, "start-lamp.sh khong tat sach sau ${GRACEFUL_STOP_TIMEOUT_MS / 1000}s - buoc phai destroy()")
                    try { site.destroy() } catch (_: Exception) {}
                    val gone = try {
                        site.waitFor(3_000L, java.util.concurrent.TimeUnit.MILLISECONDS)
                    } catch (_: InterruptedException) { false }
                    if (!gone) try { site.destroyForcibly() } catch (_: Exception) {}
                }
            } finally {
                try { stopFlag.delete() } catch (_: Exception) {}
                releaseDetachedWakeLock(wl)
            }
        }, "wp-pocket-shutdown").apply { isDaemon = true; start() }
        shutdownThread = t
    }

    /**
     * Giải nén website từ assets/www.zip ra bộ nhớ riêng của app. www.zip
     * được CI đóng gói sẵn theo đúng site_source đã khai báo trong
     * site.config.json (WordPress, git repo, thư mục local, hoặc zip URL).
     *
     * LOI THAT (xem HANDOFF.md muc 1q): marker truoc day chi la "da giai nen
     * hay chua", nen cai APK MOI DE LEN ban cu khong bao gio giai nen lai -
     * moi thay doi trong www.zip khong co hieu luc. SUA: marker mang
     * `lastUpdateTime` cua APK (Android cap nhat MOI LAN cai/cai de); lech
     * gia tri -> giai nen lai, giong het -> giu nguyen.
     *
     * LOI THAT THU HAI (HANDOFF.md muc 1bo, PDF 2 muc AD3): ban sua 1q GIAI
     * NEN LAI bang `docRoot.deleteRecursively()` - xoa SACH moi thu trong
     * filesDir/www, ke ca du lieu nguoi dung (wp-content/uploads, plugin/theme
     * tu cai, CSDL SQLite cua che do Lite, tep tai len bang File Manager) o
     * MOI lan cap nhat APK. Nay GOP DE (xem [UpdateMergeLogic]): chi thay han
     * ma nguon cua chuong trinh, con lai ghi de len tep cung ten va giu moi
     * tep nguoi dung them vao. Chua hoan tat (kill giua chung) -> marker chua
     * duoc ghi nen lan sau tu thu lai (idempotent).
     */
    private fun prepareRuntimeIfNeeded() {
        val config = loadRuntimeConfig()
        val docRoot = File(config.docrootPath(filesDir.absolutePath))
        val marker = File(filesDir, ".www_extracted")
        val currentUpdateTime = try {
            packageManager.getPackageInfo(packageName, 0).lastUpdateTime
        } catch (e: Exception) { 0L }
        val markerUpdateTime = if (marker.exists()) marker.readText().trim().toLongOrNull() else null
        if (markerUpdateTime != currentUpdateTime) {
            updateNotification(getString(R.string.notif_extracting))
            val hadData = docRoot.exists() && (docRoot.list()?.isNotEmpty() == true)
            UpdateMergeLogic.prepareForMerge(docRoot)
            docRoot.mkdirs()
            val r = assets.open("www.zip").use { input -> UpdateMergeLogic.extractMerge(input, docRoot) }
            Log.i(TAG, "Giai nen website (${if (hadData) "cap nhat - giu du lieu nguoi dung" else "lan dau"}): " +
                "ghi ${r.written} tep, bo qua ${r.skippedLinks} muc qua symlink, ${r.skippedConflicts} xung dot thu muc")
            marker.writeText(currentUpdateTime.toString())
        }
        ensureAdminPassword()
    }

    /**
     * Sinh mật khẩu quản trị ngẫu nhiên (16 ký tự, SecureRandom) NẾU chưa có
     * - mỗi máy 1 mật khẩu riêng, không có giá trị mặc định nào. File này
     * được _admin/auth.php (PHP) đọc qua biến môi trường APP_HOME
     * (xem php-fpm.conf.template) để xác thực trang quản trị (Adminer +
     * File Manager) - trang này CHỈ vào được qua LAN, không qua tunnel
     * public (chặn ở nginx.conf), cộng thêm lớp mật khẩu này.
     */
    private fun ensureAdminPassword() {
        val pwFile = File(filesDir, "admin-password.txt")
        if (pwFile.exists()) return
        // 1bc: bo sinh dung chung voi MainActivity (truoc day 2 ban sao tu viet) + dam bao dat PasswordPolicy.
        pwFile.writeText(PasswordPolicy.generate())
    }

    private fun loadRuntimeConfig(): RuntimeConfig {
        val json = assets.open("runtime.json").bufferedReader().use { it.readText() }
        return RuntimeConfig.loadFromJson(json)
    }

    private fun cloudflaredBinaryPath(): String =
        File(applicationInfo.nativeLibraryDir, "libcfd.so").absolutePath

    /**
     * Vòng lặp chạy website - KHÔNG biết đó là PHP, Node hay Python. Toàn bộ
     * lệnh + biến môi trường đến từ runtime.json (RuntimeConfig).
     */
    private fun runSiteLoop(gen: Int) {
        val config = loadRuntimeConfig()
        currentPort = config.port
        var backoffMs = 2000L

        while (shouldRun && generation == gen) {
            try {
                updateNotification(getString(R.string.notif_running, config.port))

                val nativeLibDir = applicationInfo.nativeLibraryDir
                val filesDirPath = filesDir.absolutePath
                val execArgs = config.resolvedExec(nativeLibDir, filesDirPath)

                val pb = ProcessBuilder(execArgs)
                pb.redirectErrorStream(true)
                pb.directory(File(config.docrootPath(filesDirPath)))

                val env = pb.environment()
                env["LD_LIBRARY_PATH"] = nativeLibDir
                env["HOME"] = filesDirPath
                env["TMPDIR"] = cacheDir.absolutePath
                env["PORT"] = config.port.toString() // tiện cho Node/Python doc process.env.PORT
                // Thong tin THIET BI thuan tuy (khong biet gi ve PHP/Node/...) - giong
                // PORT/HOME/TMPDIR o tren, chi la 1 SU KIEN cua may, khong phai quyet
                // dinh cua Kotlin. Script build-time (runtime cu the, vd start-lamp.sh)
                // tu quyet dinh co dung hay khong - xem "Dual-Mode PHP-Lite" HANDOFF.md
                // muc 1e. Gia tri Prefs.KEY_PHP_LITE_MODE la nguoi dung TU chon ép
                // (Auto/Luon bat/Luon tat) qua app, khong phai app tu quyet dinh logic.
                env["DEVICE_RAM_MB"] = getDeviceTotalRamMb().toString()
                val liteOverride = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                    .getString(Prefs.KEY_PHP_LITE_MODE, Prefs.LITE_MODE_AUTO)
                if (liteOverride != Prefs.LITE_MODE_AUTO) env["FORCE_LITE_MODE"] = liteOverride

                // Auto-Sleep MariaDB khi ranh (xem Prefs.KEY_AUTO_SLEEP_ENABLED) - CHI
                // truyen "AUTO_SLEEP_ENABLED=1" khi nguoi dung TU bat trong app; neu
                // khong co bien nay, start-lamp.sh chay nhanh y het truoc day (xem chu
                // thich trong start-lamp.sh de biet vi sao lam vay - giam rui ro cho
                // nguoi khong dung tinh nang nay).
                val sleepPrefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                if (sleepPrefs.getBoolean(Prefs.KEY_AUTO_SLEEP_ENABLED, false)) {
                    env["AUTO_SLEEP_ENABLED"] = "1"
                    env["AUTO_SLEEP_IDLE_MINUTES"] = sleepPrefs
                        .getInt(Prefs.KEY_AUTO_SLEEP_IDLE_MINUTES, Prefs.DEFAULT_AUTO_SLEEP_IDLE_MINUTES)
                        .toString()
                }
                // R15-R18 (1bp): ho so hieu nang PHP; 0 = khong doi gi (start-lamp.sh bo qua)
                env["WPP_PHP_PROFILE"] = PhpTuning.clamp(sleepPrefs.getInt(Prefs.KEY_PHP_PROFILE, 0)).toString()
                // T1 (1bp-L): token API trang thai - CHI truyen khi nguoi dung bat API VA token hop le (start-lamp.sh kiem lai)
                if (sleepPrefs.getBoolean(Prefs.KEY_API_ENABLED, false)) {
                    val apiToken = SecretStore.get(sleepPrefs, Prefs.KEY_API_TOKEN, null)
                    if (apiToken != null && ApiLogic.isValidToken(apiToken)) env["WPP_API_TOKEN"] = apiToken
                }
                env.putAll(config.resolvedEnv(nativeLibDir, filesDirPath))
                // Token phien cho co dung sach (xem beginSiteShutdown) - dat SAU
                // resolvedEnv de runtime.json khong the ghi de nham.
                val sessionToken = "${System.currentTimeMillis()}-${System.nanoTime()}"
                env["WPP_SESSION"] = sessionToken
                currentSessionToken = sessionToken

                // B6: dat co "hoan viec nang khi khong sac" TRUOC khi site chay (xem Monitoring.syncHeavyJobsFlag).
                try { Monitoring.syncHeavyJobsFlag(applicationContext) } catch (_: Exception) {}
                val proc = pb.start()
                siteProcess = proc
                isRunning = true
                try { StatusApi.write(applicationContext) } catch (_: Exception) {}   // T1: lam moi tep trang thai ngay khi server len
                // Ghi CA vao Logcat (nhu truoc) LAN vao file ma _admin/logs.php da
                // tro toi san (tab "start-lamp") - truoc ban vay tab nay LUON TRONG
                // vi khong ai ghi ra file ca, chi co Log.d vao Logcat (loi da phat
                // hien khi ra soat toan bo du an, xem HANDOFF.md). Append (khong
                // truncate) de dong bo cach cac log khac (nginx/php-fpm/mariadb)
                // cung chi noi tiep, khong tu xoa - xem start-lamp.sh: khong file
                // log nao trong du an nay bi truncate/xoay vong ca, chap nhan don
                // gian cho 1 may micro-hosting ca nhan.
                try {
                    val logFile = File(filesDir, "start-lamp-stdout.log")
                    // Gioi han kich thuoc (xem STDOUT_LOG_MAX_BYTES): cat khi mo neu da
                    // qua lon, va kiem tra dinh ky khi dang ghi (chi file nay do Kotlin
                    // ghi - start-lamp.sh KHONG xoay vong no duoc).
                    if (logFile.length() > STDOUT_LOG_MAX_BYTES) logFile.writeText("")
                    val fos = java.io.FileOutputStream(logFile, true)
                    var linesSinceCheck = 0
                    fos.bufferedWriter().use { writer ->
                        proc.inputStream.bufferedReader().forEachLine { line ->
                            Log.d("site", line)
                            try {
                                writer.write(line)
                                writer.newLine()
                                writer.flush()
                                if (++linesSinceCheck >= 200) {
                                    linesSinceCheck = 0
                                    // O_APPEND: sau truncate(0) lan ghi ke tiep tu dong ve cuoi file (=0).
                                    if (logFile.length() > STDOUT_LOG_MAX_BYTES) fos.channel.truncate(0)
                                }
                            } catch (_: Exception) {
                                // Loi ghi file KHONG duoc lam dut vong forEachLine - van
                                // phai tiep tuc doc het stdout cua tien trinh con, neu
                                // khong buffer stdout day len co the treo tien trinh do.
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Khong mo duoc file (vd het dung luong) - rot ve CHI Logcat, khong
                    // lam hong viec doc/cho website chay.
                    Log.w(TAG, "Khong ghi duoc start-lamp-stdout.log, chi con Logcat", e)
                    proc.inputStream.bufferedReader().forEachLine { line -> Log.d("site", line) }
                }

                val exitCode = proc.waitFor()
                // Chi cap nhat trang thai TINH neu van la phien hien hanh - luong cu
                // (da bi thay boi generation moi) thuc day sau khi script cu tat sach
                // khong duoc ghi de isRunning/lastExitCode cua phien moi.
                if (generation == gen) {
                    isRunning = false
                    lastExitCode = exitCode
                }
                if (!shouldRun || generation != gen) break

                restartCount += 1
                Log.w(TAG, "Website thoat voi ma $exitCode, thu lai sau ${backoffMs}ms (lan thu $restartCount)")
                updateNotification(getString(R.string.notif_restarting))
                Thread.sleep(backoffMs)
                backoffMs = (backoffMs * 2).coerceAtMost(30_000L)
            } catch (e: Exception) {
                isRunning = false
                lastErrorMessage = e.message ?: e.toString()
                Log.e(TAG, "Khong the khoi chay website (kiem tra runtime.json / exec)", e)
                updateNotification(getString(R.string.notif_error, e.message ?: "unknown"))
                break
            }
        }
    }

    /**
     * Cloudflare Tunnel - có 2 chế độ:
     *  - Nếu người dùng đã lưu token (Cài đặt trong app, lấy từ dashboard
     *    Cloudflare Zero Trust) -> chạy "named tunnel", cho domain CỐ ĐỊNH,
     *    không đổi mỗi lần restart.
     *  - Nếu chưa có token -> "Quick Tunnel" mặc định, không cần tài khoản,
     *    nhưng URL ngẫu nhiên và đổi mỗi lần khởi động lại.
     */
    @Volatile private var lastAppliedSiteUrl: String? = null

    /**
     * Khi Quick Tunnel đổi domain (mỗi lần kết nối lại đều random khác -
     * xem HANDOFF.md mục 10, đề xuất DeepSeek mục F5), WordPress vẫn lưu
     * URL CŨ trong database (option "siteurl"/"home") - không tự đổi
     * theo. Hậu quả THẬT: ảnh/CSS/JS trỏ sai domain, có thể redirect loop
     * khi vào wp-admin. Đây CHỈ là fallback cho Quick Tunnel (không
     * token) - Named Tunnel (có token, domain cố định do người dùng tự
     * cấu hình trên dashboard Cloudflare) không cần vì URL không bao giờ
     * đổi, xem nhánh `!token.isNullOrEmpty()` phía trên.
     *
     * Chạy bootstrap WordPress THẬT (`wp-load.php`) thay vì tự đoán
     * DB_NAME/table_prefix rồi tự viết UPDATE SQL - vì người dùng có thể
     * tự đổi prefix hoặc tự upload 1 site WordPress khác (không qua
     * 1-Click Installer của app, xem `admin-install-wp.php` dùng "wp_"
     * CỐ ĐỊNH - không thể giả định điều đó đúng cho MỌI site). Đổi lại
     * chạy chậm hơn 1 UPDATE SQL trực tiếp (phải tải toàn bộ WordPress +
     * plugin đang bật) - chấp nhận được vì tần suất RẤT THẤP (chỉ khi
     * tunnel đổi URL, không phải mỗi request).
     */
    private fun updateWordPressSiteUrlIfNeeded(newUrl: String) {
        if (newUrl == lastAppliedSiteUrl) return
        val config = loadRuntimeConfig()
        val docRoot = File(config.docrootPath(filesDir.absolutePath))
        val wpConfig = File(docRoot, "wp-config.php")
        if (!wpConfig.exists()) return // khong phai site WordPress - bo qua im lang, khong phai loi

        Thread {
            try {
                val php = File(applicationInfo.nativeLibraryDir, "libphpcli.so")
                val phpIni = File(filesDir, "lamp-run/php.ini")
                if (!php.exists() || !phpIni.exists()) return@Thread // server chua san sang, bo qua lan nay

                val escapedUrl = newUrl.replace("\\", "\\\\").replace("'", "\\'")
                val escapedRoot = docRoot.absolutePath.replace("\\", "\\\\").replace("'", "\\'")
                val phpCode = """
                    define('WP_USE_THEMES', false);
                    ${'$'}_SERVER['HTTP_HOST'] = parse_url('$escapedUrl', PHP_URL_HOST);
                    ${'$'}_SERVER['REQUEST_URI'] = '/';
                    ${'$'}_SERVER['SCRIPT_NAME'] = '/index.php';
                    require '$escapedRoot/wp-load.php';
                    if (function_exists('update_option')) {
                        update_option('siteurl', '$escapedUrl');
                        update_option('home', '$escapedUrl');
                        echo 'OK';
                    } else {
                        echo 'SKIP:khong-phai-wordpress-that';
                    }
                """.trimIndent()

                val pb = ProcessBuilder(php.absolutePath, "-c", phpIni.absolutePath, "-r", phpCode)
                pb.redirectErrorStream(true)
                pb.environment()["APP_HOME"] = filesDir.absolutePath
                val proc = pb.start()
                // Doc output tren 1 thread RIENG, chay SONG SONG voi waitFor
                // co timeout o duoi - day la cach DUY NHAT vua tranh "treo vo
                // thoi han neu tien trinh khong bao gio thoat" (phai co
                // waitFor(timeout) that) vua tranh "deadlock neu output vuot
                // buffer pipe cua OS (~64KB) ma khong ai dang doc" (phai co
                // ai do LUON doc de "hut" buffer, khong doi waitFor xong moi
                // doc). Tung thu doc-truoc/waitFor-sau va waitFor-truoc/doc-
                // sau rieng le - CA HAI deu co 1 rui ro that, chi cach nay
                // (doc song song tren thread khac) giai quyet ca 2 cung luc.
                val outputBuilder = StringBuilder()
                val readerThread = Thread {
                    try {
                        proc.inputStream.bufferedReader().forEachLine { outputBuilder.appendLine(it) }
                    } catch (_: Exception) {
                        // Stream bi dong dot ngot (vd tien trinh bi
                        // destroyForcibly() o duoi) - khong sao, outputBuilder
                        // giu lai duoc bao nhieu thi giu.
                    }
                }
                readerThread.start()
                val finished = proc.waitFor(15, java.util.concurrent.TimeUnit.SECONDS)
                if (!finished) {
                    proc.destroyForcibly()
                    readerThread.join(2000)
                    Log.w(TAG, "Cap nhat siteurl WordPress qua han 15s, da huy (co the wp-load.php bi treo)")
                    return@Thread
                }
                readerThread.join(2000) // doi not vai dong cuoi neu chua doc kip
                val output = outputBuilder.toString().trim()
                if (output.startsWith("OK")) {
                    lastAppliedSiteUrl = newUrl
                    Log.d(TAG, "Da tu cap nhat siteurl/home WordPress theo URL tunnel moi")
                } else {
                    Log.w(TAG, "Khong tu cap nhat duoc siteurl WordPress: $output")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Loi khi tu cap nhat siteurl WordPress (khong anh huong website chinh)", e)
            }
        }.start()
    }

    /** Ghi/xoá file cờ `$RUNDIR/tunnel-named` theo đúng loại tunnel đang
     * dùng - đề xuất DeepSeek mục G6 (xem HANDOFF.md mục 10). Gọi lại mỗi
     * lần vòng lặp tunnel khởi động (kể cả reconnect) nên LUÔN phản ánh
     * đúng trạng thái hiện tại, kể cả khi người dùng đổi qua lại giữa
     * Named/Quick Tunnel giữa các lần chạy server. */
    private fun updateTunnelModeFlag(named: Boolean) {
        try {
            val flagFile = File(filesDir, "lamp-run/tunnel-named")
            if (named) {
                flagFile.parentFile?.mkdirs()
                if (!flagFile.exists()) flagFile.createNewFile()
            } else {
                if (flagFile.exists()) flagFile.delete()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Khong ghi/xoa duoc co tunnel-named (khong anh huong website chinh)", e)
        }
    }

    private fun runTunnelLoop() {
        var backoffMs = 3000L
        while (shouldRun) {
            try {
                val binPath = cloudflaredBinaryPath()
                if (!File(binPath).exists()) {
                    Log.w(TAG, "Khong tim thay libcfd.so, bo qua Cloudflare Tunnel (van chay tot o LAN)")
                    return
                }

                val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                val token = SecretStore.get(prefs, Prefs.KEY_TUNNEL_TOKEN, null)?.trim()
                // De xuat DeepSeek muc G6 (xem HANDOFF.md muc 10): ghi lai
                // co "dang dung Named hay Quick Tunnel" ra file, de
                // nginx.conf.template/router-lite.php doc duoc va tu quyet
                // dinh noi dung robots.txt (chan Google index URL Quick
                // Tunnel ngau nhien/tam thoi, KHONG chan khi Named Tunnel vi
                // do la domain that nguoi dung tu chon cong khai).
                updateTunnelModeFlag(named = !token.isNullOrEmpty())

                val pb = if (!token.isNullOrEmpty()) {
                    ProcessBuilder(binPath, "tunnel", "run", "--token", token, "--no-autoupdate")
                } else {
                    ProcessBuilder(binPath, "tunnel", "--url", "http://127.0.0.1:$currentPort", "--no-autoupdate")
                }
                pb.redirectErrorStream(true)
                pb.environment()["LD_LIBRARY_PATH"] = applicationInfo.nativeLibraryDir
                pb.environment()["HOME"] = filesDir.absolutePath

                tunnelProcess = pb.start()
                updateTunnelNotification(getString(R.string.notif_tunnel_connecting))

                if (!token.isNullOrEmpty()) {
                    // Named tunnel: domain do nguoi dung tu cau hinh tren dashboard
                    // Cloudflare, khong doc duoc tu log nhu Quick Tunnel.
                    publicUrl = getString(R.string.tunnel_named_active)
                    updateTunnelNotification(getString(R.string.notif_tunnel_named_ready))
                    maybeNotifyTelegram(publicUrl!!)
                }

                tunnelProcess?.inputStream?.bufferedReader()?.forEachLine { line ->
                    Log.d("cloudflared", line)
                    if (token.isNullOrEmpty()) {
                        val matcher = TUNNEL_URL_PATTERN.matcher(line)
                        if (matcher.find()) {
                            publicUrl = matcher.group()
                            updateTunnelNotification(getString(R.string.notif_tunnel_ready, publicUrl))
                            maybeNotifyTelegram(publicUrl!!)
                            updateWordPressSiteUrlIfNeeded(publicUrl!!)
                        }
                    }
                }

                val exitCode = tunnelProcess?.waitFor() ?: -1
                publicUrl = null
                if (!shouldRun) break

                Log.w(TAG, "cloudflared thoat voi ma $exitCode, thu lai sau ${backoffMs}ms")
                Thread.sleep(backoffMs)
                backoffMs = (backoffMs * 2).coerceAtMost(30_000L)
            } catch (e: Exception) {
                Log.e(TAG, "Khong the khoi chay cloudflared (khong anh huong website chinh)", e)
                return
            }
        }
    }

    /**
     * Bao cao tu dong qua Telegram Bot khi server vua co URL cong khai - de
     * xuat tu PDF "Tien loi hoa quan ly qua Telegram Bot: Nhan bao cao tu
     * dong" (xem HANDOFF.md muc 1e). Chi gui NEU nguoi dung da dien Bot
     * Token + Chat ID trong app (mac dinh KHONG gui gi ca). Chay tren thread
     * rieng (KHONG tren tunnelThread dang doc log) de khong lam cham/nghen
     * viec doc output cua cloudflared neu mang cham.
     */
    private fun maybeNotifyTelegram(url: String) {
        if (url == lastTelegramNotifiedUrl) return
        lastTelegramNotifiedUrl = url
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val botToken = SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
        if (!TelegramNotifier.isConfigured(botToken, chatId)) return
        Thread({
            val text = "WP Pocket Server da khoi dong.\nURL: $url"
            TelegramNotifier.sendMessage(botToken!!, chatId!!, text)
        }, "wp-pocket-telegram-notify").apply { isDaemon = true }.start()
    }

    /**
     * RAM VAT LY TONG cua thiet bi (khong phai RAM con trong) - dung
     * ActivityManager.MemoryInfo chinh thuc cua Android (khong doc
     * /proc/meminfo tu Kotlin - de _admin/index.php lam rieng, tranh trung
     * lap 2 co che khac nhau trong 1 du an). API nay luon truy cap duoc,
     * khong can quyen dac biet. Dung cho "Dual-Mode PHP-Lite" (xem
     * HANDOFF.md muc 1e).
     */
    private fun getDeviceTotalRamMb(): Long {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.totalMem / (1024 * 1024)
    }

    // --------------------------- Wake lock ---------------------------

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WPPocketServer::ServerWakeLock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // ------------------------- Network-aware (B3) -------------------------

    /**
     * De xuat DeepSeek muc B3 (xem HANDOFF.md muc 10) - dien thoai doi mang
     * lien tuc (WiFi <-> 4G) khac han VPS co dia chi mang CO DINH.
     * cloudflared THUONG tu ket noi lai duoc mot minh, nhung "thuong" khong
     * phai "luon luon" (bang chung: nhieu bao cao that trong cong dong
     * Cloudflare Tunnel ve tunnel "treo" sau khi doi mang, phai restart tay
     * moi het) - chu dong destroy() tien trinh cloudflared NGAY khi phat
     * hien doi LOAI mang (khong phai moi lan onCapabilitiesChanged() ban
     * ("VALIDATED" hay cac co khac co the doi nhieu lan TREN CUNG 1 mang) de
     * vong lap runTunnelLoop() da co san TU KHOI DONG LAI NGAY, khong doi
     * timeout tu nhien cua chinh no.
     */
    private fun registerNetworkCallback() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        connectivityManager = cm
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                val transport = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkCapabilities.TRANSPORT_WIFI
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkCapabilities.TRANSPORT_CELLULAR
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkCapabilities.TRANSPORT_ETHERNET
                    else -> null
                }
                val previous = lastNetworkTransport
                if (transport != null && previous != null && transport != previous) {
                    // Chot so data da dung cho DUNG mang CU truoc khi doi (xem
                    // Monitoring.updateDataBudget) - thu hep sai so uoc tinh "chi tinh
                    // 4G" xuong thay vi de ca 15 phut bi gan nham cho mang moi. Chay
                    // thread rieng: callback nay o thread cua ConnectivityManager,
                    // updateDataBudget co the goi Telegram (mang) - khong duoc chan no.
                    val wasCellular = previous == NetworkCapabilities.TRANSPORT_CELLULAR
                    Thread({
                        try { Monitoring.updateDataBudget(applicationContext, wasCellular) } catch (_: Exception) {}
                    }, "wp-pocket-databudget").start()
                }
                if (transport != null) lastNetworkTransport = transport
                if (transport != null && previous != null && transport != previous && shouldRun) {
                    Log.w(TAG, "Mang doi loai ($previous -> $transport) - khoi dong lai Cloudflare Tunnel")
                    try {
                        tunnelProcess?.destroy()
                    } catch (_: Exception) {
                        // vong lap runTunnelLoop() se tu phat hien tien
                        // trinh thoat (du la tu destroy() nay hay tu chet
                        // rieng) va thu lai binh thuong, khong can lam gi
                        // them o day du destroy() that bai.
                    }
                }
            }
        }
        networkCallback = callback
        try {
            cm.registerDefaultNetworkCallback(callback)
        } catch (e: Exception) {
            Log.w(TAG, "Khong dang ky duoc network callback (khong anh huong website chinh)", e)
        }
    }

    private fun unregisterNetworkCallback() {
        try {
            networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
        } catch (_: Exception) {
            // Co the da bi he thong tu huy dang ky truoc do - khong sao.
        }
        networkCallback = null
    }

    // ------------------------- Thermal-aware (B2) -------------------------

    /**
     * De xuat DeepSeek muc B2 (xem HANDOFF.md muc 10) - chi CO/GHI NHAN +
     * CANH BAO khi may nong (qua Telegram, tai dung ha tang
     * TelegramNotifier da co), KHONG tu dong giam pm.max_children cua
     * php-fpm nhu 1 huong mo rong PDF co nhac - viec do can RELOAD lai
     * php-fpm luc dang chay (khong chi sua file la du), rui ro lam GIAN
     * DOAN ca website dang chay tot de "phong ngua" 1 van de (may nong)
     * chi la CANH BAO, chua chac da anh huong toc do that - danh doi
     * khong dang, nen chi dung o muc CANH BAO cho nguoi dung tu quyet dinh.
     * API tu API 29 (Android 10) tro len - may cu hon se KHONG co tinh
     * nang nay (bo qua im lang, khong phai loi).
     */
    private fun registerThermalListener() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val pm = getSystemService(POWER_SERVICE) as? PowerManager ?: return
        val listener = PowerManager.OnThermalStatusChangedListener { status ->
            if (status >= PowerManager.THERMAL_STATUS_SEVERE) {
                Log.w(TAG, "May dang nong (thermal status=$status) - hieu nang co the giam tam thoi")
                maybeAlertThermal(status)
            }
        }
        thermalListener = listener
        try {
            pm.addThermalStatusListener(listener)
        } catch (e: Exception) {
            Log.w(TAG, "Khong dang ky duoc thermal listener (khong anh huong website chinh)", e)
        }
    }

    private fun unregisterThermalListener() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        try {
            val pm = getSystemService(POWER_SERVICE) as? PowerManager
            thermalListener?.let { pm?.removeThermalStatusListener(it) }
        } catch (_: Exception) {
            // Co the da bi he thong tu huy dang ky truoc do - khong sao.
        }
        thermalListener = null
    }

    /** Gioi han 1 canh bao/30 phut - "status nong" co the giu nguyen lien
     * tuc trong thoi gian dai, KHONG duoc gui spam Telegram moi lan he
     * thong bao lai gia tri (khac loi voi "doi trang thai" - o day CHINH
     * gia tri >= SEVERE tu no da la tin hieu can canh bao, khong can doi
     * "vua doi sang"). */
    private fun maybeAlertThermal(status: Int) {
        val now = System.currentTimeMillis()
        if (now - lastThermalAlertAtMs < 30 * 60 * 1000L) return
        lastThermalAlertAtMs = now
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        val botToken = SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
        val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
        if (!TelegramNotifier.isConfigured(botToken, chatId)) return
        Thread({
            TelegramNotifier.sendMessage(
                botToken!!, chatId!!,
                "WP Pocket Server: dien thoai dang NONG (muc $status/6) - hieu nang co the tam giam. Khong can lam gi, se tu binh thuong khi may nguoi."
            )
        }, "wp-pocket-thermal-notify").apply { isDaemon = true }.start()
    }

    // ------------------------- Backup tu notification -------------------------

    /** De xuat DeepSeek muc K3 - chay LAI CHINH XAC logic cua BackupWorker
     * (doc Prefs, goi BackupManager, gui Telegram/webhook neu co cau hinh)
     * nhung KHONG qua WorkManager (khong can doi lich, chay NGAY khi bam) -
     * ly do tach rieng ham nay thay vi goi thang BackupWorker: lop Worker
     * cua WorkManager duoc thiet ke de HE THONG tu khoi tao voi
     * WorkerParameters rieng, khong danh de goi tay truc tiep nhu 1 ham
     * thuong. Chap nhan LAP LAI 1 phan nho logic (khong phai dung chung ham)
     * de giu 2 lop nay doc lap, don gian hon la gian tiep qua WorkManager
     * "chay ngay lap tuc" (them do phuc tap khong can thiet cho 1 hanh dong
     * nguoi dung muon THAY KET QUA NGAY). */
    private fun runBackupFromNotification() {
        updateNotification(getString(R.string.notif_backup_running))
        Thread({
            try {
                val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
                val effectivePassphrase = BackupManager.effectivePassphrase(applicationContext)

                val result = BackupManager.performBackup(applicationContext, effectivePassphrase)

                val dbNote = if (result.dbDumped) "kem database" else "chi co file website, chua co database"
                val encNote = if (result.encrypted) ", DA MA HOA" else ""
                val caption = "WP Pocket Server - backup theo yeu cau (tu thong bao): ${result.file.name} ($dbNote$encNote)"

                val botToken = SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)
                val chatId = prefs.getString(Prefs.KEY_TELEGRAM_CHAT_ID, null)
                val tgConfigured = TelegramNotifier.isConfigured(botToken, chatId)
                val tgOk = if (tgConfigured) TelegramNotifier.sendDocument(botToken!!, chatId!!, result.file, caption) else true
                val webhookUrl = SecretStore.get(prefs, Prefs.KEY_BACKUP_WEBHOOK_URL, null)
                val whConfigured = WebhookUploader.isConfigured(webhookUrl)
                val whOk = if (whConfigured) WebhookUploader.uploadFile(webhookUrl!!, result.file) else true
                // HANDOFF 1bo-F: khong im lang khi ban sao ngoai may khong ton tai.
                val failNote = UploadLogic.failureNote(tgConfigured, tgOk, whConfigured, whOk, result.file.length())
                if (failNote != null) {
                    Log.w(TAG, failNote)
                    if (tgConfigured) TelegramNotifier.sendMessage(botToken!!, chatId!!, "WP Pocket Server - $failNote")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Backup tu notification that bai", e)
            } finally {
                // Khoi phuc lai dong thong bao binh thuong (trang thai site/
                // tunnel hien tai) - khong de ket qua backup "che" mat trang
                // thai server chinh mai mai.
                if (isRunning) {
                    updateNotification(getString(R.string.notif_running, currentPort))
                }
            }
        }, "wp-pocket-backup-from-notif").apply { isDaemon = true }.start()
    }

    // ------------------------- Notification -------------------------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val quiet = NotificationChannel(
            CHANNEL_ID_QUIET, getString(R.string.notif_channel_name_quiet), NotificationManager.IMPORTANCE_MIN
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(quiet)
    }

    /** Kenh thong bao theo che do: chuyen dung -> yen lang (MIN); binh thuong -> LOW. Doc Prefs moi lan dung thong bao nen doi cong tac co hieu luc o lan cap nhat ke tiep. */
    private fun activeChannelId(): String =
        if (getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE).getBoolean(Prefs.KEY_DEDICATED_MODE, false)) CHANNEL_ID_QUIET else CHANNEL_ID

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        // De xuat DeepSeek muc K3 (xem HANDOFF.md muc 10) - 3 nut hanh dong
        // NGAY tren thong bao, khong can mo app roi bam tiep trong UI. Dung
        // requestCode RIENG cho tung PendingIntent (1/2/3, khac requestCode=0
        // cua openIntent o tren) de tuyet doi khong lo lan voi nhau du khac
        // Intent action - an toan hon la dua vao rieng Intent.filterEquals().
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, ServerForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val backupIntent = PendingIntent.getService(
            this, 2, Intent(this, ServerForegroundService::class.java).setAction(ACTION_BACKUP_NOW),
            PendingIntent.FLAG_IMMUTABLE
        )
        val logIntent = PendingIntent.getActivity(
            this, 3, Intent(this, LogViewerActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, activeChannelId())
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            // Dung lai chung 1 icon co san (ic_notification) cho ca 3 nut -
            // he thong Android tu ve nut hanh dong bang TEXT + icon nho, y
            // nghia nam o chuoi text, khong bat buoc phai co icon RIENG cho
            // tung hanh dong (tranh phai tao them file drawable moi, giam
            // rui ro sai duong dan resource).
            .addAction(R.drawable.ic_notification, getString(R.string.notif_action_stop), stopIntent)
            .addAction(R.drawable.ic_notification, getString(R.string.notif_action_backup_now), backupIntent)
            .addAction(R.drawable.ic_notification, getString(R.string.notif_action_view_log), logIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
        // De xuat DeepSeek muc K2 - giu widget man hinh chinh (neu nguoi
        // dung co ghim) LUON khop voi thong bao/app, khong doi chu ky rieng
        // cua no (toi thieu 30 phut, qua cham cho 1 hanh dong nguoi dung
        // vua bam).
        WppocketWidgetProvider.updateAll(applicationContext)
    }

    private fun updateTunnelNotification(text: String) {
        val siteText = if (isRunning) getString(R.string.notif_running, currentPort) else getString(R.string.notif_starting)
        updateNotification("$siteText — $text")
    }
}
