# Chưa bật minify (isMinifyEnabled = false) nên file này hiện chưa có tác dụng.
# Giữ lại để bật sau này nếu cần giảm dung lượng APK.
