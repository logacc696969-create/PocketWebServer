# Thông báo về phần mềm bên thứ ba (Third-party notices)

> **Đây là tài liệu thông tin, không phải tư vấn pháp lý.** Nó liệt kê những gì WP Pocket Server đóng gói hoặc tải
> về lúc build, kèm giấy phép đã **kiểm tra từ nguồn gốc** (ghi rõ nguồn kiểm). Dự án **chưa có file `LICENSE` riêng** —
> chủ dự án cần tự chọn giấy phép cho mã của mình (xem mục "Việc chủ dự án cần quyết định" cuối file).

## 1. Thành phần được đóng gói vào APK

| Thành phần | Dùng để | Giấy phép | Nguồn kiểm tra |
|---|---|---|---|
| **cloudflared** (Cloudflare) | Cloudflare Tunnel (`libcfd.so`) | Apache License 2.0 | `LICENSE` trong repo `cloudflare/cloudflared` (đã đọc) |
| **Adminer** 6.1.2 (ghim) | Quản lý database (`_admin/db.php`) | Apache 2.0 **hoặc** GPL 2 (chọn một) | header `@license` trong chính file đã ghim (đã đọc) |
| **Tiny File Manager** 2.6 (ghim) | Quản lý file (`_admin/files.php`) | GNU GPL v3 | `LICENSE` trong repo `prasathmani/tinyfilemanager` tại tag 2.6 (đã đọc) |
| **WP-CLI** (`wp-cli.phar`) | Dòng lệnh WordPress | MIT | `LICENSE` trong repo `wp-cli/wp-cli` (đã đọc) |
| **WordPress** (khi dùng `site_source.type = wordpress`) | Hệ quản trị nội dung | GPL v2 hoặc mới hơn | giấy phép được WordPress.org công bố — **chưa kiểm lại trong repo này** |
| **Bộ CA gốc Mozilla** (`cacert.pem` từ curl.se) | PHP xác thực HTTPS khi 1-Click Install | MPL 2.0 (theo curl.se) | **chưa kiểm lại trong repo này** |
| **Gói Termux**: `nginx`, `php`, `php-fpm`, `php-mysql`, `mariadb`, `nodejs`, `python` và các thư viện phụ thuộc | Chạy web server/PHP/DB/Node/Python | **Mỗi gói một giấy phép riêng** (nginx: BSD-2-Clause; PHP: PHP License; MariaDB: GPL v2 …) | danh sách phiên bản chính xác nằm trong artifact `build-inputs` / `termux-manifest` của CI; giấy phép từng gói ghi trong gói `.deb` tương ứng — **chưa tổng hợp tự động ở đây** |
| **AndroidX** (core-ktx, appcompat, constraintlayout, work-runtime-ktx, profileinstaller), **Material Components**, **Kotlin stdlib** | Ứng dụng Android | Apache License 2.0 | giấy phép do Google/JetBrains công bố — **chưa kiểm lại trong repo này** |

Cột "Nguồn kiểm tra" nói thẳng chỗ nào đã đọc tận nguồn và chỗ nào mới dựa trên thông tin công khai chung — để không ai
nhầm "đã kiểm" với "chắc là vậy".

## 2. Hệ quả cần biết (GPL)

MariaDB (GPL v2), Tiny File Manager (GPL v3) và WordPress (GPL v2+) là phần mềm copyleft. Khi **phân phối APK chứa
chúng cho người khác**, nghĩa vụ của GPL (cung cấp mã nguồn tương ứng hoặc lời đề nghị cung cấp, giữ nguyên thông báo
bản quyền, không bổ sung hạn chế) áp dụng cho phần đó. Nếu chỉ tự dùng trên máy của mình thì không phát sinh nghĩa vụ
phân phối. Vấn đề cụ thể của bạn nên hỏi luật sư hoặc tổ chức tư vấn giấy phép mã nguồn mở.

Việc **ghim phiên bản** Adminer/Tiny File Manager (`scripts/lib/pins.env`) giúp việc đáp ứng nghĩa vụ này dễ hơn:
biết chính xác bản nào, nguồn nào, mã băm nào đã được đóng gói.

## 3. Việc chủ dự án cần quyết định (không phải việc của công cụ)

1. **Chọn giấy phép cho mã của dự án** và thêm file `LICENSE`. Các thành phần GPL ở trên được chạy như *chương trình riêng*
   (qua file PHP/tiến trình độc lập), không liên kết vào mã Kotlin; việc này ảnh hưởng đến lựa chọn, nên cân nhắc cùng chuyên gia.
2. Quyết định có **công bố mã nguồn tương ứng** của các bản GPL đã đóng gói trong mỗi lần phát hành hay không.
3. Nếu phát hành lên cửa hàng ứng dụng: kiểm tra chính sách của cửa hàng về chạy tệp thực thi tải lúc build và về dịch vụ nền.
