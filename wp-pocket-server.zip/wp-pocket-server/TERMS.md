# Điều khoản sử dụng (bản nháp)

> Đây là bản nháp mô tả kỳ vọng hợp lý, **không phải tư vấn pháp lý**. Chủ dự án nên rà soát với luật sư trước khi phân phối rộng rãi, đặc biệt nếu thu phí hoặc phục vụ người dùng ở nhiều quốc gia.

1. **"Nguyên trạng".** Phần mềm được cung cấp như hiện có, không bảo đảm chạy liên tục (không có SLA) và không bảo đảm phù hợp mục đích cụ thể. Điện thoại có thể tắt, mất mạng hoặc hỏng.
2. **Trách nhiệm của bạn.** Bạn chịu trách nhiệm về nội dung website bạn chạy, về việc tuân thủ luật áp dụng (bảo vệ dữ liệu cá nhân, bản quyền, nội dung cấm), và về việc sao lưu dữ liệu. Xem `docs/DISASTER_RECOVERY.md` để biết app bảo vệ được gì và không bảo vệ được gì.
3. **Dịch vụ bên thứ ba.** Cloudflare, Telegram, WordPress.org và các dịch vụ khác có điều khoản riêng; bạn tự chịu trách nhiệm tuân thủ.
4. **Dữ liệu.** App không gửi dữ liệu của bạn đến chủ dự án. Xem `PRIVACY.md`.
5. **Giới hạn trách nhiệm.** Trong phạm vi luật cho phép, người đóng góp không chịu trách nhiệm cho thiệt hại gián tiếp hoặc mất dữ liệu do dùng phần mềm.
6. **Giấy phép mã nguồn.** **Chưa được chọn** — cần chủ dự án quyết định và thêm tệp `LICENSE` (xem `docs/LICENSE_OPTIONS.md`). Cho đến khi đó, mặc định mọi quyền được bảo lưu, **trừ phần cấp phép thử nghiệm ở điều 7**.
7. **Giai đoạn thử nghiệm miễn phí (beta).** *(Bản nháp theo định hướng của chủ dự án: phát hành miễn phí để người dùng kiểm thử độ ổn định, sau đó mới xem xét tính phí — cần luật sư rà soát.)*
   - **Quyền được cấp.** Chủ bản quyền **[TÊN CHỦ BẢN QUYỀN] © [NĂM]** cho bạn quyền **miễn phí, không độc quyền, có thể thu hồi** để cài đặt và chạy **bản thử nghiệm** của ứng dụng cho mục đích cá nhân và để kiểm thử. Quyền này **chỉ áp dụng cho phần mã do dự án tự viết**; các thành phần bên thứ ba (MariaDB, Tiny File Manager, WordPress, nginx, cloudflared…) giữ **giấy phép riêng** (`THIRD_PARTY_NOTICES.md`) và quyền của bạn với chúng **không bị hạn chế** bởi điều khoản này.
   - **Bản thử nghiệm có thể lỗi, kể cả mất dữ liệu.** Đừng dùng cho website quan trọng; luôn giữ bản sao lưu **ngoài điện thoại** và ngoài app.
   - **Phản hồi là tự nguyện.** Nếu bạn gửi nhật ký hoặc ảnh chụp màn hình, hãy che địa chỉ IP, token, mật khẩu (`docs/BETA_PROGRAM.md`). Chủ dự án có thể dùng phản hồi để cải thiện sản phẩm.
   - **Sau thử nghiệm, có thể tính phí.** Điều khoản này **không hứa** miễn phí vĩnh viễn cho các phiên bản sau. **[CHỦ DỰ ÁN QUYẾT: bản thử nghiệm đã tải có được tiếp tục dùng miễn phí sau khi kết thúc thử nghiệm không? giá và đối tượng tính phí? — chưa quyết]**.
   - Không bảo đảm, không SLA, giới hạn trách nhiệm như điều 1 và 5.
