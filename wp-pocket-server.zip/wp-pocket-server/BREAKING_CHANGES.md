# Thay đổi cần người dùng chú ý (breaking changes)

Một thay đổi được ghi ở đây khi nó **buộc bạn làm gì đó** hoặc **đổi hành vi mặc định** theo cách có thể gây bất ngờ. Chính sách: ghi ngay trong cùng đợt sửa, kèm cách xử lý.

## Vòng 31 (HANDOFF.md mục 1br)

| Thay đổi | Ảnh hưởng | Cách xử lý |
|----------|-----------|------------|
| Shield (mu-plugin) **tự cài vào cả site WordPress cũ** khi app khởi động | Site có thêm file `wp-content/mu-plugins/wppocket-shield.php` + thư mục `wppocket-shield/` | Không muốn: tạo file `lamp-run/shield-no-install` và xoá hai mục trên; tắt khẩn cấp: `lamp-run/shield-off` |
| WordPress: **mật khẩu ứng dụng (Application Passwords) bị tắt** | Ứng dụng/dịch vụ ngoài đang dùng mật khẩu ứng dụng (app WordPress di động, một số công cụ tự động) mất quyền truy cập REST | Bật lại ở Trung tâm bảo mật: công tắc `shield-allow-app-passwords` |
| WordPress: **tắt sửa file plugin/theme trong trang quản trị** (`DISALLOW_FILE_EDIT`) | Không còn trình sửa mã trong wp-admin | Công tắc `shield-allow-file-edit` (nếu `wp-config.php` đã tự định nghĩa hằng này thì giữ theo wp-config) |
| WordPress: khách **không còn đọc được danh sách tài khoản** qua `/wp-json/wp/v2/users`, `?author=N`, sitemap | Site headless/ứng dụng đọc danh sách tác giả công khai sẽ lỗi | Công tắc `shield-allow-user-api` |
| WordPress: thông báo đăng nhập sai nay **chung chung**; một tài khoản bị dò quá nhiều lần vào "chế độ phòng thủ" ~15 phút (chỉ mạng đã từng đăng nhập thành công mới vào được) | Chủ site đăng nhập từ mạng hoàn toàn mới đúng lúc tài khoản bị dò sẽ bị từ chối tạm | Đợi ~15 phút, hoặc "Gỡ phòng thủ" ở Trung tâm bảo mật |
| nginx: **IP bị chấm điểm và tự chặn** (444); phương thức HTTP lạ trả 405; `readme.txt`/`changelog`/`license` của plugin/theme trả 404 | Công cụ giám sát/quét bên ngoài lạ có thể bị chặn; công cụ cần đọc readme plugin sẽ không đọc được | IP tin cậy ở Trung tâm bảo mật; không có công tắc tắt riêng cho 404 readme |
| `_admin/`: **chỉ chấp nhận tên truy cập (Host) hợp lệ** (địa chỉ IP, `localhost`, tên một nhãn như `dienthoai`, đuôi `.local/.lan/.home.arpa/.internal`, hoặc tên đã khai) | Truy cập qua tên miền riêng/reverse proxy lạ bị từ chối với thông báo hướng dẫn | Thêm tên vào `lamp-run/admin-allowed-hosts.txt` (mỗi dòng một tên) |
| WordPress: mu-plugin **đăng nhập hai bước** (`wppocket-2fa.php` + thư mục `wppocket-2fa/`) **tự cài vào cả site cũ**; **thông báo đăng nhập sai nay thống nhất** ("Sign-in failed. Check your username, password and authentication code.") | Site có thêm file mu-plugin; ô "authentication code" chỉ hiện ở form đăng nhập **sau khi có người bật hai bước**; tích hợp tự đọc nội dung lỗi đăng nhập có thể thấy văn bản khác | Không muốn cài: tạo `lamp-run/twofa-no-install` và xoá hai mục trên; tắt khẩn cấp: `lamp-run/twofa-off`. Mất điện thoại: dùng mã khôi phục, quản trị viên khác đặt lại, hoặc `wp user meta delete <ID> wppocket_2fa` |
| WordPress: **XML-RPC trả danh sách phương thức rỗng** (ngoài việc đã tắt) | Công cụ đọc `system.listMethods` thấy rỗng | Không cần xử lý (XML-RPC đã tắt từ trước) |
| **Tuỳ chọn mới, mặc định TẮT:** kiểm lỗ hổng đã biết (`lamp-run/vuln-check-on`) | Khi bạn **tự bật**, app gửi *tên thư mục plugin/theme + phiên bản + phiên bản WordPress* tới `www.wpvulnerability.net` mỗi giờ | Chỉ bật khi chấp nhận; xem `PRIVACY.md` mục 3. Tắt: xoá cờ |
| `_admin/`: mã TOTP **chỉ dùng được một lần** | Nhập lại cùng mã trong cùng 30 giây bị từ chối | Đợi mã mới |
| PHP: `allow_url_include=0`, `enable_dl=0`, cookie phiên `HttpOnly`/`SameSite=Lax`/strict | Code PHP tuỳ chỉnh dùng `include 'http://...'` hay `dl()` sẽ lỗi | Dùng `require` file cục bộ |

## Vòng 28 (HANDOFF.md mục 1bo)

| Thay đổi | Ảnh hưởng | Cách xử lý |
|----------|-----------|------------|
| `site.config.json` **khoá lạ/gõ sai nay làm CI dừng** (trước đây bị bỏ qua im lặng) | Build đỏ ở bước "Kiểm tra site.config.json" nếu file có khoá sai | Sửa theo gợi ý trong thông báo; khoá ghi chú bắt đầu bằng `_` vẫn được phép |
| Thêm khoá `config_version` (hiện là `1`, có thể vắng) | Không cần làm gì với file cũ | Giữ nguyên hoặc thêm `"config_version": 1` |
| Cài đè APK: `wp-config.php` được **sinh lại** | Phiên đăng nhập WordPress hết hạn một lần | Đăng nhập lại |
| Cài đè APK: tệp đã bị gỡ khỏi gói mới **không tự bị xoá** | Tệp thừa có thể còn trên máy | Xoá tay bằng File Manager nếu muốn |
| Backup > 50 MB không gửi được qua Telegram (vẫn luôn như vậy, nay được **báo rõ**) | Bạn sẽ nhận cảnh báo "CHƯA có bản sao ngoài máy" | Dùng webhook nhận tệp lớn hoặc xuất backup thủ công |
| Sự kiện cảnh báo `backup_failed` nay cũng dùng cho "gửi ra ngoài lỗi" | Webhook cảnh báo có thể nhận `backup_failed` kể cả khi backup trong máy đã tạo xong | Đọc trường `text` để phân biệt |

## Vòng 1bp

| Thay đổi | Ảnh hưởng | Cách xử lý |
|----------|-----------|------------|
| Mỗi dòng `nginx-access.log` có thêm trường `rid=<32 ký tự hex>` **ở cuối** | Công cụ phân tích log bên ngoài đọc theo cột cố định có thể thấy một trường thừa; trang Analytics của app không bị ảnh hưởng (đã kiểm) | Bỏ qua trường cuối hoặc dùng nó để tra lỗi |
| Mọi response có thêm header `X-Request-ID` | Không ảnh hưởng chức năng | — |
| Token Telegram/Cloudflare, URL webhook/heartbeat và cụm mật khẩu backup được **mã hoá** trong SharedPreferences (tự di trú lần đọc đầu) | **Hạ cấp** xuống bản app cũ sẽ không đọc được các giá trị này; khôi phục máy làm mất khoá Keystore cũng khiến chúng không giải mã được | Nhập lại token khi gặp; luôn ghi token/cụm mật khẩu ở nơi an toàn bên ngoài |
| `nginx.conf` ghi rõ `fastcgi_read_timeout 60s` (đúng giá trị mặc định cũ) | Không đổi hành vi | — |

## Trước vòng 28
Chưa có tài liệu riêng; xem `HANDOFF.md`.
