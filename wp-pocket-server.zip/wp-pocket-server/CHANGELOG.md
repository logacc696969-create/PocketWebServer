# Nhật ký thay đổi

Định dạng theo kiểu "Keep a Changelog": mục **Sửa lỗi**, **Thêm**, **Thay đổi**. Lịch sử kỹ thuật đầy đủ từng vòng làm việc nằm ở `HANDOFF.md` (nguồn sự thật); file này chỉ tóm tắt cái người dùng cần biết. Thay đổi cần người dùng làm gì đó xem `BREAKING_CHANGES.md`.

## Chưa phát hành — vòng 31 (HANDOFF.md mục 1br)

### Thêm
- **Bảo mật chống tấn công tự động hoá/AI** (xem `docs/SECURITY.md`):
  - **Tự chặn IP**: đọc log bảo mật nginx, chấm điểm và chặn IP quét/dò (1 giờ → 24 giờ → 7 ngày); không chặn IP mạng nội bộ; có danh sách IP tin cậy.
  - **Quét mã độc**: PHP trong `uploads/`, ảnh chứa mã PHP, so lõi WordPress với checksum chính thức, file PHP lạ, mu-plugin/drop-in mới đổi, plugin/theme mới, web shell; cách ly và khôi phục được.
  - **Shield (mu-plugin WordPress, tự cài vào cả site cũ)**: ẩn danh sách tài khoản, chống dò mật khẩu phân tán theo tài khoản, nhật ký admin mới/đổi quyền/đổi email/bật plugin, tắt mật khẩu ứng dụng, ẩn phiên bản.
  - **Trung tâm bảo mật** `_admin/security.php`; **điểm sức khoẻ** và dòng "Quét mã độc", "IP khách thật" ở `_admin/health.php`.
  - **Cảnh báo Telegram** khi có sự kiện bảo mật nghiêm trọng (tối đa 1 lần/10 phút).
  - Tuỳ chọn chặn crawler AI thu thập dữ liệu (`block-ai-on`, mặc định **tắt**).
  - **Đăng nhập hai bước (TOTP) cho WordPress** (mu-plugin `wppocket-2fa`, tự cài như Shield, tuỳ chọn từng người dùng ở trang Hồ sơ): mã RFC 6238 dùng một lần, 8 mã khôi phục, bí mật mã hoá trong CSDL, thông báo lỗi thống nhất, tắt khẩn cấp bằng công tắc `twofa-off`. Chưa ai bật thì đăng nhập y như cũ.
  - **Kiểm lỗ hổng đã biết của plugin/theme/lõi** (`vuln-check-on`, **mặc định TẮT** vì gửi tên + phiên bản ra `wpvulnerability.net`): kết quả ở Trung tâm bảo mật, trong "tự kiểm tra" và cảnh báo Telegram.
- Kiểm thử ngẫu nhiên có hạt giống cố định cho mọi trang `_admin/` (`admin-fuzz-test.py`).
- **Kiểm thử trên môi trường thật** (dựng từ mã nguồn GitHub): `security-nginx-test.py` (nginx 1.31.8 + php-fpm 8.3 thật), `wp-real-test.py` (WordPress 7.1.4 thật + 4 plugin lớn), `wp-2fa-test.py`, `security-vuln-test.py`.

### Thay đổi
- **nginx**: ẩn phiên bản, cắt kết nối đọc/ghi chậm, từ chối phương thức HTTP lạ, trả 404 cho `readme/changelog/license` của plugin/theme, không ghi log "file không tồn tại" cho mỗi lần quét.
- **XML-RPC**: ngoài việc tắt, danh sách phương thức nay **rỗng** (`system.listMethods` không còn lộ gì).
- **PHP**: `allow_url_include=0`, `enable_dl=0`, không đưa tham số hàm vào stack trace, cookie phiên `HttpOnly` + `SameSite=Lax` + chế độ strict.
- **Trang `_admin/`**: chỉ chấp nhận tên truy cập (Host) hợp lệ (chống DNS rebinding; thêm tên riêng vào `lamp-run/admin-allowed-hosts.txt`), mã TOTP chỉ dùng được một lần.

### Sửa lỗi
- Lỗi tìm ra khi chạy trên môi trường thật: (1) quét mã độc báo **15 file lõi WordPress sạch là mã độc** khi chưa có checksum (chữ ký hex quá rộng); (2) web shell dạng `$f=$_POST[k]; $f($_POST[v])` lọt lưới; (3) `xmlrpc_enabled=false` vẫn lộ danh sách phương thức; (4) trong lúc làm 2FA: kiểm mã chạy hai lần làm báo sai khi tạo lại mã khôi phục.
- Trang `_admin/`: bộ đếm khoá đăng nhập có thể bị đặt lại khi hai request cùng lúc (lỗi đua) — nay ghi nguyên tử.
- `_admin/` console WP-CLI: lệnh chứa byte NUL gây lỗi 500 — nay bị từ chối.
- Hai bài kiểm Kotlin cũ hỏng sẵn (`BackupLogicTest`, thiếu file trong `run-monitorlogic-test.sh`) đã sửa.

### Lưu ý khi nâng cấp
- Shield tắt **mật khẩu ứng dụng** và **sửa file plugin/theme trong trang quản trị** của WordPress theo mặc định. Nếu bạn cần, bật lại bằng công tắc `shield-allow-app-passwords` / `shield-allow-file-edit` ở Trung tâm bảo mật.
- Đã kiểm trên nginx + php-fpm + WordPress thật (dựng từ mã nguồn); **vẫn chưa kiểm trên điện thoại thật và với MariaDB**: xem `docs/SECURITY.md` mục 8.
- Mu-plugin hai bước được tự chép vào cả site cũ; muốn tự quản lý thì tạo `lamp-run/twofa-no-install`.
- Đã thử khoá hàm chạy lệnh hệ thống (`disable_functions`) cho PHP công khai và **gỡ bỏ** vì lỗi thiết kế tìm thấy khi thử trên php-fpm thật (xem `HANDOFF.md` mục 1br-H) — không có thay đổi hành vi nào từ việc này.

### Sửa tài liệu
- Bảng đối chiếu PDF: M3, H4, C10, R19, R20 → Đã làm; ghi chú G5, R13 cập nhật.

## Chưa phát hành — vòng 30 (HANDOFF.md mục 1bq)

### Thêm
- **Mã QR chia sẻ địa chỉ website**: nút "Chia sẻ liên kết / mã QR" mở hộp thoại có mã QR để khách quét bằng camera, kèm Sao chép và Chia sẻ…. Mã QR do chính dự án tự tạo (không thêm thư viện) và đã được kiểm bằng bộ giải mã QR thật.

- **Ngưỡng và quy tắc cảnh báo chỉnh được**: nút mới cho đổi 4 ngưỡng (bộ nhớ đầy, pin cạn, pin ấm, pin quá nóng) và tự viết quy tắc cảnh báo (mỗi dòng một quy tắc, 6 chỉ số, báo lỗi từng dòng). Mặc định giữ nguyên như trước; gửi qua Telegram. Xem `docs/ALERT_RULES.md`.

- **Nút "Báo lỗi (mở form GitHub)"** ở màn hình Nhật ký: mở form Issue điền sẵn phiên bản app và mẫu máy (không gửi nhật ký/IP/token). Xem `docs/BETA_PROGRAM.md`.
- **Tài liệu giá trị và đối tượng dùng** (`docs/VALUE_AND_AUDIENCE.md`): app dành cho ai, không dành cho ai; mỗi tuyên bố kèm bằng chứng trong repo.
- **Tối ưu ảnh WordPress**: mu-plugin mới giới hạn ảnh hiển thị, tạo WebP cho ảnh JPEG mới (nếu máy chủ hỗ trợ), tuỳ chọn xoá ảnh gốc (mặc định tắt). Xem `docs/IMAGE_OPTIMIZATION.md`.
- **Trợ năng**: vùng chạm tối thiểu 48dp cho hai nút, nhãn cho ô số phút Auto-Sleep, trạng thái server được TalkBack đọc khi đổi.
- **Địa chỉ công khai nhấp nháy** khi hầm Cloudflare đang được tạo (tôn trọng cài đặt xoá hoạt ảnh).
- **Tài liệu**: mô hình quản trị, hướng dẫn mở rộng, kịch bản video hướng dẫn, trợ năng.
- **Giai đoạn thử nghiệm miễn phí (bản nháp tài liệu)**: `TERMS.md` điều 7, `docs/BETA_PROGRAM.md`, mẫu báo cáo beta, `docs/LICENSE_OPTIONS.md` cập nhật theo định hướng "miễn phí thử nghiệm trước, tính phí sau", `docs/LEGAL_NOTES_VN.md`. Chưa chọn giấy phép; cần luật sư rà soát.
- **Khôi phục bị gián đoạn được phát hiện**: nếu tắt app/mất điện giữa lúc khôi phục, sau 15 phút app báo Telegram rằng site có thể đang dở dang và gợi ý chạy lại khôi phục từ cùng bản backup.
- **Kiểm thử hỗn loạn** (`chaos-test.py`, `chaos-device.sh`): xem `docs/CHAOS_TESTING.md`.
- **Công cụ dòng lệnh `wppocket`** (`scripts/tools/wppocket_cli.py`): xem trạng thái, `--check` kiểu Nagios, theo dõi liên tục qua API LAN chỉ đọc. Xem `docs/CLI.md`.
- **Máy chủ WSGI và ASGI cho Python** (thay gunicorn, uvicorn): `"wsgi": "app:app"` chạy Flask/Django, `"asgi": "app:app"` chạy Starlette (HTTP + lifespan); chỉ dùng thư viện chuẩn. Preset mới `python-wsgi`, `python-asgi`. Không hỗ trợ WebSocket/SSE. Xem `docs/PYTHON_WSGI.md`.

### Sửa lỗi
- Runtime Node/Python/tĩnh: khởi động thất bại giữa chừng (vd đầy bộ nhớ) không còn để lại app chạy ngầm; dọn tiến trình mồ côi bền hơn (quét `/proc`, ép KILL khi cần).

### Sửa tài liệu
- Bảng đối chiếu PDF: rung khi bấm nút (J1) và lề theo kích thước màn hình (Q9) thực ra đã có từ trước, bảng cũ ghi nhầm "chưa làm".

## Chưa phát hành — vòng 28 (HANDOFF.md mục 1bo)

### Sửa lỗi
- **Cài đè APK không còn xoá dữ liệu website** (ảnh, plugin/theme tự cài, CSDL SQLite của chế độ Lite, tệp tải lên bằng File Manager). Trước đây mỗi lần cài đè xoá sạch thư mục website.
- **Gửi backup ra ngoài không còn đệm cả file trong RAM** (nguy cơ hết bộ nhớ làm sập app với backup lớn).
- **Không còn báo "backup thành công" khi bản sao ngoài máy không tồn tại** (ví dụ tệp > 50 MB với Telegram). Nay có cảnh báo rõ.

### Thêm
- Thanh tiến trình khi backup / khôi phục / xuất / nhập; các nút tác vụ bị khoá trong lúc chạy.
- Nút **Dữ liệu trên máy và xoá toàn bộ…** (xem dung lượng; xoá cần gõ lại từ xác nhận).
- Kiểm tra `site.config.json` ngay đầu build (dòng/cột khi lỗi, gợi ý khoá gõ sai) và khoá `config_version`.
- Tài liệu: `docs/FAILURE_MODES.md`, `docs/DISASTER_RECOVERY.md`, `docs/DATA_AND_SECRETS.md`, `docs/RELEASE_AND_COMPATIBILITY.md`, `docs/COMPETITIVE_ANALYSIS.md`, `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `TERMS.md`, `BREAKING_CHANGES.md`.

### Thêm (vòng 1bp)
- Cảnh báo Telegram khi PHP gặp lỗi nghiêm trọng (hết bộ nhớ, quá thời gian, lỗi cú pháp, lỗi không xử lý), gom nhóm, tối đa 1 lần/giờ.
- Nút **Kiểm tra cơ sở dữ liệu** (CHECK TABLE chỉ đọc) và nút **Hiệu năng PHP…** (3 hồ sơ, mặc định không đổi gì).
- Bí mật (token Telegram/Cloudflare, URL webhook/heartbeat, cụm mật khẩu backup) được mã hoá AES-GCM bằng khoá Android Keystore; fail-open nếu máy không hỗ trợ.
- Tuỳ chọn lưu backup mới trên thẻ nhớ khi có (mặc định tắt); baseline profile cho khởi động nhanh hơn (kèm `androidx.profileinstaller`); nút Bật server bị khoá khi server đang chạy.
- API trạng thái chỉ đọc cho mạng LAN (tuỳ chọn, mặc định tắt, token Bearer, chỉ dải mạng riêng, không có endpoint ghi).
- Mã request: header `X-Request-ID` và trường `rid=` trong `nginx-access.log`.

### Thay đổi
- Khi cài đè APK, `wp-config.php` được sinh lại từ mẫu (đăng nhập WordPress phải làm lại một lần); tệp bị gỡ khỏi gói website mới không tự bị xoá khỏi máy.

## Trước vòng 28
Xem `HANDOFF.md` (các mục 1a…1bn) và chuỗi "CÓ GÌ MỚI" trong app.
