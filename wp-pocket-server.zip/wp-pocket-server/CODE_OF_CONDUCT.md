# Quy tắc ứng xử

Dự án muốn là nơi người ở mọi trình độ đều hỏi và đóng góp được mà không bị coi thường.

## Mong đợi
- Tôn trọng, nói về vấn đề kỹ thuật chứ không về con người.
- Góp ý cụ thể và có thể hành động; chấp nhận ý kiến khác.
- Không công bố thông tin riêng của người khác (token, log chưa che, địa chỉ nhà/IP) và không yêu cầu người khác gửi chúng công khai.

## Không chấp nhận
Quấy rối, xúc phạm, phân biệt đối xử, đe doạ, spam, và dùng dự án để tấn công/xâm nhập hệ thống không thuộc quyền của bạn.

## Xử lý
Người duy trì có thể xoá nội dung, từ chối đóng góp hoặc chặn người vi phạm lặp lại. Báo cáo bằng cách mở Issue trên kho mã nguồn của dự án (hoặc liên hệ riêng chủ dự án nếu nội dung nhạy cảm).

*(Tài liệu này tự viết cho dự án; chủ dự án có thể thay bằng một mẫu cộng đồng chuẩn như Contributor Covenant nếu muốn.)*
