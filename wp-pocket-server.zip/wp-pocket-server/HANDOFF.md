# HANDOFF — WP Pocket Server

> Đọc file này trước khi động vào code. Mục tiêu: không lặp lại các quyết
> định/rủi ro đã xác định bên dưới.

## 1. Mục tiêu gốc (yêu cầu người dùng, không đổi)

- App Android **tự nó là server** — KHÔNG qua app trung gian (Termux) lúc
  chạy. Thay thế hoàn toàn việc thuê hosting/server hàng tháng.
- Chạy nền được khi **tắt màn hình** (bắt buộc, không phải optional).
- Deliverable = **source code build APK qua GitHub Actions**, không phải
  file `.apk` đã compile sẵn.
- **Không hardcode 1 backend cụ thể.** Hỗ trợ PHP/Node/Python/static qua
  config, nhưng chỉ chạy **1 website tại 1 thời điểm** (không multi-tenant —
  "nhiều backend" = linh hoạt chọn nền tảng, không phải chạy song song
  nhiều site).
- Ưu tiên ban đầu: WordPress. Nhưng kiến trúc phải tổng quát hoá được.

## 1b. Cập nhật (vòng phản hồi thứ 2): "hạn chế" không phải cái cớ để dừng

Sau khi liệt kê 7 hạn chế thực tế cho người dùng, người dùng phản hồi đúng:
nhiều cái trong đó là "chưa làm" chứ không phải "không làm được". Đã tra
cứu + implement lại 4/7 cái bằng đúng kỹ thuật đã dùng (mượn binary Termux),
KHÔNG cần công nghệ mới:

| # | Hạn chế cũ | Đã xử lý | Cách |
|---|---|---|---|
| 1 | `php -S` không phải server production | ✅ Đã fix | Đổi sang **nginx + php-fpm** thật (Termux có gói `nginx`, `php-fpm` — xác nhận qua search, cộng đồng Termux dùng combo này chạy LAMP hàng ngày) |
| 2 | SQLite thay MySQL → 1 số plugin lỗi | ✅ Đã fix | Đổi sang **MariaDB thật** (gói `mariadb` của Termux), kết nối qua unix socket |
| 3 | Không gửi email thật | 🔶 Giảm nhẹ | Cài sẵn plugin **WP Mail SMTP** trong site_source — người dùng chỉ cần điền SMTP credentials có sẵn (Gmail/Brevo...) vào wp-admin. Vẫn cần SMTP ngoài — đây là giới hạn của MỌI server (kể cả VPS thật), không riêng gì app này |
| 7 | URL Cloudflare Quick Tunnel đổi mỗi lần restart | ✅ Đã fix (tuỳ chọn) | Thêm ô nhập **Cloudflare Tunnel token** trong app (Cài đặt) → dùng `cloudflared tunnel run --token` (named tunnel, domain cố định) thay vì `--url` (quick tunnel). Cần người dùng tự tạo tunnel trên dashboard Cloudflare (miễn phí) để lấy token — việc này KHÔNG thể tự động hoá thay người dùng vì cần tài khoản của họ |
| — | (mới) Không backup | ✅ Thêm mới | Nút "Backup ngay" trong app — zip `www/` + `mysqldump` database vào `Android/data/<pkg>/files/backups/` |

**Còn lại KHÔNG fix, lý do là giới hạn phần cứng thật (không né được bằng
phần mềm):**
- Không nguồn điện dự phòng / RAID / datacenter-grade reliability
- RAM/CPU trần cứng của điện thoại — traffic tăng đột biến vẫn có thể sập,
  dù nginx+php-fpm đã xử lý đồng thời tốt hơn `php -S` nhiều
- Không multi-site/cPanel — nằm ngoài phạm vi user yêu cầu (mục 1: "chỉ 1
  website"), không phải giới hạn kỹ thuật

**Đánh đổi mới phát sinh:** nginx+php-fpm+mariadb nặng RAM hơn hẳn
`php -S`+SQLite bản cũ. Nếu người dùng chạy trên máy yếu (<3GB RAM), có thể
cần fallback về bản nhẹ — ~~CHƯA implement dual-mode~~ **ĐÃ implement ở mục
1f (Dual-Mode PHP-Lite)**, xem đó thay vì mục 7 (đã lỗi thời).

## 1c. Cập nhật (vòng phản hồi thứ 3): công cụ quản trị (Adminer + File Manager)

Người dùng hỏi "có control panel không" → không có, chỉ WordPress wp-admin
(nội dung) + app Android (bật/tắt server). Đã thêm **Adminer** (quản lý
database) + **Tiny File Manager** (quản lý file) vào `_admin/` cho runtime
`php`. Người dùng xác nhận muốn CẢ 2, và ưu tiên bảo mật cao (lo ngại
backdoor/spyware/truy cập trái phép nếu lộ) → implement **2 lớp bảo vệ**:

1. **Chặn ở nginx** (`location ^~ /_admin/` trong `nginx.conf.template`):
   chỉ `allow` dải IP LAN riêng tư (192.168.0.0/16, 10.0.0.0/8,
   172.16.0.0/12), `deny all` còn lại. **Quan trọng**: traffic từ Cloudflare
   Tunnel đến nginx qua `127.0.0.1` (vì cloudflared chạy ngay trên máy, nối
   vào localhost) — nên `127.0.0.1` CỐ Ý không nằm trong allow list, tự
   động chặn `_admin/` khỏi URL public dù website chính vẫn public bình
   thường. Đây là điểm kỹ thuật dễ hiểu sai nếu không biết kiến trúc
   Cloudflare Tunnel — đừng thêm `allow 127.0.0.1` vào đây tưởng là vô hại.
2. **Mật khẩu riêng mỗi máy** (`_admin/auth.php` + `ServerForegroundService.
   ensureAdminPassword()`): sinh ngẫu nhiên bằng `SecureRandom` (16 ký tự)
   lúc server chạy lần đầu, ghi vào `filesDir/admin-password.txt`
   (app-private storage). KHÔNG có mật khẩu mặc định nào (khác Tiny File
   Manager gốc vốn có default `admin/admin@123`). Hiện trong app
   (`MainActivity` — mục "Mật khẩu quản trị") để người dùng tự xem.

**Cơ chế**: `scripts/lib/admin_tools.sh` tải Adminer (file PHP chính thức
từ GitHub release của adminer.org) + Tiny File Manager (file PHP từ repo
GitHub gốc `prasathmani/tinyfilemanager`) lúc CI build, chèn
`require __DIR__.'/auth.php';` vào ngay sau thẻ `<?php` ĐẦU TIÊN của mỗi
file (hàm `inject_auth_guard`, dùng `awk` không phải `sed` để an toàn hơn
với file lớn nhiều `<?php` trong string) — **đã test logic này trên file
mẫu, xác nhận chỉ sửa đúng dòng đầu, cú pháp PHP hợp lệ sau khi chèn**
(không phải suy đoán). Tiny File Manager có màn đăng nhập RIÊNG của nó
(biến `$use_auth`, đã tra cứu xác nhận qua GitHub wiki, KHÔNG phải hằng số
như đoán ban đầu) — tắt đi bằng `sed` để tránh đăng nhập 2 lần (đã có
`auth.php` gác cổng rồi).

**CHƯA verify (khác với injection logic đã test ở trên):**
- URL tải Adminer (`adminer.php` từ GitHub release "latest") và Tiny File
  Manager (`tinyfilemanager.php` từ nhánh `master`) có thể đổi cấu trúc
  file/tên biến ở phiên bản tương lai — nếu `inject_auth_guard` hay dòng
  `sed` tắt `$use_auth` không còn khớp, 2 công cụ này sẽ lộ ra (Adminer)
  hoặc yêu cầu đăng nhập kép/lộ default password (Tiny File Manager). Nên
  **luôn kiểm tra thủ công sau khi build** rằng `/_admin/db.php` và
  `/_admin/files.php` có hiện màn hình đăng nhập của `auth.php` (không
  phải giao diện Adminer/TFM ngay lập tức) trước khi tin tưởng đưa vào
  dùng thật.
- Hành vi `session.save_path` + `session_start()` của PHP-FPM build từ
  Termux (php.ini.template) — chưa chạy thử trên thiết bị thật.

## 1d. Cập nhật (vòng phản hồi thứ 4): thêm gì / KHÔNG thêm gì so với cPanel

Người dùng hỏi sao không thêm hết mọi thứ cPanel có. Đã phân loại rõ, thêm
`_admin/logs.php` (xem log nginx/php-fpm/mariadb, có fallback thuần PHP nếu
`shell_exec` bị chặn) + `_admin/info.php` (`phpinfo()`) + dung lượng đĩa
trống hiện ngay trang chủ `_admin/index.php`. **Cả 2 file PHP mới đã chạy
`php -l` xác nhận cú pháp hợp lệ**, không phải suy đoán.

**CỐ Ý KHÔNG thêm (nếu ai đó — kể cả AI khác — định thêm lại, đọc lý do
trước):**
- Mail server/webmail (Roundcube...) — vô nghĩa trên IP di động/hộ gia
  đình (port 25 bị ISP chặn gần hết, không reverse-DNS). WP Mail SMTP
  (relay qua SMTP ngoài) đã là giải pháp đúng, xem mục 1b.
- DNS zone manager — server không chạy DNS, Cloudflare đã quản lý domain.
- FTP server — trùng chức năng với File Manager đã có, chỉ thêm bề mặt
  tấn công không cần thiết.
- SSH/terminal qua web — rủi ro bảo mật không tương xứng lợi ích, ADB đã
  đủ cho truy cập trực tiếp thiết bị.
- Multi-site/reseller — trái yêu cầu gốc "chỉ 1 website" (mục 1).
- SSL certificate manager — không cần, Cloudflare Tunnel đã tự cấp HTTPS
  miễn phí cho URL public, không cần tự gia hạn Let's Encrypt như cPanel.

## 1e. Cập nhật (vòng phản hồi thứ 5): tối ưu hiệu năng + backup tự động +
dashboard nâng cao — bổ sung theo đề xuất từ 1 cuộc hội thoại AI khác (PDF)

Người dùng đưa 1 file PDF (hội thoại với Google AI/Gemini, KHÔNG có quyền
truy cập mã nguồn thật của repo này — chỉ suy đoán từ mô tả) liệt kê ~20 đề
xuất để biến app gần với "Panel tính phí" hơn. Đã đọc kỹ HANDOFF.md +
toàn bộ code THẬT trước khi chọn lọc — nhiều đề xuất trong PDF **đã làm rồi**
(vd PDF chê "_admin/ chắp vá rời rạc" nhưng `admin_tools.sh` đã tự sinh
`index.php` gộp 1 trang từ vòng phản hồi thứ 4, mục 1d) hoặc **mâu thuẫn
quyết định đã chốt** (vd PDF gợi ý quay lại SQLite — mục 1b đã đổi hẳn sang
MariaDB thật, có lý do rõ ràng, KHÔNG làm lại). Danh sách dưới đây là phần
đã **thật sự bổ sung**, cộng phần **cố ý bỏ qua** (đọc trước khi đề xuất lại).

**Đã thêm (build-time / runtime, KHÔNG đổi kiến trúc "app Kotlin tuyệt đối
generic" ở mục 3):**

| # | Đề xuất (PDF) | Đã làm | File |
|---|---|---|---|
| 1 | OPcache cho PHP | ✅ | `php.ini.template` (`zend_extension = opcache.so` + config) |
| 2 | `realpath_cache_size` | ✅ | `php.ini.template` |
| 3 | PHP-FPM `pm=ondemand` thay vì `dynamic` | ✅ | `php-fpm.conf.template` |
| 4 | Nginx `open_file_cache` | ✅ | `nginx.conf.template` |
| 5 | Giảm `innodb_buffer_pool_size` + các buffer MariaDB khác | ✅ | flag CLI trong `start-lamp.sh` (không tạo file `my.cnf` riêng — ít file hơn, cùng hiệu quả) |
| 6 | Dashboard `_admin/index.php`: hiện RAM máy + trạng thái 3 daemon | ✅ | `admin_tools.sh` (đọc `/proc/meminfo` + kiểm tra file socket MariaDB) |
| 7 | "1-Click Installer" WordPress từ dashboard | ✅ | `admin-install-wp.php` (mới) — **CHỈ chạy khi docroot đang trống** (không có `wp-config.php`/`wp-load.php`), tránh ghi đè site đang chạy |
| 8 | Backup tự động định kỳ (không chỉ nút bấm tay) | ✅ | `BackupWorker.kt` (mới, WorkManager) + `BackupManager.kt` (mới, tách logic dùng chung với nút bấm tay) |
| 9 | Đồng bộ backup lên cloud | ✅ | Qua **Telegram Bot** (`TelegramNotifier.kt`) + **Webhook tổng quát** (`WebhookUploader.kt`, mới) thay vì Google Drive OAuth thật — xem lý do kỹ thuật ở mục 1g |
| 10 | Báo cáo tự động qua Telegram khi server khởi động | ✅ | `ServerForegroundService.maybeNotifyTelegram()` — gửi URL công khai lúc tunnel lên, CHỈ nếu đã cấu hình Bot Token + Chat ID |
| 11 | "Chữa lành tự động" (self-healing) không cần app luôn mở | ✅ | `HealthCheckWorker.kt` (mới, WorkManager) — watchdog BÊN NGOÀI service, phân biệt rõ với cơ chế tự-restart tiến trình con ĐÃ CÓ SẴN trong `runSiteLoop()`/`runTunnelLoop()` (mục 8, đừng viết lại) |
| 12 | **Dual-Mode PHP-Lite** (máy RAM thấp tự chuyển sang chế độ nhẹ) | ✅ | Xem mục "Dual-Mode PHP-Lite" riêng ngay dưới — đủ lớn nên tách mục |

## 1f. Dual-Mode PHP-Lite (chi tiết)

Trước bản này, đây là việc CHƯA làm, ghi nhận ở mục 7 cũ ("0d"). Sau khi tối
ưu buffer/pool-size cho MariaDB thật (bảng trên, #5) vẫn chưa đủ cho máy
THẬT SỰ yếu (< 3GB RAM) — bản này làm nốt phần fallback đầy đủ theo đúng đề
xuất gốc của PDF, với thiết kế AN TOÀN hơn PDF gợi ý (xem "quyết định 1 lần"
dưới đây).

**Cơ chế**: máy < 3072MB RAM (`LITE_MODE_THRESHOLD_MB` trong `start-lamp.sh`,
sửa tại đây nếu cần tinh chỉnh) tự chuyển sang chạy **`php -S` đơn lẻ +
SQLite**, bỏ hẳn MariaDB/nginx/php-fpm. Người dùng có thể ép tay qua app
(Auto/Luôn bật/Luôn tắt) — xem `RadioGroup` mới trong `MainActivity`.

**"Quyết định 1 lần, không bao giờ đổi lại"** — khác PDF gốc (vốn ngụ ý kiểm
tra RAM mỗi lần khởi động): chế độ được **ghi vào `$DATA/.runtime-mode` ở
LẦN SETUP ĐẦU TIÊN**, các lần sau LUÔN đọc lại giá trị cũ, bỏ qua RAM/override
hiện tại. Lý do: nếu 1 site đã chạy thật với MariaDB (đã có dữ liệu), một lần
khởi động sau đó "phát hiện" RAM thấp rồi tự chuyển sang SQLite sẽ làm
WordPress **mất kết nối database ngay lập tức** (wp-config.php cũ vẫn trỏ
MariaDB, nhưng service đó không được bật nữa) — đây là rủi ro dữ liệu nghiêm
trọng nếu làm theo đúng nghĩa đen "kiểm tra lại mỗi lần" như PDF mô tả. Muốn
đổi chế độ: xoá dữ liệu app (Cài đặt > Ứng dụng > xoá dữ liệu) để bắt đầu lại
từ đầu — người dùng được thông báo rõ điều này ngay trong log
`[start-lamp] Se GIU NGUYEN che do nay...` và trong `hint_lite_mode` (string
trong app).

**File liên quan (mới):**
- `router-lite.php` — router cho `php -S` (built-in server không đọc
  `.htaccess` nên permalink WordPress sẽ 404 nếu thiếu; đây là kỹ thuật
  CHUẨN theo tài liệu chính thức của PHP.net, không phải tự nghĩ ra).
- `ServerForegroundService.getDeviceTotalRamMb()` — dùng
  `ActivityManager.MemoryInfo` (API chính thức, không cần quyền đặc biệt),
  truyền xuống script qua `env["DEVICE_RAM_MB"]` — biến này THUẦN TUÝ là 1
  sự kiện của thiết bị (giống `PORT`/`HOME`/`TMPDIR` đã có), Kotlin KHÔNG tự
  quyết định lite hay không — quyết định thật nằm hoàn toàn trong
  `start-lamp.sh`, đúng nguyên tắc "app Kotlin generic" ở mục 3.
- `Prefs.KEY_PHP_LITE_MODE` (Auto/On/Off) → env `FORCE_LITE_MODE` → đọc bởi
  `start-lamp.sh`.
- `site_source.sh`: khi `site_source.type=wordpress`, đóng gói SẴN (không
  kích hoạt) plugin chính thức **SQLite Database Integration** (đội
  Performance của WordPress core duy trì — chọn nguồn chính thức thay vì
  drop-in cộng đồng, nhất quán với việc dự án luôn tải WordPress core từ
  `wordpress.org` chính chủ) + sinh thêm `wp-config-sqlite.php.template`
  song song `wp-config.php.template` cũ. Plugin nằm sẵn trong
  `wp-content/plugins/` KHÔNG tự kích hoạt gì (WordPress chỉ đọc
  `wp-content/db.php` NẾU file đó tồn tại) nên **không ảnh hưởng chế độ đầy
  đủ** dù luôn được đóng gói.
- `admin-auth.php`: thêm kiểm tra IP-LAN NGAY TRONG PHP (hàm
  `wp_pocket_ip_in_private_lan()`, 3 dải RFC1918 chuẩn) — bắt buộc vì chế độ
  Lite KHÔNG có nginx nên không còn lớp chặn IP nào cả nếu không tự làm ở
  đây. Áp dụng cho CẢ 2 chế độ (phòng thủ kép cho chế độ đầy đủ, vô hại vì
  cùng dải IP nginx đã cho phép).
- `nginx.conf.template` + `router-lite.php`: đều chặn `_supervisor/` và
  `*.template` — 2 luật giống hệt nhau, đảm bảo nhất quán giữa 2 chế độ.
- `scripts/runtimes/php.sh`: thêm bước tải binary CLI `php` (`libphpcli.so`)
  — **TRƯỚC BẢN NÀY CHƯA TỪNG TẢI BINARY NÀY** (dự án chỉ dùng `php-fpm`),
  nếu thiếu bước này chế độ Lite sẽ lỗi ngay khi chạy trên thiết bị thật.

**Đánh đổi CỐ Ý, không phải thiếu sót** (nói rõ để không ai "sửa lại cho
giống chế độ đầy đủ"): `php -S` là built-in dev server của PHP, xử lý
TUẦN TỰ (1 request/lần) — đây là ĐÚNG lý do dự án chuyển sang nginx+php-fpm ở
mục 1b ban đầu. Dùng lại nó ở đây là đánh đổi CÓ CHỦ ĐÍCH: máy quá yếu RAM
thì "chạy được nhưng chậm khi đông người" vẫn tốt hơn "sập liên tục" — đúng
tinh thần PDF gốc ("đổi lại một chút hiệu năng chịu tải nhưng đổi lấy sự ổn
định tuyệt đối cho máy yếu").

**Đã TEST BẰNG BINARY THẬT (PHP CLI qua apt, không phải bản Termux ARM):**
- `router-lite.php`: test đủ 8 trường hợp (file tĩnh, permalink giả lập,
  chặn `_supervisor/`, chặn `*.template`, `/_admin/` → đúng
  `_admin/index.php`, `/_admin/db.php` → đúng file, trang chủ) — TẤT CẢ
  ĐÚNG. Phát hiện + sửa 1 lỗi thật lúc test: bản đầu dùng `__DIR__` (sai vì
  file nằm trong `_supervisor/`, không phải docroot gốc) thay vì
  `$_SERVER['DOCUMENT_ROOT']` — nếu không test thực tế bằng `php -S` thật,
  lỗi này sẽ khiến TOÀN BỘ chế độ Lite không hoạt động trên thiết bị thật.
- `admin-auth.php`: test hàm CIDR với 12 trường hợp biên (ranh giới
  `172.16.0.0/12`, `127.0.0.1`, IP public, IPv6) — tất cả đúng.
- `start-lamp.sh` toàn bộ luồng quyết định chế độ: test 4 kịch bản bằng
  `sh` thật + PHP CLI thật thay cho binary Termux — (1) RAM thấp → lite,
  (2) cùng máy RAM cao lần sau → VẪN lite (quyết định giữ nguyên), (3) máy
  mới RAM cao → full, (4) `FORCE_LITE_MODE=on` dù RAM cao → lite. Cả 4 đúng.
- Nginx thật xác nhận `location ~* \.template$` + `location ^~ /_supervisor/`
  hoạt động đúng (403), khớp với hành vi tương ứng của `router-lite.php`.

**Vẫn CHƯA verify** (giới hạn thật của môi trường viết bản cập nhật — không
có Termux ARM/thiết bị Android thật):
- Bản Termux thật của `php` package có chắc chắn cung cấp `bin/php` (CLI
  SAPI) như giả định không — rất nhiều khả năng có (đây là gói CLI cơ bản
  nhất của PHP, `php-fpm` là gói RIÊNG, TÁCH BIỆT mà dự án đã dùng thành
  công từ trước), nhưng chưa tải gói Termux thật để xác nhận cấu trúc file
  bên trong.
- Plugin SQLite Database Integration bản mới nhất từ wordpress.org có đúng
  chứa file `db.copy` ở đường dẫn gốc plugin như tài liệu chính thức mô tả
  hay không — chưa tải thật để xác nhận (tài liệu chính thức của plugin ghi
  rõ vậy, nhưng cấu trúc file có thể đổi giữa các phiên bản).
- `curl -fsSL https://curl.se/ca/cacert.pem` chạy TỐT trên GitHub Actions
  runner (internet đầy đủ, không có lý do gì để lỗi) nhưng cả pipeline build
  đầy đủ (bao gồm cả `php.sh` sửa lần này) chưa được chạy thật lần nào.

**Cố ý KHÔNG làm (đọc lý do trước khi đề xuất lại, giống tinh thần mục 1d):**

- ❌ **SQLite "on-demand"/dual DB** (PDF đề xuất: MariaDB làm chính, TỰ
  CHUYỂN ĐỔI qua lại sang SQLite mỗi khi mở trang quản trị rồi đồng bộ
  ngược) — **KHÁC với Dual-Mode PHP-Lite ở mục 1f phía trên** (SQLite ở đó
  là lựa chọn CỐ ĐỊNH 1 lần cho máy yếu, không bao giờ tự chuyển qua lại).
  Ý tưởng "chuyển đổi qua lại" này vẫn bị từ chối: mâu thuẫn trực tiếp quyết
  định mục 1b (đã đổi hẳn từ SQLite sang MariaDB thật vì lý do tương thích
  plugin WordPress) VÀ rủi ro mất đồng bộ/hỏng dữ liệu cao hơn nhiều so với
  lợi ích (không rõ "đồng bộ ngược" sẽ xử lý xung đột dữ liệu thế nào nếu có
  thay đổi ở cả 2 phía trước khi đồng bộ). Không làm.
- ❌ **OverlayFS ảo / symlink `wp-content/uploads` sang `cacheDir` Android**
  — `cacheDir` có thể bị hệ điều hành TỰ XOÁ bất kỳ lúc nào khi máy thiếu bộ
  nhớ (đúng bản chất API, không phải suy đoán) → dùng cho ảnh/file người
  dùng tải lên là rủi ro MẤT DỮ LIỆU thật, không đánh đổi được.
- ❌ **Gộp nhiều điện thoại thành cluster qua LAN** (Nginx làm Load Balancer,
  proxy PHP-FPM sang máy khác) — ngoài phạm vi yêu cầu gốc "chỉ 1 website,
  không multi-tenant" (mục 1), và độ phức tạp/rủi ro (đồng bộ file + DB giữa
  nhiều máy) không tương xứng lợi ích cho 1 dự án cá nhân.
- ❌ **Thay `nginx`/`php-fpm`/`mariadb` bằng BusyBox/Toybox** — hiểu lầm từ
  PDF: Toybox/BusyBox chỉ thay được các lệnh tiện ích đơn giản (sed/awk/tar),
  KHÔNG thể thay thế được 1 web server hay database server thật. Phần "thay
  lệnh tiện ích" thực ra không cần thiết — `admin_tools.sh` hiện chỉ dùng
  `awk`/`sed`/`curl` sẵn có trên GitHub Actions runner (build-time, không
  chạy trên điện thoại) nên không có gì để tối ưu ở đây.
- ❌ **ZRAM hint qua `ComponentCallbacks2.onTrimMemory`** — Android tự quản
  lý ZRAM ở tầng kernel, app không cần (và không có API) để "ra lệnh" nén
  RAM tiến trình CON (`mariadbd`/`php-fpm`/`nginx` là tiến trình con của
  service, không phải component Android có vòng đời `onTrimMemory` riêng).
  Đề xuất PDF hiểu chưa đúng ranh giới API.
- ❌ **Cloudflare Workers/Pages làm "static mirror"** — cần thêm tài khoản
  Cloudflare API token + logic xuất static site (Simply Static hoặc tương
  đương) + đồng bộ 1 chiều lên Pages, độ phức tạp lớn cho 1 lần bổ sung.
  Ghi nhận là hướng hay nếu website chủ yếu là nội dung tĩnh, nhưng để
  tương lai.
- ❌ **HTTP/3 (QUIC)** — KHÔNG cần code: Cloudflare Tunnel tự thương lượng
  QUIC ở phía Cloudflare edge nếu trình duyệt hỗ trợ, không có gì để "bật"
  trong app hay nginx.conf. Đã ghi 1 dòng vào README thay vì sửa code.
- ❌ **Tailscale/ZeroTier thay Cloudflare Tunnel** — phương án B hợp lý cho
  rủi ro "`cloudflared` không static-link" (mục 7 cũ, việc #3), nhưng đó là
  thêm 1 kiến trúc mạng SONG SONG, không phải "bổ sung nhỏ" — để dành khi
  nào rủi ro đó THẬT SỰ xảy ra (build xong mới biết), tránh code 2 đường dự
  phòng không dùng đến.
- ❌ **Webhook/long-polling nhận lệnh ngược từ Telegram** (`/status`,
  `/backup`, `/restart_service`) — chỉ làm chiều app → Telegram (báo cáo,
  gửi file). Chiều ngược lại cần 1 tiến trình lắng nghe liên tục (tốn thêm
  RAM/pin đúng thứ đang cố tiết kiệm) hoặc webhook công khai (thêm bề mặt
  tấn công) — không tương xứng lợi ích cho 1 lần bổ sung.
- ❌ **Đưa log/cache vào tmpfs (RAM Disk)** thật sự — PDF gợi ý điều này
  nhưng Android (không root) KHÔNG cấp quyền mount tmpfs tuỳ ý cho app
  thường; `cacheDir`/`filesDir` của app đều nằm trên bộ nhớ flash thật, không
  phải RAM. Việc `open_file_cache` (nginx) + `opcache`/`realpath_cache`
  (PHP) ở bảng trên đã đạt hiệu quả tương tự (giảm I/O đọc lặp lại) MÀ
  KHÔNG cần tuyên bố sai về tmpfs — quan trọng để không ghi nhầm 1 khả năng
  kỹ thuật không có thật vào tài liệu dự án.

**Đã sửa 2 lỗi tìm được lúc rà soát (không phải do vòng sửa này gây ra — có
sẵn từ trước, phát hiện khi kiểm tra lại kỹ trước khi làm tiếp — xem yêu cầu
"rà lại và sửa lỗi" của người dùng):**

- 🔴 **Nghiêm trọng — rò rỉ salt/khoá bí mật WordPress ra URL public**:
  `site_source.sh` nhúng salt thật (lấy từ `api.wordpress.org` lúc build)
  vào `wp-config.php.template`, file này nằm ngay trong docroot với đuôi
  `.template` (KHÔNG khớp `location ~ \.php$`) nên nginx phục vụ nguyên văn
  cho BẤT KỲ AI qua URL Cloudflare Tunnel công khai — không chỉ LAN như
  `_admin/`. Vá 2 lớp: (1) `nginx.conf.template` thêm
  `location ~* \.template$ { deny all; }` chặn mọi file `.template` ở bất kỳ
  đâu trong docroot, cộng `location ^~ /_supervisor/ { deny all; }` chặn cả
  thư mục chứa config gốc; (2) `start-lamp.sh` **xoá hẳn**
  `wp-config.php.template` ngay sau khi sinh `wp-config.php` thật (phòng khi
  luật nginx sau này lỡ bị sửa/xoá mất). Đã test bằng nginx thật (xem dưới),
  xác nhận cả `/wp-config.php.template` lẫn `/_supervisor/nginx.conf.template`
  trả về 403, file thường (`/index.html`) vẫn 200, luật LAN-only cũ của
  `_admin/` không bị ảnh hưởng.
- 🟡 **Bug do vòng sửa này gây ra — `install-wp.php` dùng
  `sys_get_temp_dir()`**: `php-fpm.conf.template` mặc định `clear_env=yes`
  (mặc định của chính php-fpm), chỉ đúng 1 biến `APP_HOME` được truyền qua
  (`env[APP_HOME] = ...`) — biến `TMPDIR` Kotlin đặt cho TIẾN TRÌNH CHA
  KHÔNG tự động truyền xuống PHP, nên `sys_get_temp_dir()` nhiều khả năng
  trả về `/tmp` (không ghi được trong sandbox app Android). Sửa: dùng hẳn
  thư mục `_admin/.install-tmp/` (chắc chắn ghi được, cùng cơ chế mà
  `auth.php` đã dùng thành công từ trước) thay vì phụ thuộc temp dir hệ
  thống.

**Đã TEST BẰNG BINARY THẬT** (khác "CHƯA verify" thuần suy luận — môi trường
viết bản cập nhật này cài được `nginx`/`php-fpm`/`mariadb` bản Ubuntu x86 qua
`apt` để kiểm tra cú pháp, dù KHÔNG phải bản Termux ARM thật sẽ chạy trên
điện thoại):

- `nginx -t` với file `nginx.conf.template` đã resolve placeholder: cú pháp
  hợp lệ. Chạy nginx thật + `curl`: xác nhận 2 luật chặn mới (`.template`,
  `_supervisor/`) trả 403 đúng như thiết kế, file thường vẫn 200, luật
  `_admin/` cũ không bị ảnh hưởng.
- `php-fpm -t` với `php-fpm.conf.template` + `php.ini.template` đã resolve:
  cú pháp hợp lệ (kể cả `pm=ondemand`, `curl.cainfo`/`openssl.cafile`,
  toàn bộ khối `opcache.*`) — chỉ thiếu các file `.so` extension thật của
  Termux (đúng như dự kiến, container test này là x86 không phải ARM).
- Khởi động `mariadbd` thật với đúng các cờ mới thêm
  (`--innodb-buffer-pool-size=32M`, `--key-buffer-size=8M`,
  `--max-connections=20`, `--table-open-cache=128`,
  `--skip-performance-schema`, `--skip-name-resolve`): lên thành công,
  tạo database + user `wordpress` giống hệt khối SQL trong `start-lamp.sh`,
  chạy `mysqldump --socket=... -uroot --databases wordpress` (đúng lệnh
  `BackupManager.kt` dùng) ra file dump đúng dữ liệu test. **Đã bỏ cờ
  `--innodb-buffer-pool-instances`** sau khi test cho thấy MariaDB 10.11 báo
  đây là cờ đã bị loại bỏ (no-op, chỉ giữ tương thích ngược) — bớt 1 dòng
  warning vô ích trong log.

**Vẫn CHƯA verify được** (giới hạn thật của môi trường viết bản cập nhật
này — không có Android SDK, không có thiết bị ARM thật, không vào được
`dl.google.com`/Google Play Services):

- `zend_extension = opcache.so` giả định Termux đóng gói OPcache dưới dạng
  file `.so` RỜI. Nếu bản build PHP của Termux tích hợp OPcache tĩnh sẵn
  trong binary `php-fpm`, dòng này chỉ gây warning vô hại lúc khởi động —
  xem `$RUNDIR/php-fpm.log` nếu cần xác nhận sau lần build đầu.
- Cờ CLI của `mariadbd` đã test cú pháp đúng trên MariaDB 10.11 (Ubuntu
  x86) — bản Termux ARM có thể là phiên bản MariaDB khác, dù các cờ dùng ở
  đây đều rất chuẩn/ổn định nên rủi ro khác biệt thấp.
- `/proc/meminfo` có đọc được KHÔNG CẦN QUYỀN trên MỌI phiên bản
  Android/kernel hay không — đa số thiết bị cho đọc, nhưng có thể khác nhau
  tuỳ nhà sản xuất/bản ROM. Nếu không đọc được, dashboard tự ẩn phần RAM
  (không lỗi trang, đã có `if ($mem && ...)` guard).
- `androidx.work:work-runtime-ktx:2.9.1` — chọn vì khớp an toàn với
  compileSdk 34 hiện tại của repo, nhưng CHƯA build-test thật.
- Luồng tải WordPress trực tiếp từ `_admin/install-wp.php` phụ thuộc
  `allow_url_fopen` hoặc extension `curl.so` hoạt động đúng trên thiết bị —
  cả 2 đều nằm trong danh sách "CHƯA verify" cũ ở mục 7 (extension `.so` của
  PHP). Nếu cả 2 đều không hoạt động, trang sẽ báo lỗi rõ ràng (không im
  lặng thất bại) thay vì giả vờ thành công. CA cert bundle (`cacert.pem`,
  tải lúc build từ `curl.se/ca/cacert.pem`) đã thêm để tránh lỗi xác thực
  SSL — chưa test end-to-end việc tải `wordpress.org` thật qua `curl.so`
  của Termux.
- Gọi Telegram Bot API (`sendMessage`/`sendDocument`) viết đúng theo đặc tả
  chính thức nhưng CHƯA gọi thử qua mạng di động Việt Nam thật.

## 1g. Đồng bộ Cloud "Webhook tổng quát" (thay cho Google Drive OAuth thật)

PDF đề xuất đồng bộ backup lên **Google Drive/AWS S3/FTP**. Đã cân nhắc làm
Google Sign-In + Drive API "xịn" (API chính thức hiện tại của Google là
`AuthorizationClient`, KHÔNG phải `GoogleSignInClient` cũ — Google đã tách
authentication (Credential Manager) và authorization (AuthorizationClient)
thành 2 API riêng từ ~2024, xem `developer.android.com/identity/authorization`)
nhưng **KHÔNG làm**, vì 3 lý do kỹ thuật thật, không phải ngại khó:

1. Cần thêm `com.google.android.gms:play-services-auth` — phụ thuộc Google
   Play Services, NẶNG hơn hẳn mọi thứ đã có trong app (hiện chỉ dùng
   androidx thuần), và không đảm bảo có sẵn trên MỌI điện thoại Android (máy
   không cài dịch vụ Google sẽ không dùng được tính năng này).
2. OAuth Client ID kiểu "Android" **bắt buộc khớp SHA-1 chữ ký APK** — dự án
   này **CHƯA có code signing ổn định** (mục 7.6 dưới, chỉ mới
   `assembleDebug`). Trên GitHub Actions, keystore debug được TỰ SINH MỚI
   mỗi lần chạy runner (không có bước cache/commit keystore cố định) → SHA-1
   đổi MỖI LẦN build lại → phải cấu hình lại OAuth Client ID liên tục, không
   thực tế chút nào cho tới khi mục 7.6 được giải quyết trước.
3. Scope Drive là scope "nhạy cảm" (sensitive scope) — Google yêu cầu xác
   minh ứng dụng (App Verification) nếu vượt quá số lượng nhỏ tài khoản thử
   nghiệm (test users) ở chế độ Testing — quá nhiều rào cản bên ngoài cho 1
   app cá nhân tự build chạy trên chính điện thoại của mình.

**Giải pháp thay thế**: `WebhookUploader.kt` (mới) — gửi file backup qua
HTTP POST `multipart/form-data` (field `"file"`) tới **BẤT KỲ URL nào**
người dùng tự điền, dùng chung `BackupWorker` với Telegram (cả 2 chạy song
song nếu người dùng điền cả 2). Cách này đạt đúng mục tiêu "đẩy backup ra
khỏi điện thoại" mà KHÔNG cần OAuth/Play Services/code signing, và VẪN đưa
được backup vào Google Drive thật nếu người dùng trỏ webhook tới 1 **Google
Apps Script Web App** tự viết (mẫu rất phổ biến: hàm `doPost(e)` +
`DriveApp.createFile(...)`, script chạy dưới quyền TÀI KHOẢN GOOGLE CỦA
NGƯỜI DÙNG khi họ tự deploy trong script.google.com của chính họ — hoàn
toàn không cần Android app biết gì về OAuth) — hoặc n8n/Make.com/Zapier nếu
muốn nối tiếp sang S3/Dropbox/nơi khác.

**Đã test bằng server thật**: dựng 1 HTTP server Python (`http.server` +
`cgi.parse_multipart`), gửi đúng byte-format mà `WebhookUploader.uploadFile()`
tạo ra (boundary, header, CRLF) — server phân tích đúng field `file`, đúng
số byte nội dung. Vì `TelegramNotifier.sendDocument()` dùng CHUNG cấu trúc
multipart này, test này cũng xác nhận gián tiếp cho cả 2 hàm.

**Nếu sau này mục 7.6 (code signing) được giải quyết** và có nhu cầu thật
mạnh, có thể quay lại làm Google Sign-In/Drive API chính thống — lúc đó rào
cản #2 ở trên không còn nữa, chỉ còn #1 và #3 cần cân nhắc.

## 1h. Sửa lại 3 ý tưởng bị từ chối trước đó — thay bằng cách AN TOÀN đạt cùng mục tiêu

Người dùng yêu cầu (đúng nguyên văn): với các ý tưởng bị từ chối vì "API
sai hay có rủi ro", tìm giải pháp khác đạt cùng mục tiêu mà KHÔNG rủi ro.
Rà lại toàn bộ danh sách "cố ý không làm" ở mục 1e/1f theo tiêu chí này:

**KHÔNG có cách an toàn (giữ nguyên từ chối, đã tra thêm bằng chứng):**
- ❌ **ZRAM hint qua `onTrimMemory`** — tra cứu xác nhận: cơ chế Linux đúng
  cho việc này là `process_madvise(MADV_COLD/MADV_PAGEOUT)`, nhưng tài liệu
  patch chính thức của kernel ghi rõ *"Only privileged processes can do
  something for other process's address space"* — ứng dụng thường (kể cả
  không root) **không có quyền** gọi hint này lên tiến trình CON
  (mariadbd/php-fpm/nginx) của chính nó, chỉ daemon hệ thống
  (`lmkd`/`ActivityManagerService`) mới gọi được. Đây là giới hạn nền tảng
  thật, không phải do chưa tìm đúng API. Giữ nguyên từ chối.
- ❌ **SQLite on-demand switching, LAN cluster, `.template` cluster đa
  thiết bị** — không phải vấn đề "API sai" mà là rủi ro thiết kế/ngoài phạm
  vi thật (xung đột dữ liệu, vượt yêu cầu gốc "1 website duy nhất") — không
  có "cách làm đúng API" nào thay đổi được bản chất rủi ro này.

**CÓ cách an toàn — đã làm:**

1. **"RAM Disk cho log/cache" → không làm được đúng nghĩa (Android không
   cấp quyền mount tmpfs cho app thường), nhưng đạt được lợi ích tương tự
   bằng tính năng CÓ SẴN, CHÍNH THỨC của nginx**: `access_log` hỗ trợ
   `buffer=` + `flush=` — gom log trong bộ nhớ nginx tự quản lý rồi mới ghi
   xuống flash theo lô, thay vì ghi từng dòng ngay lập tức. Sửa
   `nginx.conf.template`:
   `access_log __RUNDIR__/nginx-access.log combined buffer=64k flush=5m;`
   — **Test bằng `nginx -t` thật**: phát hiện cú pháp đúng phải khai báo
   tường minh format `combined` trước `buffer=`/`flush=` (thiếu sẽ bị nginx
   hiểu nhầm `buffer=64k` là TÊN format, lỗi `unknown log format`) — sửa và
   test lại xác nhận OK.

2. **"OverlayFS/symlink `wp-content/uploads` sang `cacheDir`" → vẫn TỪ CHỐI
   phần uploads (rủi ro mất ảnh/video người dùng là thật, không đổi), nhưng
   áp dụng AN TOÀN cho `wp-content/cache`** (dữ liệu cache thuần tuý, mọi
   plugin cache của WordPress đều tự tạo lại được nếu mất — đúng bản chất
   "cache" là đồ bỏ được). Thêm vào `start-lamp.sh` (dùng chung cả 2 chế
   độ): symlink `wp-content/cache` → `$TMPDIR` (cacheDir Android, đã có sẵn
   qua env Kotlin đặt), tự tạo lại thư mục đích mỗi lần chạy (phòng khi
   Android đã xoá cacheDir giữa các lần). **Test bằng `sh` thật**: xác nhận
   symlink hoạt động, ghi/đọc qua symlink đúng, và **uploads/ hoàn toàn
   không bị đụng tới** (test tách biệt 2 thư mục rõ ràng), mô phỏng Android
   xoá cacheDir giữa chừng → thư mục đích tự tạo lại đúng, symlink không vỡ.

3. **"Webhook 2 chiều nhận lệnh Telegram" → vẫn TỪ CHỐI đúng nghĩa webhook
   (mở URL công khai/tiến trình lắng nghe liên tục là rủi ro thật), nhưng
   thay bằng LONG-POLLING** (`TelegramCommandWorker.kt`, mới) — phone chủ
   động HỎI Telegram định kỳ qua `getUpdates` (cách dùng CHÍNH THỨC,
   phổ biến của Telegram Bot API cho bot không có server riêng), KHÔNG mở
   port/URL nào cả nên KHÔNG có bề mặt tấn công mới. Hỗ trợ `/status`
   (RAM/dung lượng/pin/trạng thái server), `/backup` (backup ngay + gửi
   file), `/restart` (khởi động lại service). **Bảo mật**: so sánh `chatId`
   dạng SỐ (không phải chuỗi) với giá trị đã cấu hình trong app — lệnh từ
   chatId khác bị bỏ qua HOÀN TOÀN, không phản hồi gì (tránh lộ thông tin
   "server này tồn tại" cho người lạ dù họ có được Bot Token). Dùng
   `org.json` có sẵn trong Android SDK để parse JSON, KHÔNG thêm thư viện
   ngoài. Lên lịch/huỷ theo đúng lúc Telegram được cấu hình/xoá cấu hình
   trong app (cùng chỗ với `BackupWorker`).

**Vẫn CHƯA verify** (giới hạn môi trường viết bản cập nhật, không có thiết
bị Android thật): logic parse JSON của `getUpdates()` viết đúng theo field
path thật của Telegram Bot API (`result[].update_id`,
`result[].message.chat.id`, `result[].message.text` — API rất ổn định,
nhiều năm không đổi cấu trúc cơ bản này) và đúng method signature của
`org.json.JSONObject`/`JSONArray` (API lõi Android từ API 1, không đổi) —
nhưng chưa chạy thử JVM/thiết bị thật để xác nhận biên dịch/chạy đúng 100%.

## 1i. Audit toàn diện (vòng phản hồi thứ 6): không tin lời tự thuật, kiểm tra lại

Người dùng yêu cầu xác nhận: (1) không sót việc, (2) không có tính năng nào
thiếu UI/chưa nối dây ("vỏ rỗng"), (3) tài liệu không lệch pha với code
thật. Rà lại toàn bộ bằng cách đọc lại code (không chỉ đọc lại những gì đã
tự ghi) — tìm và sửa được:

**"Vỏ rỗng" thật tìm thấy (có logic nhưng thiếu phản hồi cho người dùng):**
- RadioGroup Dual-Mode PHP-Lite chỉ lưu **lựa chọn** (Auto/Bật/Tắt) — ở chế
  độ Auto, người dùng không có cách nào biết KẾT QUẢ THẬT (Lite hay Full)
  ngoại trừ tự mở dashboard web riêng. Đã thêm `tvRuntimeMode` trong
  `MainActivity` — đọc trực tiếp file `filesDir/lamp-run/lite-mode` (cùng
  file `start-lamp.sh` ghi ra, không qua IPC nào) để hiện ngay trong app.

**Lỗ hổng lên lịch WorkManager tìm thấy:**
- `BackupWorker`/`TelegramCommandWorker` trước đó CHỈ được đăng ký lại từ
  `MainActivity.onCreate()`. Android "Buộc dừng" (Settings > Ứng dụng) huỷ
  HẾT WorkManager job đã đăng ký — nếu sau đó máy khởi động lại (auto-start
  qua `BootReceiver` bật server) mà người dùng CHƯA mở lại app, 2 job này sẽ
  không được đăng ký lại. Gom logic vào `WorkScheduler.kt` (mới), gọi từ CẢ
  `MainActivity.onCreate()` LẪN `ServerForegroundService.onCreate()` (chạy
  trong mọi trường hợp service được tạo, kể cả từ BootReceiver).

**Tài liệu lệch pha với code (đã sửa toàn bộ):**
- Mục "0d" (dòng cũ, trước mục 2) và mục 1b vẫn ghi "CHƯA implement
  dual-mode" — SAI, đã làm ở mục 1f. Đã sửa cả 2 chỗ.
- Mục 8 liệt kê Dual-Mode PHP-Lite + webhook Telegram 2 chiều vào danh sách
  "cố ý không làm" — SAI theo nghĩa đen (ý tưởng GỐC bị từ chối, nhưng đã
  làm bằng CÁCH KHÁC an toàn hơn ở mục 1f/1h). Viết lại toàn bộ mục 8 phân
  biệt rõ "còn từ chối" / "đã làm bằng cách khác".
- Mục 5 vẫn ghi "không dùng SQLite drop-in nữa" mà không nhắc mục 1f (SQLite
  quay lại CHỈ cho Dual-Mode PHP-Lite) — dễ gây hiểu lầm mâu thuẫn nếu đọc
  mục 5 trước mục 1f. Đã thêm chú thích chéo.
- Mục 8 có 1 đoạn văn bị lặp/cắt câu dở dang do 1 lần sửa `str_replace`
  trước đó khớp nhầm đoạn ngắn hơn dự định (tự phát hiện khi đọc lại toàn
  bộ file tuần tự, không phải qua công cụ tự động) — đã dọn sạch.

**Đã kiểm tra và XÁC NHẬN KHÔNG có vấn đề (để khỏi phải rà lại lần sau):**
- Mọi file `.kt` mới đều được tham chiếu từ ít nhất 1 nơi khác (không có
  file mồ côi) — kiểm bằng `grep` chéo toàn bộ thư mục.
  `WebhookUploader`/`TelegramCommandWorker`/`BackupWorker`/`HealthCheckWorker`
  đều có nơi gọi `schedule()`/`cancel()`/hàm chính từ code thật, không chỉ
  tồn tại như file độc lập.
  Không còn `TODO`/`FIXME`/"chưa làm xong" sót lại trong `app/src` hay
  `scripts/` (grep toàn bộ, 0 kết quả).
- Mọi `binding.xxx` dùng trong `MainActivity.kt` đều có `android:id` tương
  ứng trong `activity_main.xml` và ngược lại (chỉ 2 trường hợp lệch là
  `tvTitle`/`tvPublicLabel` — nhãn tĩnh, không cần code đụng tới, không phải
  lỗi).

## 1j. Auto-Sleep MariaDB khi rảnh (vòng phản hồi thứ 7 — hiện thực hoá đề
xuất "Cơ chế Ngủ đông thông minh" từng bị hoãn ở mục 1e)

Thiết kế: opt-in hoàn toàn (mặc định TẮT, xem `Prefs.KEY_AUTO_SLEEP_ENABLED`)
— ai không bật thì `start-lamp.sh`/`nginx.conf`/`php.ini` sinh ra giống HỆT
trước khi có tính năng này, không thêm rủi ro cho luồng đã ổn định.

**Phát hiện quan trọng lúc thiết kế** (đọc lại `start-lamp.sh` trước khi động
tay, không giả định): tưởng ban đầu là nginx được `exec` thay thế shell ở
cuối script (nên sợ phải tái cấu trúc lớn để có 1 "supervisor" sống sót giám
sát định kỳ) — hoá ra nginx ĐÃ được chạy nền (`&`) từ trước, script kết thúc
bằng 1 vòng lặp giám sát mỗi 3 giây (kiểm tra `kill -0` cho cả 3 tiến trình).
Nhờ vậy chỉ cần MỞ RỘNG vòng lặp có sẵn này, không cần tái cấu trúc gì cả —
giảm rủi ro đáng kể so với thiết kế ban đầu trong đầu.

Điểm mấu chốt để không tự phá chính mình: cờ `MARIADB_SLEEPING` trong vòng
lặp giám sát. Vòng lặp gốc coi "MariaDB đã thoát" là crash → tắt hết
php-fpm+nginx → để Kotlin restart toàn cụm. Nếu KHÔNG có cờ này, chính hành
động Auto-Sleep tự tắt MariaDB sẽ NGAY LẬP TỨC bị hiểu nhầm là crash, phá
sạch tác dụng của tính năng vừa bật.

Chuỗi xử lý "đánh thức": nginx phát hiện file `mariadb-asleep` tồn tại (chỉ 1
lần `stat()` rẻ mỗi request `.php`, vô hại khi tính năng tắt vì file này
không bao giờ được tạo) → `rewrite ... last` nội bộ sang `wake-mariadb.php`
(`internal;`, không gọi trực tiếp từ ngoài được) → PHP spawn lại MariaDB qua
`wake-mariadb.sh` (file DUY NHẤT chứa lệnh khởi động mariadbd, dùng chung với
lần khởi động đầu tiên trong `start-lamp.sh` — tránh 2 nơi chứa cùng 1 lệnh
dài dễ lệch nhau khi sửa sau này) → poll bằng `mysqli_connect` thật (không
chỉ check file socket tồn tại — có khoảng trễ ngắn giữa lúc socket được tạo
và lúc MariaDB thật sự nhận kết nối) → xoá cờ `mariadb-asleep` → redirect
khách về ĐÚNG URL gốc họ định xem (nginx truyền qua `fastcgi_param
ORIGINAL_URI $request_uri` — biến này giữ nguyên URI gốc bất kể rewrite nội
bộ, không phải tự chế).

**Lỗi thiết kế tự bắt được trước khi ship** (không phải chỉ đọc lại bằng
mắt — đã nghĩ tới rồi tự sửa): định đặt `wake-mariadb.php` trong `_admin/`
cho gọn, nhưng `_admin/` bị chặn CHỈ CHO LAN (xem mục 1c) — nếu để nhầm ở đó,
tính năng sẽ KHÔNG BAO GIỜ hoạt động được với khách thật qua Cloudflare Tunnel
(chính đối tượng cần đánh thức MariaDB!). Đã sửa: đặt ở gốc docroot, đánh dấu
`internal` trong nginx.

Cơ chế theo dõi "rảnh bao lâu": KHÔNG dùng `access_log` (đã có
`buffer=64k flush=5m` từ trước để giảm hao mòn flash — dùng log làm nguồn tin
sẽ trễ tới 5 phút, không hợp với nhu cầu biết "rảnh" trong vài chục giây-vài
phút). Thay bằng 1 script PHP cực nhẹ (`activity-touch.php`, nạp qua
`auto_prepend_file` CHỈ khi bật tính năng) — chỉ gọi `touch()` (cập nhật
mtime, không ghi nội dung) mỗi request PHP thật, rẻ hơn nhiều so với ghi log.

Đã kiểm chứng (chưa build-test thật trên thiết bị, xem mục 8 nguyên tắc
chung): `php -l` sạch cho 2 file PHP mới + toàn bộ file `.php` khác;
`sh -n` sạch cho `start-lamp.sh` sau khi sửa; mô phỏng đầy đủ pipeline `sed`
sinh `nginx.conf`/`php.ini` ở cả 2 nhánh bật/tắt — ngoặc cân bằng, không còn
placeholder sót; cross-check `binding`/`R.string` cho phần UI Kotlin mới —
sạch; đếm ngoặc `{}`/`()` sau khi lọc bỏ dòng comment cho 3 file `.kt` bị sửa
— cân bằng cả 3. `stat -c %Y` (dùng để đọc mốc hoạt động) đã tra cứu xác
nhận là cú pháp hợp lệ của `toybox` (công cụ dòng lệnh chuẩn của Android từ
6.0 trở lên, hỗ trợ `-c FORMAT` y hệt GNU coreutils, `%Y` = "Mod unix time")
— tự tin hơn hẳn so với chỉ đoán, dù vẫn chưa chạy thật trên thiết bị.

**Vòng audit lại (theo yêu cầu người dùng "kiểm tra vỏ rỗng") phát hiện 3 lỗi
thật, đã sửa:**
1. Comment giải thích cho `__CF_REALIP_DIRECTIVES__` (thêm ở mục này) và
   comment đầu `wake-mariadb.sh.template` (của chính vòng làm việc này) đều
   VÔ TÌNH viết lại nguyên văn tên placeholder mà chúng đang mô tả — bị
   chính `sed ... g` của nó thay đè, tạo ra dòng comment vô nghĩa (không
   crash vì vẫn là comment hợp lệ, nhưng sai/rối). Cùng lỗi này cũng có SẴN
   TỪ TRƯỚC (không phải do vòng này gây ra) ở 3 chỗ khác trong
   `php.ini.template` (`__EXT_DIR__`, `__RUNDIR__` x2) — đã sửa hết, đổi
   sang mô tả không lặp lại token literal.
2. `wake-mariadb.php` dùng `mysqli_connect(null, ..., $socket)` (kiểu tham
   số socket riêng) để kiểm tra MariaDB sẵn sàng — đổi sang
   `mysqli_connect('localhost:' . $socket, ...)` cho khớp ĐÚNG kiểu gọi mà
   `wp-config.php.template` đang dùng thật cho cả website (đã có bằng chứng
   hoạt động), thay vì dùng 1 kiểu gọi khác chưa từng chứng minh trong
   chính dự án này dù cả hai đều đúng theo tài liệu PHP.

Giới hạn CHƯA giải quyết (để ở mục 7): `_admin/` (Adminer...) chưa tích hợp
cơ chế đánh thức — vào đúng lúc MariaDB ngủ sẽ thấy lỗi kết nối, phải tự tải
lại; dùng khoá advisory (`fopen` mode `x`) để giảm spawn trùng khi nhiều
khách cùng lúc đánh thức, nhưng lớp bảo vệ CHÍNH vẫn là cơ chế tự chống chạy
trùng có sẵn của MariaDB — rủi ro tồn dư cực thấp, không phải zero tuyệt đối.

## 1k. Lỗi THẬT đầu tiên trên thiết bị thật (vòng phản hồi thứ 8) —
`mariadb-install-db` fail, đã tìm ra nguyên nhân gốc bằng audit code, không
phải đoán

**Đây là lần đầu tiên có bằng chứng người dùng ĐÃ build được APK và CÀI LÊN
MÁY THẬT** (khác mọi mục 1e-1j trước đó, vốn chỉu test bằng binary Ubuntu
x86 hoặc mô phỏng pipeline `sed`) — log thật cho thấy: app chạy đúng tới
bước quyết định Dual-Mode (mục 1f) — chọn đúng chế độ `full` (RAM=3680MB >
ngưỡng 3072MB) — dò đúng module `realip` của nginx (mục APO ở README) — rồi
fail Y HỆT NHAU ở đúng 1 bước: `mariadb-install-db that bai`, lặp lại giống
hệt qua nhiều lần thử lại (không đổi lỗi giữa các lần — dấu hiệu quan trọng
để loại bỏ giả thuyết "dữ liệu dở dang từ lần thất bại trước").

**Nguyên nhân gốc (xác nhận bằng audit code, KHÔNG phải suy đoán từ log)**:
đọc lại `php.sh` — dòng thu thập file để đóng gói vào `www.zip` (mục
"Thu thap toan bo .so phu thuoc") chỉ khớp file có tên kết thúc `.so*`. Toàn
bộ thư mục `share/mariadb/` (hoặc `share/mysql/` tuỳ bản) mà `mariadb`
tải về **CÓ tồn tại trong `$EXTRACT_DIR`** (do `termux_download_with_deps`
giải nén nguyên `data.tar` của gói `.deb`) nhưng **CHƯA BAO GIỜ được copy**
vào `$OUT_DIR`/`$STAGING` — không qua cơ chế `lib*.so` (chỉ nhận file `.so`,
xem `build-apk.yml` dòng `cp *.so ... jniLibs/`), cũng không qua `www.zip`
(staging trước đây chỉ chèn các file `.template`/`.php` viết tay, không
đụng tới thư mục này). Kết quả: thư mục này **không tồn tại ở bất kỳ đâu
trên điện thoại**. `mariadb-install-db` (thực chất gọi `mariadbd --bootstrap`
bên trong) cần các file `.sql` ở đây để sinh system tables, và cần
`errmsg.sys` chỉ để KHỞI ĐỘNG được (`init_errmessage()` chạy trước cả bước
bootstrap) — thiếu 1 trong 2 sẽ fail NGAY LẬP TỨC, giống hệt nhau mọi lần,
bất kể RAM/retry/trạng thái dở dang — khớp chính xác 100% với log thật quan
sát được.

**Đã sửa (3 file, chưa build-test thật lại — cần người dùng push + build lại
để xác nhận):**
1. `php.sh`: thêm bước tìm thư mục `share` chung (tất cả gói Termux cài
   chung 1 prefix nên chỉ có 1 thư mục `share` duy nhất gộp từ mọi gói đã
   tải) và copy nguyên vẹn vào `_supervisor/mariadb-share/share/` trong
   `www.zip` — cố ý copy cả thư mục thay vì chỉ phần `mariadb`/`mysql` để
   không phải đoán đúng tên con giữa các phiên bản.
2. `start-lamp.sh`: thêm `--basedir="$MARIADB_BASEDIR"` (trỏ vào thư mục
   trên) + `--tmpdir="$TMPDIR"` (rủi ro đã ghi trước ở mục 7 #0b, tiện sửa
   cùng lúc dù chưa có bằng chứng riêng đây là nguyên nhân) vào lệnh
   `mariadb-install-db`. Thêm kiểm tra `[ -d "$MARIADB_BASEDIR" ]` sớm, báo
   lỗi rõ ràng thay vì để `mariadb-install-db` tự báo lỗi mơ hồ nếu ai đó
   chạy nhầm bản APK cũ (build trước fix này).
3. `wake-mariadb.sh.template`: thêm placeholder `__MARIADB_BASEDIR__` (và
   `$TMPDIR` trực tiếp, không qua placeholder vì đã có sẵn trong environment
   lúc script này chạy) vào lệnh `mariadbd` thật — vì **charset/error catalog
   cần đọc ở MỌI LẦN CHẠY, không chỉ lúc cài đặt** (nếu chỉ sửa
   `mariadb-install-db` mà bỏ qua `mariadbd`, install có thể qua nhưng
   mariadbd thật vẫn có thể lỗi/thiếu charset lúc chạy request thật).

**CẬP NHẬT (sau khi qua được mục 1l/1m - cài đặt APK đã thành công)**: build
có đủ fix mục 1k (basedir) + 1l (debug.keystore) + 1m (thu hẹp bundling) đã
CÀI ĐƯỢC lên máy thật, nhưng bấm "Bật server" vẫn ra Y HỆT lỗi
"mariadb-install-db that bai" như log gốc ban đầu - nghĩa là fix `--basedir`
ở mục 1k **CHƯA CHẮC đã đúng/đủ**, dù lý luận từ audit code có vẻ hợp lý.
Vẫn CHƯA có nội dung thật của `mysql-install.log` (chỉ có dòng log wrapper
"LOI: ... xem mysql-install.log" từ `start-lamp.sh`, chưa từng thấy nội dung
BÊN TRONG file đó) - đây là việc ưu tiên số 1 cần lấy được trước khi sửa
tiếp, để tránh đoán mò thêm vòng nữa. Cũng cần xem log build GitHub Actions
(bước chạy `php.sh`) để xác nhận dòng "Da dong goi ... vao
_supervisor/mariadb-share" có thực sự in ra hay bị rơi vào nhánh "CANH BAO
NGHIEM TRONG: khong tim thay thu muc con 'mariadb' hoac 'mysql'" (nếu vậy,
nghĩa là giả định cấu trúc gói Termux mariadb ở mục 1k sai ngay từ bước
build, chưa cần xét tới runtime).

**CHƯA verify (thành thật, giống mọi mục khác)**:
- Chưa có internet lúc sửa (môi trường này không truy cập được
  `packages.termux.dev`) nên KHÔNG kiểm tra được cấu trúc `.deb` mariadb
  thật của Termux — giả định thư mục con tên `mariadb` hoặc `mysql` bên
  trong `share/` dựa trên quy ước phổ biến của MariaDB, có cảnh báo runtime
  (`CANH BAO` trong `php.sh`) nếu không khớp giả định này, nhưng cần build
  lại thật để xác nhận đây là fix ĐẦY ĐỦ, không phải TRUOC MOT PHAN của
  chuỗi lỗi (vd sau khi qua được bước này có thể lộ ra lỗi tiếp theo — 0a,
  0c, 0d ở mục 7 vẫn còn "CHƯA verify").
- `--tmpdir="$TMPDIR"` thêm phòng ngừa theo mục 7 #0b, chưa có bằng chứng
  riêng (chỉ 1 log lỗi duy nhất, không phân biệt được liệu thiếu basedir
  hay thiếu tmpdir hay cả 2 mới là nguyên nhân) — nếu sau khi sửa basedir mà
  vẫn lỗi, xem `mysql-install.log` mới để biết còn thiếu gì.
- Việc tự tìm 1 thư mục "share" duy nhất bằng `find ... -name share | head -n1`
  giả định các gói Termux dùng chung 1 prefix (đúng theo hiểu biết về cách
  Termux đóng gói) — nếu sai, `php.sh` in cảnh báo rõ ràng thay vì fail âm
  thầm, nhưng chưa chạy thật để xác nhận.

**Bài học cho các vòng audit sau**: đây là lỗi kiểu "bỏ sót khi liệt kê file
cần đóng gói", không phải lỗi logic trong script chạy trên điện thoại — audit
code trước đó (`sh -n`, mô phỏng `sed`...) không bắt được vì các file đó
đúng cú pháp, chỉ đơn giản là KHÔNG ĐƯỢC ĐÓNG GÓI. Nếu có build tiếp theo
vẫn lỗi ở bước mới, ưu tiên kiểm tra "file cần thiết có thực sự nằm trong
`www.zip`/`jniLibs` không" trước khi nghi ngờ logic script.

## 1l. "Ứng dụng chưa được cài đặt" khi cài APK mới đè lên bản cũ (vòng phản
hồi thứ 9) — cố định debug keystore

Sau khi build lại APK với fix mục 1k, người dùng cài `app-debug.apk` mới lên
đúng thiết bị đã cài bản build TRƯỚC đó (bản đã dùng để lấy log lỗi
mariadb-install-db ở mục 1k) → Android báo "Ứng dụng chưa được cài đặt"
(dialog chung chung, không nói rõ lý do).

**Nguyên nhân (xác nhận bằng audit, không đoán)**: repo KHÔNG khai báo
`signingConfigs` nào trong `app/build.gradle.kts`, và `build-apk.yml` không
cache `~/.android/`. Android Gradle Plugin mặc định TỰ SINH
`~/.android/debug.keystore` nếu chưa có trên máy — GitHub Actions là máy ảo
MỚI HOÀN TOÀN mỗi lần chạy, nên **mỗi lần build CI sinh ra 1 certificate
NGẪU NHIÊN KHÁC NHAU** (dù alias/mật khẩu quy ước giống nhau
`androiddebugkey`/`android` — chỉ có cặp khoá thật là ngẫu nhiên). Android
chặn cài đè APK mới lên app cùng `applicationId` nếu certificate khác nhau,
đúng y hệt tình huống này (bản cũ ký bởi certificate ngẫu nhiên của lần
build trước, bản mới ký bởi certificate ngẫu nhiên KHÁC của lần build sau).

**Đã sửa**: tạo sẵn 1 file `app/debug.keystore` cố định (bằng `keytool`,
alias/mật khẩu đúng quy ước Android debug mặc định, hạn 10000 ngày) và commit
thẳng vào repo (không nằm trong diện bị `.gitignore` loại trừ — đã kiểm tra),
khai báo `signingConfigs { getByName("debug") { storeFile = file("debug.keystore")... } }`
trong `app/build.gradle.kts` để MỌI lần build CI từ nay dùng CHUNG 1
certificate. **Lưu ý bắt buộc 1 LẦN DUY NHẤT**: vì certificate mới này khác
với certificate ngẫu nhiên của MỌI bản build trước đó, người dùng phải GỠ
CÀI ĐẶT bản đang có trên điện thoại trước khi cài bản build kế tiếp (mất
data MariaDB/WordPress hiện có, chấp nhận được vì đang ở giai đoạn build-test
lần đầu). Từ lần build này trở đi, cài đè bình thường không cần gỡ nữa.

**Không liên quan đến mục 7.6 (code signing cho bản RELEASE)** — fix này chỉ
làm debug keystore ỔN ĐỊNH giữa các lần build CI, KHÔNG phải tạo release
keystore để phát hành/ký chính thức; mục 7.6 vẫn còn nguyên, đừng nhầm 2 việc
này là một.

## 1m. "Ứng dụng chưa được cài đặt" xảy ra ngay cả khi cài SẠCH (không phải
đè lên bản cũ) — nghi ngờ dung lượng APK tăng, đã thu hẹp phạm vi bundling

Người dùng xác nhận lại: lần cài thất bại ở mục 1l thực ra là **gỡ cài đặt
bản cũ HOÀN TOÀN rồi mới cài bản mới** (không phải cài đè) — nghĩa là giả
thuyết "lệch chữ ký do cài đè" ở mục 1l **KHÔNG giải thích được lỗi này**,
vì không có app nào cùng `applicationId` tồn tại sẵn để xung đột chữ ký khi
cài trên máy sạch. Quan trọng hơn: bản build ĐÓ chính là bản chỉ có fix mục
1k (đóng gói `share/`), CHƯA có fix debug.keystore ở mục 1l — nên 2 việc
này (1l và 1m) là 2 sự kiện độc lập, không liên quan nhau.

**Dữ kiện xác nhận được**: cùng 1 thiết bị (Sharp/SoftBank "706SH") **đã
từng cài thành công** bản build gốc (bản tạo ra log lỗi mariadb-install-db ở
mục 1k) — nghĩa là thiết bị này chắc chắn tương thích ABI/Android version,
loại trừ hẳn khả năng "máy chỉ ho trợ CPU 32-bit". File `app-debug.apk` sau
giải nén nặng 96,32 MB - không có dấu hiệu bị cắt cụt/hỏng (kích thước hợp
lý so với zip nguồn 94,73 MB từ GitHub Actions artifact). Người dùng không
có máy tính/không dùng được `adb`, nên KHÔNG lấy được mã lỗi
`INSTALL_FAILED_*` chính xác - mọi suy luận dưới đây dựa trên loại trừ, KHÔNG
có bằng chứng log trực tiếp.

**Khác biệt DUY NHẤT** giữa bản gốc (cài được) và bản này (không cài được)
là đúng 1 thay đổi: fix mục 1k thêm bước copy **nguyên cả thư mục `share/`
dùng chung** (gộp từ nginx + php-fpm + mariadb + php đã tải) vào `www.zip`.
Lúc viết fix đó, dòng chú thích tự ước lượng "vài trăm KB, không đáng kể" —
**đây là USE ĐOÁN CHƯA ĐO THẬT**, rất có thể sai: PHP thường kéo theo dữ
liệu `icu`/gettext (cho module `intl`/`mbstring`) nặng tới vài chục MB, cộng
thêm doc/man của nginx - có thể đã đẩy `www.zip` (và do đó cả APK) phình to
đáng kể so với bản gốc.

**Đã thu hẹp lại** (`php.sh`): thay vì copy nguyên `share/`, giờ tìm và chỉ
copy ĐÚNG thư mục con `share/mariadb` (hoặc `share/mysql`) — nơi thực sự
chứa SQL bootstrap + errmsg.sys + charset mà `mariadb-install-db`/`mariadbd`
cần, bỏ qua phần dữ liệu của nginx/php không liên quan. Thêm dòng log in ra
dung lượng thực tế của phần đã đóng gói (`du -sh`) để lần build tới thấy
ngay con số thật thay vì đoán.

**CHƯA xác nhận đây có phải nguyên nhân thật hay không** (thiếu bằng chứng
`adb`/dung lượng trống thiết bị) — các khả năng khác chưa loại trừ được:
hết dung lượng trống trên máy (nhiều file `.zip`/`.apk` debug cũ đọng lại
trong Downloads cộng dồn), hoặc lỗi giải nén/tải file một lần duy nhất
(transient). Việc thu hẹp bundling ở trên là cải thiện HỢP LÝ dù nguyên
nhân thật là gì (giảm dung lượng APK vô ích), nhưng **không thay thế** cho
việc người dùng tự kiểm tra dung lượng trống trên máy (Cài đặt → Lưu trữ)
và xoá bớt các file `.zip`/`.apk` debug cũ trong Downloads trước khi thử cài
lại bản mới nhất.

## 1n. Có log thật của `mysql-install.log` lần đầu tiên — SAI HOÀN TOÀN so
với giả thuyết mục 1k, vấn đề nằm ở bước THỰC THI binary, không phải thiếu
file SQL/errmsg

Sau khi qua được mục 1l/1m (cài đặt thành công), người dùng bật server vẫn
gặp lỗi MariaDB. Lần này lấy được **nội dung thật** của `mysql-install.log`
(lần đầu tiên trong suốt quá trình, trước giờ chỉ thấy dòng log wrapper
"LOI: ... xem mysql-install.log"):

```
.../start-lamp.sh[258]: /data/app/com.wppocket.server-<hash>/lib/arm64/libmariadbinstall.so: No such file or directory
```

**Đây KHÔNG PHẢI lỗi từ bên trong MariaDB** (không phải "missing SQL file",
không phải "can't find messagefile" như giả thuyết mục 1k suy luận) — đây là
lỗi của **chính shell khi thử THỰC THI file `libmariadbinstall.so`**, xảy ra
TRƯỚC KHI mariadb-install-db kịp chạy dòng lệnh nào. Nghĩa là toàn bộ lý
luận ở mục 1k (thiếu `share/mariadb` khiến mariadb-install-db lỗi khi đọc
SQL/errmsg) **CHƯA BAO GIỜ có cơ hội được kiểm chứng** - binary còn chưa
chạy được thì chưa thể nói tới việc nó đọc thiếu file gì. Fix `--basedir` ở
mục 1k không sai về mặt lý thuyết (có thể vẫn cần sau này), nhưng KHÔNG PHẢI
nguyên nhân của lỗi đang thấy từ đầu tới giờ.

**"No such file or directory" khi thực thi 1 file có 2 khả năng**, không
phân biệt được chỉ từ dòng log này:
1. File `libmariadbinstall.so` thật sự KHÔNG tồn tại tại đúng đường dẫn đó
   trên máy (lỗi ở bước build/đóng gói - `php.sh` không copy được binary
   này vào APK vì lý do nào đó).
2. File CÓ tồn tại, nhưng nhân Android không LOAD được nó khi thực thi -
   khả năng đáng ngờ nhất: binary MariaDB tải từ kho gói Termux có thể được
   biên dịch với đường dẫn "dynamic linker/interpreter" cố định trỏ vào bên
   trong môi trường Termux thật (vd `/data/data/com.termux/files/usr/...`)
   - đường dẫn này KHÔNG tồn tại trên máy này (app không cài qua Termux).
   Nếu đúng vậy, nhân Android trả lỗi `ENOENT` ("No such file or directory")
   dù file rõ ràng có ở đó - đây LÀ rủi ro CHƯA TỪNG được audit/nhắc tới ở
   bất kỳ đâu trong repo trước giờ (đã tìm, không thấy). **CHƯA XÁC NHẬN
   được khả năng 2 này đúng hay sai** - môi trường sửa code này không có
   internet để tải thử gói mariadb thật của Termux và kiểm tra header ELF
   của binary, nên đây vẫn là suy luận, không phải bằng chứng trực tiếp.

**Đã làm (chỉ thêm chẩn đoán, KHÔNG đoán fix mới)**: cố tình KHÔNG vá thêm 1
giả thuyết nữa (đã sai 3 lần liên tiếp ở mục 1k/1l/1m rồi) - thay vào đó,
thêm đoạn kiểm tra TRỰC TIẾP vào `start-lamp.sh`, ngay trước dòng gọi
`libmariadbinstall.so`: in ra rõ ràng "file TON TAI" kèm `ls -la` (quyền,
kích thước) hoặc "file KHONG TON TAI", và tổng số file trong thư mục chứa
binary — tất cả in thẳng vào log app (mục "Xem log"), KHÔNG cần đào log
build GitHub Actions nữa. Lần chạy tiếp theo sẽ biết ngay là khả năng 1 hay
2 ở trên, từ đó mới quyết định hướng sửa đúng (sửa `php.sh` nếu là khả năng
1, hoặc thêm bước `patchelf`/gọi linker tường minh nếu là khả năng 2).

**Việc cần làm tiếp**: người dùng build lại (có đoạn chẩn đoán mới) → bật
server → xem log app → đọc 2 dòng chẩn đoán mới ngay phía trên dòng lỗi cũ →
báo lại nguyên văn. Đồng thời vẫn nên xem log build GitHub Actions (bước
"Chuan bi runtime + website (php)") bằng cách **BẤM MỞ RỘNG (click) trực
tiếp bước đó**, không chỉ dùng ô tìm kiếm log (nghi ô tìm kiếm của GitHub
không quét được nội dung các bước đang thu gọn - lần trước tìm "mariadb-share"
và "CANH BAO NGHIEM TRONG" đều ra 0/0 dù chưa chắc code không chạy) - tìm
dòng "CANH BAO: khong tim thay binary cho MARIADB_INSTALL_BIN" (nếu có nghĩa
là ngay từ bước tải/tìm binary trong `php.sh` đã thất bại, chưa cần bàn tới
`share/`).

## 1o. Xác nhận file TỒN TẠI + ĐỦ QUYỀN thực thi nhưng vẫn lỗi — rất có thể
`mariadb-install-db` là SHELL SCRIPT với shebang trỏ sai, không phải binary
thiếu

Log build GitHub Actions xác nhận bundling `share/mariadb` ở mục 1m chạy
đúng (`Da dong goi .../usr/share/mariadb ... dung luong: 5.7M`). Log chẩn
đoán mới thêm ở mục 1n cho kết quả:

```
libmariadbinstall.so TON TAI: -rwxr-xr-x 1 system system 22151 ... 
Tong so file trong $BIN: 83
```

**Loại trừ dứt điểm khả năng 1 ở mục 1n** (file không tồn tại) — file có
thật, đúng quyền thực thi (`rwxr-xr-x`), size hợp lý. Vậy chỉ còn khả năng 2:
Android không LOAD được file dù nó tồn tại và có quyền chạy — đúng kiểu lỗi
kinh điển khi thực thi 1 **shell script có dòng shebang trỏ tới interpreter
không tồn tại trên máy** (ví dụ
`#!/data/data/com.termux/files/usr/bin/bash`) — kernel trả về CHÍNH XÁC
"No such file or directory" trong trường hợp này, dù file script rõ ràng có
ở đó.

**Bằng chứng gián tiếp ủng hộ giả thuyết này**: kích thước chỉ 22KB — quá
nhỏ cho 1 binary C/C++ biên dịch liên kết với MariaDB, nhưng hợp lý cho 1
shell script. `mariadb-install-db` trong nhiều bản phân phối MariaDB/MySQL
(rất có thể gồm cả bản Termux) vốn dĩ LÀ shell script gọi `mariadbd
--bootstrap` bên trong, không phải binary riêng.

**Vẫn CHƯA xác nhận 100%** — môi trường sửa code không có internet để tải
thử gói mariadb thật của Termux và xem trực tiếp file, nên đây là suy luận
từ bằng chứng gián tiếp (kích thước + đúng loại lỗi kinh điển), không phải
đọc trực tiếp được nội dung file.

**Đã sửa (`php.sh`)**: sau bước copy mỗi binary trong vòng lặp đổi tên
`lib*.so`, kiểm tra 2 byte đầu file — nếu là `#!` (dấu hiệu chắc chắn của
script, ELF thật luôn bắt đầu bằng `\x7fELF`) thì tự động đổi dòng shebang
đầu tiên thành `#!/system/bin/sh` (shell có sẵn trên MỌI thiết bị Android,
khác với interpreter Termux không tồn tại ngoài Termux thật). Áp dụng cho
CẢ 7 binary trong vòng lặp (không chỉ mariadb-install-db), vì `mariadb`,
`mariadb-dump` rất có thể cũng là script tương tự, chỉ là chưa lộ ra vì
`start-lamp.sh` chưa chạy tới đó.

**Rủi ro CÒN LẠI, chưa giải quyết được nếu đúng đây là script**: đổi được
shebang chỉ giải quyết bước ĐẦU TIÊN (chạy được interpreter). Bên TRONG
script gốc rất có thể gọi các chương trình khác (như `mariadbd`) bằng TÊN
TRẦN (`mariadbd --bootstrap ...`) dựa vào `$PATH`, hoặc bằng đường dẫn tuyệt
đối kiểu Termux — cả 2 đều sẽ KHÔNG tìm thấy trên máy này, vì `start-lamp.sh`
KHÔNG set `$PATH` bao gồm `$BIN`, và dù có set thì binary thật của chúng ta
tên là `libmariadbd.so` (đổi tên theo quy ước `lib*.so`), không phải
`mariadbd` — tên KHÔNG khớp. Nếu gặp lỗi mới (khác "No such file or
directory" như cũ) sau khi build với fix này, đó là dấu hiệu ĐÃ QUA được
bước shebang, cần đọc lỗi mới để sửa tiếp bước đó, KHÔNG phải quay lại nghi
ngờ mục 1o này nữa.

**Để không phải đoán tiếp nếu vẫn lỗi**: `php.sh` giờ in TOÀN BỘ nội dung
script gốc (nếu phát hiện là script) ra thẳng log build GitHub Actions (giới
hạn 200 dòng đầu) — nếu vòng sau vẫn lỗi, đọc trực tiếp log build (bước
"Chuan bi runtime + website (php)", đoạn giữa "CANH BAO: ... la SHELL
SCRIPT" và "KET THUC libmariadbinstall.so") để biết chính xác script gọi gì
bên trong, thay vì đoán tiếp.

## 1p. Fix shebang mục 1o CÓ TÁC DỤNG THẬT — script chạy được, lỗi mới lộ ra
2 vấn đề khác: thiếu `my_print_defaults` + bug `find_bin` khớp nhầm file

Build lại với fix mục 1o, log build xác nhận:
```
CANH BAO: libmariadbinstall.so la SHELL SCRIPT ... shebang goc: "#!/data/data/com.termux/files/usr/bin/sh" ... Dang doi shebang sang /system/bin/sh.
```
Giả thuyết mục 1o **ĐÚNG** — xác nhận trực tiếp bằng nội dung file thật (không còn suy luận): `mariadb-install-db` của Termux đúng là shell script, dòng đầu tiên nguyên bản là
`#!/data/data/com.termux/files/usr/bin/sh`. Sau khi vá, lỗi đổi hẳn sang:
```
FATAL ERROR: Could not find my_print_defaults
The following directories were searched: .../mariadb-share/bin, .../mariadb-share/extra
```
Đây là **tiến bộ thật** (đúng như dự đoán trong mục 1o) — script đã chạy được, đang thực thi logic bên trong (tự tìm binary phụ trợ qua `--basedir`), chỉ là còn thiếu 1 file.

**Phát hiện thêm 1 bug thật khi đọc log**: đoạn log cũng cho thấy
`libmysqlcli.so` (biến `MYSQL_CLI_BIN`, đáng lẽ là client `mariadb`/`mysql`)
lại chứa nội dung của `mariadb-convert-table-format` (1 script Perl chuyển
đổi bảng MyISAM) — SAI HOÀN TOÀN so với mong đợi. Nguyên nhân: hàm
`find_bin()`/`find_sbin()` dùng pattern `"*/bin/$1*"` (CÓ dấu `*` cuối) —
với `find_bin mariadb`, pattern trở thành `*/bin/mariadb*`, khớp VỚI MỌI
file bắt đầu bằng "mariadb" trong `bin/` (mariadb-dump, mariadb-install-db,
mariadb-convert-table-format, mariadb-admin...). Vì thứ tự duyệt file của
`find` KHÔNG đảm bảo theo bảng chữ cái, `head -n1` lấy ra file nào tuỳ hên
xui — lần build này vớ đúng file sai. **Đã sửa**: bỏ dấu `*` cuối trong cả
2 hàm, khớp CHÍNH XÁC tên file.

**Đã sửa (`php.sh`)**:
1. Sửa `find_bin`/`find_sbin` khớp chính xác tên file (bug ở trên).
2. Thêm tìm `my_print_defaults` (biến `MY_PRINT_DEFAULTS_BIN`, trước giờ
   chưa hề được tìm tới, dù đây là binary phụ trợ THIẾT YẾU mà
   mariadb-install-db tự gọi qua `--basedir`, không qua bất kỳ tham số dòng
   lệnh hay biến môi trường nào ta kiểm soát được).
3. Tạo `$MARIADB_BASEDIR/bin/` (thư mục THẬT, nằm trong `www.zip`, KHÔNG bị
   giới hạn "chỉ nhận lib*.so" như nativeLibraryDir) chứa 5 file với **TÊN
   GỐC** (không đổi tên): `my_print_defaults`, `mariadbd`,
   `mariadb-install-db`, `mariadb`, `mariadb-dump` — copy trực tiếp từ
   `$EXTRACT_DIR`, áp dụng LẠI đúng kiểm tra shebang như mục 1o cho từng
   file (phòng trường hợp file nào trong số này CŨNG là script).
4. Tạo thêm 3 symlink `sbin`, `libexec`, `extra` đều trỏ về `bin` — vì CHƯA
   biết chắc bản MariaDB này tìm `mariadbd` ở thư mục con nào (mới chỉ thấy
   nó tìm `my_print_defaults` ở đúng 2 nơi "bin"/"extra"), symlink cả 4 tên
   về 1 chỗ để không phụ thuộc đúng 1 giả định.

**CHƯA xác nhận đây đã ĐỦ hay chưa** — rất có thể sau khi qua được bước
`my_print_defaults`, script sẽ tiếp tục tìm `mariadbd` (hoặc file khác) và
lộ ra thiếu sót tiếp theo, vì mới chỉ đọc được ~200 dòng đầu của script (do
giới hạn `head -n 200` khi in log), chưa thấy được đoạn logic gọi
`mariadbd --bootstrap` thực sự nằm ở đâu trong phần sau của file.

## 1q. Phát hiện bug NGHIÊM TRỌNG: `www.zip` chỉ giải nén ĐÚNG 1 LẦN trong
suốt vòng đời cài đặt — mọi fix ở mục 1k/1p có thể CHƯA TỪNG được áp dụng
thật trên máy

Build #31 log xác nhận `mariadb-share/bin/` (chứa `my_print_defaults`, fix
mục 1p) được đóng gói đúng vào build. Nhưng chạy trên máy thật vẫn ra ĐÚNG
lỗi cũ "Could not find my_print_defaults", tìm đúng 2 thư mục đã tạo — dù
build rõ ràng đã có file đó.

**Nguyên nhân xác nhận bằng đọc code Kotlin** (`ServerForegroundService.kt`,
hàm `prepareRuntimeIfNeeded()`): việc giải nén `assets/www.zip` ra
`filesDir/www/` được canh giữ bởi 1 marker file (`.www_extracted`) kiểu
"đã giải nén hay chưa" — KHÔNG mang thông tin phiên bản nào cả:
```kotlin
val marker = File(filesDir, ".www_extracted")
if (!marker.exists()) { ...giai nen... ; marker.writeText("ok") }
```
`filesDir` chỉ bị Android xoá khi GỠ CÀI ĐẶT hoặc "Xoá dữ liệu" — KHÔNG bị
xoá khi cài đè (update) APK. Từ sau mục 1l (debug keystore cố định), người
dùng không còn cần gỡ cài đặt giữa các lần build nữa — nghĩa là **rất có
thể mọi lần build/cài đè từ mục 1k trở đi đều giữ nguyên nội dung `www.zip`
CŨ trên máy**, các fix bên trong nó (bundling `share/mariadb` ở mục 1k,
`mariadb-share/bin/` ở mục 1p) build đúng nhưng CHƯA TỪNG thực sự chạy trên
thiết bị.

**Vì sao fix shebang (mục 1o) vẫn quan sát được có tác dụng dù có bug này**:
`libmariadbinstall.so` nằm trong `nativeLibraryDir` (jniLibs), do
PackageManager của Android tự quản lý và LUÔN cập nhật đúng theo APK mới
nhất ở MỌI lần cài (không đi qua `www.zip`/marker) — nên fix đó không bị
ảnh hưởng bởi bug này. Chỉ những gì nằm TRONG `www.zip` (mọi thứ dưới
`_supervisor/`, gồm cả `mariadb-share/`) mới bị kẹt.

**Đã sửa** (`ServerForegroundService.kt`): đổi nội dung marker từ chuỗi cố
định `"ok"` sang `packageManager.getPackageInfo(packageName, 0).lastUpdateTime`
(mốc thời gian Android tự cập nhật ở MỌI lần cài/cài đè, kể cả khi
versionCode không đổi). Lệch giá trị so với lần giải nén trước → tự giải
nén lại; giống hệt → giữ nguyên (vẫn chỉ giải nén 1 lần cho MỖI bản cài, y
như thiết kế ban đầu, chỉ thêm khả năng NHẬN RA khi có bản mới). Vì định
dạng marker cũ (`"ok"`) không parse được thành số, lần cài bản vá này sẽ tự
động coi marker cũ là không hợp lệ và giải nén lại — không bắt buộc người
dùng phải tự xoá dữ liệu, nhưng VẪN khuyến nghị làm 1 lần cho chắc (loại bỏ
hoàn toàn nghi ngờ, vì đây là lần đầu phát hiện bug này, muốn có 1 phép thử
sạch tuyệt đối).

**Bài học cho các vòng audit sau**: khi 1 fix nằm trong `www.zip` (khác với
fix nằm trong `nativeLibraryDir`/jniLibs) mà build log xác nhận đúng nhưng
runtime vẫn y hệt lỗi cũ, **nghi ngờ cache/marker TRƯỚC KHI nghi ngờ logic
fix sai** - kiểm tra `ServerForegroundService.kt` có logic tương tự nào
khác đang cache theo kiểu "chỉ làm 1 lần" hay không (xem thêm dòng
"Se GIU NGUYEN che do nay ve sau" ở quyết định RAM lúc khởi động - CÙNG một
kiểu thiết kế "chỉ đọc 1 lần, đổi qua xoá dữ liệu" - nên đây có thể KHÔNG
phải bug duy nhất kiểu này trong dự án).

## 1r. Người dùng xác nhận LUÔN gỡ cài đặt sạch trước khi cài (loại giả
thuyết cache mục 1q) — nguyên nhân thật: Android/SELinux chặn thực thi file
nằm trong `filesDir`, không phải do cache

Sau khi đề xuất fix mục 1q (marker theo `lastUpdateTime`), người dùng xác
nhận: **trước giờ luôn gỡ cài đặt bản cũ hoàn toàn rồi mới cài bản mới,
chưa bao giờ cài đè**. Gỡ cài đặt hoàn toàn CHẮC CHẮN xoá sạch `filesDir`
(và app có `android:allowBackup="false"` — đã kiểm tra trong
`AndroidManifest.xml` — nên không có chuyện Android khôi phục dữ liệu cũ
qua backup). Vậy giả thuyết cache ở mục 1q **KHÔNG PHẢI nguyên nhân của lỗi
"Could not find my_print_defaults"** — dù bug đó có thật (đáng giữ fix lại
phòng sau này có ai cài đè), nó không giải thích được hiện tượng đang thấy,
vì mỗi lần test đều là cài sạch.

**Nguyên nhân thật (đọc code Kotlin `ServerForegroundService.kt`)**: hàm
`unzip()` copy nội dung file qua `FileOutputStream` đơn thuần, **không hề
gọi `setExecutable()` hay set bất kỳ quyền Unix nào** — nhưng quan trọng
hơn quyền chmod: file nằm trong `filesDir` (nơi ứng dụng tự ghi ra LÚC
CHẠY) — đây CHÍNH LÀ vùng mà kiến trúc README/HANDOFF của dự án này đã ngầm
xác nhận từ đầu là **Android/SELinux có thể từ chối cho thực thi**, dù đã
`chmod +x` đầy đủ. Bằng chứng gián tiếp nhưng rất mạnh: đây CHÍNH LÀ lý do
duy nhất khiến dự án phải bày ra cả cơ chế đổi tên `lib*.so` cầu kỳ cho MỌI
binary khác từ đầu tới giờ (nginx, php-fpm, mariadbd...) — nếu file trong
`filesDir` thực thi được bình thường, đã không cần cơ chế đó ngay từ đầu.
`nativeLibraryDir` là nơi DUY NHẤT được xác nhận chắc chắn cho thực thi
(bằng chứng: mọi binary `lib*.so` đã chạy được xuyên suốt từ mục 1o tới
giờ).

**Vì sao mục 1p (copy file thật vào `mariadb-share/bin/`) build đúng nhưng
runtime vẫn lỗi y hệt**: file `my_print_defaults` khi đó nằm trong
`filesDir/www/_supervisor/mariadb-share/bin/` — đúng vùng bị chặn thực thi
ở trên. Script `mariadb-install-db` dùng `test -x` để tìm — nếu Android từ
chối quyền thực thi ở tầng SELinux (khác với bit chmod thông thường mà
`test -x` kiểm tra — CHƯA chắc chắn 100% `test -x` có phát hiện được từ
chối SELinux hay không, nhưng dù không phát hiện qua `test -x`, việc THỰC
THI thật sự vẫn sẽ bị chặn và báo lỗi tương đương), kết quả cuối cùng quan
sát được vẫn khớp: "không dùng được binary này".

**Đã sửa**:
1. `php.sh`: bỏ hẳn đoạn copy file thật vào `mariadb-share/bin/` (không hoạt
   động). Đưa `my_print_defaults` qua CHÍNH cơ chế `lib*.so` như 7 binary
   còn lại (`libmyprintdefaults.so`, vào `nativeLibraryDir`).
2. `start-lamp.sh`: thay vì đặt file thật, giờ **tạo symlink** mỗi lần
   script này chạy — `$MARIADB_BASEDIR/bin/my_print_defaults` (và
   `mariadbd`, `mariadb-install-db`, `mariadb`, `mariadb-dump`) đều trỏ VỀ
   file thật trong `$BIN` (nativeLibraryDir). `test -x` và việc thực thi
   qua symlink đều theo TARGET thật — nơi chắc chắn được thực thi — nên
   không còn phụ thuộc quyền thực thi của file nằm trong `www.zip` nữa. Tạo
   lại (`ln -sf`, ghi đè) MỖI LẦN start-lamp.sh chạy vì `$BIN` (đường dẫn
   nativeLibraryDir) đổi khác nhau ở MỖI LẦN CÀI ĐẶT app (đã thấy nhiều giá
   trị hash khác nhau qua các log trước) — không thể tạo 1 lần cố định lúc
   build.

**CHƯA xác nhận đây đã hết lỗi hoàn toàn** — đây là suy luận có bằng chứng
gián tiếp mạnh (khớp với chính kiến trúc dự án), nhưng chưa có log thật xác
nhận SAU khi áp dụng fix symlink này. Nếu build tới vẫn lỗi (dù đã đổi khác
nội dung lỗi), đó vẫn là tiến bộ - đọc lỗi mới để biết bước tiếp theo, đừng
quay lại nghi ngờ mục 1q (cache) nữa vì đã bị loại trừ ở đây.

## 1s. Fix symlink mục 1r CÓ TÁC DỤNG (qua được `my_print_defaults`) — lỗi
mới liên quan `mariadbd`, đường dẫn ghép bất thường, cần xem toàn bộ script

Build #34, cài sạch (gỡ cài đặt trước như mọi khi), log xác nhận: không còn
lỗi "Could not find my_print_defaults" nữa — symlink mục 1r hoạt động đúng.
Lỗi mới:
```
FATAL ERROR: Could not find /data/user/0/.../mariadb-share//data/data/com.termux/files/usr/bin/mariadbd
```

Đây KHÔNG phải kiểu lỗi đơn giản "thiếu file ở bin/sbin/extra" như
`my_print_defaults` — đường dẫn báo lỗi là `$basedir` nối với 1 đường dẫn
TUYỆT ĐỐI khác trỏ vào Termux thật (`/data/data/com.termux/...`), tạo ra 1
đường dẫn vô nghĩa (`.../mariadb-share//data/data/...`). Nghi ngờ: đâu đó
trong logic script (phần chưa từng thấy được — 200 dòng đầu chỉ mới tới hết
phần giấy phép GPL, chưa tới `main()`/logic tìm `mysqld`), script đọc được
1 giá trị mặc định ĐÃ LÀ đường dẫn tuyệt đối kiểu Termux (có thể từ
`my_print_defaults` đọc 1 file cấu hình mặc định nào đó bundled kèm trong
`share/mariadb/` mà ta đã copy nguyên vẹn), rồi ghép nhầm với `$basedir`
thay vì dùng thẳng.

**CHƯA sửa gì về logic** — cố tình không đoán tiếp vì đã sai nhiều lần khi
đoán logic bên trong 1 file chưa thấy hết. Chỉ sửa `php.sh`: bỏ giới hạn
`head -n 200` khi in nội dung script ra log build, giờ in TOÀN BỘ (`cat`)
để lần build tới thấy được đúng đoạn logic gây lỗi, sửa cho chính xác thay
vì đoán.

**Việc cần làm tiếp**: build lại (chỉ đổi mỗi chỗ in log, không đổi gì về
hành vi chạy) → lỗi runtime chắc chắn vẫn y hệt (vì logic thật chưa đổi) →
lấy TOÀN BỘ nội dung `libmariadbinstall.so` trong log build lần này (giờ
không bị cắt ở 200 dòng nữa) gửi lại để đọc được đoạn tìm `mysqld`/`mariadbd`
thật.

## 1t. Tìm ra CHÍNH XÁC nguyên nhân lỗi `mariadbd` bằng cách đọc nguyên văn
script thật + đối chiếu mã nguồn gốc MariaDB trên GitHub (không còn đoán)

Ở mục 1s, mình đã tra được mã nguồn gốc `mysql_install_db.sh` thật của
MariaDB trên GitHub (`MariaDB/server`) để có cơ sở đối chiếu, và yêu cầu
người dùng lấy toàn bộ nội dung script thật của Termux (sau khi bỏ giới hạn
`head -n 200`). Có nội dung đầy đủ, thấy ngay dòng gây lỗi, trong nhánh xử
lý khi có truyền `--basedir` (đúng nhánh mình dùng):

```sh
elif test -n "$basedir"
then
  bindir="$basedir/bin"
  resolveip="$bindir/resolveip"
  mysqld="$basedir//data/data/com.termux/files/usr/bin/mariadbd"   # <-- day
  langdir="$basedir/share/mariadb/english"
  srcpkgdatadir="$basedir/share/mariadb"
  ...
```

So với mã nguồn gốc (dùng `@mysqld_locations@` - 1 placeholder được thay
bằng danh sách thư mục TƯƠNG ĐỐI lúc build), bản Termux lại đóng cứng
**NGUYÊN VĂN 1 đường dẫn tuyệt đối trỏ vào Termux thật** ngay trong mã
nguồn của script (`/data/data/com.termux/files/usr/bin/mariadbd`), nối
thẳng vào `$basedir` — khác hẳn `langdir`/`srcpkgdatadir` ngay bên cạnh vẫn
dùng `$basedir/...` bình thường (nên `share/mariadb` ở mục 1k vẫn hoạt động
đúng). Đây rõ ràng là đặc thù/lỗi từ quá trình Termux build gói này, không
phải điều ta có thể sửa bằng cách đổi `--basedir` truyền vào - giá trị này
là chuỗi có sẵn trong file, không tính toán lúc chạy.

**Đã sửa** (`start-lamp.sh`): tạo thêm 1 symlink tại ĐÚNG đường dẫn tuyệt
đối vô lý đó bên trong `$MARIADB_BASEDIR`:
```sh
mkdir -p "$MARIADB_BASEDIR/data/data/com.termux/files/usr/bin"
ln -sf "$BIN/libmariadbd.so" "$MARIADB_BASEDIR/data/data/com.termux/files/usr/bin/mariadbd"
```
(các symlink `bin/mariadbd` kiểu "bình thường" ở mục 1r vẫn giữ lại, không
hại gì, chỉ là script này không thực sự dùng tới chúng).

**Chủ động sửa thêm 1 việc** (đọc thấy trong CÙNG file, chưa gặp lỗi thật
nhưng chắc chắn sẽ gặp ngay bước kế tiếp): script gọi thẳng
`"$basedir/bin/resolveip" $hostname` để kiểm tra hostname, KHÔNG có
`test -x` nào trước đó (khác với `my_print_defaults`/`mariadbd` đều có kiểm
tra rõ ràng trước khi báo lỗi) - nếu thiếu sẽ ra lỗi FATAL khác hẳn ("Neither
host ... could be looked up"). Đã thêm bundling `resolveip` (qua đúng cơ chế
`lib*.so` như các binary khác) + symlink `$MARIADB_BASEDIR/bin/resolveip`
(đường dẫn TƯƠNG ĐỐI bình thường, không bị lỗi đóng cứng như mariadbd) —
chủ động làm trước, đỡ mất thêm 1 vòng build-test mới phát hiện ra.

**Rủi ro còn lại đã đọc thấy nhưng CHƯA sửa** (chưa có bằng chứng bắt buộc
phải sửa): `plugindir="$basedir/lib/mysql/plugin"` — truyền vào mariadbd
qua `--plugin-dir=`, nhưng KHÔNG có `cannot_find_file` nào kiểm tra thư mục
này tồn tại hay không trong toàn bộ script. Nhiều khả năng mariadbd chỉ
cảnh báo (không chết) nếu thư mục này rỗng/thiếu, vì storage engine lõi
(InnoDB/Aria) thường được biên dịch tĩnh, không cần nạp qua plugin. Chưa
bundle gì cho mục này - nếu vòng build tới lộ ra lỗi liên quan `plugindir`,
đó là việc cần làm tiếp theo, không phải bug ở đây.

## 1u. VƯỢT QUA toàn bộ vấn đề "tìm không thấy file" — mariadbd đã THỰC SỰ
CHẠY, lỗi giờ là lỗi linker chuẩn của Android, thiếu `libz.so.1`

Sau fix mục 1t, log xác nhận dòng **"Installing MariaDB/MySQL system tables
in ... ..."** xuất hiện — nghĩa là `mariadb-install-db` đã tìm đủ mọi file
cần thiết và THỰC SỰ gọi được `mariadbd --bootstrap`. Lỗi mới:
```
CANNOT LINK EXECUTABLE ".../mariadbd": library "libz.so.1" not found
```
Đây là thông báo gốc của chính **dynamic linker Android** (không phải lỗi
tự viết của script) — xác nhận `mariadbd` là binary ELF thật, linker Android
tự lo được (không cần lo vụ "linker riêng của Termux" như từng nghi ngờ ở
mục 1n/1o) — chỉ là thiếu 1 thư viện phụ thuộc.

**Nguyên nhân**: bước "Thu thap toan bo .so phu thuoc" trong `php.sh` dùng
`find -type f -name '*.so*'` — cờ `-type f` **loại bỏ symlink**. Trên
Linux, thư viện dùng chung thường có 2 lớp: file thật mang số hiệu đầy đủ
(`libz.so.1.3.1`) và 1 **symlink SONAME** ngắn hơn (`libz.so.1`) — đây mới
chính là tên mà các binary khác (như `mariadbd`) ghi trong mục "NEEDED" của
ELF header, và tên này bị `-type f` bỏ sót hoàn toàn.

**Đã sửa**:
1. `php.sh`: bắt cả symlink (`-type f -o -type l`). File nào tên không kết
   thúc bằng đúng `.so` (như `libz.so.1`) được đổi tên (thay `.` bằng `_`,
   thêm `.so`) để qua được `build-apk.yml` (chỉ nhận `*.so`) — đồng thời ghi
   lại ánh xạ "tên SONAME thật → tên đã đổi" vào `_supervisor/soname-map.txt`
   (đóng gói qua `www.zip` như `mariadb-share`).
2. `start-lamp.sh`: đọc `soname-map.txt`, tạo 1 thư mục ghi được riêng
   (`$RUNDIR/compat-libs`) chứa symlink **đúng tên SONAME gốc** trỏ về file
   đã đổi tên trong `nativeLibraryDir`, rồi đưa thư mục này lên **trước**
   trong `LD_LIBRARY_PATH` (`export LD_LIBRARY_PATH="$COMPAT_DIR:$BIN"`) —
   linker sẽ gặp đúng tên nó cần trước khi tìm ở `nativeLibraryDir`. Áp dụng
   chung cho MỌI binary trong script (không riêng mariadbd), vì nginx/php-fpm
   nhiều khả năng cũng phụ thuộc các thư viện dạng SONAME tương tự, chỉ là
   chưa chạy tới để lộ ra.

**CHƯA xác nhận đã đủ** — rất có thể còn NHIỀU thư viện SONAME khác cũng bị
thiếu tương tự (openssl, pcre2...) mà mariadbd cần tuần tự — nếu log tới còn
báo "library X not found" cho thư viện KHÁC, đó là điều fix này nhắm tới xử
lý được luôn (không cần sửa thêm gì, vì cơ chế đã tổng quát cho MỌI thư viện
SONAME dạng này) — chỉ cần xác nhận qua log thật.

## 1v. Fix mục 1u vô tình làm APK phình to gấp rưỡi (94MB → 161MB), gây lại
lỗi "Ứng dụng chưa được cài đặt" — đã sửa bằng khử trùng lặp theo nội dung
thật

Ngay sau fix mục 1u (bắt thêm symlink khi gom `.so`), người dùng build lại
và gặp lại đúng lỗi cài đặt kiểu mục 1m: "Ứng dụng chưa được cài đặt", file
zip tăng từ 94MB lên **161MB** chỉ sau đúng 1 lần sửa.

**Nguyên nhân (tự phát hiện khi soát lại code, có mô phỏng xác nhận)**: 1
thư viện dùng chung thường có CẢ CHUỖI symlink cùng trỏ về 1 file vật lý
duy nhất (ví dụ `libicudata.so` → `libicudata.so.75` → `libicudata.so.75.1`
— 3 TÊN khác nhau, CÙNG 1 NỘI DUNG). Code ở mục 1u copy theo TỪNG TÊN
(basename) riêng biệt mà không kiểm tra xem nội dung đã copy chưa — `cp`
mặc định đi theo symlink để lấy nội dung, nên mỗi tên khác nhau tạo ra 1
**bản copy đầy đủ riêng**. Với các file lớn (đặc biệt `libicudata` của PHP,
thường vài chục MB), nhân 2-3 lần là đủ giải thích mức tăng quan sát được.

**Đã sửa**: khử trùng lặp bằng đường dẫn THẬT (`readlink -f`, quy về đúng 1
file vật lý duy nhất bất kể qua bao nhiêu lớp symlink) — dùng mảng kết hợp
bash (`declare -A REALPATH_SEEN`) để nhớ nội dung nào đã copy rồi. Nếu 1 nội
dung đã có bản copy (dưới BẤT KỲ tên nào), các tên khác trỏ tới CÙNG nội
dung đó chỉ ghi thêm 1 dòng vào `soname-map.txt` (để `start-lamp.sh` vẫn tạo
đủ symlink cho MỌI tên SONAME mà binary khác có thể cần), không copy lại.
Đã mô phỏng bằng dữ liệu giả (1 file "nặng" 1MB với 3 tên symlink trỏ vào)
để xác nhận: chỉ 1 bản copy trong thư mục ra, đủ cả 3 dòng ánh xạ trong
`soname-map.txt` — đúng như thiết kế.

**Bài học cho các vòng sau**: khi thêm logic quét/copy file theo pattern
rộng (`find ... | cp`), luôn tự hỏi "các kết quả tìm được có thể trỏ chung 1
nội dung không" trước khi copy hàng loạt - đặc biệt với symlink, vốn RẤT
phổ biến trong cách đóng gói thư viện `.so` chuẩn Linux.

## 1w. MariaDB đã HOÀN TẤT (toàn bộ chuỗi lỗi mục 1k-1v xong) — vấn đề MỚI:
`php-fpm` không lên, chưa có cách xem log thật vì app thiếu tab UI

Log xác nhận: `mariadb-install-db` chạy xong, in "OK", tạo được
database/user `wordpress`, `mariadbd` (qua `wake-mariadb.sh`) khởi động
được bình thường (thấy "Cho MariaDB san sang..." qua mà không báo lỗi). Coi
như **toàn bộ chuỗi vấn đề MariaDB (mục 1k → 1v) đã giải quyết xong hoàn
toàn** - không cần quay lại các mục đó nữa trừ khi có bằng chứng MỚI cho
thấy MariaDB tự nhiên lỗi lại.

Vấn đề tiếp theo: `php-fpm` không mở được socket sau 20s. Người dùng thử
xem `php-fpm.log` và `php-fpm-stdout.log` qua "Xem log" trong app, cả 2 đều
báo "(chưa có file này...)" — **đọc code Kotlin xác nhận đây là hiện tượng
THẬT, không phải app lỗi**: `LogViewerActivity.kt` chỉ có 7 tab cố định
(`start-lamp-stdout.log`, `nginx-error.log`, `nginx-access.log`,
`php-fpm.log`, `php-error.log`, `mysqld.log`, `mysql-install.log`) —
**KHÔNG có tab nào cho `php-fpm-stdout.log`** (file mà `start-lamp.sh` tự
redirect stdout/stderr của tiến trình `php-fpm` vào, dòng lệnh khởi động
php-fpm) - dù file này chắc chắn được tạo ra bởi chính redirect của shell,
người dùng KHÔNG CÓ CÁCH nào xem nó qua UI hiện tại. `php-fpm.log` (tab có
sẵn) trống/không tồn tại vì đây là file do CHÍNH php-fpm tự mở sau khi khởi
động xong phần lõi - nếu nó chết sớm (rất có thể ở bước dynamic linking,
cùng loại lỗi với mariadbd ở mục 1u trước khi được sửa), nó chưa kịp mở file
này.

**Đã sửa** (`start-lamp.sh`): khi timeout 20s xảy ra, in THẲNG toàn bộ nội
dung `php-fpm-stdout.log` VÀ `php-fpm.log` vào log chính
(`start-lamp-stdout.log`, tab đầu tiên ai cũng biết xem) qua các lệnh `log`,
kèm cho biết php-fpm còn sống hay đã chết tại thời điểm timeout. Không cần
thêm tab mới trong app (đỡ phải sửa Kotlin + rebuild thêm 1 vòng) — chỉ cần
người dùng xem lại đúng log chính như mọi lần.

**Nghi ngờ hàng đầu** (chưa xác nhận, sẽ biết ngay ở log tới): `libphpfpm.so`
gặp cùng loại lỗi thiếu thư viện dùng chung như mariadbd từng gặp ở mục 1u
(trước khi có `compat-libs`) — nhưng php-fpm có RẤT NHIỀU phụ thuộc hơn
(openssl, libxml2, icu, curl, gmp, ffi, zip, xslt, tidy...), khả năng có 1
thư viện nào đó vẫn chưa được `soname-map.txt` phủ tới (dù cơ chế đã tổng
quát hoá ở mục 1v, không loại trừ 1 truong hợp đặc biệt nào đó, ví dụ
thư viện có 4-5 lớp symlink thay vì 2-3, hoặc 1 extension .so nao cua PHP tu
rieng dyn-load them thu vien khac ma khong qua buoc thu thap chinh).

## 1x. Fix mục 1w phát huy tác dụng ngay lập tức — lộ ra chính xác nguyên
nhân `php-fpm` chết: thiếu `libnghttp3.so` (phụ thuộc gián tiếp của
`libcurl` chưa từng được tải)

Nhờ log chính giờ in thẳng nội dung `php-fpm-stdout.log`, lỗi lộ ra ngay
trong lần build tiếp theo, không cần hỏi thêm:
```
CANNOT LINK EXECUTABLE "libphpfpm.so": library "libnghttp3.so" not found
```

**Nguyên nhân xác nhận bằng đọc code**: `termux_fetch.sh` tự ghi rõ trong
chú thích của chính nó (dòng 45): cơ chế tải phụ thuộc chỉ đi **1 cấp**
(Depends của gói CHÍNH, không đệ quy vào Depends của từng gói phụ thuộc).
`php` có `libcurl` là 1 Depends trực tiếp, `libcurl` được tải về, nhưng
**Depends CỦA `libcurl`** (openssl, libnghttp2, libnghttp3, libngtcp2,
libssh2, zlib) thì KHÔNG được tải, vì đã đi quá 1 cấp. `openssl`/`zlib` vẫn
có sẵn (do nginx/mariadb/php đều khai Depends thẳng), nhưng
`libnghttp2`/`libnghttp3`/`libngtcp2`/`libssh2` thì chưa từng được tải bao
giờ.

**Xác nhận bằng cách tra ĐÚNG mã nguồn `build.sh` thật của gói `libcurl`
trên kho chính thức Termux** (`github.com/termux/termux-packages`, nhánh
`master`) — không đoán:
```
TERMUX_PKG_DEPENDS="libnghttp2, libnghttp3, libngtcp2, libssh2, openssl (>= 1:3.2.1-1), zlib"
```
Khớp đúng 100% với lỗi thật gặp phải.

**Đã sửa** (`php.sh`): thêm 4 gói `libnghttp2 libnghttp3 libngtcp2 libssh2`
làm tham số phụ (`extra_deps`) khi gọi `termux_download_with_deps php ...`
— đúng cơ chế mà chính `termux_fetch.sh` đã thiết kế sẵn cho tình huống
này (`TERMUX_EXTRA_DEPS`, xem chú thích đầu file).

**CHƯA xác nhận đây đã đủ** — 4 gói này CÓ THỂ tự chúng cũng có Depends
riêng (vd `libssh2` cần openssl/zlib - đã có sẵn nên không sao; `libngtcp2`
có thể cần 1 gói "crypto backend" riêng nếu Termux đóng gói tách rời) mà
mình chưa tra tới nơi tới chốn do giới hạn thời gian - nếu log tới vẫn báo
thiếu thư viện (dù chắc chắn sẽ là thư viện KHÁC, không còn là
`libnghttp3` nữa), đó là hướng cần tra tiếp, cùng 1 phương pháp: tìm đúng
`build.sh` thật của gói tương ứng trên kho Termux, không đoán.

## 1y. Hết lỗi `libnghttp3` — lộ ra 2 vấn đề trong `php.ini.template`: 8
dòng `extension=` vô ích (chỉ gây warning) + `opcache` gây FATAL CRASH thật
do đường dẫn cứng kiểu Termux

Sau fix mục 1x, `php-fpm` không còn chết vì thiếu `.so` phụ thuộc của chính
nó nữa, nhưng vẫn chết trong vòng 20s. Log (nhờ tính năng in trực tiếp ở
mục 1w) cho thấy:
- 8 dòng cảnh báo (`Warning`, không fatal) "Unable to load dynamic
  library" cho `mysqli.so, pdo_mysql.so, mbstring.so, json.so, openssl.so,
  curl.so, zip.so, gd.so`, `opcache.so` (Zend extension).
- 1 dòng **Fatal Error** thực sự làm chết tiến trình:
  `Unable to create opcache lock file in /data/data/com.termux/files/usr/tmp:
  No such file or directory (2)`.

**Nguyên nhân (tra cứu lịch sử build.sh của gói `php` trên Termux, nhiều
phiên bản qua nhiều năm đều nhất quán)**: các extension này được biên dịch
**TĨNH thẳng vào binary `php`/`php-fpm`** (cấu hình kiểu `--enable-mbstring`,
`--with-curl=...`, `--with-mysqli=mysqlnd` — không có `=shared`), KHÔNG tồn
tại dưới dạng file `.so` riêng lẻ nào để mà nạp. `php.ini.template` (viết từ
trước, xem mục 1e) có sẵn 8 dòng `extension = xxx.so` với đúng 1 dòng chú
thích tự nghi ngờ: "opcache CÓ THỂ đã đóng gói tĩnh sẵn, nếu vậy dòng
`zend_extension` sẽ chỉ gây warning vô hại" — **bằng chứng thật xác nhận
ĐÚNG một nửa** (opcache đúng là đóng gói tĩnh sẵn) **nhưng SAI nửa còn lại**
(không phải "warning vô hại" — opcache tĩnh sẵn đó tự động kích hoạt theo
`opcache.enable`, và bên trong nó tự tạo file khóa tại 1 đường dẫn Termux
đóng cứng, không tồn tại trên máy này — giống hệt kiểu lỗi đường dẫn cứng
đã gặp với `mariadbd` ở mục 1t, nhưng lần này KHÔNG có tham số nào như
`--basedir` để trỏ hướng khác — opcache tự quyết định đường dẫn này nội bộ).

**Đã sửa** (`php.ini.template`):
1. Xoá 8 dòng `extension = xxx.so` — không tồn tại file để nạp, dòng này
   chỉ sinh warning vô ích, chức năng tương ứng (kết nối MySQL, mbstring,
   json, curl...) **vẫn hoạt động bình thường** vì đã nằm sẵn trong binary,
   không mất gì khi xoá dòng cấu hình sai kỳ vọng này.
2. Tắt hẳn opcache (`opcache.enable = 0`, bỏ dòng `zend_extension =
   opcache.so` vì cũng vô ích tương tự) — mất lợi ích tăng tốc biên dịch lại
   bytecode mỗi request, nhưng website vẫn chạy đúng, chỉ chậm hơn 1 chút.
   Ưu tiên chạy được trước, tối ưu hiệu năng sau (có thể quay lại bật opcache
   sau này NẾU tìm được cách cấu hình đường dẫn lock file của nó, nhưng
   opcache không có tuỳ chọn php.ini nào cho việc này ở mức hiểu biết hiện
   tại).

**Bài học cho các vòng sau**: 1 dòng comment "CHƯA verify" tự nghi ngờ trong
code cũ, khi bằng chứng thật xuất hiện, có thể ĐÚNG MỘT PHẦN và SAI MỘT
PHẦN cùng lúc — không nên coi "đã từng nghi ngờ đúng hướng" là bằng chứng đủ
để yên tâm, vẫn cần đọc kỹ nội dung lỗi thật đến cùng.

## 1z. 🎉 CỘT MỐC LỚN: Toàn bộ stack (MariaDB + php-fpm + nginx) chạy được,
trang quản trị load thành công — thêm tính năng copy/đổi mật khẩu

Sau fix mục 1y, người dùng xác nhận: **trang quản trị load được**. Đây là
lần đầu tiên toàn bộ chuỗi khởi động (MariaDB init → php-fpm → nginx) chạy
trót lọt từ đầu đến cuối. Coi như xong phần "làm cho chạy được" — từ đây về
sau là polish/tính năng, không còn là debug loop nữa (trừ khi phát sinh lỗi
MỚI, thật, có bằng chứng).

**Phản hồi UX từ người dùng dẫn tới 2 việc sửa/thêm:**

1. **"Nhấn vào không copy được mật khẩu, phải gõ từng chữ"** — nguyên nhân:
   `tvAdminPassword` (màn hình chính) dựa vào `textIsSelectable` (long-press
   để chọn+copy), nhưng chính TextView này bị code tự **ghi đè text mỗi 1
   giây** (vòng lặp cập nhật trạng thái server) — hủy mất vùng đã chọn NGAY
   GIỮA lúc người dùng thao tác copy. Đã thêm 1 nút "Sao chép" riêng
   (`btnCopyAdminPassword`), copy thẳng bằng code (`ClipboardManager`),
   không phụ thuộc trạng thái chọn text nào cả.

2. **"Sao chỉ có 1 mật khẩu, không phải tài khoản/mật khẩu phân quyền?"** —
   đây là ĐÚNG THIẾT KẾ, không phải thiếu sót: trang `_admin/` (File
   Manager, cài WordPress, xem log server) là bộ công cụ QUẢN LÝ MÁY, dành
   cho ĐÚNG 1 người (chủ điện thoại) — giống mô hình mật khẩu router/NAS gia
   đình, không phải hệ quản trị nội dung nhiều người dùng. **WordPress**
   (sau khi cài qua chính trang này) có HỆ TÀI KHOẢN/PHÂN QUYỀN ĐẦY ĐỦ
   riêng của nó (Administrator/Editor/Author/Subscriber...), đăng nhập ở
   `/wp-admin` — đó mới là nơi quản lý nhiều người dùng cho NỘI DUNG website.
   2 hệ thống hoàn toàn tách biệt, dùng đúng mục đích của mỗi bên. Đã bổ
   sung câu giải thích ngắn vào `hint_admin_tools` (string hiển thị ngay
   trong app) để người dùng sau không thắc mắc lại.

3. **"Mật khẩu có đổi được không?"** — trước đây KHÔNG có cách nào đổi
   ngoài việc tự vào xoá file `admin-password.txt` qua máy tính (không có
   UI). Đã thêm nút "Đổi mật khẩu quản trị" trên màn hình chính, mở hộp
   thoại cho nhập mật khẩu mới (≥6 ký tự) hoặc bấm "Sinh ngẫu nhiên". Ghi đè
   thẳng vào `admin-password.txt` — `_admin/auth.php` đọc file này MỖI LẦN
   có request (không cache), nên đổi xong áp dụng NGAY, không cần khởi động
   lại server. Phiên đăng nhập CŨ (session PHP) vẫn còn hiệu lực cho tới khi
   hết hạn/xoá cookie trình duyệt — giới hạn bình thường của cơ chế session,
   không phải lỗi.

**Chưa build-test tính năng mới này trên máy thật** (chỉ soát code +
kiểm tra cân bằng ngoặc, không có Android SDK ở đây) — cần người dùng build
+ test xác nhận UI hiển thị đúng và luồng đổi mật khẩu hoạt động như mô tả.

## 1aa. Làm rõ các lớp "quyền" thật sự trong hệ thống (người dùng hỏi) + tiện
phát hiện và sửa Adminer đang tải lỗi 404

Người dùng hỏi đúng hướng: "quyền trên server" là 1 lớp KHÁC hẳn quyền
WordPress, không phải cùng 1 thứ. Rà lại code xác nhận hệ thống này thực ra
có **3 lớp** riêng biệt, không phải 2:

1. **Mật khẩu quản trị** (`admin-password.txt`, mục 1z) — gác cổng vào
   TOÀN BỘ `_admin/` (File Manager, Adminer, cài WordPress, xem log). Ai có
   mật khẩu này = có thể sờ vào MỌI THỨ trên máy qua các công cụ đó.
2. **MariaDB** — có 2 tài khoản khác nhau, KHÔNG liên quan gì tới mật khẩu
   quản trị ở trên:
   - `root`: tạo với `--auth-root-authentication-method=normal` (xem
     `start-lamp.sh`) — nghĩa là **KHÔNG CÓ MẬT KHẨU** (theo đúng mô tả của
     chính `mariadb-install-db --help`: "tạo root login được mà không cần
     mật khẩu"). Ai vào được Adminer (tức đã qua lớp 1) và đăng nhập root =
     toàn quyền MỌI database, không riêng gì WordPress.
   - `wordpress`@`localhost`: tạo bằng `CREATE USER ... IDENTIFIED BY
     'wordpress'` — mật khẩu cố định là chuỗi "wordpress", nhưng
     `GRANT ALL PRIVILEGES ON wordpress.*` CHỈ trên đúng 1 database
     `wordpress`, không đụng được database khác. Đây là tài khoản
     `wp-config.php` dùng để kết nối, tách biệt hoàn toàn khỏi root.
3. **WordPress roles** (Administrator/Editor/Author/Subscriber...) — như đã
   nói ở mục 1z, đây là lớp riêng, ở TẦNG ỨNG DỤNG, quản lý ai được làm gì
   VỚI NỘI DUNG website, không liên quan gì tới quyền hệ thống/database ở
   trên.

Tóm lại: **lớp 1 (mật khẩu quản trị) và lớp 2 (MariaDB root không mật khẩu)
gộp lại gần như tương đương "toàn quyền trên máy"** — hiện tại chưa phân
tách chi tiết hơn nữa (không có khái niệm nhiều "tài khoản quản trị máy"
với quyền khác nhau) vì đây vẫn là công cụ 1-chủ-sở-hữu, không phải server
nhiều người quản trị.

**Phát hiện thêm lúc tra cứu** (không phải người dùng báo, tự thấy khi đọc
lại code liên quan): `_admin/db.php` (Adminer) tải từ URL GitHub Releases cũ
đang **404 thật** trong log build gần nhất (`vong lap trong log build da
thay "CANH BAO: khong tai duoc Adminer"` nhiều lần liên tiếp mà chưa ai để
ý vì không chặn build chính) — nghĩa là công cụ Adminer **không có mặt**
trong các bản build gần đây. Đã sửa `admin_tools.sh` đổi sang
`https://www.adminer.org/latest.php` (URL chính thức của adminer.org dành
riêng cho mục đích script tự động tải bản mới nhất, không đổi tên file theo
phiên bản như GitHub Releases) — CHƯA build-test xác nhận URL mới tải được.

## 1ab. Vòng phản hồi thứ 9: tham khảo phân tích của DeepSeek (file PDF người
dùng gửi) về tính năng còn thiếu so với hosting trả phí — đã LÀM NGAY 1 số
việc giá trị cao/rủi ro thấp, phần còn lại đưa vào mục 10 (backlog có tổ
chức)

Người dùng gửi 1 phân tích dài của DeepSeek (không phải Claude) liệt kê rất
nhiều tính năng "hosting trả phí có mà app chưa có". Đọc kỹ, tách làm 2:
việc LÀM ĐƯỢC NGAY bằng cách sửa code/config (rủi ro thấp, không cần chạy
thử phức tạp) và phần còn lại (cần code Kotlin/PHP mới, cần thiết bị thật để
test) đưa vào backlog ở mục 10.

**Đã sửa/thêm ngay (đọc code xong mới sửa, không đoán mù):**

1. **`--single-transaction --quick --lock-tables=false` cho `mysqldump`**
   (`BackupManager.kt`, đề xuất DeepSeek mục O4) — tránh khoá bảng làm site
   đứng hình lúc backup, tránh backup không nhất quán nếu có ghi dữ liệu
   đồng thời.
2. **Phát hiện + sửa 1 bug thật khi sửa mục trên**: `mysqldump` trước đây
   gọi với `LD_LIBRARY_PATH` KHÔNG có `compat-libs` (mục 1u/1v) — vì
   `mysqldump` cũng là binary ELF thật, rất có thể cần đúng các thư viện
   SONAME như `mariadbd`/`php-fpm` đã từng thiếu. Thiếu `compat-libs`,
   `mysqldump` có thể CHẾT NGAY khi chạy, lỗi bị nuốt âm thầm bởi
   `catch(Exception)`, hiển thị y hệt trường hợp bình thường "không có
   MariaDB" — nghĩa là **backup CSDL có thể đã từng âm thầm thất bại** mà
   không ai biết. Đã sửa dùng đúng `compat-libs` như `start-lamp.sh`.
3. **Hardening `wp-config.php.template` + bản SQLite** (đề xuất mục G1):
   `FS_METHOD='direct'` (tránh WordPress hỏi thông tin FTP không tồn tại khi
   update plugin/theme), `DISALLOW_FILE_EDIT` (chặn sửa file PHP qua
   wp-admin — chặn 1 vector tấn công phổ biến), `WP_AUTO_UPDATE_CORE='minor'`
   (tự vá lỗi bảo mật nhỏ).
4. **`php.ini.template`**: thêm `expose_php = Off` (ẩn version PHP khỏi
   header, đề xuất mục R4), `date.timezone = Asia/Ho_Chi_Minh` (tránh
   warning, dù WordPress tự ghi đè theo cài đặt riêng của nó).
5. **`nginx.conf.template`** (đề xuất mục G2/G3/R3):
   - Chặn `xmlrpc.php` (vector brute-force/DDoS phổ biến nhất của WordPress).
   - Rate-limit `wp-login.php` (`limit_req_zone` + `limit_req burst=3
     nodelay`) — chặn dò mật khẩu hàng loạt.
   - Security headers cơ bản: `X-Frame-Options`, `X-Content-Type-Options`,
     `Referrer-Policy` (KHÔNG thêm HSTS — xem chú thích trong file, lý do:
     chưa phân biệt được nguồn TLS thật (Cloudflare) với LAN thật, bật nhầm
     có thể làm hỏng truy cập LAN qua http:// thường).
   - Chặn file rác dạng `.bak/.old/.swp/.orig/.save` (có thể lộ mã nguồn/mật
     khẩu DB dạng văn bản thuần nếu ai đó vô tình để lại file sao lưu trong
     docroot).
6. **`start-lamp.sh`: thêm `trap` tắt sạch khi nhận SIGTERM/INT** (đề xuất
   mục O9) — **phát hiện 1 bug thật khi đọc code Kotlin**: nút "Tắt server"
   gọi `Process.destroy()`, lệnh này CHỈ gửi SIGTERM cho ĐÚNG 1 tiến trình
   `sh` bọc ngoài (tham chiếu trực tiếp Kotlin nắm giữ), KHÔNG tự động
   chuyển tiếp cho `mariadbd`/`php-fpm`/`nginx` chạy nền bên trong (hành vi
   Unix chuẩn — tín hiệu không tự lan sang tiến trình con). Không có `trap`,
   3 tiến trình con có thể trở thành tiến trình MỒ CÔI tiếp tục chạy ngầm
   dù giao diện đã báo "Tắt server" thành công — MariaDB bị bỏ rơi kiểu này
   có nguy cơ hỏng dữ liệu InnoDB nếu sau đó bị hệ điều hành SIGKILL. Đã
   thêm `trap` gửi `SIGTERM` sạch cho cả 3 + `wait` MariaDB flush xong trước
   khi thoát — dùng ĐÚNG cơ chế đã có sẵn cho riêng tính năng Auto-Sleep,
   giờ áp dụng cho MỌI trường hợp dừng server.

**Đã KIỂM TRA và xác nhận DeepSeek nêu SAI/THỪA (đọc code thấy đã có sẵn,
không cần sửa)** — quan trọng để không có ai làm lại nhầm:
- Mục O1 (`client_max_body_size` thiếu) — **SAI**, `nginx.conf.template` đã
  có `client_max_body_size 32m;` khớp đúng `post_max_size`/
  `upload_max_filesize` trong php.ini từ trước.
- Mục O2 (`memory_limit`/`max_execution_time` thiếu) — **SAI**, đã có sẵn
  (`memory_limit = 128M`, `max_execution_time = 60`).
- Mục O5 (charset/collation lệch) — **SAI**, `CREATE DATABASE ... CHARACTER
  SET utf8mb4` đã đúng từ `start-lamp.sh`, và để trống `DB_COLLATE` trong
  wp-config vốn dĩ là khuyến nghị CHÍNH THỨC của WordPress (để nó tự chọn
  collation phù hợp).
- Mục O7 (thiếu real IP qua Cloudflare) — **SAI**, đã có cơ chế phát hiện +
  bật module `realip` tự động từ trước (xem log thật: "nginx co modul
  realip - bat khoi phuc IP that").

**CHƯA build-test tất cả các thay đổi trên trên thiết bị thật** — chỉ soát
cú pháp (`sh -n`, đếm ngoặc Kotlin thủ công, không có `nginx -t` ở đây) — cần
người dùng build + test xác nhận, đặc biệt phần `nginx.conf.template` (sai
cú pháp nginx sẽ làm nginx từ chối khởi động HOÀN TOÀN, không phải lỗi im
lặng).

## 1ac. Tiếp tục backlog (mục 10) — CHỈ phần KHÔNG đụng `nginx.conf` (đang
chờ người dùng xác nhận batch mục 1ab an toàn trước khi sửa nginx thêm)

Người dùng chưa kịp build/test batch mục 1ab. Vì thay đổi `nginx.conf`
lần trước có rủi ro cao hơn (sai cú pháp = nginx từ chối khởi động HOÀN
TOÀN, không phải lỗi cục bộ như mọi lần trước), chủ động dừng sửa thêm
nginx cho tới khi có xác nhận — nhưng vẫn làm tiếp phần backlog KHÔNG đụng
tới nginx trong lúc chờ, để không lãng phí thời gian:

1. **Chống dò mật khẩu + audit log cho `_admin/`** (`admin-auth.php`, đề
   xuất mục A6/G4 ở mục 10): sai 5 lần từ cùng 1 IP → khoá tạm 15 phút.
   Dùng file JSON đơn giản (không cần thêm SQLite/DB) + `flock` cho an toàn
   khi có nhiều tab trình duyệt cùng lúc. Đăng nhập đúng thì xoá đếm sai của
   IP đó. Mọi lần thử (đúng/sai/bị khoá) đều ghi vào `admin-audit.log` —
   thêm file này vào **cả 2** nơi xem log (đã đồng bộ theo đúng comment sẵn
   có trong `LogViewerActivity.kt`): tab thứ 8 trong app VÀ mục mới trong
   `_admin/logs.php`.
2. **Kiểm tra dung lượng trống trước khi backup** (`BackupManager.kt`, đề
   xuất mục F7) — trước đây không kiểm tra gì, máy gần đầy có thể tạo ra
   file zip cụt mà không ai biết cho tới lúc cần khôi phục. Giờ ước lượng
   dung lượng cần (gấp đôi kích thước `www/` hiện tại, tối thiểu 10MB) và so
   với dung lượng trống thật (`StatFs`) — báo lỗi rõ ràng qua đúng đường
   Toast đã có sẵn nếu không đủ, thay vì để backup âm thầm hỏng.
3. **Phát hiện thêm 1 bug thật cùng loại** khi soát lại file để sửa mục
   trên: hàm `performRestore()` (khôi phục từ backup) CŨNG thiếu
   `compat-libs` giống hệt `mysqldump` ở mục 1ab (dùng `libmysqlcli.so` để
   nạp lại SQL) — nghĩa là **tính năng Khôi phục cũng có thể đã từng âm
   thầm thất bại phần database** (phần file vẫn khôi phục bình thường, chỉ
   riêng DB bị bỏ qua, đúng y hệt hành vi "không có MariaDB" bình thường nên
   không ai để ý). Đã sửa cùng lúc.

**Đã rà toàn bộ code Kotlin tìm lỗi CÙNG LOẠI** (`grep LD_LIBRARY_PATH`
xuyên suốt mọi file `.kt`) để chắc không sót thêm chỗ nào — 2 chỗ còn lại
(`ServerForegroundService.kt`) là nơi khởi động CHÍNH `start-lamp.sh`, đúng
thiết kế (`start-lamp.sh` tự tính `COMPAT_DIR` và tự export lại bên trong,
xem mục 1u) — không phải bug, không cần sửa.

**CHƯA build-test được cả 2 mục trên** — không có PHP/Kotlin compiler trong
môi trường này (`php -l` báo "not found", không cài được vì không có
mạng); chỉ soát cú pháp bằng đọc kỹ + đếm ngoặc thủ công. Cần người dùng
build + test xác nhận, đặc biệt luồng khoá IP (thử sai 5 lần xem có khoá
đúng 15 phút không) và audit log có hiện đúng trong "Xem log" (tab mới) hay
không.

## 1ad. Tiếp tục backlog (mục 10) — self-check HTTP thật + cảnh báo Telegram
(đề xuất DeepSeek mục A3), vẫn KHÔNG đụng `nginx.conf`

`HealthCheckWorker` (mục 1e) trước đây CHỈ kiểm tra "Foreground Service của
Android còn sống hay không" — KHÔNG biết website có thực sự TRẢ LỜI đúng
hay không (vd `php-fpm`/`nginx` bên trong bị treo nhưng tiến trình chính vẫn
còn) — đúng khoảng trống lớn nhất DeepSeek nêu ("server chết im lặng là
trải nghiệm tệ nhất").

**Đã thêm**: gọi HTTP thật tới `127.0.0.1:$currentPort` (KHÔNG qua
Cloudflare Tunnel — tránh nhầm lỗi mạng/tunnel với lỗi server thật) mỗi lần
`HealthCheckWorker` chạy (tối thiểu 15 phút/lần, giới hạn của
`PeriodicWorkRequest`). Coi là "không phản hồi" CHỈ khi kết nối thất bại/hết
giờ (nginx không lắng nghe, hoặc php-fpm treo không bao giờ trả lời) — BẤT
KỲ mã HTTP nào trả về được (kể cả 500/404) vẫn tính là "có phản hồi", vì đó
là lỗi tầng ứng dụng (WordPress/plugin lỗi), khác hẳn "server chết hẳn" mà
tính năng này nhắm cảnh báo. Đợi đủ 2 lần kiểm tra LIÊN TIẾP không phản hồi
(~30 phút) mới cảnh báo qua Telegram (nếu đã cấu hình) — đếm reset về 0 ngay
khi site phản hồi lại, và chỉ báo ĐÚNG 1 LẦN khi vừa chạm ngưỡng (không spam
lặp lại mỗi 15 phút sau đó).

**Cố tình KHÔNG thêm hành động tự sửa/restart nào ở đây** — cơ chế tự phục
hồi tiến trình con đã có sẵn từ trước (`runSiteLoop`/`runTunnelLoop`, xem
mục 8) — tính năng mới này chỉ BÁO CHO BIẾT khi cơ chế đó không hiệu quả,
tránh chồng chéo/xung đột với logic tự phục hồi đã hoạt động ổn định.

**CHƯA build-test** (không có Android SDK/emulator ở đây) — cần người dùng
xác nhận: (1) worker không làm gì bất thường khi Telegram chưa cấu hình
(phải im lặng bỏ qua, không lỗi), (2) khi ngắt hẳn php-fpm/nginx thủ công có
nhận được cảnh báo sau ~30 phút hay không.

## 1ae. Tiếp tục backlog (mục 10) 1 mạch, không dừng hỏi giữa chừng — WP-Cron
thật + rotation log, vẫn KHÔNG đụng `nginx.conf`

Theo đúng yêu cầu người dùng ("làm tiếp phần dang dở, đừng nhảy việc") — làm
liền 1 lượt, không dừng lại xin xác nhận sau mỗi việc nhỏ:

1. **WP-Cron thật** (`start-lamp.sh`, đề xuất mục F2): WordPress mặc định
   chỉ chạy "cron" khi CÓ KHÁCH TRUY CẬP — site ít khách sẽ không tự đăng
   bài lên lịch, plugin backup/dọn dẹp không tự chạy đúng giờ. Thêm gọi
   `wp-cron.php` qua HTTP mỗi ~5 phút (100 vòng lặp giám sát × `sleep 3`) —
   dùng PHP CLI (`libphpcli.so` đã có sẵn) để tự gọi `file_get_contents()`,
   KHÔNG dùng lệnh `curl` (chương trình dòng lệnh này KHÔNG được đóng gói
   riêng — chỉ có thư viện `libcurl` bên trong PHP, xem mục 1x). Chỉ chạy
   nếu `DOCROOT` có `wp-cron.php` (tức site WordPress).
2. **Rotation log đơn giản** (`start-lamp.sh`, đề xuất mục F1): log
   nginx/php/mariadb trước đây chỉ giảm TẦN SUẤT ghi (`buffer=`/`flush=`,
   mục 1e), không giới hạn KÍCH THƯỚC — sẽ phình vô hạn qua nhiều tháng.
   Giờ kiểm tra mỗi ~1 giờ (1200 vòng lặp), cắt sạch (`: > file`, giữ đúng 1
   bản hiện tại, KHÔNG làm GFS retention đầy đủ — quá phức tạp cho công cụ
   1-người-dùng) file nào vượt 5MB. An toàn dù nginx/php-fpm/mariadbd đang
   mở file để ghi (chế độ `O_APPEND` tự ghi tiếp từ vị trí 0 sau khi cắt,
   không cần gửi tín hiệu reload).
3. **Kiểm tra mục "che token trong log" (đề xuất G7) — KHÔNG thấy bằng
   chứng cần sửa**: rà toàn bộ `Log.w`/`Log.e` trong
   `TelegramNotifier.kt`/`TelegramCommandWorker.kt`, không có dòng nào in
   thẳng URL/bot token ra log — chỉ in mã lỗi HTTP hoặc thông báo chung
   chung. Đánh dấu mục này là ĐÃ KIỂM TRA, không phải vấn đề thật trong code
   hiện tại, gỡ khỏi backlog để không ai mất công tra lại.

**CHƯA build-test** (không có Android SDK/PHP CLI thật ở đây) — cần người
dùng xác nhận: (1) sau vài phút, thử tạo 1 bài viết WordPress "Lên lịch"
(scheduled) trong quá khứ gần, xem có tự đăng đúng giờ không (dấu hiệu
WP-Cron chạy); (2) log không bị mất đột ngột bất thường (dấu hiệu rotation
chạy sai).

## 1af. Tiếp tục backlog (mục 10) 1 mạch — 2FA (TOTP) đầy đủ cho `_admin/`,
vẫn KHÔNG đụng `nginx.conf`

Đề xuất mục A7. Đây là việc RỦI RO CAO HƠN các việc trước trong backlog —
nếu thuật toán TOTP sai, người dùng có thể **tự khoá luôn tài khoản quản
trị của mình** (khác các bug trước, chỉ làm mất 1 tính năng chứ không khoá
truy cập). Xử lý rủi ro này bằng 2 cách:

1. **Kiểm chứng thuật toán bằng Python TRƯỚC khi viết PHP** (không đoán):
   viết lại HOTP/TOTP (RFC 6238/4226: HMAC-SHA1 + dynamic truncation) bằng
   Python, chạy đối chiếu với CẢ 3 test vector chính thức trong RFC 6238
   Appendix B (T=59/1111111109/1111111111) — khớp 100%. Đối chiếu thêm phần
   giải mã base32 với `base64.b32decode` chuẩn của Python — cũng khớp. Sau
   đó mới chuyển dịch NGUYÊN VẸN logic đã xác nhận đúng sang PHP
   (`admin-totp-lib.php`) — không phải "viết PHP rồi hy vọng đúng".
2. **"Cửa thoát hiểm" ngay trong app Android**: nút "Tắt 2FA khẩn cấp"
   (`MainActivity.kt`, chỉ hiện khi 2FA đang bật) — xoá thẳng file cờ bật
   2FA bằng quyền ghi file của chính app, KHÔNG cần mật khẩu/mã TOTP nào cả.
   Đây là đường thoát DUY NHẤT nếu người dùng mất/hỏng điện thoại chứa app
   Authenticator — cầm được điện thoại chính (đã mở được app) là đủ tin
   cậy, không cần xác thực thêm.

**Luồng hoạt động**: bật qua `_admin/2fa.php` — sinh khoá bí mật, hiện dạng
văn bản (CHỦ Ý không tự vẽ mã QR — không có thư viện QR sẵn, và không muốn
gọi API ngoài để vẽ QR vì sẽ phải gửi khoá bí mật ra ngoài mạng, phản tác
dụng bảo mật; hầu hết app Authenticator hỗ trợ "nhập tay" khoá dạng text) —
CHỈ thực sự BẬT sau khi người dùng nhập đúng 1 mã 6 số từ app Authenticator
để xác nhận đã cài đúng (tránh bật nhầm với khoá gõ sai). Từ đó, đăng nhập
`_admin/` cần đủ 2 bước: mật khẩu đúng → rồi mới hỏi mã 6 số. Mã TOTP sai
dùng CHUNG cơ chế khoá IP tạm 15 phút với mật khẩu sai (mục 1ac) — không
làm bộ đếm riêng.

**CHƯA build-test được với 1 app Authenticator THẬT** (không có
Android/thiết bị ở đây) — dù thuật toán đã kiểm chứng đúng chuẩn RFC, vẫn
cần người dùng tự bật thử và xác nhận Google Authenticator/Authy chấp nhận
đúng mã. Nếu mã không khớp lúc test thật, khả năng cao nhất là **lệch giờ
giữa điện thoại và... chính điện thoại** (cùng 1 máy chạy cả server lẫn
app Authenticator, nên khó lệch giờ thật, nhưng vẫn ghi chú phòng hờ) —
xem `$window` trong `wp_pocket_totp_verify()` (đang cho phép lệch ±30 giây).

## 1ag. Vòng phản hồi thứ 10: đọc lại TOÀN BỘ code (không chỉ đọc HANDOFF) để
đối chiếu với chính file PDF DeepSeek gốc — phát hiện 2 bug thật KHÔNG nằm
trong PDF, cộng thêm 4 mục backlog (mục 10)

Yêu cầu lần này khác các vòng trước: không chỉ "làm tiếp backlog theo thứ
tự", mà **đọc lại toàn bộ mã nguồn thật** (không chỉ tin vào HANDOFF.md) để
tự kiểm tra xem còn thiếu gì so với PDF hay không. Cách làm này lộ ra 2 bug
thật mà các vòng trước không phát hiện, vì chúng nằm NGOÀI phạm vi các đề
xuất PDF — chỉ lộ ra khi đọc kỹ luồng dữ liệu thật giữa các file.

### Bug thật #1 (phát hiện khi đọc code, không phải đề xuất PDF): `APP_HOME`
chưa từng được export ở chế độ Lite — TOÀN BỘ `_admin/` không dùng được

Mọi file `admin-*.php` (`auth.php`, `2fa.php`, `logs.php`, `install-wp.php`,
`wake-mariadb.php`, `activity-touch.php`...) đọc `getenv('APP_HOME')`. Biến
này TRƯỚC BẢN NÀY chỉ từng được đặt bằng 1 cách DUY NHẤT: dòng
`env[APP_HOME] = __FILESDIR__` trong `php-fpm.conf.template` — CHỈ áp dụng
cho tiến trình chạy QUA php-fpm. Ở chế độ Lite (`php -S` đơn lẻ, không có
php-fpm — xem mục 1e), KHÔNG có cơ chế nào đặt biến này: `DATA="$HOME"`
trong `start-lamp.sh` là 1 biến shell CỤC BỘ, không "export", nên KHÔNG được
tiến trình con kế thừa.

**Hậu quả THẬT** (kiểm chứng bằng `php -S` + `getenv()` thật, không đọc code
suông): `getenv('APP_HOME')` luôn trả `false` ở chế độ Lite →
`admin-auth.php` luôn trả lỗi 500 "Chưa có mật khẩu quản trị" (vì
`$passwordFile` thành `null`) → **toàn bộ trang quản trị (File Manager, cài
WordPress, xem log, 2FA...) không dùng được MỘT CHÚT NÀO ở chế độ Lite**, dù
bản thân các trang đó hoàn toàn đúng. Đây là bug tồn tại từ mục 1e (lúc Lite
mode ra đời) tới giờ, không ai phát hiện vì các vòng test trước chỉ test
riêng lẻ từng trang qua chế độ Full.

Sửa: `export APP_HOME="$DATA"` ngay đầu `start-lamp.sh`, dùng chung cho cả 2
chế độ (ở chế độ Full, dòng `env[APP_HOME]` trong `php-fpm.conf.template`
VẪN GIỮ NGUYÊN — không thừa, vì php-fpm không tự kế thừa biến môi trường
shell theo mặc định nên vẫn cần dòng đó riêng; ở chế độ Lite, biến export
mới là thứ DUY NHẤT giải quyết vấn đề, vì `php -S` (CLI SAPI) có kế thừa
biến môi trường tiến trình cha bình thường). Đã kiểm chứng đúng bằng
`php -S` thật với `export`/`getenv()` thật, không giả định.

### Đề xuất A8 (chế độ bảo trì 1 nút) — và bug thật #2 phát hiện TRONG LÚC
làm A8: `open_file_cache` làm trễ tới 60 giây

Bật/tắt qua `_admin/maintenance.php` (form POST, cùng khuôn mẫu
`admin-2fa.php`), tạo/xoá file cờ `$RUNDIR/maintenance-mode`. Cả
`nginx.conf.template` (chế độ Full) lẫn `router-lite.php` (chế độ Lite) đều
kiểm tra file này, bỏ qua `/_admin/` để chủ site luôn vào được.

Test HÀNH VI THẬT (không chỉ `nginx -t`) bằng `nginx`/`php -S` cài qua `apt`
trong máy build này thì phát hiện: **bật cờ xong, `curl` vẫn thấy site bình
thường, không phải trang bảo trì** — dù cú pháp đúng 100% (`nginx -t` pass).
Cô lập bằng cách bisect dần từ 1 file `nginx.conf` tối giản (chỉ có đúng
logic if/set) cho tới khi thêm lại từng khối của file thật — thủ phạm là
khối `open_file_cache` (đã có sẵn TỪ TRƯỚC, không phải do bản này thêm vào):
`open_file_cache_errors on` + `open_file_cache_valid 60s` khiến nginx **dùng
lại kết quả kiểm tra `-f` CŨ tới 60 giây**, kể cả với đúng file vừa đổi.

Đã xác nhận lại với chính tác giả nginx (Igor Sysoev, nginx-ru mailing list,
2008): hỏi "`open_file_cache`/`open_file_cache_errors` có ảnh hưởng tới test
`-f`/`-d` trong `if` không?" → trả lời "Да" (Có) — xác nhận đây không phải
hiểu nhầm của tôi, mà là hành vi CHÍNH THỐNG của nginx, ít người để ý vì tên
gọi "open FILE cache" nghe như chỉ ảnh hưởng phục vụ file tĩnh.

**Quan trọng: bug này không chỉ ảnh hưởng maintenance-mode MỚI, mà ảnh hưởng
luôn cờ `mariadb-asleep` (Auto-Sleep) CÓ SẴN TỪ TRƯỚC** — cùng cơ chế
`if (-f ...)`. Auto-Sleep may mắn KHÔNG bị lộ ra trong thực tế vì nó chỉ
kích hoạt sau NHIỀU PHÚT không hoạt động (>> 60 giây), nên tới lúc có request
"đánh thức", cache chắc chắn đã hết hạn từ lâu — nhưng đây vẫn là 1 race
condition TIỀM ẨN (vd nếu sau này ai chỉnh thời gian Auto-Sleep xuống dưới
~90 giây, hoặc có request rơi đúng vào khung hẹp, sẽ gặp lỗi "Error
establishing a database connection" ngẫu nhiên, khó tái hiện).

Sửa (đã test LẠI CẢ 2 CHIỀU bật/tắt, có mô phỏng traffic thật — nhiều request
liên tục trước khi đổi trạng thái file, để tránh "may mắn" do
`open_file_cache_min_uses` chưa đạt ngưỡng):
- `open_file_cache_errors off` (thay vì `on`): không cache kết quả "không
  tìm thấy" nữa → chiều BẬT có hiệu lực NGAY LẬP TỨC (0 độ trễ).
- `open_file_cache_valid` giảm từ `60s` xuống `2s`: chiều TẮT (xoá file) vẫn
  bị cache (đây là kết quả "thành công", khác `errors` chỉ kiểm soát lỗi)
  nhưng giờ tối đa ~2 giây thay vì ~60 giây — đánh đổi hợp lý cho 1 site cá
  nhân lưu lượng thấp, gần như không mất gì về hiệu năng (vẫn giữ mở file
  descriptor 30 giây qua `inactive`, chỉ phần "kiểm tra lại mtime" thường
  xuyên hơn).

Test cuối: bật cờ → `curl` thấy 503 + trang bảo trì ngay lập tức; có traffic
liên tục rồi xoá cờ → tối đa ~2 giây sau `curl` thấy 200 trở lại. Test cả 2
chế độ (nginx thật cho Full, `php -S` thật cho Lite) — khớp nhau.

### Đề xuất A4/A5 (dashboard metrics nhẹ theo thời gian)

Ghi vào `$RUNDIR/metrics.csv` mỗi 100 vòng lặp giám sát (~5 phút, khớp nhịp
WP-Cron đã có) — CHỈ ở chế độ Full (vòng lặp giám sát không tồn tại ở Lite,
đúng tinh thần "Lite đổi lấy RAM thấp nhất có thể" đã ghi từ mục 1e, không
phải thiếu sót). Dùng `php -r` (kỹ thuật ĐÃ CHỨNG MINH, giống hệt WP-Cron)
đọc `/proc/meminfo` + `disk_free_space()`/`disk_total_space()` (hàm đã dùng
thật trong `_admin/index.php` từ trước) + `/proc/loadavg`, THAY VÌ tự parse
`df`/`awk` chưa kiểm chứng trên toolbox/toybox của Android. Cắt bớt (giữ
~2016 dòng ~ 7 ngày) gộp chung vào khối rotation log mỗi ~1 giờ đã có sẵn.

Trang xem `_admin/metrics.php`: đọc CSV, vẽ sparkline bằng `<svg><polyline>`
thuần PHP (KHÔNG Chart.js/JS ngoài, đúng tinh thần "không dùng
Prometheus/Grafana — quá nặng" đã ghi ở mục 10), có chọn khoảng 24h/3
ngày/7 ngày. Đã test render thật (`php -S` + CSV giả) — cả trường hợp có dữ
liệu lẫn chưa có dữ liệu (mới cài/chế độ Lite), không lỗi PHP runtime.

Card mới trong `_admin/index.php` (`admin_tools.sh`): "Chế độ bảo trì" (đổi
màu `highlight` + ghi "(ĐANG BẬT)" khi đang bật, cùng mẫu card `install-wp.php`
dùng) và "Thống kê theo thời gian". Đã test render cả 2 trạng thái.

### Đề xuất O10 (dọn socket/PID cũ khi khởi động)

Vòng trước CHỦ Ý hoãn vì "chưa có bằng chứng thật". Lần này làm luôn vì đây
là thao tác phòng thủ thuần tuý, không đổi hành vi nếu không có gì tồn tại
(`rm -f` im lặng bỏ qua) — khác các đề xuất suy đoán khác vẫn tiếp tục hoãn.
Thêm `rm -f "$MYSQL_SOCK" "$FPM_SOCK"` trước khi khởi động mariadbd/php-fpm.

### Đề xuất B1/B6 (backup ưu tiên lúc đang sạc) — tuỳ chọn, TẮT theo mặc định

`BackupWorker.kt` vốn ĐÃ có `setRequiresBatteryNotLow(true)` từ trước (1
phần B1 coi như đã làm mà backlog mục 10 ghi nhầm là "chưa làm" — bài học:
tin vào chính code, không tin mù vào tóm tắt backlog). Thêm MỚI 1 cờ RIÊNG,
tuỳ chọn, mặc định TẮT: `Prefs.KEY_BACKUP_REQUIRE_CHARGING` →
`BackupWorker.schedule(..., requireCharging)` → `.setRequiresCharging(...)`.
Mặc định tắt để không đổi hành vi cho người đã dùng backup tự động từ trước;
người dùng tự bật qua 1 công tắc mới trong app (`switchBackupRequireCharging`)
nếu muốn đánh đổi "chắc chắn có backup" lấy "an toàn pin/ổn định hơn" — đúng
tinh thần "User có option override" PDF đã ghi. CHƯA build-test được bằng
Android Studio thật (không có SDK ở đây) — đã rà soát chéo tên biến khớp
nhau ở mọi nơi (`Prefs.kt`/`BackupWorker.kt`/`WorkScheduler.kt`/
`MainActivity.kt`/layout XML/`strings.xml`) và kiểm tra XML hợp lệ bằng
`xmllint`, nhưng KHÔNG thay thế được việc build Gradle thật.

### Đã tra cứu, CHƯA implement: APCu

Backlog mục 10 ghi "CHƯA xác nhận Termux có đóng gói `php-apcu` hay không".
Tra cứu qua GitHub thấy repo `termux-packages` CÓ thư mục
`/packages/php-apcu/` (maintainer `@ian4hu`) — vậy package CÓ tồn tại. Ghi
nhận lại phát hiện này nhưng KHÔNG wire vào code: khác các thay đổi khác
trong vòng này (đều test được bằng nginx/php/sh thật ngay trong máy build),
việc file `.so` của APCu có LOAD ĐÚNG trên bản PHP Termux hay không là câu
hỏi CHỈ trả lời được trên thiết bị Android thật — thêm 1 dependency `.so`
mới mà không kiểm chứng được rủi ro thật sự (đúng tinh thần thận trọng với
extension `.so` đã ghi ở mục 7 "0c") cho 1 tính năng THUẦN TUÝ hiệu năng
(không sửa được bug/tính năng thiếu) không đáng đánh đổi trong vòng này.

### Việc CÒN LẠI trong backlog mục 10 (không đụng tới vòng này, lý do như cũ)

Battery/thermal/network-aware nâng cao hơn (B2/B3/B5/B7), staging/clone,
WP-CLI bundled, export/import site, Quick Settings Tile, Widget, notification
actions, QR code, onboarding wizard, multi-ABI build, test automation CI —
giữ nguyên trong backlog, công sức lớn hơn nhiều so với các việc đã làm ở
vòng này, để lần sau.

## 2. Trạng thái hiện tại

**CẬP NHẬT (mục 1k): người dùng ĐÃ build APK thật qua GitHub Actions VÀ cài
lên thiết bị Android thật** — dòng "Lần build Kotlin thật đầu tiên = khi
người dùng push lên GitHub" bên dưới KHÔNG còn đúng, đã xảy ra rồi. App chạy
được tới bước quyết định Dual-Mode + dò module nginx thật trên thiết bị thật
(bằng chứng: log thật, không phải suy luận), rồi dừng ở lỗi
`mariadb-install-db` — đã sửa (xem mục 1k), CHƯA có log build/chạy lại sau
fix để xác nhận đã hết lỗi. Coi đây là trạng thái mới nhất, không phải 2
dòng mô tả cũ bên dưới (giữ lại vì phần Kotlin/CI ở đó vẫn đúng).

Trước fix ở mục 1k, tình trạng là: viết xong, CHƯA build-test thật bằng
Android SDK/thiết bị Android (môi trường tạo ra project này không có Android
SDK / không truy cập được `dl.google.com`, `maven.google.com` nên không
compile-verify được phần Kotlin). Riêng phần **bash/PHP/nginx/php-fpm/mariadb**
(mục 1e-1i) ĐÃ được test bằng binary thật (cài qua `apt` trên Ubuntu x86,
không phải bản Termux ARM) — mức độ tin cậy khác nhau rõ rệt giữa 2 phần
này, xem từng mục 1e-1i để biết chính xác cái gì đã test bằng công cụ thật,
cái gì chỉ là suy luận theo tài liệu.

## 3. Kiến trúc

```
site.config.json (root, DUY NHẤT người dùng sửa)
        │
        ▼ (đọc bởi GitHub Actions)
.github/workflows/build-apk.yml
        │
        ├─▶ scripts/runtimes/{php,node,python,static}.sh   (chọn theo .runtime)
        │        ├─ scripts/lib/termux_fetch.sh   → tải binary từ kho Termux
        │        └─ scripts/lib/site_source.sh    → tải mã nguồn website
        │        └─ xuất: libruntimesrv.so + www.zip + runtime.json
        │
        ├─▶ scripts/prepare_cloudflared.sh          → libcfd.so (Go, static)
        │
        └─▶ gradle assembleDebug  → APK (upload artifact)

Trong app lúc chạy:
  ServerForegroundService (Foreground Service + WakeLock)
    ├─ prepareRuntimeIfNeeded(): giải nén www.zip lần đầu + ensureAdminPassword()
    │    (sinh mật khẩu quản trị ngẫu nhiên nếu chưa có, → filesDir/admin-password.txt)
    ├─ đọc assets/runtime.json → RuntimeConfig.kt → ProcessBuilder
    │    (KHÔNG biết đó là PHP/Node/Python — hoàn toàn generic. Với PHP:
    │    exec = /system/bin/sh start-lamp.sh → tự chạy mariadbd+php-fpm+nginx,
    │    trong đó nginx phục vụ cả website chính LẪN /_admin/ (Adminer +
    │    File Manager + Logs + Info, chỉ vào được qua LAN, xem mục 1c))
    └─ chạy song song libcfd.so → đọc SharedPrefs KEY_TUNNEL_TOKEN:
         ├─ có token  → `cloudflared tunnel run --token ...` (named, domain cố định)
         └─ không có  → `cloudflared tunnel --url ...` (Quick Tunnel, URL ngẫu nhiên)
```

**Nguyên tắc bất biến:** mọi thứ "biết" về backend cụ thể nằm ở
`scripts/runtimes/*.sh` (build-time, bash). App (Kotlin, runtime) tuyệt đối
generic — chỉ đọc `runtime.json`. Nếu sửa code mà thấy mình đang viết
`if (runtime == "php")` trong Kotlin → **sai hướng, dừng lại**.

**Lớp WorkManager (mục 1e/1h, độc lập vòng đời với `ServerForegroundService`
ở trên)** — chạy nền định kỳ, KHÔNG cần server đang bật hay app đang mở:
```
WorkScheduler.ensureScheduledFromPrefs() — gọi từ CẢ 2 nơi:
  MainActivity.onCreate() (mở app) VÀ ServerForegroundService.onCreate()
  (tự bật qua BootReceiver) — tránh lỗ hổng Android "Buộc dừng" huỷ hết job
    ├─ HealthCheckWorker (mỗi 15 phút): KEY_SERVER_WANTED=true nhưng
    │    isRunning=false → tự startForegroundService() lại (watchdog)
    ├─ BackupWorker (mỗi N giờ, nếu bật): BackupManager.performBackup()
    │    → TelegramNotifier.sendDocument() + WebhookUploader.uploadFile()
    │    (mỗi cái độc lập, chỉ chạy nếu đã cấu hình)
    └─ TelegramCommandWorker (mỗi 15 phút, nếu đã cấu hình Telegram):
         getUpdates() long-polling → /status /backup /restart
```

## 4. File map (chỉ những file quan trọng)

| File | Vai trò |
|---|---|
| `site.config.json` | Config DUY NHẤT: runtime, port, entry, site_source |
| `.github/workflows/build-apk.yml` | Pipeline CI — đọc config, dispatch, build |
| `scripts/lib/termux_fetch.sh` | Tải .deb từ kho Termux + walk `Depends` |
| `scripts/lib/site_source.sh` | Lấy mã nguồn theo `site_source.type` |
| `scripts/lib/admin_tools.sh` | Tải Adminer + Tiny File Manager, gắn `auth.php`, sinh `_admin/index.php` |
| `scripts/runtimes/*.sh` | 1 file/runtime — binary + `runtime.json` |
| `scripts/runtimes/templates/start-lamp.sh` | Supervisor 1 tiến trình chạy mariadbd+php-fpm+nginx (chỉ runtime `php`) |
| `scripts/runtimes/templates/*.template` | nginx.conf / php-fpm.conf / php.ini — có `__PLACEHOLDER__`, resolve lúc runtime bởi `start-lamp.sh` |
| `scripts/runtimes/templates/admin-*.php` | auth.php (cổng đăng nhập + IP-check, mục 1f), logs.php, info.php, **install-wp.php** (1-Click Installer, mục 1e), 2fa.php (mục 1af), **maintenance.php** + **metrics.php** (mới, mục 1ag) — công cụ quản trị tự viết |
| `scripts/runtimes/templates/router-lite.php` | Router cho `php -S` ở Dual-Mode PHP-Lite — mô phỏng pretty-permalink + chặn `_supervisor/`/`*.template` + mục 1ag: kiểm tra `maintenance-mode` |
| `scripts/prepare_cloudflared.sh` | Tải cloudflared (KHÔNG qua Termux) |
| `RuntimeConfig.kt` | Parse `runtime.json`, thay placeholder `${BIN} ${PORT} ${DOCROOT} ${FILESDIR}` |
| `Prefs.kt` | Key SharedPreferences: `KEY_AUTO_START`, `KEY_TUNNEL_TOKEN`, + mục 1e: `KEY_SERVER_WANTED`, `KEY_BACKUP_AUTO_ENABLED`, `KEY_BACKUP_INTERVAL_HOURS`, `KEY_TELEGRAM_BOT_TOKEN`, `KEY_TELEGRAM_CHAT_ID`, + mục 1f: `KEY_PHP_LITE_MODE`, + mục 1ag: `KEY_BACKUP_REQUIRE_CHARGING` |
| `BackupManager.kt` | **(mới, mục 1e)** Logic backup (zip + mysqldump) dùng chung cho nút bấm tay và `BackupWorker` |
| `BackupWorker.kt` | **(mới, mục 1e)** WorkManager — backup định kỳ tự động, gửi qua Telegram nếu đã cấu hình, + mục 1ag: tuỳ chọn `setRequiresCharging` |
| `HealthCheckWorker.kt` | **(mới, mục 1e)** WorkManager — watchdog định kỳ 15 phút, tự khởi động lại service nếu bị hệ thống giết chết dù người dùng vẫn muốn chạy |
| `TelegramNotifier.kt` | **(mới, mục 1e)** Gọi Telegram Bot API (`sendMessage`/`sendDocument`) bằng `HttpURLConnection` thuần |
| `WebhookUploader.kt` | **(mới, mục 1g)** Gửi backup qua HTTP POST tới URL bất kỳ (thay Google Drive OAuth — xem lý do mục 1g) |
| `TelegramCommandWorker.kt` | **(mới, mục 1h)** Long-polling `getUpdates` — điều khiển từ xa `/status /backup /restart` an toàn hơn webhook |
| `WorkScheduler.kt` | **(mới, mục 1i)** Gom logic đăng ký/huỷ WorkManager job theo Prefs — dùng chung `MainActivity` + `ServerForegroundService`, tránh lỗ hổng "Buộc dừng" |
| `ServerForegroundService.kt` | Chạy site process (generic) + tunnel process (quick/named tuỳ token) + `ensureAdminPassword()` + mục 1e: đặt `KEY_SERVER_WANTED`, đăng ký `HealthCheckWorker`, báo Telegram lúc có URL công khai |
| `MainActivity.kt` | UI: start/stop, IP LAN + URL public, auto-start, bỏ qua tối ưu pin, **backup ngay**, **mật khẩu quản trị + mở `/_admin/`**, **ô nhập token tunnel**, + mục 1e: **bật/tắt backup tự động + khoảng cách giờ + Telegram Bot Token/Chat ID** |

## 5. Kỹ thuật cốt lõi đã dùng (và LÝ DO — đừng tốn thời gian tìm lại)

- **Binary chạy như tiến trình con**: đặt tên `lib*.so` trong `jniLibs/<abi>/`
  → PackageManager tự copy vào `nativeLibraryDir` + cấp quyền thực thi, né
  W^X (Android 10+ chặn exec file tự giải nén ra thư mục ghi được).
  Cần `android:extractNativeLibs="true"` trong Manifest để có file thật trên
  đĩa cho `ProcessBuilder` (nếu để false, lib chạy trực tiếp từ zip APK qua
  mmap — không dùng được với ProcessBuilder).
- **Chạy nền khi tắt màn hình** = Foreground Service (`specialUse` type,
  Android 14+ bắt buộc khai báo `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`) +
  `PARTIAL_WAKE_LOCK` + notification cố định + `START_STICKY`. Đã xác nhận
  khả thi 100%, không phải giới hạn kỹ thuật — đừng nghi ngờ lại điểm này.
- **PHP runtime (mặc định `"runtime": "php"`)**: nginx + php-fpm + MariaDB
  thật, không phải `php -S` dev server nữa (đã nâng cấp — xem mục 1b).
  Cả 3 daemon được **1 script supervisor duy nhất**
  (`scripts/runtimes/templates/start-lamp.sh`, chạy qua `/system/bin/sh` có
  sẵn trên mọi Android) khởi chạy + giám sát, để `ServerForegroundService`
  vẫn chỉ cần `ProcessBuilder` MỘT tiến trình (giữ kiến trúc generic không
  đổi — xem mục 3). Config nginx/php-fpm/php.ini/wp-config.php là
  **template** (`__PLACEHOLDER__`), được `start-lamp.sh` `sed` thành giá trị
  thật lúc app chạy lần đầu trên THIẾT BỊ THẬT — vì đường dẫn
  (`nativeLibraryDir`, `filesDir`, socket path) chỉ biết được lúc đó, không
  biết được lúc CI build.
- **Node/Python/static** vẫn dùng cơ chế đơn giản cũ (1 binary, không
  nginx/php-fpm) — KHÔNG nâng cấp tương tự PHP, vì Node/Python thường tự có
  framework server riêng đủ dùng (Express, Django runserver...) khi có
  `entry`; trường hợp không có `entry` (Python fallback `http.server`) vẫn
  còn hạn chế tương tự `php -S` cũ nhưng ngoài phạm vi ưu tiên hiện tại.
- **PHP/Node/Python binary**: mượn từ kho gói mã nguồn mở Termux
  (`https://packages.termux.dev/apt/termux-main`, định dạng apt/.deb).
  Lý do: tự cross-compile bằng NDK tốn quá nhiều công cho scope này.
  → **Rủi ro đã biết**: binary build cho layout thư mục Termux
  (`$PREFIX=/data/data/com.termux/files/usr`), tách ra dùng riêng CÓ THỂ
  thiếu `.so` phụ thuộc gián tiếp. Đã giảm thiểu bằng: (a) tải cả
  `Depends` field của gói chính, (b) set `LD_LIBRARY_PATH=nativeLibraryDir`
  lúc exec. **CHƯA verify end-to-end.** Với nginx/php-fpm/mariadb, rủi ro
  này áp dụng cho CẢ 3 gói, không chỉ 1 — nhiều bề mặt lỗi hơn bản cũ.
- **cloudflared**: KHÔNG qua Termux — tải thẳng binary release chính thức
  (`cloudflared-linux-arm64`/`cloudflared-linux-arm` từ GitHub release của
  Cloudflare). Lý do: binary Go, nhiều khả năng static-linked, tránh hẳn vấn
  đề thiếu `.so` ở trên. 2 chế độ: **Quick Tunnel** mặc định (`tunnel --url
  ...`, không cần tài khoản, URL đổi mỗi lần chạy) hoặc **Named Tunnel** nếu
  người dùng lưu token trong app (`tunnel run --token ...`, domain cố định).
  Giải quyết CGNAT (đa số mạng di động/cáp quang hộ gia đình VN không có IP
  công khai) mà không cần port-forward.
- ~~SQLite Database Integration~~ — **ĐÃ THAY** bằng MariaDB thật (xem mục
  1b). Không dùng SQLite drop-in nữa cho runtime PHP **mặc định**. (Cập nhật
  mục 1f: SQLite CÓ quay lại, nhưng CHỈ làm phương án dự phòng cho Dual-Mode
  PHP-Lite trên máy quá yếu RAM — không phải mặc định, không mâu thuẫn quyết
  định ở mục 1b.)
- **Gradle wrapper KHÔNG commit vào repo** (tránh phải có sẵn
  `gradle-wrapper.jar` binary). CI dùng action `gradle/actions/setup-gradle@v4`
  cài Gradle trực tiếp, chạy `gradle assembleDebug` (không phải `./gradlew`).
  Mở bằng Android Studio local thì Android Studio tự sinh wrapper.

## 6. Đã cân nhắc và LOẠI BỎ (đừng đề xuất lại)

- ❌ **Termux làm runtime/app trung gian** — người dùng từ chối rõ ràng, chỉ
  dùng Termux làm *nguồn tải binary lúc build-time*, không chạy Termux app
  lúc runtime.
- ❌ **`static-php-cli` cho Android** — search không xác nhận có hỗ trợ
  target Android (chỉ thấy Linux/macOS/FreeBSD/Windows). Không dùng.
- ❌ **Nhiều website/multi-tenant chạy song song** — người dùng xác nhận chỉ
  cần 1 website tại 1 thời điểm.
- ❌ **Hardcode PHP trong Kotlin** — đã refactor bỏ hoàn toàn (xem mục 3).

## 7. Điểm nghẽn / rủi ro CHƯA giải quyết (làm tiếp từ đây)

**7.0. Phản hồi THẬT từ thiết bị thật (không phải mô phỏng nữa)**: người
dùng báo bấm "Bật server" chỉ hiện "đang khởi động" rồi im lìm, không upload
được file web, có backup mà không có restore, không có chỗ xem log trong
app. Suy luận từ code (KHÔNG phải đoán): `isRunning` được set `true` ngay
khi `ProcessBuilder.start()` thành công — tức LUÔN thành công (spawn
`/system/bin/sh` gần như không bao giờ lỗi ở tầng OS) — bất kể
nginx/php-fpm/mariadb bên trong `start-lamp.sh` có thực sự lên được hay
không. Nếu LAMP stack crash-loop ngầm (rất có thể — nhiều phần "chưa
verify trên thiết bị thật" ở mục 1e/8 giờ có khả năng đang xảy ra thật),
`admin-password.txt` không bao giờ được tạo → nút "Mở trang quản trị" (nơi
có Tiny File Manager để upload + 1-Click WordPress Installer) không bao giờ
dùng được → đúng y hệt "vỏ rỗng" mà người dùng mô tả, dù code các tính năng
đó vẫn tồn tại đầy đủ, chỉ là không chạm tới được.

Đã vá 3 việc để giải quyết TRỰC TIẾP các phản hồi trên:
1. **`LogViewerActivity.kt`** (màn hình mới) — xem log NGAY TRONG APP, đọc
   thẳng từ file trên đĩa (không qua web server) — công cụ chẩn đoán quan
   trọng nhất còn thiếu, vì trước đây log CHỈ xem được qua `_admin/logs.php`
   (web) hoặc `adb logcat` (cần máy tính) — cả 2 đều vô dụng đúng lúc cần
   nhất (server không lên được).
2. **Trạng thái 3 mức thay vì 2** (`ServerForegroundService.restartCount`/
   `lastErrorMessage` mới) — trước chỉ có "Đang chạy"/"Đã dừng", giờ thêm
   "⚠️ Không lên được (đã thử lại N lần)" khi đang crash-loop ngầm, kèm gợi
   ý bấm "Xem log".
3. **Restore** (`BackupManager.performRestore` + UI chọn file + dialog xác
   nhận trong `MainActivity`) — xác nhận trước đó ĐÚNG LÀ chưa từng tồn tại
   (grep toàn bộ project ra 0 kết quả cho "restore"), không phải người dùng
   tìm thiếu.

**CHƯA giải quyết** (cần chính log mới xem được ở #1 để biết đích xác): lý
do THẬT SỰ khiến LAMP stack không lên được trên thiết bị của người dùng này
cụ thể — có thể là bất kỳ rủi ro nào đã liệt kê ở mục 8 (thiếu `.so` từ
Termux, MariaDB lỗi trên ARM, php-fpm non-root...). Bước tiếp theo: người
dùng cài bản APK mới, bấm "Xem log", chọn tab "start-lamp.sh (tổng quan khởi
động)" trước tiên, dán nội dung lại để chẩn đoán tiếp.

**Mới phát sinh từ nâng cấp LAMP (mục 1b) — CHƯA verify, ưu tiên kiểm tra
ngay sau lần build đầu tiên nếu chọn `"runtime": "php"`:**

0a. **php-fpm chạy non-root** — pool config (`php-fpm.conf.template`) cố ý
    KHÔNG có `user =`/`group =` (thường bắt buộc nếu master process là
    root; ở đây process app vốn đã non-root nên bỏ qua). Termux tự bản thân
    cũng non-root và package `php-fpm` của họ chạy được — kỳ vọng hợp lý
    nhưng CHƯA test trực tiếp trên app này. Nếu php-fpm lỗi "unable to
    setuid" hoặc tương tự, đây là chỗ đầu tiên cần sửa
    (`scripts/runtimes/templates/php-fpm.conf.template`).
0a2. **Auto-Sleep (mục 1j) — thời gian thực tế MariaDB khởi động lại trên ARM
    di động chưa đo được**. `wake-mariadb.php` poll tối đa ~8s rồi rơi về
    trang chờ nếu chưa xong — nếu MariaDB thật sự mất lâu hơn trên phần cứng
    cụ thể nào đó, khách sẽ thấy vài lần refresh liên tiếp thay vì 1 lần như
    kỳ vọng (không phải lỗi, chỉ là trải nghiệm không tối ưu). Đo lại số này
    trên thiết bị thật rồi tinh chỉnh nếu cần.
0b. ~~`mariadb-install-db` trên Android...~~ **ĐÃ XẢY RA THẬT + ĐÃ SỬA ở mục
    1k** (vòng phản hồi thứ 8) — nguyên nhân thật KHÔNG phải TMPDIR như dòng
    này từng đoán, mà là thiếu hẳn `--basedir` (thư mục `share/mariadb` chưa
    từng được đóng gói vào APK). Đã thêm cả `--tmpdir` phòng ngừa theo đúng
    dòng này lúc sửa, nhưng chưa có bằng chứng riêng đó có phải nguyên nhân
    phụ hay không. Xem mục 1k, ĐỪNG đọc dòng gốc này như hướng dẫn sửa nữa.
0c. **extension .so của PHP** (`mysqli.so`, `pdo_mysql.so`, `mbstring.so`...)
    — `php.sh` copy TẤT CẢ file `.so` tìm thấy vào `nativeLibraryDir`, và
    `php.ini.template` set `extension_dir` trỏ đúng đó, nhưng CHƯA xác nhận
    Termux đóng gói các extension này ở đúng dạng `.so` rời (một số bản PHP
    build với extension tĩnh sẵn trong binary, khi đó dòng `extension=X.so`
    trong php.ini sẽ gây warning vô hại lúc khởi động, không phải lỗi
    nghiêm trọng — nhưng cần xem log `$HOME/lamp-run/php-fpm.log` để chắc).
0d. **RAM/CPU nặng hơn hẳn bản cũ** — 3 daemon (mariadbd + php-fpm + nginx)
    cùng lúc thay vì 1 tiến trình `php -S`. ~~Nếu app crash liên tục trên
    máy yếu, cân nhắc thêm biến thể "php-lite"~~ — **ĐÃ implement ở mục 1f
    (Dual-Mode PHP-Lite)**, không phải "chưa làm" như dòng này từng ghi —
    nếu thấy mâu thuẫn mục 1f thì tin mục 1f.

**Từ trước (chưa đổi):**

1. **[Ưu tiên cao] Chưa build-test thật lần nào.** Việc đầu tiên khi có môi
   trường thật (GitHub Actions hoặc máy có Android SDK): push repo, chạy
   workflow, đọc log lỗi.
2. **Binary Termux thiếu `.so`** (xem mục 5) — nếu gặp lỗi
   `cannot open shared object file` / `undefined symbol` trong
   `adb logcat`: tìm gói Termux chứa lib đó, thêm vào `extra_deps` khi gọi
   `termux_download_with_deps` trong `scripts/runtimes/<runtime>.sh` tương
   ứng. Nếu lặp lại nhiều lần không hết → chuyển "Kế hoạch B" (tự
   cross-compile bằng NDK, static-link) — xem README mục "Kế hoạch B", chưa
   implement, cần làm mới nếu tới bước này.
3. **cloudflared có thực sự static-linked không** — chưa xác nhận 100% qua
   search. Nếu binary lỗi thiếu `.so`, áp dụng cùng cơ chế
   `LD_LIBRARY_PATH` như binary khác (đã có sẵn trong code, chỉ cần thêm
   bước tải dependency nếu phát sinh).
4. **CI đã build-test thật trên GitHub Actions** (khác mọi phần khác của dự
   án — đây là phần DUY NHẤT đã chạy thật, không chỉ mô phỏng). Lịch sử thật
   (không phải giả định lúc viết code nữa):
   - `android-actions/setup-android@v3` **THẬT SỰ LỖI** trên CI thật (build
     #3, #8...): action này luôn cài cố định gói SDK `tools` bên trong bất
     kể input `packages:` là gì — gói này đã bị Google gỡ khỏi kho từ
     14-15/9/2026 (sự cố xảy ra đồng loạt trên rất nhiều repo không liên
     quan, không phải lỗi riêng của dự án này). **Đã gỡ bỏ action này khỏi
     `build-apk.yml`**, thay bằng dùng thẳng SDK có sẵn trên runner GitHub
     (theo đúng hướng dẫn chính thức của `actions/runner-images` issue
     #13469) — đã build qua được bước này thật.
   - Repo build thật của người dùng có cấu trúc đặc biệt: **chỉ lưu 1 file
     `.zip` nguồn ở gốc + `.github/workflows/`**, không checkin source trực
     tiếp kiểu git thông thường. `build-apk.yml` đã thêm bước "Giải nén file
     zip nguồn" ngay sau Checkout để tự tìm + giải nén + xử lý cả 2 trường
     hợp (zip có/không có 1 thư mục bọc ngoài) — đã kiểm thử bằng cách mô
     phỏng đúng kịch bản (thư mục trống + zip thật) trước khi giao, không
     chỉ đọc code.
   - `gradle/actions/setup-gradle@v4` và các version khác trong workflow —
     vẫn CHƯA gặp lỗi qua các lần build thật đã thấy, nhưng cũng chưa nghĩa
     là chắc chắn không có vấn đề gì (mới build tới bước Gradle setup, chưa
     có log build thành công hoàn chỉnh tới cuối cùng — xem file build log
     mới nhất trong lịch sử trò chuyện để biết đã build tới đâu).
5. **AGP 8.5.2 / Gradle 8.9 / Kotlin 1.9.24 / compileSdk 34** — tổ hợp version
   chọn theo kiến thức tại thời điểm viết (khớp nhau về lý thuyết), chưa
   verify build thật. Nếu lỗi version-mismatch, đây là chỗ sửa.
6. **Chưa có code signing cho bản RELEASE** — hiện tại `assembleDebug` (APK
   ký bằng debug keystore, cần bật "cài từ nguồn không xác định"; từ mục 1l
   debug keystore đã CỐ ĐỊNH giữa các lần build CI, không còn đổi ngẫu nhiên
   nữa, nhưng đây vẫn KHÔNG phải bản release/ký chính thức). Nếu người dùng
   cần bản release, thêm `signingConfigs.release` (keystore riêng, không
   dùng chung debug.keystore) vào `app/build.gradle.kts`.
7. ~~Quick Tunnel URL đổi mỗi lần restart~~ — **ĐÃ FIX ở mục 1b** (named
   tunnel qua token, KHÔNG phải "chưa implement" như bản HANDOFF cũ từng
   ghi nhầm ở đây — nếu thấy dòng này mâu thuẫn mục 1b thì tin mục 1b).
   Rủi ro THẬT còn lại: named tunnel cần người dùng tự tạo tunnel + lấy
   token trên dashboard Cloudflare (không thể tự động hoá thay họ), và
   luồng `cloudflared tunnel run --token` **chưa test thật** trên thiết bị
   — nếu lỗi, so sánh log `adb logcat | grep cloudflared` giữa 2 chế độ.
8. **Adminer / Tiny File Manager tải từ URL "latest"/"master" ngoài kiểm
   soát** (xem mục 1c) — nếu 2 project đó đổi cấu trúc file, cơ chế chèn
   `auth.php` (`inject_auth_guard`, hàm `sed` tắt `$use_auth`) có thể không
   khớp nữa. **Luôn kiểm tra thủ công** sau build: `/_admin/db.php` và
   `/_admin/files.php` phải hiện màn hình đăng nhập của `auth.php` trước,
   không phải giao diện Adminer/TFM ngay lập tức.

## 8. Việc KHÔNG cần làm lại (đã xong, đừng viết lại từ đầu)

- Đừng viết lại cơ chế Foreground Service / WakeLock / notification —
  `ServerForegroundService.kt` đã đúng pattern chuẩn Android.
  Chỉ sửa nếu có bug cụ thể.
- Đừng viết lại `RuntimeConfig.kt` / cơ chế placeholder — đã generic đúng
  yêu cầu "không hardcode".
  Thêm runtime mới = thêm file `scripts/runtimes/<ten>.sh` theo khuôn có
  sẵn (xem `php.sh` làm mẫu), KHÔNG sửa `.kt`.
- Đừng đề xuất lại Termux-as-app, static-php-cli, hay kiến trúc multi-site
  (đã bị loại ở mục 6, có lý do rõ ràng).
- Đừng đề xuất lại danh sách "cố ý không làm" **hiện còn hiệu lực** (đọc mục
  1e/1f/1g/1h để biết lý do đầy đủ trước khi đề xuất lại — DANH SÁCH DƯỚI ĐÂY
  LÀ BẢN CẬP NHẬT MỚI NHẤT, đừng tin danh sách cũ hơn nếu thấy mâu thuẫn):
  SQLite on-demand/dual DB switching (mục 1e — khác Dual-Mode PHP-Lite ở mục
  1f, đã LÀM), OverlayFS/symlink `wp-content/uploads` sang cacheDir (mục 1e —
  chỉ phần `uploads` bị từ chối, phần `wp-content/cache` ĐÃ làm an toàn ở mục
  1h), cluster nhiều điện thoại qua LAN (mục 1e), BusyBox thay web/database
  server (mục 1e), ZRAM hint qua `onTrimMemory` (mục 1e, có bằng chứng kernel
  ở mục 1h), Cloudflare Workers static mirror (mục 1e), Tailscale/ZeroTier
  (mục 1e), Google Sign-In/Drive API thật cho tới khi có code signing ổn định
  (mục 1g). **KHÔNG còn trong danh sách từ chối** (đã làm bằng cách khác an
  toàn hơn — đừng đề xuất lại nguyên bản gốc): Dual-Mode PHP-Lite (mục 1f),
  webhook Telegram 2 chiều (mục 1e từ chối bản webhook — đã thay bằng
  long-polling an toàn hơn ở mục 1h), "RAM Disk"/tmpfs cho log (mục 1e từ
  chối vì bất khả thi — đã thay bằng `access_log buffer=`/`flush=` ở mục 1h).
- Đừng viết lại `BackupManager.kt` (logic backup), `TelegramNotifier.kt`
  (gọi Telegram Bot API), `router-lite.php`, hay `WorkScheduler.kt` trừ khi
  có bug cụ thể — đều đã tách riêng đúng nguyên tắc "1 nơi, dùng chung".
  Riêng `router-lite.php`: đừng đổi lại dùng `__DIR__` thay vì
  `$_SERVER['DOCUMENT_ROOT']` — ĐÃ test thực tế xác nhận `__DIR__` SAI hoàn
  toàn ở đây (file nằm trong `_supervisor/`, không phải docroot) — xem mục
  1f.
- Đừng đề xuất lại Google Sign-In/Drive API "xịn" cho tới khi mục 7.6 (code
  signing) được giải quyết trước — lý do đầy đủ ở mục 1g.
- Đừng đề xuất lại "hint ZRAM qua onTrimMemory" — đã tra bằng chứng kernel
  xác nhận đây là giới hạn nền tảng thật (chỉ tiến trình có đặc quyền hệ
  thống mới gọi được `process_madvise` lên tiến trình khác), không phải do
  chưa tìm đúng API. Xem mục 1h.
- Đừng viết lại `access_log` trong `nginx.conf.template` mà bỏ mất tên
  format `combined` tường minh trước `buffer=`/`flush=` — ĐÃ test bằng
  `nginx -t` thật và xác nhận thiếu nó sẽ lỗi "unknown log format" (nginx
  hiểu nhầm `buffer=64k` là tên format). Xem mục 1h.

## 9. Việc tiếp theo cụ thể (đề xuất thứ tự)

**CẬP NHẬT (mục 1l): trước khi cài bản build MỚI NHẤT (sau fix keystore cố
định), phải GỠ CÀI ĐẶT bản "WP Pocket Server" đang có trên điện thoại 1 LẦN
DUY NHẤT** (Cài đặt → Ứng dụng → WP Pocket Server → Gỡ cài đặt) — nếu không
gỡ trước, Android sẽ báo "Ứng dụng chưa được cài đặt" do certificate ký khác
với bản cũ. Từ lần build này trở đi (đã dùng `app/debug.keystore` cố định),
cài đè bình thường không cần gỡ nữa.

**CẬP NHẬT (mục 1k): bước 1-4 dưới đây đã hoàn thành thật (build + cài lên
máy thật) trước khi có bản sửa `mariadb-install-db` ở mục 1k** — 0. push lại
bản đã sửa lên GitHub → build lại → cài đè APK mới → bấm "Bật server" → "Xem
log" trong app, xác nhận KHÔNG còn dòng "LOI: mariadb-install-db that bai"
(nếu vẫn còn, đọc `mysql-install.log` mới, đối chiếu mục 1k phần "CHƯA
verify"). Sau khi qua được bước này mới tiếp tục các bước 1-4 cũ bên dưới
như bình thường (chúng mô tả checklist chung, vẫn còn giá trị tham khảo).

1. Push repo lên GitHub → xem tab Actions → đọc log lỗi đầu tiên (nếu có).
2. Nếu lỗi ở bước SDK/Gradle version → sửa version trong
   `.github/workflows/build-apk.yml`.
3. Nếu lỗi ở bước tải binary Termux (thiếu `.so`) → xem mục 7.2.
4. Nếu build ra APK thành công → cài thử, bấm "Bật server", kiểm tra
   `adb logcat | grep -E "site|cloudflared"` xem site + tunnel có lên không.
5. Test lần lượt 4 runtime (`php`/`node`/`python`/`static`) bằng cách đổi
   `site.config.json` rồi push lại — mỗi lần chỉ test 1 runtime.
6. Nếu ổn định → cân nhắc mục 7.6 (code signing) nếu cần bản release; kiểm
   tra thử luồng named tunnel (dán token Cloudflare vào app) nếu muốn domain
   cố định thay vì Quick Tunnel ngẫu nhiên.
7. Kiểm tra `/_admin/` (mục 1c, 1d, rủi ro #8 ở mục 7): vào bằng trình
   duyệt cùng mạng LAN, xác nhận hiện màn hình xin mật khẩu trước khi thấy
   Adminer/File Manager/Log/Info.
8. **(Mới, mục 1e)** Kiểm tra dashboard `_admin/index.php` hiện đúng dòng
   RAM máy + trạng thái MariaDB (chấm xanh/đỏ) — nếu KHÔNG hiện dòng RAM,
   `/proc/meminfo` không đọc được trên máy đó (đã có guard, không phải lỗi
   chặn trang, xem mục 1e phần "CHƯA verify").
8b. **(Mới, mục 1e - bảo mật)** Từ mạng 4G/ngoài LAN, thử mở
   `https://<url-tunnel>/wp-config.php.template` và
   `https://<url-tunnel>/_supervisor/nginx.conf.template` — PHẢI thấy lỗi
   403 (đã test bằng nginx thật trên máy tính, xem mục 1e, nhưng nên xác
   nhận lại 1 lần trên bản build APK thật để chắc chắn `nginx.conf.template`
   không bị lỗi resolve placeholder nào khác trên thiết bị).
9. **(Mới, mục 1e)** Nếu muốn thử "1-Click Install WordPress": đổi
   `site.config.json` sang `site_source.type` khác `wordpress` (vd `local`
   với thư mục `site/` trống), build lại, mở `/_admin/install-wp.php` qua
   LAN, xác nhận tải + cài xong rồi mở website thấy màn hình cài đặt
   WordPress 5 phút.
10. **(Mới, mục 1e)** Test backup tự động: bật "Tự động backup định kỳ"
    trong app, đặt khoảng cách giờ nhỏ để test nhanh hơn (vd 1), đợi qua ít
    nhất 1 chu kỳ, kiểm tra `Android/data/<package>/files/backups/` có file
    mới không. Nếu điền Telegram Bot Token + Chat ID, kiểm tra có nhận được
    tin nhắn/file trong Telegram không.
11. **(Mới, mục 1e)** Test watchdog: bật server, vào Recent Apps vuốt tắt
    app (không bấm "Tắt server" trong app), đợi khoảng 15-30 phút, kiểm tra
    server còn chạy không (mở lại app hoặc tạo yêu cầu tới URL LAN) — đây là
    `HealthCheckWorker` hoạt động.
12. **(Mới, mục 1f)** Test Dual-Mode PHP-Lite: chọn "Luôn bật" trong app
    (RadioGroup) TRƯỚC lần bấm "Bật server" đầu tiên trên site mới, xác nhận
    `_admin/index.php` hiện badge "Chế độ PHP-Lite" + dòng "php -S đơn lẻ".
    Test cả trên máy RAM thật < 3GB với chế độ "Tự động" để xác nhận
    `DEVICE_RAM_MB` đọc đúng qua `ActivityManager`. Sau đó thử đăng bài/tải
    ảnh trên WordPress để xác nhận SQLite hoạt động bình thường.
13. **(Mới, mục 1h)** Test điều khiển Telegram: điền Bot Token + Chat ID,
    chat `/status` với bot, đợi tối đa ~15 phút, xác nhận nhận được tin
    nhắn trạng thái. Thử `/backup` và `/restart`. Thử nhắn từ 1 tài khoản
    Telegram KHÁC (không phải Chat ID đã cấu hình) — xác nhận KHÔNG nhận
    được phản hồi gì (đúng thiết kế bảo mật).
14. **(Mới, mục 1i)** Test lỗ hổng Force-stop: bật auto-start + backup tự
    động + Telegram, vào Cài đặt Android > Ứng dụng > WP Pocket Server >
    "Buộc dừng", khởi động lại máy (auto-start sẽ tự bật server) — **KHÔNG
    mở lại app** — đợi qua 1 chu kỳ backup, xác nhận vẫn có file backup mới
    (xác nhận `WorkScheduler` gọi từ `ServerForegroundService.onCreate()`
    hoạt động đúng). Đồng thời xác nhận `tvRuntimeMode` trong app hiện đúng
    "Đầy đủ" hoặc "PHP-Lite" khớp với dashboard web.

## 10. Backlog tính năng nâng cao (tham khảo phân tích DeepSeek, vòng phản
hồi thứ 9) — CHƯA làm, ghi lại có tổ chức để không mất ý

Nguồn: người dùng gửi 1 phân tích dài của DeepSeek (AI khác, không phải
Claude) so sánh dự án với hosting trả phí. Một phần đã LÀM NGAY và ghi ở
mục 1ab (kèm phần DeepSeek nêu SAI, đã kiểm chứng loại bỏ). Phần DƯỚI ĐÂY
là phần CÒN LẠI, thật sự cần code Kotlin/PHP mới hoặc cần thiết bị thật để
test kỹ — KHÔNG làm ngay vì rủi ro/công sức cao hơn, liệt kê để làm dần,
theo đúng tinh thần "đọc bằng chứng trước khi sửa" đã áp dụng xuyên suốt
file này. Nếu AI hoặc người tiếp theo chọn làm mục nào, cập nhật mục đó
sang phần "làm rồi" (mục 1x mới) thay vì để trùng ở đây.

**Ưu tiên cao (giá trị cao, rủi ro thấp — nên làm sớm nếu tiếp tục):**

- **Log rotation** — ĐÃ LÀM ở mục 1ae (không còn trong backlog).
- **Kiểm tra dung lượng trống trước khi backup** — ĐÃ LÀM ở mục 1ac (không
  còn trong backlog).
- **Maintenance mode 1 nút** (đề xuất A8) — ĐÃ LÀM ở mục 1ag (không còn
  trong backlog). Làm luôn cả sửa `nginx.conf` (khác quyết định tạm hoãn ở
  mục 1ac) — trong lúc làm phát hiện thêm bug thật `open_file_cache` làm trễ
  toggle tới 60 giây, đã sửa cùng lúc, xem chi tiết ở mục 1ag.
- **Đổi mật khẩu quản trị** — ĐÃ LÀM ở mục 1z (không còn trong backlog).
- **Chặn brute-force `_admin/`** — ĐÃ LÀM ở mục 1ac (không còn trong
  backlog).

**Ưu tiên vừa (giá trị cao, công sức/rủi ro vừa phải):**

- **Uptime monitoring + cảnh báo Telegram thật** — ĐÃ LÀM ở mục 1ad (không
  còn trong backlog).
- **2FA (TOTP) cho `_admin/`** — ĐÃ LÀM ở mục 1af (không còn trong backlog).
- **Dashboard metrics theo thời gian nhẹ** (đề xuất A4/A5) — ĐÃ LÀM ở mục
  1ag (không còn trong backlog).
- **WP-Cron thật** — ĐÃ LÀM ở mục 1ae (không còn trong backlog).
- **Dọn dẹp PID/socket cũ khi khởi động** (đề xuất O10) — ĐÃ LÀM ở mục 1ag
  (không còn trong backlog). Quyết định làm sớm hơn dự kiến vì đây là thao
  tác phòng thủ 0 rủi ro (khác đa số đề xuất khác trong file này vốn cần
  "bằng chứng thật" trước khi sửa) — xem lý do đầy đủ ở mục 1ag.

**Ưu tiên thấp / để sau (công sức lớn, hoặc giá trị chưa rõ so với công sức):**

- Battery/thermal/network-aware scheduling (nhóm B trong phân tích gốc) —
  MỘT PHẦN đã làm ở mục 1ag: `setRequiresBatteryNotLow(true)` hoá ra ĐÃ có
  sẵn từ trước (backlog này từng ghi nhầm là "chưa làm" — bài học: tin vào
  code, không tin mù backlog); thêm mới 1 công tắc TUỲ CHỌN "chỉ backup khi
  đang sạc" (`setRequiresCharging`, mặc định TẮT). CÒN LẠI: thermal
  (`PowerManager.getCurrentThermalStatus()`), network-aware (đổi WiFi/4G),
  data usage budget, `onTrimMemory()` — CHƯA làm, ý tưởng hay, chưa cấp
  thiết.
- Staging/clone site, WP-CLI bundled, export/import site sang máy khác.
- Quick Settings Tile, Home screen Widget, notification actions, QR code
  chia sẻ URL, onboarding wizard.
- APCu (thay thế nhẹ cho opcache đã tắt ở mục 1y) — ĐÃ TRA CỨU ở mục 1ag:
  Termux CÓ đóng gói `php-apcu` (xác nhận qua GitHub, thư mục
  `/packages/php-apcu/` trong repo `termux-packages`) — nhưng CHƯA wire vào
  code, vì việc file `.so` có load đúng hay không chỉ kiểm chứng được trên
  thiết bị Android thật, không test được trong môi trường build. Người tiếp
  theo có thiết bị thật có thể thử ngay, không cần tra cứu lại việc package
  có tồn tại hay không.
- Multi-ABI build, test automation trong CI (`sh -n`/`php -l`/`nginx -t` tự
  động thay vì thủ công như hiện tại).

**KHÔNG làm (đã có lý do rõ ràng, đừng đề xuất lại - xem thêm mục 6):**

Redis/Memcached, Prometheus/Grafana, Docker/Kubernetes, multi-tenant/reseller
— đều quá nặng hoặc không khả thi trên Android không root, đúng như phân
tích DeepSeek đã tự nhận định.

**Lưu ý về giới hạn phần cứng (không phần mềm nào cứu được, nói thẳng để
không kỳ vọng sai):** không có SLA/uptime 99.9% thật (điện thoại có thể mất
điện/mất mạng/bị người dùng tắt bất cứ lúc nào), không multi-region, không
scale ngang, IP di động có thể nằm trong dải bị 1 số dịch vụ chặn, pin sẽ
chai nhanh hơn nếu chạy server 24/7 — đây là đánh đổi đã biết trước của mô
hình "server bỏ túi", không phải thiếu sót có thể sửa.
