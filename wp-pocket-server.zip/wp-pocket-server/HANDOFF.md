# HANDOFF — WP Pocket Server

> Đọc file này trước khi động vào code. Mục tiêu: không lặp lại các quyết
> định/rủi ro đã xác định bên dưới.

## 1. Mục tiêu gốc (yêu cầu người dùng, không đổi)

- App Android **tự nó là server** — KHÔNG qua app trung gian (Termux) lúc
  chạy. Thay thế hoàn toàn việc thuê hosting/server hàng tháng.
- Chạy nền được khi **tắt màn hình** (bắt buộc, không phải optional).
- Deliverable = **source code build APK qua GitHub Actions**, không phải
  file `.apk` đã compile sẵn.
- **Không hardcode 1 backend cụ thể.** Hỗ trợ PHP/Node/Python/static qua
  config, nhưng chỉ chạy **1 website tại 1 thời điểm** (không multi-tenant —
  "nhiều backend" = linh hoạt chọn nền tảng, không phải chạy song song
  nhiều site).
- Ưu tiên ban đầu: WordPress. Nhưng kiến trúc phải tổng quát hoá được.

## 1b. Cập nhật (vòng phản hồi thứ 2): "hạn chế" không phải cái cớ để dừng

Sau khi liệt kê 7 hạn chế thực tế cho người dùng, người dùng phản hồi đúng:
nhiều cái trong đó là "chưa làm" chứ không phải "không làm được". Đã tra
cứu + implement lại 4/7 cái bằng đúng kỹ thuật đã dùng (mượn binary Termux),
KHÔNG cần công nghệ mới:

| # | Hạn chế cũ | Đã xử lý | Cách |
|---|---|---|---|
| 1 | `php -S` không phải server production | ✅ Đã fix | Đổi sang **nginx + php-fpm** thật (Termux có gói `nginx`, `php-fpm` — xác nhận qua search, cộng đồng Termux dùng combo này chạy LAMP hàng ngày) |
| 2 | SQLite thay MySQL → 1 số plugin lỗi | ✅ Đã fix | Đổi sang **MariaDB thật** (gói `mariadb` của Termux), kết nối qua unix socket |
| 3 | Không gửi email thật | 🔶 Giảm nhẹ | Cài sẵn plugin **WP Mail SMTP** trong site_source — người dùng chỉ cần điền SMTP credentials có sẵn (Gmail/Brevo...) vào wp-admin. Vẫn cần SMTP ngoài — đây là giới hạn của MỌI server (kể cả VPS thật), không riêng gì app này |
| 7 | URL Cloudflare Quick Tunnel đổi mỗi lần restart | ✅ Đã fix (tuỳ chọn) | Thêm ô nhập **Cloudflare Tunnel token** trong app (Cài đặt) → dùng `cloudflared tunnel run --token` (named tunnel, domain cố định) thay vì `--url` (quick tunnel). Cần người dùng tự tạo tunnel trên dashboard Cloudflare (miễn phí) để lấy token — việc này KHÔNG thể tự động hoá thay người dùng vì cần tài khoản của họ |
| — | (mới) Không backup | ✅ Thêm mới | Nút "Backup ngay" trong app — zip `www/` + `mysqldump` database vào `Android/data/<pkg>/files/backups/` |

**Còn lại KHÔNG fix, lý do là giới hạn phần cứng thật (không né được bằng
phần mềm):**
- Không nguồn điện dự phòng / RAID / datacenter-grade reliability
- RAM/CPU trần cứng của điện thoại — traffic tăng đột biến vẫn có thể sập,
  dù nginx+php-fpm đã xử lý đồng thời tốt hơn `php -S` nhiều
- Không multi-site/cPanel — nằm ngoài phạm vi user yêu cầu (mục 1: "chỉ 1
  website"), không phải giới hạn kỹ thuật

**Đánh đổi mới phát sinh:** nginx+php-fpm+mariadb nặng RAM hơn hẳn
`php -S`+SQLite bản cũ. Nếu người dùng chạy trên máy yếu (<3GB RAM), có thể
cần fallback về bản nhẹ — ~~CHƯA implement dual-mode~~ **ĐÃ implement ở mục
1f (Dual-Mode PHP-Lite)**, xem đó thay vì mục 7 (đã lỗi thời).

## 1c. Cập nhật (vòng phản hồi thứ 3): công cụ quản trị (Adminer + File Manager)

Người dùng hỏi "có control panel không" → không có, chỉ WordPress wp-admin
(nội dung) + app Android (bật/tắt server). Đã thêm **Adminer** (quản lý
database) + **Tiny File Manager** (quản lý file) vào `_admin/` cho runtime
`php`. Người dùng xác nhận muốn CẢ 2, và ưu tiên bảo mật cao (lo ngại
backdoor/spyware/truy cập trái phép nếu lộ) → implement **2 lớp bảo vệ**:

1. **Chặn ở nginx** (`location ^~ /_admin/` trong `nginx.conf.template`):
   chỉ `allow` dải IP LAN riêng tư (192.168.0.0/16, 10.0.0.0/8,
   172.16.0.0/12), `deny all` còn lại. **Quan trọng**: traffic từ Cloudflare
   Tunnel đến nginx qua `127.0.0.1` (vì cloudflared chạy ngay trên máy, nối
   vào localhost) — nên `127.0.0.1` CỐ Ý không nằm trong allow list, tự
   động chặn `_admin/` khỏi URL public dù website chính vẫn public bình
   thường. Đây là điểm kỹ thuật dễ hiểu sai nếu không biết kiến trúc
   Cloudflare Tunnel — đừng thêm `allow 127.0.0.1` vào đây tưởng là vô hại.
2. **Mật khẩu riêng mỗi máy** (`_admin/auth.php` + `ServerForegroundService.
   ensureAdminPassword()`): sinh ngẫu nhiên bằng `SecureRandom` (16 ký tự)
   lúc server chạy lần đầu, ghi vào `filesDir/admin-password.txt`
   (app-private storage). KHÔNG có mật khẩu mặc định nào (khác Tiny File
   Manager gốc vốn có default `admin/admin@123`). Hiện trong app
   (`MainActivity` — mục "Mật khẩu quản trị") để người dùng tự xem.

**Cơ chế**: `scripts/lib/admin_tools.sh` tải Adminer (file PHP chính thức
từ GitHub release của adminer.org) + Tiny File Manager (file PHP từ repo
GitHub gốc `prasathmani/tinyfilemanager`) lúc CI build, chèn
`require __DIR__.'/auth.php';` vào ngay sau thẻ `<?php` ĐẦU TIÊN của mỗi
file (hàm `inject_auth_guard`, dùng `awk` không phải `sed` để an toàn hơn
với file lớn nhiều `<?php` trong string) — **đã test logic này trên file
mẫu, xác nhận chỉ sửa đúng dòng đầu, cú pháp PHP hợp lệ sau khi chèn**
(không phải suy đoán). Tiny File Manager có màn đăng nhập RIÊNG của nó
(biến `$use_auth`, đã tra cứu xác nhận qua GitHub wiki, KHÔNG phải hằng số
như đoán ban đầu) — tắt đi bằng `sed` để tránh đăng nhập 2 lần (đã có
`auth.php` gác cổng rồi).

**CHƯA verify (khác với injection logic đã test ở trên):**
- URL tải Adminer (`adminer.php` từ GitHub release "latest") và Tiny File
  Manager (`tinyfilemanager.php` từ nhánh `master`) có thể đổi cấu trúc
  file/tên biến ở phiên bản tương lai — nếu `inject_auth_guard` hay dòng
  `sed` tắt `$use_auth` không còn khớp, 2 công cụ này sẽ lộ ra (Adminer)
  hoặc yêu cầu đăng nhập kép/lộ default password (Tiny File Manager). Nên
  **luôn kiểm tra thủ công sau khi build** rằng `/_admin/db.php` và
  `/_admin/files.php` có hiện màn hình đăng nhập của `auth.php` (không
  phải giao diện Adminer/TFM ngay lập tức) trước khi tin tưởng đưa vào
  dùng thật.
- Hành vi `session.save_path` + `session_start()` của PHP-FPM build từ
  Termux (php.ini.template) — chưa chạy thử trên thiết bị thật.

## 1d. Cập nhật (vòng phản hồi thứ 4): thêm gì / KHÔNG thêm gì so với cPanel

Người dùng hỏi sao không thêm hết mọi thứ cPanel có. Đã phân loại rõ, thêm
`_admin/logs.php` (xem log nginx/php-fpm/mariadb, có fallback thuần PHP nếu
`shell_exec` bị chặn) + `_admin/info.php` (`phpinfo()`) + dung lượng đĩa
trống hiện ngay trang chủ `_admin/index.php`. **Cả 2 file PHP mới đã chạy
`php -l` xác nhận cú pháp hợp lệ**, không phải suy đoán.

**CỐ Ý KHÔNG thêm (nếu ai đó — kể cả AI khác — định thêm lại, đọc lý do
trước):**
- Mail server/webmail (Roundcube...) — vô nghĩa trên IP di động/hộ gia
  đình (port 25 bị ISP chặn gần hết, không reverse-DNS). WP Mail SMTP
  (relay qua SMTP ngoài) đã là giải pháp đúng, xem mục 1b.
- DNS zone manager — server không chạy DNS, Cloudflare đã quản lý domain.
- FTP server — trùng chức năng với File Manager đã có, chỉ thêm bề mặt
  tấn công không cần thiết.
- SSH/terminal qua web — rủi ro bảo mật không tương xứng lợi ích, ADB đã
  đủ cho truy cập trực tiếp thiết bị.
- Multi-site/reseller — trái yêu cầu gốc "chỉ 1 website" (mục 1).
- SSL certificate manager — không cần, Cloudflare Tunnel đã tự cấp HTTPS
  miễn phí cho URL public, không cần tự gia hạn Let's Encrypt như cPanel.

## 1e. Cập nhật (vòng phản hồi thứ 5): tối ưu hiệu năng + backup tự động +
dashboard nâng cao — bổ sung theo đề xuất từ 1 cuộc hội thoại AI khác (PDF)

Người dùng đưa 1 file PDF (hội thoại với Google AI/Gemini, KHÔNG có quyền
truy cập mã nguồn thật của repo này — chỉ suy đoán từ mô tả) liệt kê ~20 đề
xuất để biến app gần với "Panel tính phí" hơn. Đã đọc kỹ HANDOFF.md +
toàn bộ code THẬT trước khi chọn lọc — nhiều đề xuất trong PDF **đã làm rồi**
(vd PDF chê "_admin/ chắp vá rời rạc" nhưng `admin_tools.sh` đã tự sinh
`index.php` gộp 1 trang từ vòng phản hồi thứ 4, mục 1d) hoặc **mâu thuẫn
quyết định đã chốt** (vd PDF gợi ý quay lại SQLite — mục 1b đã đổi hẳn sang
MariaDB thật, có lý do rõ ràng, KHÔNG làm lại). Danh sách dưới đây là phần
đã **thật sự bổ sung**, cộng phần **cố ý bỏ qua** (đọc trước khi đề xuất lại).

**Đã thêm (build-time / runtime, KHÔNG đổi kiến trúc "app Kotlin tuyệt đối
generic" ở mục 3):**

| # | Đề xuất (PDF) | Đã làm | File |
|---|---|---|---|
| 1 | OPcache cho PHP | ✅ | `php.ini.template` (`zend_extension = opcache.so` + config) |
| 2 | `realpath_cache_size` | ✅ | `php.ini.template` |
| 3 | PHP-FPM `pm=ondemand` thay vì `dynamic` | ✅ | `php-fpm.conf.template` |
| 4 | Nginx `open_file_cache` | ✅ | `nginx.conf.template` |
| 5 | Giảm `innodb_buffer_pool_size` + các buffer MariaDB khác | ✅ | flag CLI trong `start-lamp.sh` (không tạo file `my.cnf` riêng — ít file hơn, cùng hiệu quả) |
| 6 | Dashboard `_admin/index.php`: hiện RAM máy + trạng thái 3 daemon | ✅ | `admin_tools.sh` (đọc `/proc/meminfo` + kiểm tra file socket MariaDB) |
| 7 | "1-Click Installer" WordPress từ dashboard | ✅ | `admin-install-wp.php` (mới) — **CHỈ chạy khi docroot đang trống** (không có `wp-config.php`/`wp-load.php`), tránh ghi đè site đang chạy |
| 8 | Backup tự động định kỳ (không chỉ nút bấm tay) | ✅ | `BackupWorker.kt` (mới, WorkManager) + `BackupManager.kt` (mới, tách logic dùng chung với nút bấm tay) |
| 9 | Đồng bộ backup lên cloud | ✅ | Qua **Telegram Bot** (`TelegramNotifier.kt`) + **Webhook tổng quát** (`WebhookUploader.kt`, mới) thay vì Google Drive OAuth thật — xem lý do kỹ thuật ở mục 1g |
| 10 | Báo cáo tự động qua Telegram khi server khởi động | ✅ | `ServerForegroundService.maybeNotifyTelegram()` — gửi URL công khai lúc tunnel lên, CHỈ nếu đã cấu hình Bot Token + Chat ID |
| 11 | "Chữa lành tự động" (self-healing) không cần app luôn mở | ✅ | `HealthCheckWorker.kt` (mới, WorkManager) — watchdog BÊN NGOÀI service, phân biệt rõ với cơ chế tự-restart tiến trình con ĐÃ CÓ SẴN trong `runSiteLoop()`/`runTunnelLoop()` (mục 8, đừng viết lại) |
| 12 | **Dual-Mode PHP-Lite** (máy RAM thấp tự chuyển sang chế độ nhẹ) | ✅ | Xem mục "Dual-Mode PHP-Lite" riêng ngay dưới — đủ lớn nên tách mục |

## 1f. Dual-Mode PHP-Lite (chi tiết)

Trước bản này, đây là việc CHƯA làm, ghi nhận ở mục 7 cũ ("0d"). Sau khi tối
ưu buffer/pool-size cho MariaDB thật (bảng trên, #5) vẫn chưa đủ cho máy
THẬT SỰ yếu (< 3GB RAM) — bản này làm nốt phần fallback đầy đủ theo đúng đề
xuất gốc của PDF, với thiết kế AN TOÀN hơn PDF gợi ý (xem "quyết định 1 lần"
dưới đây).

**Cơ chế**: máy < 3072MB RAM (`LITE_MODE_THRESHOLD_MB` trong `start-lamp.sh`,
sửa tại đây nếu cần tinh chỉnh) tự chuyển sang chạy **`php -S` đơn lẻ +
SQLite**, bỏ hẳn MariaDB/nginx/php-fpm. Người dùng có thể ép tay qua app
(Auto/Luôn bật/Luôn tắt) — xem `RadioGroup` mới trong `MainActivity`.

**"Quyết định 1 lần, không bao giờ đổi lại"** — khác PDF gốc (vốn ngụ ý kiểm
tra RAM mỗi lần khởi động): chế độ được **ghi vào `$DATA/.runtime-mode` ở
LẦN SETUP ĐẦU TIÊN**, các lần sau LUÔN đọc lại giá trị cũ, bỏ qua RAM/override
hiện tại. Lý do: nếu 1 site đã chạy thật với MariaDB (đã có dữ liệu), một lần
khởi động sau đó "phát hiện" RAM thấp rồi tự chuyển sang SQLite sẽ làm
WordPress **mất kết nối database ngay lập tức** (wp-config.php cũ vẫn trỏ
MariaDB, nhưng service đó không được bật nữa) — đây là rủi ro dữ liệu nghiêm
trọng nếu làm theo đúng nghĩa đen "kiểm tra lại mỗi lần" như PDF mô tả. Muốn
đổi chế độ: xoá dữ liệu app (Cài đặt > Ứng dụng > xoá dữ liệu) để bắt đầu lại
từ đầu — người dùng được thông báo rõ điều này ngay trong log
`[start-lamp] Se GIU NGUYEN che do nay...` và trong `hint_lite_mode` (string
trong app).

**File liên quan (mới):**
- `router-lite.php` — router cho `php -S` (built-in server không đọc
  `.htaccess` nên permalink WordPress sẽ 404 nếu thiếu; đây là kỹ thuật
  CHUẨN theo tài liệu chính thức của PHP.net, không phải tự nghĩ ra).
- `ServerForegroundService.getDeviceTotalRamMb()` — dùng
  `ActivityManager.MemoryInfo` (API chính thức, không cần quyền đặc biệt),
  truyền xuống script qua `env["DEVICE_RAM_MB"]` — biến này THUẦN TUÝ là 1
  sự kiện của thiết bị (giống `PORT`/`HOME`/`TMPDIR` đã có), Kotlin KHÔNG tự
  quyết định lite hay không — quyết định thật nằm hoàn toàn trong
  `start-lamp.sh`, đúng nguyên tắc "app Kotlin generic" ở mục 3.
- `Prefs.KEY_PHP_LITE_MODE` (Auto/On/Off) → env `FORCE_LITE_MODE` → đọc bởi
  `start-lamp.sh`.
- `site_source.sh`: khi `site_source.type=wordpress`, đóng gói SẴN (không
  kích hoạt) plugin chính thức **SQLite Database Integration** (đội
  Performance của WordPress core duy trì — chọn nguồn chính thức thay vì
  drop-in cộng đồng, nhất quán với việc dự án luôn tải WordPress core từ
  `wordpress.org` chính chủ) + sinh thêm `wp-config-sqlite.php.template`
  song song `wp-config.php.template` cũ. Plugin nằm sẵn trong
  `wp-content/plugins/` KHÔNG tự kích hoạt gì (WordPress chỉ đọc
  `wp-content/db.php` NẾU file đó tồn tại) nên **không ảnh hưởng chế độ đầy
  đủ** dù luôn được đóng gói.
- `admin-auth.php`: thêm kiểm tra IP-LAN NGAY TRONG PHP (hàm
  `wp_pocket_ip_in_private_lan()`, 3 dải RFC1918 chuẩn) — bắt buộc vì chế độ
  Lite KHÔNG có nginx nên không còn lớp chặn IP nào cả nếu không tự làm ở
  đây. Áp dụng cho CẢ 2 chế độ (phòng thủ kép cho chế độ đầy đủ, vô hại vì
  cùng dải IP nginx đã cho phép).
- `nginx.conf.template` + `router-lite.php`: đều chặn `_supervisor/` và
  `*.template` — 2 luật giống hệt nhau, đảm bảo nhất quán giữa 2 chế độ.
- `scripts/runtimes/php.sh`: thêm bước tải binary CLI `php` (`libphpcli.so`)
  — **TRƯỚC BẢN NÀY CHƯA TỪNG TẢI BINARY NÀY** (dự án chỉ dùng `php-fpm`),
  nếu thiếu bước này chế độ Lite sẽ lỗi ngay khi chạy trên thiết bị thật.

**Đánh đổi CỐ Ý, không phải thiếu sót** (nói rõ để không ai "sửa lại cho
giống chế độ đầy đủ"): `php -S` là built-in dev server của PHP, xử lý
TUẦN TỰ (1 request/lần) — đây là ĐÚNG lý do dự án chuyển sang nginx+php-fpm ở
mục 1b ban đầu. Dùng lại nó ở đây là đánh đổi CÓ CHỦ ĐÍCH: máy quá yếu RAM
thì "chạy được nhưng chậm khi đông người" vẫn tốt hơn "sập liên tục" — đúng
tinh thần PDF gốc ("đổi lại một chút hiệu năng chịu tải nhưng đổi lấy sự ổn
định tuyệt đối cho máy yếu").

**Đã TEST BẰNG BINARY THẬT (PHP CLI qua apt, không phải bản Termux ARM):**
- `router-lite.php`: test đủ 8 trường hợp (file tĩnh, permalink giả lập,
  chặn `_supervisor/`, chặn `*.template`, `/_admin/` → đúng
  `_admin/index.php`, `/_admin/db.php` → đúng file, trang chủ) — TẤT CẢ
  ĐÚNG. Phát hiện + sửa 1 lỗi thật lúc test: bản đầu dùng `__DIR__` (sai vì
  file nằm trong `_supervisor/`, không phải docroot gốc) thay vì
  `$_SERVER['DOCUMENT_ROOT']` — nếu không test thực tế bằng `php -S` thật,
  lỗi này sẽ khiến TOÀN BỘ chế độ Lite không hoạt động trên thiết bị thật.
- `admin-auth.php`: test hàm CIDR với 12 trường hợp biên (ranh giới
  `172.16.0.0/12`, `127.0.0.1`, IP public, IPv6) — tất cả đúng.
- `start-lamp.sh` toàn bộ luồng quyết định chế độ: test 4 kịch bản bằng
  `sh` thật + PHP CLI thật thay cho binary Termux — (1) RAM thấp → lite,
  (2) cùng máy RAM cao lần sau → VẪN lite (quyết định giữ nguyên), (3) máy
  mới RAM cao → full, (4) `FORCE_LITE_MODE=on` dù RAM cao → lite. Cả 4 đúng.
- Nginx thật xác nhận `location ~* \.template$` + `location ^~ /_supervisor/`
  hoạt động đúng (403), khớp với hành vi tương ứng của `router-lite.php`.

**Vẫn CHƯA verify** (giới hạn thật của môi trường viết bản cập nhật — không
có Termux ARM/thiết bị Android thật):
- Bản Termux thật của `php` package có chắc chắn cung cấp `bin/php` (CLI
  SAPI) như giả định không — rất nhiều khả năng có (đây là gói CLI cơ bản
  nhất của PHP, `php-fpm` là gói RIÊNG, TÁCH BIỆT mà dự án đã dùng thành
  công từ trước), nhưng chưa tải gói Termux thật để xác nhận cấu trúc file
  bên trong.
- Plugin SQLite Database Integration bản mới nhất từ wordpress.org có đúng
  chứa file `db.copy` ở đường dẫn gốc plugin như tài liệu chính thức mô tả
  hay không — chưa tải thật để xác nhận (tài liệu chính thức của plugin ghi
  rõ vậy, nhưng cấu trúc file có thể đổi giữa các phiên bản).
- `curl -fsSL https://curl.se/ca/cacert.pem` chạy TỐT trên GitHub Actions
  runner (internet đầy đủ, không có lý do gì để lỗi) nhưng cả pipeline build
  đầy đủ (bao gồm cả `php.sh` sửa lần này) chưa được chạy thật lần nào.

**Cố ý KHÔNG làm (đọc lý do trước khi đề xuất lại, giống tinh thần mục 1d):**

- ❌ **SQLite "on-demand"/dual DB** (PDF đề xuất: MariaDB làm chính, TỰ
  CHUYỂN ĐỔI qua lại sang SQLite mỗi khi mở trang quản trị rồi đồng bộ
  ngược) — **KHÁC với Dual-Mode PHP-Lite ở mục 1f phía trên** (SQLite ở đó
  là lựa chọn CỐ ĐỊNH 1 lần cho máy yếu, không bao giờ tự chuyển qua lại).
  Ý tưởng "chuyển đổi qua lại" này vẫn bị từ chối: mâu thuẫn trực tiếp quyết
  định mục 1b (đã đổi hẳn từ SQLite sang MariaDB thật vì lý do tương thích
  plugin WordPress) VÀ rủi ro mất đồng bộ/hỏng dữ liệu cao hơn nhiều so với
  lợi ích (không rõ "đồng bộ ngược" sẽ xử lý xung đột dữ liệu thế nào nếu có
  thay đổi ở cả 2 phía trước khi đồng bộ). Không làm.
- ❌ **OverlayFS ảo / symlink `wp-content/uploads` sang `cacheDir` Android**
  — `cacheDir` có thể bị hệ điều hành TỰ XOÁ bất kỳ lúc nào khi máy thiếu bộ
  nhớ (đúng bản chất API, không phải suy đoán) → dùng cho ảnh/file người
  dùng tải lên là rủi ro MẤT DỮ LIỆU thật, không đánh đổi được.
- ❌ **Gộp nhiều điện thoại thành cluster qua LAN** (Nginx làm Load Balancer,
  proxy PHP-FPM sang máy khác) — ngoài phạm vi yêu cầu gốc "chỉ 1 website,
  không multi-tenant" (mục 1), và độ phức tạp/rủi ro (đồng bộ file + DB giữa
  nhiều máy) không tương xứng lợi ích cho 1 dự án cá nhân.
- ❌ **Thay `nginx`/`php-fpm`/`mariadb` bằng BusyBox/Toybox** — hiểu lầm từ
  PDF: Toybox/BusyBox chỉ thay được các lệnh tiện ích đơn giản (sed/awk/tar),
  KHÔNG thể thay thế được 1 web server hay database server thật. Phần "thay
  lệnh tiện ích" thực ra không cần thiết — `admin_tools.sh` hiện chỉ dùng
  `awk`/`sed`/`curl` sẵn có trên GitHub Actions runner (build-time, không
  chạy trên điện thoại) nên không có gì để tối ưu ở đây.
- ❌ **ZRAM hint qua `ComponentCallbacks2.onTrimMemory`** — Android tự quản
  lý ZRAM ở tầng kernel, app không cần (và không có API) để "ra lệnh" nén
  RAM tiến trình CON (`mariadbd`/`php-fpm`/`nginx` là tiến trình con của
  service, không phải component Android có vòng đời `onTrimMemory` riêng).
  Đề xuất PDF hiểu chưa đúng ranh giới API.
- ❌ **Cloudflare Workers/Pages làm "static mirror"** — cần thêm tài khoản
  Cloudflare API token + logic xuất static site (Simply Static hoặc tương
  đương) + đồng bộ 1 chiều lên Pages, độ phức tạp lớn cho 1 lần bổ sung.
  Ghi nhận là hướng hay nếu website chủ yếu là nội dung tĩnh, nhưng để
  tương lai.
- ❌ **HTTP/3 (QUIC)** — KHÔNG cần code: Cloudflare Tunnel tự thương lượng
  QUIC ở phía Cloudflare edge nếu trình duyệt hỗ trợ, không có gì để "bật"
  trong app hay nginx.conf. Đã ghi 1 dòng vào README thay vì sửa code.
- ❌ **Tailscale/ZeroTier thay Cloudflare Tunnel** — phương án B hợp lý cho
  rủi ro "`cloudflared` không static-link" (mục 7 cũ, việc #3), nhưng đó là
  thêm 1 kiến trúc mạng SONG SONG, không phải "bổ sung nhỏ" — để dành khi
  nào rủi ro đó THẬT SỰ xảy ra (build xong mới biết), tránh code 2 đường dự
  phòng không dùng đến.
- ❌ **Webhook/long-polling nhận lệnh ngược từ Telegram** (`/status`,
  `/backup`, `/restart_service`) — chỉ làm chiều app → Telegram (báo cáo,
  gửi file). Chiều ngược lại cần 1 tiến trình lắng nghe liên tục (tốn thêm
  RAM/pin đúng thứ đang cố tiết kiệm) hoặc webhook công khai (thêm bề mặt
  tấn công) — không tương xứng lợi ích cho 1 lần bổ sung.
- ❌ **Đưa log/cache vào tmpfs (RAM Disk)** thật sự — PDF gợi ý điều này
  nhưng Android (không root) KHÔNG cấp quyền mount tmpfs tuỳ ý cho app
  thường; `cacheDir`/`filesDir` của app đều nằm trên bộ nhớ flash thật, không
  phải RAM. Việc `open_file_cache` (nginx) + `opcache`/`realpath_cache`
  (PHP) ở bảng trên đã đạt hiệu quả tương tự (giảm I/O đọc lặp lại) MÀ
  KHÔNG cần tuyên bố sai về tmpfs — quan trọng để không ghi nhầm 1 khả năng
  kỹ thuật không có thật vào tài liệu dự án.

**Đã sửa 2 lỗi tìm được lúc rà soát (không phải do vòng sửa này gây ra — có
sẵn từ trước, phát hiện khi kiểm tra lại kỹ trước khi làm tiếp — xem yêu cầu
"rà lại và sửa lỗi" của người dùng):**

- 🔴 **Nghiêm trọng — rò rỉ salt/khoá bí mật WordPress ra URL public**:
  `site_source.sh` nhúng salt thật (lấy từ `api.wordpress.org` lúc build)
  vào `wp-config.php.template`, file này nằm ngay trong docroot với đuôi
  `.template` (KHÔNG khớp `location ~ \.php$`) nên nginx phục vụ nguyên văn
  cho BẤT KỲ AI qua URL Cloudflare Tunnel công khai — không chỉ LAN như
  `_admin/`. Vá 2 lớp: (1) `nginx.conf.template` thêm
  `location ~* \.template$ { deny all; }` chặn mọi file `.template` ở bất kỳ
  đâu trong docroot, cộng `location ^~ /_supervisor/ { deny all; }` chặn cả
  thư mục chứa config gốc; (2) `start-lamp.sh` **xoá hẳn**
  `wp-config.php.template` ngay sau khi sinh `wp-config.php` thật (phòng khi
  luật nginx sau này lỡ bị sửa/xoá mất). Đã test bằng nginx thật (xem dưới),
  xác nhận cả `/wp-config.php.template` lẫn `/_supervisor/nginx.conf.template`
  trả về 403, file thường (`/index.html`) vẫn 200, luật LAN-only cũ của
  `_admin/` không bị ảnh hưởng.
- 🟡 **Bug do vòng sửa này gây ra — `install-wp.php` dùng
  `sys_get_temp_dir()`**: `php-fpm.conf.template` mặc định `clear_env=yes`
  (mặc định của chính php-fpm), chỉ đúng 1 biến `APP_HOME` được truyền qua
  (`env[APP_HOME] = ...`) — biến `TMPDIR` Kotlin đặt cho TIẾN TRÌNH CHA
  KHÔNG tự động truyền xuống PHP, nên `sys_get_temp_dir()` nhiều khả năng
  trả về `/tmp` (không ghi được trong sandbox app Android). Sửa: dùng hẳn
  thư mục `_admin/.install-tmp/` (chắc chắn ghi được, cùng cơ chế mà
  `auth.php` đã dùng thành công từ trước) thay vì phụ thuộc temp dir hệ
  thống.

**Đã TEST BẰNG BINARY THẬT** (khác "CHƯA verify" thuần suy luận — môi trường
viết bản cập nhật này cài được `nginx`/`php-fpm`/`mariadb` bản Ubuntu x86 qua
`apt` để kiểm tra cú pháp, dù KHÔNG phải bản Termux ARM thật sẽ chạy trên
điện thoại):

- `nginx -t` với file `nginx.conf.template` đã resolve placeholder: cú pháp
  hợp lệ. Chạy nginx thật + `curl`: xác nhận 2 luật chặn mới (`.template`,
  `_supervisor/`) trả 403 đúng như thiết kế, file thường vẫn 200, luật
  `_admin/` cũ không bị ảnh hưởng.
- `php-fpm -t` với `php-fpm.conf.template` + `php.ini.template` đã resolve:
  cú pháp hợp lệ (kể cả `pm=ondemand`, `curl.cainfo`/`openssl.cafile`,
  toàn bộ khối `opcache.*`) — chỉ thiếu các file `.so` extension thật của
  Termux (đúng như dự kiến, container test này là x86 không phải ARM).
- Khởi động `mariadbd` thật với đúng các cờ mới thêm
  (`--innodb-buffer-pool-size=32M`, `--key-buffer-size=8M`,
  `--max-connections=20`, `--table-open-cache=128`,
  `--skip-performance-schema`, `--skip-name-resolve`): lên thành công,
  tạo database + user `wordpress` giống hệt khối SQL trong `start-lamp.sh`,
  chạy `mysqldump --socket=... -uroot --databases wordpress` (đúng lệnh
  `BackupManager.kt` dùng) ra file dump đúng dữ liệu test. **Đã bỏ cờ
  `--innodb-buffer-pool-instances`** sau khi test cho thấy MariaDB 10.11 báo
  đây là cờ đã bị loại bỏ (no-op, chỉ giữ tương thích ngược) — bớt 1 dòng
  warning vô ích trong log.

**Vẫn CHƯA verify được** (giới hạn thật của môi trường viết bản cập nhật
này — không có Android SDK, không có thiết bị ARM thật, không vào được
`dl.google.com`/Google Play Services):

- `zend_extension = opcache.so` giả định Termux đóng gói OPcache dưới dạng
  file `.so` RỜI. Nếu bản build PHP của Termux tích hợp OPcache tĩnh sẵn
  trong binary `php-fpm`, dòng này chỉ gây warning vô hại lúc khởi động —
  xem `$RUNDIR/php-fpm.log` nếu cần xác nhận sau lần build đầu.
- Cờ CLI của `mariadbd` đã test cú pháp đúng trên MariaDB 10.11 (Ubuntu
  x86) — bản Termux ARM có thể là phiên bản MariaDB khác, dù các cờ dùng ở
  đây đều rất chuẩn/ổn định nên rủi ro khác biệt thấp.
- `/proc/meminfo` có đọc được KHÔNG CẦN QUYỀN trên MỌI phiên bản
  Android/kernel hay không — đa số thiết bị cho đọc, nhưng có thể khác nhau
  tuỳ nhà sản xuất/bản ROM. Nếu không đọc được, dashboard tự ẩn phần RAM
  (không lỗi trang, đã có `if ($mem && ...)` guard).
- `androidx.work:work-runtime-ktx:2.9.1` — chọn vì khớp an toàn với
  compileSdk 34 hiện tại của repo, nhưng CHƯA build-test thật.
- Luồng tải WordPress trực tiếp từ `_admin/install-wp.php` phụ thuộc
  `allow_url_fopen` hoặc extension `curl.so` hoạt động đúng trên thiết bị —
  cả 2 đều nằm trong danh sách "CHƯA verify" cũ ở mục 7 (extension `.so` của
  PHP). Nếu cả 2 đều không hoạt động, trang sẽ báo lỗi rõ ràng (không im
  lặng thất bại) thay vì giả vờ thành công. CA cert bundle (`cacert.pem`,
  tải lúc build từ `curl.se/ca/cacert.pem`) đã thêm để tránh lỗi xác thực
  SSL — chưa test end-to-end việc tải `wordpress.org` thật qua `curl.so`
  của Termux.
- Gọi Telegram Bot API (`sendMessage`/`sendDocument`) viết đúng theo đặc tả
  chính thức nhưng CHƯA gọi thử qua mạng di động Việt Nam thật.

## 1g. Đồng bộ Cloud "Webhook tổng quát" (thay cho Google Drive OAuth thật)

PDF đề xuất đồng bộ backup lên **Google Drive/AWS S3/FTP**. Đã cân nhắc làm
Google Sign-In + Drive API "xịn" (API chính thức hiện tại của Google là
`AuthorizationClient`, KHÔNG phải `GoogleSignInClient` cũ — Google đã tách
authentication (Credential Manager) và authorization (AuthorizationClient)
thành 2 API riêng từ ~2024, xem `developer.android.com/identity/authorization`)
nhưng **KHÔNG làm**, vì 3 lý do kỹ thuật thật, không phải ngại khó:

1. Cần thêm `com.google.android.gms:play-services-auth` — phụ thuộc Google
   Play Services, NẶNG hơn hẳn mọi thứ đã có trong app (hiện chỉ dùng
   androidx thuần), và không đảm bảo có sẵn trên MỌI điện thoại Android (máy
   không cài dịch vụ Google sẽ không dùng được tính năng này).
2. OAuth Client ID kiểu "Android" **bắt buộc khớp SHA-1 chữ ký APK** — dự án
   này **CHƯA có code signing ổn định** (mục 7.6 dưới, chỉ mới
   `assembleDebug`). Trên GitHub Actions, keystore debug được TỰ SINH MỚI
   mỗi lần chạy runner (không có bước cache/commit keystore cố định) → SHA-1
   đổi MỖI LẦN build lại → phải cấu hình lại OAuth Client ID liên tục, không
   thực tế chút nào cho tới khi mục 7.6 được giải quyết trước.
3. Scope Drive là scope "nhạy cảm" (sensitive scope) — Google yêu cầu xác
   minh ứng dụng (App Verification) nếu vượt quá số lượng nhỏ tài khoản thử
   nghiệm (test users) ở chế độ Testing — quá nhiều rào cản bên ngoài cho 1
   app cá nhân tự build chạy trên chính điện thoại của mình.

**Giải pháp thay thế**: `WebhookUploader.kt` (mới) — gửi file backup qua
HTTP POST `multipart/form-data` (field `"file"`) tới **BẤT KỲ URL nào**
người dùng tự điền, dùng chung `BackupWorker` với Telegram (cả 2 chạy song
song nếu người dùng điền cả 2). Cách này đạt đúng mục tiêu "đẩy backup ra
khỏi điện thoại" mà KHÔNG cần OAuth/Play Services/code signing, và VẪN đưa
được backup vào Google Drive thật nếu người dùng trỏ webhook tới 1 **Google
Apps Script Web App** tự viết (mẫu rất phổ biến: hàm `doPost(e)` +
`DriveApp.createFile(...)`, script chạy dưới quyền TÀI KHOẢN GOOGLE CỦA
NGƯỜI DÙNG khi họ tự deploy trong script.google.com của chính họ — hoàn
toàn không cần Android app biết gì về OAuth) — hoặc n8n/Make.com/Zapier nếu
muốn nối tiếp sang S3/Dropbox/nơi khác.

**Đã test bằng server thật**: dựng 1 HTTP server Python (`http.server` +
`cgi.parse_multipart`), gửi đúng byte-format mà `WebhookUploader.uploadFile()`
tạo ra (boundary, header, CRLF) — server phân tích đúng field `file`, đúng
số byte nội dung. Vì `TelegramNotifier.sendDocument()` dùng CHUNG cấu trúc
multipart này, test này cũng xác nhận gián tiếp cho cả 2 hàm.

**Nếu sau này mục 7.6 (code signing) được giải quyết** và có nhu cầu thật
mạnh, có thể quay lại làm Google Sign-In/Drive API chính thống — lúc đó rào
cản #2 ở trên không còn nữa, chỉ còn #1 và #3 cần cân nhắc.

## 1h. Sửa lại 3 ý tưởng bị từ chối trước đó — thay bằng cách AN TOÀN đạt cùng mục tiêu

Người dùng yêu cầu (đúng nguyên văn): với các ý tưởng bị từ chối vì "API
sai hay có rủi ro", tìm giải pháp khác đạt cùng mục tiêu mà KHÔNG rủi ro.
Rà lại toàn bộ danh sách "cố ý không làm" ở mục 1e/1f theo tiêu chí này:

**KHÔNG có cách an toàn (giữ nguyên từ chối, đã tra thêm bằng chứng):**
- ❌ **ZRAM hint qua `onTrimMemory`** — tra cứu xác nhận: cơ chế Linux đúng
  cho việc này là `process_madvise(MADV_COLD/MADV_PAGEOUT)`, nhưng tài liệu
  patch chính thức của kernel ghi rõ *"Only privileged processes can do
  something for other process's address space"* — ứng dụng thường (kể cả
  không root) **không có quyền** gọi hint này lên tiến trình CON
  (mariadbd/php-fpm/nginx) của chính nó, chỉ daemon hệ thống
  (`lmkd`/`ActivityManagerService`) mới gọi được. Đây là giới hạn nền tảng
  thật, không phải do chưa tìm đúng API. Giữ nguyên từ chối.
- ❌ **SQLite on-demand switching, LAN cluster, `.template` cluster đa
  thiết bị** — không phải vấn đề "API sai" mà là rủi ro thiết kế/ngoài phạm
  vi thật (xung đột dữ liệu, vượt yêu cầu gốc "1 website duy nhất") — không
  có "cách làm đúng API" nào thay đổi được bản chất rủi ro này.

**CÓ cách an toàn — đã làm:**

1. **"RAM Disk cho log/cache" → không làm được đúng nghĩa (Android không
   cấp quyền mount tmpfs cho app thường), nhưng đạt được lợi ích tương tự
   bằng tính năng CÓ SẴN, CHÍNH THỨC của nginx**: `access_log` hỗ trợ
   `buffer=` + `flush=` — gom log trong bộ nhớ nginx tự quản lý rồi mới ghi
   xuống flash theo lô, thay vì ghi từng dòng ngay lập tức. Sửa
   `nginx.conf.template`:
   `access_log __RUNDIR__/nginx-access.log combined buffer=64k flush=5m;`
   — **Test bằng `nginx -t` thật**: phát hiện cú pháp đúng phải khai báo
   tường minh format `combined` trước `buffer=`/`flush=` (thiếu sẽ bị nginx
   hiểu nhầm `buffer=64k` là TÊN format, lỗi `unknown log format`) — sửa và
   test lại xác nhận OK.

2. **"OverlayFS/symlink `wp-content/uploads` sang `cacheDir`" → vẫn TỪ CHỐI
   phần uploads (rủi ro mất ảnh/video người dùng là thật, không đổi), nhưng
   áp dụng AN TOÀN cho `wp-content/cache`** (dữ liệu cache thuần tuý, mọi
   plugin cache của WordPress đều tự tạo lại được nếu mất — đúng bản chất
   "cache" là đồ bỏ được). Thêm vào `start-lamp.sh` (dùng chung cả 2 chế
   độ): symlink `wp-content/cache` → `$TMPDIR` (cacheDir Android, đã có sẵn
   qua env Kotlin đặt), tự tạo lại thư mục đích mỗi lần chạy (phòng khi
   Android đã xoá cacheDir giữa các lần). **Test bằng `sh` thật**: xác nhận
   symlink hoạt động, ghi/đọc qua symlink đúng, và **uploads/ hoàn toàn
   không bị đụng tới** (test tách biệt 2 thư mục rõ ràng), mô phỏng Android
   xoá cacheDir giữa chừng → thư mục đích tự tạo lại đúng, symlink không vỡ.

3. **"Webhook 2 chiều nhận lệnh Telegram" → vẫn TỪ CHỐI đúng nghĩa webhook
   (mở URL công khai/tiến trình lắng nghe liên tục là rủi ro thật), nhưng
   thay bằng LONG-POLLING** (`TelegramCommandWorker.kt`, mới) — phone chủ
   động HỎI Telegram định kỳ qua `getUpdates` (cách dùng CHÍNH THỨC,
   phổ biến của Telegram Bot API cho bot không có server riêng), KHÔNG mở
   port/URL nào cả nên KHÔNG có bề mặt tấn công mới. Hỗ trợ `/status`
   (RAM/dung lượng/pin/trạng thái server), `/backup` (backup ngay + gửi
   file), `/restart` (khởi động lại service). **Bảo mật**: so sánh `chatId`
   dạng SỐ (không phải chuỗi) với giá trị đã cấu hình trong app — lệnh từ
   chatId khác bị bỏ qua HOÀN TOÀN, không phản hồi gì (tránh lộ thông tin
   "server này tồn tại" cho người lạ dù họ có được Bot Token). Dùng
   `org.json` có sẵn trong Android SDK để parse JSON, KHÔNG thêm thư viện
   ngoài. Lên lịch/huỷ theo đúng lúc Telegram được cấu hình/xoá cấu hình
   trong app (cùng chỗ với `BackupWorker`).

**Vẫn CHƯA verify** (giới hạn môi trường viết bản cập nhật, không có thiết
bị Android thật): logic parse JSON của `getUpdates()` viết đúng theo field
path thật của Telegram Bot API (`result[].update_id`,
`result[].message.chat.id`, `result[].message.text` — API rất ổn định,
nhiều năm không đổi cấu trúc cơ bản này) và đúng method signature của
`org.json.JSONObject`/`JSONArray` (API lõi Android từ API 1, không đổi) —
nhưng chưa chạy thử JVM/thiết bị thật để xác nhận biên dịch/chạy đúng 100%.

## 1i. Audit toàn diện (vòng phản hồi thứ 6): không tin lời tự thuật, kiểm tra lại

Người dùng yêu cầu xác nhận: (1) không sót việc, (2) không có tính năng nào
thiếu UI/chưa nối dây ("vỏ rỗng"), (3) tài liệu không lệch pha với code
thật. Rà lại toàn bộ bằng cách đọc lại code (không chỉ đọc lại những gì đã
tự ghi) — tìm và sửa được:

**"Vỏ rỗng" thật tìm thấy (có logic nhưng thiếu phản hồi cho người dùng):**
- RadioGroup Dual-Mode PHP-Lite chỉ lưu **lựa chọn** (Auto/Bật/Tắt) — ở chế
  độ Auto, người dùng không có cách nào biết KẾT QUẢ THẬT (Lite hay Full)
  ngoại trừ tự mở dashboard web riêng. Đã thêm `tvRuntimeMode` trong
  `MainActivity` — đọc trực tiếp file `filesDir/lamp-run/lite-mode` (cùng
  file `start-lamp.sh` ghi ra, không qua IPC nào) để hiện ngay trong app.

**Lỗ hổng lên lịch WorkManager tìm thấy:**
- `BackupWorker`/`TelegramCommandWorker` trước đó CHỈ được đăng ký lại từ
  `MainActivity.onCreate()`. Android "Buộc dừng" (Settings > Ứng dụng) huỷ
  HẾT WorkManager job đã đăng ký — nếu sau đó máy khởi động lại (auto-start
  qua `BootReceiver` bật server) mà người dùng CHƯA mở lại app, 2 job này sẽ
  không được đăng ký lại. Gom logic vào `WorkScheduler.kt` (mới), gọi từ CẢ
  `MainActivity.onCreate()` LẪN `ServerForegroundService.onCreate()` (chạy
  trong mọi trường hợp service được tạo, kể cả từ BootReceiver).

**Tài liệu lệch pha với code (đã sửa toàn bộ):**
- Mục "0d" (dòng cũ, trước mục 2) và mục 1b vẫn ghi "CHƯA implement
  dual-mode" — SAI, đã làm ở mục 1f. Đã sửa cả 2 chỗ.
- Mục 8 liệt kê Dual-Mode PHP-Lite + webhook Telegram 2 chiều vào danh sách
  "cố ý không làm" — SAI theo nghĩa đen (ý tưởng GỐC bị từ chối, nhưng đã
  làm bằng CÁCH KHÁC an toàn hơn ở mục 1f/1h). Viết lại toàn bộ mục 8 phân
  biệt rõ "còn từ chối" / "đã làm bằng cách khác".
- Mục 5 vẫn ghi "không dùng SQLite drop-in nữa" mà không nhắc mục 1f (SQLite
  quay lại CHỈ cho Dual-Mode PHP-Lite) — dễ gây hiểu lầm mâu thuẫn nếu đọc
  mục 5 trước mục 1f. Đã thêm chú thích chéo.
- Mục 8 có 1 đoạn văn bị lặp/cắt câu dở dang do 1 lần sửa `str_replace`
  trước đó khớp nhầm đoạn ngắn hơn dự định (tự phát hiện khi đọc lại toàn
  bộ file tuần tự, không phải qua công cụ tự động) — đã dọn sạch.

**Đã kiểm tra và XÁC NHẬN KHÔNG có vấn đề (để khỏi phải rà lại lần sau):**
- Mọi file `.kt` mới đều được tham chiếu từ ít nhất 1 nơi khác (không có
  file mồ côi) — kiểm bằng `grep` chéo toàn bộ thư mục.
  `WebhookUploader`/`TelegramCommandWorker`/`BackupWorker`/`HealthCheckWorker`
  đều có nơi gọi `schedule()`/`cancel()`/hàm chính từ code thật, không chỉ
  tồn tại như file độc lập.
  Không còn `TODO`/`FIXME`/"chưa làm xong" sót lại trong `app/src` hay
  `scripts/` (grep toàn bộ, 0 kết quả).
- Mọi `binding.xxx` dùng trong `MainActivity.kt` đều có `android:id` tương
  ứng trong `activity_main.xml` và ngược lại (chỉ 2 trường hợp lệch là
  `tvTitle`/`tvPublicLabel` — nhãn tĩnh, không cần code đụng tới, không phải
  lỗi).

## 1j. Auto-Sleep MariaDB khi rảnh (vòng phản hồi thứ 7 — hiện thực hoá đề
xuất "Cơ chế Ngủ đông thông minh" từng bị hoãn ở mục 1e)

Thiết kế: opt-in hoàn toàn (mặc định TẮT, xem `Prefs.KEY_AUTO_SLEEP_ENABLED`)
— ai không bật thì `start-lamp.sh`/`nginx.conf`/`php.ini` sinh ra giống HỆT
trước khi có tính năng này, không thêm rủi ro cho luồng đã ổn định.

**Phát hiện quan trọng lúc thiết kế** (đọc lại `start-lamp.sh` trước khi động
tay, không giả định): tưởng ban đầu là nginx được `exec` thay thế shell ở
cuối script (nên sợ phải tái cấu trúc lớn để có 1 "supervisor" sống sót giám
sát định kỳ) — hoá ra nginx ĐÃ được chạy nền (`&`) từ trước, script kết thúc
bằng 1 vòng lặp giám sát mỗi 3 giây (kiểm tra `kill -0` cho cả 3 tiến trình).
Nhờ vậy chỉ cần MỞ RỘNG vòng lặp có sẵn này, không cần tái cấu trúc gì cả —
giảm rủi ro đáng kể so với thiết kế ban đầu trong đầu.

Điểm mấu chốt để không tự phá chính mình: cờ `MARIADB_SLEEPING` trong vòng
lặp giám sát. Vòng lặp gốc coi "MariaDB đã thoát" là crash → tắt hết
php-fpm+nginx → để Kotlin restart toàn cụm. Nếu KHÔNG có cờ này, chính hành
động Auto-Sleep tự tắt MariaDB sẽ NGAY LẬP TỨC bị hiểu nhầm là crash, phá
sạch tác dụng của tính năng vừa bật.

Chuỗi xử lý "đánh thức": nginx phát hiện file `mariadb-asleep` tồn tại (chỉ 1
lần `stat()` rẻ mỗi request `.php`, vô hại khi tính năng tắt vì file này
không bao giờ được tạo) → `rewrite ... last` nội bộ sang `wake-mariadb.php`
(`internal;`, không gọi trực tiếp từ ngoài được) → PHP spawn lại MariaDB qua
`wake-mariadb.sh` (file DUY NHẤT chứa lệnh khởi động mariadbd, dùng chung với
lần khởi động đầu tiên trong `start-lamp.sh` — tránh 2 nơi chứa cùng 1 lệnh
dài dễ lệch nhau khi sửa sau này) → poll bằng `mysqli_connect` thật (không
chỉ check file socket tồn tại — có khoảng trễ ngắn giữa lúc socket được tạo
và lúc MariaDB thật sự nhận kết nối) → xoá cờ `mariadb-asleep` → redirect
khách về ĐÚNG URL gốc họ định xem (nginx truyền qua `fastcgi_param
ORIGINAL_URI $request_uri` — biến này giữ nguyên URI gốc bất kể rewrite nội
bộ, không phải tự chế).

**Lỗi thiết kế tự bắt được trước khi ship** (không phải chỉ đọc lại bằng
mắt — đã nghĩ tới rồi tự sửa): định đặt `wake-mariadb.php` trong `_admin/`
cho gọn, nhưng `_admin/` bị chặn CHỈ CHO LAN (xem mục 1c) — nếu để nhầm ở đó,
tính năng sẽ KHÔNG BAO GIỜ hoạt động được với khách thật qua Cloudflare Tunnel
(chính đối tượng cần đánh thức MariaDB!). Đã sửa: đặt ở gốc docroot, đánh dấu
`internal` trong nginx.

Cơ chế theo dõi "rảnh bao lâu": KHÔNG dùng `access_log` (đã có
`buffer=64k flush=5m` từ trước để giảm hao mòn flash — dùng log làm nguồn tin
sẽ trễ tới 5 phút, không hợp với nhu cầu biết "rảnh" trong vài chục giây-vài
phút). Thay bằng 1 script PHP cực nhẹ (`activity-touch.php`, nạp qua
`auto_prepend_file` CHỈ khi bật tính năng) — chỉ gọi `touch()` (cập nhật
mtime, không ghi nội dung) mỗi request PHP thật, rẻ hơn nhiều so với ghi log.

Đã kiểm chứng (chưa build-test thật trên thiết bị, xem mục 8 nguyên tắc
chung): `php -l` sạch cho 2 file PHP mới + toàn bộ file `.php` khác;
`sh -n` sạch cho `start-lamp.sh` sau khi sửa; mô phỏng đầy đủ pipeline `sed`
sinh `nginx.conf`/`php.ini` ở cả 2 nhánh bật/tắt — ngoặc cân bằng, không còn
placeholder sót; cross-check `binding`/`R.string` cho phần UI Kotlin mới —
sạch; đếm ngoặc `{}`/`()` sau khi lọc bỏ dòng comment cho 3 file `.kt` bị sửa
— cân bằng cả 3. `stat -c %Y` (dùng để đọc mốc hoạt động) đã tra cứu xác
nhận là cú pháp hợp lệ của `toybox` (công cụ dòng lệnh chuẩn của Android từ
6.0 trở lên, hỗ trợ `-c FORMAT` y hệt GNU coreutils, `%Y` = "Mod unix time")
— tự tin hơn hẳn so với chỉ đoán, dù vẫn chưa chạy thật trên thiết bị.

**Vòng audit lại (theo yêu cầu người dùng "kiểm tra vỏ rỗng") phát hiện 3 lỗi
thật, đã sửa:**
1. Comment giải thích cho `__CF_REALIP_DIRECTIVES__` (thêm ở mục này) và
   comment đầu `wake-mariadb.sh.template` (của chính vòng làm việc này) đều
   VÔ TÌNH viết lại nguyên văn tên placeholder mà chúng đang mô tả — bị
   chính `sed ... g` của nó thay đè, tạo ra dòng comment vô nghĩa (không
   crash vì vẫn là comment hợp lệ, nhưng sai/rối). Cùng lỗi này cũng có SẴN
   TỪ TRƯỚC (không phải do vòng này gây ra) ở 3 chỗ khác trong
   `php.ini.template` (`__EXT_DIR__`, `__RUNDIR__` x2) — đã sửa hết, đổi
   sang mô tả không lặp lại token literal.
2. `wake-mariadb.php` dùng `mysqli_connect(null, ..., $socket)` (kiểu tham
   số socket riêng) để kiểm tra MariaDB sẵn sàng — đổi sang
   `mysqli_connect('localhost:' . $socket, ...)` cho khớp ĐÚNG kiểu gọi mà
   `wp-config.php.template` đang dùng thật cho cả website (đã có bằng chứng
   hoạt động), thay vì dùng 1 kiểu gọi khác chưa từng chứng minh trong
   chính dự án này dù cả hai đều đúng theo tài liệu PHP.

Giới hạn CHƯA giải quyết (để ở mục 7): `_admin/` (Adminer...) chưa tích hợp
cơ chế đánh thức — vào đúng lúc MariaDB ngủ sẽ thấy lỗi kết nối, phải tự tải
lại; dùng khoá advisory (`fopen` mode `x`) để giảm spawn trùng khi nhiều
khách cùng lúc đánh thức, nhưng lớp bảo vệ CHÍNH vẫn là cơ chế tự chống chạy
trùng có sẵn của MariaDB — rủi ro tồn dư cực thấp, không phải zero tuyệt đối.

## 2. Trạng thái hiện tại

**Đã viết xong, CHƯA build-test thật bằng Android SDK/thiết bị Android**
(môi trường tạo ra project này không có Android SDK / không truy cập được
`dl.google.com`, `maven.google.com` nên không compile-verify được phần
Kotlin). Lần build Kotlin thật đầu tiên = khi người dùng push lên GitHub và
Actions chạy. Riêng phần **bash/PHP/nginx/php-fpm/mariadb** (mục 1e-1i) ĐÃ
được test bằng binary thật (cài qua `apt` trên Ubuntu x86, không phải bản
Termux ARM) — mức độ tin cậy khác nhau rõ rệt giữa 2 phần này, xem từng mục
1e-1i để biết chính xác cái gì đã test bằng công cụ thật, cái gì chỉ là suy
luận theo tài liệu.

## 3. Kiến trúc

```
site.config.json (root, DUY NHẤT người dùng sửa)
        │
        ▼ (đọc bởi GitHub Actions)
.github/workflows/build-apk.yml
        │
        ├─▶ scripts/runtimes/{php,node,python,static}.sh   (chọn theo .runtime)
        │        ├─ scripts/lib/termux_fetch.sh   → tải binary từ kho Termux
        │        └─ scripts/lib/site_source.sh    → tải mã nguồn website
        │        └─ xuất: libruntimesrv.so + www.zip + runtime.json
        │
        ├─▶ scripts/prepare_cloudflared.sh          → libcfd.so (Go, static)
        │
        └─▶ gradle assembleDebug  → APK (upload artifact)

Trong app lúc chạy:
  ServerForegroundService (Foreground Service + WakeLock)
    ├─ prepareRuntimeIfNeeded(): giải nén www.zip lần đầu + ensureAdminPassword()
    │    (sinh mật khẩu quản trị ngẫu nhiên nếu chưa có, → filesDir/admin-password.txt)
    ├─ đọc assets/runtime.json → RuntimeConfig.kt → ProcessBuilder
    │    (KHÔNG biết đó là PHP/Node/Python — hoàn toàn generic. Với PHP:
    │    exec = /system/bin/sh start-lamp.sh → tự chạy mariadbd+php-fpm+nginx,
    │    trong đó nginx phục vụ cả website chính LẪN /_admin/ (Adminer +
    │    File Manager + Logs + Info, chỉ vào được qua LAN, xem mục 1c))
    └─ chạy song song libcfd.so → đọc SharedPrefs KEY_TUNNEL_TOKEN:
         ├─ có token  → `cloudflared tunnel run --token ...` (named, domain cố định)
         └─ không có  → `cloudflared tunnel --url ...` (Quick Tunnel, URL ngẫu nhiên)
```

**Nguyên tắc bất biến:** mọi thứ "biết" về backend cụ thể nằm ở
`scripts/runtimes/*.sh` (build-time, bash). App (Kotlin, runtime) tuyệt đối
generic — chỉ đọc `runtime.json`. Nếu sửa code mà thấy mình đang viết
`if (runtime == "php")` trong Kotlin → **sai hướng, dừng lại**.

**Lớp WorkManager (mục 1e/1h, độc lập vòng đời với `ServerForegroundService`
ở trên)** — chạy nền định kỳ, KHÔNG cần server đang bật hay app đang mở:
```
WorkScheduler.ensureScheduledFromPrefs() — gọi từ CẢ 2 nơi:
  MainActivity.onCreate() (mở app) VÀ ServerForegroundService.onCreate()
  (tự bật qua BootReceiver) — tránh lỗ hổng Android "Buộc dừng" huỷ hết job
    ├─ HealthCheckWorker (mỗi 15 phút): KEY_SERVER_WANTED=true nhưng
    │    isRunning=false → tự startForegroundService() lại (watchdog)
    ├─ BackupWorker (mỗi N giờ, nếu bật): BackupManager.performBackup()
    │    → TelegramNotifier.sendDocument() + WebhookUploader.uploadFile()
    │    (mỗi cái độc lập, chỉ chạy nếu đã cấu hình)
    └─ TelegramCommandWorker (mỗi 15 phút, nếu đã cấu hình Telegram):
         getUpdates() long-polling → /status /backup /restart
```

## 4. File map (chỉ những file quan trọng)

| File | Vai trò |
|---|---|
| `site.config.json` | Config DUY NHẤT: runtime, port, entry, site_source |
| `.github/workflows/build-apk.yml` | Pipeline CI — đọc config, dispatch, build |
| `scripts/lib/termux_fetch.sh` | Tải .deb từ kho Termux + walk `Depends` |
| `scripts/lib/site_source.sh` | Lấy mã nguồn theo `site_source.type` |
| `scripts/lib/admin_tools.sh` | Tải Adminer + Tiny File Manager, gắn `auth.php`, sinh `_admin/index.php` |
| `scripts/runtimes/*.sh` | 1 file/runtime — binary + `runtime.json` |
| `scripts/runtimes/templates/start-lamp.sh` | Supervisor 1 tiến trình chạy mariadbd+php-fpm+nginx (chỉ runtime `php`) |
| `scripts/runtimes/templates/*.template` | nginx.conf / php-fpm.conf / php.ini — có `__PLACEHOLDER__`, resolve lúc runtime bởi `start-lamp.sh` |
| `scripts/runtimes/templates/admin-*.php` | auth.php (cổng đăng nhập + IP-check, mục 1f), logs.php, info.php, **install-wp.php** (1-Click Installer, mục 1e) — công cụ quản trị tự viết |
| `scripts/runtimes/templates/router-lite.php` | **(mới, mục 1f)** Router cho `php -S` ở Dual-Mode PHP-Lite — mô phỏng pretty-permalink + chặn `_supervisor/`/`*.template` |
| `scripts/prepare_cloudflared.sh` | Tải cloudflared (KHÔNG qua Termux) |
| `RuntimeConfig.kt` | Parse `runtime.json`, thay placeholder `${BIN} ${PORT} ${DOCROOT} ${FILESDIR}` |
| `Prefs.kt` | Key SharedPreferences: `KEY_AUTO_START`, `KEY_TUNNEL_TOKEN`, + mục 1e: `KEY_SERVER_WANTED`, `KEY_BACKUP_AUTO_ENABLED`, `KEY_BACKUP_INTERVAL_HOURS`, `KEY_TELEGRAM_BOT_TOKEN`, `KEY_TELEGRAM_CHAT_ID`, + mục 1f: `KEY_PHP_LITE_MODE` |
| `BackupManager.kt` | **(mới, mục 1e)** Logic backup (zip + mysqldump) dùng chung cho nút bấm tay và `BackupWorker` |
| `BackupWorker.kt` | **(mới, mục 1e)** WorkManager — backup định kỳ tự động, gửi qua Telegram nếu đã cấu hình |
| `HealthCheckWorker.kt` | **(mới, mục 1e)** WorkManager — watchdog định kỳ 15 phút, tự khởi động lại service nếu bị hệ thống giết chết dù người dùng vẫn muốn chạy |
| `TelegramNotifier.kt` | **(mới, mục 1e)** Gọi Telegram Bot API (`sendMessage`/`sendDocument`) bằng `HttpURLConnection` thuần |
| `WebhookUploader.kt` | **(mới, mục 1g)** Gửi backup qua HTTP POST tới URL bất kỳ (thay Google Drive OAuth — xem lý do mục 1g) |
| `TelegramCommandWorker.kt` | **(mới, mục 1h)** Long-polling `getUpdates` — điều khiển từ xa `/status /backup /restart` an toàn hơn webhook |
| `WorkScheduler.kt` | **(mới, mục 1i)** Gom logic đăng ký/huỷ WorkManager job theo Prefs — dùng chung `MainActivity` + `ServerForegroundService`, tránh lỗ hổng "Buộc dừng" |
| `ServerForegroundService.kt` | Chạy site process (generic) + tunnel process (quick/named tuỳ token) + `ensureAdminPassword()` + mục 1e: đặt `KEY_SERVER_WANTED`, đăng ký `HealthCheckWorker`, báo Telegram lúc có URL công khai |
| `MainActivity.kt` | UI: start/stop, IP LAN + URL public, auto-start, bỏ qua tối ưu pin, **backup ngay**, **mật khẩu quản trị + mở `/_admin/`**, **ô nhập token tunnel**, + mục 1e: **bật/tắt backup tự động + khoảng cách giờ + Telegram Bot Token/Chat ID** |

## 5. Kỹ thuật cốt lõi đã dùng (và LÝ DO — đừng tốn thời gian tìm lại)

- **Binary chạy như tiến trình con**: đặt tên `lib*.so` trong `jniLibs/<abi>/`
  → PackageManager tự copy vào `nativeLibraryDir` + cấp quyền thực thi, né
  W^X (Android 10+ chặn exec file tự giải nén ra thư mục ghi được).
  Cần `android:extractNativeLibs="true"` trong Manifest để có file thật trên
  đĩa cho `ProcessBuilder` (nếu để false, lib chạy trực tiếp từ zip APK qua
  mmap — không dùng được với ProcessBuilder).
- **Chạy nền khi tắt màn hình** = Foreground Service (`specialUse` type,
  Android 14+ bắt buộc khai báo `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`) +
  `PARTIAL_WAKE_LOCK` + notification cố định + `START_STICKY`. Đã xác nhận
  khả thi 100%, không phải giới hạn kỹ thuật — đừng nghi ngờ lại điểm này.
- **PHP runtime (mặc định `"runtime": "php"`)**: nginx + php-fpm + MariaDB
  thật, không phải `php -S` dev server nữa (đã nâng cấp — xem mục 1b).
  Cả 3 daemon được **1 script supervisor duy nhất**
  (`scripts/runtimes/templates/start-lamp.sh`, chạy qua `/system/bin/sh` có
  sẵn trên mọi Android) khởi chạy + giám sát, để `ServerForegroundService`
  vẫn chỉ cần `ProcessBuilder` MỘT tiến trình (giữ kiến trúc generic không
  đổi — xem mục 3). Config nginx/php-fpm/php.ini/wp-config.php là
  **template** (`__PLACEHOLDER__`), được `start-lamp.sh` `sed` thành giá trị
  thật lúc app chạy lần đầu trên THIẾT BỊ THẬT — vì đường dẫn
  (`nativeLibraryDir`, `filesDir`, socket path) chỉ biết được lúc đó, không
  biết được lúc CI build.
- **Node/Python/static** vẫn dùng cơ chế đơn giản cũ (1 binary, không
  nginx/php-fpm) — KHÔNG nâng cấp tương tự PHP, vì Node/Python thường tự có
  framework server riêng đủ dùng (Express, Django runserver...) khi có
  `entry`; trường hợp không có `entry` (Python fallback `http.server`) vẫn
  còn hạn chế tương tự `php -S` cũ nhưng ngoài phạm vi ưu tiên hiện tại.
- **PHP/Node/Python binary**: mượn từ kho gói mã nguồn mở Termux
  (`https://packages.termux.dev/apt/termux-main`, định dạng apt/.deb).
  Lý do: tự cross-compile bằng NDK tốn quá nhiều công cho scope này.
  → **Rủi ro đã biết**: binary build cho layout thư mục Termux
  (`$PREFIX=/data/data/com.termux/files/usr`), tách ra dùng riêng CÓ THỂ
  thiếu `.so` phụ thuộc gián tiếp. Đã giảm thiểu bằng: (a) tải cả
  `Depends` field của gói chính, (b) set `LD_LIBRARY_PATH=nativeLibraryDir`
  lúc exec. **CHƯA verify end-to-end.** Với nginx/php-fpm/mariadb, rủi ro
  này áp dụng cho CẢ 3 gói, không chỉ 1 — nhiều bề mặt lỗi hơn bản cũ.
- **cloudflared**: KHÔNG qua Termux — tải thẳng binary release chính thức
  (`cloudflared-linux-arm64`/`cloudflared-linux-arm` từ GitHub release của
  Cloudflare). Lý do: binary Go, nhiều khả năng static-linked, tránh hẳn vấn
  đề thiếu `.so` ở trên. 2 chế độ: **Quick Tunnel** mặc định (`tunnel --url
  ...`, không cần tài khoản, URL đổi mỗi lần chạy) hoặc **Named Tunnel** nếu
  người dùng lưu token trong app (`tunnel run --token ...`, domain cố định).
  Giải quyết CGNAT (đa số mạng di động/cáp quang hộ gia đình VN không có IP
  công khai) mà không cần port-forward.
- ~~SQLite Database Integration~~ — **ĐÃ THAY** bằng MariaDB thật (xem mục
  1b). Không dùng SQLite drop-in nữa cho runtime PHP **mặc định**. (Cập nhật
  mục 1f: SQLite CÓ quay lại, nhưng CHỈ làm phương án dự phòng cho Dual-Mode
  PHP-Lite trên máy quá yếu RAM — không phải mặc định, không mâu thuẫn quyết
  định ở mục 1b.)
- **Gradle wrapper KHÔNG commit vào repo** (tránh phải có sẵn
  `gradle-wrapper.jar` binary). CI dùng action `gradle/actions/setup-gradle@v4`
  cài Gradle trực tiếp, chạy `gradle assembleDebug` (không phải `./gradlew`).
  Mở bằng Android Studio local thì Android Studio tự sinh wrapper.

## 6. Đã cân nhắc và LOẠI BỎ (đừng đề xuất lại)

- ❌ **Termux làm runtime/app trung gian** — người dùng từ chối rõ ràng, chỉ
  dùng Termux làm *nguồn tải binary lúc build-time*, không chạy Termux app
  lúc runtime.
- ❌ **`static-php-cli` cho Android** — search không xác nhận có hỗ trợ
  target Android (chỉ thấy Linux/macOS/FreeBSD/Windows). Không dùng.
- ❌ **Nhiều website/multi-tenant chạy song song** — người dùng xác nhận chỉ
  cần 1 website tại 1 thời điểm.
- ❌ **Hardcode PHP trong Kotlin** — đã refactor bỏ hoàn toàn (xem mục 3).

## 7. Điểm nghẽn / rủi ro CHƯA giải quyết (làm tiếp từ đây)

**Mới phát sinh từ nâng cấp LAMP (mục 1b) — CHƯA verify, ưu tiên kiểm tra
ngay sau lần build đầu tiên nếu chọn `"runtime": "php"`:**

0a. **php-fpm chạy non-root** — pool config (`php-fpm.conf.template`) cố ý
    KHÔNG có `user =`/`group =` (thường bắt buộc nếu master process là
    root; ở đây process app vốn đã non-root nên bỏ qua). Termux tự bản thân
    cũng non-root và package `php-fpm` của họ chạy được — kỳ vọng hợp lý
    nhưng CHƯA test trực tiếp trên app này. Nếu php-fpm lỗi "unable to
    setuid" hoặc tương tự, đây là chỗ đầu tiên cần sửa
    (`scripts/runtimes/templates/php-fpm.conf.template`).
0a2. **Auto-Sleep (mục 1j) — thời gian thực tế MariaDB khởi động lại trên ARM
    di động chưa đo được**. `wake-mariadb.php` poll tối đa ~8s rồi rơi về
    trang chờ nếu chưa xong — nếu MariaDB thật sự mất lâu hơn trên phần cứng
    cụ thể nào đó, khách sẽ thấy vài lần refresh liên tiếp thay vì 1 lần như
    kỳ vọng (không phải lỗi, chỉ là trải nghiệm không tối ưu). Đo lại số này
    trên thiết bị thật rồi tinh chỉnh nếu cần.
0b. **`mariadb-install-db` trên Android** — lệnh này thường cần chạy được
    vài binary phụ trợ (vd `mariadbd --bootstrap`) và ghi file tạm; đường
    dẫn tmp mặc định có thể không khớp môi trường Android. Nếu lỗi, xem log
    `$HOME/lamp-run/mysql-install.log`, thường cần set thêm `TMPDIR` hoặc
    `--tmpdir=` trỏ vào `cacheDir` của app.
0c. **extension .so của PHP** (`mysqli.so`, `pdo_mysql.so`, `mbstring.so`...)
    — `php.sh` copy TẤT CẢ file `.so` tìm thấy vào `nativeLibraryDir`, và
    `php.ini.template` set `extension_dir` trỏ đúng đó, nhưng CHƯA xác nhận
    Termux đóng gói các extension này ở đúng dạng `.so` rời (một số bản PHP
    build với extension tĩnh sẵn trong binary, khi đó dòng `extension=X.so`
    trong php.ini sẽ gây warning vô hại lúc khởi động, không phải lỗi
    nghiêm trọng — nhưng cần xem log `$HOME/lamp-run/php-fpm.log` để chắc).
0d. **RAM/CPU nặng hơn hẳn bản cũ** — 3 daemon (mariadbd + php-fpm + nginx)
    cùng lúc thay vì 1 tiến trình `php -S`. ~~Nếu app crash liên tục trên
    máy yếu, cân nhắc thêm biến thể "php-lite"~~ — **ĐÃ implement ở mục 1f
    (Dual-Mode PHP-Lite)**, không phải "chưa làm" như dòng này từng ghi —
    nếu thấy mâu thuẫn mục 1f thì tin mục 1f.

**Từ trước (chưa đổi):**

1. **[Ưu tiên cao] Chưa build-test thật lần nào.** Việc đầu tiên khi có môi
   trường thật (GitHub Actions hoặc máy có Android SDK): push repo, chạy
   workflow, đọc log lỗi.
2. **Binary Termux thiếu `.so`** (xem mục 5) — nếu gặp lỗi
   `cannot open shared object file` / `undefined symbol` trong
   `adb logcat`: tìm gói Termux chứa lib đó, thêm vào `extra_deps` khi gọi
   `termux_download_with_deps` trong `scripts/runtimes/<runtime>.sh` tương
   ứng. Nếu lặp lại nhiều lần không hết → chuyển "Kế hoạch B" (tự
   cross-compile bằng NDK, static-link) — xem README mục "Kế hoạch B", chưa
   implement, cần làm mới nếu tới bước này.
3. **cloudflared có thực sự static-linked không** — chưa xác nhận 100% qua
   search. Nếu binary lỗi thiếu `.so`, áp dụng cùng cơ chế
   `LD_LIBRARY_PATH` như binary khác (đã có sẵn trong code, chỉ cần thêm
   bước tải dependency nếu phát sinh).
4. **`android-actions/setup-android@v3`, `gradle/actions/setup-gradle@v4`
   và các action version cụ thể trong workflow** — chọn theo hiểu biết tại
   thời điểm viết, CHƯA chạy thử. Nếu CI báo lỗi action không tồn tại/phiên
   bản không tương thích, cập nhật version trong `build-apk.yml`, không phải
   lỗi kiến trúc.
5. **AGP 8.5.2 / Gradle 8.9 / Kotlin 1.9.24 / compileSdk 34** — tổ hợp version
   chọn theo kiến thức tại thời điểm viết (khớp nhau về lý thuyết), chưa
   verify build thật. Nếu lỗi version-mismatch, đây là chỗ sửa.
6. **Chưa có code signing / release build** — hiện tại `assembleDebug`
   (APK chưa ký, cần bật "cài từ nguồn không xác định"). Nếu người dùng cần
   bản release/ký, thêm keystore + signing config vào `app/build.gradle.kts`.
7. ~~Quick Tunnel URL đổi mỗi lần restart~~ — **ĐÃ FIX ở mục 1b** (named
   tunnel qua token, KHÔNG phải "chưa implement" như bản HANDOFF cũ từng
   ghi nhầm ở đây — nếu thấy dòng này mâu thuẫn mục 1b thì tin mục 1b).
   Rủi ro THẬT còn lại: named tunnel cần người dùng tự tạo tunnel + lấy
   token trên dashboard Cloudflare (không thể tự động hoá thay họ), và
   luồng `cloudflared tunnel run --token` **chưa test thật** trên thiết bị
   — nếu lỗi, so sánh log `adb logcat | grep cloudflared` giữa 2 chế độ.
8. **Adminer / Tiny File Manager tải từ URL "latest"/"master" ngoài kiểm
   soát** (xem mục 1c) — nếu 2 project đó đổi cấu trúc file, cơ chế chèn
   `auth.php` (`inject_auth_guard`, hàm `sed` tắt `$use_auth`) có thể không
   khớp nữa. **Luôn kiểm tra thủ công** sau build: `/_admin/db.php` và
   `/_admin/files.php` phải hiện màn hình đăng nhập của `auth.php` trước,
   không phải giao diện Adminer/TFM ngay lập tức.

## 8. Việc KHÔNG cần làm lại (đã xong, đừng viết lại từ đầu)

- Đừng viết lại cơ chế Foreground Service / WakeLock / notification —
  `ServerForegroundService.kt` đã đúng pattern chuẩn Android.
  Chỉ sửa nếu có bug cụ thể.
- Đừng viết lại `RuntimeConfig.kt` / cơ chế placeholder — đã generic đúng
  yêu cầu "không hardcode".
  Thêm runtime mới = thêm file `scripts/runtimes/<ten>.sh` theo khuôn có
  sẵn (xem `php.sh` làm mẫu), KHÔNG sửa `.kt`.
- Đừng đề xuất lại Termux-as-app, static-php-cli, hay kiến trúc multi-site
  (đã bị loại ở mục 6, có lý do rõ ràng).
- Đừng đề xuất lại danh sách "cố ý không làm" **hiện còn hiệu lực** (đọc mục
  1e/1f/1g/1h để biết lý do đầy đủ trước khi đề xuất lại — DANH SÁCH DƯỚI ĐÂY
  LÀ BẢN CẬP NHẬT MỚI NHẤT, đừng tin danh sách cũ hơn nếu thấy mâu thuẫn):
  SQLite on-demand/dual DB switching (mục 1e — khác Dual-Mode PHP-Lite ở mục
  1f, đã LÀM), OverlayFS/symlink `wp-content/uploads` sang cacheDir (mục 1e —
  chỉ phần `uploads` bị từ chối, phần `wp-content/cache` ĐÃ làm an toàn ở mục
  1h), cluster nhiều điện thoại qua LAN (mục 1e), BusyBox thay web/database
  server (mục 1e), ZRAM hint qua `onTrimMemory` (mục 1e, có bằng chứng kernel
  ở mục 1h), Cloudflare Workers static mirror (mục 1e), Tailscale/ZeroTier
  (mục 1e), Google Sign-In/Drive API thật cho tới khi có code signing ổn định
  (mục 1g). **KHÔNG còn trong danh sách từ chối** (đã làm bằng cách khác an
  toàn hơn — đừng đề xuất lại nguyên bản gốc): Dual-Mode PHP-Lite (mục 1f),
  webhook Telegram 2 chiều (mục 1e từ chối bản webhook — đã thay bằng
  long-polling an toàn hơn ở mục 1h), "RAM Disk"/tmpfs cho log (mục 1e từ
  chối vì bất khả thi — đã thay bằng `access_log buffer=`/`flush=` ở mục 1h).
- Đừng viết lại `BackupManager.kt` (logic backup), `TelegramNotifier.kt`
  (gọi Telegram Bot API), `router-lite.php`, hay `WorkScheduler.kt` trừ khi
  có bug cụ thể — đều đã tách riêng đúng nguyên tắc "1 nơi, dùng chung".
  Riêng `router-lite.php`: đừng đổi lại dùng `__DIR__` thay vì
  `$_SERVER['DOCUMENT_ROOT']` — ĐÃ test thực tế xác nhận `__DIR__` SAI hoàn
  toàn ở đây (file nằm trong `_supervisor/`, không phải docroot) — xem mục
  1f.
- Đừng đề xuất lại Google Sign-In/Drive API "xịn" cho tới khi mục 7.6 (code
  signing) được giải quyết trước — lý do đầy đủ ở mục 1g.
- Đừng đề xuất lại "hint ZRAM qua onTrimMemory" — đã tra bằng chứng kernel
  xác nhận đây là giới hạn nền tảng thật (chỉ tiến trình có đặc quyền hệ
  thống mới gọi được `process_madvise` lên tiến trình khác), không phải do
  chưa tìm đúng API. Xem mục 1h.
- Đừng viết lại `access_log` trong `nginx.conf.template` mà bỏ mất tên
  format `combined` tường minh trước `buffer=`/`flush=` — ĐÃ test bằng
  `nginx -t` thật và xác nhận thiếu nó sẽ lỗi "unknown log format" (nginx
  hiểu nhầm `buffer=64k` là tên format). Xem mục 1h.

## 9. Việc tiếp theo cụ thể (đề xuất thứ tự)

1. Push repo lên GitHub → xem tab Actions → đọc log lỗi đầu tiên (nếu có).
2. Nếu lỗi ở bước SDK/Gradle version → sửa version trong
   `.github/workflows/build-apk.yml`.
3. Nếu lỗi ở bước tải binary Termux (thiếu `.so`) → xem mục 7.2.
4. Nếu build ra APK thành công → cài thử, bấm "Bật server", kiểm tra
   `adb logcat | grep -E "site|cloudflared"` xem site + tunnel có lên không.
5. Test lần lượt 4 runtime (`php`/`node`/`python`/`static`) bằng cách đổi
   `site.config.json` rồi push lại — mỗi lần chỉ test 1 runtime.
6. Nếu ổn định → cân nhắc mục 7.6 (code signing) nếu cần bản release; kiểm
   tra thử luồng named tunnel (dán token Cloudflare vào app) nếu muốn domain
   cố định thay vì Quick Tunnel ngẫu nhiên.
7. Kiểm tra `/_admin/` (mục 1c, 1d, rủi ro #8 ở mục 7): vào bằng trình
   duyệt cùng mạng LAN, xác nhận hiện màn hình xin mật khẩu trước khi thấy
   Adminer/File Manager/Log/Info.
8. **(Mới, mục 1e)** Kiểm tra dashboard `_admin/index.php` hiện đúng dòng
   RAM máy + trạng thái MariaDB (chấm xanh/đỏ) — nếu KHÔNG hiện dòng RAM,
   `/proc/meminfo` không đọc được trên máy đó (đã có guard, không phải lỗi
   chặn trang, xem mục 1e phần "CHƯA verify").
8b. **(Mới, mục 1e - bảo mật)** Từ mạng 4G/ngoài LAN, thử mở
   `https://<url-tunnel>/wp-config.php.template` và
   `https://<url-tunnel>/_supervisor/nginx.conf.template` — PHẢI thấy lỗi
   403 (đã test bằng nginx thật trên máy tính, xem mục 1e, nhưng nên xác
   nhận lại 1 lần trên bản build APK thật để chắc chắn `nginx.conf.template`
   không bị lỗi resolve placeholder nào khác trên thiết bị).
9. **(Mới, mục 1e)** Nếu muốn thử "1-Click Install WordPress": đổi
   `site.config.json` sang `site_source.type` khác `wordpress` (vd `local`
   với thư mục `site/` trống), build lại, mở `/_admin/install-wp.php` qua
   LAN, xác nhận tải + cài xong rồi mở website thấy màn hình cài đặt
   WordPress 5 phút.
10. **(Mới, mục 1e)** Test backup tự động: bật "Tự động backup định kỳ"
    trong app, đặt khoảng cách giờ nhỏ để test nhanh hơn (vd 1), đợi qua ít
    nhất 1 chu kỳ, kiểm tra `Android/data/<package>/files/backups/` có file
    mới không. Nếu điền Telegram Bot Token + Chat ID, kiểm tra có nhận được
    tin nhắn/file trong Telegram không.
11. **(Mới, mục 1e)** Test watchdog: bật server, vào Recent Apps vuốt tắt
    app (không bấm "Tắt server" trong app), đợi khoảng 15-30 phút, kiểm tra
    server còn chạy không (mở lại app hoặc tạo yêu cầu tới URL LAN) — đây là
    `HealthCheckWorker` hoạt động.
12. **(Mới, mục 1f)** Test Dual-Mode PHP-Lite: chọn "Luôn bật" trong app
    (RadioGroup) TRƯỚC lần bấm "Bật server" đầu tiên trên site mới, xác nhận
    `_admin/index.php` hiện badge "Chế độ PHP-Lite" + dòng "php -S đơn lẻ".
    Test cả trên máy RAM thật < 3GB với chế độ "Tự động" để xác nhận
    `DEVICE_RAM_MB` đọc đúng qua `ActivityManager`. Sau đó thử đăng bài/tải
    ảnh trên WordPress để xác nhận SQLite hoạt động bình thường.
13. **(Mới, mục 1h)** Test điều khiển Telegram: điền Bot Token + Chat ID,
    chat `/status` với bot, đợi tối đa ~15 phút, xác nhận nhận được tin
    nhắn trạng thái. Thử `/backup` và `/restart`. Thử nhắn từ 1 tài khoản
    Telegram KHÁC (không phải Chat ID đã cấu hình) — xác nhận KHÔNG nhận
    được phản hồi gì (đúng thiết kế bảo mật).
14. **(Mới, mục 1i)** Test lỗ hổng Force-stop: bật auto-start + backup tự
    động + Telegram, vào Cài đặt Android > Ứng dụng > WP Pocket Server >
    "Buộc dừng", khởi động lại máy (auto-start sẽ tự bật server) — **KHÔNG
    mở lại app** — đợi qua 1 chu kỳ backup, xác nhận vẫn có file backup mới
    (xác nhận `WorkScheduler` gọi từ `ServerForegroundService.onCreate()`
    hoạt động đúng). Đồng thời xác nhận `tvRuntimeMode` trong app hiện đúng
    "Đầy đủ" hoặc "PHP-Lite" khớp với dashboard web.
