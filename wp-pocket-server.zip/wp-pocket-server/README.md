# WP Pocket Server

Source code Android (Kotlin + Gradle) — build APK tự động qua GitHub Actions.
Biến điện thoại Android thành server chạy **một website duy nhất**, backend
**không hardcode** trong app — chọn PHP/Node/Python/static chỉ bằng cách sửa
1 file `site.config.json`, không đụng code Kotlin hay workflow.

Kèm sẵn Cloudflare Quick Tunnel: server có URL https công khai ngay lập tức,
không cần mở port router, không cần IP tĩnh (giải quyết đúng vấn đề CGNAT của
mạng di động/cáp quang hộ gia đình ở VN). Có thể dán token Cloudflare để dùng
domain cố định thay vì URL ngẫu nhiên đổi mỗi lần khởi động lại.

**Runtime PHP mặc định dùng nginx + php-fpm + MariaDB thật** (không phải
`php -S` dev server + SQLite) — xử lý đồng thời đúng nghĩa, tương thích
plugin WordPress cần MySQL thật. Có nút "Backup ngay" trong app để zip
website + dump database ra bộ nhớ ngoài.

Kèm sẵn **Adminer** (quản lý database) + **File Manager** (quản lý file) +
**dashboard hệ thống** (RAM/dung lượng còn trống, trạng thái 3 dịch vụ) +
**1-Click Install WordPress** + **Xác thực 2 bước (2FA)** + **Chế độ bảo
trì 1 nút** + **Thống kê RAM/dung lượng/tải theo thời gian** tại `/_admin/`
— chỉ truy cập được qua mạng LAN (tự động chặn khỏi URL Cloudflare public),
cộng thêm mật khẩu riêng sinh ngẫu nhiên mỗi máy (xem trong app). Hướng dẫn
dùng từng mục ở phần **"Trang quản trị `/_admin/`"** bên dưới.

**Tự động hoá**: backup định kỳ theo lịch (không chỉ bấm tay, có thể giới
hạn "chỉ chạy khi đang sạc") + gửi báo cáo/file backup qua **Telegram Bot**
hoặc **webhook** tuỳ ý + **điều khiển từ xa qua Telegram** (`/status`
`/backup` `/restart`) + tự khởi động lại server nếu bị hệ điều hành Android
giết tiến trình dù người dùng vẫn muốn server chạy ("watchdog"). Xem mục
"Tự động hoá" trong app và phần chi tiết bên dưới.

**Dual-Mode PHP-Lite**: máy RAM thấp (dưới 3GB) tự động chuyển sang chế độ
nhẹ (`php -S` thay vì nginx+php-fpm+MariaDB đầy đủ) để vẫn chạy được thay vì
đơ máy — có thể ép tay Luôn bật/Luôn tắt/Tự động trong app. Xem mục riêng
bên dưới.

**Auto-Sleep MariaDB khi rảnh** (tuỳ chọn, mặc định TẮT — xem mục riêng bên
dưới): tự tắt MariaDB nếu không có ai truy cập trong N phút để tiết kiệm
RAM/pin, tự "đánh thức" lại trong vài giây khi có khách quay lại.

## File DUY NHẤT bạn cần sửa: `site.config.json`

```jsonc
{
  "runtime": "php",              // "php" | "node" | "python" | "static"
  "port": 8080,
  "entry": "",                   // "server.js" (node) / "app.py" (python), bỏ trống = mặc định
  "site_source": {
    "type": "wordpress",         // "wordpress" | "git" | "local" | "zip"
    "repo": "",                  // dùng khi type=git
    "branch": "main",
    "path": "site",              // dùng khi type=local (commit code vào thư mục này)
    "url": ""                    // dùng khi type=zip
  }
}
```

Đổi backend hay đổi website = sửa file này rồi push. Workflow tự đọc, tự tải
đúng runtime + đúng nguồn code, tự build lại APK.

## Kiến trúc: vì sao "không hardcode"

- **`ServerForegroundService.kt`**: một Foreground Service chuẩn của Android
  (giống service phát nhạc, VPN, tải file). Nó **không biết** mình đang chạy
  PHP hay Node — nó chỉ đọc `assets/runtime.json` (một file JSON tả "chạy
  lệnh gì, port nào, biến môi trường nào") rồi `ProcessBuilder` thực thi.
  Giữ notification cố định + `PARTIAL_WAKE_LOCK` để Android không kill khi
  tắt màn hình; tự khởi động lại nếu tiến trình crash.
- **`RuntimeConfig.kt`**: parse `runtime.json`, thay các placeholder
  `${BIN}` `${PORT}` `${DOCROOT}` `${FILESDIR}` thành giá trị thật. Đây là
  toàn bộ "logic" mà app biết — mọi thứ cụ thể (PHP cần `-S -t`, Node cần
  chạy file `.js`, Python cần `-m http.server`...) nằm trong shell script
  phía CI, không nằm trong app.
- **`scripts/runtimes/{php,node,python,static}.sh`**: mỗi script lo phần
  "backend cụ thể" — tải đúng binary + sinh đúng `runtime.json`. Thêm backend
  mới (vd Ruby) = thêm 1 file script mới theo đúng khuôn mẫu, không sửa app.
- **`scripts/lib/termux_fetch.sh`**: hàm dùng chung để tải binary build sẵn
  cho Android từ kho gói mã nguồn mở Termux (dùng cho php/node/python).
- **`scripts/lib/site_source.sh`**: hàm dùng chung để lấy mã nguồn website
  theo `site_source.type` (WordPress / git repo riêng / thư mục local commit
  sẵn / file zip).
- **`ServerForegroundService`** cũng chạy song song `cloudflared` (Cloudflare
  Quick Tunnel) — binary Go build tĩnh, tải trực tiếp từ GitHub release của
  Cloudflare, không qua Termux nên không có vấn đề thiếu `.so`.

**Node/Python/static**: 1 binary duy nhất, đặt tên `libruntimesrv.so` trong
`jniLibs/<abi>/`. **PHP** (nginx+php-fpm+MariaDB): NHIỀU binary
(`libnginx.so`, `libphpfpm.so`, `libmariadbd.so`, `libmariadbinstall.so`,
`libmysqlcli.so`, `libmysqldump.so`) chạy cùng lúc, giám sát bởi 1 script
`start-lamp.sh` — xem `scripts/runtimes/templates/`. Quy ước đặt tên `lib*.so`
khiến PackageManager tự cấp quyền thực thi khi cài app, né giới hạn W^X
(chặn thực thi file tự giải nén ra thư mục ghi được) áp dụng từ Android 10
trở lên — áp dụng cho MỌI binary kể trên, không riêng gì `libruntimesrv.so`.

Cổng quản trị (`/_admin/` — Adminer, File Manager, Log, PHP Info) chỉ tồn
tại với runtime `php`, do `scripts/lib/admin_tools.sh` tải + gắn cổng xác
thực (`_admin/auth.php`, mật khẩu ngẫu nhiên sinh bởi
`ServerForegroundService.ensureAdminPassword()`), chặn khỏi URL public ở
tầng nginx (`_admin/` chỉ allow dải IP LAN, xem `nginx.conf.template`).

## Nói thẳng: phần nào chắc chắn, phần nào chưa

**Chắc chắn** (API Android chuẩn, không mơ hồ):
- Chạy nền khi tắt màn hình (Foreground Service + WakeLock)
- Tự khởi động lại khi tiến trình crash, tự bật lại sau khi khởi động lại máy
- Cloudflare Tunnel outbound-only → có URL public mà không cần port-forward

**Rủi ro thật, cần tự kiểm chứng khi build lần đầu** — nằm ở
`scripts/lib/termux_fetch.sh`: binary php/node/python "mượn" từ kho Termux,
vốn build để chạy đúng layout thư mục Termux. Khi tách ra dùng riêng, có thể
thiếu vài thư viện `.so` phụ thuộc gián tiếp hoặc sai đường dẫn config mặc
định. Đây là bản chất kỹ thuật của việc tái sử dụng binary ngoài môi trường
gốc — không phải giới hạn riêng của cách làm này. `cloudflared` **không** có
vấn đề này vì là binary Go build tĩnh, tự chứa toàn bộ dependency.

Nếu app báo lỗi kiểu "cannot open shared object" / "undefined symbol" (xem
`adb logcat | grep -E "site|php|node"`):
1. Xem log để biết thiếu thư viện `.so` nào
2. Tìm gói Termux chứa nó: https://github.com/termux/termux-packages
3. Thêm tên gói vào `extra_deps` khi gọi `termux_download_with_deps` trong
   script runtime tương ứng, hoặc bổ sung thủ công vào `jniLibs/arm64-v8a/`

Tương tự, chưa xác nhận bản `nginx` "mượn" từ Termux có biên dịch sẵn module
`ngx_http_realip_module` hay không (module này dùng để khôi phục IP thật của
khách sau Cloudflare Tunnel — xem mục APO bên dưới). `start-lamp.sh` đã tự dò
qua `nginx -V` trước khi bật, nên nếu module này không có, tính năng đó chỉ
tự tắt chứ không làm app lỗi.

### Kế hoạch B (chắc chắn hơn, tốn công hơn)

Nếu "mượn binary Termux" gặp quá nhiều lỗi thư viện, hướng chắc chắn hơn về
lâu dài là tự biên dịch runtime từ mã nguồn bằng Android NDK, tĩnh hoá
(static-link) các phần cần thiết vào một binary duy nhất — loại bỏ hoàn toàn
vấn đề thiếu `.so`. Việc này tốn công dựng toàn bộ build chain (vd với PHP:
zlib, openssl, sqlite, php qua `--enable-static` + toolchain NDK) nên không
đưa sẵn vào đây, nhưng là hướng nên làm nếu dùng app này nghiêm túc/lâu dài.

Không cần dựng từ số 0: dự án PocketMine-MP (server Minecraft chạy trên
Android) đã có sẵn pipeline build PHP tĩnh hoàn toàn cho target
`android-aarch64` bằng toolchain `aarch64-linux-musl`
(https://github.com/pmmp/PHP-Binaries) — dùng làm điểm khởi đầu tham khảo
tốt cho phần PHP. `nginx` và MariaDB thì chưa có pipeline tương tự sẵn có,
vẫn phải tự dựng.

## Build APK

```bash
cd wp-pocket-server
git init && git add . && git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<ten-ban>/<ten-repo>.git
git push -u origin main
```

**Cách khác (không cần git ở máy)**: nén cả thư mục `wp-pocket-server/`
thành 1 file `.zip`, upload thẳng file đó + thư mục `.github/workflows/`
(chứa `build-apk.yml`) lên repo GitHub qua giao diện web. `build-apk.yml`
tự nhận diện repo chỉ có file zip (không có source checkin trực tiếp) và tự
giải nén trước khi build — không cần thêm bước nào khác. Chỉ cần nhớ: mỗi
khi sửa gì trong file zip, `.github/workflows/build-apk.yml` PHẢI luôn là
bản đang chạy thật trên GitHub (workflow không nằm trong zip, GitHub đọc nó
trực tiếp) — 2 chỗ này dễ bị lệch nhau nếu chỉ cập nhật 1 trong 2.

Vào tab **Actions** trên GitHub — workflow `Build APK` tự chạy (đọc
`site.config.json`, tải đúng runtime + website + cloudflared, build APK).
Tải file `.apk` ở mục **Artifacts** của lần chạy đó, cài lên máy (cần bật
"Cài từ nguồn không xác định" vì là bản debug chưa ký Play Store).

Cũng mở được trực tiếp bằng Android Studio để build/debug local (Android
Studio tự tạo Gradle wrapper nếu project chưa có).

## Sau khi cài app

1. Mở app, bấm **Bật server**. Lần đầu mất chút thời gian giải nén website.
1b. Nếu trạng thái không chuyển sang "Đang chạy" sau khoảng 1 phút (hoặc
   hiện dòng "⚠️ Không lên được") — bấm **Xem log** (luôn bấm được, kể cả
   khi server lỗi, vì đọc thẳng file trên đĩa chứ không qua web server) —
   chọn tab "start-lamp.sh" trước tiên để xem tổng quan lỗi khởi động.
2. Bấm **Bỏ qua tối ưu hoá pin** — nếu không, Android vẫn có thể tạm dừng
   service sau thời gian dài không dùng máy (Doze mode), dù đã là Foreground
   Service.
2b. Nếu máy là Xiaomi/Redmi, Oppo/Realme, Vivo, Huawei/Honor, Samsung, hoặc
   OnePlus: bấm thêm **Mở cài đặt Tự khởi động của hãng máy**. Các hãng này
   có thêm 1 lớp quản lý pin RIÊNG ngoài Android gốc, có thể vẫn tắt ngầm
   Foreground Service dù bước 2 đã làm đúng — đây là vấn đề rất phổ biến với
   Android tùy biến sâu (xem dontkillmyapp.com), không phải lỗi của app.
   Nút này dùng các màn hình cài đặt không chính thức của từng hãng (best-
   effort, có thể không khớp trên vài phiên bản ROM cụ thể) — nếu không mở
   được màn hình riêng, sẽ tự chuyển sang trang chi tiết ứng dụng chuẩn, tự
   tìm mục Pin/Tự khởi động bên trong.
3. App hiện 2 địa chỉ:
   - **LAN**: `http://192.168.x.x:8080` — chỉ dùng được cùng mạng WiFi
   - **Công khai**: `https://xxx.trycloudflare.com` — truy cập được từ bất
     kỳ đâu có Internet, đổi mỗi lần khởi động lại server (Quick Tunnel,
     miễn phí không cần tài khoản). Muốn domain cố định: tạo tunnel trên
     dashboard Cloudflare (miễn phí), dán token vào ô "Cloudflare Tunnel
     token" trong app rồi bật lại server.
4. **Mật khẩu quản trị** hiện sẵn trong app — bấm "Mở trang quản trị" để
   vào Adminer (database) + File Manager + Log + PHP Info tại `/_admin/`
   (chỉ vào được qua cùng mạng LAN, không qua URL public).
5. Nút **"Backup ngay"** — zip website + dump database vào
   `Android/data/<package>/files/backups/` trên máy.
5b. Nút **"Khôi phục từ backup"** — chọn 1 trong các bản backup đã có, xác
   nhận rồi ghi đè website + database hiện tại bằng bản đó. Nên dừng server
   trước khi khôi phục. Không thể hoàn tác sau khi xác nhận.

Nếu chọn `"runtime": "php"` + `"site_source": {"type": "wordpress"}`, lần
đầu mở URL sẽ thấy màn hình cài đặt WordPress 5 phút quen thuộc.

### Chạy nền liên tục: mức độ đảm bảo thật

- **Tắt màn hình**: chạy được bình thường — đây là Foreground Service +
  `PARTIAL_WAKE_LOCK` đúng chuẩn Android, không phải mẹo vặt.
- **Bị hệ thống âm thầm giết** (đặc biệt máy Xiaomi/Oppo/Vivo/Huawei...):
  KHÔNG đảm bảo được 100% dù đã bật hết bước 2 + 2b ở trên — đây là giới
  hạn thật của các bản Android tùy biến sâu, không phải lỗi app (xem
  dontkillmyapp.com). App có lớp phòng hờ thứ 2: `HealthCheckWorker` chạy
  độc lập qua WorkManager, tối đa mỗi 15 phút tự kiểm tra và bật lại server
  nếu bị giết mà người dùng chưa tắt — không tức thời, nhưng vẫn tự phục
  hồi thay vì phải mở tay.
- **Máy khởi động lại** (ai đó bấm nguồn, tự reboot sau cập nhật hệ thống):
  tự bật lại server qua `BootReceiver` (cần bật công tắc "Tự khởi động"
  trong app trước) — không cần mở app thủ công.
- **Máy tắt nguồn hoàn toàn**: KHÔNG có app nào (kể cả app này) tự bật lại
  được nguồn máy — đây là giới hạn phần cứng/firmware, không phải giới hạn
  của code. Vài dòng máy quảng cáo "báo thức sống sót qua tắt nguồn" là
  tính năng gắn cứng vào firmware của hãng cho đúng app Đồng hồ có sẵn,
  không có API công khai cho app bên thứ 3.

## Trang quản trị `/_admin/` — hướng dẫn từng mục

Vào bằng nút **"Mở trang quản trị"** trong app, hoặc gõ tay
`http://<IP-LAN-cua-may>:<port>/_admin/` trên trình duyệt của **bất kỳ máy
nào cùng mạng WiFi** (điện thoại khác, laptop...) — không vào được từ URL
Cloudflare public, đây là chủ ý (chặn ở tầng nginx, xem mục kiến trúc phía
trên). Nhập mật khẩu hiện sẵn trong app (sinh ngẫu nhiên, đổi được — xem
mục 2FA bên dưới).

- **Adminer** — quản lý database MySQL/MariaDB bằng giao diện web, không
  cần biết SQL để xem/sửa dữ liệu cơ bản. Đăng nhập tự động (thông tin kết
  nối đã điền sẵn), không cần tự nhớ tên database/user/mật khẩu MariaDB.
- **File Manager** (Tiny File Manager) — xem/sửa/xoá/tải lên file trong thư
  mục website trực tiếp từ trình duyệt, không cần FTP/SSH.
- **Xem log** — đọc trực tiếp file log trên đĩa (nginx, php-fpm, mariadb,
  `start-lamp.sh`) theo tab, kể cả khi server đang LỖI không lên được (đọc
  thẳng file, không qua web server nên không phụ thuộc server sống hay
  chết). Đây là nơi đầu tiên nên xem khi server báo lỗi.
- **Thông tin hệ thống** — RAM còn trống, dung lượng đĩa, trạng thái sống
  của nginx/php-fpm/mariadb, chế độ đang chạy (Đầy đủ/Lite).
- **Cài WordPress 1-Click** — chỉ hiện khi thư mục web đang trống. Bấm 1
  nút, tự tải WordPress mới nhất từ wordpress.org + tự kết nối database có
  sẵn (không cần tự nhập thông tin database) — mất 30 giây tới 2 phút tuỳ
  mạng. Có sẵn ô chọn tải trước plugin **Cloudflare** chính thức (khuyên để
  nguyên, dùng cho Automatic Platform Optimization — xem mục Cloudflare bên
  dưới), chỉ tải file chứ chưa tự kích hoạt/nhập API Token.
- **Xác thực 2 bước (2FA)** — thêm 1 lớp bảo vệ ngoài mật khẩu, dùng app
  Authenticator (Google Authenticator, Authy...) giống đăng nhập ngân
  hàng/Gmail. Bấm bật → hiện 1 chuỗi ký tự (nhập tay vào app Authenticator,
  chọn "Nhập khoá thủ công" thay vì quét QR vì trang này chủ ý không tự vẽ
  mã QR) → nhập lại đúng 1 mã 6 số hiện ra trên app Authenticator để xác
  nhận đã cài đúng, lúc đó mới thực sự bật. Từ đó đăng nhập `/_admin/` cần
  2 bước: mật khẩu → mã 6 số. **Lỡ mất điện thoại cài app Authenticator /
  đổi máy mất mã**: mở app WP Pocket Server (máy chính, đã mở được sẵn) →
  có nút **"Tắt 2FA khẩn cấp"** (chỉ hiện khi 2FA đang bật) → không cần mật
  khẩu hay mã nào cả, đây là đường thoát duy nhất nên chỉ dùng khi thật sự
  cần.
- **Chế độ bảo trì** *(mới)* — bấm 1 nút để tạm ẩn website với khách (họ
  thấy trang "Website đang bảo trì" thay vì site thật), trong khi bạn vẫn
  vào `/_admin/` bình thường để làm việc. Dùng khi đang cập nhật WordPress/
  plugin/theme và chưa muốn khách thấy giao diện dở dang. Bật/tắt có hiệu
  lực gần như ngay lập tức (tối đa ~2 giây với chiều tắt, do cơ chế cache
  file của nginx — đã đo bằng thời gian thực, không phải phỏng đoán). Bấm
  lại đúng nút đó (đổi thành "Tắt chế độ bảo trì") để mở lại cho khách.
- **Thống kê theo thời gian** *(mới)* — 3 biểu đồ đơn giản: RAM đã dùng,
  dung lượng đĩa đã dùng, load trung bình — ghi mỗi ~5 phút, xem theo mốc
  24 giờ / 3 ngày / 7 ngày. Giúp biết máy có đang quá tải hay sắp đầy đĩa
  hay không mà không cần cài thêm app theo dõi nào. **Chỉ ghi được ở chế độ
  Đầy đủ** — chế độ Lite không có vòng lặp giám sát nền nên không thu thập
  được (đúng thiết kế đánh đổi lấy RAM thấp nhất của Lite, không phải lỗi);
  trang sẽ báo "chưa có dữ liệu" thay vì lỗi nếu rơi vào trường hợp này.

## Điều khiển từ xa qua Telegram

Nếu đã điền **Bot Token** + **Chat ID** ở mục "Tự động hoá" trong app (tạo
bot miễn phí qua [@BotFather](https://t.me/BotFather) trên Telegram, lấy
Chat ID bằng cách nhắn thử cho bot rồi mở
`https://api.telegram.org/bot<TOKEN>/getUpdates`), ngoài việc TỰ ĐỘNG nhận
báo cáo (server bắt đầu chạy, backup xong, cảnh báo sập...), bạn còn nhắn
trực tiếp cho bot 3 lệnh để điều khiển máy từ xa, không cần mở app:

- `/status` — máy trả lời ngay tình trạng RAM/đĩa/trạng thái server hiện
  tại.
- `/backup` — yêu cầu backup ngay lập tức, xong sẽ tự gửi file zip qua chat.
- `/restart` (hoặc `/restart_service`) — khởi động lại server từ xa, hữu
  ích khi site bị treo mà bạn không cầm điện thoại chính trong tay.

## Backup: lịch tự động, "chỉ khi đang sạc", và nơi gửi đi

Mục "Tự động hoá" trong app:

- Bật **"Tự động backup định kỳ"** + chọn số giờ giữa 2 lần backup.
- **"Chỉ backup tự động khi đang sạc"** *(mới, mặc định TẮT)* — bật nếu ưu
  tiên an toàn pin/ổn định hơn là chắc chắn đúng giờ. **Lưu ý thật**: nếu
  máy hiếm khi được cắm sạc trong lúc chạy server, bật tuỳ chọn này đồng
  nghĩa backup tự động có thể sẽ *không bao giờ* chạy — cân nhắc trước khi
  bật, không phải công tắc "càng bật càng tốt".
- File backup (zip website + dump database) có thể gửi đi 2 cách, dùng
  song song được cả hai:
  - **Telegram Bot** — điền Bot Token + Chat ID như mục trên, file backup
    tự gửi kèm mỗi lần chạy xong (giới hạn ~50MB của Telegram — site lớn
    hơn nên dùng webhook).
  - **Webhook** — điền 1 URL bất kỳ nhận được HTTP POST file (nhận dạng
    `multipart`, field tên `"file"` — ví dụ dựng bằng Google Apps Script để
    tự lưu vào Google Drive của bạn) vào ô **"Webhook backup khác"** — máy
    tự POST file zip lên đó mỗi lần backup xong, không giới hạn dung lượng
    như Telegram.

## Dual-Mode PHP-Lite (máy RAM thấp vẫn chạy được)

Máy có dưới 3GB RAM chạy đủ nginx + php-fpm + MariaDB thật cùng lúc có thể
không đủ bộ nhớ, dễ bị Android tự kill vì thiếu RAM. App tự phát hiện qua
tổng RAM của máy và chuyển sang **chế độ Lite**: chỉ chạy `php -S` (máy chủ
PHP tối giản có sẵn, không cần nginx/php-fpm/MariaDB) — đổi lại nhẹ RAM hơn
nhiều nhưng **không hỗ trợ database thật** (site cần MySQL, như hầu hết
WordPress, sẽ không chạy đúng ở chế độ này) và không có phần Thống kê theo
thời gian ở trên.

3 lựa chọn trong app (mục **"Chế độ RAM thấp (PHP-Lite)"**, radio button):
- **Tự động** (mặc định) — máy tự quyết theo RAM lúc khởi động server.
- **Luôn bật** — ép luôn chạy Lite dù RAM đủ (ví dụ muốn tiết kiệm pin tối
  đa cho 1 site tĩnh không cần database).
- **Luôn tắt** — ép luôn chạy Đầy đủ dù RAM thấp (rủi ro tự set nếu máy quá
  yếu, có thể bị Android kill do thiếu RAM).

Dòng chữ nhỏ dưới nút Bật/Tắt server trong app (không phải 3 nút chọn ở
trên) cho biết chế độ THẬT SỰ đang chạy — quan trọng khi để "Tự động" vì
lựa chọn đó không tự nói cho bạn biết kết quả thực tế là Đầy đủ hay Lite.

## Auto-Sleep MariaDB khi rảnh (tuỳ chọn, mặc định TẮT)

Đề xuất "Cơ chế Ngủ đông thông minh" trong tài liệu thiết kế gốc. Bật trong
app (switch "Tự tắt MariaDB khi rảnh") nếu muốn tiết kiệm RAM/pin cho website
ít truy cập — đổi lại request đầu tiên sau một thời gian dài không ai ghé sẽ
chậm hơn vài giây (MariaDB cần khởi động lại).

Cách hoạt động: 1 script PHP cực nhẹ (chỉ `touch()` 1 file, không ghi log)
chạy trước mọi trang PHP để đánh dấu "vừa có người dùng". Vòng lặp giám sát
có sẵn của `start-lamp.sh` (vốn đã kiểm tra mỗi 3 giây xem nginx/php-fpm/
mariadb có còn sống không) kiểm tra thêm mốc thời gian này — quá ngưỡng thì
gửi tín hiệu tắt êm cho MariaDB (không phải tắt đột ngột, tránh hỏng dữ liệu).
Khi có request mới, nginx tự chuyển hướng nội bộ sang 1 trang "đang khởi động
lại..." đồng thời âm thầm bật MariaDB lại, rồi tự đưa khách quay về đúng
trang họ định xem.

Giới hạn đã biết (thành thật, không che):
- `_admin/` (Adminer, quản lý file...) CHƯA được tích hợp cơ chế đánh thức —
  nếu vào đúng lúc MariaDB đang ngủ sẽ thấy lỗi kết nối database, tự tải lại
  trang sau vài giây là được (traffic thật từ khách sẽ tự đánh thức trước).
- Dùng khoá nhẹ (advisory lock) để giảm việc nhiều khách cùng lúc đều cố
  khởi động lại MariaDB, nhưng lớp bảo vệ CHÍNH vẫn là cơ chế tự chống chạy
  trùng có sẵn của MariaDB (từ chối khởi động lần 2 trên cùng thư mục dữ
  liệu) — rủi ro tồn dư cực thấp nhưng không phải bằng 0 tuyệt đối.
- Chưa build-test trên thiết bị thật (giống mọi tính năng khác của dự án ở
  giai đoạn này) — logic đã được mô phỏng kỹ (giả lập pipeline `sed`, kiểm
  tra cú pháp PHP/shell) nhưng hành vi thời gian thực (MariaDB thật mất bao
  lâu để khởi động lại trên phần cứng ARM di động) chưa đo được.



Vì đã dùng Cloudflare Tunnel, bạn có thể tận dụng thêm các tính năng MIỄN
PHÍ trên **dashboard Cloudflare** (dash.cloudflare.com) mà không cần đụng gì
tới app hay code — tất cả các mục dưới đây là cấu hình phía Cloudflare, xử
lý ở edge server của họ trước khi request chạm tới điện thoại của bạn:

- **Cache trang tĩnh** (Caching → Configuration, hoặc Page Rules): cache
  ảnh/CSS/JS giúp giảm đáng kể số request PHP/MariaDB phải xử lý thật trên
  máy.
- **HTTP/3 (QUIC)**: bật ở Network → HTTP/3 — Cloudflare tự thương lượng
  với trình duyệt, giảm tải xử lý TCP handshake, không cần cấu hình gì
  thêm ở nginx.
- **WAF miễn phí** (Security → WAF): chặn bot/quét lỗ hổng phổ biến trước
  khi tới website — giúp bạn KHÔNG cần cài thêm plugin bảo mật nặng (kiểu
  Wordfence) trên máy vốn đã hạn chế RAM.
- **Automatic Platform Optimization (APO)** — nếu chạy WordPress, đây là
  nâng cấp đáng cân nhắc nhất: Cloudflare cache TOÀN BỘ trang HTML (không
  chỉ ảnh/CSS/JS) ngay ở edge, khiến điện thoại gần như "vô hình" với
  lượng truy cập đọc thông thường (chỉ còn phải xử lý request thật sự động
  như đăng nhập/bình luận). Miễn phí nếu đang dùng gói Pro trở lên, 5
  USD/tháng nếu đang dùng gói Free. Cách bật:
  1. 1-Click Installer (`_admin/install-wp.php`) có sẵn tùy chọn tải trước
     plugin "Cloudflare" chính thức khi cài WordPress — để nguyên checkbox
     mặc định là đủ.
  2. Vào trang quản trị WordPress → Plugins → kích hoạt "Cloudflare" → nhập
     email + API Token (tạo tại dash.cloudflare.com).
  3. Trên dashboard Cloudflare của domain → tab Speed → bật "Automatic
     Platform Optimization for WordPress".

  Lưu ý: khi dùng Cloudflare Tunnel, mọi request công khai đến `nginx` đều
  qua `127.0.0.1` (do `cloudflared` chạy local) nên mặc định WordPress/log
  sẽ thấy MỌI khách là `127.0.0.1`, không phân biệt được ai với ai — làm
  sai các plugin chống spam/giới hạn đăng nhập theo IP. Bản cập nhật này đã
  thêm cấu hình khôi phục IP thật từ header `CF-Connecting-IP` trong
  `nginx.conf.template` (tự dò xem bản `nginx` của Termux có module
  `realip` hay không trước khi bật, không giả định — nếu không có thì tự
  bỏ qua an toàn, không làm nginx từ chối khởi động). Chưa verify module
  này có mặt trong bản `nginx` thật của Termux hay không (giống mọi phần
  "chưa verify" khác của dự án — xem mục "Nói thẳng" bên dưới).

## Những đánh đổi thật cần biết trước khi dùng lâu dài

- Điện thoại không có nguồn điện dự phòng, RAID, hay backup tự động như
  datacenter — mất điện/rớt WiFi là site sập ngay.
- Bảo mật (cập nhật WordPress/dependency, vá lỗ hổng) hoàn toàn do bạn tự quản.
- Quick Tunnel phù hợp: site cá nhân, học tập, demo, traffic thấp.
- Không phù hợp: site kinh doanh cần uptime cao — lúc đó một VPS giá rẻ vẫn
  đáng tiền hơn nhiều so với rủi ro mất dữ liệu/downtime.
