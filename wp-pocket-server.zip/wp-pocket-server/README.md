# WP Pocket Server

Source code Android (Kotlin + Gradle) — build APK tự động qua GitHub Actions.
Biến điện thoại Android thành server chạy **một website duy nhất**, backend
**không hardcode** trong app — chọn PHP/Node/Python/static chỉ bằng cách sửa
1 file `site.config.json`, không đụng code Kotlin hay workflow.

Kèm sẵn Cloudflare Quick Tunnel: server có URL https công khai ngay lập tức,
không cần mở port router, không cần IP tĩnh (giải quyết đúng vấn đề CGNAT của
mạng di động/cáp quang hộ gia đình ở VN). Có thể dán token Cloudflare để dùng
domain cố định thay vì URL ngẫu nhiên đổi mỗi lần khởi động lại.

**Runtime PHP mặc định dùng nginx + php-fpm + MariaDB thật** (không phải
`php -S` dev server + SQLite) — xử lý đồng thời đúng nghĩa, tương thích
plugin WordPress cần MySQL thật. Có nút "Backup ngay" trong app để zip
website + dump database ra bộ nhớ ngoài.

Kèm sẵn **Adminer** (quản lý database) + **File Manager** (quản lý file) +
**dashboard hệ thống** (RAM/dung lượng còn trống, trạng thái 3 dịch vụ) +
**1-Click Install WordPress** tại `/_admin/` — chỉ truy cập được qua mạng
LAN (tự động chặn khỏi URL Cloudflare public), cộng thêm mật khẩu riêng sinh
ngẫu nhiên mỗi máy (xem trong app).

**Tự động hoá**: backup định kỳ theo lịch (không chỉ bấm tay) + báo cáo/gửi
file backup qua **Telegram Bot** (tuỳ chọn, tự tạo bot miễn phí qua
@BotFather) + tự khởi động lại server nếu bị hệ điều hành Android giết tiến
trình dù người dùng vẫn muốn server chạy ("watchdog"). Xem mục "Tự động hoá"
trong app.

**Auto-Sleep MariaDB khi rảnh** (tuỳ chọn, mặc định TẮT — xem mục riêng bên
dưới): tự tắt MariaDB nếu không có ai truy cập trong N phút để tiết kiệm
RAM/pin, tự "đánh thức" lại trong vài giây khi có khách quay lại.

## File DUY NHẤT bạn cần sửa: `site.config.json`

```jsonc
{
  "runtime": "php",              // "php" | "node" | "python" | "static"
  "port": 8080,
  "entry": "",                   // "server.js" (node) / "app.py" (python), bỏ trống = mặc định
  "site_source": {
    "type": "wordpress",         // "wordpress" | "git" | "local" | "zip"
    "repo": "",                  // dùng khi type=git
    "branch": "main",
    "path": "site",              // dùng khi type=local (commit code vào thư mục này)
    "url": ""                    // dùng khi type=zip
  }
}
```

Đổi backend hay đổi website = sửa file này rồi push. Workflow tự đọc, tự tải
đúng runtime + đúng nguồn code, tự build lại APK.

## Kiến trúc: vì sao "không hardcode"

- **`ServerForegroundService.kt`**: một Foreground Service chuẩn của Android
  (giống service phát nhạc, VPN, tải file). Nó **không biết** mình đang chạy
  PHP hay Node — nó chỉ đọc `assets/runtime.json` (một file JSON tả "chạy
  lệnh gì, port nào, biến môi trường nào") rồi `ProcessBuilder` thực thi.
  Giữ notification cố định + `PARTIAL_WAKE_LOCK` để Android không kill khi
  tắt màn hình; tự khởi động lại nếu tiến trình crash.
- **`RuntimeConfig.kt`**: parse `runtime.json`, thay các placeholder
  `${BIN}` `${PORT}` `${DOCROOT}` `${FILESDIR}` thành giá trị thật. Đây là
  toàn bộ "logic" mà app biết — mọi thứ cụ thể (PHP cần `-S -t`, Node cần
  chạy file `.js`, Python cần `-m http.server`...) nằm trong shell script
  phía CI, không nằm trong app.
- **`scripts/runtimes/{php,node,python,static}.sh`**: mỗi script lo phần
  "backend cụ thể" — tải đúng binary + sinh đúng `runtime.json`. Thêm backend
  mới (vd Ruby) = thêm 1 file script mới theo đúng khuôn mẫu, không sửa app.
- **`scripts/lib/termux_fetch.sh`**: hàm dùng chung để tải binary build sẵn
  cho Android từ kho gói mã nguồn mở Termux (dùng cho php/node/python).
- **`scripts/lib/site_source.sh`**: hàm dùng chung để lấy mã nguồn website
  theo `site_source.type` (WordPress / git repo riêng / thư mục local commit
  sẵn / file zip).
- **`ServerForegroundService`** cũng chạy song song `cloudflared` (Cloudflare
  Quick Tunnel) — binary Go build tĩnh, tải trực tiếp từ GitHub release của
  Cloudflare, không qua Termux nên không có vấn đề thiếu `.so`.

**Node/Python/static**: 1 binary duy nhất, đặt tên `libruntimesrv.so` trong
`jniLibs/<abi>/`. **PHP** (nginx+php-fpm+MariaDB): NHIỀU binary
(`libnginx.so`, `libphpfpm.so`, `libmariadbd.so`, `libmariadbinstall.so`,
`libmysqlcli.so`, `libmysqldump.so`) chạy cùng lúc, giám sát bởi 1 script
`start-lamp.sh` — xem `scripts/runtimes/templates/`. Quy ước đặt tên `lib*.so`
khiến PackageManager tự cấp quyền thực thi khi cài app, né giới hạn W^X
(chặn thực thi file tự giải nén ra thư mục ghi được) áp dụng từ Android 10
trở lên — áp dụng cho MỌI binary kể trên, không riêng gì `libruntimesrv.so`.

Cổng quản trị (`/_admin/` — Adminer, File Manager, Log, PHP Info) chỉ tồn
tại với runtime `php`, do `scripts/lib/admin_tools.sh` tải + gắn cổng xác
thực (`_admin/auth.php`, mật khẩu ngẫu nhiên sinh bởi
`ServerForegroundService.ensureAdminPassword()`), chặn khỏi URL public ở
tầng nginx (`_admin/` chỉ allow dải IP LAN, xem `nginx.conf.template`).

## Nói thẳng: phần nào chắc chắn, phần nào chưa

**Chắc chắn** (API Android chuẩn, không mơ hồ):
- Chạy nền khi tắt màn hình (Foreground Service + WakeLock)
- Tự khởi động lại khi tiến trình crash, tự bật lại sau khi khởi động lại máy
- Cloudflare Tunnel outbound-only → có URL public mà không cần port-forward

**Rủi ro thật, cần tự kiểm chứng khi build lần đầu** — nằm ở
`scripts/lib/termux_fetch.sh`: binary php/node/python "mượn" từ kho Termux,
vốn build để chạy đúng layout thư mục Termux. Khi tách ra dùng riêng, có thể
thiếu vài thư viện `.so` phụ thuộc gián tiếp hoặc sai đường dẫn config mặc
định. Đây là bản chất kỹ thuật của việc tái sử dụng binary ngoài môi trường
gốc — không phải giới hạn riêng của cách làm này. `cloudflared` **không** có
vấn đề này vì là binary Go build tĩnh, tự chứa toàn bộ dependency.

Nếu app báo lỗi kiểu "cannot open shared object" / "undefined symbol" (xem
`adb logcat | grep -E "site|php|node"`):
1. Xem log để biết thiếu thư viện `.so` nào
2. Tìm gói Termux chứa nó: https://github.com/termux/termux-packages
3. Thêm tên gói vào `extra_deps` khi gọi `termux_download_with_deps` trong
   script runtime tương ứng, hoặc bổ sung thủ công vào `jniLibs/arm64-v8a/`

Tương tự, chưa xác nhận bản `nginx` "mượn" từ Termux có biên dịch sẵn module
`ngx_http_realip_module` hay không (module này dùng để khôi phục IP thật của
khách sau Cloudflare Tunnel — xem mục APO bên dưới). `start-lamp.sh` đã tự dò
qua `nginx -V` trước khi bật, nên nếu module này không có, tính năng đó chỉ
tự tắt chứ không làm app lỗi.

### Kế hoạch B (chắc chắn hơn, tốn công hơn)

Nếu "mượn binary Termux" gặp quá nhiều lỗi thư viện, hướng chắc chắn hơn về
lâu dài là tự biên dịch runtime từ mã nguồn bằng Android NDK, tĩnh hoá
(static-link) các phần cần thiết vào một binary duy nhất — loại bỏ hoàn toàn
vấn đề thiếu `.so`. Việc này tốn công dựng toàn bộ build chain (vd với PHP:
zlib, openssl, sqlite, php qua `--enable-static` + toolchain NDK) nên không
đưa sẵn vào đây, nhưng là hướng nên làm nếu dùng app này nghiêm túc/lâu dài.

Không cần dựng từ số 0: dự án PocketMine-MP (server Minecraft chạy trên
Android) đã có sẵn pipeline build PHP tĩnh hoàn toàn cho target
`android-aarch64` bằng toolchain `aarch64-linux-musl`
(https://github.com/pmmp/PHP-Binaries) — dùng làm điểm khởi đầu tham khảo
tốt cho phần PHP. `nginx` và MariaDB thì chưa có pipeline tương tự sẵn có,
vẫn phải tự dựng.

## Build APK

```bash
cd wp-pocket-server
git init && git add . && git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<ten-ban>/<ten-repo>.git
git push -u origin main
```

Vào tab **Actions** trên GitHub — workflow `Build APK` tự chạy (đọc
`site.config.json`, tải đúng runtime + website + cloudflared, build APK).
Tải file `.apk` ở mục **Artifacts** của lần chạy đó, cài lên máy (cần bật
"Cài từ nguồn không xác định" vì là bản debug chưa ký Play Store).

Cũng mở được trực tiếp bằng Android Studio để build/debug local (Android
Studio tự tạo Gradle wrapper nếu project chưa có).

## Sau khi cài app

1. Mở app, bấm **Bật server**. Lần đầu mất chút thời gian giải nén website.
2. Bấm **Bỏ qua tối ưu hoá pin** — nếu không, Android vẫn có thể tạm dừng
   service sau thời gian dài không dùng máy (Doze mode), dù đã là Foreground
   Service.
2b. Nếu máy là Xiaomi/Redmi, Oppo/Realme, Vivo, Huawei/Honor, Samsung, hoặc
   OnePlus: bấm thêm **Mở cài đặt Tự khởi động của hãng máy**. Các hãng này
   có thêm 1 lớp quản lý pin RIÊNG ngoài Android gốc, có thể vẫn tắt ngầm
   Foreground Service dù bước 2 đã làm đúng — đây là vấn đề rất phổ biến với
   Android tùy biến sâu (xem dontkillmyapp.com), không phải lỗi của app.
   Nút này dùng các màn hình cài đặt không chính thức của từng hãng (best-
   effort, có thể không khớp trên vài phiên bản ROM cụ thể) — nếu không mở
   được màn hình riêng, sẽ tự chuyển sang trang chi tiết ứng dụng chuẩn, tự
   tìm mục Pin/Tự khởi động bên trong.
3. App hiện 2 địa chỉ:
   - **LAN**: `http://192.168.x.x:8080` — chỉ dùng được cùng mạng WiFi
   - **Công khai**: `https://xxx.trycloudflare.com` — truy cập được từ bất
     kỳ đâu có Internet, đổi mỗi lần khởi động lại server (Quick Tunnel,
     miễn phí không cần tài khoản). Muốn domain cố định: tạo tunnel trên
     dashboard Cloudflare (miễn phí), dán token vào ô "Cloudflare Tunnel
     token" trong app rồi bật lại server.
4. **Mật khẩu quản trị** hiện sẵn trong app — bấm "Mở trang quản trị" để
   vào Adminer (database) + File Manager + Log + PHP Info tại `/_admin/`
   (chỉ vào được qua cùng mạng LAN, không qua URL public).
5. Nút **"Backup ngay"** — zip website + dump database vào
   `Android/data/<package>/files/backups/` trên máy.

Nếu chọn `"runtime": "php"` + `"site_source": {"type": "wordpress"}`, lần
đầu mở URL sẽ thấy màn hình cài đặt WordPress 5 phút quen thuộc.

### Chạy nền liên tục: mức độ đảm bảo thật

- **Tắt màn hình**: chạy được bình thường — đây là Foreground Service +
  `PARTIAL_WAKE_LOCK` đúng chuẩn Android, không phải mẹo vặt.
- **Bị hệ thống âm thầm giết** (đặc biệt máy Xiaomi/Oppo/Vivo/Huawei...):
  KHÔNG đảm bảo được 100% dù đã bật hết bước 2 + 2b ở trên — đây là giới
  hạn thật của các bản Android tùy biến sâu, không phải lỗi app (xem
  dontkillmyapp.com). App có lớp phòng hờ thứ 2: `HealthCheckWorker` chạy
  độc lập qua WorkManager, tối đa mỗi 15 phút tự kiểm tra và bật lại server
  nếu bị giết mà người dùng chưa tắt — không tức thời, nhưng vẫn tự phục
  hồi thay vì phải mở tay.
- **Máy khởi động lại** (ai đó bấm nguồn, tự reboot sau cập nhật hệ thống):
  tự bật lại server qua `BootReceiver` (cần bật công tắc "Tự khởi động"
  trong app trước) — không cần mở app thủ công.
- **Máy tắt nguồn hoàn toàn**: KHÔNG có app nào (kể cả app này) tự bật lại
  được nguồn máy — đây là giới hạn phần cứng/firmware, không phải giới hạn
  của code. Vài dòng máy quảng cáo "báo thức sống sót qua tắt nguồn" là
  tính năng gắn cứng vào firmware của hãng cho đúng app Đồng hồ có sẵn,
  không có API công khai cho app bên thứ 3.

## Auto-Sleep MariaDB khi rảnh (tuỳ chọn, mặc định TẮT)

Đề xuất "Cơ chế Ngủ đông thông minh" trong tài liệu thiết kế gốc. Bật trong
app (switch "Tự tắt MariaDB khi rảnh") nếu muốn tiết kiệm RAM/pin cho website
ít truy cập — đổi lại request đầu tiên sau một thời gian dài không ai ghé sẽ
chậm hơn vài giây (MariaDB cần khởi động lại).

Cách hoạt động: 1 script PHP cực nhẹ (chỉ `touch()` 1 file, không ghi log)
chạy trước mọi trang PHP để đánh dấu "vừa có người dùng". Vòng lặp giám sát
có sẵn của `start-lamp.sh` (vốn đã kiểm tra mỗi 3 giây xem nginx/php-fpm/
mariadb có còn sống không) kiểm tra thêm mốc thời gian này — quá ngưỡng thì
gửi tín hiệu tắt êm cho MariaDB (không phải tắt đột ngột, tránh hỏng dữ liệu).
Khi có request mới, nginx tự chuyển hướng nội bộ sang 1 trang "đang khởi động
lại..." đồng thời âm thầm bật MariaDB lại, rồi tự đưa khách quay về đúng
trang họ định xem.

Giới hạn đã biết (thành thật, không che):
- `_admin/` (Adminer, quản lý file...) CHƯA được tích hợp cơ chế đánh thức —
  nếu vào đúng lúc MariaDB đang ngủ sẽ thấy lỗi kết nối database, tự tải lại
  trang sau vài giây là được (traffic thật từ khách sẽ tự đánh thức trước).
- Dùng khoá nhẹ (advisory lock) để giảm việc nhiều khách cùng lúc đều cố
  khởi động lại MariaDB, nhưng lớp bảo vệ CHÍNH vẫn là cơ chế tự chống chạy
  trùng có sẵn của MariaDB (từ chối khởi động lần 2 trên cùng thư mục dữ
  liệu) — rủi ro tồn dư cực thấp nhưng không phải bằng 0 tuyệt đối.
- Chưa build-test trên thiết bị thật (giống mọi tính năng khác của dự án ở
  giai đoạn này) — logic đã được mô phỏng kỹ (giả lập pipeline `sed`, kiểm
  tra cú pháp PHP/shell) nhưng hành vi thời gian thực (MariaDB thật mất bao
  lâu để khởi động lại trên phần cứng ARM di động) chưa đo được.



Vì đã dùng Cloudflare Tunnel, bạn có thể tận dụng thêm các tính năng MIỄN
PHÍ trên **dashboard Cloudflare** (dash.cloudflare.com) mà không cần đụng gì
tới app hay code — tất cả các mục dưới đây là cấu hình phía Cloudflare, xử
lý ở edge server của họ trước khi request chạm tới điện thoại của bạn:

- **Cache trang tĩnh** (Caching → Configuration, hoặc Page Rules): cache
  ảnh/CSS/JS giúp giảm đáng kể số request PHP/MariaDB phải xử lý thật trên
  máy.
- **HTTP/3 (QUIC)**: bật ở Network → HTTP/3 — Cloudflare tự thương lượng
  với trình duyệt, giảm tải xử lý TCP handshake, không cần cấu hình gì
  thêm ở nginx.
- **WAF miễn phí** (Security → WAF): chặn bot/quét lỗ hổng phổ biến trước
  khi tới website — giúp bạn KHÔNG cần cài thêm plugin bảo mật nặng (kiểu
  Wordfence) trên máy vốn đã hạn chế RAM.
- **Automatic Platform Optimization (APO)** — nếu chạy WordPress, đây là
  nâng cấp đáng cân nhắc nhất: Cloudflare cache TOÀN BỘ trang HTML (không
  chỉ ảnh/CSS/JS) ngay ở edge, khiến điện thoại gần như "vô hình" với
  lượng truy cập đọc thông thường (chỉ còn phải xử lý request thật sự động
  như đăng nhập/bình luận). Miễn phí nếu đang dùng gói Pro trở lên, 5
  USD/tháng nếu đang dùng gói Free. Cách bật:
  1. 1-Click Installer (`_admin/install-wp.php`) có sẵn tùy chọn tải trước
     plugin "Cloudflare" chính thức khi cài WordPress — để nguyên checkbox
     mặc định là đủ.
  2. Vào trang quản trị WordPress → Plugins → kích hoạt "Cloudflare" → nhập
     email + API Token (tạo tại dash.cloudflare.com).
  3. Trên dashboard Cloudflare của domain → tab Speed → bật "Automatic
     Platform Optimization for WordPress".

  Lưu ý: khi dùng Cloudflare Tunnel, mọi request công khai đến `nginx` đều
  qua `127.0.0.1` (do `cloudflared` chạy local) nên mặc định WordPress/log
  sẽ thấy MỌI khách là `127.0.0.1`, không phân biệt được ai với ai — làm
  sai các plugin chống spam/giới hạn đăng nhập theo IP. Bản cập nhật này đã
  thêm cấu hình khôi phục IP thật từ header `CF-Connecting-IP` trong
  `nginx.conf.template` (tự dò xem bản `nginx` của Termux có module
  `realip` hay không trước khi bật, không giả định — nếu không có thì tự
  bỏ qua an toàn, không làm nginx từ chối khởi động). Chưa verify module
  này có mặt trong bản `nginx` thật của Termux hay không (giống mọi phần
  "chưa verify" khác của dự án — xem mục "Nói thẳng" bên dưới).

## Những đánh đổi thật cần biết trước khi dùng lâu dài

- Điện thoại không có nguồn điện dự phòng, RAID, hay backup tự động như
  datacenter — mất điện/rớt WiFi là site sập ngay.
- Bảo mật (cập nhật WordPress/dependency, vá lỗ hổng) hoàn toàn do bạn tự quản.
- Quick Tunnel phù hợp: site cá nhân, học tập, demo, traffic thấp.
- Không phù hợp: site kinh doanh cần uptime cao — lúc đó một VPS giá rẻ vẫn
  đáng tiền hơn nhiều so với rủi ro mất dữ liệu/downtime.
