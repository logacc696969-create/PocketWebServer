# WP Pocket Server

Source code Android (Kotlin + Gradle) — build APK tự động qua GitHub Actions.
Biến điện thoại Android thành server chạy **một website duy nhất**, backend
**không hardcode** trong app — chọn PHP/Node/Python/static chỉ bằng cách sửa
1 file `site.config.json`, không đụng code Kotlin hay workflow.

> **Dành cho ai, không dành cho ai, và giá trị cốt lõi:** xem `docs/VALUE_AND_AUDIENCE.md`. Tóm tắt: host một website nhỏ trên điện thoại Android cũ, ra Internet không cần VPS/mở cổng/IP tĩnh. **Không phù hợp** cho website thương mại cần uptime, lưu lượng lớn, nhiều website, hay dữ liệu nhạy cảm. Đang trong giai đoạn **thử nghiệm miễn phí** (`docs/BETA_PROGRAM.md`).

Kèm sẵn Cloudflare Quick Tunnel: server có URL https công khai ngay lập tức,
không cần mở port router, không cần IP tĩnh (giải quyết đúng vấn đề CGNAT của
mạng di động/cáp quang hộ gia đình ở VN). Có thể dán token Cloudflare để dùng
domain cố định thay vì URL ngẫu nhiên đổi mỗi lần khởi động lại.

**Runtime PHP mặc định dùng nginx + php-fpm + MariaDB thật** (không phải
`php -S` dev server + SQLite) — xử lý đồng thời đúng nghĩa, tương thích
plugin WordPress cần MySQL thật. Có nút "Backup ngay" trong app để zip
website + dump database ra bộ nhớ ngoài.

Kèm sẵn **Adminer** (quản lý database) + **File Manager** (quản lý file) +
**dashboard hệ thống** (RAM/dung lượng còn trống, trạng thái 3 dịch vụ) +
**1-Click Install WordPress** + **Xác thực 2 bước (2FA)** + **Chế độ bảo
trì 1 nút** + **Thống kê RAM/dung lượng/tải theo thời gian** tại `/_admin/`
— chỉ truy cập được qua mạng LAN (tự động chặn khỏi URL Cloudflare public),
cộng thêm mật khẩu riêng sinh ngẫu nhiên mỗi máy (xem trong app). Hướng dẫn
dùng từng mục ở phần **"Trang quản trị `/_admin/`"** bên dưới.

**Tự động hoá**: backup định kỳ theo lịch (không chỉ bấm tay, có thể giới
hạn "chỉ chạy khi đang sạc") + gửi báo cáo/file backup qua **Telegram Bot**
hoặc **webhook** tuỳ ý + **điều khiển từ xa qua Telegram** (`/status`
`/backup` `/restart`) + tự khởi động lại server nếu bị hệ điều hành Android
giết tiến trình dù người dùng vẫn muốn server chạy ("watchdog"). Xem mục
"Tự động hoá" trong app và phần chi tiết bên dưới.

**Dual-Mode PHP-Lite**: máy RAM thấp (dưới 3GB) tự động chuyển sang chế độ
nhẹ (`php -S` thay vì nginx+php-fpm+MariaDB đầy đủ) để vẫn chạy được thay vì
đơ máy — có thể ép tay Luôn bật/Luôn tắt/Tự động trong app. Xem mục riêng
bên dưới.

**Auto-Sleep MariaDB khi rảnh** (tuỳ chọn, mặc định TẮT — xem mục riêng bên
dưới): tự tắt MariaDB nếu không có ai truy cập trong N phút để tiết kiệm
RAM/pin, tự "đánh thức" lại trong vài giây khi có khách quay lại.

## File DUY NHẤT bạn cần sửa: `site.config.json`

```jsonc
{
  "runtime": "php",              // "php" | "node" | "python" | "static"
  "port": 8080,
  "entry": "",                   // "server.js" (node) / "app.py" (python), bỏ trống = mặc định
  "site_source": {
    "type": "wordpress",         // "wordpress" | "git" | "local" | "zip"
    "repo": "",                  // dùng khi type=git
    "branch": "main",
    "path": "site",              // dùng khi type=local (commit code vào thư mục này)
    "url": "",                   // dùng khi type=zip
    "sha256": ""                 // TUỲ CHỌN, type=zip: SHA-256 của file zip; sai => dừng build (xem mục "Xác minh toàn vẹn")
  }
}
```

Đổi backend hay đổi website = sửa file này rồi push. Workflow tự đọc, tự tải
đúng runtime + đúng nguồn code, tự build lại APK.

**Không muốn sửa tay?** Thư mục `presets/` có sẵn 7 cấu hình mẫu, và công cụ
`apply_preset.py` ghi đè `site.config.json` *sau khi kiểm tra hợp lệ* (từ chối
nếu sai thay vì ghi file hỏng):

```bash
python3 scripts/tools/apply_preset.py --list
python3 scripts/tools/apply_preset.py wordpress                      # mặc định của dự án
python3 scripts/tools/apply_preset.py static-local                   # web tĩnh: code ở thư mục site/
python3 scripts/tools/apply_preset.py node-git --repo https://github.com/ban/app.git --port 3000
```

Công cụ chặn những lỗi hay gặp: cổng < 1024 (Android không bind được) hoặc 65535
(staging dùng cổng + 1); `entry` có `..`, dấu nháy hay khoảng trắng (giá trị này
được chèn thẳng vào JSON khởi động); `type=wordpress` đi với runtime khác `php`;
`repo` không phải `https://`/`git@` hoặc bắt đầu bằng `-`.

### Chẩn đoán và hiệu năng (vòng 1bp)

- **Cảnh báo lỗi PHP nghiêm trọng.** Mỗi chu kỳ kiểm tra sức khoẻ (15 phút) app đọc phần mới của `lamp-run/php-error.log` (PHP tự ghi sẵn), nhận ra lỗi *hết bộ nhớ*, *quá thời gian thực thi*, *lỗi cú pháp*, *lỗi không được xử lý*, gom các lỗi giống nhau lại và gửi Telegram tối đa 1 lần/giờ. Trước đây một plugin làm trang trắng (HTTP 500) chỉ để lại dấu trong file log mà không ai được báo.
- **Kiểm tra cơ sở dữ liệu.** Nút **Kiểm tra cơ sở dữ liệu** chạy `CHECK TABLE … QUICK` cho từng bảng MariaDB (chỉ đọc). App **không tự sửa** (InnoDB không dùng được REPAIR và sửa tự động có thể làm hỏng thêm); nếu có bảng lỗi hãy sao lưu và cân nhắc khôi phục. Chế độ Lite (SQLite) không có bước này.
- **Ngưỡng và quy tắc cảnh báo.** Nút **Ngưỡng và quy tắc cảnh báo…** cho chỉnh 4 ngưỡng (bộ nhớ đầy, pin cạn, pin ấm, pin quá nóng; luôn được kẹp vào khoảng hợp lý) và tự viết quy tắc, mỗi dòng một quy tắc, ví dụ `high_ram: ram_percent > 90 for 15m` (6 chỉ số, tối đa 20 quy tắc, báo lỗi từng dòng, gửi qua Telegram). Chi tiết: `docs/ALERT_RULES.md`.
- **Ứng dụng Python (Flask, Django…).** Runtime `python` có máy chủ WSGI **và ASGI** đi kèm (chỉ thư viện chuẩn, thay gunicorn/uvicorn): đặt `"wsgi": "app:app"` (Flask/Django) hoặc `"asgi": "app:app"` (Starlette) — hoặc `python3 scripts/tools/apply_preset.py python-wsgi` / `python-asgi`. Đa luồng có giới hạn, thời hạn kết nối, giới hạn body, lifespan, dừng sạch. Không có WebSocket/SSE; FastAPI mới cần pydantic-core native nên không chạy được trên Android. Chi tiết: `docs/PYTHON_WSGI.md`.
- **Công cụ dòng lệnh `wppocket`.** Chạy trên máy tính cùng mạng LAN: `python3 scripts/tools/wppocket_cli.py status` (hoặc `--check` kiểu Nagios cho cron/giám sát). Dùng API trạng thái chỉ đọc nên chỉ giám sát, không điều khiển. Chi tiết: `docs/CLI.md`.
- **Kiểm thử hỗn loạn.** `python3 scripts/tests/chaos-test.py` gây sự cố ngẫu nhiên (seed tái lập được) lên bộ giám sát thật; `scripts/chaos/chaos-device.sh` cho các kịch bản trên điện thoại (giết app/daemon, đầy bộ nhớ, mất mạng). Bảng cái gì đã kiểm, cái gì chưa: `docs/CHAOS_TESTING.md`.
- **Thử nghiệm miễn phí.** Ứng dụng ban đầu phát hành miễn phí cho người dùng kiểm thử độ ổn định, sau đó mới xem xét tính phí (giấy phép/giá do chủ dự án quyết). Hướng dẫn cho người thử: `docs/BETA_PROGRAM.md`; điều khoản dùng thử (bản nháp): `TERMS.md` điều 7; ghi chú pháp lý (dữ liệu cá nhân ở Việt Nam, mật mã/xuất khẩu — không phải tư vấn pháp lý): `docs/LEGAL_NOTES_VN.md`.
- **Tối ưu ảnh (WordPress).** mu-plugin `wppocket-images` cài sẵn: giới hạn ảnh hiển thị 1920 px, tạo kích thước phụ WebP cho ảnh JPEG mới, chỉnh chất lượng; tuỳ chọn xoá ảnh gốc (mặc định tắt). Chưa chạy với WordPress thật. Chi tiết: `docs/IMAGE_OPTIMIZATION.md`.
- **Trợ năng.** Đã rà bằng `scripts/tools/a11y_audit.py` (vùng chạm ≥ 48dp, nhãn cho ô nhập, live region cho trạng thái…); chưa thử TalkBack thật. Xem `docs/ACCESSIBILITY.md`.
- **Mở rộng và quản trị dự án.** Không có bộ nạp plugin; các điểm mở rộng thật (runtime, công cụ admin, kênh thông báo): `docs/EXTENDING.md`. Mô hình quản trị: `docs/GOVERNANCE.md`. Kịch bản video hướng dẫn: `docs/VIDEO_TUTORIAL_SCRIPT.md`.
- **Hiệu năng PHP.** Nút **Hiệu năng PHP…** chọn hồ sơ: *Tiết kiệm RAM* (mặc định, không đổi gì: 128 MB / 60 giây / tệp 32 MB), *Plugin nặng* (256 MB / 120 giây / 64 MB) hoặc *Tải/nhập tệp lớn* (192 MB / 300 giây / 128 MB). Cần khởi động lại server. Ba tầng (nginx `client_max_body_size`, PHP `post_max_size`, `upload_max_filesize`) và `fastcgi_read_timeout` luôn được chỉnh khớp nhau; hồ sơ nặng dùng nhiều RAM hơn.
- **Backup trên thẻ nhớ.** Tuỳ chọn **Lưu backup mới trên thẻ nhớ khi có** (mặc định tắt) ghi các tệp zip backup mới sang thẻ nhớ nếu máy có và ghi được; không có thẻ thì lưu như cũ. Danh sách khôi phục và việc giữ 5 bản gộp cả hai nơi. Chỉ backup được lưu sang thẻ — không bao giờ CSDL hay website.
- **API trạng thái chỉ đọc cho mạng LAN (tuỳ chọn, mặc định tắt).** Bật hộp kiểm **API trạng thái chỉ đọc…**, khởi động lại server, rồi bấm **Địa chỉ và token API…** để lấy địa chỉ `http://<IP-máy>:<cổng>/api/v1/status` và token (256 bit, lưu mã hoá). Gọi bằng `curl -H "Authorization: Bearer <token>" <địa chỉ>` sẽ nhận JSON: server đang chạy, % pin và đang sạc, % bộ nhớ đã dùng, giờ backup cuối, số backup, phiên bản app, `generated_at` (dữ liệu làm mới tối đa mỗi ~15 phút). **Chỉ** nhận yêu cầu từ dải mạng riêng (192.168/16, 10/8, 172.16/12); từ Internet (kể cả qua tunnel) bị chặn, và **không có endpoint nào ghi hay điều khiển** (không backup/khởi động lại qua API). Đổi token trong cùng hộp thoại (có hiệu lực sau khi khởi động lại server). Dùng cho Home Assistant, Uptime Kuma, script riêng…
- **Mã request.** Mỗi request có mã ngẫu nhiên ở header `X-Request-ID` và ở cuối dòng log `nginx-access.log` (`rid=…`). Khi ai đó báo lỗi, chỉ cần mã này để tìm đúng dòng log.

### Kiểm tra `site.config.json` ngay đầu build

CI chạy `python3 scripts/tools/validate_config.py site.config.json` trước mọi bước khác: báo **dòng và cột** khi JSON sai cú pháp (kèm gợi ý dấu phẩy thừa, chú thích `//`, nháy đơn), báo **tên khoá gõ sai** kèm gợi ý (ví dụ `instal_deps` → `install_deps`; trước đây khoá sai bị bỏ qua im lặng), kiểm tra giá trị (cổng, runtime, nguồn git/zip, `sha256`…). Khoá `config_version` (hiện là `1`, có thể vắng) cho phép đổi định dạng sau này mà không âm thầm hiểu sai file cũ. Khoá bắt đầu bằng `_` là ghi chú, luôn được bỏ qua. Chạy tay cùng lệnh trên máy bạn để kiểm tra trước khi đẩy lên.

### Mức hỗ trợ theo loại ứng dụng (đọc kỹ trước khi chọn)

| Loại | Phần chạy | Vận hành kiểu hosting (nginx, header bảo mật, gzip, rate-limit, bảo trì, analytics, `_admin/`) |
|---|---|---|
| **WordPress** | nginx + php-fpm + MariaDB | Đầy đủ, kèm WP-CLI, staging, rollback lõi, chế độ an toàn plugin |
| **Ứng dụng PHP bất kỳ** (Laravel, Symfony, Slim, CodeIgniter, PHP thuần…) | nginx + php-fpm + MariaDB cục bộ | Đầy đủ như WordPress **trừ** các trang chỉ dành cho WordPress |
| **Node / Python** | Chạy thẳng tiến trình của bạn trên một cổng | **Chưa có** — không nginx, không `_admin/`; chỉ có tính năng mức app (tunnel, giám sát, pin/nhiệt, backup file, Telegram) |
| **Web tĩnh** | Máy chủ file đơn giản | Như Node/Python |

**Ứng dụng PHP bất kỳ** — ba tuỳ chọn trong `site.config.json` (đều không bắt buộc, mặc định giữ hành vi cũ):

- `"docroot": "public"` — thư mục con được phục vụ làm web root (Laravel/Symfony/Slim: `public`). `.env`, `composer.json`,
  `vendor/`, `storage/` nằm **ngoài** web root nên không tải được từ bên ngoài. Có tác dụng cả với runtime `static` (`dist`, `build`…).
  Tiny File Manager trong `_admin/` vẫn thấy cả dự án.
- `"profile": "auto"` — `auto` nhận WordPress theo nguồn (type=wordpress, có dấu hiệu WordPress, hoặc nguồn trống để cài WP
  1-click), còn lại là `generic`. Ép bằng `wordpress` hoặc `generic`. Với `generic`, menu `_admin/` **không** hiện WP-CLI, Staging,
  Rollback, Chế độ an toàn, nút "Cài WordPress" và các trang đó không được triển khai.
- `"db_name": ""` — tên database tạo sẵn (mặc định `wordpress` cho WordPress, `app` cho ứng dụng khác). Ứng dụng **không cần sửa file
  cấu hình**: kết nối được truyền qua biến môi trường `DB_CONNECTION=mysql`, `DB_HOST=localhost`, `DB_SOCKET`, `DB_DATABASE`,
  `DB_USERNAME`, `DB_PASSWORD` (Laravel và nhiều framework đọc sẵn). Tài khoản chỉ có quyền trên database của nó (và `<tên>_*`),
  kết nối chỉ qua unix socket nội bộ (MariaDB chạy `--skip-networking`); tên tài khoản = mật khẩu = tên database.

Preset sẵn: `php-local`, `php-git` (`python3 scripts/tools/apply_preset.py php-git --repo https://github.com/ban/app.git`).

> **Chưa thử với Laravel thật** (cần `composer install` từ packagist, không truy cập được khi phát triển). Đã kiểm bằng một ứng dụng
> mẫu có cùng cấu trúc (bộ điều khiển trước `public/index.php`, URL đẹp, `.env`/`vendor` ngoài web root, kết nối CSDL bằng biến môi
> trường) trên nginx + php-fpm + MariaDB thật. Chưa có chế độ "không cần MariaDB" — MariaDB luôn được bật cho runtime PHP.

### Ứng dụng Node / Python / PHP có thư viện (dependency)

Với `runtime` là `node`, `python` hoặc `php` (không phải WordPress), CI **tự cài thư viện lúc build** — bạn
không cần commit `node_modules`/thư viện Python/`vendor` nữa (`"install_deps": true` mặc định):

| Có file này | CI chạy | Kết quả trong APK |
|---|---|---|
| `package.json` | `npm ci` (nếu có lock) hoặc `npm install`, `--omit=dev --ignore-scripts` | `node_modules/` |
| `requirements.txt` | `pip install --only-binary=:all:` | `.pylibs/` (tự thêm vào `PYTHONPATH`) |
| `composer.json` | `composer install --no-dev --no-scripts --no-plugins` | `vendor/` |

**An toàn trước, tiện lợi sau:** script cài đặt của gói **không bao giờ chạy** (npm/composer tắt script; pip chỉ nhận
*wheel*, không chạy `setup.py`) — gói chỉ có mã nguồn cần biên dịch sẽ bị từ chối và build **thất bại rõ ràng** thay vì ra
một APK chạy hỏng. Đã có sẵn `node_modules`/`.pylibs`/`vendor` trong nguồn thì CI bỏ qua. Tắt hẳn: `"install_deps": false`.

**Giới hạn thật — mã native không chạy được trên Android.** Thư viện được cài trên máy build (x86_64, glibc) nên addon
`.node` hay module `.so` của Python **không nạp được** trên điện thoại. CI cảnh báo tên gói; riêng Python thì xoá các
`.so` đó (gói có đường lui Python thuần như MarkupSafe vẫn chạy bình thường, gói bắt buộc có mã biên dịch sẽ báo
`ImportError` khi chạy). Hãy dùng thư viện thuần JS/Python. Composer: build không kiểm tra được `ext-*` — CI liệt kê các
extension ứng dụng cần để bạn đối chiếu với `php -m` của Termux.

**WSGI / WebSocket:** mặc định runtime Node và Python chạy server riêng ngay trên cổng của app (không đi qua nginx) nên không cần
cấu hình `Upgrade` cho WebSocket (và Cloudflare chuyển tiếp WebSocket sẵn). Bật `"front_proxy": true` (mục ngay dưới) thì nginx đã có sẵn `Upgrade`. Muốn WSGI "thật" cho Flask/Django, thêm một server **thuần Python** như `waitress` vào
`requirements.txt` và đặt `entry` là file khởi chạy nó. `waitress` chạy một tiến trình nhiều luồng nên hợp RAM hạn chế;
`gunicorn` mặc định tách nhiều tiến trình (tốn RAM hơn) — dùng được hay không còn tuỳ máy, dự án chưa thử trên thiết bị.

### Node / Python / static: đóng gói thư viện và nginx phía trước (tuỳ chọn)

**Đóng gói đúng cách (áp dụng cho cả ba runtime, không cần bật gì).** Binary Termux của Node, Python, php-CLI cần các thư viện có số phiên bản
(`libz.so.1`, `libicuuc.so.77`…). Android chỉ nạp thư viện tên `lib*.so` từ thư mục native của app, nên build đổi tên chúng, ghi bảng
`soname-map.txt`, và `start-generic.sh` dựng lại symlink đúng tên gốc lúc chạy (cùng cơ chế đã chạy ổn trên thiết bị với runtime PHP). Riêng
**Python** còn được đóng gói đầy đủ thư viện chuẩn (`os`, `encodings`…) và các module mở rộng (`_socket`, `math`…). Trước bản này hai việc đó
chưa có nên runtime Python không khởi động được. CI có job `runtime-packaging` dựng thật gói Termux cho từng runtime rồi kiểm tra **mọi phụ thuộc
của mọi file ELF đều có mặt** (không cần điện thoại); job này hiện chỉ *báo* (không chặn APK) cho tới khi đã thử trên thiết bị thật.

**nginx phía trước (`"front_proxy"` trong `site.config.json`).**
- `node` / `python`: mặc định `false`. Đặt `true` để nginx nghe cổng công cộng và chuyển tiếp tới app (app tự nghe `PORT+1`): thêm header
  bảo mật (X-Frame-Options, nosniff, Referrer-Policy, CSP tập con, HSTS có điều kiện), nén gzip, `X-Forwarded-For`/`X-Real-IP` đúng IP khách
  qua Cloudflare, WebSocket (`Upgrade`), và `/healthz` (HEAD `/` tới app: 502 khi app chết). App chết hoặc nginx chết thì cả bộ được dừng và
  khởi động lại. Lưu ý: app vẫn nghe trên mọi giao diện ở cổng nội bộ `PORT+1`; hãy cho app đọc biến `HOST` nếu muốn chỉ nghe `127.0.0.1`.
- `static`: mặc định `true` — nginx phục vụ thẳng thư mục web (gzip, ETag/304, Cache-Control 7 ngày cho ảnh/CSS/JS, header bảo mật, chặn
  dotfile và thư mục điều phối `_supervisor/`) và **không cần php** nên APK nhỏ hơn nhiều. `false` = `php -S` như trước.
- Đổi bằng preset: `python3 scripts/tools/apply_preset.py node-local --front-proxy true`.
- Không có ở runtime `php`: PHP đã có nginx riêng đầy đủ hơn (rate-limit, bảo trì, page cache…).

## Kiến trúc: vì sao "không hardcode"

- **`ServerForegroundService.kt`**: một Foreground Service chuẩn của Android
  (giống service phát nhạc, VPN, tải file). Nó **không biết** mình đang chạy
  PHP hay Node — nó chỉ đọc `assets/runtime.json` (một file JSON tả "chạy
  lệnh gì, port nào, biến môi trường nào") rồi `ProcessBuilder` thực thi.
  Giữ notification cố định + `PARTIAL_WAKE_LOCK` để Android không kill khi
  tắt màn hình; tự khởi động lại nếu tiến trình crash.
- **`RuntimeConfig.kt`**: parse `runtime.json`, thay các placeholder
  `${BIN}` `${PORT}` `${DOCROOT}` `${FILESDIR}` thành giá trị thật. Đây là
  toàn bộ "logic" mà app biết — mọi thứ cụ thể (PHP cần `-S -t`, Node cần
  chạy file `.js`, Python cần `-m http.server`...) nằm trong shell script
  phía CI, không nằm trong app.
- **`scripts/runtimes/{php,node,python,static}.sh`**: mỗi script lo phần
  "backend cụ thể" — tải đúng binary + sinh đúng `runtime.json`. Thêm backend
  mới (vd Ruby) = thêm 1 file script mới theo đúng khuôn mẫu, không sửa app.
- **`scripts/lib/termux_fetch.sh`**: hàm dùng chung để tải binary build sẵn
  cho Android từ kho gói mã nguồn mở Termux (dùng cho php/node/python).
- **`scripts/lib/site_source.sh`**: hàm dùng chung để lấy mã nguồn website
  theo `site_source.type` (WordPress / git repo riêng / thư mục local commit
  sẵn / file zip).
- **`ServerForegroundService`** cũng chạy song song `cloudflared` (Cloudflare
  Quick Tunnel) — binary Go build tĩnh, tải trực tiếp từ GitHub release của
  Cloudflare, không qua Termux nên không có vấn đề thiếu `.so`.

**Node/Python/static**: 1 binary duy nhất, đặt tên `libruntimesrv.so` trong
`jniLibs/<abi>/`. **PHP** (nginx+php-fpm+MariaDB): NHIỀU binary
(`libnginx.so`, `libphpfpm.so`, `libmariadbd.so`, `libmariadbinstall.so`,
`libmysqlcli.so`, `libmysqldump.so`) chạy cùng lúc, giám sát bởi 1 script
`start-lamp.sh` — xem `scripts/runtimes/templates/`. Quy ước đặt tên `lib*.so`
khiến PackageManager tự cấp quyền thực thi khi cài app, né giới hạn W^X
(chặn thực thi file tự giải nén ra thư mục ghi được) áp dụng từ Android 10
trở lên — áp dụng cho MỌI binary kể trên, không riêng gì `libruntimesrv.so`.

Cổng quản trị (`/_admin/` — Adminer, File Manager, Log, PHP Info) chỉ tồn
tại với runtime `php`, do `scripts/lib/admin_tools.sh` tải + gắn cổng xác
thực (`_admin/auth.php`, mật khẩu ngẫu nhiên sinh bởi
`ServerForegroundService.ensureAdminPassword()`), chặn khỏi URL public ở
tầng nginx (`_admin/` chỉ allow dải IP LAN, xem `nginx.conf.template`).

## Nói thẳng: phần nào chắc chắn, phần nào chưa

**Chắc chắn** (API Android chuẩn, không mơ hồ):
- Chạy nền khi tắt màn hình (Foreground Service + WakeLock)
- Tự khởi động lại khi tiến trình crash, tự bật lại sau khi khởi động lại máy
- Cloudflare Tunnel outbound-only → có URL public mà không cần port-forward

**Rủi ro thật, cần tự kiểm chứng khi build lần đầu** — nằm ở
`scripts/lib/termux_fetch.sh`: binary php/node/python "mượn" từ kho Termux,
vốn build để chạy đúng layout thư mục Termux. Khi tách ra dùng riêng, có thể
thiếu vài thư viện `.so` phụ thuộc gián tiếp hoặc sai đường dẫn config mặc
định. Đây là bản chất kỹ thuật của việc tái sử dụng binary ngoài môi trường
gốc — không phải giới hạn riêng của cách làm này. `cloudflared` **không** có
vấn đề này vì là binary Go build tĩnh, tự chứa toàn bộ dependency.

Nếu app báo lỗi kiểu "cannot open shared object" / "undefined symbol" (xem
`adb logcat | grep -E "site|php|node"`):
1. Xem log để biết thiếu thư viện `.so` nào
2. Tìm gói Termux chứa nó: https://github.com/termux/termux-packages
3. Thêm tên gói vào `extra_deps` khi gọi `termux_download_with_deps` trong
   script runtime tương ứng, hoặc bổ sung thủ công vào `jniLibs/arm64-v8a/`

Tương tự, chưa xác nhận bản `nginx` "mượn" từ Termux có biên dịch sẵn module
`ngx_http_realip_module` hay không (module này dùng để khôi phục IP thật của
khách sau Cloudflare Tunnel — xem mục APO bên dưới). `start-lamp.sh` đã tự dò
qua `nginx -V` trước khi bật, nên nếu module này không có, tính năng đó chỉ
tự tắt chứ không làm app lỗi.

### Kế hoạch B (chắc chắn hơn, tốn công hơn)

Nếu "mượn binary Termux" gặp quá nhiều lỗi thư viện, hướng chắc chắn hơn về
lâu dài là tự biên dịch runtime từ mã nguồn bằng Android NDK, tĩnh hoá
(static-link) các phần cần thiết vào một binary duy nhất — loại bỏ hoàn toàn
vấn đề thiếu `.so`. Việc này tốn công dựng toàn bộ build chain (vd với PHP:
zlib, openssl, sqlite, php qua `--enable-static` + toolchain NDK) nên không
đưa sẵn vào đây, nhưng là hướng nên làm nếu dùng app này nghiêm túc/lâu dài.

Không cần dựng từ số 0: dự án PocketMine-MP (server Minecraft chạy trên
Android) đã có sẵn pipeline build PHP tĩnh hoàn toàn cho target
`android-aarch64` bằng toolchain `aarch64-linux-musl`
(https://github.com/pmmp/PHP-Binaries) — dùng làm điểm khởi đầu tham khảo
tốt cho phần PHP. `nginx` và MariaDB thì chưa có pipeline tương tự sẵn có,
vẫn phải tự dựng.

## Build APK

```bash
cd wp-pocket-server
git init && git add . && git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<ten-ban>/<ten-repo>.git
git push -u origin main
```

**Cách khác (không cần git ở máy)**: nén cả thư mục `wp-pocket-server/`
thành 1 file `.zip`, upload thẳng file đó + thư mục `.github/workflows/`
(chứa `build-apk.yml`) lên repo GitHub qua giao diện web. `build-apk.yml`
tự nhận diện repo chỉ có file zip (không có source checkin trực tiếp) và tự
giải nén trước khi build — không cần thêm bước nào khác. Chỉ cần nhớ: mỗi
khi sửa gì trong file zip, `.github/workflows/build-apk.yml` PHẢI luôn là
bản đang chạy thật trên GitHub (workflow không nằm trong zip, GitHub đọc nó
trực tiếp) — 2 chỗ này dễ bị lệch nhau nếu chỉ cập nhật 1 trong 2.

Vào tab **Actions** trên GitHub — workflow `Build APK` tự chạy (đọc
`site.config.json`, tải đúng runtime + website + cloudflared, build APK).
Tải file `.apk` ở mục **Artifacts** của lần chạy đó, cài lên máy (cần bật
"Cài từ nguồn không xác định" vì là bản debug chưa ký Play Store).

Cũng mở được trực tiếp bằng Android Studio để build/debug local (Android
Studio tự tạo Gradle wrapper nếu project chưa có).

## Sau khi cài app

1. Mở app, bấm **Bật server**. Lần đầu mất chút thời gian giải nén website.
1b. Nếu trạng thái không chuyển sang "Đang chạy" sau khoảng 1 phút (hoặc
   hiện dòng "⚠️ Không lên được") — bấm **Xem log** (luôn bấm được, kể cả
   khi server lỗi, vì đọc thẳng file trên đĩa chứ không qua web server) —
   chọn tab "start-lamp.sh" trước tiên để xem tổng quan lỗi khởi động.
2. Bấm **Bỏ qua tối ưu hoá pin** — nếu không, Android vẫn có thể tạm dừng
   service sau thời gian dài không dùng máy (Doze mode), dù đã là Foreground
   Service.
2b. Nếu máy là Xiaomi/Redmi, Oppo/Realme, Vivo, Huawei/Honor, Samsung, hoặc
   OnePlus: bấm thêm **Mở cài đặt Tự khởi động của hãng máy**. Các hãng này
   có thêm 1 lớp quản lý pin RIÊNG ngoài Android gốc, có thể vẫn tắt ngầm
   Foreground Service dù bước 2 đã làm đúng — đây là vấn đề rất phổ biến với
   Android tùy biến sâu (xem dontkillmyapp.com), không phải lỗi của app.
   Nút này dùng các màn hình cài đặt không chính thức của từng hãng (best-
   effort, có thể không khớp trên vài phiên bản ROM cụ thể) — nếu không mở
   được màn hình riêng, sẽ tự chuyển sang trang chi tiết ứng dụng chuẩn, tự
   tìm mục Pin/Tự khởi động bên trong.
3. App hiện 2 địa chỉ:
   - **LAN**: `http://192.168.x.x:8080` — chỉ dùng được cùng mạng WiFi
   - **Công khai**: `https://xxx.trycloudflare.com` — truy cập được từ bất
     kỳ đâu có Internet, đổi mỗi lần khởi động lại server (Quick Tunnel,
     miễn phí không cần tài khoản). Muốn domain cố định: tạo tunnel trên
     dashboard Cloudflare (miễn phí), dán token vào ô "Cloudflare Tunnel
     token" trong app rồi bật lại server.
4. **Mật khẩu quản trị** hiện sẵn trong app — bấm "Mở trang quản trị" để
   vào Adminer (database) + File Manager + Log + PHP Info tại `/_admin/`
   (chỉ vào được qua cùng mạng LAN, không qua URL public).
5. Nút **"Backup ngay"** — zip website + dump database vào
   `Android/data/<package>/files/backups/` trên máy.
5b. Nút **"Khôi phục từ backup"** — chọn 1 trong các bản backup đã có, xác
   nhận rồi ghi đè website + database hiện tại bằng bản đó. Nên dừng server
   trước khi khôi phục. Không thể hoàn tác sau khi xác nhận.

Nếu chọn `"runtime": "php"` + `"site_source": {"type": "wordpress"}`, lần
đầu mở URL sẽ thấy màn hình cài đặt WordPress 5 phút quen thuộc.

### Chạy nền liên tục: mức độ đảm bảo thật

- **Tắt màn hình**: chạy được bình thường — đây là Foreground Service +
  `PARTIAL_WAKE_LOCK` đúng chuẩn Android, không phải mẹo vặt.
- **Bị hệ thống âm thầm giết** (đặc biệt máy Xiaomi/Oppo/Vivo/Huawei...):
  KHÔNG đảm bảo được 100% dù đã bật hết bước 2 + 2b ở trên — đây là giới
  hạn thật của các bản Android tùy biến sâu, không phải lỗi app (xem
  dontkillmyapp.com). App có lớp phòng hờ thứ 2: `HealthCheckWorker` chạy
  độc lập qua WorkManager, tối đa mỗi 15 phút tự kiểm tra và bật lại server
  nếu bị giết mà người dùng chưa tắt — không tức thời, nhưng vẫn tự phục
  hồi thay vì phải mở tay.
- **Máy khởi động lại** (ai đó bấm nguồn, tự reboot sau cập nhật hệ thống):
  tự bật lại server qua `BootReceiver` (cần bật công tắc "Tự khởi động"
  trong app trước) — không cần mở app thủ công.
- **Máy tắt nguồn hoàn toàn**: KHÔNG có app nào (kể cả app này) tự bật lại
  được nguồn máy — đây là giới hạn phần cứng/firmware, không phải giới hạn
  của code. Vài dòng máy quảng cáo "báo thức sống sót qua tắt nguồn" là
  tính năng gắn cứng vào firmware của hãng cho đúng app Đồng hồ có sẵn,
  không có API công khai cho app bên thứ 3.

## Trang quản trị `/_admin/` — hướng dẫn từng mục

Vào bằng nút **"Mở trang quản trị"** trong app, hoặc gõ tay
`http://<IP-LAN-cua-may>:<port>/_admin/` trên trình duyệt của **bất kỳ máy
nào cùng mạng WiFi** (điện thoại khác, laptop...) — không vào được từ URL
Cloudflare public, đây là chủ ý (chặn ở tầng nginx, xem mục kiến trúc phía
trên). Nhập mật khẩu hiện sẵn trong app (sinh ngẫu nhiên, đổi được — xem
mục 2FA bên dưới).

- **Adminer** — quản lý database MySQL/MariaDB bằng giao diện web, không
  cần biết SQL để xem/sửa dữ liệu cơ bản. Đăng nhập tự động (thông tin kết
  nối đã điền sẵn), không cần tự nhớ tên database/user/mật khẩu MariaDB.
- **File Manager** (Tiny File Manager) — xem/sửa/xoá/tải lên file trong thư
  mục website trực tiếp từ trình duyệt, không cần FTP/SSH.
- **Xem log** — đọc trực tiếp file log trên đĩa (nginx, php-fpm, mariadb,
  `start-lamp.sh`) theo tab, kể cả khi server đang LỖI không lên được (đọc
  thẳng file, không qua web server nên không phụ thuộc server sống hay
  chết). Đây là nơi đầu tiên nên xem khi server báo lỗi.
- **Thông tin hệ thống** — RAM còn trống, dung lượng đĩa, trạng thái sống
  của nginx/php-fpm/mariadb, chế độ đang chạy (Đầy đủ/Lite).
- **Cài WordPress 1-Click** — chỉ hiện khi thư mục web đang trống. Bấm 1
  nút, tự tải WordPress mới nhất từ wordpress.org + tự kết nối database có
  sẵn (không cần tự nhập thông tin database) — mất 30 giây tới 2 phút tuỳ
  mạng. Có sẵn ô chọn tải trước plugin **Cloudflare** chính thức (khuyên để
  nguyên, dùng cho Automatic Platform Optimization — xem mục Cloudflare bên
  dưới), chỉ tải file chứ chưa tự kích hoạt/nhập API Token.
- **Xác thực 2 bước (2FA)** — thêm 1 lớp bảo vệ ngoài mật khẩu, dùng app
  Authenticator (Google Authenticator, Authy...) giống đăng nhập ngân
  hàng/Gmail. Bấm bật → hiện 1 chuỗi ký tự (nhập tay vào app Authenticator,
  chọn "Nhập khoá thủ công" thay vì quét QR vì trang này chủ ý không tự vẽ
  mã QR) → nhập lại đúng 1 mã 6 số hiện ra trên app Authenticator để xác
  nhận đã cài đúng, lúc đó mới thực sự bật. Từ đó đăng nhập `/_admin/` cần
  2 bước: mật khẩu → mã 6 số. **Lỡ mất điện thoại cài app Authenticator /
  đổi máy mất mã**: mở app WP Pocket Server (máy chính, đã mở được sẵn) →
  có nút **"Tắt 2FA khẩn cấp"** (chỉ hiện khi 2FA đang bật) → không cần mật
  khẩu hay mã nào cả, đây là đường thoát duy nhất nên chỉ dùng khi thật sự
  cần.
- **Phiên đăng nhập** *(mới)* — danh sách thiết bị đang đăng nhập `/_admin/` (trình duyệt, IP, đăng nhập lúc nào,
  hoạt động lần cuối; thiết bị bạn đang dùng được đánh dấu). Có nút **Thu hồi** từng thiết bị, **Đăng xuất các
  thiết bị khác**, và **Đăng xuất** (trước đây `/_admin/` *không có* cách đăng xuất). **Đổi mật khẩu quản trị trong app
  sẽ đăng xuất mọi thiết bị** ở lần bấm kế tiếp của họ — trước đây phiên cũ vẫn sống vô thời hạn sau khi đổi mật khẩu,
  nên đổi mật khẩu vì nghi lộ không đuổi được kẻ đã đăng nhập. Thu hồi có hiệu lực ở *lần bấm kế tiếp* của thiết bị bị
  thu hồi (không ngắt kết nối đang mở tức thì). Phiên cũ tạo trước bản này bị buộc đăng nhập lại 1 lần.
  Nếu bộ nhớ đầy khiến không ghi được sổ phiên, bạn vẫn đăng nhập được (cố ý, để không tự khoá mình ngoài đúng lúc cần
  dọn dẹp), nhưng phiên đó không thu hồi từ xa được và trang sẽ cảnh báo.
- **Chế độ bảo trì** *(mới)* — bấm 1 nút để tạm ẩn website với khách (họ
  thấy trang "Website đang bảo trì" thay vì site thật), trong khi bạn vẫn
  vào `/_admin/` bình thường để làm việc. Dùng khi đang cập nhật WordPress/
  plugin/theme và chưa muốn khách thấy giao diện dở dang. Bật/tắt có hiệu
  lực gần như ngay lập tức (tối đa ~2 giây với chiều tắt, do cơ chế cache
  file của nginx — đã đo bằng thời gian thực, không phải phỏng đoán). Bấm
  lại đúng nút đó (đổi thành "Tắt chế độ bảo trì") để mở lại cho khách.
- **Thống kê theo thời gian** *(mới)* — 3 biểu đồ đơn giản: RAM đã dùng,
  dung lượng đĩa đã dùng, load trung bình — ghi mỗi ~5 phút, xem theo mốc
  24 giờ / 3 ngày / 7 ngày. Giúp biết máy có đang quá tải hay sắp đầy đĩa
  hay không mà không cần cài thêm app theo dõi nào. **Chỉ ghi được ở chế độ
  Đầy đủ** — chế độ Lite không có vòng lặp giám sát nền nên không thu thập
  được (đúng thiết kế đánh đổi lấy RAM thấp nhất của Lite, không phải lỗi);
  trang sẽ báo "chưa có dữ liệu" thay vì lỗi nếu rơi vào trường hợp này.
  Phía trên các biểu đồ có **tỷ lệ uptime 24 giờ / 7 ngày / 30 ngày** *(mới)*: mỗi ~15 phút app tự gọi HTTP vào chính máy
  (không qua tunnel) và ghi "có trả lời / không"; dịch vụ bị hệ điều hành giết trong lúc bạn muốn chạy cũng tính là
  "xuống". **Quãng không có mẫu nào (app bị tắt hẳn, máy tắt nguồn, mất điện) không được tính** — cột "Độ phủ dữ liệu" cho
  biết bao nhiêu % thời gian thật sự có mẫu; độ phủ thấp nghĩa là số uptime lạc quan hơn thực tế. Lệnh `/status` của Telegram
  cũng in 3 dòng uptime này. Đây là số **tự đo trên chính máy**, không phải SLA.
- **Sức khoẻ site** *(mới)* — trang `/_admin/health.php`, chỉ đọc: kiểm `memory_limit`, **ba tầng giới hạn upload khớp nhau**
  (nginx `client_max_body_size` ↔ `post_max_size` ↔ `upload_max_filesize` — lệch là lỗi 413/tải ảnh thất bại mà người dùng khó
  hiểu), extension PHP cần cho WordPress, dung lượng trống (báo khi < 1 GB hoặc > 90%), `WP_DEBUG` đang bật, trạng thái tunnel /
  bảo trì / cache trang, uptime 24 giờ; và với WordPress dùng MariaDB: kích thước database, **dung lượng autoload options**
  (quá 1 MB làm chậm mọi lượt tải trang), **WP-Cron** (tác vụ sắp tới, cái nào quá hạn > 10 phút) và **bài hẹn giờ đăng** — bài
  đã qua giờ đăng > 10 phút mà vẫn chưa lên được báo màu đỏ kèm lệnh khắc phục `cron event run --due-now` (WP-CLI console).
  Trang không chạm DB khi MariaDB đang ngủ (Auto-Sleep) và tự bỏ qua mục DB ở chế độ Lite.
- **Nhật ký thao tác** *(mới)* — ngoài việc đăng nhập đúng/sai, `/_admin/` ghi thêm mỗi **thao tác nhạy cảm đã qua kiểm CSRF**
  (bật/tắt bảo trì, 2FA, safe mode, staging, rollback core, cài WordPress, chạy WP-CLI…): dòng `thao tac <trang>.php
  action=<…>`, riêng WP-CLI ghi 2 từ đầu của lệnh (vd `wp-cli plugin install`). **Không** ghi giá trị các trường khác hay đối số
  lệnh (có thể chứa mật khẩu/URL). Xem trong *Xem log → đăng nhập quản trị*. **Chưa phủ**: thao tác bên trong Adminer và Tiny
  File Manager (hai ứng dụng bên thứ ba có giao thức riêng; xem `HANDOFF.md` mục 1bk).
  *(Cập nhật 1bl)* Hai công cụ đó giờ có **vết truy cập**: `truy cap db.php (Adminer)` / `truy cap files.php (File Manager)`, tối đa
  1 dòng / 10 phút / phiên — chỉ cho biết *có người mở công cụ*, **không** ghi từng truy vấn hay thao tác tệp.
- **Pin và nhiệt độ máy** *(mới)* — màn hình chính có thêm dòng `Pin: 73% (đang sạc) · 36.5°C` (đổi màu cam ≥ 40°C, đỏ ≥ 45°C).
  Cảnh báo (Telegram/…) khi pin ≥ 40°C (nhắc lại mỗi 2 giờ) và ≥ 45°C (mỗi 30 phút). Khi ≥ 45°C app **tự giảm tải mà không động
  vào php-fpm**: hoãn các việc nặng (tối ưu DB hằng tuần, tự cập nhật WordPress — cờ `defer-heavy-jobs` có sẵn) và hoãn chu kỳ
  backup định kỳ **tối đa 3 lần liên tiếp** (máy ở xứ nóng luôn ≥ 45°C thì vẫn phải backup — mất dữ liệu nguy hiểm hơn một lần
  chạy hơi nóng). Nhiệt độ đọc từ `BatteryManager` (mọi máy Android 8+), không phụ thuộc API nhiệt của hệ điều hành.
- **Kiểm tra khôi phục backup hằng tuần** *(mới — "backup chưa thử khôi phục thì chưa phải backup")* — mỗi 7 ngày (chỉ khi bật
  backup tự động, pin không yếu), app lấy **backup mới nhất**, nạp thử database của nó vào **database tạm** `wordpress_verify` trên
  chính MariaDB đang chạy (không cần máy chủ thứ hai), kiểm có bảng `…posts`/`…options` và dòng `siteurl`, rồi **xoá database tạm**.
  An toàn: nạp bằng một user MariaDB riêng chỉ có quyền trên database tạm — dù dump có `USE wordpress` hay `DROP …` thì chính
  MariaDB từ chối; ngoài ra dump được đổi tên database và bị từ chối nếu chứa lệnh nguy hiểm. Kết quả: **OK**, **FAILED**
  (backup có vấn đề → báo Telegram/webhook `backup_verify_failed`) hoặc **SKIPPED** (không kiểm được lúc này: MariaDB đang ngủ, hết
  chỗ, máy nóng, backup mã hoá chưa có mật khẩu, có trigger/view…; **không** báo động). Lệnh Telegram `/verify` chạy ngay;
  `/status` in kết quả gần nhất. Chỉ cho site WordPress dùng MariaDB; tốn ~ vài lần kích thước dump dung lượng tạm.
- **Phím tắt trên biểu tượng app** *(mới)* — nhấn giữ biểu tượng WP Pocket Server ở màn hình chính: **Bật server**, **Tắt server**,
  **Backup ngay**, **Xem log** (Android 7.1+; app yêu cầu Android 8+ nên máy nào cài được đều có). Backup từ phím tắt chạy qua
  WorkManager (sống sót khi tiến trình bị giết) và **không** bị hoãn vì RAM thấp/máy nóng như chu kỳ tự động — bạn chủ động bấm
  nên chạy ngay. Đích của phím tắt là activity **không exported** nên app khác không thể gọi để tắt server của bạn. Ngoài ra: các nhóm
  cài đặt co/giãn có hiệu ứng, mở màn hình log có chuyển cảnh mờ dần, và ở bản debug có StrictMode (chỉ ghi log).
- **Chế độ máy chủ chuyên dụng** *(mới)* — công tắc ở màn hình chính cho trường hợp dành riêng một điện thoại làm máy chủ: bật
  **tự khởi động cùng máy** (kể cả khi sau đó bỏ tích "tự khởi động"), thông báo của dịch vụ chuyển sang kênh **yên lặng**
  (không biểu tượng trên thanh trạng thái — Android vẫn bắt buộc có thông báo cho dịch vụ nền), và **ẩn các cài đặt cấu hình**
  (chế độ Lite/ngủ/cache/backup/tunnel token/tự động hoá) cho màn hình gọn; tắt công tắc để chỉnh lại. Khi bật có hộp thoại
  **hướng dẫn vận hành vật lý 24/7**: cắm sạc liên tục (bật giới hạn sạc 80% nếu máy có), nơi thoáng mát/tháo ốp lưng/quạt nhỏ,
  tắt tối ưu pin + tự khởi động theo hãng, cáp sạc chính hãng, nguồn dự phòng. Không làm "kiosk" (cần quyền device-owner).
- **Bảo vệ site** *(mới)* — trang `/_admin/protect.php`, **mọi mục mặc định TẮT**, bật/tắt tại đó:
  - **Giới hạn tốc độ toàn site:** mỗi IP tối đa 10 yêu cầu PHP/giây (cho phép đợt ngắn 30), vượt thì nhận HTTP 429. `/wp-admin/` và
    file tĩnh (ảnh, CSS, JS) **không** bị giới hạn. IP thật của khách lấy từ header `CF-Connecting-IP` của Cloudflare (Cloudflare luôn ghi
    đè header này), nên khách khác nhau có bộ đếm riêng — nếu đếm theo IP kết nối thì sau tunnel mọi khách đều là `127.0.0.1` và bị
    chặn cùng lúc. Chỉ ở chế độ Đầy đủ (nginx).
  - **Chặn bot:** trả 403 cho User-Agent của công cụ quét lỗ hổng (sqlmap, nikto, masscan, nmap, zgrab, acunetix, nessus, openvas,
    wpscan, dirbuster, gobuster, havij, netsparker) và bot SEO/cào dữ liệu ngốn băng thông (AhrefsBot, SemrushBot, MJ12bot, DotBot,
    PetalBot, BLEXBot, DataForSeoBot, Bytespider). **Không** chặn Googlebot/Bingbot, trình duyệt thường, curl hay User-Agent rỗng. Đây
    là lớp giảm tải: kẻ tấn công giả User-Agent vẫn qua được — không phải tường lửa. Chỉ ở chế độ Đầy đủ.
  - **Luật IP cho `_admin/`:** chế độ "chỉ cho phép" hoặc "chặn" một danh sách IP/CIDR IPv4 trong mạng LAN, áp dụng cho **mọi trang
    quản trị kể cả form đăng nhập, Adminer và File Manager**. Trang **từ chối lưu** nếu luật sẽ khoá chính IP bạn đang dùng. File luật
    hỏng/rỗng không khoá ai. **Cảnh báo tự khoá:** điện thoại/laptop thường nhận IP động (DHCP) — đổi mạng hay khởi động lại router có thể
    đổi IP và khoá bạn; khi đó dùng nút **"Xoá luật IP _admin"** trên màn hình chính của app (chỉ hiện khi đang có luật), nên gán IP tĩnh
    cho thiết bị quản trị trước khi dùng chế độ "chỉ cho phép".

## Điều khiển từ xa qua Telegram

Nếu đã điền **Bot Token** + **Chat ID** ở mục "Tự động hoá" trong app (tạo
bot miễn phí qua [@BotFather](https://t.me/BotFather) trên Telegram, lấy
Chat ID bằng cách nhắn thử cho bot rồi mở
`https://api.telegram.org/bot<TOKEN>/getUpdates`), ngoài việc TỰ ĐỘNG nhận
báo cáo (server bắt đầu chạy, backup xong, cảnh báo sập...), bạn còn nhắn
trực tiếp cho bot 3 lệnh để điều khiển máy từ xa, không cần mở app:

- `/status` — máy trả lời ngay tình trạng RAM/đĩa/trạng thái server hiện
  tại.
- `/backup` — yêu cầu backup ngay lập tức, xong sẽ tự gửi file zip qua chat.
- `/restart` (hoặc `/restart_service`) — khởi động lại server từ xa, hữu
  ích khi site bị treo mà bạn không cầm điện thoại chính trong tay.

## Backup: lịch tự động, "chỉ khi đang sạc", và nơi gửi đi

Mục "Tự động hoá" trong app:

- Bật **"Tự động backup định kỳ"** + chọn số giờ giữa 2 lần backup.
- **"Chỉ backup tự động khi đang sạc"** *(mới, mặc định TẮT)* — bật nếu ưu
  tiên an toàn pin/ổn định hơn là chắc chắn đúng giờ. **Lưu ý thật**: nếu
  máy hiếm khi được cắm sạc trong lúc chạy server, bật tuỳ chọn này đồng
  nghĩa backup tự động có thể sẽ *không bao giờ* chạy — cân nhắc trước khi
  bật, không phải công tắc "càng bật càng tốt".
- **"Việc nặng chỉ khi đang sạc"** *(mới, mặc định TẮT)* — tương tự trên nhưng
  cho các việc nặng *khác* backup: bảo trì database hằng tuần (`OPTIMIZE TABLE`
  ghi lại bảng) và tự động cập nhật WordPress (lõi/plugin/theme/bản dịch). Khi
  bật và máy **không cắm nguồn**, các việc này tạm hoãn (bảo trì thử lại mỗi
  giờ, cập nhật tự thử lại ở lần kiểm tra kế); website vẫn chạy bình thường.
  **Đánh đổi thật**: máy ít khi cắm sạc thì cập nhật — *kể cả bản vá bảo mật* —
  có thể bị hoãn rất lâu. Có lưới an toàn: trong lúc server chạy, app làm mới một
  cờ trạng thái mỗi ~10 phút; nếu cờ cũ hơn 2 giờ (app bị tắt/bị hệ thống dừng)
  thì các việc này tự chạy lại thay vì bị hoãn vô hạn.
- **"Mã hoá backup trước khi gửi đi"** *(mới, mặc định TẮT)* — file backup
  chứa `wp-config.php` (mật khẩu database thật, WordPress salts, có thể cả
  SMTP credentials). Gửi qua Telegram/webhook ở dạng chưa mã hoá nghĩa là
  nếu Bot Token hoặc URL webhook bị lộ (chụp màn hình nhầm, log, chia sẻ
  sai người...), toàn bộ backup + mật khẩu lộ theo. Bật tuỳ chọn này + tự
  đặt 1 mật khẩu (nên từ 12 ký tự): mọi backup (cả tự động lẫn bấm tay
  "Backup ngay") được mã hoá **AES-256-GCM** ngay trước khi gửi đi, file
  kết quả có đuôi `.zip.enc`, bản `.zip` chưa mã hoá bị xoá luôn, không lưu
  song song. **Đánh đổi thật, đọc kỹ**:
  - **Quên mật khẩu = mất backup vĩnh viễn** — không có "cửa sau", không
    ai khôi phục được, kể cả tác giả dự án. Nên ghi mật khẩu vào nơi an
    toàn khác (trình quản lý mật khẩu), không chỉ nhớ trong đầu.
  - Nếu bật switch nhưng **chưa nhập mật khẩu**, backup sẽ **không** được
    mã hoá (app sẽ nhắc bằng thông báo ngắn lúc lưu) — tránh tưởng đã mã
    hoá mà thực ra chưa.
  - Khôi phục qua nút **"Khôi phục từ backup"** trong app vẫn dùng được với
    file `.zip.enc` — app tự nhận ra và hỏi lại mật khẩu trước khi khôi
    phục. Bản `.zip` giải mã tạm chỉ tồn tại trong lúc khôi phục rồi bị xoá
    ngay, dù thành công hay thất bại.
  - **Giải mã trên máy tính** (vd điện thoại hỏng, cần lấy backup ra khỏi
    Telegram và mở bằng laptop): dùng script `scripts/tools/decrypt_backup.py`
    có sẵn trong repo:
    ```
    pip install cryptography
    python decrypt_backup.py backup-20260927-120000.zip.enc
    ```
    Script hỏi mật khẩu (gõ ẩn), ra file `.zip` thường. Đã kiểm chứng chéo:
    file do app Android mã hoá được script Python này giải mã ra khớp 100%
    với bản gốc, và sai mật khẩu/file bị sửa đều bị từ chối rõ ràng (GCM có
    xác thực, không bao giờ ra dữ liệu "rác" âm thầm).
- File backup (zip website + dump database) có thể gửi đi 2 cách, dùng
  song song được cả hai:
  - **Telegram Bot** — điền Bot Token + Chat ID như mục trên, file backup
    tự gửi kèm mỗi lần chạy xong (giới hạn ~50MB của Telegram — site lớn
    hơn nên dùng webhook).
  - **Webhook** — điền 1 URL bất kỳ nhận được HTTP POST file (nhận dạng
    `multipart`, field tên `"file"` — ví dụ dựng bằng Google Apps Script để
    tự lưu vào Google Drive của bạn) vào ô **"Webhook backup khác"** — máy
    tự POST file zip lên đó mỗi lần backup xong, không giới hạn dung lượng
    như Telegram.
  - **Webhook cảnh báo** *(mới, khác webhook ở trên)* — ô **"Webhook cảnh báo"**: 1 URL nhận **HTTP POST JSON**
    `{"app":"wp-pocket-server","event":"site_down|backup_ok|backup_failed","ts":<giây epoch>,"text":"…"}` (Zapier / Make / n8n / Discord
    qua cầu nối…). Gửi khi website không phản hồi liên tiếp, backup tự động xong, backup tự động thất bại — **không cần Telegram**.
    Nội dung chỉ là câu cảnh báo (+ tên file backup), không kèm mật khẩu/token/URL tunnel; URL webhook lưu trong SharedPreferences
    riêng tư của app và **không bao giờ ghi vào log**. Chưa có sự kiện "server vừa bật/tắt" hay "máy nóng".

### Nhập backup từ file, xuất ra ngoài, và gói di chuyển

Ba nút trong mục backup (không cần cấp quyền lưu trữ — dùng trình chọn file của hệ thống):

- **"Nhập backup từ file…"** — chọn file `.zip` hoặc `.zip.enc` bất kỳ (từ Drive,
  máy tính, điện thoại cũ…). App nhận dạng theo **nội dung** (đổi tên file cũng
  không sao): file mã hoá thì hỏi mật khẩu. Trước khi hỏi xác nhận, app kiểm tra
  *toàn bộ* file (CRC từng mục, tên đường dẫn, có thư mục `www/`, dump database
  còn nguyên); file hỏng hoặc không phải backup của app bị từ chối và **không ghi
  đè gì cả**. *(Mới)* Với site WordPress, app còn quét dump database theo luồng để chắc nó **có cấu trúc WordPress**
  (có bảng `…options` và `…posts` — mọi tiền tố — cùng dữ liệu trong `options`): một dump rỗng hoặc sai database vẫn kết thúc
  bằng dòng "Dump completed" nên trước đây có thể lọt qua; giờ bị từ chối kèm lý do. Site không phải WordPress không bị ép.
  Cũng áp dụng cho backup tự động ngay sau khi tạo (backup hỏng được báo thay vì im lặng). Chưa phải "khôi phục thử vào DB tạm".
- **"Xuất backup ra ngoài…"** — chép một bản backup đang có ra nơi bạn chọn (bản
  mã hoá được xuất nguyên vẹn, vẫn mã hoá).
- **"Gói di chuyển sang hosting khác"** (trong cùng nút xuất) — tạo gói để đem
  WordPress sang máy chủ/hosting khác **không cần app này**: thư mục `wp-content/`
  (đã lọc), `database.sql` (không có `CREATE DATABASE`/`USE` nên nạp được vào
  database tên bất kỳ), `README-MIGRATION.txt` (các bước + tiền tố bảng + URL cũ
  để chạy `wp search-replace`) và `wp-pocket-export.json`. Cố ý **không** chứa
  `wp-config.php` (mật khẩu DB), lõi WordPress, và các tệp đặc thù của nền tảng
  này. Gói **không mã hoá** — coi như dữ liệu nhạy cảm, xoá sau khi chuyển xong.
  Site đang chạy chế độ PHP-Lite (SQLite) không xuất được SQL cho MySQL; README
  trong gói ghi rõ.

> **Đây là gói chuyển thủ công theo quy trình chuẩn, KHÔNG phải file của All-in-One
> WP Migration (`.wpress`) hay Duplicator.** Đã tra cứu: `.wpress` là định dạng
> riêng của plugin (header cố định 4.377 byte cho mỗi tệp, cơ sở dữ liệu dùng tiền
> tố giữ chỗ, kèm metadata nội bộ) và không có cách nào ở đây để kiểm chứng một file
> tự sinh có được plugin chấp nhận — nên dự án không giả vờ tương thích.

## Dual-Mode PHP-Lite (máy RAM thấp vẫn chạy được)

Máy có dưới 3GB RAM chạy đủ nginx + php-fpm + MariaDB thật cùng lúc có thể
không đủ bộ nhớ, dễ bị Android tự kill vì thiếu RAM. App tự phát hiện qua
tổng RAM của máy và chuyển sang **chế độ Lite**: chỉ chạy `php -S` (máy chủ
PHP tối giản có sẵn, không cần nginx/php-fpm/MariaDB) — đổi lại nhẹ RAM hơn
nhiều nhưng **không hỗ trợ database thật** (site cần MySQL, như hầu hết
WordPress, sẽ không chạy đúng ở chế độ này) và không có phần Thống kê theo
thời gian ở trên.

3 lựa chọn trong app (mục **"Chế độ RAM thấp (PHP-Lite)"**, radio button):
- **Tự động** (mặc định) — máy tự quyết theo RAM lúc khởi động server.
- **Luôn bật** — ép luôn chạy Lite dù RAM đủ (ví dụ muốn tiết kiệm pin tối
  đa cho 1 site tĩnh không cần database).
- **Luôn tắt** — ép luôn chạy Đầy đủ dù RAM thấp (rủi ro tự set nếu máy quá
  yếu, có thể bị Android kill do thiếu RAM).

Dòng chữ nhỏ dưới nút Bật/Tắt server trong app (không phải 3 nút chọn ở
trên) cho biết chế độ THẬT SỰ đang chạy — quan trọng khi để "Tự động" vì
lựa chọn đó không tự nói cho bạn biết kết quả thực tế là Đầy đủ hay Lite.

## Auto-Sleep MariaDB khi rảnh (tuỳ chọn, mặc định TẮT)

Đề xuất "Cơ chế Ngủ đông thông minh" trong tài liệu thiết kế gốc. Bật trong
app (switch "Tự tắt MariaDB khi rảnh") nếu muốn tiết kiệm RAM/pin cho website
ít truy cập — đổi lại request đầu tiên sau một thời gian dài không ai ghé sẽ
chậm hơn vài giây (MariaDB cần khởi động lại).

Cách hoạt động: 1 script PHP cực nhẹ (chỉ `touch()` 1 file, không ghi log)
chạy trước mọi trang PHP để đánh dấu "vừa có người dùng". Vòng lặp giám sát
có sẵn của `start-lamp.sh` (vốn đã kiểm tra mỗi 3 giây xem nginx/php-fpm/
mariadb có còn sống không) kiểm tra thêm mốc thời gian này — quá ngưỡng thì
gửi tín hiệu tắt êm cho MariaDB (không phải tắt đột ngột, tránh hỏng dữ liệu).
Khi có request mới, nginx tự chuyển hướng nội bộ sang 1 trang "đang khởi động
lại..." đồng thời âm thầm bật MariaDB lại, rồi tự đưa khách quay về đúng
trang họ định xem.

Giới hạn đã biết (thành thật, không che):
- `_admin/` (Adminer, quản lý file...) CHƯA được tích hợp cơ chế đánh thức —
  nếu vào đúng lúc MariaDB đang ngủ sẽ thấy lỗi kết nối database, tự tải lại
  trang sau vài giây là được (traffic thật từ khách sẽ tự đánh thức trước).
- Dùng khoá nhẹ (advisory lock) để giảm việc nhiều khách cùng lúc đều cố
  khởi động lại MariaDB, nhưng lớp bảo vệ CHÍNH vẫn là cơ chế tự chống chạy
  trùng có sẵn của MariaDB (từ chối khởi động lần 2 trên cùng thư mục dữ
  liệu) — rủi ro tồn dư cực thấp nhưng không phải bằng 0 tuyệt đối.
- Chưa build-test trên thiết bị thật (giống mọi tính năng khác của dự án ở
  giai đoạn này) — logic đã được mô phỏng kỹ (giả lập pipeline `sed`, kiểm
  tra cú pháp PHP/shell) nhưng hành vi thời gian thực (MariaDB thật mất bao
  lâu để khởi động lại trên phần cứng ARM di động) chưa đo được.



Vì đã dùng Cloudflare Tunnel, bạn có thể tận dụng thêm các tính năng MIỄN
PHÍ trên **dashboard Cloudflare** (dash.cloudflare.com) mà không cần đụng gì
tới app hay code — tất cả các mục dưới đây là cấu hình phía Cloudflare, xử
lý ở edge server của họ trước khi request chạm tới điện thoại của bạn:

- **Cache trang tĩnh** (Caching → Configuration, hoặc Page Rules): cache
  ảnh/CSS/JS giúp giảm đáng kể số request PHP/MariaDB phải xử lý thật trên
  máy.
- **HTTP/3 (QUIC)**: bật ở Network → HTTP/3 — Cloudflare tự thương lượng
  với trình duyệt, giảm tải xử lý TCP handshake, không cần cấu hình gì
  thêm ở nginx.
- **WAF miễn phí** (Security → WAF): chặn bot/quét lỗ hổng phổ biến trước
  khi tới website — giúp bạn KHÔNG cần cài thêm plugin bảo mật nặng (kiểu
  Wordfence) trên máy vốn đã hạn chế RAM.
- **Automatic Platform Optimization (APO)** — nếu chạy WordPress, đây là
  nâng cấp đáng cân nhắc nhất: Cloudflare cache TOÀN BỘ trang HTML (không
  chỉ ảnh/CSS/JS) ngay ở edge, khiến điện thoại gần như "vô hình" với
  lượng truy cập đọc thông thường (chỉ còn phải xử lý request thật sự động
  như đăng nhập/bình luận). Miễn phí nếu đang dùng gói Pro trở lên, 5
  USD/tháng nếu đang dùng gói Free. Cách bật:
  1. 1-Click Installer (`_admin/install-wp.php`) có sẵn tùy chọn tải trước
     plugin "Cloudflare" chính thức khi cài WordPress — để nguyên checkbox
     mặc định là đủ.
  2. Vào trang quản trị WordPress → Plugins → kích hoạt "Cloudflare" → nhập
     email + API Token (tạo tại dash.cloudflare.com).
  3. Trên dashboard Cloudflare của domain → tab Speed → bật "Automatic
     Platform Optimization for WordPress".

  Lưu ý: khi dùng Cloudflare Tunnel, mọi request công khai đến `nginx` đều
  qua `127.0.0.1` (do `cloudflared` chạy local) nên mặc định WordPress/log
  sẽ thấy MỌI khách là `127.0.0.1`, không phân biệt được ai với ai — làm
  sai các plugin chống spam/giới hạn đăng nhập theo IP. Bản cập nhật này đã
  thêm cấu hình khôi phục IP thật từ header `CF-Connecting-IP` trong
  `nginx.conf.template` (tự dò xem bản `nginx` của Termux có module
  `realip` hay không trước khi bật, không giả định — nếu không có thì tự
  bỏ qua an toàn, không làm nginx từ chối khởi động). Chưa verify module
  này có mặt trong bản `nginx` thật của Termux hay không (giống mọi phần
  "chưa verify" khác của dự án — xem mục "Nói thẳng" bên dưới).

## Giám sát, cảnh báo và vận hành

Các mục dưới đây nằm trong phần **Tự động hoá** của app (cảnh báo gửi qua
Telegram nếu bạn đã cấu hình bot).

- **Heartbeat ngoài (khuyên dùng).** Telegram do chính điện thoại gửi nên *không
  thể* báo khi điện thoại đã chết (hết pin, mất mạng, bị tắt). Hãy tạo 1 "check"
  trên healthchecks.io hoặc Uptime Kuma (kiểu push), dán URL vào ô *URL heartbeat*.
  App gọi URL đó khoảng mỗi 15 phút **chỉ khi website thật sự phản hồi**; thiếu
  ping thì dịch vụ ngoài báo cho bạn. Nên đặt chu kỳ ≥ 30 phút và thời gian chờ
  thêm ≥ 15 phút (Android có thể trì hoãn tác vụ nền khi máy ngủ sâu). Khi bạn tự
  bấm *Tắt server*, hãy tạm dừng check bên đó để khỏi nhận báo động giả.
- **Ngân sách data di động.** Nhập số MB mỗi tháng (0 = tắt). App cộng dồn bộ đếm
  data di động của **cả máy** (mọi ứng dụng, kể cả chia sẻ mạng — điện thoại làm
  server thường là thiết bị chuyên dụng nên đây sát với hoá đơn nhà mạng hơn), tính
  từ lúc bạn bật tính năng — vẫn là **ước tính**, không phải số của nhà mạng. Báo khi đạt 80% và 100%; tuỳ chọn *giảm tốc độ tải về* sẽ giới hạn
  ~128 KB/s mỗi kết nối, chỉ ở chế độ Full (nginx), không áp dụng cho Lite.
- **Pin yếu.** Dưới 15% và không sạc, app tạm dừng nhận lệnh Telegram để dành pin
  cho website (không ảnh hưởng website; có thể tắt công tắc này).
- **Bộ nhớ đầy.** Từ 85%, app tự cắt các file log lớn (không đụng backup hay nhật
  ký đăng nhập) và báo bạn tối đa 1 lần/24 giờ. Nếu vẫn đầy, hãy xoá bớt backup cũ.
- **Điều kiện môi trường ngầm** *(mới)*. Cảnh báo Telegram (mỗi loại có thời gian chờ riêng để không spam) khi:
  **Tiết kiệm dữ liệu (Data Saver)** của Android đang bật mà app chưa được miễn — Android có thể chặn mạng nền khi tắt
  màn hình làm tunnel đứt; **đang dùng VPN** (cloudflared đi qua VPN có thể chậm/đứt); **đang roaming** trên mạng di
  động (mỗi lượt khách là cước data quốc tế); app bị xếp vào nhóm tiết kiệm pin **RARE/RESTRICTED** (health-check, backup
  bị trì hoãn hàng giờ); **pin ≤ 5% và không sạc**. Chỉ là cảnh báo — app không tự thay đổi cài đặt nào của máy. Giá trị
  hệ thống không đọc được sẽ *không* gây cảnh báo giả. Cần cấu hình Telegram để nhận.
- **Mật khẩu quản trị tự đặt** phải: ≥ 8 ký tự, không nằm trong danh sách mật khẩu phổ biến (kể cả dạng
  `password123`, `P@ssw0rd`, `admin2024!`), không phải dãy liên tiếp/lặp (`12345678`, `abcdabcd`), ≥ 4 ký tự khác nhau,
  và **không có dấu cách/xuống dòng ở đầu hoặc cuối** (lỗi thật: trang quản trị so sánh với bản đã cắt khoảng trắng nên
  mật khẩu như vậy không bao giờ đăng nhập được nữa). Đây là *sàn* chặn mật khẩu hiển nhiên yếu, không thay thế mật khẩu
  ngẫu nhiên (mặc định 16 ký tự) hay 2FA: `Admin2024xyz` vẫn qua được. Để trống ô nhập = app tự sinh mật khẩu ngẫu nhiên.
- **Dò mật khẩu `_admin/`.** Khi có IP bị khoá tạm hoặc từ 5 lần đăng nhập sai,
  app báo Telegram (trễ tối đa ~15 phút, tối đa 1 lần/30 phút).
- **Tắt server.** App yêu cầu script tắt sạch nginx → php-fpm → MariaDB và chờ tối
  đa 40 giây trước khi buộc dừng, để MariaDB kịp ghi dữ liệu.

### Đo sức chịu tải của chính điện thoại bạn

Hãy chạy từ **một máy khác trong cùng mạng** (không chạy trên chính điện thoại server) và đo thẳng theo IP LAN, không qua Cloudflare:

```
sh scripts/tools/loadtest.sh http://192.168.1.50:8080/ 300 "1 5 10 20 40"
```

Cần `ab` (`apt install apache2-utils` hoặc `brew install httpd`). Bảng kết quả cho req/s và độ trễ p50/p95/p99 ở từng mức đồng thời: khi req/s
không tăng nữa mà p95 tăng vọt thì đó là "gối" chịu tải (thường do số worker php-fpm hoặc CPU); khi cột *loi/non2xx* khác 0 thì máy đã tới trần. Máy nóng sẽ
tự giảm xung nên chạy ngắn, nghỉ giữa các lần đo, và đo ở nhiều thời điểm (đang sạc/không sạc). Hãy đo cả trang chủ WordPress lẫn một file tĩnh để thấy
phần chi phí do PHP/DB so với nginx.

### Email gửi đi và quy định dữ liệu (app không làm hộ bạn)

- **SPF/DKIM/DMARC:** nếu website gửi email từ địa chỉ thuộc tên miền của bạn qua
  dịch vụ SMTP (Brevo, Gmail...), bạn phải tự thêm bản ghi SPF/DKIM/DMARC ở nhà
  cung cấp tên miền theo hướng dẫn của dịch vụ SMTP đó; thiếu thì email dễ vào thư rác.
- **GDPR/cookie:** nếu có khách truy cập từ EU, bạn cần chính sách riêng tư và
  banner đồng ý cookie (thường qua plugin WordPress chuyên dụng). Dự án không đóng
  gói sẵn các plugin này.
- **Backup đã gửi đi:** file gửi qua Telegram/webhook *không tự bị xoá* khi bạn gỡ
  app. Hãy dùng *Mã hoá backup* và tự xoá khỏi nơi nhận khi không còn cần.

### HSTS, CSP và log truy vấn chậm

nginx trong app gửi sẵn `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy` (kể cả cho file tĩnh và trang lỗi), và:

- **HSTS** (ép trình duyệt luôn dùng HTTPS cho tên miền của bạn): nginx gửi `Strict-Transport-Security: max-age=2592000` (30 ngày, không `includeSubDomains`, không `preload`) **chỉ khi request đi qua HTTPS của Cloudflare**. Truy cập qua LAN bằng `http://` không nhận header này (RFC 6797 cấm máy chủ gửi HSTS qua HTTP thường). Muốn thời hạn dài hơn hoặc `preload`, đặt ở Cloudflare (*SSL/TLS → Edge Certificates → HSTS*; tên menu có thể đổi); khi đó trình duyệt thấy hai header và chỉ dùng cái đầu tiên, nên hãy kiểm tra lại bằng `curl -sI`. Không bật `preload` nếu chưa chắc, vì rất khó rút lại.
- **CSP** (`Content-Security-Policy`): nginx gửi sẵn một **tập con an toàn**: `frame-ancestors 'self'; base-uri 'self'` (chống nhúng trang vào site khác để lừa bấm, và chặn chèn thẻ `<base>`). Hai chỉ thị này không bị `default-src` chi phối và không chặn script hay style, nên không làm hỏng WordPress. **Không** bật CSP đầy đủ (`default-src`, `script-src`, `object-src`, `form-action`…): WordPress và nhiều plugin dùng script nội tuyến, nhúng PDF qua `<object>`, gửi form tới cổng thanh toán ngoài, nên một CSP chặt sẽ làm hỏng giao diện quản trị. Nếu cần CSP đầy đủ, thử ở chế độ chỉ báo cáo (`Content-Security-Policy-Report-Only`) qua quy tắc đổi header phản hồi của Cloudflare rồi siết dần.
- **Truy vấn chậm của MariaDB**: câu SQL chạy quá 2 giây được ghi vào `lamp-run/mysql-slow.log` (xem ở `_admin/` mục *Nhật ký* → `mariadb-cham`, hoặc trong app ở màn hình xem log). File tự được cắt khi vượt 5 MB. Log này có thể chứa câu SQL bạn tự gõ (ví dụ trong Adminer), nên đừng gửi nguyên văn cho người khác khi nhờ hỗ trợ.

### Cache trang công khai (tuỳ chọn, mặc định TẮT)

Công tắc **Cache trang công khai (thử nghiệm)** trên màn hình chính bật `fastcgi_cache` của nginx: trang WordPress đã tạo cho khách chưa đăng nhập được trả thẳng từ cache trong tối đa 2 phút thay vì chạy lại PHP và MariaDB, nhanh hơn rõ rệt và đỡ tốn pin. Chỉ có tác dụng ở chế độ đầy đủ (không phải PHP-Lite). Bật/tắt có hiệu lực sau tối đa vài giây, không cần khởi động lại server; nút *Xoá cache trang ngay* xóa toàn bộ cache, và mỗi lần khởi động server cache bắt đầu trống.

**Nguyên tắc an toàn: chỉ cache trang công khai của khách ẩn danh, nghi ngờ là KHÔNG cache.** Không bao giờ cache: người có cookie liên quan đến đăng nhập, phiên, giỏ hàng, bình luận, ngôn ngữ (danh sách cookie cố ý rộng, khớp cả tên lẫn giá trị); địa chỉ có `?`; mọi phương thức khác GET/HEAD; yêu cầu có header `Authorization`; `/wp-admin`, `/wp-json`, `wp-login.php`, `wp-cron.php`, `_admin/`; mọi URL trỏ thẳng tới file `.php`; phản hồi có `Set-Cookie` hoặc `Cache-Control: private/no-cache/no-store` (nginx tự không lưu). Khóa cache gồm cả http/https, host, và nhóm thiết bị (mobile/desktop) để các biến thể không bao giờ phục vụ chéo nhau.

Cache được **xoá ngay** khi đăng/sửa/xoá bài, duyệt bình luận, đổi theme/plugin/menu/danh mục (một mu-plugin nhỏ, nạp qua `try/catch` nên không thể làm hỏng website); các thay đổi khác (ví dụ sửa thẳng database bằng Adminer) hiện chậm tối đa 2 phút hoặc bấm *Xoá cache trang ngay*. Đánh đổi cần biết: plugin tuỳ biến nội dung theo cookie lạ tên không nằm trong danh sách trên có thể bị phục vụ nhầm biến thể, nếu gặp hãy tắt công tắc. Header phản hồi `X-WPP-Cache` cho biết trạng thái: `HIT`, `MISS` hoặc `BYPASS`.

### Khởi động nóng (OPcache) và IPv6

- **OPcache có cache tầng hai trên đĩa** (`opcache.file_cache`, thư mục `lamp-run/opcache-file`): sau khi server khởi động lại (Android giết app, đổi mạng, cập nhật), PHP đọc bản dịch có sẵn thay vì biên dịch lại hàng trăm file WordPress. Tự dọn khi vượt khoảng 100 MB. Sửa file nguồn (cập nhật plugin/WordPress) **không** bị phục vụ bản dịch cũ. Không dùng `opcache.preload` vì WordPress không hợp với nó (script preload phải liệt kê tệp mà lõi/plugin đổi theo mỗi lần cập nhật).
- **IPv6:** nếu điện thoại bind được IPv6, nginx nghe thêm `[::]:CỔNG`, nhưng **chỉ nhận kết nối từ loopback, link-local (`fe80::/10`) và ULA (`fc00::/7`)**, tức mạng nội bộ. Nguồn IPv6 khác (kể cả địa chỉ công cộng) bị cắt, vì IPv6 công cộng không có NAT che chắn và sẽ cho phép vào thẳng server mà bỏ qua Cloudflare. Truy cập từ Internet vẫn đi qua Cloudflare Tunnel như trước. Muốn tắt hẳn: đặt biến `DISABLE_IPV6=1`.

### Giám sát từ bên ngoài: `/healthz`

`GET /healthz` trả `200` với nội dung `pong` khi nginx và php-fpm đang nhận việc; `502` khi php-fpm chết; `503` khi đang bật chế độ bảo trì. Điểm khác với ping trang chủ: `/healthz` **không chạy WordPress và không chạm MariaDB**, nên giám sát định kỳ (UptimeRobot, Cloudflare Health Check…) không tốn pin và không đánh thức MariaDB khi Auto-Sleep đang bật. Muốn kiểm tra sâu hơn (cả database) thì ping trang chủ `/`.

### Kiểm tra bản mới và phát hành

Nút **Kiểm tra bản mới** trên màn hình chính hỏi GitHub bản phát hành (Release) mới nhất, **chỉ khi bạn bấm** (không chạy nền), và chỉ mở trang tải khi có bản mới hơn: app **không tự cài** gì. App biết repo nào để hỏi nhờ CI ghi tên repo vào `assets/update-repo.txt` lúc build (bản build ở máy riêng không có file này nên nút báo rõ thay vì đoán).
Để phát hành: đặt tag `vX.Y.Z` rồi đẩy lên (`git tag v0.2.0 && git push origin v0.2.0`). CI build APK với `versionName = X.Y.Z`, rồi tạo GitHub Release kèm APK và `SHA256SUMS.txt`. APK trong Release được ký bằng **khoá phát hành riêng của chủ dự án** (xem `docs/RELEASE_SIGNING.md`): CI từ chối phát hành nếu chưa có khoá, và từ chối APK ký bằng khoá debug công khai trong kho mã. Cài đè được lên bản ký cùng khoá và giữ nguyên dữ liệu (vẫn nên backup trước); **chuyển từ bản debug-ký sang bản khoá riêng cần gỡ và cài lại một lần** (sao lưu trước). Mặc định nút chỉ thấy bản **ổn định**. Tag có dấu gạch ngang (ví dụ `v0.3.0-beta1`) được CI tạo thành **pre-release**; ai tích ô *Nhận cả bản thử nghiệm (beta)* dưới nút mới thấy các bản này (và bản ổn định cùng số luôn được coi là mới hơn bản beta của nó). Release draft không bao giờ được thấy.

### Mục lục tài liệu

| Tài liệu | Nội dung |
|----------|----------|
| `HANDOFF.md` | Nhật ký kỹ thuật từng vòng làm việc (nguồn sự thật, ghi lại mọi thay đổi) |
| `CHANGELOG.md` | Tóm tắt thay đổi cho người dùng |
| `BREAKING_CHANGES.md` | Thay đổi buộc người dùng làm gì đó |
| `docs/FAILURE_MODES.md` | Cái gì có thể hỏng, app phản ứng ra sao |
| `docs/DISASTER_RECOVERY.md` | RPO/RTO, backup chứa gì, quy trình khôi phục, diễn tập |
| `docs/DATA_AND_SECRETS.md` | Dữ liệu nằm đâu, giữ bao lâu, bí mật, xoá dữ liệu |
| `docs/RELEASE_AND_COMPATIBILITY.md` | Đánh số phiên bản, quy trình phát hành, tương thích |
| `docs/VALUE_AND_AUDIENCE.md` | Tuyên bố giá trị, đối tượng phù hợp / không phù hợp (mỗi tuyên bố kèm bằng chứng trong repo) |
| `docs/GOVERNANCE.md` | Mô hình quản trị: ai quyết cái gì, đóng góp, phát hành |
| `docs/EXTENDING.md` | Điểm mở rộng thật: thêm runtime, công cụ admin, kênh thông báo |
| `docs/VIDEO_TUTORIAL_SCRIPT.md` | Kịch bản 3 video hướng dẫn (cảnh quay, lời thoại, phụ đề) |
| `docs/ACCESSIBILITY.md` | Rà soát trợ năng: quy tắc, đã sửa gì, chưa kiểm gì |
| `docs/IMAGE_OPTIMIZATION.md` | Tối ưu ảnh WordPress: hằng số cấu hình, lưu ý, chưa kiểm |
| `docs/BETA_PROGRAM.md` | Chương trình thử nghiệm miễn phí: rủi ro, việc nên thử, cách báo lỗi và che thông tin |
| `docs/LEGAL_NOTES_VN.md` | Ghi chú pháp lý tham khảo: dữ liệu cá nhân (VN) và mật mã/xuất khẩu — đem hỏi luật sư |
| `docs/CHAOS_TESTING.md` | Kiểm thử hỗn loạn: kịch bản, cái đã/chưa kiểm, lỗi đã tìm thấy |
| `docs/CLI.md` | Công cụ dòng lệnh wppocket (giám sát qua API LAN), mã thoát, an toàn |
| `docs/PYTHON_WSGI.md` | Chạy Flask/Django bằng máy chủ WSGI đi kèm, giới hạn và cách dùng |
| `docs/ALERT_RULES.md` | Ngưỡng cảnh báo chỉnh được và cú pháp quy tắc cảnh báo tự định nghĩa |
| `docs/RELEASE_SIGNING.md` | Ký bản phát hành bằng khoá riêng của chủ dự án: tạo khoá, 4 secret GitHub, ghim dấu vân tay, giữ khoá, cài lại một lần |
| `docs/SECURITY.md` | Bảo mật chống tấn công tự động hoá/AI: tự chặn IP, quét mã độc, Shield, đăng nhập hai bước WordPress, các lớp tuỳ chọn (pool PHP cứng, giới hạn đồng thời, cổng REST, URL đăng nhập bí mật), kiểm lỗ hổng đã biết (tuỳ chọn), Trung tâm bảo mật, cách phục hồi, **giới hạn trung thực** |
| `docs/PDF_TRACEABILITY.md` | Đối chiếu từng mục của hai PDF phân tích với code (sinh tự động, có kiểm chứng) |
| `docs/LICENSE_OPTIONS.md` | Các lựa chọn giấy phép và điều cần quyết (dự án chưa có giấy phép) |
| `docs/COMPETITIVE_ANALYSIS.md` | So sánh với giải pháp tương tự (kèm độ tin cậy) |
| `PRIVACY.md`, `THIRD_PARTY_NOTICES.md`, `TERMS.md` | Quyền riêng tư, bản quyền bên thứ ba, điều khoản (bản nháp) |
| `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md` | Cách đóng góp, quy tắc ứng xử |

### Cập nhật APK: dữ liệu nào được giữ, dữ liệu nào bị thay

Cài APK mới đè lên bản đang chạy **giữ nguyên dữ liệu của bạn**: ảnh/tệp trong `wp-content/uploads`, plugin và theme bạn tự cài, CSDL SQLite của chế độ Lite (`wp-content/database`), bản dịch, và mọi tệp bạn tự thêm vào thư mục website bằng File Manager. CSDL MariaDB nằm riêng nên cũng giữ nguyên. Các tệp **trùng đường dẫn với gói website mới** được ghi đè bằng bản mới (để code mới có hiệu lực). Phần mã của chương trình (`_admin/`, `_supervisor/`, `mariadb-share/`, `wp-admin/`, `wp-includes/`) được thay hẳn, và `wp-config.php` được sinh lại từ mẫu (đăng nhập WordPress sẽ phải làm lại một lần). Tệp đã bị gỡ khỏi gói ở phiên bản mới **không** tự bị xoá khỏi máy (đánh đổi có chủ ý để không bao giờ mất dữ liệu); xoá tay bằng File Manager nếu muốn. Trước bản 1bo, mỗi lần cài đè xoá sạch cả thư mục website — nếu bạn từng cài đè mà mất ảnh/plugin thì đó là nguyên nhân; hãy khôi phục từ backup. Chi tiết: HANDOFF.md mục 1bo.

### Dữ liệu trên máy và xoá toàn bộ

Nút **Dữ liệu trên máy và xoá toàn bộ…** (mục Backup) cho biết website, MariaDB, nhật ký, backup trong máy chiếm bao nhiêu và còn trống bao nhiêu. Từ đó có thể **xoá toàn bộ dữ liệu** của ứng dụng: bạn phải gõ lại một từ xác nhận (`XOA` / `DELETE`), thao tác không hoàn tác. Backup đã gửi lên Telegram hoặc webhook nằm ở dịch vụ đó và không bị xoá. Trong lúc backup/khôi phục/xuất/nhập chạy, app hiện thanh tiến trình và khoá các nút tác vụ để tránh chạy chồng nhau.

### Truy cập thiết bị khác trong mạng LAN từ xa (không cần mã mới)

Dự án **cố ý không có** chức năng reverse-proxy tới địa chỉ LAN: một ô "nhập địa chỉ
rồi proxy" công khai là rủi ro SSRF/open-proxy (ai biết URL có thể dùng máy bạn để
quét mạng nội bộ). Cách an toàn là để Cloudflare làm việc đó — **chỉ khi bạn dùng
Named Tunnel** (nhập *Tunnel token* trong app; Quick Tunnel `trycloudflare.com` mặc
định không hỗ trợ):

1. Trong bảng điều khiển Cloudflare Zero Trust, mở tunnel của bạn và thêm một
   *Public Hostname* mới trỏ tới dịch vụ LAN, ví dụ `http://192.168.1.50:8123`.
   (Điện thoại phải cùng mạng với thiết bị đó.)
2. Bật **Cloudflare Access** cho hostname ấy (chính sách đăng nhập), để không ai
   truy cập được nếu chưa xác thực.

Tên menu trên dashboard có thể thay đổi theo thời gian — đối chiếu tài liệu hiện
hành của Cloudflare.

**Một tunnel, nhiều dịch vụ; WebSocket; nén.** Tunnel chạy bằng token là loại *quản lý từ xa*: bạn thêm bao nhiêu *Public Hostname* cũng được trên dashboard, mỗi cái trỏ tới một dịch vụ khác nhau mà điện thoại với tới được (`http://127.0.0.1:CỔNG` cho app Node/Python chạy cùng máy, `http://192.168.x.x:CỔNG` cho thiết bị LAN). Vì vậy dự án **không cần** nginx kiểu reverse-proxy cho Node/Python hay thiết bị LAN:
- **WebSocket** (chat, thời gian thực): Cloudflare chuyển tiếp WebSocket **không cần cấu hình thêm trên mọi gói**, và app Node/Python lắng nghe trực tiếp nên không có nginx nào cần thêm header `Upgrade`.
- **Nén Brotli/Zstandard:** Cloudflare nén cho khách truy cập theo mặc định (gói Free: Zstandard; Pro/Business: Brotli) và yêu cầu origin gửi `br` hoặc `gzip`, nên gzip của nginx là đủ; không cần module Brotli ở origin.
- Quick Tunnel (không có token) chỉ chuyển được **một** địa chỉ.
- Đừng mở thiết bị LAN ra Internet mà không bật Cloudflare Access (xem trên).

### Cache đối tượng (APCu) và dữ liệu đổi từ bên ngoài

Nếu bản build có `apcu.so`, WordPress dùng cache đối tượng APCu giữa các request (nhanh hơn rõ rệt). APCu chỉ thuộc về nhóm
tiến trình php-fpm, nên khi dữ liệu bị đổi **từ ngoài** WordPress (WP-CLI, Adminer, khôi phục backup, promote staging) thì site
từng hiện dữ liệu cũ cho đến khi khởi động lại server — đã sửa: app ghi một "tem" vào `lamp-run/object-cache-epoch` mỗi khi
có thao tác như vậy và cache tự xoá ở request kế tiếp. Nếu bạn tự đổi DB bằng công cụ **ngoài** app (vd `adb shell` + `mysql`),
hãy khởi động lại server để chắc chắn thấy thay đổi.

### Xác minh toàn vẹn những gì build tải về

Build tải khoảng chục loại tệp từ internet rồi đóng vào APK chạy trên máy bạn. Mỗi tệp đi qua `scripts/lib/verify_download.sh`:

| Tệp | Đối chiếu với | Nếu **sai** hash | Nếu **không có** hash để đối chiếu |
|---|---|---|---|
| Gói `.deb` Termux | `SHA256` trong index của kho (cache cũ/cắt dở tự bị bỏ và tải lại) | dừng build | cảnh báo |
| `cloudflared` | SHA-256 trong ghi chú phát hành **đúng tag** (tag lấy qua chuyển hướng, không dùng API) + kiểm ELF | dừng build | cảnh báo |
| Adminer, Tiny File Manager | **phiên bản + SHA-256 ghim sẵn** (`scripts/lib/pins.env`) — trước đây tải `latest.php` / nhánh `master` | dừng build | cảnh báo |
| WordPress | `latest.zip.sha1` của wordpress.org | dừng build | cảnh báo |
| WP-CLI, bộ CA `cacert.pem` | `.sha256` do nhà phát hành công bố cạnh tệp | dừng build | cảnh báo |
| Plugin WordPress.org | nhà phát hành không công bố hash → chỉ **ghi nhận** hash vào báo cáo | — | — |
| `site_source.type = zip` | tuỳ chọn `site_source.sha256` trong `site.config.json` | dừng build | cảnh báo |

Kết quả từng tệp nằm trong artifact `build-inputs` (OK / UNVERIFIED / RECORDED). Đặt biến kho `VERIFY_STRICT=1` để
UNVERIFIED cũng dừng build. Nâng cấp Adminer/TFM: `bash scripts/tools/update_pins.sh` rồi chạy test (xem đầu file đó).

**Giới hạn thật (nói thẳng):** hash lấy từ *chính nhà phát hành* của tệp nên chống được tệp hỏng/cắt dở, CDN/mirror trả
sai, và việc thay riêng tệp tải; **không** chống được việc chính nhà phát hành bị chiếm quyền. Chưa kiểm **chữ ký GPG** của
kho Termux (cần ghim sẵn khoá công khai do người dùng tự xác minh vân tay — bài toán "khoá đầu tiên lấy ở đâu" không tự
giải được bằng script; và sandbox phát triển không truy cập được kho Termux để thử). Dòng `SHA-1` của WordPress yếu về mặt
mật mã, chỉ dùng để phát hiện hỏng/đổi khi tải.

**SBOM** *(mới)*: mỗi lần build CI sinh `sbom.cdx.json` (định dạng CycloneDX 1.5, artifact `sbom`; ở bản phát hành `vX.Y.Z` được
đính kèm cùng APK) liệt kê thư viện Gradle, gói Termux (kèm SHA-256), Adminer/Tiny File Manager (phiên bản + hash đã ghim) và từng
tệp tải về cùng trạng thái xác minh (OK/UNVERIFIED/RECORDED). Giấy phép chỉ được khai cho Adminer và Tiny File Manager (đã
đọc từ nguồn); các thành phần khác **không** khai giấy phép (không đoán). Tạo tay: `python3 scripts/tools/make_sbom.py --out sbom.cdx.json`.

Thông báo giấy phép bên thứ ba: [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). Dữ liệu nào lưu/gửi đi đâu:
[`PRIVACY.md`](PRIVACY.md) (bản nháp, không phải tư vấn pháp lý). **Dự án chưa có file `LICENSE`** — chủ dự án cần tự chọn.

### Ghim phiên bản gói Termux (`termux-packages.lock`) — việc cần làm trên máy bạn

Kho Termux chỉ giữ bản mới nhất nên không "ghim" được theo kiểu `apt install pkg=ver`.
CI so `major.minor` của php/php-fpm/mariadb/nginx với `termux-packages.lock` và báo lỗi
nếu lệch. Tệp khoá **chưa có sẵn** trong repo (cần dữ liệu từ lần build thật; kho Termux
chặn truy cập tự động nên không tạo trước được). Tạo lần đầu, **sau khi bạn đã test bản
APK vừa build**: tải artifact `termux-manifest` của lần chạy đó, rồi

```bash
python3 scripts/lib/termux_lock.py update termux-manifest-*.tsv termux-packages.lock
# commit termux-packages.lock vào repo
```

Muốn tạm cho phép lệch: đặt biến kho `ALLOW_TERMUX_DRIFT=1`.

## Bảo mật chống tấn công tự động hoá bằng AI (vòng 1br)

Kẻ tấn công dùng AI để khai thác lỗ hổng chỉ vài giờ sau khi công bố, quét hàng loạt từ IP đám mây và dò mật khẩu bằng hàng trăm IP. Điện thoại không có người trực, nên app có các lớp **tự động** (chi tiết, cách dùng, cách phục hồi và giới hạn: **`docs/SECURITY.md`**):

- **Tự chặn IP quét/dò** (chấm điểm log nginx, chặn 1 giờ → 24 giờ → 7 ngày, không bao giờ chặn IP trong mạng nội bộ).
- **Quét mã độc và thay đổi lạ**: PHP trong `uploads/`, so lõi WordPress với checksum chính thức, plugin/mu-plugin mới, web shell; cách ly được và khôi phục được.
- **Shield trong WordPress**: ẩn danh sách tài khoản, chống dò mật khẩu phân tán theo tài khoản, ghi nhật ký khi có admin mới/đổi quyền/bật plugin, che phiên bản plugin.
- **Đăng nhập hai bước (TOTP) cho WordPress**: tuỳ chọn từng người dùng ở trang Hồ sơ, mã khôi phục dùng một lần, có công tắc tắt khẩn cấp.
- **Các lớp tuỳ chọn, mặc định TẮT** (mỗi lớp có đánh đổi, bật ở Trung tâm bảo mật): **pool PHP cứng** (trang công khai không gọi được `exec/system/shell_exec…`), **giới hạn đồng thời** (mỗi IP tối đa 5 request PHP cùng lúc), **cổng REST** (khách chưa đăng nhập không gọi được `/wp-json/`), **URL đăng nhập bí mật** (`/wp-login.php` và `/wp-admin/` trả 404 cho đến khi mở URL bí mật một lần).
- **Chính sách mạng của app:** Android cấm HTTP thuần (chỉ cho máy này), webhook và heartbeat chỉ `https://`; bản phát hành ký bằng khoá riêng của chủ dự án.
- **Kiểm lỗ hổng đã biết của plugin/theme** (**tuỳ chọn, mặc định TẮT** vì gửi tên + phiên bản plugin ra `wpvulnerability.net` — xem `PRIVACY.md`).
- **Trung tâm bảo mật** tại `_admin/security.php`, cảnh báo Telegram, điểm sức khoẻ ở `_admin/health.php`.

**Nói thẳng:** các lớp này **không thay thế việc cập nhật WordPress/plugin ngay khi có bản vá** và không thay Cloudflare WAF. Chúng được kiểm bằng test tự động, kể cả trên **nginx, PHP-FPM và WordPress thật dựng từ mã nguồn** (đã tìm và sửa lỗi thật), nhưng **chưa chạy trên điện thoại thật và chưa kiểm với MariaDB** — xem mục 8 trong `docs/SECURITY.md` trước khi tin vào chúng.

## Những đánh đổi thật cần biết trước khi dùng lâu dài

- Điện thoại không có nguồn điện dự phòng, RAID, hay backup tự động như
  datacenter — mất điện/rớt WiFi là site sập ngay.
- Bảo mật (cập nhật WordPress/dependency, vá lỗ hổng) hoàn toàn do bạn tự quản.
- Quick Tunnel phù hợp: site cá nhân, học tập, demo, traffic thấp.
- Không phù hợp: site kinh doanh cần uptime cao — lúc đó một VPS giá rẻ vẫn
  đáng tiền hơn nhiều so với rủi ro mất dữ liệu/downtime.
