# Đóng góp cho WP Pocket Server

## Trước khi sửa
1. Đọc `HANDOFF.md`: đầu file có các quy tắc làm việc và mục lục các vòng. **Code là nguồn sự thật**; nếu HANDOFF nói khác code thì sửa HANDOFF tại chỗ kèm một dòng "ĐÍNH CHÍNH".
2. Với mỗi lần sửa, **ghi lại vào `HANDOFF.md`** một mục mới (nguyên nhân, cách sửa, cách kiểm chứng, phần chưa kiểm chứng và lý do) để người sau xem được tổng quan và lịch sử.

## Chạy kiểm tra
- Tĩnh, không cần cài gì ngoài Python 3: `python3 scripts/tools/lex-check.py scripts app`, `python3 scripts/tools/android-ref-check.py .`, `python3 scripts/tools/validate_config.py site.config.json`.
- Test: các tệp trong `scripts/tests/` (`*.py`, `run-*.sh`). Danh sách chạy ở CI nằm trong `.github/workflows/build-apk.yml`. Test cần PHP/jq/nginx/MariaDB/kotlinc chỉ chạy được ở CI hoặc máy có đủ công cụ.
- Máy không có kotlinc/PHP vẫn có JDK đầy đủ: `python3 scripts/tests/java-real-jdk-test.py` chạy các bản Java sát nguyên bản (`scripts/tests/java/*.java`) trên JDK thật. Đo độ phủ JaCoCo của test JVM Kotlin: workflow `coverage` (chạy thủ công).
- Cách viết test: logic thuần (không Android) tách ra tệp `.kt` riêng, kèm test JVM và bản "port" Python chạy được ở mọi nơi, kèm một **đối chứng âm** (cho thấy test thật sự bắt được lỗi cũ).

## Quy ước
- Không tin "có/không" từ một lần đọc sơ: đọc đủ phần liên quan, kiểm bằng code hoặc lệnh trước khi ghi vào tài liệu.
- Bình luận trong code Kotlin/PHP viết tiếng Việt không dấu; tài liệu `.md` viết tiếng Việt có dấu.
- Thay đổi hành vi người dùng thấy → cập nhật `CHANGELOG.md`; cần người dùng làm gì → `BREAKING_CHANGES.md`; chuỗi giao diện thêm vào cả `values/` và `values-en/`.

## Báo lỗi
Nêu phiên bản, loại thiết bị/Android, bước tái hiện, và đoạn log (token đã được che).

Mọi người tham gia tuân theo `CODE_OF_CONDUCT.md`.
