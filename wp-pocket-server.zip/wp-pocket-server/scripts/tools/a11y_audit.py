#!/usr/bin/env python3
"""Ra soat TRO NANG (TalkBack) cho layout XML (PDF 2 muc J8; HANDOFF.md muc 1bq-H). Chi dung stdlib. Khong thay the thu bang TalkBack that tren may.

    python3 scripts/tools/a11y_audit.py [thu_muc_res]      # mac dinh app/src/main/res; thoat 1 neu co vi pham

Quy tac (moi quy tac co ma de tra cuu):
  A1  ImageView/ImageButton: phai co contentDescription khong rong HOAC importantForAccessibility="no"
  A2  Vung cham >= 48dp: khong duoc dat minHeight/minWidth < 48dp cho Button/ImageButton/CheckBox/Switch/RadioButton/view clickable
      (tru khi layout_height/width >= 48dp)
  A3  EditText: phai co hint, contentDescription hoac duoc TextView khac tro bang labelFor
  A4  CheckBox/Switch/RadioButton/ToggleButton: phai co text hoac contentDescription
  A5  textSize dung sp (khong dp/px/pt) de theo co chu nguoi dung
  A6  TextView trang thai CHINH cua server (id nam trong LIVE_STATUS_IDS) phai co accessibilityLiveRegion=polite de TalkBack doc khi doi (Dang chay/Da dung).
      CO Y khong ap dung cho tvDeviceStatus (doi nhiet do/pin lien tuc - polite se doc lien tuc, gay on) va layout widget_* (RemoteViews)
  A7  Khong dat importantForAccessibility="no" cho view co the bam (an khoi TalkBack)
  A8  contentDescription/hint ngoai tai nguyen: phai la @string/ (de dich), khong chuoi cung
Chay lai voi --self-test de kiem chinh bo ra soat bang layout co loi co chu y.
"""
import os, re, sys
import xml.etree.ElementTree as ET

ANDROID = "{http://schemas.android.com/apk/res/android}"
LIVE_STATUS_IDS = {"tvStatus"}
CLICKABLE = {"Button", "ImageButton", "CheckBox", "Switch", "RadioButton", "ToggleButton", "com.google.android.material.button.MaterialButton", "androidx.appcompat.widget.SwitchCompat", "com.google.android.material.switchmaterial.SwitchMaterial"}
IMAGES = {"ImageView", "ImageButton", "androidx.appcompat.widget.AppCompatImageView", "com.google.android.material.imageview.ShapeableImageView"}
CHECKS = {"CheckBox", "Switch", "RadioButton", "ToggleButton", "androidx.appcompat.widget.SwitchCompat", "com.google.android.material.switchmaterial.SwitchMaterial"}


def dp(v):
    m = re.fullmatch(r"(-?[0-9.]+)dp", (v or "").strip())
    return float(m.group(1)) if m else None


def audit_tree(root, fname):
    out = []
    labelled = set()
    for el in root.iter():
        lf = el.get(ANDROID + "labelFor")
        if lf:
            labelled.add(lf.replace("@+id/", "").replace("@id/", ""))
    for el in root.iter():
        tag = el.tag if isinstance(el.tag, str) else ""
        g = lambda a: el.get(ANDROID + a)
        vid = (g("id") or "").replace("@+id/", "").replace("@id/", "")
        where = "%s <%s%s>" % (fname, tag.split(".")[-1], (" id=" + vid) if vid else "")
        cd, hint, text = g("contentDescription"), g("hint"), g("text")
        imp = g("importantForAccessibility")
        if tag in IMAGES and not (cd and cd.strip()) and imp != "no":
            out.append(("A1", where, "anh khong co contentDescription (them mo ta hoac importantForAccessibility=\"no\" neu chi trang tri)"))
        if tag in CLICKABLE or g("clickable") == "true":
            for attr, lay in (("minHeight", "layout_height"), ("minWidth", "layout_width")):
                mv = dp(g(attr))
                if mv is not None and mv < 48 and not (dp(g(lay)) or 0) >= 48:
                    out.append(("A2", where, "%s=%gdp < 48dp: vung cham qua nho (de >= 48dp hoac layout_%s >= 48dp)" % (attr, mv, "height" if attr == "minHeight" else "width")))
            if imp == "no":
                out.append(("A7", where, "view bam duoc nhung importantForAccessibility=\"no\" (TalkBack khong thay)"))
        if tag == "EditText" or tag.endswith(".TextInputEditText"):
            if not ((hint and hint.strip()) or (cd and cd.strip()) or vid in labelled):
                out.append(("A3", where, "o nhap khong co hint/contentDescription/labelFor"))
        if tag in CHECKS and not ((text and text.strip()) or (cd and cd.strip())):
            out.append(("A4", where, "cong tac/o chon khong co text hoac contentDescription"))
        ts = g("textSize")
        if ts and not re.fullmatch(r"[0-9.]+sp|@dimen/.+", ts.strip()):
            out.append(("A5", where, "textSize=%s: dung sp de theo co chu nguoi dung" % ts))
        if tag == "TextView" and vid in LIVE_STATUS_IDS and g("accessibilityLiveRegion") not in ("polite", "assertive"):
            out.append(("A6", where, "TextView trang thai nen co accessibilityLiveRegion=\"polite\""))
        for a, v in (("contentDescription", cd), ("hint", hint)):
            if v and v.strip() and not v.startswith("@") and not re.fullmatch(r"[0-9.:,/ -]+", v.strip()):  # goi y chi gom so (vd "24") khong can dich
                out.append(("A8", where, "%s la chuoi cung %r (dung @string/ de dich duoc)" % (a, v)))
    return out


def audit_dir(res):
    found = []
    for d in sorted(os.listdir(res)):
        if not d.startswith("layout"):
            continue
        for f in sorted(os.listdir(os.path.join(res, d))):
            if f.endswith(".xml"):
                try:
                    root = ET.parse(os.path.join(res, d, f)).getroot()
                except ET.ParseError as e:
                    found.append(("XML", d + "/" + f, str(e)))
                    continue
                found += audit_tree(root, d + "/" + f)
    return found


SELF_BAD = """<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android">
  <ImageView android:id="@+id/pic" android:src="@drawable/x"/>
  <Button android:id="@+id/tiny" android:minHeight="0dp" android:layout_height="wrap_content" android:text="x"/>
  <ImageButton android:id="@+id/ib" android:minWidth="24dp" android:contentDescription="Dong" android:layout_width="wrap_content"/>
  <EditText android:id="@+id/et"/>
  <Switch android:id="@+id/sw"/>
  <TextView android:id="@+id/tvStatus" android:textSize="14dp"/>
  <Button android:id="@+id/hidden" android:importantForAccessibility="no" android:text="x"/>
</LinearLayout>"""


def self_test():
    root = ET.fromstring(SELF_BAD)
    codes = sorted({c for c, _, _ in audit_tree(root, "bad.xml")})
    want = ["A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8"]
    ok = codes == want
    print("self-test: bo ra soat bat dung 8/8 ma loi tren layout co loi co chu y: %s %s" % (codes, "OK" if ok else "SAI (can %s)" % want))
    good = ET.fromstring("""<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android">
  <ImageView android:contentDescription="@string/a" android:src="@drawable/x"/>
  <ImageView android:importantForAccessibility="no" android:src="@drawable/x"/>
  <Button android:minHeight="48dp" android:text="@string/a"/>
  <Button android:minHeight="0dp" android:layout_height="56dp" android:text="@string/a"/>
  <TextView android:id="@+id/etLabel" android:labelFor="@+id/et" android:text="@string/a"/>
  <EditText android:id="@+id/et"/>
  <TextView android:id="@+id/tvStatus" android:accessibilityLiveRegion="polite" android:textSize="14sp"/>
</LinearLayout>""")
    clean = audit_tree(good, "good.xml")
    print("self-test: layout dung KHONG bi bao nham: %s" % ("OK" if not clean else clean))
    return 0 if ok and not clean else 1


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        sys.exit(self_test())
    res = next((a for a in sys.argv[1:] if not a.startswith("--")), os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "app", "src", "main", "res"))
    found = audit_dir(res)
    for code, where, msg in found:
        print("%s %s: %s" % (code, where, msg))
    print("a11y_audit: %s" % ("SACH" if not found else "%d vi pham" % len(found)))
    sys.exit(1 if found else 0)
