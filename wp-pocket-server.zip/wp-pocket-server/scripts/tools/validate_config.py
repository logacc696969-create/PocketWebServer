#!/usr/bin/env python3
"""Kiem tra site.config.json TRUOC khi build (PDF 2 muc AF1 + AF2; HANDOFF.md muc 1bo).

  python3 scripts/tools/validate_config.py [site.config.json]

Truoc day CI chi doc file bang `jq` o tung buoc -> go sai ten khoa (vd "instal_deps": false) bi IM LANG BO QUA,
JSON sai cu phap (dau phay thua, chu thich) chi lo ra o buoc sau voi loi cua jq kho hieu. Nay kiem tra NGAY o dau job:
  * cu phap JSON: bao DONG + COT + dong sai, goi y loi hay gap (dau phay thua, nhay don, chu thich //);
  * config_version (AF1): vang = 1 (tuong thich nguoc); so nguyen > ban cong cu nay hieu = DUNG, bao can cong cu moi hon;
  * khoa la (go sai chinh ta) -> loi KEM GOI Y gan nhat ("ban muon go 'install_deps'?"); khoa bat dau bang '_' la ghi chu, bo qua;
  * gia tri: dung CHINH `validate()` cua apply_preset.py (mot nguon su that cho cac rang buoc cua script build) + site_source.sha256.
Thoat ma 0 = hop le, 1 = co loi (in het MOI loi mot luot, khong dung o loi dau). Trong GitHub Actions in them dong ::error.
"""
import difflib, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import apply_preset as ap  # noqa: E402  (validate() la nguon su that cua cac rang buoc gia tri)

CONFIG_VERSION = 1   # phien ban dinh dang ma cong cu build nay hieu
TOP_KEYS = ("config_version", "runtime", "port", "entry", "wsgi", "asgi", "install_deps", "docroot", "profile", "db_name", "front_proxy", "site_source")
SS_KEYS = ("type", "repo", "branch", "path", "url", "sha256")


def _suggest(key, allowed):
    m = difflib.get_close_matches(key, allowed, n=1, cutoff=0.6)
    return " - ban muon go %r?" % m[0] if m else " (cac khoa hop le: %s)" % ", ".join(allowed)


def _json_error(text, e):
    lines = text.split("\n")
    ctx = lines[e.lineno - 1].rstrip() if 0 < e.lineno <= len(lines) else ""
    bad = ctx[e.colno - 1] if 0 < e.colno <= len(ctx) else ""
    hint = ""
    if re.search(r"//|/\*", ctx):
        hint = " Goi y: JSON khong cho phep chu thich (// hoac /* */); dung khoa bat dau bang '_' (vd \"_ghichu\") de ghi chu."
    elif bad in ("}", "]") or "Illegal trailing comma" in e.msg:
        hint = " Goi y: thua dau phay o cuoi doi tuong/mang, ngay truoc dau } hoac ]."
    elif bad == "'" or ctx.lstrip().startswith("'"):
        hint = " Goi y: JSON chi dung dau nhay KEP \"...\", khong dung nhay don."
    elif "Expecting ',' delimiter" in e.msg:
        hint = " Goi y: thieu dau phay giua hai muc (kiem tra dong ngay TREN dong nay)."
    return "site.config.json sai cu phap JSON o dong %d, cot %d: %s.%s\n      dong %d: %s" % (e.lineno, e.colno, e.msg, hint, e.lineno, ctx.strip())


def check_text(text):
    """Tra ve danh sach loi (rong = hop le)."""
    try:
        cfg = json.loads(text)
    except json.JSONDecodeError as e:
        return [_json_error(text, e)]
    if not isinstance(cfg, dict):
        return ["site.config.json phai la MOT DOI TUONG JSON {...} (dang la %s)" % type(cfg).__name__]
    errs = []
    # --- AF1: phien ban dinh dang ---
    if "config_version" in cfg:
        v = cfg["config_version"]
        if isinstance(v, bool) or not isinstance(v, int) or v < 1:
            errs.append("config_version phai la so nguyen duong (dang la %r)" % (v,))
        elif v > CONFIG_VERSION:
            errs.append("config_version=%d moi hon ban cong cu build nay hieu (toi da %d): cap nhat scripts/ cua du an truoc khi dung file cau hinh nay" % (v, CONFIG_VERSION))
    # --- AF2: khoa la / go sai ---
    for k in cfg:
        if k.startswith("_") or k in TOP_KEYS:
            continue
        errs.append("khoa %r khong hop le o cap goc" % k + _suggest(k, TOP_KEYS))
    ss = cfg.get("site_source")
    if "site_source" in cfg and not isinstance(ss, dict):
        errs.append("site_source phai la doi tuong {...} (dang la %s)" % type(ss).__name__)
        ss = {}
    for k in (ss or {}):
        if k.startswith("_") or k in SS_KEYS:
            continue
        errs.append("khoa %r khong hop le trong site_source" % k + _suggest(k, SS_KEYS))
    # --- gia tri: mot nguon su that voi apply_preset.validate ---
    safe = dict(cfg)
    if not isinstance(safe.get("site_source", {}), dict):
        safe["site_source"] = {}
    try:
        errs.extend(ap.validate(safe))
    except Exception as ex:  # khong de ngoai le Python che mat cac loi da tim duoc
        errs.append("khong kiem tra duoc gia tri (%s: %s)" % (type(ex).__name__, ex))
    sha = (ss or {}).get("sha256")
    if sha not in (None, ""):
        if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", sha):
            errs.append("site_source.sha256 phai la chuoi 64 ky tu hex (dang la %r)" % (sha,))
        elif (ss or {}).get("type") != "zip":
            errs.append("site_source.sha256 chi dung khi site_source.type = \"zip\" (dang la %r)" % ((ss or {}).get("type"),))
    return errs


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    path = argv[0] if argv else "site.config.json"
    try:
        with open(path, encoding="utf-8") as f:
            text = f.read()
    except OSError as e:
        print("LOI: khong doc duoc %s: %s" % (path, e), file=sys.stderr)
        return 1
    errs = check_text(text)
    if not errs:
        print("site.config.json: hop le (config_version %s)" % (json.loads(text).get("config_version", "chua khai bao -> %d" % CONFIG_VERSION)))
        return 0
    print("LOI: %s khong hop le (%d van de):" % (path, len(errs)), file=sys.stderr)
    for m in errs:
        print("  - " + m, file=sys.stderr)
        if os.environ.get("GITHUB_ACTIONS") == "true":
            print("::error file=%s,title=site.config.json::%s" % (path, m.split("\n")[0].replace("%", "%25")))
    return 1


if __name__ == "__main__":
    sys.exit(main())
