#!/usr/bin/env python3
"""Ap dung 1 preset vao site.config.json (HANDOFF.md muc 1az, J4).

  python3 scripts/tools/apply_preset.py --list
  python3 scripts/tools/apply_preset.py wordpress
  python3 scripts/tools/apply_preset.py node-git --repo https://github.com/ban/app.git --branch main --port 3000
  python3 scripts/tools/apply_preset.py static-local --out /tmp/test.json

Moi lan chay deu KIEM TRA HOP LE truoc khi ghi - cung cac rang buoc ma script build gia dinh:
  * runtime thuoc {php,node,python,static}; type thuoc {wordpress,git,local,zip};
  * port la so nguyen 1024..65534 (Android khong bind duoc cong <1024; staging dung cong PORT+1);
  * wsgi / asgi (chi runtime python) dang module:callable [()] - may chu di kem (scripts/runtimes/wpp_wsgi.py; asgi qua cau noi ASGI->WSGI), loai tru nhau va voi entry;
  * entry chi gom [A-Za-z0-9._/-], khong '..', khong bat dau bang '/' (gia tri duoc chen THANG
    vao chuoi JSON "exec" cua runtime.json nen dau nhay/gach nguoc se lam hong file);
  * type=wordpress chi di voi runtime=php (ca 4 runtime deu goi fetch_site_source);
  * type=git can repo https://|http://|git@ (khong bat dau bang '-': chan chen tuy chon vao git clone);
  * type=zip can url http(s); type=local can path tuong doi trong repo;
  * install_deps (neu co) phai la boolean;
  * docroot: thu muc con an toan, chi cho runtime php/static; profile: auto|wordpress|generic; db_name: ten DB hop le (HANDOFF.md muc 1bb).
Khong ghi gi neu sai (thoat ma 1).
"""
import argparse, json, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
PRESET_DIR = os.path.join(ROOT, "presets")
RUNTIMES = ("php", "node", "python", "static")
TYPES = ("wordpress", "git", "local", "zip")
SAFE = r"[A-Za-z0-9._/-]+"
BAD_REPO_CHARS = re.compile(r"""[\s;&|$`'"\\<>(){}\[\]*?!#]""")
# URL zip duoc script dat trong dau nhay khi goi curl -> cho phep ?, &, =, # (link tai thuong co tham so)
BAD_URL_CHARS = re.compile(r"""[\s'"\\`$<>]""")

def validate(cfg):
    e = []
    rt = cfg.get("runtime")
    if rt not in RUNTIMES: e.append("runtime phai la mot trong %s (dang la %r)" % (list(RUNTIMES), rt))
    port = cfg.get("port", 8080)
    if isinstance(port, bool) or not isinstance(port, int) or not (1024 <= port <= 65534):
        e.append("port phai la so nguyen 1024..65534 (dang la %r; Android khong bind duoc <1024, staging dung PORT+1)" % (port,))
    entry = cfg.get("entry", "")
    if entry is None: entry = ""
    if not isinstance(entry, str): e.append("entry phai la chuoi")
    elif entry:
        if not re.fullmatch(SAFE, entry) or ".." in entry.split("/") or entry.startswith("/") or len(entry) > 100:
            e.append("entry %r khong hop le (chi [A-Za-z0-9._/-], khong '..', khong bat dau bang '/', toi da 100 ky tu)" % entry)
    declared = []
    for key in ("wsgi", "asgi"):
        val = cfg.get(key, "")
        if val is None: val = ""
        if not isinstance(val, str): e.append("%s phai la chuoi 'module:callable'" % key)
        elif val:
            declared.append(key)
            ident = r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*"
            if len(val) > 100 or not re.fullmatch(ident + ":" + ident + r"(?:\(\))?", val):
                e.append("%s %r khong hop le (dang module:callable, vi du app:app, mysite.wsgi:application, app:create_app())" % (key, val))
            if rt != "python": e.append("%s chi ap dung cho runtime python (dang la %r)" % (key, rt))
    if isinstance(entry, str) and entry: declared.append("entry")
    if len(declared) > 1: e.append("chi dung MOT trong entry, wsgi hoac asgi (dang khai bao: %s)" % ", ".join(declared))
    dr = cfg.get("docroot", "")
    if dr is None: dr = ""
    if not isinstance(dr, str): e.append("docroot phai la chuoi")
    elif dr and (not re.fullmatch(r"[A-Za-z0-9._][A-Za-z0-9._-]*(/[A-Za-z0-9._][A-Za-z0-9._-]*)*", dr) or ".." in dr.split("/") or "." in dr.split("/")):
        e.append("docroot %r khong hop le (chi [A-Za-z0-9._-] va '/', khong '..', khong bat dau/ket thuc bang '/')" % dr)
    prof = cfg.get("profile", "auto")
    if prof not in ("auto", "wordpress", "generic"): e.append("profile phai la auto | wordpress | generic (dang la %r)" % (prof,))
    dbn = cfg.get("db_name", "") or ""
    if not isinstance(dbn, str) or (dbn and not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,31}", dbn)):
        e.append("db_name %r khong hop le (chu cai dau, chi [A-Za-z0-9_], toi da 32 ky tu)" % (dbn,))
    elif dbn.lower() in ("mysql", "information_schema", "performance_schema", "sys", "test"): e.append("db_name %r trung ten database he thong" % dbn)
    fp = cfg.get("front_proxy")
    if fp is not None and not isinstance(fp, bool): e.append("front_proxy phai la true/false (dang la %r)" % (fp,))
    elif fp is not None and rt not in ("node", "python", "static"):
        e.append("front_proxy chi ap dung cho runtime node, python hoac static (dang la %r) - runtime php da co nginx rieng" % rt)
    idp = cfg.get("install_deps", True)
    if not isinstance(idp, bool): e.append("install_deps phai la true/false (dang la %r)" % (idp,))
    ss = cfg.get("site_source") or {}
    t = ss.get("type")
    if t not in TYPES: e.append("site_source.type phai la mot trong %s (dang la %r)" % (list(TYPES), t))
    # profile hieu luc = wordpress khi dat ro, hoac auto + type=wordpress (auto + nguon khac chi biet luc build: bash se tu choi tiep)
    if (prof == "wordpress" or (prof == "auto" and t == "wordpress")) and dbn not in ("", "wordpress"):
        e.append("site WordPress yeu cau db_name de trong hoac 'wordpress' (dang la %r) - dung profile generic cho ung dung khac" % dbn)
    if t == "wordpress" and prof == "generic":
        e.append("site_source.type=wordpress mau thuan voi profile=generic")
    if dr and rt not in ("php", "static"):
        e.append("docroot chi ap dung cho runtime php hoac static (dang la %r)" % rt)
    if t == "wordpress" and rt != "php":
        e.append("site_source.type=wordpress chi di voi runtime=php (dang la %r)" % rt)
    if t == "git":
        repo = ss.get("repo", "")
        if not isinstance(repo, str) or not repo:
            e.append("site_source.type=git can site_source.repo")
        elif not re.match(r"^(https://|http://|git@)", repo) or BAD_REPO_CHARS.search(repo.replace("@", "").replace(":", "")):
            e.append("site_source.repo %r khong hop le (can https://, http:// hoac git@..., khong co khoang trang/ky tu dac biet)" % repo)
        br = ss.get("branch", "main")
        if not isinstance(br, str) or not re.fullmatch(SAFE, br) or br.startswith("-"):
            e.append("site_source.branch %r khong hop le" % (br,))
    if t == "local":
        p = ss.get("path", "site")
        if not isinstance(p, str) or not re.fullmatch(SAFE, p) or ".." in p.split("/") or p.startswith("/"):
            e.append("site_source.path %r khong hop le (duong dan tuong doi trong repo, khong '..')" % (p,))
    if t == "zip":
        u = ss.get("url", "")
        if not isinstance(u, str) or not re.match(r"^https?://", u) or BAD_URL_CHARS.search(u):
            e.append("site_source.url %r khong hop le (can http(s)://, khong khoang trang/ky tu dac biet)" % (u,))
    return e

def load_presets():
    out = {}
    for fn in sorted(os.listdir(PRESET_DIR)):
        if fn.endswith(".json"):
            out[fn[:-5]] = json.load(open(os.path.join(PRESET_DIR, fn), encoding="utf-8"))
    return out

def apply(preset, overrides):
    cfg = {k: v for k, v in preset.items() if k not in ("_preset", "_requires")}
    cfg["site_source"] = dict(cfg.get("site_source", {}))
    for k in ("docroot", "profile", "db_name"):
        if overrides.get(k) is not None: cfg[k] = overrides[k]
    for k in ("port", "entry"):
        if overrides.get(k) is not None: cfg[k] = overrides[k]
    for k in ("repo", "branch", "path", "url"):
        if overrides.get(k) is not None: cfg["site_source"][k] = overrides[k]
    if overrides.get("type") is not None: cfg["site_source"]["type"] = overrides["type"]
    if overrides.get("runtime") is not None: cfg["runtime"] = overrides["runtime"]
    if overrides.get("no_install_deps"): cfg["install_deps"] = False
    if overrides.get("front_proxy") is not None: cfg["front_proxy"] = (overrides["front_proxy"] == "true")
    missing = [r for r in preset.get("_requires", []) if not cfg["site_source"].get(r)]
    return cfg, missing

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("preset", nargs="?")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--out", default=os.path.join(ROOT, "site.config.json"))
    ap.add_argument("--port", type=int); ap.add_argument("--entry")
    ap.add_argument("--repo"); ap.add_argument("--branch"); ap.add_argument("--path"); ap.add_argument("--url")
    ap.add_argument("--type"); ap.add_argument("--runtime")
    ap.add_argument("--docroot"); ap.add_argument("--profile"); ap.add_argument("--db-name", dest="db_name")
    ap.add_argument("--front-proxy", dest="front_proxy", choices=("true", "false"), help="node/python: them nginx phia truoc (header bao mat, gzip, WebSocket); static: false = php -S thay vi nginx (HANDOFF.md muc 1bi)")
    ap.add_argument("--no-install-deps", action="store_true", help="dat install_deps=false (tu commit node_modules/.pylibs/vendor)")
    a = ap.parse_args(argv)
    presets = load_presets()
    if a.list or not a.preset:
        for n, p in presets.items():
            req = (" [can: --%s]" % ", --".join(p["_requires"])) if p.get("_requires") else ""
            print("%-14s %s%s" % (n, p.get("_preset", ""), req))
        return 0
    if a.preset not in presets:
        print("LOI: khong co preset %r. Dung --list de xem." % a.preset, file=sys.stderr); return 1
    cfg, missing = apply(presets[a.preset], vars(a))
    if missing:
        print("LOI: preset %r can: %s" % (a.preset, ", ".join("--" + m for m in missing)), file=sys.stderr); return 1
    errs = validate(cfg)
    if errs:
        print("LOI: cau hinh khong hop le, KHONG ghi gi:", file=sys.stderr)
        for m in errs: print("  - " + m, file=sys.stderr)
        return 1
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2); f.write("\n")
    print("Da ghi %s: runtime=%s, type=%s, port=%s" % (a.out, cfg["runtime"], cfg["site_source"]["type"], cfg.get("port", 8080)))
    return 0

if __name__ == "__main__":
    sys.exit(main())
