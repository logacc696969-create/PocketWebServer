#!/usr/bin/env python3
"""Kiem tra THAM CHIEU cua app Android khi khong co kotlinc/Gradle (vd sandbox khong mang). KHONG thay build that - chi bat som
nhom loi hay gap khi sua tay: R.id/R.string/R.layout/R.drawable khong ton tai; ten viewBinding (binding.xxx) khong co trong layout;
so tham so getString(R.string.x, ...) khac so cho %s/%d cua chuoi (VI va EN); chuoi VI/EN lech so cho; Prefs.KEY_* chua khai bao;
Object.ham() khong ton tai trong object (BackupLogic, MonitorLogic...); lop khai bao trong Manifest khong co trong ma.
Dung: python3 scripts/tools/android-ref-check.py [thu_muc_goc_du_an]   (exit 1 neu co loi)
"""
import glob, os, re, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
M = os.path.join(ROOT, 'app/src/main')
problems = []


def rd(p):
    return open(p, encoding='utf8').read()


def strip_comments(s):
    """Bo chu thich Kotlin (// va /* */ LONG NHAU), GIU NGUYEN noi dung chuoi ("...", \"\"\"...\"\"\", '.'); xuong dong duoc giu."""
    out, i, n = [], 0, len(s)
    while i < n:
        if s.startswith('//', i):
            j = s.find('\n', i); i = n if j < 0 else j
        elif s.startswith('/*', i):
            d, i = 1, i + 2
            while i < n and d:
                if s.startswith('/*', i): d += 1; i += 2
                elif s.startswith('*/', i): d -= 1; i += 2
                else:
                    if s[i] == '\n': out.append('\n')
                    i += 1
        elif s.startswith('"""', i):
            j = s.find('"""', i + 3); j = n if j < 0 else j + 3
            out.append(s[i:j]); i = j
        elif s[i] == '"':
            j = i + 1
            while j < n and s[j] != '"' and s[j] != '\n':
                j += 2 if s[j] == '\\' else 1
            out.append(s[i:j + 1]); i = j + 1
        elif s[i] == "'":
            j = i + 1
            while j < n and s[j] != "'" and s[j] != '\n':
                j += 2 if s[j] == '\\' else 1
            out.append(s[i:j + 1]); i = j + 1
        else:
            out.append(s[i]); i += 1
    return ''.join(out)


kt_files = sorted(glob.glob(M + '/java/**/*.kt', recursive=True))
kt = {os.path.basename(f)[:-3]: rd(f) for f in kt_files}
kt_all = '\n'.join(strip_comments(s) for s in kt.values())

# ---- tai nguyen
layout_files = glob.glob(M + '/res/layout*/*.xml')
ids = set()
for f in layout_files + glob.glob(M + '/res/menu/*.xml'):
    ids |= set(re.findall(r'@\+id/(\w+)', rd(f)))
strings = {'vi': {}, 'en': {}}
for f in glob.glob(M + '/res/values*/strings.xml'):
    lang = 'en' if 'values-en' in f else 'vi'
    for n, v in re.findall(r'<string\s+name="([^"]+)"[^>]*>(.*?)</string>', rd(f), re.S):
        strings[lang][n] = v
all_str = set(strings['vi']) | set(strings['en'])
dimens = set()
for f in glob.glob(M + '/res/values*/*.xml'):
    dimens |= set(re.findall(r'<dimen\s+name="([^"]+)"', rd(f)))
layouts = {os.path.basename(f)[:-4] for f in layout_files}
drawables = {os.path.basename(f).rsplit('.', 1)[0] for f in glob.glob(M + '/res/drawable*/*')}

def framework(pattern, text):
    """Tham chieu R.x.y KHONG di sau 'android.' (android.R.string.ok la cua he thong)."""
    return set(re.findall(r'(?<![\w.])R\.' + pattern + r'\.(\w+)', text))

for kind, have in (('id', ids), ('string', all_str), ('layout', layouts), ('drawable', drawables)):
    for n in sorted(framework(kind, kt_all) - have):
        problems.append('R.%s.%s khong ton tai trong res/' % (kind, n))
layout_txt = '\n'.join(rd(f) for f in layout_files + glob.glob(M + '/res/xml/*.xml'))
for n in sorted(set(re.findall(r'@string/(\w+)', layout_txt + rd(M + '/AndroidManifest.xml'))) - all_str):
    problems.append('@string/%s (layout/manifest) khong ton tai' % n)
for n in sorted(set(re.findall(r'@drawable/(\w+)', layout_txt + rd(M + '/AndroidManifest.xml'))) - drawables):
    problems.append('@drawable/%s (layout/manifest) khong ton tai' % n)
for n in sorted(set(re.findall(r'@dimen/(\w+)', layout_txt)) - dimens):
    problems.append('@dimen/%s (layout) khong ton tai' % n)
for n in sorted(framework('dimen', kt_all) - dimens):
    problems.append('R.dimen.%s khong ton tai trong res/' % n)
for n in sorted(set(strings['vi']) ^ set(strings['en'])):
    problems.append('chuoi %s chi co o 1 trong 2 ngon ngu (VI/EN)' % n)

# ---- viewBinding
def camel(s):
    p = s.split('_')
    return p[0] + ''.join(x[:1].upper() + x[1:] for x in p[1:])
lay_ids = {os.path.basename(f)[:-4]: {camel(i) for i in re.findall(r'@\+id/(\w+)', rd(f))}
           for f in glob.glob(M + '/res/layout/*.xml')}
cls2lay = {''.join(x.capitalize() for x in n.split('_')) + 'Binding': n for n in lay_ids}
for name, src in kt.items():
    code = strip_comments(src)
    for b in set(re.findall(r'databinding\.(\w+Binding)', code)):
        if b not in cls2lay:
            problems.append('%s: %s khong co layout tuong ung' % (name, b)); continue
        for m in set(re.findall(r'\bbinding\.(\w+)', code)):
            if m != 'root' and m not in lay_ids[cls2lay[b]]:
                problems.append('%s: binding.%s khong co trong %s.xml' % (name, m, cls2lay[b]))

# ---- getString(R.string.x, args)
def placeholders(v):
    pos = re.findall(r'%(\d+)\$', v)
    return max(map(int, pos)) if pos else len(re.findall(r'%[sdfx]', v))
for name, src in kt.items():
    code = strip_comments(src)
    for m in re.finditer(r'(?:getString|getText)\(\s*R\.string\.(\w+)\s*((?:,[^()]*(?:\([^()]*\)[^()]*)*)?)\)', code):
        n, rest = m.group(1), m.group(2).strip()
        args = 0
        if rest.startswith(','):
            depth, args = 0, 1
            for ch in rest[1:]:
                if ch in '([{': depth += 1
                elif ch in ')]}': depth -= 1
                elif ch == ',' and depth == 0: args += 1
        for lang in ('vi', 'en'):
            v = strings[lang].get(n)
            if v is not None and placeholders(v) != args:
                problems.append('%s: getString(R.string.%s) %d tham so nhung chuoi %s co %d cho' % (name, n, args, lang, placeholders(v)))
for n in all_str:
    a, b = strings['vi'].get(n), strings['en'].get(n)
    if a is not None and b is not None and placeholders(a) != placeholders(b):
        problems.append('chuoi %s: so cho %%s/%%d lech giua VI va EN' % n)

# ---- Prefs.KEY_*
defined = set(re.findall(r'(?:const\s+val|val)\s+(KEY_\w+)', kt.get('Prefs', '')))
for n in sorted(set(re.findall(r'Prefs\.(KEY_\w+)', kt_all)) - defined):
    problems.append('Prefs.%s chua khai bao' % n)

# ---- Object.ham()
objs = {}
for name, src in kt.items():
    for m in re.finditer(r'(?m)^\s*(?:private\s+|internal\s+)?object\s+(\w+)', src):
        objs[m.group(1)] = strip_comments(src)
mem = {o: set(re.findall(r'\bfun\s+(?:<[^>]+>\s*)?(?:\w+\.)?(\w+)\s*\(', s)) | set(re.findall(r'\b(?:val|var|const val)\s+(\w+)', s))
          | set(re.findall(r'\b(?:class|object)\s+(\w+)', s)) for o, s in objs.items()}
test_src = {os.path.basename(f): strip_comments(rd(f)) for f in glob.glob(ROOT + '/scripts/tests/*.kt')}
for fn, code in list(((n, strip_comments(s)) for n, s in kt.items())) + list(test_src.items()):
    for o in objs:
        for m in re.finditer(r'(?<![\w.])' + o + r'\.(\w+)', code):
            if m.group(1) not in mem[o]:
                problems.append('%s: %s.%s khong ton tai' % (fn, o, m.group(1)))

# ---- Manifest
man = rd(M + '/AndroidManifest.xml')
for c in sorted(set(re.findall(r'android:name="\.?([A-Z]\w+)"', man))):
    if not re.search(r'\b(class|object)\s+' + c + r'\b', kt_all):
        problems.append('Manifest khai bao lop %s nhung khong co trong ma' % c)

# ---- App Shortcuts (J5/J6, 1bn): ShortcutActivity KHONG exported (neu exported, app khac tat duoc server cua ban), shortcuts.xml khop ma
sc_path = M + '/res/xml/shortcuts.xml'
if os.path.exists(sc_path):
    sc = rd(sc_path)
    gradle = rd(os.path.join(ROOT, 'app/build.gradle.kts'))
    app_id = (re.search(r'applicationId\s*=\s*"([^"]+)"', gradle) or [None, None])[1]
    if 'applicationIdSuffix' in gradle:
        problems.append('build.gradle.kts co applicationIdSuffix: targetPackage trong shortcuts.xml se KHONG khop o ban debug')
    if not re.search(r'android:name="android\.app\.shortcuts"\s+android:resource="@xml/shortcuts"', man):
        problems.append('Manifest thieu meta-data android.app.shortcuts tro toi @xml/shortcuts')
    if len(re.findall(r'<shortcut\b', sc)) > 4:
        problems.append('shortcuts.xml co qua 4 static shortcut (gioi han cua Android)')
    for pkg in set(re.findall(r'android:targetPackage="([^"]+)"', sc)):
        if pkg != app_id:
            problems.append('shortcuts.xml: targetPackage %s != applicationId %s' % (pkg, app_id))
    for cls in set(re.findall(r'android:targetClass="([^"]+)"', sc)):
        short = cls.split('.')[-1]
        if not re.search(r'\b(class|object)\s+' + short + r'\b', kt_all):
            problems.append('shortcuts.xml: targetClass %s khong co trong ma' % cls)
        m = re.search(r'<activity\b[^>]*android:name="\.?' + short + r'"[^>]*?/?>', man, re.S)
        if not m:
            problems.append('shortcuts.xml: %s chua khai bao trong Manifest' % short)
        elif short == 'ShortcutActivity' and 'android:exported="false"' not in m.group(0):
            problems.append('ShortcutActivity phai la android:exported="false" (neu exported, app khac goi duoc de tat server)')
    sa = kt.get('ShortcutActivity', '')
    consts = dict(re.findall(r'const val (ACTION_\w+) = "([^"]+)"', sa))
    for act in re.findall(r'<intent\b[^>]*android:action="([^"]+)"[^>]*android:targetClass="[^"]*ShortcutActivity"', sc) + \
               re.findall(r'<intent\b[^>]*android:targetClass="[^"]*ShortcutActivity"[^>]*android:action="([^"]+)"', sc):
        if act not in consts.values():
            problems.append('shortcuts.xml: action %s khong khop hang so nao trong ShortcutActivity.kt' % act)
    for name, val in consts.items():
        if val not in sc:
            problems.append('ShortcutActivity.%s (%s) khong co trong shortcuts.xml' % (name, val))

for p in sorted(set(problems)):
    print('LOI:', p)
print('android-ref-check: %s' % ('SACH' if not problems else '%d van de' % len(set(problems))))
sys.exit(1 if problems else 0)
