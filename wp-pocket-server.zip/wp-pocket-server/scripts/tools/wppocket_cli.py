#!/usr/bin/env python3
"""wppocket - cong cu dong lenh cho WP Pocket Server (PDF 2 muc T4; HANDOFF.md muc 1bq-D).

Chay tren may tinh (hoac Termux) trong CUNG mang LAN voi dien thoai, doc API trang thai CHI DOC (T1: GET /api/v1/status, Bearer token).
Chi dung thu vien chuan cua Python 3.8+ (khong pip). KHONG dieu khien duoc server (API chi doc) - day la cong cu giam sat / kiem tra.

    wppocket config set --host 192.168.1.23 --port 8080 --token <64 ky tu hex>   # luu tep cau hinh quyen 0600
    wppocket status                     # tom tat de doc
    wppocket status --json              # JSON nguyen ven (da kiem tra lược do)
    wppocket status --check --max-disk 90 --min-battery 15 --max-backup-age 48h --max-staleness 10m
                                        # kieu Nagios: dong dau OK/WARNING/CRITICAL, ma thoat 0/1/2 (3 = khong biet: khong ket noi/sai token)
    wppocket watch --interval 30        # theo doi lien tuc

Thu tu uu tien cau hinh: tham so dong lenh > bien moi truong (WPPOCKET_HOST, WPPOCKET_PORT, WPPOCKET_TOKEN, WPPOCKET_LANG) > tep cau hinh.
Ma thoat: 0 OK | 1 WARNING | 2 CRITICAL | 3 UNKNOWN (khong ket noi / sai token / API tat) | 64 sai cu phap lenh.

An toan: API chi mo cho mang LAN va di bang HTTP thuong -> CLI TU CHOI gui token toi may khong thuoc mang noi bo (IP rieng, loopback, *.local,
*.lan, *.home.arpa, ten khong co dau cham) tru khi co --allow-public; KHONG theo chuyen huong (khong ro ri token sang may khac); gioi han
64 KB phan hoi; token luon bi che (xxxx...xxxx) khi in ra; tep cau hinh quyen 0600 (canh bao neu nguoi khac doc duoc).
"""
import argparse
import ipaddress
import json
import os
import re
import socket
import stat
import sys
import time
import urllib.error
import urllib.request

VERSION = "1"
SCHEMA = "wp-pocket-status/1"
MAX_BODY = 64 * 1024
EX_OK, EX_WARN, EX_CRIT, EX_UNKNOWN, EX_USAGE = 0, 1, 2, 3, 64
TOKEN_RE = re.compile(r"[0-9a-f]{32,64}")  # dung fullmatch: "$" khop truoc xuong dong cuoi -> token "aaa\n" lot qua va gay chen header
PRIVATE_SUFFIXES = (".local", ".lan", ".home.arpa", ".localdomain")

STR = {
    "vi": {
        "title": "WP Pocket Server @ %s",
        "running": "Máy chủ", "yes": "ĐANG CHẠY", "no": "KHÔNG CHẠY",
        "battery": "Pin", "charging": "đang sạc", "not_charging": "không sạc",
        "disk": "Bộ nhớ", "used": "đã dùng %d%%",
        "backup": "Backup", "never": "chưa có", "ago": "%s trước", "count": "%d bản",
        "fresh": "Dữ liệu", "unknown": "không rõ",
        "s": "%d giây", "m": "%d phút", "h": "%d giờ", "d": "%d ngày",
        "err_conn": "Không kết nối được tới %s (%s). Điện thoại có cùng mạng LAN, server đang chạy và đã bật API không?",
        "err_timeout": "hết thời gian chờ", "err_refused": "bị từ chối",
        "err_401": "Token sai hoặc thiếu (HTTP 401). Mở app → Địa chỉ và token API… để lấy token.",
        "err_403": "Bị chặn (HTTP 403): máy của bạn không thuộc dải mạng LAN mà API cho phép (192.168/16, 10/8, 172.16/12).",
        "err_404": "Không có API (HTTP 404): hãy bật API trạng thái trong app rồi KHỞI ĐỘNG LẠI server.",
        "err_5xx": "Máy chủ lỗi (HTTP %d).",
        "err_redirect": "Máy chủ chuyển hướng (HTTP %d) - từ chối theo để không lộ token.",
        "err_big": "Phản hồi quá lớn (> 64 KB) - không phải API của WP Pocket Server?",
        "err_json": "Phản hồi không phải JSON hợp lệ.",
        "err_schema": "Phản hồi không đúng lược đồ %s (nhận: %s). Phiên bản app quá cũ/mới?",
        "err_public": "Từ chối gửi token tới %r: không phải địa chỉ mạng nội bộ (API chỉ cho LAN và đi bằng HTTP thường). Dùng --allow-public nếu bạn chắc chắn.",
        "err_token": "Token phải là 32-64 ký tự hex thường (0-9, a-f). Lấy trong app: Địa chỉ và token API…",
        "err_nohost": "Chưa có địa chỉ máy chủ: dùng --host, biến WPPOCKET_HOST hoặc `wppocket config set --host ...`.",
        "err_notoken": "Chưa có token: dùng WPPOCKET_TOKEN hoặc `wppocket config set --token ...` (tránh --token vì lộ trong danh sách tiến trình).",
        "warn_perm": "Cảnh báo: tệp cấu hình %s cho người khác đọc được (quyền %s); nên chmod 600.",
        "chk_ok": "OK - máy chủ chạy, pin %s, bộ nhớ %s, backup %s",
        "chk_warn": "WARNING - %s", "chk_crit": "CRITICAL - %s", "chk_unknown": "UNKNOWN - %s",
        "c_down": "máy chủ KHÔNG chạy", "c_stale": "dữ liệu cũ %s (quá %s): app/điện thoại có thể bị treo",
        "w_disk": "bộ nhớ đầy %d%% (ngưỡng %d%%)", "w_batt": "pin %d%% không sạc (ngưỡng %d%%)",
        "w_backup": "backup cũ %s (ngưỡng %s)", "w_nobackup": "chưa có backup nào",
        "cfg_saved": "Đã lưu cấu hình vào %s (quyền 0600).", "cfg_none": "(chưa có cấu hình)",
        "cfg_need": "config set cần ít nhất một trong --host/--port/--token.",
    },
    "en": {
        "title": "WP Pocket Server @ %s",
        "running": "Server", "yes": "RUNNING", "no": "NOT RUNNING",
        "battery": "Battery", "charging": "charging", "not_charging": "not charging",
        "disk": "Storage", "used": "%d%% used",
        "backup": "Backup", "never": "none yet", "ago": "%s ago", "count": "%d copies",
        "fresh": "Data", "unknown": "unknown",
        "s": "%d s", "m": "%d min", "h": "%d h", "d": "%d d",
        "err_conn": "Cannot reach %s (%s). Is the phone on the same LAN, the server running and the API enabled?",
        "err_timeout": "timed out", "err_refused": "refused",
        "err_401": "Wrong or missing token (HTTP 401). In the app open: API address and token…",
        "err_403": "Blocked (HTTP 403): your machine is not in the LAN range the API allows (192.168/16, 10/8, 172.16/12).",
        "err_404": "No API (HTTP 404): enable the status API in the app, then RESTART the server.",
        "err_5xx": "Server error (HTTP %d).",
        "err_redirect": "The server redirected (HTTP %d) - refusing to follow so the token is not leaked.",
        "err_big": "Response too large (> 64 KB) - not a WP Pocket Server API?",
        "err_json": "The response is not valid JSON.",
        "err_schema": "The response does not match schema %s (got: %s). App version too old/new?",
        "err_public": "Refusing to send the token to %r: not an internal network address (the API is LAN-only over plain HTTP). Use --allow-public if you are sure.",
        "err_token": "The token must be 32-64 lowercase hex characters (0-9, a-f). Get it in the app: API address and token…",
        "err_nohost": "No server address: use --host, the WPPOCKET_HOST variable or `wppocket config set --host ...`.",
        "err_notoken": "No token: use WPPOCKET_TOKEN or `wppocket config set --token ...` (avoid --token: it shows in the process list).",
        "warn_perm": "Warning: config file %s is readable by others (mode %s); chmod 600 it.",
        "chk_ok": "OK - server running, battery %s, storage %s, backup %s",
        "chk_warn": "WARNING - %s", "chk_crit": "CRITICAL - %s", "chk_unknown": "UNKNOWN - %s",
        "c_down": "server is NOT running", "c_stale": "data is stale %s (over %s): the app/phone may be hung",
        "w_disk": "storage %d%% full (threshold %d%%)", "w_batt": "battery %d%% and not charging (threshold %d%%)",
        "w_backup": "backup is %s old (threshold %s)", "w_nobackup": "no backup yet",
        "cfg_saved": "Saved configuration to %s (mode 0600).", "cfg_none": "(no configuration)",
        "cfg_need": "config set needs at least one of --host/--port/--token.",
    },
}


class CliError(Exception):
    def __init__(self, msg, code=EX_UNKNOWN):
        Exception.__init__(self, msg)
        self.code = code


# ----------------------------------------------------------------------------- logic thuan (co the import de kiem)

def parse_duration(text):
    """'90s' | '10m' | '48h' | '2d' | '30' (giay) -> giay (int) hoac None neu sai / <= 0."""
    m = re.fullmatch(r"([0-9]{1,6})([smhd]?)", (text or "").strip())
    if not m:
        return None
    n = int(m.group(1)) * {"": 1, "s": 1, "m": 60, "h": 3600, "d": 86400}[m.group(2)]
    return n if n > 0 else None


def duration_arg(text):
    """Kieu tham so argparse: sai dinh dang -> ArgumentTypeError (argparse bao loi, thoat 64)."""
    v = parse_duration(text)
    if v is None:
        raise argparse.ArgumentTypeError("%r khong hop le: dung dang 30s, 10m, 48h, 2d" % text)
    return v


def human_duration(sec, lang):
    t = STR[lang]
    sec = max(0, int(sec))
    if sec < 60:
        return t["s"] % sec
    if sec < 3600:
        return t["m"] % (sec // 60)
    if sec < 86400:
        return t["h"] % (sec // 3600)
    return t["d"] % (sec // 86400)


_INTERNAL_NETS = [ipaddress.ip_network(x) for x in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8", "169.254.0.0/16", "::1/128", "fc00::/7", "fe80::/10")]


def _ip_is_internal(ip):
    # Danh sach MINH BACH thay vi ip.is_private (is_private con tinh ca dai tai lieu/du phong 192.0.2/24, 203.0.113/24, 198.18/15, 240/4...).
    if ip.version == 6 and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped
    return any(ip in n for n in _INTERNAL_NETS if n.version == ip.version)


def is_private_host(host):
    """IP RFC1918/loopback/link-local/IPv6 ULA, hoac ten noi bo (*.local, *.lan, *.home.arpa, localhost, ten khong co dau cham)."""
    h = (host or "").strip().strip("[]").lower()
    if not h:
        return False
    try:
        return _ip_is_internal(ipaddress.ip_address(h.split("%")[0]))
    except ValueError:
        pass
    if h == "localhost" or "." not in h:
        return True
    return any(h.endswith(s) for s in PRIVATE_SUFFIXES)


def mask_token(tok):
    if not tok:
        return ""
    return tok[:4] + "..." + tok[-4:] if len(tok) >= 12 else "****"


def validate_status(d):
    """Tra ve (ok, ly_do). Chap nhan truong thua (tuong thich xuoi); truong thieu/sai kieu bi coi la 'khong biet' o noi hien thi."""
    if not isinstance(d, dict):
        return False, type(d).__name__
    if d.get("schema") != SCHEMA:
        return False, str(d.get("schema"))
    return True, ""


def _int_or_none(v, lo, hi):
    return v if isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi else None


def evaluate(d, now, lang, max_disk=None, min_battery=None, max_backup_age=None, max_staleness=None):
    """Danh gia kieu Nagios. Tra ve (level, thong_bao) voi level 0 OK / 1 WARNING / 2 CRITICAL."""
    t = STR[lang]
    crit, warn = [], []
    gen = d.get("generated_at")
    if max_staleness is not None and isinstance(gen, int) and now - gen > max_staleness:
        crit.append(t["c_stale"] % (human_duration(now - gen, lang), human_duration(max_staleness, lang)))
    if d.get("server_running") is not True:
        crit.append(t["c_down"])
    disk = _int_or_none(d.get("disk_used_pct"), 0, 100)
    if max_disk is not None and disk is not None and disk >= max_disk:
        warn.append(t["w_disk"] % (disk, max_disk))
    batt = _int_or_none(d.get("battery_pct"), 0, 100)
    if min_battery is not None and batt is not None and batt <= min_battery and d.get("charging") is not True:
        warn.append(t["w_batt"] % (batt, min_battery))
    last = d.get("last_backup_at")
    if max_backup_age is not None:
        if not isinstance(last, int) or isinstance(last, bool) or last <= 0:
            warn.append(t["w_nobackup"])
        elif now - last > max_backup_age:
            warn.append(t["w_backup"] % (human_duration(now - last, lang), human_duration(max_backup_age, lang)))
    if crit:
        return EX_CRIT, t["chk_crit"] % "; ".join(crit + warn)
    if warn:
        return EX_WARN, t["chk_warn"] % "; ".join(warn)
    batt_s = ("%d%%" % batt) if batt is not None else t["unknown"]
    disk_s = ("%d%%" % disk) if disk is not None else t["unknown"]
    if isinstance(last, int) and not isinstance(last, bool) and last > 0:
        bk = t["ago"] % human_duration(max(0, now - last), lang)
    else:
        bk = t["never"]
    return EX_OK, t["chk_ok"] % (batt_s, disk_s, bk)


def render_status(d, hostport, now, lang):
    t = STR[lang]
    ver = d.get("app_version")
    head = t["title"] % hostport + (" (v%s)" % ver if isinstance(ver, str) and ver else "")
    run = t["yes"] if d.get("server_running") is True else t["no"]
    batt = _int_or_none(d.get("battery_pct"), 0, 100)
    if batt is None:
        batt_s = t["unknown"]
    else:
        batt_s = "%d%% (%s)" % (batt, t["charging"] if d.get("charging") is True else t["not_charging"])
    disk = _int_or_none(d.get("disk_used_pct"), 0, 100)
    disk_s = t["used"] % disk if disk is not None else t["unknown"]
    last = d.get("last_backup_at")
    cnt = _int_or_none(d.get("backup_count"), 0, 10 ** 6)
    if isinstance(last, int) and not isinstance(last, bool) and last > 0:
        bk = t["ago"] % human_duration(max(0, now - last), lang) + (" (%s)" % (t["count"] % cnt) if cnt is not None else "")
    else:
        bk = t["never"]
    gen = d.get("generated_at")
    fresh = t["ago"] % human_duration(max(0, now - gen), lang) if isinstance(gen, int) and not isinstance(gen, bool) and gen > 0 else t["unknown"]
    rows = [(t["running"], run), (t["battery"], batt_s), (t["disk"], disk_s), (t["backup"], bk), (t["fresh"], fresh)]
    w = max(len(k) for k, _ in rows) + 1
    return "\n".join([head] + ["  %-*s %s" % (w, k + ":", v) for k, v in rows])


# ----------------------------------------------------------------------------- cau hinh

def config_path():
    p = os.environ.get("WPPOCKET_CONFIG")
    if p:
        return p
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "wppocket", "config.json")


def load_config(lang="vi", warn=True):
    p = config_path()
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    if warn and os.name == "posix":
        try:
            mode = stat.S_IMODE(os.stat(p).st_mode)
            if mode & 0o077:
                sys.stderr.write(STR[lang]["warn_perm"] % (p, oct(mode)) + "\n")
        except OSError:
            pass
    return {k: data[k] for k in ("host", "port", "token") if k in data}


def save_config(cfg):
    p = config_path()
    os.makedirs(os.path.dirname(p), mode=0o700, exist_ok=True)
    tmp = p + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)
    return p


def resolve(args, lang):
    cfg = load_config(lang)
    host = args.host or os.environ.get("WPPOCKET_HOST") or cfg.get("host")
    port = args.port or os.environ.get("WPPOCKET_PORT") or cfg.get("port") or 8080
    token = args.token or os.environ.get("WPPOCKET_TOKEN") or cfg.get("token")
    t = STR[lang]
    if not host:
        raise CliError(t["err_nohost"], EX_USAGE)
    try:
        port = int(port)
        if not 1 <= port <= 65535:
            raise ValueError
    except (TypeError, ValueError):
        raise CliError("port: 1..65535", EX_USAGE)
    if not token:
        raise CliError(t["err_notoken"], EX_USAGE)
    if not TOKEN_RE.fullmatch(str(token)):
        raise CliError(t["err_token"], EX_USAGE)
    if not re.fullmatch(r"[A-Za-z0-9.\-:\[\]%]{1,253}", str(host)):
        raise CliError("host khong hop le / invalid host", EX_USAGE)
    if not is_private_host(str(host)) and not args.allow_public:
        raise CliError(t["err_public"] % str(host), EX_USAGE)
    return str(host), port, str(token)


# ----------------------------------------------------------------------------- mang

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def fetch_status(host, port, token, timeout, lang):
    t = STR[lang]
    hostport = "[%s]:%d" % (host.strip("[]"), port) if ":" in host.strip("[]") else "%s:%d" % (host, port)
    url = "http://%s/api/v1/status" % hostport
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token, "Accept": "application/json", "User-Agent": "wppocket-cli/" + VERSION})
    # ProxyHandler({}): KHONG di qua proxy cua moi truong (http_proxy) - token se ro ri toi proxy; khong theo chuyen huong.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    try:
        with opener.open(req, timeout=timeout) as r:
            body = r.read(MAX_BODY + 1)
            code = r.status
    except urllib.error.HTTPError as e:
        code = e.code
        if code == 401:
            raise CliError(t["err_401"])
        if code == 403:
            raise CliError(t["err_403"])
        if code == 404:
            raise CliError(t["err_404"])
        if 300 <= code < 400:
            raise CliError(t["err_redirect"] % code)
        raise CliError(t["err_5xx"] % code)
    except (socket.timeout, TimeoutError):
        raise CliError(t["err_conn"] % (hostport, t["err_timeout"]))
    except urllib.error.URLError as e:
        reason = e.reason
        if isinstance(reason, (socket.timeout, TimeoutError)):
            raise CliError(t["err_conn"] % (hostport, t["err_timeout"]))
        if isinstance(reason, ConnectionRefusedError):
            raise CliError(t["err_conn"] % (hostport, t["err_refused"]))
        raise CliError(t["err_conn"] % (hostport, str(reason)))
    except OSError as e:
        raise CliError(t["err_conn"] % (hostport, str(e)))
    if len(body) > MAX_BODY:
        raise CliError(t["err_big"])
    try:
        d = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise CliError(t["err_json"])
    ok, why = validate_status(d)
    if not ok:
        raise CliError(t["err_schema"] % (SCHEMA, why))
    return d, hostport


# ----------------------------------------------------------------------------- lenh

def cmd_status(args, lang):
    host, port, token = resolve(args, lang)
    d, hp = fetch_status(host, port, token, args.timeout, lang)
    now = int(time.time())
    if args.json:
        print(json.dumps(d, ensure_ascii=False, indent=2, sort_keys=True))
    elif not args.check:
        print(render_status(d, hp, now, lang))
    if args.check:
        level, msg = evaluate(d, now, lang, args.max_disk, args.min_battery, args.max_backup_age, args.max_staleness)
        print(msg)
        return level
    return EX_OK if d.get("server_running") is True else EX_CRIT


def cmd_watch(args, lang):
    host, port, token = resolve(args, lang)
    n = 0
    last = EX_OK
    while True:
        try:
            d, hp = fetch_status(host, port, token, args.timeout, lang)
            now = int(time.time())
            level, msg = evaluate(d, now, lang, args.max_disk, args.min_battery, args.max_backup_age, args.max_staleness)
            print("%s  %s" % (time.strftime("%H:%M:%S"), msg))
            last = level
        except CliError as e:
            print("%s  %s" % (time.strftime("%H:%M:%S"), STR[lang]["chk_unknown"] % e))
            last = e.code
        sys.stdout.flush()
        n += 1
        if args.count and n >= args.count:
            return last
        time.sleep(args.interval)


def cmd_config(args, lang):
    t = STR[lang]
    if args.action == "path":
        print(config_path())
        return EX_OK
    if args.action == "show":
        cfg = load_config(lang)
        if not cfg:
            print(t["cfg_none"])
            return EX_OK
        for k in ("host", "port", "token"):
            if k in cfg:
                print("%s = %s" % (k, cfg[k] if (k != "token" or args.reveal) else mask_token(str(cfg[k]))))
        return EX_OK
    # set
    if not (args.host or args.port or args.token):
        raise CliError(t["cfg_need"], EX_USAGE)
    cfg = load_config(lang, warn=False)
    if args.host:
        if not re.fullmatch(r"[A-Za-z0-9.\-:\[\]%]{1,253}", args.host):
            raise CliError("host khong hop le / invalid host", EX_USAGE)
        if not is_private_host(args.host) and not args.allow_public:
            raise CliError(t["err_public"] % args.host, EX_USAGE)
        cfg["host"] = args.host
    if args.port:
        if not 1 <= args.port <= 65535:
            raise CliError("port: 1..65535", EX_USAGE)
        cfg["port"] = args.port
    if args.token:
        if not TOKEN_RE.fullmatch(args.token):
            raise CliError(t["err_token"], EX_USAGE)
        cfg["token"] = args.token
    print(t["cfg_saved"] % save_config(cfg))
    return EX_OK


def build_parser():
    ap = argparse.ArgumentParser(prog="wppocket", description="Cong cu dong lenh giam sat WP Pocket Server (API trang thai chi doc, LAN).")
    ap.add_argument("--lang", choices=("vi", "en"), default=None, help="ngon ngu (mac dinh: WPPOCKET_LANG hoac vi)")
    sub = ap.add_subparsers(dest="cmd")

    def conn(p):
        p.add_argument("--host")
        p.add_argument("--port", type=int)
        p.add_argument("--token", help="TRANH dung: lo trong danh sach tien trinh; dung WPPOCKET_TOKEN hoac `config set`")
        p.add_argument("--allow-public", action="store_true", help="cho phep gui token toi may khong thuoc mang noi bo (khong khuyen nghi)")
        p.add_argument("--timeout", type=float, default=5.0)

    def thresholds(p):
        p.add_argument("--max-disk", type=int, metavar="PCT")
        p.add_argument("--min-battery", type=int, metavar="PCT")
        p.add_argument("--max-backup-age", type=duration_arg, metavar="DUR")
        p.add_argument("--max-staleness", type=duration_arg, metavar="DUR")

    s = sub.add_parser("status", help="trang thai hien tai")
    conn(s)
    thresholds(s)
    s.add_argument("--json", action="store_true")
    s.add_argument("--check", action="store_true", help="kieu Nagios: in 1 dong OK/WARNING/CRITICAL, ma thoat 0/1/2")
    w = sub.add_parser("watch", help="theo doi lien tuc")
    conn(w)
    thresholds(w)
    w.add_argument("--interval", type=float, default=30.0)
    w.add_argument("--count", type=int, default=0, help="so lan (0 = vo han)")
    c = sub.add_parser("config", help="xem/dat cau hinh")
    c.add_argument("action", choices=("show", "set", "path"))
    c.add_argument("--host")
    c.add_argument("--port", type=int)
    c.add_argument("--token")
    c.add_argument("--allow-public", action="store_true")
    c.add_argument("--reveal", action="store_true", help="show: in token day du")

    def usage_error(message):
        sys.stderr.write("wppocket: %s\n" % message)
        sys.exit(EX_USAGE)

    ap.error = usage_error
    for p in (s, w, c):
        p.error = usage_error
    return ap


def main(argv=None):
    ap = build_parser()
    args = ap.parse_args(argv)
    lang = args.lang or os.environ.get("WPPOCKET_LANG") or "vi"
    if lang not in STR:
        lang = "vi"
    if not args.cmd:
        ap.print_help()
        return EX_USAGE
    for name in ("max_disk", "min_battery"):
        v = getattr(args, name, None)
        if v is not None and not 0 <= v <= 100:
            sys.stderr.write("wppocket: --%s phai trong 0..100\n" % name.replace("_", "-"))
            return EX_USAGE
    try:
        if args.cmd == "status":
            return cmd_status(args, lang)
        if args.cmd == "watch":
            return cmd_watch(args, lang)
        return cmd_config(args, lang)
    except CliError as e:
        sys.stderr.write(str(e) + "\n")
        return e.code
    except KeyboardInterrupt:
        return EX_OK


if __name__ == "__main__":
    sys.exit(main())
