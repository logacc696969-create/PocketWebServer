#!/usr/bin/env python3
"""Doc muc DT_NEEDED (cac thu vien dong ma file ELF yeu cau) bang Python THUAN - khong can readelf/binutils, chay duoc o bat ky dau
(sandbox, CI, may nguoi dung). Ho tro ELF32/ELF64, little/big endian. Dung boi check-runtime-closure.py. HANDOFF.md muc 1bi.
Khong phai bo phan tich ELF day du: chi doi dung de lay danh sach NEEDED va SONAME."""
import struct, sys

def _u(fmt, data, off): return struct.unpack_from(fmt, data, off)

def parse(path):
    """Tra ve dict {'needed': [...], 'soname': str|None, 'bits': 32|64}; ném ValueError neu khong phai ELF dong."""
    with open(path, 'rb') as f: data = f.read()
    if data[:4] != b'\x7fELF': raise ValueError('khong phai ELF')
    bits = {1: 32, 2: 64}.get(data[4]); end = {1: '<', 2: '>'}.get(data[5])
    if not bits or not end: raise ValueError('ELF khong hop le')
    if bits == 64:
        phoff, = _u(end + 'Q', data, 0x20); phentsize, phnum = _u(end + 'HH', data, 0x36)
    else:
        phoff, = _u(end + 'I', data, 0x1C); phentsize, phnum = _u(end + 'HH', data, 0x2A)
    loads, dyn = [], None
    for i in range(phnum):
        o = phoff + i * phentsize
        if bits == 64:
            p_type, _fl, p_off, p_vaddr, _pa, p_filesz, p_memsz, _al = _u(end + 'IIQQQQQQ', data, o)
        else:
            p_type, p_off, p_vaddr, _pa, p_filesz, p_memsz, _fl, _al = _u(end + 'IIIIIIII', data, o)
        if p_type == 1: loads.append((p_vaddr, p_off, p_filesz))
        if p_type == 2: dyn = (p_off, p_filesz)
    if dyn is None: return {'needed': [], 'soname': None, 'bits': bits}
    def v2o(v):
        for va, off, sz in loads:
            if va <= v < va + max(sz, 1): return off + (v - va)
        return v   # du phong: coi vaddr = offset (ELF tu tao trong test)
    ents, esz = [], 16 if bits == 64 else 8
    off, size = dyn
    for o in range(off, off + size, esz):
        tag, val = _u(end + ('qQ' if bits == 64 else 'iI'), data, o)
        if tag == 0: break
        ents.append((tag, val))
    strtab = next((v for t, v in ents if t == 5), None)
    if strtab is None: return {'needed': [], 'soname': None, 'bits': bits}
    so = v2o(strtab)
    def s(i):
        a = so + i; b = data.index(b'\0', a); return data[a:b].decode('utf-8', 'replace')
    return {'needed': [s(v) for t, v in ents if t == 1], 'soname': next((s(v) for t, v in ents if t == 14), None), 'bits': bits}

if __name__ == '__main__':
    for p in sys.argv[1:]:
        try: r = parse(p); print('%s: NEEDED=%s SONAME=%s' % (p, ' '.join(r['needed']), r['soname']))
        except ValueError as e: print('%s: %s' % (p, e))
