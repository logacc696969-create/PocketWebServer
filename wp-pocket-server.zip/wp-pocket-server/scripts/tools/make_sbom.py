#!/usr/bin/env python3
"""Sinh SBOM CycloneDX 1.5 (JSON) cho WP Pocket Server tu DU LIEU BUILD DA CO (PDF 2 muc L5; HANDOFF.md muc 1bk).

Nguon (tat ca tuy chon, thieu nguon nao thi bo qua nguon do - khong dung giua chung):
  - app/build.gradle.kts           -> thu vien Gradle (implementation/api/...("group:artifact:version"))     pkg:maven/...
  - scripts/lib/pins.env           -> Adminer / Tiny File Manager (phien ban + SHA-256 da ghim)               pkg:github/...
  - --termux m1.tsv [m2.tsv ...]   -> goi Termux da tai (pkg<TAB>version<TAB>sha256<TAB>arch), khu trung       pkg:deb/termux/...
  - --verify report.tsv            -> bao cao xac minh tai file (nhan<TAB>trang thai<TAB>thuat toan<TAB>hash<TAB>nguon): moi tep
                                      thanh component type=file kem hash THUC va trang thai xac minh (property)
Giay phep CHI ghi cho Adminer va Tiny File Manager (da doc tan nguon, xem THIRD_PARTY_NOTICES.md); cac thanh phan con lai KHONG khai giay phep (khong doan).
Dau ra on dinh (cung dau vao => cung bytes): serialNumber = uuid5 cua noi dung; thoi gian chi co khi truyen --timestamp.
Dung: python3 scripts/tools/make_sbom.py --version 0.2.0 --termux a.tsv b.tsv --verify r.tsv --out sbom.cdx.json
"""
import argparse, json, os, re, sys, uuid

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
HEX64 = re.compile(r'^[0-9a-f]{64}$')

# Giay phep da doc tan nguon (THIRD_PARTY_NOTICES.md, cot "Nguon kiem tra" = da doc). Dung `name` (KHONG ep ma SPDX) khi nguon chi ghi
# "GPL v2"/"GPL v3" ma khong noi "only"/"or later" - de khong khang dinh nhieu hon nhung gi da doc.
LICENSES = {
    'adminer': [{'license': {'name': 'Apache License 2.0 or GNU GPL v2 (choose one) - per @license header'}}],
    'tinyfilemanager': [{'license': {'name': 'GNU GPL v3'}}],
}


def read(p):
    try:
        return open(p, encoding='utf8').read()
    except OSError:
        return ''


def purl_escape(s):
    return re.sub(r'[^A-Za-z0-9._~-]', lambda m: '%%%02X' % ord(m.group(0)), s)


def gradle_deps(root):
    out = []
    for m in re.finditer(r'(?m)^\s*(?:implementation|api|runtimeOnly|compileOnly)\(\s*"([^":]+):([^":]+):([^":"]+)"\s*\)', read(os.path.join(root, 'app/build.gradle.kts'))):
        g, a, v = m.groups()
        out.append({'type': 'library', 'group': g, 'name': a, 'version': v,
                    'purl': 'pkg:maven/%s/%s@%s' % (purl_escape(g), purl_escape(a), purl_escape(v)),
                    'bom-ref': 'maven:%s:%s:%s' % (g, a, v),
                    'properties': [{'name': 'wppocket:source', 'value': 'app/build.gradle.kts'}]})
    return out


def pins(root):
    env = {}
    for line in read(os.path.join(root, 'scripts/lib/pins.env')).splitlines():
        m = re.match(r'^([A-Z0-9_]+)=("?)(.*?)\2\s*$', line.strip())
        if m:
            env[m.group(1)] = m.group(3)
    out = []
    for key, name, owner, repo in (('ADMINER', 'adminer', 'vrana', 'adminer'), ('TFM', 'tinyfilemanager', 'prasathmani', 'tinyfilemanager')):
        ver, sha = env.get(key + '_VERSION', ''), env.get(key + '_SHA256', '').lower()
        if not ver:
            continue
        c = {'type': 'application', 'name': name, 'version': ver,
             'purl': 'pkg:github/%s/%s@%s' % (owner, repo, purl_escape(ver)), 'bom-ref': 'pin:' + name,
             'licenses': LICENSES[name],
             'properties': [{'name': 'wppocket:source', 'value': 'scripts/lib/pins.env (ghim phien ban + SHA-256)'}]}
        if HEX64.match(sha):
            c['hashes'] = [{'alg': 'SHA-256', 'content': sha}]
        out.append(c)
    return out


def termux(paths):
    seen, out = set(), []
    for p in paths:
        for line in read(p).splitlines():
            f = line.rstrip('\n').split('\t')
            if len(f) < 3 or not f[0].strip() or line.startswith('#'):
                continue
            pkg, ver, sha = f[0].strip(), f[1].strip(), f[2].strip().lower()
            arch = f[3].strip() if len(f) > 3 and f[3].strip() else 'unknown'
            key = (pkg, ver, arch)
            if key in seen:
                continue
            seen.add(key)
            c = {'type': 'library', 'name': pkg, 'version': ver,
                 'purl': 'pkg:deb/termux/%s@%s?arch=%s' % (purl_escape(pkg), purl_escape(ver), purl_escape(arch)),
                 'bom-ref': 'termux:%s:%s:%s' % (pkg, ver, arch),
                 'properties': [{'name': 'wppocket:source', 'value': 'packages.termux.dev (goi .deb tai luc build)'}]}
            if HEX64.match(sha):
                c['hashes'] = [{'alg': 'SHA-256', 'content': sha}]
            out.append(c)
    return out


def verify_report(path):
    out, seen = [], set()
    for line in read(path).splitlines():
        f = line.split('\t')
        if len(f) < 4 or line.startswith('#'):
            continue
        label, status, algo, digest = f[0].strip(), f[1].strip(), f[2].strip().lower(), f[3].strip().lower()
        src = f[4].strip() if len(f) > 4 else ''
        if not label or (label, digest) in seen:
            continue
        seen.add((label, digest))
        c = {'type': 'file', 'name': label, 'bom-ref': 'file:%s:%s' % (label, digest[:12]),
             'properties': [{'name': 'wppocket:verify-status', 'value': status}]}
        if src:
            c['properties'].append({'name': 'wppocket:hash-source', 'value': src})
        alg = {'sha256': 'SHA-256', 'sha1': 'SHA-1', 'sha512': 'SHA-512'}.get(algo)
        want = {'SHA-256': 64, 'SHA-1': 40, 'SHA-512': 128}.get(alg)
        if alg and want and re.fullmatch(r'[0-9a-f]{%d}' % want, digest):
            c['hashes'] = [{'alg': alg, 'content': digest}]
        out.append(c)
    return out


def build(version, termux_paths, verify_path, root=ROOT, timestamp=None):
    comps = gradle_deps(root) + pins(root) + termux(termux_paths) + (verify_report(verify_path) if verify_path else [])
    comps.sort(key=lambda c: (c['type'], c['name'], c.get('version', ''), c['bom-ref']))
    uniq, seen = [], set()
    for c in comps:
        if c['bom-ref'] in seen:
            continue
        seen.add(c['bom-ref']); uniq.append(c)
    app = {'type': 'application', 'name': 'WP Pocket Server', 'version': version, 'bom-ref': 'app:wp-pocket-server',
           'purl': 'pkg:generic/wp-pocket-server@%s' % purl_escape(version)}
    bom = {'bomFormat': 'CycloneDX', 'specVersion': '1.5', 'version': 1,
           'metadata': {'component': app,
                        'tools': {'components': [{'type': 'application', 'name': 'make_sbom.py', 'version': '1'}]}},
           'components': uniq}
    if timestamp:
        bom['metadata']['timestamp'] = timestamp
    body = json.dumps(bom, sort_keys=True, ensure_ascii=False)
    bom['serialNumber'] = 'urn:uuid:' + str(uuid.uuid5(uuid.NAMESPACE_URL, 'wppocket-sbom:' + body))
    return bom


def main():
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('--version', default='0.0.0')
    ap.add_argument('--termux', nargs='*', default=[])
    ap.add_argument('--verify', default='')
    ap.add_argument('--root', default=ROOT)
    ap.add_argument('--timestamp', default='')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    bom = build(a.version, a.termux, a.verify, a.root, a.timestamp or None)
    with open(a.out, 'w', encoding='utf8') as fh:
        json.dump(bom, fh, indent=2, sort_keys=True, ensure_ascii=False); fh.write('\n')
    kinds = {}
    for c in bom['components']:
        kinds[c['type']] = kinds.get(c['type'], 0) + 1
    print('SBOM: %d thanh phan %s -> %s' % (len(bom['components']), kinds, a.out))


if __name__ == '__main__':
    main()
