#!/usr/bin/env python3
"""Kiem tra TINH "dong goi du thu vien" cua mot thu muc runtime-out (HANDOFF.md muc 1bi) - thay the viec phai cai APK len dien thoai moi biet
thieu thu vien ("library libz.so.1 not found" - loi that da gap o vong 1u).
Voi MOI file lib*.so (ELF) trong thu muc: moi muc DT_NEEDED phai thoa MOT trong:
  (a) la thu vien he thong Android duoc phep dung (libc.so, libm.so, libdl.so, liblog.so, ...);
  (b) co file cung ten trong thu muc;
  (c) co dong trong soname-map.txt ("ten SONAME that" -> "ten da doi"), VA file da doi ton tai trong thu muc.
Cach dung: python3 check-runtime-closure.py <runtime-out> [soname-map.txt] [--allow=libfoo.so,...]   Thoat 0 = du, 1 = thieu."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import elf_needed

# Thu vien he thong ma ung dung Android duoc phep nap (NDK public libraries). KHONG co libz.so.1 / libc++_shared.so / libcrypto...: phai tu dong goi.
SYSTEM_OK = {'libc.so', 'libm.so', 'libdl.so', 'liblog.so', 'libz.so', 'libandroid.so', 'libOpenSLES.so', 'libEGL.so', 'libGLESv1_CM.so',
             'libGLESv2.so', 'libGLESv3.so', 'libvulkan.so', 'libjnigraphics.so', 'libmediandk.so', 'libnativewindow.so', 'libaaudio.so'}

def load_map(path):
    m = {}
    if path and os.path.exists(path):
        for line in open(path, encoding='utf-8'):
            p = line.split()
            if len(p) == 2: m[p[0]] = p[1]
    return m

def check(outdir, map_path=None, extra_allow=()):
    smap = load_map(map_path or os.path.join(outdir, 'soname-map.txt'))
    allow = SYSTEM_OK | set(extra_allow)
    files = sorted(f for f in os.listdir(outdir) if f.endswith('.so') and os.path.isfile(os.path.join(outdir, f)))
    problems, checked = [], 0
    for f in files:
        try: info = elf_needed.parse(os.path.join(outdir, f))
        except ValueError: continue          # file .so khong phai ELF (vd script da doi shebang) -> bo qua
        checked += 1
        for n in info['needed']:
            if n in allow or os.path.exists(os.path.join(outdir, n)): continue
            mapped = smap.get(n)
            if mapped and os.path.exists(os.path.join(outdir, mapped)): continue
            problems.append((f, n, ('soname-map tro toi %s nhung file nay KHONG co' % mapped) if mapped else 'khong co file, khong co trong soname-map, khong phai thu vien he thong'))
    return checked, problems

if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    allow = [x for a in sys.argv[1:] if a.startswith('--allow=') for x in a[8:].split(',') if x]
    if not args: print(__doc__); sys.exit(2)
    checked, problems = check(args[0], args[1] if len(args) > 1 else None, allow)
    for f, n, why in problems: print('THIEU: %s can %s - %s' % (f, n, why))
    print('check-runtime-closure: %d file ELF, %s' % (checked, 'DU' if not problems else '%d phu thuoc THIEU' % len(problems)))
    sys.exit(1 if problems else 0)
