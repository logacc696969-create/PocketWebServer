#!/usr/bin/env python3
"""Kiem tra app/src/main/baseline-prof.txt (S8; HANDOFF.md muc 1bp-K) KHONG can build Android.

Cu phap (theo tai lieu Android 'Manually create and measure Baseline Profiles'): moi dong la mot quy tac, tap cha cua dinh dang HRF cua ART:
  [HSP]*L<lop>;                       quy tac LOP
  [HSP]*L<lop>;-><ham>(<tham so>)<tra ve>   quy tac HAM (mo ta kieu JVM)
Cong cu nay chi chap nhan tap con KHONG dung ky tu thay the (khong co * / **) de kiem DUOC bang doi chieu voi ma nguon: moi lop phai la lop
Kotlin co that (hoac lop ViewBinding sinh tu layout), moi ham phai co that voi DUNG kieu JVM. Quy tac khong khop gi thi AGP bo qua (khong loi build)
nhung se la quy tac chet - kiem tra de khong bao gio chet."""
import os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "app/src/main/java")
RULE = re.compile(r"^([HSP]{0,3})(L[A-Za-z0-9_/$]+;)(?:->([A-Za-z0-9_$<>]+)\(([^)]*)\)([A-Za-z0-9_/$;\[]+))?$")
KT_TYPES = {"Int": "I", "Long": "J", "Boolean": "Z", "Unit": "V", "Float": "F", "Double": "D", "String": "Ljava/lang/String;", "Bundle": "Landroid/os/Bundle;",
            "Intent": "Landroid/content/Intent;", "IBinder": "Landroid/os/IBinder;", "Context": "Landroid/content/Context;"}
def kt_desc(t):
    return KT_TYPES.get(t.strip().rstrip("?"))
def find_class_file(cls_path):
    pkg_path = cls_path[1:-1]                       # com/wppocket/server/MainActivity
    base = os.path.join(SRC, os.path.dirname(pkg_path)); name = os.path.basename(pkg_path)
    p = os.path.join(base, name + ".kt")
    return p if os.path.isfile(p) else None
def kt_signature_desc(text, fn):
    """Tra ve danh sach descriptor (params, ret) cua moi khai bao `fun <fn>(...)` trong ma Kotlin."""
    out = []
    for m in re.finditer(r"\bfun\s+%s\s*\(([^)]*)\)\s*(?::\s*([\w?.]+))?" % re.escape(fn), text):
        params = [p for p in (x.strip() for x in m.group(1).split(",")) if p]
        pd = []
        for p in params:
            d = kt_desc(p.split(":", 1)[1]) if ":" in p else None
            if d is None: pd = None; break
            pd.append(d)
        ret = kt_desc(m.group(2)) if m.group(2) else "V"
        if pd is not None and ret: out.append(("".join(pd), ret))
    return out
def check(lines):
    errs = []
    layouts = {f[:-4] for f in os.listdir(os.path.join(ROOT, "app/src/main/res/layout")) if f.endswith(".xml")}
    for n, raw in enumerate(lines, 1):
        l = raw.rstrip("\n")
        if not l.strip(): errs.append("dong %d: dong trong (khong cho phep, de tranh loi phan tich)" % n); continue
        if l.lstrip().startswith("#"): errs.append("dong %d: chu thich '#' - khong dung (khong chac profgen chap nhan)" % n); continue
        if "*" in l: errs.append("dong %d: ky tu thay the '*' - cong cu nay chi cho quy tac ro rang de kiem duoc" % n); continue
        m = RULE.match(l)
        if not m: errs.append("dong %d: sai cu phap: %r" % (n, l)); continue
        cls, fn, params, ret = m.group(2), m.group(3), m.group(4), m.group(5)
        if "/databinding/" in cls:                    # lop ViewBinding sinh tu layout: ActivityMainBinding <- activity_main.xml
            nm = cls.rsplit("/", 1)[1][:-1]; snake = re.sub(r"(?<!^)([A-Z])", r"_\1", nm[:-len("Binding")]).lower()
            if snake not in layouts: errs.append("dong %d: %s khong co layout %s.xml" % (n, cls, snake))
            continue
        f = find_class_file(cls)
        if f is None: errs.append("dong %d: khong co tep Kotlin cho lop %s" % (n, cls)); continue
        if fn:
            descs = kt_signature_desc(open(f, encoding="utf-8").read(), fn)
            if (params, ret) not in descs: errs.append("dong %d: %s->%s(%s)%s khong khop khai bao Kotlin (co: %s)" % (n, cls, fn, params, ret, descs))
    return errs
def main():
    p = os.path.join(ROOT, "app/src/main/baseline-prof.txt")
    errs = check(open(p, encoding="utf-8").read().split("\n")[:-1] if open(p, encoding="utf-8").read().endswith("\n") else open(p, encoding="utf-8").read().split("\n"))
    for e in errs: print("LOI:", e, file=sys.stderr)
    print("baseline-prof.txt: %s" % ("hop le" if not errs else "%d loi" % len(errs)))
    return 1 if errs else 0
if __name__ == "__main__":
    sys.exit(main())
