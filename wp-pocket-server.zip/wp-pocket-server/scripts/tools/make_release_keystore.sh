#!/bin/sh
# Tao KHOA KY PHAT HANH cho ung dung (HANDOFF.md muc 1br-H, docs/RELEASE_SIGNING.md). Chay MOT LAN tren may CUA BAN (khong chay tren CI/may chung).
# Dung:  sh scripts/tools/make_release_keystore.sh <thu-muc-dich-NGOAI-repo> ["Ten chu so huu"]
# Ket qua trong thu muc dich (quyen 0600/0700): release.jks, secrets.txt (4 gia tri dan vao GitHub Secrets), release.jks.b64.
# CANH BAO: MAT khoa nay = KHONG BAO GIO cap nhat duoc app da phat hanh (Android chi cho cai de neu CUNG chu ky). Sao luu release.jks + mat khau
# o it nhat 2 noi OFFLINE (usb ma hoa, ket sat/trinh quan ly mat khau). KHONG commit, KHONG gui qua chat/email.
set -eu
DEST="${1:-}"
OWNER="${2:-WP Pocket Server}"
if [ -z "$DEST" ]; then
  echo "Dung: sh $0 <thu-muc-dich-NGOAI-repo> [\"Ten chu so huu\"]" >&2; exit 2
fi
command -v keytool >/dev/null 2>&1 || { echo "Thieu keytool (cai JDK 17+)." >&2; exit 2; }
command -v openssl >/dev/null 2>&1 || { echo "Thieu openssl (de sinh mat khau ngau nhien)." >&2; exit 2; }
# Tu choi thu muc dich nam TRONG mot kho git (de khong lo commit nham khoa)
mkdir -p "$DEST"
DEST_ABS="$(cd "$DEST" && pwd)"
d="$DEST_ABS"
while [ "$d" != "/" ]; do
  if [ -e "$d/.git" ]; then echo "TU CHOI: $DEST_ABS nam trong kho git ($d) - chon thu muc NGOAI repo." >&2; exit 2; fi
  d="$(dirname "$d")"
done
if [ -e "$DEST_ABS/release.jks" ] || [ -e "$DEST_ABS/secrets.txt" ]; then
  echo "TU CHOI: da co release.jks/secrets.txt trong $DEST_ABS (khong ghi de khoa cu)." >&2; exit 2
fi
umask 077
chmod 700 "$DEST_ABS"
PASS="$(openssl rand -base64 36 | tr -d '/+=\n' | cut -c1-32)"
ALIAS="wppocket-release"
keytool -genkeypair -v -keystore "$DEST_ABS/release.jks" -storetype PKCS12 -alias "$ALIAS" -keyalg RSA -keysize 4096 -validity 10950 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=$OWNER, O=$OWNER" >/dev/null 2>&1
chmod 600 "$DEST_ABS/release.jks"
base64 < "$DEST_ABS/release.jks" | tr -d '\n' > "$DEST_ABS/release.jks.b64"
chmod 600 "$DEST_ABS/release.jks.b64"
FP="$(keytool -list -v -keystore "$DEST_ABS/release.jks" -storepass "$PASS" -alias "$ALIAS" 2>/dev/null | sed -n 's/^ *SHA256: *//p' | head -n1)"
{
  echo "# GitHub: Settings > Secrets and variables > Actions > New repository secret. Dan DUNG 4 gia tri sau (ten bi-mat = truoc dau '=')."
  echo "RELEASE_KEYSTORE_B64=$(cat "$DEST_ABS/release.jks.b64")"
  echo "RELEASE_KEYSTORE_PASSWORD=$PASS"
  echo "RELEASE_KEY_ALIAS=$ALIAS"
  echo "RELEASE_KEY_PASSWORD=$PASS"
  echo "# Dau van tay chung chi (SHA-256) - ghi lai de doi chieu voi APK da ky: $FP"
} > "$DEST_ABS/secrets.txt"
chmod 600 "$DEST_ABS/secrets.txt"
echo "Da tao khoa trong: $DEST_ABS"
echo "  release.jks     (khoa - SAO LUU OFFLINE)"
echo "  secrets.txt     (4 gia tri dan vao GitHub Secrets; xoa/giu kin sau khi dan)"
echo "Dau van tay SHA-256 cua chung chi: $FP"
echo "Buoc tiep: docs/RELEASE_SIGNING.md (them 4 secret, day tag vX.Y.Z)."
