#!/bin/sh
# loadtest.sh - do TRAN CHIU TAI cua website tren dien thoai (HANDOFF.md muc 1ay, de xuat DeepSeek muc M1)
#
# CHAY TU MAY TINH/DIEN THOAI KHAC cung mang LAN, KHONG chay tren chinh dien thoai server (se tranh tai cua chinh no).
#   sh scripts/tools/loadtest.sh http://192.168.1.50:8080/ [so_request_moi_muc=300] [muc_dong_thoi="1 5 10 20 40"]
# Can `ab` (ApacheBench: apt install apache2-utils / brew install httpd). Moi muc chay [so_request] request voi N ket noi
# dong thoi roi in 1 dong: req/s, do tre trung vi p50 / p95 / p99 (ms), so request LOI.
#
# CACH DOC KET QUA:
#  - req/s tang theo so ket noi roi PHANG hoac GIAM = "goi" chiu tai (thuong la pm.max_children cua php-fpm hoac CPU).
#    Muc dong thoi o do req/s dat dinh la so khach DONG THOI toi da ma khong tre them.
#  - p95/p99 tang vot trong khi req/s khong tang = hang doi (php-fpm het worker) -> khach cho lau.
#  - LOI > 0 (non-2xx / failed) = may bat dau tu choi/het bo nho/het worker: DAY la tran that.
#  - May NONG len se TU GIAM XUNG (thermal throttle) -> chay NGAN (mac dinh 300 request/muc), de nguoi 10-20 giay giua cac lan
#    do; do lai nhieu lan o cac thoi diem khac nhau (pin day/pin yeu, dang sac/khong sac).
#  - Do ca trang CHU (WordPress that, nhieu truy van DB) va 1 trang tinh (vd /wp-includes/images/w-logo-blue.png) de
#    thay phan chi phi PHP/DB vs phan nginx.
#  - Qua Cloudflare Tunnel (URL cong khai) do them do tre mang va co the bi gioi han toc do cua Cloudflare - de do suc chiu tai
#    cua MAY, hay do thang theo IP LAN.
URL="$1"; REQS="${2:-300}"; LEVELS="${3:-1 5 10 20 40}"
[ -n "$URL" ] || { sed -n '2,24p' "$0" | sed 's/^# \{0,1\}//'; exit 2; }
command -v ab >/dev/null 2>&1 || { echo "LOI: can 'ab' (ApacheBench). Cai: apt install apache2-utils | brew install httpd" >&2; exit 2; }
case "$URL" in http://*|https://*) ;; *) echo "LOI: URL phai bat dau bang http:// hoac https://" >&2; exit 2 ;; esac
# ab can URL co duong dan ("/") - them neu thieu
case "$URL" in *://*/*) ;; *) URL="$URL/" ;; esac
PAUSE="${LOADTEST_PAUSE:-10}"   # nghi giua cac muc de may nguoi (chong thermal throttle lam lech so do)
TMP="$(mktemp)"; trap 'rm -f "$TMP"' EXIT INT TERM
printf '%-6s %9s %8s %8s %8s %7s %7s\n' "dong" "req/s" "p50ms" "p95ms" "p99ms" "loi" "non2xx"
BAD=0
for C in $LEVELS; do
  [ "$C" -gt "$REQS" ] && continue            # ab yeu cau -c <= -n
  ab -q -n "$REQS" -c "$C" "$URL" > "$TMP" 2>&1 || { echo "LOI: ab that bai o muc $C: $(tail -1 "$TMP")" >&2; BAD=1; continue; }
  RPS=$(sed -n 's/^Requests per second: *\([0-9.]*\).*/\1/p' "$TMP")
  P50=$(sed -n 's/^ *50% *\([0-9]*\).*/\1/p' "$TMP"); P95=$(sed -n 's/^ *95% *\([0-9]*\).*/\1/p' "$TMP"); P99=$(sed -n 's/^ *99% *\([0-9]*\).*/\1/p' "$TMP")
  FAILED=$(sed -n 's/^Failed requests: *\([0-9]*\).*/\1/p' "$TMP")
  NON2=$(sed -n 's/^Non-2xx responses: *\([0-9]*\).*/\1/p' "$TMP"); NON2="${NON2:-0}"
  printf '%-6s %9s %8s %8s %8s %7s %7s\n' "$C" "${RPS:-?}" "${P50:-?}" "${P95:-?}" "${P99:-?}" "${FAILED:-?}" "$NON2"
  [ "${FAILED:-0}" -gt 0 ] 2>/dev/null && BAD=1
  [ "$NON2" -gt 0 ] && BAD=1
  sleep "$PAUSE"
done
[ "$BAD" = 0 ] || echo "(co request LOI o it nhat 1 muc - xem cot 'loi'/'non2xx': day la tran chiu tai cua may)"
exit $BAD
