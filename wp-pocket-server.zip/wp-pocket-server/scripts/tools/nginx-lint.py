#!/usr/bin/env python3
"""Kiem CU PHAP nhe cho nginx.conf.template khi KHONG co nginx that (vd sandbox khong co mang).
KHONG thay the `nginx -t` (khong biet ngu nghia, khong biet module); chi bat 3 loi hay gap nhat khi sua tay:
  1) quen dau ';' cuoi lenh      2) lech cap ngoac { }      3) dau nhay ' hoac " khong dong.
  4) THIEU ';' GIUA HAI LENH LIEN NHAU (bi gop thanh 1 lenh hop le ve cu phap): bat bang cach canh bao khi mot DONG TIEP THEO
     cua cung 1 lenh lai bat dau bang ten lenh da xuat hien o dau lenh khac trong file (vd add_header, location, fastcgi_param).
Cach dung: python3 scripts/tools/nginx-lint.py [duong_dan]   (mac dinh: scripts/runtimes/templates/nginx.conf.template)
Thoat 0 = sach, 1 = co loi (in dong). CI van chay `nginx -t` that; day chi la luoi an toan truoc do."""
import re, sys

def lint(text, dirs=None):
    # placeholder DUNG MOT MINH tren 1 dong (vd __CF_REALIP_DIRECTIVES__) la khoi lenh -> bo trong; placeholder trong dong -> 'X'
    text = re.sub(r'(?m)^[ \t]*__[A-Z0-9_]+__[ \t]*$', '', text)
    text = re.sub(r'__[A-Z0-9_]+__', 'X', text)
    errs, depth, buf, line, i, n = [], 0, '', 1, 0, len(text)
    stmt_line, first_words, new_line = 1, set(), False
    while i < n:
        c = text[i]
        if c == '\n':
            line += 1
            new_line = buf.strip() != ''
        elif new_line and not c.isspace() and c not in '#{};\'"':
            m = re.match(r'[A-Za-z_][A-Za-z0-9_]*(?=[\s;(])', text[i:])
            if m and dirs and m.group(0) in dirs:
                errs.append((line, 'dong bat dau bang lenh "%s" nhung lenh truoc (dong %d) chua co ";"' % (m.group(0), stmt_line)))
            new_line = False
        if c == '#' and buf.strip() == '' or (c == '#' and (i == 0 or text[i-1] in ' \t\n;{}')):
            while i < n and text[i] != '\n': i += 1
            continue
        if c in '\'"':
            q, start = c, line
            buf += c; i += 1
            while i < n and text[i] != q:
                if text[i] == '\\' and i + 1 < n:
                    buf += text[i]; i += 1
                if text[i] == '\n': line += 1
                buf += text[i]; i += 1
            if i >= n: errs.append((start, 'dau nhay %s khong dong' % q)); break
            buf += q; i += 1
            continue
        if c == '{':
            if buf.strip() == '': errs.append((line, "'{' khong thuoc lenh nao"))
            depth += 1; buf = ''
        elif c == '}':
            if buf.strip() != '': errs.append((stmt_line, 'thieu ";" truoc "}": ' + buf.strip()[:70]))
            depth -= 1; buf = ''
            if depth < 0: errs.append((line, "thua '}'")); depth = 0
        elif c == ';':
            buf = ''
        else:
            if buf.strip() == '' and not c.isspace():
                stmt_line = line
                m0 = re.match(r'[A-Za-z_][A-Za-z0-9_]*(?=[\s;(])', text[i:])
                if m0: first_words.add(m0.group(0))
            buf += c
        i += 1
    if buf.strip() != '': errs.append((stmt_line, 'lenh cuoi file thieu ";": ' + buf.strip()[:70]))
    if depth != 0: errs.append((line, 'lech ngoac: %d "{" chua dong' % depth))
    return errs if dirs is not None else first_words

def lint_all(text):
    return lint(text, dirs=lint(text))

if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else 'scripts/runtimes/templates/nginx.conf.template'
    errs = lint_all(open(path, encoding='utf-8').read())
    for ln, msg in errs: print('%s:%d: %s' % (path, ln, msg))
    print('nginx-lint: %s' % ('SACH' if not errs else '%d LOI' % len(errs)))
    sys.exit(1 if errs else 0)
