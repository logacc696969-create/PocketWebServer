#!/usr/bin/env bash
# In (hoặc --write: ghi đè) phiên bản + SHA-256 MỚI NHẤT cho Adminer và Tiny File Manager trong scripts/lib/pins.env.
# HANDOFF.md mục 1bc. KHÔNG tự chạy trong CI: nâng cấp công cụ bên thứ ba phải có người duyệt.
#
# Quy trình nâng cấp:
#   1. bash scripts/tools/update_pins.sh            # xem bản mới + hash (không ghi gì)
#   2. bash scripts/tools/update_pins.sh --write    # ghi vào pins.env
#   3. python3 scripts/tests/admin-thirdparty-test.py   # kiểm cổng bảo vệ _admin/ trên ĐÚNG bản mới (tải thật)
#   4. python3 scripts/tests/supply-chain-test.py        # pins.env khớp file thật
#   5. đọc ghi chú phát hành của 2 dự án rồi mới commit
# Tìm bản mới qua chuyển hướng của github.com/<repo>/releases/latest (không dùng API: giới hạn 60 yêu cầu/giờ/IP).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PINS="$HERE/../lib/pins.env"
WRITE=0; [[ "${1:-}" == "--write" ]] && WRITE=1

latest_tag() { # <owner/repo>
  local loc
  loc="$(curl -sSI --max-time 30 --retry 2 "https://github.com/$1/releases/latest" | tr -d '\r' | awk 'tolower($1)=="location:"{print $2}' | tail -n1)"
  [[ -n "$loc" ]] || { echo "khong xac dinh duoc ban moi nhat cua $1" >&2; exit 1; }
  echo "${loc##*/}"
}
sha_of_url() { curl -fsSL --max-time 120 --retry 2 "$1" | sha256sum | awk '{print $1}'; }

AD_TAG="$(latest_tag vrana/adminer)"; AD_VER="${AD_TAG#v}"
AD_URL="https://github.com/vrana/adminer/releases/download/${AD_TAG}/adminer-${AD_VER}.php"
AD_SHA="$(sha_of_url "$AD_URL")"

TF_VER="$(latest_tag prasathmani/tinyfilemanager)"
TF_URL="https://raw.githubusercontent.com/prasathmani/tinyfilemanager/${TF_VER}/tinyfilemanager.php"
TF_SHA="$(sha_of_url "$TF_URL")"

echo "Adminer           : $AD_VER  sha256=$AD_SHA"
echo "Tiny File Manager : $TF_VER  sha256=$TF_SHA"
[[ ${#AD_SHA} -eq 64 && ${#TF_SHA} -eq 64 ]] || { echo "hash khong hop le" >&2; exit 1; }

if [[ $WRITE -eq 1 ]]; then
  sed -i -E "s/^ADMINER_VERSION=.*/ADMINER_VERSION=${AD_VER}/; s/^ADMINER_SHA256=.*/ADMINER_SHA256=${AD_SHA}/; s/^TFM_VERSION=.*/TFM_VERSION=${TF_VER}/; s/^TFM_SHA256=.*/TFM_SHA256=${TF_SHA}/" "$PINS"
  echo "Da ghi $PINS - hay chay buoc 3-5 o dau file truoc khi commit."
else
  echo "(chi xem; them --write de ghi vao scripts/lib/pins.env)"
fi
