#!/usr/bin/env python3
"""Kiem tra ngoac/chuoi SO BO cho PHP va Kotlin khi KHONG co php / kotlinc (vd sandbox khong mang).

KHONG thay `php -l` / kotlinc (CI van chay cac cong cu that). Bo quet tu viet (khong dung thu vien): bo qua chuoi, chu thich,
heredoc/nowdoc (PHP), chuoi tho \"\"\" va mau ${...} long nhau (Kotlin); bao:
  - dong/mo ngoac () [] {} khong khop nhau,
  - chuoi / chu thich khoi / heredoc khong dong,
  - PHP: file bat dau bang `<?php` ma thieu `?>`/ket thuc hop le thi KHONG bao (hop le), HTML sau `?>` duoc bo qua.
Dung: python3 scripts/tools/lex-check.py <file|thu muc> ...   (exit 1 neu co loi)
"""
import os, re, sys

PAIR = {')': '(', ']': '[', '}': '{'}


def scan_php(src):
    errs, stack = [], []
    i, n, line = 0, len(src), 1
    in_php = False

    def err(msg):
        errs.append((line, msg))

    while i < n:
        c = src[i]
        if not in_php:
            j = src.find('<?', i)
            if j < 0:
                break
            line += src.count('\n', i, j)
            if src.startswith('<?php', j):
                i = j + 5
            elif src.startswith('<?=', j):
                i = j + 3
            else:
                i = j + 2
            in_php = True
            continue
        if c == '\n':
            line += 1; i += 1; continue
        if src.startswith('?>', i):
            in_php = False; i += 2; continue
        if c == '#' and not src.startswith('#[', i) or src.startswith('//', i):
            j = src.find('\n', i)
            k = src.find('?>', i)
            end = n if j < 0 else j
            if 0 <= k < end:
                end = k
            i = end; continue
        if src.startswith('/*', i):
            j = src.find('*/', i + 2)
            if j < 0:
                err('chu thich /* khong dong'); break
            line += src.count('\n', i, j); i = j + 2; continue
        if src.startswith('<<<', i):
            m = re.match(r"<<<[ \t]*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\1[ \t]*\n", src[i:])
            if m:
                label = m.group(2)
                body_start = i + m.end()
                m2 = re.compile(r'^[ \t]*' + label + r'\b', re.M).search(src, body_start)
                if not m2:
                    err('heredoc/nowdoc %s khong dong' % label); break
                line += src.count('\n', i, m2.end()); i = m2.end(); continue
        if c in ("'", '"', '`'):
            j = i + 1
            while j < n:
                if src[j] == '\\':
                    j += 2; continue
                if src[j] == c:
                    break
                j += 1
            else:
                err('chuoi %s khong dong' % c); break
            line += src.count('\n', i, j); i = j + 1; continue
        if c in '([{':
            stack.append((c, line))
        elif c in PAIR:
            if not stack or stack[-1][0] != PAIR[c]:
                err("dong ngoac '%s' khong khop" % c)
            else:
                stack.pop()
        i += 1
    for ch, ln in stack:
        errs.append((ln, "mo ngoac '%s' khong duoc dong" % ch))
    return errs


def scan_kotlin(src):
    errs, stack = [], []   # stack: ('(', line) | ('${', line) cho mau chuoi
    i, n, line = 0, len(src), 1

    def err(msg):
        errs.append((line, msg))

    def read_string(i, raw):
        """Doc than chuoi bat dau SAU dau nhay mo; tra ve (chi so sau dau dong) hoac None; xu ly ${...} de quy."""
        nonlocal line
        while i < n:
            c = src[i]
            if c == '\n':
                if not raw:
                    err('chuoi thuong bi xuong dong'); return None
                line += 1; i += 1; continue
            if not raw and c == '\\':
                i += 2; continue
            if raw and src.startswith('"""', i):
                while src.startswith('""""', i):
                    i += 1
                return i + 3
            if not raw and c == '"':
                return i + 1
            if c == '$' and i + 1 < n and src[i + 1] == '{':
                depth, j = 1, i + 2
                i = scan_code(j, depth)
                if i is None:
                    return None
                continue
            i += 1
        err('chuoi khong dong'); return None

    def scan_code(i, depth):
        """Quet ma Kotlin den khi dong het `depth` ngoac { cua mau; depth=0 => quet toan file."""
        nonlocal line
        local = []
        while i < n:
            c = src[i]
            if c == '\n':
                line += 1; i += 1; continue
            if src.startswith('//', i):
                j = src.find('\n', i); i = n if j < 0 else j; continue
            if src.startswith('/*', i):
                d, j = 1, i + 2
                while j < n and d:
                    if src.startswith('/*', j): d += 1; j += 2
                    elif src.startswith('*/', j): d -= 1; j += 2
                    else:
                        if src[j] == '\n': line += 1
                        j += 1
                if d:
                    err('chu thich /* khong dong'); return None
                i = j; continue
            if src.startswith('"""', i):
                i = read_string(i + 3, True)
                if i is None: return None
                continue
            if c == '"':
                i = read_string(i + 1, False)
                if i is None: return None
                continue
            if c == "'":
                j = i + 1
                if j < n and src[j] == '\\':
                    j += 2
                    while j < n and src[j] != "'" and src[j] != '\n': j += 1
                else:
                    j += 1
                if j < n and src[j] == "'":
                    i = j + 1; continue
                i += 1; continue
            if c in '([{':
                local.append((c, line))
            elif c in PAIR:
                if not local:
                    if c == '}' and depth > 0:
                        return i + 1        # het mau ${...}
                    err("dong ngoac '%s' khong khop" % c)
                elif local[-1][0] != PAIR[c]:
                    err("dong ngoac '%s' khong khop (mo '%s' dong %d)" % (c, local[-1][0], local[-1][1])); local.pop()
                else:
                    local.pop()
            i += 1
        for ch, ln in local:
            errs.append((ln, "mo ngoac '%s' khong duoc dong" % ch))
        return n

    scan_code(0, 0)
    return errs


def check(path):
    src = open(path, encoding='utf8').read()
    return scan_php(src) if path.endswith('.php') else scan_kotlin(src)


def files(args):
    for a in args:
        if os.path.isdir(a):
            for r, _, fs in os.walk(a):
                for f in sorted(fs):
                    if f.endswith(('.php', '.kt')):
                        yield os.path.join(r, f)
        else:
            yield a


def main():
    bad = 0
    for f in files(sys.argv[1:] or ['.']):
        for ln, m in check(f)[:10]:
            print('%s:%d: %s' % (f, ln, m)); bad += 1
    print('lex-check: %s' % ('SACH' if not bad else '%d van de' % bad))
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
