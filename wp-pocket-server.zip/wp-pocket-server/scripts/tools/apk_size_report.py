#!/usr/bin/env python3
"""Bao cao THANH PHAN cua APK (HANDOFF.md muc 1br-H): cai gi chiem dung luong, cai gi lap lai, .so co duoc nen khong.

Dung:  python3 scripts/tools/apk_size_report.py app/build/outputs/apk/debug/*.apk
       python3 scripts/tools/apk_size_report.py artifact.zip          # zip tai tu GitHub Actions (chua cac .apk) cung doc duoc
       them  --top 30  --json  --estimate (nen thu cac .so dang luu khong nen de uoc luong muc co the giam)

Chi doc (khong ghi, khong cai gi). Doc muc luc zip cua APK nen nhanh; --estimate moi doc noi dung (cham hon).
Nhom: lib/<abi>/*.so, assets/, classes*.dex, res + resources.arsc, khac. "Luu (stored)" = khong nen trong APK; "Nen (deflated)" = da nen.
"Lap lai trong APK" = nhieu muc CUNG noi dung (CRC32 + kich thuoc) duoi ten khac nhau. "Lap giua cac APK" = muc co cung ten + noi dung o >= 2 APK
(vd APK universal chua lai y het lib/ cua APK arm64 va armeabi-v7a) - day la ly do thu muc artifact CI nang gap doi.
"""
import argparse, collections, io, json, os, sys, zipfile, zlib


def category(name):
    if name.startswith('lib/'):
        parts = name.split('/')
        return 'lib/' + parts[1] if len(parts) > 2 else 'lib/?'
    if name.startswith('assets/'):
        return 'assets'
    if name.startswith('classes') and name.endswith('.dex'):
        return 'dex'
    if name.startswith('res/') or name == 'resources.arsc':
        return 'res'
    if name.startswith('META-INF/'):
        return 'META-INF'
    return 'khac'


def human(n):
    for u in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or u == 'GB':
            return ('%d %s' % (n, u)) if u == 'B' else ('%.1f %s' % (n, u))
        n /= 1024.0


def open_apks(path):
    """[(ten, ZipFile, kich thuoc tep)] - APK truc tiep, hoac cac .apk ben trong 1 zip (artifact CI)."""
    size = os.path.getsize(path)
    z = zipfile.ZipFile(path)
    inner = [i for i in z.infolist() if i.filename.lower().endswith('.apk')]
    if inner and not any(i.filename in ('AndroidManifest.xml', 'classes.dex') for i in z.infolist()):
        out = []
        for i in inner:
            out.append((os.path.basename(i.filename), zipfile.ZipFile(io.BytesIO(z.read(i))), i.file_size))
        return out
    return [(os.path.basename(path), z, size)]


def analyze(name, z, filesize, estimate=False, top=15):
    infos = [i for i in z.infolist() if not i.is_dir()]
    cats = collections.OrderedDict()
    for i in infos:
        c = cats.setdefault(category(i.filename), {'n': 0, 'raw': 0, 'zip': 0, 'stored': 0, 'deflated': 0})
        c['n'] += 1
        c['raw'] += i.file_size
        c['zip'] += i.compress_size
        c['stored' if i.compress_type == zipfile.ZIP_STORED else 'deflated'] += 1
    by_key = collections.defaultdict(list)
    for i in infos:
        if i.file_size >= 4096:
            by_key[(i.CRC, i.file_size)].append(i)
    dups = []
    for k, v in by_key.items():
        if len(v) > 1:
            dups.append({'names': [x.filename for x in v], 'size': v[0].file_size, 'wasted_zip': sum(x.compress_size for x in v[1:])})
    dups.sort(key=lambda d: -d['wasted_zip'])
    big = sorted(infos, key=lambda i: -i.compress_size)[:top]
    rep = {'apk': name, 'file_size': filesize, 'entries': len(infos), 'categories': cats,
           'top': [{'name': i.filename, 'zip': i.compress_size, 'raw': i.file_size, 'method': 'stored' if i.compress_type == zipfile.ZIP_STORED else 'deflated'} for i in big],
           'dups': dups, 'dup_wasted': sum(d['wasted_zip'] for d in dups)}
    if estimate:
        saving, rows = 0, []
        for i in sorted([x for x in infos if x.filename.endswith('.so') and x.compress_type == zipfile.ZIP_STORED], key=lambda x: -x.file_size)[:40]:
            c = len(zlib.compress(z.read(i), 6))
            saving += max(0, i.compress_size - c)
            rows.append((i.filename, i.file_size, c))
        rep['estimate'] = {'so_stored_count': sum(1 for x in infos if x.filename.endswith('.so') and x.compress_type == zipfile.ZIP_STORED), 'saving_if_deflated_top40': saving, 'rows': rows[:10]}
    return rep


def cross(apks):
    """Muc cung ten + noi dung xuat hien o >= 2 APK: tra (tong byte lap [theo kich thuoc nen], chi tiet theo nhom)."""
    seen = {}
    for name, z, _ in apks:
        for i in z.infolist():
            if i.is_dir() or i.file_size < 4096:
                continue
            seen.setdefault((i.filename, i.CRC, i.file_size), []).append((name, i.compress_size))
    total, by_cat = 0, collections.Counter()
    for (fn, _, _), v in seen.items():
        if len(v) > 1:
            w = sum(cs for _, cs in v[1:])
            total += w
            by_cat[category(fn)] += w
    return total, dict(by_cat)


def render(rep, top):
    L = ['', '== %s: %s (%d muc) ==' % (rep['apk'], human(rep['file_size']), rep['entries']),
         '%-18s %6s %12s %12s %8s %9s' % ('nhom', 'muc', 'goc', 'trong APK', 'luu', 'nen')]
    for c, v in sorted(rep['categories'].items(), key=lambda kv: -kv[1]['zip']):
        L.append('%-18s %6d %12s %12s %8d %9d' % (c, v['n'], human(v['raw']), human(v['zip']), v['stored'], v['deflated']))
    L.append('-- %d muc lon nhat (theo dung luong trong APK):' % len(rep['top'][:top]))
    for t in rep['top'][:top]:
        L.append('   %10s (goc %10s, %-8s) %s' % (human(t['zip']), human(t['raw']), t['method'], t['name']))
    if rep['dups']:
        L.append('-- LAP LAI trong APK (cung noi dung, ten khac): tiet kiem duoc %s' % human(rep['dup_wasted']))
        for d in rep['dups'][:8]:
            L.append('   %10s x%d: %s' % (human(d['size']), len(d['names']), ' = '.join(d['names'])[:200]))
    else:
        L.append('-- khong co muc lap lai trong APK (>= 4 KB cung noi dung)')
    e = rep.get('estimate')
    if e:
        L.append('-- %d tep .so dang LUU KHONG NEN; neu nen (deflate) tiet kiem uoc tinh %s (chi tinh 40 tep lon nhat):' % (e['so_stored_count'], human(e['saving_if_deflated_top40'])))
        for n, raw, c in e['rows']:
            L.append('   %10s -> %10s  %s' % (human(raw), human(c), n))
    return L


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('paths', nargs='+')
    ap.add_argument('--top', type=int, default=15)
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--estimate', action='store_true')
    a = ap.parse_args(argv)
    apks = []
    for p in a.paths:
        apks += open_apks(p)
    reps = [analyze(n, z, fs, a.estimate, a.top) for n, z, fs in apks]
    total = sum(fs for _, _, fs in apks)
    cr_total, cr_cat = cross(apks) if len(apks) > 1 else (0, {})
    if a.json:
        print(json.dumps({'apks': reps, 'total': total, 'cross_apk_duplicate': cr_total, 'cross_by_category': cr_cat}, ensure_ascii=False, indent=1))
        return 0
    out = ['TONG %d APK: %s' % (len(apks), human(total))]
    for r in reps:
        out += render(r, a.top)
    if len(apks) > 1:
        out += ['', '== LAP GIUA CAC APK (cung ten + cung noi dung o >= 2 APK): %s ==' % human(cr_total)]
        for c, w in sorted(cr_cat.items(), key=lambda kv: -kv[1]):
            out.append('   %-18s %s' % (c, human(w)))
        out.append('   (APK "universal" chua lai y het cac APK theo ABI; chi can tai/cai 1 APK dung ABI cua may)')
    print('\n'.join(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
