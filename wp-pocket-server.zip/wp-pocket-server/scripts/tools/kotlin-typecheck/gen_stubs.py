#!/usr/bin/env python3
"""Sinh R + ActivityMainBinding tu layout/strings THAT cua cay ma nguon (HANDOFF.md muc 1az), de kotlinc
kiem kieu MainActivity ma khong can Android SDK/Gradle: moi R.string.x / binding.x sai ten hoac sai kieu
se bi bat. Dung qua run.sh: gen_stubs.py <app/src/main> <outdir>"""
import re, sys, os, xml.etree.ElementTree as ET
root, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
res = os.path.join(root, "res")
# ---- R
cats = {"string": set(), "id": set(), "layout": set(), "drawable": set(), "color": set(), "xml": set(), "mipmap": set(), "style": set(), "array": set(), "plurals": set(), "dimen": set()}
for fn in os.listdir(os.path.join(res, "values")):
    if fn.endswith(".xml"):
        for el in ET.parse(os.path.join(res, "values", fn)).getroot():
            n = el.get("name")
            if not n: continue
            t = el.tag if el.tag in cats else None
            if el.tag == "string-array": t = "array"
            if t: cats[t].add(n.replace(".", "_"))
ids = {}
for fn in os.listdir(os.path.join(res, "layout")):
    cats["layout"].add(fn[:-4])
    txt = open(os.path.join(res, "layout", fn), encoding="utf-8").read()
    for m in re.finditer(r"<([\w.]+)\s[^>]*?android:id=\"@\+id/(\w+)\"", txt, re.S):
        cats["id"].add(m.group(2))
        if fn == "activity_main.xml": ids[m.group(2)] = m.group(1)
for d in ("drawable", "mipmap", "xml"):
    p = os.path.join(res, d)
    if os.path.isdir(p):
        for fn in os.listdir(p): cats[d].add(fn.rsplit(".", 1)[0])
with open(os.path.join(out, "R.kt"), "w") as f:
    f.write("package com.wppocket.server\nobject R {\n")
    for c, names in cats.items():
        f.write(f"  object {c} {{\n")
        for n in sorted(names): f.write(f"    const val {n}: Int = 0\n")
        f.write("  }\n")
    f.write("}\n")
# ---- binding
tmap = {"Button": "android.widget.Button", "Switch": "android.widget.Switch", "EditText": "android.widget.EditText", "TextView": "android.widget.TextView",
        "RadioGroup": "android.widget.RadioGroup", "RadioButton": "android.widget.RadioButton", "ScrollView": "android.widget.ScrollView",
        "LinearLayout": "android.widget.LinearLayout", "ProgressBar": "android.widget.ProgressBar", "ImageView": "android.widget.ImageView",
        "CheckBox": "android.widget.CheckBox", "SwitchCompat": "android.widget.Switch", "SwitchMaterial": "android.widget.Switch", "MaterialButton": "android.widget.Button", "TextInputEditText": "android.widget.EditText", "Spinner": "android.widget.Spinner", "Space": "android.view.View", "View": "android.view.View"}
os.makedirs(os.path.join(out, "binding"), exist_ok=True)
with open(os.path.join(out, "binding", "ActivityMainBinding.kt"), "w") as f:
    f.write("package com.wppocket.server.databinding\nclass ActivityMainBinding {\n  val root: android.view.View = TODO()\n")
    for n, tag in sorted(ids.items()):
        cam = n  # viewBinding: id camelCase da la camelCase trong du an nay
        f.write(f"  val {cam}: {tmap.get(tag.split('.')[-1], 'android.view.View')} = TODO()\n")
    f.write("  companion object { fun inflate(i: android.view.LayoutInflater): ActivityMainBinding = TODO() }\n}\n")
