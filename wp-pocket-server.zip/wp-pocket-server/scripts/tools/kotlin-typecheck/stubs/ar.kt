package androidx.activity.result
class ActivityResult(val resultCode: Int, val data: android.content.Intent?)
fun interface ActivityResultCallback<O> { fun onActivityResult(result: O) }
abstract class ActivityResultLauncher<I> { abstract fun launch(input: I) }
