package androidx.core.content
object ContextCompat {
    fun checkSelfPermission(c: android.content.Context, p: String): Int = 0
    fun startForegroundService(c: android.content.Context, i: android.content.Intent) {}
    fun getColor(c: android.content.Context, id: Int): Int = 0
}
