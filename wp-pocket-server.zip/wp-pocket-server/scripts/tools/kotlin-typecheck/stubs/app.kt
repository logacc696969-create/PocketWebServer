package androidx.appcompat.app
open class AppCompatActivity : android.app.Activity() {
    fun <I, O> registerForActivityResult(contract: androidx.activity.result.contract.ActivityResultContract<I, O>,
        callback: androidx.activity.result.ActivityResultCallback<O>): androidx.activity.result.ActivityResultLauncher<I> = TODO()
    override fun onCreate(savedInstanceState: android.os.Bundle?) { super.onCreate(savedInstanceState) }
}
class AlertDialog {
    class Builder(ctx: android.content.Context) {
        fun setTitle(t: Int): Builder = this
        fun setTitle(t: CharSequence?): Builder = this
        fun setMessage(m: Int): Builder = this
        fun setMessage(m: CharSequence?): Builder = this
        fun setView(v: android.view.View): Builder = this
        fun setItems(items: Array<out CharSequence>, l: android.content.DialogInterface.OnClickListener?): Builder = this
        fun setPositiveButton(t: Int, l: android.content.DialogInterface.OnClickListener?): Builder = this
        fun setPositiveButton(t: CharSequence?, l: android.content.DialogInterface.OnClickListener?): Builder = this
        fun setNegativeButton(t: Int, l: android.content.DialogInterface.OnClickListener?): Builder = this
        fun setNegativeButton(t: CharSequence?, l: android.content.DialogInterface.OnClickListener?): Builder = this
        fun setNeutralButton(t: Int, l: android.content.DialogInterface.OnClickListener?): Builder = this
        fun setOnCancelListener(l: android.content.DialogInterface.OnCancelListener?): Builder = this
        fun setCancelable(b: Boolean): Builder = this
        fun setOnDismissListener(l: android.content.DialogInterface.OnDismissListener?): Builder = this
        fun create(): AlertDialog = AlertDialog()
        fun show(): AlertDialog = AlertDialog()
    }
}
