#!/bin/bash
# Kiem KIEU toan bo Kotlin cua app ma KHONG can Android SDK/Gradle (HANDOFF.md muc 1az).
# Can: kotlinc, python3, android.jar (API 34): ANDROID_JAR=/duong/dan/android.jar hoac
# $ANDROID_HOME/platforms/android-34/android.jar.
# Cach lam: sinh R + ActivityMainBinding tu res/ THAT, them stub androidx toi thieu (stubs/), roi
# bien dich. Cac file phu thuoc WorkManager/NotificationCompat/ViewBinding khac van loi vi KHONG co
# stub (danh sach ALLOW ben duoi) - bat ky loi nao O FILE KHAC la that bai. Gioi han: day la kiem
# KIEU, khong chay duoc app; khong thay the build Gradle that.
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="${1:-$HERE/../../../app/src/main}"
JAR="${ANDROID_JAR:-${ANDROID_HOME:-/nonexistent}/platforms/android-34/android.jar}"
[ -f "$JAR" ] || { echo "Thieu android.jar (dat ANDROID_JAR=...)"; exit 2; }
command -v kotlinc >/dev/null || { echo "Thieu kotlinc"; exit 2; }
ALLOW="BackupWorker.kt TelegramCommandWorker.kt HealthCheckWorker.kt LogViewerActivity.kt ServerForegroundService.kt"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
python3 "$HERE/gen_stubs.py" "$SRC" "$OUT/gen" || exit 2
kotlinc -nowarn -cp "$JAR" "$SRC"/java/com/wppocket/server/*.kt "$HERE"/stubs/*.kt "$OUT/gen/R.kt" "$OUT/gen"/binding/*.kt -d "$OUT/cls" > "$OUT/log" 2>&1
total=$(grep -c 'error:' "$OUT/log")
bad=0
for f in $(grep 'error:' "$OUT/log" | sed -E 's#^.*/([A-Za-z]+\.kt):.*#\1#' | sort -u); do
  case " $ALLOW " in *" $f "*) continue ;; esac
  echo "LOI KIEU o $f:"; grep "$f.*error:" "$OUT/log" | sed -E 's#^.*/([A-Za-z]+\.kt:[0-9]+):[0-9]+: error: #   \1 #' | head -8
  bad=1
done
echo "(tong $total loi; cac file trong danh sach ALLOW thieu stub WorkManager/NotificationCompat nen bo qua)"
[ "$bad" = 0 ] && echo "TONG KET: kiem kieu OK - khong co loi o cac file con lai" || exit 1
