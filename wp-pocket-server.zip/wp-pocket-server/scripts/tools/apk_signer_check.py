#!/usr/bin/env python3
"""Kiem tra CHU KY cua APK phat hanh (HANDOFF.md muc 1br-H). CI goi sau khi build ban phat hanh; chay duoc tren may ban.

Dung:  python3 scripts/tools/apk_signer_check.py [--apksigner PATH] [--expect-sha256 DAU_VAN_TAY] [--debug-keystore app/debug.keystore] app-*-release.apk ...
Bao LOI (exit 1) khi: apksigner khong xac minh duoc; khong co chu ky v2/v3; cac APK ky BANG CHUNG CHI KHAC NHAU; hoac chung chi TRUNG voi khoa debug cong khai trong repo
(nghia la secret phat hanh bi dien nham bang khoa debug - ai cung ky gia duoc). In dau van tay SHA-256 de ban doi chieu voi gia tri luc tao khoa.
--expect-sha256 (tuy chon; CI lay tu bien repo RELEASE_CERT_SHA256): neu co, MOI APK phai ky bang dung chung chi nay - phat hien secret bi thay bang khoa khac.
"""
import argparse, glob, os, re, shutil, subprocess, sys


def find_apksigner():
    p = shutil.which('apksigner')
    if p:
        return p
    for root in (os.environ.get('ANDROID_SDK_ROOT'), os.environ.get('ANDROID_HOME'), os.path.expanduser('~/Android/Sdk')):
        if root:
            c = sorted(glob.glob(os.path.join(root, 'build-tools', '*', 'apksigner')), key=lambda x: [int(n) if n.isdigit() else 0 for n in re.split(r'[.\-]', x.split(os.sep)[-2])])
            if c:
                return c[-1]
    return None


def norm(fp):
    return re.sub(r'[^0-9a-f]', '', fp.lower())


def apk_cert(apksigner, apk):
    """(ok, sha256_hex, [loi]) tu `apksigner verify --print-certs -v`."""
    r = subprocess.run([apksigner, 'verify', '--print-certs', '-v', apk], capture_output=True, text=True)
    out = r.stdout + r.stderr
    errs = []
    if r.returncode != 0:
        errs.append('apksigner verify that bai (ma %d): %s' % (r.returncode, out.strip().splitlines()[0] if out.strip() else ''))
    v2 = re.search(r'Verified using v2 scheme[^:]*:\s*true', out, re.I) is not None
    v3 = re.search(r'Verified using v3 scheme[^:]*:\s*true', out, re.I) is not None
    if not (v2 or v3):
        errs.append('khong co chu ky v2/v3 (chi v1 hoac chua ky)')
    m = re.search(r'Signer #1 certificate SHA-256 digest:\s*([0-9a-fA-F]+)', out)
    if not m:
        errs.append('khong doc duoc dau van tay chung chi')
    return (not errs), (norm(m.group(1)) if m else ''), errs


def keystore_fp(keytool, ks, alias, pw):
    r = subprocess.run([keytool, '-list', '-v', '-keystore', ks, '-storepass', pw, '-alias', alias], capture_output=True, text=True)
    m = re.search(r'SHA-?256:\s*([0-9A-Fa-f:]+)', r.stdout + r.stderr)
    return norm(m.group(1)) if m else ''


def pretty(h):
    return ':'.join(h[i:i + 2] for i in range(0, len(h), 2)).upper()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('apks', nargs='+')
    ap.add_argument('--apksigner')
    ap.add_argument('--expect-sha256', default='')
    ap.add_argument('--keytool', default=shutil.which('keytool') or 'keytool')
    ap.add_argument('--debug-keystore', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'app', 'debug.keystore'))
    ap.add_argument('--debug-alias', default='androiddebugkey')
    ap.add_argument('--debug-pass', default='android')
    a = ap.parse_args(argv)
    apksigner = a.apksigner or find_apksigner()
    if not apksigner:
        print('LOI: khong tim thay apksigner (Android SDK build-tools).', file=sys.stderr)
        return 2
    apks = [p for pat in a.apks for p in (glob.glob(pat) or [pat])]
    bad, certs = [], {}
    for apk in apks:
        ok, fp, errs = apk_cert(apksigner, apk)
        print('%s: %s  %s' % (os.path.basename(apk), 'OK' if ok else 'LOI', pretty(fp) if fp else '-'))
        for e in errs:
            bad.append('%s: %s' % (os.path.basename(apk), e))
        if fp:
            certs.setdefault(fp, []).append(os.path.basename(apk))
    if len(certs) > 1:
        bad.append('cac APK ky bang %d chung chi KHAC NHAU: %s' % (len(certs), '; '.join('%s <- %s' % (pretty(k)[:23], ','.join(v)) for k, v in certs.items())))
    dbg = keystore_fp(a.keytool, a.debug_keystore, a.debug_alias, a.debug_pass) if os.path.isfile(a.debug_keystore) else ''
    if dbg and dbg in certs:
        bad.append('APK dang ky bang KHOA DEBUG CONG KHAI cua repo (secret phat hanh sai/thieu?) - khong dung de phat hanh: %s' % ','.join(certs[dbg]))
    exp = norm(a.expect_sha256)
    if a.expect_sha256.strip() and len(exp) != 64:
        bad.append('--expect-sha256 khong phai dau van tay SHA-256 hop le (can 64 ky tu hex, co the cach nhau bang dau :)')
    elif exp:
        for fp, names in certs.items():
            if fp != exp:
                bad.append('chung chi %s (%s) KHAC dau van tay mong doi %s - secret khoa phat hanh co the da bi thay' % (pretty(fp)[:23] + '...', ','.join(names), pretty(exp)[:23] + '...'))
    if bad:
        for b in bad:
            print('LOI: ' + b, file=sys.stderr)
        return 1
    if certs:
        print('Chung chi phat hanh (SHA-256): %s' % pretty(next(iter(certs))))
    return 0


if __name__ == '__main__':
    sys.exit(main())
