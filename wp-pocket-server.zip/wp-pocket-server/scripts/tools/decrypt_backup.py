#!/usr/bin/env python3
"""
Giai ma file backup "backup-*.zip.enc" (do WP Pocket Server tao khi bat tuy
chon "Ma hoa backup truoc khi gui di") thanh file .zip thuong - CHAY TREN MAY
TINH (Windows/Mac/Linux), khong can dien thoai. De xuat DeepSeek muc F6 (xem
HANDOFF.md muc 10).

CACH DUNG:
    pip install cryptography
    python decrypt_backup.py backup-20260927-120000.zip.enc
    (se hoi mat khau - go bi an, khong hien ra man hinh)

    Hoac chi dinh file dau ra:
    python decrypt_backup.py backup-20260927-120000.zip.enc -o khoi-phuc.zip

DINH DANG FILE (phai KHOP CHINH XAC voi BackupManager.encryptBackupFile() trong
app Android - da kiem chung cheo bang file do Kotlin that tao ra, xem
HANDOFF.md):
    [16 byte salt][12 byte IV/nonce][ciphertext + 16 byte GCM tag]
    Khoa AES-256 duoc "derive" tu mat khau qua PBKDF2-HMAC-SHA256, salt o tren,
    100,000 vong lap. Ma hoa: AES-256-GCM (co xac thuc - sai mat khau/file bi
    sua se bi phat hien, khong bao gio ra "rac" am tham).

QUEN MAT KHAU = KHONG AI KHOI PHUC DUOC (dung y dinh cua ma hoa that). Khong
co "cua sau" nao, ke ca tac gia du an.
"""
import argparse
import getpass
import sys

try:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
except ImportError:
    sys.exit("Thieu thu vien 'cryptography'. Cai bang: pip install cryptography")

SALT_LEN = 16
IV_LEN = 12
PBKDF2_ITERATIONS = 100_000  # PHAI khop BackupManager.kt
KEY_LEN = 32  # AES-256


def decrypt_file(input_path: str, output_path: str, passphrase: str) -> None:
    with open(input_path, "rb") as f:
        data = f.read()

    if len(data) < SALT_LEN + IV_LEN + 16:  # +16 = do dai toi thieu cua GCM tag
        sys.exit("File qua ngan, khong dung dinh dang backup ma hoa cua WP Pocket Server.")

    salt = data[:SALT_LEN]
    iv = data[SALT_LEN : SALT_LEN + IV_LEN]
    ciphertext_and_tag = data[SALT_LEN + IV_LEN :]

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_LEN,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    key = kdf.derive(passphrase.encode("utf-8"))

    try:
        plaintext = AESGCM(key).decrypt(iv, ciphertext_and_tag, None)
    except InvalidTag:
        sys.exit("Giai ma that bai - SAI MAT KHAU hoac file backup bi hong/bi sua.")

    with open(output_path, "wb") as f:
        f.write(plaintext)


def main() -> None:
    parser = argparse.ArgumentParser(description="Giai ma backup WP Pocket Server (.zip.enc -> .zip)")
    parser.add_argument("input", help="File backup da ma hoa (vd backup-20260927-120000.zip.enc)")
    parser.add_argument("-o", "--output", help="File .zip dau ra (mac dinh: bo duoi .enc)")
    args = parser.parse_args()

    output = args.output
    if not output:
        output = args.input[:-4] if args.input.endswith(".enc") else args.input + ".decrypted.zip"

    passphrase = getpass.getpass("Mat khau ma hoa backup: ")
    decrypt_file(args.input, output, passphrase)
    print(f"Da giai ma thanh cong: {output}")


if __name__ == "__main__":
    main()
