#!/usr/bin/env python3
"""WP Pocket Server - may chu WSGI nhe cho runtime Python (PDF 1 muc H2; HANDOFF.md muc 1bq-C).

Thay cho gunicorn/waitress: CHI dung thu vien chuan cua Python (wsgiref, socketserver, signal) nen KHONG them phu thuoc, khong can ma
native va chay duoc voi bo Python Termux da dong goi san. Chay Flask, Django, Bottle, Pyramid... (moi ung dung WSGI, PEP 3333).

    python wpp_wsgi.py module:callable [--port 8080] [--bind 127.0.0.1] [--threads 16] [--max-body 64] [--timeout 30] [--trust-proxy] [--access-log]
    python wpp_wsgi.py app:app                    # Flask: app = Flask(__name__)
    python wpp_wsgi.py mysite.wsgi:application    # Django
    python wpp_wsgi.py app:create_app()           # nha may ung dung (goi ham, khong tham so)
    python wpp_wsgi.py app:app --asgi             # ung dung ASGI (Starlette, FastAPI...) - cau noi ASGI->WSGI, xem AsgiBridge

Thiet ke cho DIEN THOAI (RAM/pin han che):
  * Da luong co GIOI HAN (--threads, mac dinh 16): qua tai -> tra 503 ngay (Retry-After) thay vi tao luong vo han lam can RAM.
  * Chong ket ket noi: moi ket noi co thoi han doc/ghi (--timeout, mac dinh 30 giay) - khach cham/hu khong giu luong mai.
  * Gioi han kich thuoc body (--max-body MB, mac dinh 64) -> 413 TRUOC khi goi ung dung; body chunked -> 411 (nginx phia truoc luon gui Content-Length).
  * wsgi.input bi chan theo Content-Length: ung dung goi .read() khong tham so khong bao gio treo cho den khi khach dong ket noi.
  * --trust-proxy (chi bat khi nginx phia truoc, bind 127.0.0.1): lay IP that tu X-Forwarded-For, scheme tu X-Forwarded-Proto, CHI khi
    ket noi den tu loopback va gia tri hop le. Mac dinh TAT (bind 0.0.0.0 ma tin header = ai cung gia IP duoc).
  * Dung sach: SIGTERM/SIGINT -> ngung nhan ket noi moi, thoat ma 0.
  * --asgi: chay ung dung ASGI 3.0 (HTTP + lifespan) qua cau noi [AsgiBridge]; phan hoi duoc GOM DAY DU roi moi tra (khong streaming/SSE),
    KHONG co WebSocket. Xem docs/PYTHON_WSGI.md.
"""
import argparse
import asyncio
import concurrent.futures
import http
import importlib
import inspect
import ipaddress
import os
import signal
import socket
import socketserver
import sys
import threading
import time
import traceback
import urllib.parse
from wsgiref import simple_server

LOOPBACK = ("127.0.0.1", "::1")
LINGER_MAX_BYTES = 8 * 1024 * 1024
LINGER_MAX_SECONDS = 2.0
_state = threading.local()


class _LimitedInput(object):
    """wsgi.input chi doc toi da Content-Length byte (ung dung goi read() khong tham so van khong treo)."""

    def __init__(self, raw, length):
        self._raw = raw
        self._left = max(0, length)

    def read(self, size=-1):
        if self._left <= 0:
            return b""
        if size is None or size < 0 or size > self._left:
            size = self._left
        data = self._raw.read(size)
        self._left -= len(data)
        return data

    def readline(self, size=-1):
        if self._left <= 0:
            return b""
        lim = self._left if (size is None or size < 0 or size > self._left) else size
        data = self._raw.readline(lim)
        self._left -= len(data)
        return data

    def readlines(self, hint=-1):
        out = []
        while True:
            line = self.readline()
            if not line:
                return out
            out.append(line)

    def __iter__(self):
        return iter(self.readline, b"")


def _plain(start_response, status, text):
    # Tu choi SOM (khong doc body): dong ket noi ngay se gui RST lam khach khong doc duoc phan hoi 4xx -> "lingering close" o shutdown_request.
    _state.linger = True
    body = (text + "\n").encode("utf-8")
    start_response(status, [("Content-Type", "text/plain; charset=utf-8"), ("Content-Length", str(len(body)))])
    return [body]


def guard(app, max_body_bytes, trust_proxy):
    """Lop bao ve ngoai ung dung: kiem tra body, chan wsgi.input, tin header proxy (neu duoc bat)."""

    def wrapped(environ, start_response):
        if "chunked" in environ.get("HTTP_TRANSFER_ENCODING", "").lower():
            return _plain(start_response, "411 Length Required", "Request body must have Content-Length (chunked is not supported)")
        raw_len = environ.get("CONTENT_LENGTH", "") or "0"
        try:
            length = int(raw_len)
            if length < 0:
                raise ValueError
        except ValueError:
            return _plain(start_response, "400 Bad Request", "Invalid Content-Length")
        if length > max_body_bytes:
            return _plain(start_response, "413 Payload Too Large", "Request body too large (limit %d MB)" % (max_body_bytes // (1024 * 1024)))
        environ["wsgi.input"] = _LimitedInput(environ["wsgi.input"], length)
        if trust_proxy and environ.get("REMOTE_ADDR") in LOOPBACK:
            xff = environ.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip()
            if xff:
                try:
                    environ["REMOTE_ADDR"] = str(ipaddress.ip_address(xff))
                except ValueError:
                    pass  # gia tri la -> giu dia chi loopback, khong tin
            proto = environ.get("HTTP_X_FORWARDED_PROTO", "").split(",")[0].strip().lower()
            if proto in ("http", "https"):
                environ["wsgi.url_scheme"] = proto
        return app(environ, start_response)

    return wrapped


class _ServerHandler(simple_server.ServerHandler):
    def cleanup_headers(self):
        simple_server.ServerHandler.cleanup_headers(self)
        # May chu dong ket noi sau moi phan hoi: noi ro de client/nginx khong cho ket noi giu song.
        if "Connection" not in self.headers:
            self.headers["Connection"] = "close"


class _RequestHandler(simple_server.WSGIRequestHandler):
    timeout = 30

    def handle(self):
        # Tuong duong CPython wsgiref.simple_server.WSGIRequestHandler.handle (3.8-3.13), chi doi lop ServerHandler.
        self.raw_requestline = self.rfile.readline(65537)
        if len(self.raw_requestline) > 65536:
            self.requestline = ""
            self.request_version = ""
            self.command = ""
            self.send_error(414)
            return
        if not self.parse_request():
            return
        handler = _ServerHandler(self.rfile, self.wfile, self.get_stderr(), self.get_environ())
        handler.request_handler = self
        handler.run(self.server.get_app())

    def log_message(self, fmt, *args):
        if getattr(self.server, "access_log", False):
            sys.stdout.write("%s - - [%s] %s\n" % (self.client_address[0], self.log_date_time_string(), fmt % args))
            sys.stdout.flush()


class BoundedThreadedServer(socketserver.ThreadingMixIn, simple_server.WSGIServer):
    daemon_threads = True
    request_queue_size = 64
    allow_reuse_address = True

    def __init__(self, server_address, handler_class, max_threads=16):
        self._slots = threading.BoundedSemaphore(max_threads)
        self.access_log = False
        self.rejected = 0
        simple_server.WSGIServer.__init__(self, server_address, handler_class)

    def process_request(self, request, client_address):
        if not self._slots.acquire(False):
            self.rejected += 1
            try:
                request.sendall(b"HTTP/1.1 503 Service Unavailable\r\nRetry-After: 1\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
            except OSError:
                pass
            self.shutdown_request(request)
            return
        socketserver.ThreadingMixIn.process_request(self, request, client_address)

    def process_request_thread(self, request, client_address):
        try:
            socketserver.ThreadingMixIn.process_request_thread(self, request, client_address)
        finally:
            self._slots.release()

    def shutdown_request(self, request):
        """Dong ket noi. Neu vua tu choi som (411/413/400), xa toi da 8 MB / 2 giay du lieu khach con gui de ho DOC DUOC phan hoi thay vi nhan RST."""
        linger = getattr(_state, "linger", False)
        _state.linger = False
        try:
            request.shutdown(socket.SHUT_WR)
            if linger:
                request.settimeout(0.5)
                end = time.time() + LINGER_MAX_SECONDS
                drained = 0
                while drained < LINGER_MAX_BYTES and time.time() < end:
                    chunk = request.recv(65536)
                    if not chunk:
                        break
                    drained += len(chunk)
        except OSError:
            pass
        self.close_request(request)

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionError, socket.timeout, TimeoutError)):
            return  # khach dong ket noi/cham qua han: chuyen binh thuong tren di dong, khong phai loi cua ung dung
        sys.stderr.write("[wpp_wsgi] loi khi xu ly ket noi tu %s:\n%s\n" % (client_address[0], traceback.format_exc()))
        sys.stderr.flush()


class AsgiBridge(object):
    """Cau noi ASGI 3.0 -> WSGI (HANDOFF.md muc 1bq-K): chay ung dung ASGI tren MOT vong lap asyncio rieng (luong nen), moi yeu cau WSGI cua
    may chu da luong di qua vong lap do. Ho tro: HTTP (body da biet Content-Length), lifespan (startup/shutdown), scope day du (client, server,
    scheme, headers, state). KHONG ho tro: WebSocket, streaming/SSE that su (phan hoi duoc gom het roi moi gui; app khong ket thuc trong --asgi-timeout
    giay -> 504), HTTP/2.

    receive() sau khi giao body se CHAN cho den khi app xong (khong tra http.disconnect ngay): Starlette/StreamingResponse lang nghe disconnect song song
    va se tu huy neu nhan duoc no som."""

    UNSUPPORTED = object()
    HOP_BY_HOP = ("connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers", "transfer-encoding", "upgrade")

    def __init__(self, app, timeout=60):
        self.app = app
        self.timeout = timeout
        self.state = {}
        self.lifespan_active = False
        self.loop = asyncio.new_event_loop()
        threading.Thread(target=self._run, name="asgi-loop", daemon=True).start()
        self._ls_in = None
        self._ls_done = None

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    # ---------------------------------------------------------------- lifespan
    def start(self, startup_timeout=30):
        """Gui lifespan.startup. Tra ve None (xong, hoac app khong ho tro lifespan) hoac chuoi thong bao neu app bao startup.failed."""
        return asyncio.run_coroutine_threadsafe(self._startup(startup_timeout), self.loop).result(startup_timeout + 5)

    async def _startup(self, startup_timeout):
        loop = asyncio.get_event_loop()
        self._ls_in = asyncio.Queue()
        started = loop.create_future()
        self._ls_done = loop.create_future()

        async def receive():
            return await self._ls_in.get()

        async def send(msg):
            t = msg.get("type")
            if t == "lifespan.startup.complete" and not started.done():
                started.set_result(None)
            elif t == "lifespan.startup.failed" and not started.done():
                started.set_result(str(msg.get("message") or "startup failed"))
            elif t in ("lifespan.shutdown.complete", "lifespan.shutdown.failed") and not self._ls_done.done():
                self._ls_done.set_result(None)

        async def run():
            try:
                await self.app({"type": "lifespan", "asgi": {"version": "3.0", "spec_version": "2.0"}, "state": self.state}, receive, send)
            except BaseException:
                # Theo dac ta: app nem loi voi scope lifespan = khong ho tro lifespan -> may chu chay tiep binh thuong.
                if not started.done():
                    started.set_result(self.UNSUPPORTED)
            finally:
                if not started.done():
                    started.set_result(self.UNSUPPORTED)
                if not self._ls_done.done():
                    self._ls_done.set_result(None)

        loop.create_task(run())
        await self._ls_in.put({"type": "lifespan.startup"})
        try:
            result = await asyncio.wait_for(started, startup_timeout)
        except asyncio.TimeoutError:
            return "lifespan.startup khong xong trong %ds" % startup_timeout
        if result is self.UNSUPPORTED:
            return None
        self.lifespan_active = result is None
        return result

    def stop(self, timeout=5):
        """lifespan.shutdown (chi khi startup da xong); khong cho qua 'timeout' giay. Khong bao gio nem loi."""
        if not self.lifespan_active:
            return
        try:
            asyncio.run_coroutine_threadsafe(self._shutdown(timeout), self.loop).result(timeout + 2)
        except Exception:
            pass

    async def _shutdown(self, timeout):
        await self._ls_in.put({"type": "lifespan.shutdown"})
        try:
            await asyncio.wait_for(self._ls_done, timeout)
        except asyncio.TimeoutError:
            pass

    # ---------------------------------------------------------------- yeu cau HTTP
    def _scope(self, environ):
        headers = []
        for k, v in environ.items():
            if k.startswith("HTTP_"):
                headers.append((k[5:].lower().replace("_", "-").encode("latin-1"), str(v).encode("latin-1", "replace")))
        for k in ("CONTENT_TYPE", "CONTENT_LENGTH"):
            if environ.get(k):
                headers.append((k.lower().replace("_", "-").encode("latin-1"), str(environ[k]).encode("latin-1", "replace")))
        raw = environ.get("PATH_INFO", "") or "/"
        try:
            path = raw.encode("latin-1").decode("utf-8")  # PEP 3333: PATH_INFO la byte da giai ma phan tram, hien duoi dang latin-1
        except (UnicodeEncodeError, UnicodeDecodeError):
            path = raw
        try:
            port = int(environ.get("SERVER_PORT") or 0)
        except ValueError:
            port = 0
        return {
            "type": "http", "asgi": {"version": "3.0", "spec_version": "2.3"},
            "http_version": str(environ.get("SERVER_PROTOCOL", "HTTP/1.1")).split("/")[-1],
            "method": environ.get("REQUEST_METHOD", "GET"), "scheme": environ.get("wsgi.url_scheme", "http"),
            "path": path, "raw_path": urllib.parse.quote(path).encode("ascii"),
            "query_string": environ.get("QUERY_STRING", "").encode("latin-1", "replace"), "root_path": "",
            "headers": headers, "client": (environ.get("REMOTE_ADDR", ""), 0), "server": (environ.get("SERVER_NAME", ""), port),
            "state": dict(self.state),
        }

    async def _handle(self, scope, body):
        gave_body = [False]
        out = {"status": None, "headers": [], "chunks": [], "done": False}

        async def receive():
            if not gave_body[0]:
                gave_body[0] = True
                return {"type": "http.request", "body": body, "more_body": False}
            await asyncio.Event().wait()  # chan cho den khi app xong (task bi huy) - xem docstring lop

        async def send(message):
            t = message.get("type")
            if t == "http.response.start":
                out["status"] = int(message["status"])
                out["headers"] = list(message.get("headers") or [])
            elif t == "http.response.body":
                out["chunks"].append(bytes(message.get("body") or b""))
                if not message.get("more_body"):
                    out["done"] = True

        await self.app(scope, receive, send)
        if out["status"] is None:
            raise RuntimeError("ung dung ASGI ket thuc ma khong gui http.response.start")
        return out

    def __call__(self, environ, start_response):
        scope = self._scope(environ)
        body = environ["wsgi.input"].read()  # lop guard() da chan theo Content-Length
        fut = asyncio.run_coroutine_threadsafe(self._handle(scope, body), self.loop)
        try:
            out = fut.result(self.timeout)
        except concurrent.futures.TimeoutError:
            fut.cancel()
            return _plain(start_response, "504 Gateway Timeout", "ASGI application did not finish within %ds" % self.timeout)
        except BaseException as e:
            sys.stderr.write("[wpp_wsgi] ung dung ASGI nem loi:\n%s\n" % "".join(traceback.format_exception(type(e), e, e.__traceback__)))
            sys.stderr.flush()
            return _plain(start_response, "500 Internal Server Error", "Internal Server Error")
        try:
            phrase = http.HTTPStatus(out["status"]).phrase
        except ValueError:
            phrase = "Unknown"
        data = b"".join(out["chunks"])
        hdrs = []
        have_len = False
        for k, v in out["headers"]:
            name = bytes(k).decode("latin-1")
            if name.lower() in self.HOP_BY_HOP:
                continue  # wsgiref cam header hop-by-hop do ung dung dat
            if name.lower() == "content-length":
                have_len = True
            hdrs.append((name, bytes(v).decode("latin-1")))
        if not have_len:
            hdrs.append(("Content-Length", str(len(data))))
        start_response("%d %s" % (out["status"], phrase), hdrs)
        return [b""] if scope["method"] == "HEAD" else [data]


def load_app(target):
    """'module:attr' | 'module:obj.attr' | 'module:factory()'. Thoat (SystemExit) kem thong bao ro khi khong nap duoc."""
    mod_name, sep, attr = target.partition(":")
    if not sep or not mod_name or not attr:
        raise SystemExit("wpp_wsgi: can 'module:callable' (vi du app:app), nhan duoc %r" % target)
    call = attr.endswith("()")
    if call:
        attr = attr[:-2]
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)
    try:
        obj = importlib.import_module(mod_name)
    except ImportError as e:
        raise SystemExit("wpp_wsgi: khong nap duoc module %r: %s" % (mod_name, e))
    try:
        for part in attr.split("."):
            obj = getattr(obj, part)
    except AttributeError:
        raise SystemExit("wpp_wsgi: module %r khong co %r" % (mod_name, attr))
    if call:
        obj = obj()
    if not callable(obj):
        raise SystemExit("wpp_wsgi: %s:%s khong phai ung dung WSGI (khong goi duoc)" % (mod_name, attr))
    return obj


def make_server(app, host="127.0.0.1", port=8080, threads=16, timeout=30, max_body_mb=64, trust_proxy=False, access_log=False):
    handler = type("WppHandler", (_RequestHandler,), {"timeout": timeout})
    server = BoundedThreadedServer((host, port), handler, max_threads=threads)
    server.access_log = access_log
    server.set_app(guard(app, max_body_mb * 1024 * 1024, trust_proxy))
    return server


def main(argv=None):
    ap = argparse.ArgumentParser(prog="wpp_wsgi", description="May chu WSGI nhe cua WP Pocket Server")
    ap.add_argument("target", help="module:callable, vi du app:app")
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8080")))
    ap.add_argument("--bind", default="127.0.0.1")
    ap.add_argument("--threads", type=int, default=16)
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--max-body", type=int, default=64, help="MB")
    ap.add_argument("--trust-proxy", action="store_true")
    ap.add_argument("--access-log", action="store_true")
    ap.add_argument("--asgi", action="store_true", help="target la ung dung ASGI (Starlette, FastAPI...), chay qua cau noi ASGI->WSGI")
    ap.add_argument("--asgi-timeout", type=int, default=60, help="giay toi da cho MOT yeu cau ASGI (phan hoi duoc gom het roi moi gui)")
    args = ap.parse_args(argv)
    if not (1 <= args.threads <= 256) or not (1 <= args.timeout <= 3600) or not (1 <= args.max_body <= 4096) or not (1 <= args.port <= 65535):
        raise SystemExit("wpp_wsgi: --port 1..65535, --threads 1..256, --timeout 1..3600, --max-body 1..4096")
    app = load_app(args.target)
    bridge = None
    if args.asgi:
        if not (1 <= args.asgi_timeout <= 3600):
            raise SystemExit("wpp_wsgi: --asgi-timeout 1..3600")
        if not (inspect.iscoroutinefunction(app) or inspect.iscoroutinefunction(getattr(app, "__call__", None))):
            raise SystemExit("wpp_wsgi: %s khong giong ung dung ASGI (khong phai ham async / doi tuong co async __call__) - neu la Flask/Django hay bo --asgi" % args.target)
        bridge = AsgiBridge(app, args.asgi_timeout)
        err = bridge.start()
        if err:
            raise SystemExit("wpp_wsgi: lifespan startup that bai: %s" % err)
        app = bridge
    try:
        server = make_server(app, args.bind, args.port, args.threads, args.timeout, args.max_body, args.trust_proxy, args.access_log)
    except OSError as e:
        raise SystemExit("wpp_wsgi: khong mo duoc cong %s:%d: %s" % (args.bind, args.port, e))

    def stop(signum, frame):
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    sys.stdout.write("[wpp_wsgi] listening %s:%d app=%s threads=%d timeout=%ds max-body=%dMB trust-proxy=%s\n" % (
        args.bind, args.port, args.target, args.threads, args.timeout, args.max_body, args.trust_proxy))
    sys.stdout.flush()
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
        if bridge is not None:
            bridge.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
