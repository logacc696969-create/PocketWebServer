#!/usr/bin/env bash
# Chuẩn bị runtime "static": website chỉ gồm HTML/CSS/JS thuần, không cần backend thật.
#
# Hai chế độ (site.config.json "front_proxy"; HANDOFF.md mục 1bi):
#   true (MẶC ĐỊNH): nginx phục vụ thẳng thư mục web - gzip, ETag, Cache-Control cho tài sản tĩnh, header bảo mật, chặn dotfile; KHÔNG cần
#                    php/ICU nên APK nhỏ hơn nhiều.
#   false:           như trước - binary php làm `php -S` (static server nhẹ, không gzip/cache).
#
# Usage: scripts/runtimes/static.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh
source scripts/lib/site_profile.sh
source scripts/lib/reproducible_zip.sh

source scripts/lib/collect_libs.sh
source scripts/lib/generic_runtime.sh

FRONT="$(generic_front_proxy true)"
SONAME_MAP="$(mktemp)"
if [[ "$FRONT" == "true" ]]; then
  generic_bundle_nginx "$OUT_DIR" "$SONAME_MAP"
else
  EXTRACT_DIR="$(mktemp -d)"
  termux_download_with_deps php "$EXTRACT_DIR"
  PHP_BIN="$(termux_find_binary "$EXTRACT_DIR" php)"
  if [[ -z "$PHP_BIN" ]]; then
    echo "LOI: khong tim thay binary php (dung lam static server) sau khi tai tu Termux" >&2
    exit 1
  fi
  cp "$PHP_BIN" "$OUT_DIR/libruntimesrv.so"
  chmod 755 "$OUT_DIR/libruntimesrv.so"
  # Gom thu vien dung cach (ten ket thuc .so + soname-map) - xem node.sh.
  collect_shared_libs "$EXTRACT_DIR" "$OUT_DIR" "$SONAME_MAP"
fi

STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"
# docroot: thu muc con duoc phuc vu (vd "dist", "build", "public"); "" = goc (HANDOFF.md muc 1bb). Sai/thieu thu muc -> build that bai.
WEB_SUBDIR="$(site_docroot_subdir)" || exit 1
if [[ -n "$WEB_SUBDIR" && ! -d "$STAGING/$WEB_SUBDIR" ]]; then
  echo "LOI: site.config.json docroot=\"$WEB_SUBDIR\" nhung khong co thu muc nay trong ma nguon website" >&2
  exit 1
fi
generic_install_supervisor "$STAGING" "$SONAME_MAP" "$FRONT"
make_reproducible_zip "$STAGING" "$OUT_DIR/www.zip"  # tai lap duoc (HANDOFF.md muc 1ay)

PORT="$(jq -r '.port // 8080' site.config.json)"

if [[ "$FRONT" == "true" ]]; then
  generic_write_runtime_json "$OUT_DIR" "$PORT" libnginx.so static "" "" "$WEB_SUBDIR" ""
  echo "Xong: $OUT_DIR (runtime=static, nginx phuc vu thang${WEB_SUBDIR:+, docroot=$WEB_SUBDIR})"
else
  generic_write_runtime_json "$OUT_DIR" "$PORT" libruntimesrv.so direct libruntimesrv.so "-S 0.0.0.0:__PORT__ -t __DOCROOT__${WEB_SUBDIR:+/$WEB_SUBDIR}" "" ""
  echo "Xong: $OUT_DIR (runtime=static, php -S${WEB_SUBDIR:+, docroot=$WEB_SUBDIR})"
fi
