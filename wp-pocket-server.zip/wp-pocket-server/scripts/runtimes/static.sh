#!/usr/bin/env bash
# Chuẩn bị runtime "static": website chỉ gồm HTML/CSS/JS thuần, không cần
# backend thật. Vẫn dùng lại binary php (đã ổn định qua nhánh php.sh) chỉ để
# làm static file server nhẹ - tránh phải nhúng thêm một binary khác chỉ cho
# việc phục vụ file tĩnh.
#
# Usage: scripts/runtimes/static.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh

EXTRACT_DIR="$(mktemp -d)"
termux_download_with_deps php "$EXTRACT_DIR"

PHP_BIN="$(termux_find_binary "$EXTRACT_DIR" php)"
if [[ -z "$PHP_BIN" ]]; then
  echo "LOI: khong tim thay binary php (dung lam static server) sau khi tai tu Termux" >&2
  exit 1
fi
cp "$PHP_BIN" "$OUT_DIR/libruntimesrv.so"
chmod 755 "$OUT_DIR/libruntimesrv.so"
find "$EXTRACT_DIR" -type f -name '*.so*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true

STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"
(cd "$STAGING" && zip -qr "$OLDPWD/$OUT_DIR/www.zip" .)

PORT="$(jq -r '.port // 8080' site.config.json)"

cat > "$OUT_DIR/runtime.json" <<JSON
{
  "port": ${PORT},
  "binary": "libruntimesrv.so",
  "docroot": "www",
  "exec": ["\${BIN}", "-S", "0.0.0.0:\${PORT}", "-t", "\${DOCROOT}"],
  "env": {}
}
JSON

echo "Xong: $OUT_DIR (runtime=static)"
