#!/usr/bin/env bash
# Chuẩn bị runtime Node.js: tải binary node từ Termux + mã nguồn website +
# sinh runtime.json. Dùng khi site.config.json có "runtime": "node".
#
# entry mặc định: "server.js" (đặt "entry" khác trong site.config.json nếu
# file khởi động của bạn tên khác, vd "index.js" hoặc "src/main.js").
#
# Usage: scripts/runtimes/node.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh
source scripts/lib/site_deps.sh
source scripts/lib/reproducible_zip.sh
source scripts/lib/collect_libs.sh
source scripts/lib/generic_runtime.sh

EXTRACT_DIR="$(mktemp -d)"
termux_download_with_deps nodejs "$EXTRACT_DIR"

NODE_BIN="$(termux_find_binary "$EXTRACT_DIR" node)"
if [[ -z "$NODE_BIN" ]]; then
  echo "LOI: khong tim thay binary node sau khi tai tu Termux" >&2
  exit 1
fi
cp "$NODE_BIN" "$OUT_DIR/libruntimesrv.so"
chmod 755 "$OUT_DIR/libruntimesrv.so"
# Thu vien phu thuoc: gom dung cach (ten ket thuc .so + soname-map) - truoc day "cp -n" giu nguyen ten co so phien ban (libz.so.1...) nen
# build-apk.yml ("cp *.so") bo sot va node bao "library libz.so.1 not found" khi chay (HANDOFF.md muc 1bi).
SONAME_MAP="$(mktemp)"
collect_shared_libs "$EXTRACT_DIR" "$OUT_DIR" "$SONAME_MAP"
# "front_proxy": true -> them nginx phia truoc (header bao mat, gzip, WebSocket); mac dinh false.
FRONT="$(generic_front_proxy)"
if [[ "$FRONT" == "true" ]]; then generic_bundle_nginx "$OUT_DIR" "$SONAME_MAP"; fi

STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"

# npm install/ci lac BUILD (--omit=dev --ignore-scripts), khong can commit node_modules (HANDOFF.md muc 1ba).
# Tat bang site.config.json: "install_deps": false.
install_site_deps node "$STAGING"

generic_install_supervisor "$STAGING" "$SONAME_MAP" "$FRONT"
make_reproducible_zip "$STAGING" "$OUT_DIR/www.zip"  # tai lap duoc (HANDOFF.md muc 1ay)

PORT="$(jq -r '.port // 8080' site.config.json)"
ENTRY="$(jq -r '.entry // "server.js"' site.config.json)"
[[ "$ENTRY" == "null" || -z "$ENTRY" ]] && ENTRY="server.js"

MODE=direct; [[ "$FRONT" == "true" ]] && MODE=proxy
# Che do proxy: app nghe PORT+1 (bien PORT cua app do start-generic.sh dat), nginx nghe PORT cong cong.
generic_write_runtime_json "$OUT_DIR" "$PORT" libruntimesrv.so "$MODE" libruntimesrv.so "__DOCROOT__/${ENTRY}" "" '"NODE_ENV": "production"'

echo "Xong: $OUT_DIR (runtime=node, entry=${ENTRY}, che do=$MODE)"
