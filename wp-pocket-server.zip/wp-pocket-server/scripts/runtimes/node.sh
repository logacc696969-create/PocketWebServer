#!/usr/bin/env bash
# Chuẩn bị runtime Node.js: tải binary node từ Termux + mã nguồn website +
# sinh runtime.json. Dùng khi site.config.json có "runtime": "node".
#
# entry mặc định: "server.js" (đặt "entry" khác trong site.config.json nếu
# file khởi động của bạn tên khác, vd "index.js" hoặc "src/main.js").
#
# Usage: scripts/runtimes/node.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh

EXTRACT_DIR="$(mktemp -d)"
termux_download_with_deps nodejs "$EXTRACT_DIR"

NODE_BIN="$(termux_find_binary "$EXTRACT_DIR" node)"
if [[ -z "$NODE_BIN" ]]; then
  echo "LOI: khong tim thay binary node sau khi tai tu Termux" >&2
  exit 1
fi
cp "$NODE_BIN" "$OUT_DIR/libruntimesrv.so"
chmod 755 "$OUT_DIR/libruntimesrv.so"
find "$EXTRACT_DIR" -type f -name '*.so*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true

STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"

if [[ -d "$STAGING/node_modules" ]]; then
  echo "== (goi y) da thay san node_modules trong nguon - bo qua npm install =="
elif [[ -f "$STAGING/package.json" ]]; then
  echo "CANH BAO: co package.json nhung chua co node_modules. App khong tu chay"
  echo "'npm install' tren dien thoai. Hay chay 'npm install' truoc va commit"
  echo "node_modules vao nguon website (hoac dung site_source.type=git/zip da build san)." >&2
fi

(cd "$STAGING" && zip -qr "$OLDPWD/$OUT_DIR/www.zip" .)

PORT="$(jq -r '.port // 8080' site.config.json)"
ENTRY="$(jq -r '.entry // "server.js"' site.config.json)"
[[ "$ENTRY" == "null" || -z "$ENTRY" ]] && ENTRY="server.js"

cat > "$OUT_DIR/runtime.json" <<JSON
{
  "port": ${PORT},
  "binary": "libruntimesrv.so",
  "docroot": "www",
  "exec": ["\${BIN}", "\${DOCROOT}/${ENTRY}"],
  "env": {
    "NODE_ENV": "production"
  }
}
JSON

echo "Xong: $OUT_DIR (runtime=node, entry=${ENTRY})"
