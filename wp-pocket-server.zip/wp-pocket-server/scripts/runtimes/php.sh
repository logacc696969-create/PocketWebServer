#!/usr/bin/env bash
# Chuẩn bị runtime PHP "production-capable": nginx + php-fpm + MariaDB thật
# (không phải `php -S` dev server + SQLite như bản đầu) - dùng lại đúng kỹ
# thuật mượn binary Termux đã có, chỉ mượn thêm 3 gói thay vì 1.
#
# Lý do nâng cấp: `php -S` chính PHP.net ghi rõ chỉ để dev/test, xử lý tuần
# tự - nghẽn khi có vài người truy cập cùng lúc. nginx+php-fpm xử lý đồng
# thời đúng nghĩa. MariaDB thật (thay vì SQLite) giúp tương thích các plugin
# WordPress cao cấp giả định có MySQL.
#
# Đánh đổi: nặng RAM/CPU hơn bản cũ - đây là giới hạn phần cứng điện thoại
# thật, không né được bằng phần mềm (xem HANDOFF.md mục giới hạn cứng).
#
# Usage: scripts/runtimes/php.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."   # ve root repo

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh
source scripts/lib/admin_tools.sh

EXTRACT_DIR="$(mktemp -d)"

echo "== Tai php-fpm (+ Depends) =="
termux_download_with_deps php-fpm "$EXTRACT_DIR"
echo "== Tai nginx (+ Depends) =="
termux_download_with_deps nginx "$EXTRACT_DIR"
echo "== Tai mariadb (+ Depends) - co the mat vai phut, goi nang =="
termux_download_with_deps mariadb "$EXTRACT_DIR"
echo "== Tai php (goi mysqli/pdo_mysql, dam bao co du extension) =="
termux_download_with_deps php "$EXTRACT_DIR" php-mysql || true

# --- Doi ten cac binary theo quy uoc lib*.so de PackageManager cai dat thuc thi ---
# SUA LOI THAT (phat hien tu log build that - xem HANDOFF.md muc 1p): ban
# dau dung "*/bin/$1*" (CO dau * cuoi) - dau * thua nay khien vd
# "find_bin mariadb" khop VOI MOI file bat dau bang "mariadb" trong bin/
# (mariadb-dump, mariadb-install-db, mariadb-convert-table-format,
# mariadb-admin, mariadb-check...), khong chi dung 1 file ten "mariadb". Vi
# thu tu duyet file cua `find` KHONG dam bao theo bang chu cai, ket qua
# "head -n1" co the ra BAT KY file nao trong so do - thuc te da bat dung
# "mariadb-convert-table-format" (1 script Perl) thay vi client "mariadb"
# that. Bo dau * cuoi de khop CHINH XAC ten file, khong con mo ho.
find_bin() { find "$EXTRACT_DIR" -type f -path "*/bin/$1" | head -n1; }
find_sbin() { find "$EXTRACT_DIR" -type f \( -path "*/sbin/$1" -o -path "*/bin/$1" \) | head -n1; }

PHP_FPM_BIN="$(find_sbin php-fpm)"
NGINX_BIN="$(find_sbin nginx)"
MARIADBD_BIN="$(find_sbin mariadbd)"
[[ -z "$MARIADBD_BIN" ]] && MARIADBD_BIN="$(find_sbin mysqld)"
MARIADB_INSTALL_BIN="$(find_bin mariadb-install-db)"
[[ -z "$MARIADB_INSTALL_BIN" ]] && MARIADB_INSTALL_BIN="$(find_bin mysql_install_db)"
MYSQL_CLI_BIN="$(find_bin mariadb)"
[[ -z "$MYSQL_CLI_BIN" ]] && MYSQL_CLI_BIN="$(find_bin mysql)"
MYSQLDUMP_BIN="$(find_bin mariadb-dump)"
[[ -z "$MYSQLDUMP_BIN" ]] && MYSQLDUMP_BIN="$(find_bin mysqldump)"
# my_print_defaults: binary phu tro RIENG, KHONG nam trong danh sach 7 binary
# chinh o vong lap ben duoi - phat hien la nguyen nhan loi "FATAL ERROR:
# Could not find my_print_defaults" that tren thiet bi that (xem HANDOFF.md
# muc 1p). Ban than mariadb-install-db (dung sau khi sua shebang o muc 1o)
# tu tim binary nay qua --basedir, KHONG qua bien moi truong nao ca - nen
# khong dua vao vong lap lib*.so nhu cac binary khac, ma phai dat dung cho
# no tim (xem khoi dong goi $MARIADB_BASEDIR/bin/ ben duoi).
MY_PRINT_DEFAULTS_BIN="$(find_bin my_print_defaults)"
# Ten file CHINH XAC "php" (khong dung glob "php*" nhu find_bin/find_sbin -
# se vo tinh khop nham phpize/php-config/phpdbg cung nam trong bin/ cua goi
# Termux "php"). Can cho Dual-Mode PHP-Lite (`php -S`, xem HANDOFF.md muc
# 1e) - TRUOC BAN NAY chua bao gio tai binary CLI nay (du an chi dung
# php-fpm), la 1 lo hong thuc thi neu khong them dong nay.
PHP_CLI_BIN="$(find "$EXTRACT_DIR" -type f -path "*/bin/php" | head -n1)"

for pair in "PHP_FPM_BIN:libphpfpm.so" "NGINX_BIN:libnginx.so" "MARIADBD_BIN:libmariadbd.so" \
            "MARIADB_INSTALL_BIN:libmariadbinstall.so" "MYSQL_CLI_BIN:libmysqlcli.so" \
            "MYSQLDUMP_BIN:libmysqldump.so" "PHP_CLI_BIN:libphpcli.so"; do
  var="${pair%%:*}"; out_name="${pair##*:}"
  val="${!var}"
  if [[ -z "$val" ]]; then
    echo "CANH BAO: khong tim thay binary cho $var - thieu se lam start-lamp.sh loi khi chay, xem HANDOFF.md" >&2
    continue
  fi
  cp "$val" "$OUT_DIR/$out_name"
  chmod 755 "$OUT_DIR/$out_name"

  # --- Phat hien + va shebang neu day la SHELL SCRIPT, khong phai binary
  # bien dich (xem HANDOFF.md muc 1o) ---
  # LY DO (bang chung THAT tu thiet bi that, khong phai doan): log chan doan
  # o start-lamp.sh xac nhan libmariadbinstall.so TON TAI, quyen thuc thi
  # DAY DU (rwxr-xr-x), nhung van loi "No such file or directory" khi Android
  # thu chay - day la dau hieu KINH DIEN cua 1 script co dong dau (shebang)
  # tro toi 1 interpreter KHONG TON TAI tren may (vd
  # "#!/data/data/com.termux/files/usr/bin/bash"), KHONG PHAI file thieu hay
  # sai quyen. Kich thuoc file (22KB, qua nho cho 1 binary C++ bien dich lien
  # ket voi MariaDB) cung khop: mariadb-install-db trong nhieu ban phan phoi
  # MariaDB/MySQL (kem ca ban Termux dang dung) VON LA SHELL SCRIPT, khong
  # phai binary - goi mariadbd --bootstrap ben trong qua ten chuong trinh,
  # khong phai qua duong dan tuyet doi.
  # Kiem tra 2 byte dau tien: "#!" la dau hieu chac chan cua script (ELF that
  # se bat dau bang 4 byte "\x7fELF"). Neu la script, doi dong shebang tro ve
  # "/system/bin/sh" (shell co san tren MOI thiet bi Android, khac voi
  # interpreter Termux khong ton tai ngoai Termux that).
  first_bytes="$(head -c2 "$OUT_DIR/$out_name" 2>/dev/null || true)"
  if [[ "$first_bytes" == "#!" ]]; then
    old_shebang="$(head -n1 "$OUT_DIR/$out_name")"
    echo "CANH BAO: $out_name la SHELL SCRIPT (khong phai binary bien dich) - shebang goc: \"$old_shebang\" tro vao duong dan CHI CO trong Termux that, se loi 'No such file or directory' tren may khong co Termux. Dang doi shebang sang /system/bin/sh."
    { echo "#!/system/bin/sh"; tail -n +2 "$OUT_DIR/$out_name"; } > "$OUT_DIR/$out_name.patched"
    mv "$OUT_DIR/$out_name.patched" "$OUT_DIR/$out_name"
    chmod 755 "$OUT_DIR/$out_name"
    echo "  -> Da doi shebang cua $out_name sang #!/system/bin/sh"
    # In nguyen noi dung script vao log build (KHONG chi shebang) - de neu
    # sau buoc nay van loi (vd script goi chuong trinh khac bang TEN TRAN
    # nhu "mariadbd" thay vi duong dan day du - se khong tim thay vi APK chi
    # nhan file dat ten "lib*.so"), lan sau co san bang chung THAT trong log
    # build, khong phai doan tiep. Gioi han 200 dong phong truong hop script
    # qua dai lam log kho doc.
    echo "  -> Noi dung $out_name (de doi chieu neu buoc nay chua du, xem HANDOFF.md muc 1o):"
    echo "----- BAT DAU $out_name -----"
    head -n 200 "$OUT_DIR/$out_name"
    echo "----- KET THUC $out_name -----"
  fi
done

echo "== Thu thap toan bo .so phu thuoc (openssl, pcre, sqlite, zlib, oniguruma, mysql client lib...) =="
find "$EXTRACT_DIR" -type f -name '*.so*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true
echo "== Thu thap extension .so cua php (mysqli.so, pdo_mysql.so, mbstring.so...) neu co =="
find "$EXTRACT_DIR" -type f -name '*.so' -path '*/php*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true

# --- Chuan bi website vao staging, chen them _supervisor/ + wp-config template ---
STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"
prepare_admin_tools "$STAGING"

mkdir -p "$STAGING/_supervisor"
cp scripts/runtimes/templates/nginx.conf.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/php-fpm.conf.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/php.ini.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/router-lite.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/start-lamp.sh "$STAGING/_supervisor/start-lamp.sh"
chmod 755 "$STAGING/_supervisor/start-lamp.sh"

# --- Dong goi thu muc "share" cua MariaDB (SQL bootstrap system-tables,
# catalog thong bao loi errmsg.sys, dinh nghia charset) ---
# LY DO THEM (phat hien tu log loi that "mariadb-install-db that bai" o tren
# thiet bi that): dong copy ".so*" phia tren (dong "Thu thap toan bo .so phu
# thuoc") CHI khop ten file ket thuc ".so" - toan bo thu muc share/mariadb/
# (hoac share/mysql/ tuy ban) tai ve cung goi mariadb (nam trong $EXTRACT_DIR)
# bi BO SOT HOAN TOAN, khong dc copy vao OUT_DIR/STAGING o dau ca. Day KHONG
# phai file phu - mariadb-install-db (thuc chat goi mariadbd --bootstrap ben
# trong) doc cac file .sql nay de dung sinh system tables, VA can errmsg.sys
# chi de KHOI DONG duoc (init_errmessage() chay truoc ca buoc bootstrap) - nen
# thieu se loi NGAY LAP TUC, GIONG HET NHAU moi lan chay, bat ke RAM/retry
# (khop dung hien tuong log that: khong phai loi ngau nhien hay do trang thai
# dang do cua lan chay truoc).
# Khong the dua qua co che "lib*.so" nhu cac binary khac (build-apk.yml CHI
# "cp *.so" vao jniLibs/, khong nhan file/thu muc nao khac) - nen phai di qua
# STAGING/www.zip giong cac file cau hinh khac, roi start-lamp.sh tro
# --basedir vao day (xem sua doi tuong ung trong start-lamp.sh).
# SUA LAI (sau khi gap loi cai dat APK that - xem HANDOFF.md muc 1m): BAN DAU
# dinh copy NGUYEN CA thu muc "share" gop chung tu moi goi (nginx/php-fpm/
# mariadb/php) cho AN TOAN ten thu muc con - nhung day la doan CHUA VERIFY
# dung luong ("vai tram KB, khong dang ke" chi la UOC LUONG, khong do that).
# PHP thuong keo theo icu/gettext data (module intl/mbstring) co the nang
# TOI VAI CHUC MB trong share/, cong voi doc/man cua nginx - khong can thiet
# cho muc dich o day (chi can file cua MARIADB). Nen CHI tim va copy DUNG
# thu muc con "mariadb" (hoac "mysql") thay vi ca "share/" de tranh phinh to
# APK khong dang. Neu ten thu muc con khac 2 ten nay (chua tung thay truong
# hop nay voi goi mariadb cua Termux), se in CANH BAO ro rang thay vi am
# tham thieu.
MARIADB_SHARE_DIR="$(find "$EXTRACT_DIR" -type d \( -name mariadb -o -name mysql \) -path '*/share/*' | head -n1)"
if [[ -n "$MARIADB_SHARE_DIR" ]]; then
  DEST_NAME="$(basename "$MARIADB_SHARE_DIR")"
  mkdir -p "$STAGING/_supervisor/mariadb-share/share"
  cp -a "$MARIADB_SHARE_DIR" "$STAGING/_supervisor/mariadb-share/share/$DEST_NAME"
  SHARE_SIZE="$(du -sh "$STAGING/_supervisor/mariadb-share" 2>/dev/null | cut -f1)"
  echo "== Da dong goi $MARIADB_SHARE_DIR vao _supervisor/mariadb-share/share/$DEST_NAME (sql bootstrap + errmsg.sys + charsets cua MariaDB, dung luong: ${SHARE_SIZE:-khong ro}) =="
else
  echo "CANH BAO NGHIEM TRONG: khong tim thay thu muc con 'mariadb' hoac 'mysql' trong bat ky share/ nao cua goi da tai - mariadb-install-db se KHONG the khoi dong (thieu SQL bootstrap + errmsg.sys)" >&2
fi

# --- Dong goi $MARIADB_BASEDIR/bin/ voi TEN GOC (khong doi ten lib*.so) ---
# LY DO (bang chung THAT tren thiet bi - xem HANDOFF.md muc 1p): sau khi sua
# shebang o muc 1o, mariadb-install-db chay duoc nhung dung lai ngay voi
# "FATAL ERROR: Could not find my_print_defaults", tim trong
# "$basedir/bin" va "$basedir/extra". Day la hanh vi CHUAN cua chinh script
# mariadb-install-db (tu tim cac binary phu tro qua --basedir, KHONG qua
# bien moi truong/PATH) - can dat dung file TEN GOC (khong phai "lib*.so")
# vao dung cho no tim. KHONG the lam qua nativeLibraryDir (chi nhan file
# "lib*.so", xem HANDOFF.md muc 1k) nen phai dung $MARIADB_BASEDIR (nam
# trong www.zip, thu muc thuong, khong bi rang buoc ten file).
# Tao "bin/" that, roi "sbin"/"libexec"/"extra" la SYMLINK tro ve "bin" -
# vi CHUA chac chan script tim mariadbd o thu muc con nao (chi moi thay no
# tim my_print_defaults o "bin"/"extra"; cac ban MariaDB/script khac nhau co
# the tim mariadbd o "sbin" hoac "libexec") - symlink ca 4 ten ve 1 cho de
# khong phu thuoc dung 1 gia dinh nao.
mkdir -p "$STAGING/_supervisor/mariadb-share/bin"
for bp in "MY_PRINT_DEFAULTS_BIN:my_print_defaults" "MARIADBD_BIN:mariadbd" \
          "MARIADB_INSTALL_BIN:mariadb-install-db" "MYSQL_CLI_BIN:mariadb" \
          "MYSQLDUMP_BIN:mariadb-dump"; do
  bvar="${bp%%:*}"; bname="${bp##*:}"
  bval="${!bvar}"
  if [[ -z "$bval" ]]; then
    echo "CANH BAO: khong tim thay binary goc cho $bvar (can cho $bname trong \$MARIADB_BASEDIR/bin) - mariadb-install-db co the van loi neu thieu file nay" >&2
    continue
  fi
  cp "$bval" "$STAGING/_supervisor/mariadb-share/bin/$bname"
  chmod 755 "$STAGING/_supervisor/mariadb-share/bin/$bname"
  # Ap dung LAI cung 1 kiem tra shebang nhu vong lap lib*.so o tren - cac
  # binary nay copy TRUC TIEP tu $EXTRACT_DIR, chua qua buoc va shebang nao,
  # nen neu chung CUNG la script (nhu libmariadbinstall.so/libmysqlcli.so da
  # gap) se can va y het.
  fb="$(head -c2 "$STAGING/_supervisor/mariadb-share/bin/$bname" 2>/dev/null || true)"
  if [[ "$fb" == "#!" ]]; then
    echo "CANH BAO: $bname (trong mariadb-share/bin) cung la SHELL SCRIPT - shebang goc: \"$(head -n1 "$STAGING/_supervisor/mariadb-share/bin/$bname")\" - dang doi sang /system/bin/sh"
    { echo "#!/system/bin/sh"; tail -n +2 "$STAGING/_supervisor/mariadb-share/bin/$bname"; } > "$STAGING/_supervisor/mariadb-share/bin/$bname.patched"
    mv "$STAGING/_supervisor/mariadb-share/bin/$bname.patched" "$STAGING/_supervisor/mariadb-share/bin/$bname"
    chmod 755 "$STAGING/_supervisor/mariadb-share/bin/$bname"
  fi
done
( cd "$STAGING/_supervisor/mariadb-share" && for d in sbin libexec extra; do ln -sfn bin "$d"; done )
echo "== Da dong goi mariadb-share/bin/ (my_print_defaults, mariadbd, mariadb-install-db, mariadb, mariadb-dump - ten goc) + symlink sbin/libexec/extra -> bin =="

# Auto-Sleep MariaDB khi ranh (xem HANDOFF.md, tinh nang opt-in - xem
# Prefs.KEY_AUTO_SLEEP_ENABLED). wake-mariadb.sh.template + activity-touch.php
# nam trong _supervisor/ (bi chan truy cap ngoai boi nginx.conf.template, xem
# "location ^~ /_supervisor/" - CHI can doc duoc qua filesystem, khong can
# web-accessible). wake-mariadb.php thi NGUOC LAI - PHAI dat o GOC docroot
# (KHONG duoc dat trong _admin/), vi _admin/ chi cho LAN truy cap (xem
# nginx.conf.template) trong khi wake-mariadb.php can duoc kich hoat boi
# CHINH KHACH CONG KHAI (qua Cloudflare Tunnel) - dat nham vao _admin/ se
# lam tinh nang nay khong bao gio hoat dong duoc voi khach that.
cp scripts/runtimes/templates/wake-mariadb.sh.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/activity-touch.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/wake-mariadb.php "$STAGING/wake-mariadb.php"

# CA cert bundle cho PHP (curl.so + stream SSL cua file_get_contents) - can
# cho tinh nang "1-Click Install WordPress" (_admin/install-wp.php, xem
# HANDOFF.md muc 1e) goi HTTPS ra wordpress.org/api.wordpress.org. Day la
# noi DUY NHAT trong du an PHP tu goi mang ra ngoai (khac voi cloudflared,
# vi Go co co che xac thuc TLS rieng khong phu thuoc file nay) nen truoc gio
# chua can, gio moi phat sinh. Tai luc BUILD (GitHub Actions runner co
# internet + CA store that day du) thay vi luc runtime tren dien thoai.
echo "== Tai CA cert bundle cho PHP (curl/openssl) =="
curl -fsSL https://curl.se/ca/cacert.pem -o "$STAGING/_supervisor/cacert.pem" \
  || echo "CANH BAO: khong tai duoc cacert.pem - 1-Click Install WordPress co the loi SSL, cac chuc nang khac khong anh huong"

# Neu site_source.sh da tao wp-config.php.template (dung MariaDB qua socket) -> giu nguyen.
# Neu chi thay wp-config.php tinh (truong hop khong phai wordpress) -> khong dong gi them.

(cd "$STAGING" && zip -qr "$OLDPWD/$OUT_DIR/www.zip" .)

PORT="$(jq -r '.port // 8080' site.config.json)"

cat > "$OUT_DIR/runtime.json" <<JSON
{
  "port": ${PORT},
  "binary": "libnginx.so",
  "docroot": "www",
  "exec": ["/system/bin/sh", "\${DOCROOT}/_supervisor/start-lamp.sh"],
  "env": {}
}
JSON

echo "Xong: $OUT_DIR (runtime=php, nginx+php-fpm+mariadb)"
