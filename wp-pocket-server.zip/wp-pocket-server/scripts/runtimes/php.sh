#!/usr/bin/env bash
# Chuẩn bị runtime PHP "production-capable": nginx + php-fpm + MariaDB thật
# (không phải `php -S` dev server + SQLite như bản đầu) - dùng lại đúng kỹ
# thuật mượn binary Termux đã có, chỉ mượn thêm 3 gói thay vì 1.
#
# Lý do nâng cấp: `php -S` chính PHP.net ghi rõ chỉ để dev/test, xử lý tuần
# tự - nghẽn khi có vài người truy cập cùng lúc. nginx+php-fpm xử lý đồng
# thời đúng nghĩa. MariaDB thật (thay vì SQLite) giúp tương thích các plugin
# WordPress cao cấp giả định có MySQL.
#
# Đánh đổi: nặng RAM/CPU hơn bản cũ - đây là giới hạn phần cứng điện thoại
# thật, không né được bằng phần mềm (xem HANDOFF.md mục giới hạn cứng).
#
# Usage: scripts/runtimes/php.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."   # ve root repo

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/verify_download.sh
source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh
source scripts/lib/site_deps.sh
source scripts/lib/site_profile.sh
source scripts/lib/admin_tools.sh
source scripts/lib/reproducible_zip.sh

EXTRACT_DIR="$(mktemp -d)"

echo "== Tai php-fpm (+ Depends) =="
termux_download_with_deps php-fpm "$EXTRACT_DIR"
echo "== Tai nginx (+ Depends) =="
termux_download_with_deps nginx "$EXTRACT_DIR"
echo "== Tai mariadb (+ Depends) - co the mat vai phut, goi nang =="
termux_download_with_deps mariadb "$EXTRACT_DIR"
echo "== Tai php (goi mysqli/pdo_mysql, dam bao co du extension) =="
# TERMUX_EXTRA_DEPS: libnghttp2, libnghttp3, libngtcp2, libssh2 - day la
# PHU THUOC GIAN TIEP cua libcurl (ban than libcurl la 1 Depends TRUC TIEP
# cua php, nhung termux_download_with_deps chi di 1 cap - xem chu thich
# trong termux_fetch.sh - nen Depends CUA libcurl khong duoc tai). Xac nhan
# CHINH XAC tu ma nguon that
# (https://github.com/termux/termux-packages/blob/master/packages/libcurl/build.sh,
# dong "TERMUX_PKG_DEPENDS=\"libnghttp2, libnghttp3, libngtcp2, libssh2,
# openssl (>= 1:3.2.1-1), zlib\"" - openssl/zlib da co san qua Depends truc
# tiep cua nginx/mariadb/php nen khong can liet ke lai). Bang chung that tren
# thiet bi: php-fpm bao dung linker Android "library libnghttp3.so not
# found" (xem HANDOFF.md muc 1x) - khong phai doan, tra duoc dung file build
# script that cua Termux.
termux_download_with_deps php "$EXTRACT_DIR" php-mysql libnghttp2 libnghttp3 libngtcp2 libssh2 || true

echo "== Tai php-apcu (de xuat DeepSeek muc I4, xem HANDOFF.md muc 10) - KHONG BAT BUOC =="
# APCu la cache trong tien trinh (shared-memory), nhe hon Redis/Memcached
# rat nhieu (da tu choi Redis/Memcached - xem HANDOFF.md phan "khong lam
# lai") - nhung KHAC voi mysqli/pdo_mysql/mbstring... (da bien dich TINH vao
# ngay binary php/php-fpm tren ban Termux gan day, xem chu thich dai trong
# php.ini.template), APCu la extension PECL rieng ma Termux van dong goi
# THANH 1 GOI RIENG (".../packages/php-apcu/" trong repo termux-packages) -
# tuc la KHONG duoc bien dich tinh san, van can file .so rieng.
#
# "|| true": neu goi nay khong ton tai/khong tai duoc (vd Termux doi cach
# dong goi sau nay), build VAN TIEP TUC BINH THUONG - website chinh (chay
# qua mysqli/pdo_mysql da bien dich tinh, khong phu thuoc APCu) hoat dong
# 100% du KHONG co APCu. File apcu.so (neu tai duoc) se TU DONG duoc gom
# vao OUT_DIR boi dong "find ... -name '*.so' -path '*/php*'" da co san ben
# duoi - KHONG can sua gi them o do.
#
# QUAN TRONG: khac voi cac goi khac o file nay, dong nay CHUA duoc chinh
# tay chay thu tren mang that (domain repo Termux - packages.termux.dev -
# khong nam trong danh sach domain duoc phep truy cap cua moi truong dung de
# soan file nay, xem HANDOFF.md muc 1ap) - nhung ham termux_download_pkg
# duoc goi lai o day la ham DA duoc chinh cac goi php/php-fpm/nginx/mariadb
# o tren dung va xac nhan hoat dong dung tren thiet bi that nhieu lan, nen
# rui ro chu yeu chi con la "goi php-apcu co ton tai dung ten nay hay khong"
# (kha nang cao la co, vi HANDOFF.md muc 1ag da tung xac nhan qua GitHub
# tim thay thu muc goi nay that trong repo termux-packages) - CHUA phai
# "chac chan 100% da chay thanh cong tren thiet bi that", ai build lai nen
# tu xac nhan 1 lan qua log build (dong "== Tai php-apcu ==" o duoi in
# ra gi).
termux_download_pkg php-apcu "$EXTRACT_DIR" || true

# --- Doi ten cac binary theo quy uoc lib*.so de PackageManager cai dat thuc thi ---
# SUA LOI THAT (phat hien tu log build that - xem HANDOFF.md muc 1p): ban
# dau dung "*/bin/$1*" (CO dau * cuoi) - dau * thua nay khien vd
# "find_bin mariadb" khop VOI MOI file bat dau bang "mariadb" trong bin/
# (mariadb-dump, mariadb-install-db, mariadb-convert-table-format,
# mariadb-admin, mariadb-check...), khong chi dung 1 file ten "mariadb". Vi
# thu tu duyet file cua `find` KHONG dam bao theo bang chu cai, ket qua
# "head -n1" co the ra BAT KY file nao trong so do - thuc te da bat dung
# "mariadb-convert-table-format" (1 script Perl) thay vi client "mariadb"
# that. Bo dau * cuoi de khop CHINH XAC ten file, khong con mo ho.
find_bin() { find "$EXTRACT_DIR" -type f -path "*/bin/$1" | head -n1; }
find_sbin() { find "$EXTRACT_DIR" -type f \( -path "*/sbin/$1" -o -path "*/bin/$1" \) | head -n1; }

PHP_FPM_BIN="$(find_sbin php-fpm)"
NGINX_BIN="$(find_sbin nginx)"
MARIADBD_BIN="$(find_sbin mariadbd)"
[[ -z "$MARIADBD_BIN" ]] && MARIADBD_BIN="$(find_sbin mysqld)"
MARIADB_INSTALL_BIN="$(find_bin mariadb-install-db)"
[[ -z "$MARIADB_INSTALL_BIN" ]] && MARIADB_INSTALL_BIN="$(find_bin mysql_install_db)"
MYSQL_CLI_BIN="$(find_bin mariadb)"
[[ -z "$MYSQL_CLI_BIN" ]] && MYSQL_CLI_BIN="$(find_bin mysql)"
MYSQLDUMP_BIN="$(find_bin mariadb-dump)"
[[ -z "$MYSQLDUMP_BIN" ]] && MYSQLDUMP_BIN="$(find_bin mysqldump)"
# my_print_defaults: binary phu tro RIENG ma mariadb-install-db tu tim qua
# --basedir (khong qua bien moi truong nao). Dua vao CHINH vong lap
# lib*.so/nativeLibraryDir ben duoi (KHONG con dua rieng vao
# mariadb-share/bin/ nhu ban truoc - xem HANDOFF.md muc 1r ve ly do doi
# huong: nativeLibraryDir la noi DUY NHAT Android chac chan CHO PHEP thuc
# thi; file copy vao filesDir/www.zip co the bi CHAN thuc thi boi SELinux du
# co chmod +x day du).
MY_PRINT_DEFAULTS_BIN="$(find_bin my_print_defaults)"
# resolveip: doc NGUYEN VAN script that (xem HANDOFF.md muc 1t) thay day la
# buoc TIEP THEO sau mariadbd se can toi - script goi thang
# "\$basedir/bin/resolveip" (duong dan tuong doi binh thuong, khong bi loi
# dong cung nhu mariadbd) de kiem tra hostname, KHONG co "test -x" truoc khi
# goi - neu thieu se lo ra loi FATAL khac ("Neither host ... could be looked
# up"). Bundle truoc luon, tranh phai cho nguoi dung build tiep 1 vong nua
# moi biet.
RESOLVEIP_BIN="$(find_bin resolveip)"
# Ten file CHINH XAC "php" (khong dung glob "php*" nhu find_bin/find_sbin -
# se vo tinh khop nham phpize/php-config/phpdbg cung nam trong bin/ cua goi
# Termux "php"). Can cho Dual-Mode PHP-Lite (`php -S`, xem HANDOFF.md muc
# 1e) - TRUOC BAN NAY chua bao gio tai binary CLI nay (du an chi dung
# php-fpm), la 1 lo hong thuc thi neu khong them dong nay.
PHP_CLI_BIN="$(find "$EXTRACT_DIR" -type f -path "*/bin/php" | head -n1)"

for pair in "PHP_FPM_BIN:libphpfpm.so" "NGINX_BIN:libnginx.so" "MARIADBD_BIN:libmariadbd.so" \
            "MARIADB_INSTALL_BIN:libmariadbinstall.so" "MYSQL_CLI_BIN:libmysqlcli.so" \
            "MYSQLDUMP_BIN:libmysqldump.so" "PHP_CLI_BIN:libphpcli.so" \
            "MY_PRINT_DEFAULTS_BIN:libmyprintdefaults.so" "RESOLVEIP_BIN:libresolveip.so"; do
  var="${pair%%:*}"; out_name="${pair##*:}"
  val="${!var}"
  if [[ -z "$val" ]]; then
    echo "CANH BAO: khong tim thay binary cho $var - thieu se lam start-lamp.sh loi khi chay, xem HANDOFF.md" >&2
    continue
  fi
  cp "$val" "$OUT_DIR/$out_name"
  chmod 755 "$OUT_DIR/$out_name"

  # --- Phat hien + va shebang neu day la SHELL SCRIPT, khong phai binary
  # bien dich (xem HANDOFF.md muc 1o) ---
  # LY DO (bang chung THAT tu thiet bi that, khong phai doan): log chan doan
  # o start-lamp.sh xac nhan libmariadbinstall.so TON TAI, quyen thuc thi
  # DAY DU (rwxr-xr-x), nhung van loi "No such file or directory" khi Android
  # thu chay - day la dau hieu KINH DIEN cua 1 script co dong dau (shebang)
  # tro toi 1 interpreter KHONG TON TAI tren may (vd
  # "#!/data/data/com.termux/files/usr/bin/bash"), KHONG PHAI file thieu hay
  # sai quyen. Kich thuoc file (22KB, qua nho cho 1 binary C++ bien dich lien
  # ket voi MariaDB) cung khop: mariadb-install-db trong nhieu ban phan phoi
  # MariaDB/MySQL (kem ca ban Termux dang dung) VON LA SHELL SCRIPT, khong
  # phai binary - goi mariadbd --bootstrap ben trong qua ten chuong trinh,
  # khong phai qua duong dan tuyet doi.
  # Kiem tra 2 byte dau tien: "#!" la dau hieu chac chan cua script (ELF that
  # se bat dau bang 4 byte "\x7fELF"). Neu la script, doi dong shebang tro ve
  # "/system/bin/sh" (shell co san tren MOI thiet bi Android, khac voi
  # interpreter Termux khong ton tai ngoai Termux that).
  first_bytes="$(head -c2 "$OUT_DIR/$out_name" 2>/dev/null || true)"
  if [[ "$first_bytes" == "#!" ]]; then
    old_shebang="$(head -n1 "$OUT_DIR/$out_name")"
    echo "CANH BAO: $out_name la SHELL SCRIPT (khong phai binary bien dich) - shebang goc: \"$old_shebang\" tro vao duong dan CHI CO trong Termux that, se loi 'No such file or directory' tren may khong co Termux. Dang doi shebang sang /system/bin/sh."
    { echo "#!/system/bin/sh"; tail -n +2 "$OUT_DIR/$out_name"; } > "$OUT_DIR/$out_name.patched"
    mv "$OUT_DIR/$out_name.patched" "$OUT_DIR/$out_name"
    chmod 755 "$OUT_DIR/$out_name"
    echo "  -> Da doi shebang cua $out_name sang #!/system/bin/sh"
    # In NGUYEN VEN toan bo noi dung script vao log build (KHONG gioi han
    # dong nua - tung gioi han 200 dong nhung 200 dong dau chi toan phan giay
    # phep GPL, chua toi duoc logic chinh; loi "mariadbd" hien tai (xem
    # HANDOFF.md muc 1s) can thay duoc doan logic O GIUA/CUOI file ma 200
    # dong khong du) - de neu con loi tiep, co san toan bo bang chung that
    # trong log build, khong phai doan tiep tung phan.
    echo "  -> Noi dung $out_name (de doi chieu neu buoc nay chua du, xem HANDOFF.md muc 1o/1s):"
    echo "----- BAT DAU $out_name -----"
    cat "$OUT_DIR/$out_name"
    echo "----- KET THUC $out_name -----"
  fi
done

echo "== Thu thap toan bo .so phu thuoc (openssl, pcre, sqlite, zlib, oniguruma, mysql client lib...) =="
# SUA (xem HANDOFF.md muc 1u): truoc chi bat "-type f", BO SOT moi thu vien
# dang SYMLINK theo kieu dat ten SONAME chuan Linux (vd "libz.so.1" ->
# "libz.so.1.3.1" - file that mang so hieu day du, con ten "SONAME" ma
# binary khac THAT SU can qua muc NEEDED trong ELF header lai la 1 symlink
# ngan hon). Bang chung that tren thiet bi: mariadbd bao dung linker cua
# chinh Android "library libz.so.1 not found", du zlib chac chan da duoc
# tai ve (chi la ban symlink SONAME bi "-type f" loai bo).
# Gio bat ca symlink ("-o -type l"). Voi file KHONG ket thuc dung ".so" (vd
# "libz.so.1") - build-apk.yml chi "cp *.so" nen se BO SOT tiep neu giu
# nguyen ten - doi ten sang ket thuc ".so" (thay dau "." trong ten bang "_"
# roi them ".so") de vao duoc jniLibs, DONG THOI ghi lai anh xa "ten SONAME
# that -> ten da doi" vao 1 file danh sach ("soname-map.txt", dong goi qua
# www.zip nhu mariadb-share) de start-lamp.sh tao lai dung symlink ten
# SONAME luc chay (xem bien COMPAT_DIR trong start-lamp.sh).
# SUA TIEP (xem HANDOFF.md muc 1v): ban dau moi TEN (basename) khac nhau deu
# bi COPY RIENG - nhung 1 thu vien thuong co CA CHUOI symlink cung tro ve 1
# file that (vd "libicudata.so" -> "libicudata.so.75" -> "libicudata.so.75.1",
# 3 TEN khac nhau, CUNG 1 NOI DUNG) - vi `cp` mac dinh DI THEO symlink de lay
# noi dung, moi ten khac nhau tao ra 1 BAN COPY DAY DU rieng, nhan 2-3 lan
# dung luong cho MOI thu vien co dang symlink chain nay (dac biet nang voi
# icu data cua PHP, vai chuc MB/file) - day chinh la ly do APK tu 94MB len
# 161MB chi sau 1 lan sua, dan toi loi cai dat "Ung dung chua duoc cai dat"
# (lai giong dung kieu loi da gap o muc 1m). Khu trung bang duong dan THAT
# (readlink -f, ve dung 1 file vat ly duy nhat) - NEU da copy roi (bat ke
# ten nao dua no ra) thi KHONG copy lai, chi ghi them 1 dong anh xa trong
# soname-map.txt tro ve ten da dung.
SONAME_MAP="$(mktemp)"
: > "$SONAME_MAP"
declare -A REALPATH_SEEN
while IFS= read -r -d '' f; do
  bn="$(basename "$f")"
  real="$(readlink -f "$f" 2>/dev/null || echo "$f")"
  if [[ "$bn" == *.so ]]; then target_name="$bn"; else target_name="$(echo "$bn" | tr '.' '_').so"; fi
  if [[ -n "${REALPATH_SEEN[$real]:-}" ]]; then
    existing="${REALPATH_SEEN[$real]}"
    [[ "$bn" != "$existing" ]] && echo "$bn $existing" >> "$SONAME_MAP"
    continue
  fi
  if [[ -e "$OUT_DIR/$target_name" ]]; then
    REALPATH_SEEN[$real]="$target_name"
    [[ "$bn" != "$target_name" ]] && echo "$bn $target_name" >> "$SONAME_MAP"
    continue
  fi
  cp "$f" "$OUT_DIR/$target_name" 2>/dev/null || continue
  REALPATH_SEEN[$real]="$target_name"
  [[ "$bn" != "$target_name" ]] && echo "$bn $target_name" >> "$SONAME_MAP"
done < <(find "$EXTRACT_DIR" \( -type f -o -type l \) -name '*.so*' -print0)
echo "== Thu thap extension .so cua php (mysqli.so, pdo_mysql.so, mbstring.so...) neu co =="
find "$EXTRACT_DIR" -type f -name '*.so' -path '*/php*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true

echo "== Tai wp-cli.phar (de xuat DeepSeek muc A9, xem HANDOFF.md muc 10 + muc 1ap) =="
# Truoc day (mUc HANDOFF backlog cu, xem admin-safe-mode.php) du an KHONG
# bundle WP-CLI - gio doi lai vi KHONG con can Termux repo cho rieng viec
# nay: wp-cli.phar la 1 file PHP THUAN (khong phai binary rieng nen tang) -
# tac gia WP-CLI TU phat hanh ban build san (.phar - PHP Archive, 1 file
# gom moi thu can) tren GitHub Releases, ma raw.githubusercontent.com nam
# san trong danh sach domain duoc phep cua chinh moi truong dung de soan
# script nay (da xac nhan tai duoc that trong khi soan - xem HANDOFF.md muc
# 1ap, KHAC voi php-apcu o tren van con phai xin "|| true" vi Termux repo
# khong nam trong danh sach do). "|| true" van giu de an toan (mang chap
# chon luc CI that chay).
WPCLI_URL="https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar"
WPCLI_OUT="$OUT_DIR/wp-cli.phar"
# SUA 1bc: doi chieu SHA-256 do chinh kho wp-cli/builds cong bo canh file (wp-cli.phar.sha256, da kiem tra ton tai).
# Sai hash => DUNG build; khong tai duoc file => bo qua nhu truoc (ham fetch_with_sidecar_hash tra 3).
# LUU Y: KHONG "2>/dev/null" o day - thong bao SAI HASH (stderr) phai hien ra. Hash sai => verify_file `exit 1` thang script nay.
_wpcli_rc=0
fetch_with_sidecar_hash "wp-cli.phar" "$WPCLI_URL" "${WPCLI_URL}.sha256" sha256 "$WPCLI_OUT" || _wpcli_rc=$?
if [[ $_wpcli_rc -eq 0 ]]; then
  echo "wp-cli.phar: OK ($(du -h "$WPCLI_OUT" 2>/dev/null | cut -f1))"
else
  echo "wp-cli.phar: KHONG TAI DUOC (bo qua - trang _admin/wpcli.php se tu an di neu thieu file nay)"
  rm -f "$WPCLI_OUT"
fi

# --- Chuan bi website vao staging, chen them _supervisor/ + wp-config template ---
STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"
install_site_deps php "$STAGING"   # composer install luc BUILD cho app PHP khong phai WordPress (HANDOFF.md muc 1ba)

# Ho so site (HANDOFF.md muc 1bb): docroot con (vd public/), profile wordpress|generic, ten CSDL. Loi cau hinh -> build THAT BAI ngay.
WEB_SUBDIR="$(site_docroot_subdir)" || exit 1
if [[ -n "$WEB_SUBDIR" && ! -d "$STAGING/$WEB_SUBDIR" ]]; then
  echo "LOI: site.config.json docroot=\"$WEB_SUBDIR\" nhung khong co thu muc nay trong ma nguon website" >&2
  exit 1
fi
SITE_PROFILE="$(site_resolve_profile "$STAGING")" || exit 1
DB_NAME="$(site_resolve_db_name "$SITE_PROFILE")" || exit 1
echo "== Ho so site: profile=$SITE_PROFILE, web root=./${WEB_SUBDIR}, CSDL=$DB_NAME =="
prepare_admin_tools "$STAGING" "$WEB_SUBDIR" "$SITE_PROFILE"

mkdir -p "$STAGING/_supervisor"
cp scripts/runtimes/templates/nginx.conf.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/php-fpm.conf.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/php.ini.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/router-lite.php "$STAGING/_supervisor/"
# HANDOFF.md muc 1br: tu dong chan IP do quet (start-lamp.sh goi dinh ky qua libphpcli.so) + quet ma doc/file la (admin-security.php co ban sao rieng).
cp scripts/runtimes/templates/security-guard.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/security-scan.php "$STAGING/_supervisor/"
# kiem lo hong da biet cua plugin/theme/loi (TUY CHON, mac dinh tat; HANDOFF.md muc 1br-H): supervisor chi chay khi co file lamp-run/vuln-check-on
cp scripts/runtimes/templates/security-vuln.php "$STAGING/_supervisor/"
# mu-plugin Shield (HANDOFF.md muc 1br): ban goc de start-lamp.sh dong bo vao wp-content/mu-plugins moi lan khoi dong (site WordPress CU cung duoc bao ve, khong chi site moi cai)
cp scripts/runtimes/templates/wppocket-shield-loader.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/wppocket-shield-logic.php "$STAGING/_supervisor/"
# mu-plugin dang nhap hai buoc (TOTP) tuy chon cho tung nguoi dung (HANDOFF.md muc 1br-H): cung kieu ban goc + dong bo moi lan khoi dong
cp scripts/runtimes/templates/wppocket-2fa-loader.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/wppocket-2fa-logic.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/start-lamp.sh "$STAGING/_supervisor/start-lamp.sh"
chmod 755 "$STAGING/_supervisor/start-lamp.sh"
site_write_profile_env "$STAGING" "$SITE_PROFILE" "$WEB_SUBDIR" "$DB_NAME"   # start-lamp.sh doc file nay luc chay

# --- Dong goi thu muc "share" cua MariaDB (SQL bootstrap system-tables,
# catalog thong bao loi errmsg.sys, dinh nghia charset) ---
# LY DO THEM (phat hien tu log loi that "mariadb-install-db that bai" o tren
# thiet bi that): dong copy ".so*" phia tren (dong "Thu thap toan bo .so phu
# thuoc") CHI khop ten file ket thuc ".so" - toan bo thu muc share/mariadb/
# (hoac share/mysql/ tuy ban) tai ve cung goi mariadb (nam trong $EXTRACT_DIR)
# bi BO SOT HOAN TOAN, khong dc copy vao OUT_DIR/STAGING o dau ca. Day KHONG
# phai file phu - mariadb-install-db (thuc chat goi mariadbd --bootstrap ben
# trong) doc cac file .sql nay de dung sinh system tables, VA can errmsg.sys
# chi de KHOI DONG duoc (init_errmessage() chay truoc ca buoc bootstrap) - nen
# thieu se loi NGAY LAP TUC, GIONG HET NHAU moi lan chay, bat ke RAM/retry
# (khop dung hien tuong log that: khong phai loi ngau nhien hay do trang thai
# dang do cua lan chay truoc).
# Khong the dua qua co che "lib*.so" nhu cac binary khac (build-apk.yml CHI
# "cp *.so" vao jniLibs/, khong nhan file/thu muc nao khac) - nen phai di qua
# STAGING/www.zip giong cac file cau hinh khac, roi start-lamp.sh tro
# --basedir vao day (xem sua doi tuong ung trong start-lamp.sh).
# SUA LAI (sau khi gap loi cai dat APK that - xem HANDOFF.md muc 1m): BAN DAU
# dinh copy NGUYEN CA thu muc "share" gop chung tu moi goi (nginx/php-fpm/
# mariadb/php) cho AN TOAN ten thu muc con - nhung day la doan CHUA VERIFY
# dung luong ("vai tram KB, khong dang ke" chi la UOC LUONG, khong do that).
# PHP thuong keo theo icu/gettext data (module intl/mbstring) co the nang
# TOI VAI CHUC MB trong share/, cong voi doc/man cua nginx - khong can thiet
# cho muc dich o day (chi can file cua MARIADB). Nen CHI tim va copy DUNG
# thu muc con "mariadb" (hoac "mysql") thay vi ca "share/" de tranh phinh to
# APK khong dang. Neu ten thu muc con khac 2 ten nay (chua tung thay truong
# hop nay voi goi mariadb cua Termux), se in CANH BAO ro rang thay vi am
# tham thieu.
MARIADB_SHARE_DIR="$(find "$EXTRACT_DIR" -type d \( -name mariadb -o -name mysql \) -path '*/share/*' | head -n1)"
if [[ -n "$MARIADB_SHARE_DIR" ]]; then
  DEST_NAME="$(basename "$MARIADB_SHARE_DIR")"
  mkdir -p "$STAGING/_supervisor/mariadb-share/share"
  cp -a "$MARIADB_SHARE_DIR" "$STAGING/_supervisor/mariadb-share/share/$DEST_NAME"
  SHARE_SIZE="$(du -sh "$STAGING/_supervisor/mariadb-share" 2>/dev/null | cut -f1)"
  echo "== Da dong goi $MARIADB_SHARE_DIR vao _supervisor/mariadb-share/share/$DEST_NAME (sql bootstrap + errmsg.sys + charsets cua MariaDB, dung luong: ${SHARE_SIZE:-khong ro}) =="
else
  echo "CANH BAO NGHIEM TRONG: khong tim thay thu muc con 'mariadb' hoac 'mysql' trong bat ky share/ nao cua goi da tai - mariadb-install-db se KHONG the khoi dong (thieu SQL bootstrap + errmsg.sys)" >&2
fi

# Dong goi soname-map.txt (xem chu thich o buoc "Thu thap toan bo .so phu
# thuoc" phia tren) - danh sach anh xa "ten SONAME that -> ten da doi trong
# nativeLibraryDir" de start-lamp.sh tao lai dung symlink luc chay.
cp "$SONAME_MAP" "$STAGING/_supervisor/soname-map.txt"
echo "== Da dong goi soname-map.txt ($(wc -l < "$SONAME_MAP" | tr -d ' ') anh xa thu vien .so can symlink lai dung ten SONAME luc chay) =="

# --- $MARIADB_BASEDIR/bin/ KHONG con dung o day nua (xem HANDOFF.md muc 1r)
# ---
# BAN TRUOC (muc 1p) tung COPY file that (my_print_defaults, mariadbd...)
# vao day luc build - build log bao thanh cong, nhung runtime van bao "Could
# not find my_print_defaults" HET LAN NAY DEN LAN KHAC, ke ca sau khi nguoi
# dung xac nhan ho LUON go cai dat + cai lai sach (loai bo hoan toan nghi ngo
# do cache/marker cu). Nguyen nhan that: file nam trong
# filesDir/www (noi ung dung tu ghi ra luc chay), KHONG phai nativeLibraryDir
# - Android/SELinux CO THE tu choi cho THUC THI file o day DU DA chmod +x
# day du (day chinh la ly do goc khien du an nay phai bay ra ca co che doi
# ten "lib*.so" cho MOI binary khac tu dau toi gio - xem README/HANDOFF muc
# 1a - CHỈ nativeLibraryDir moi chac chan duoc Android cho thuc thi).
# HUONG SUA MOI: dua my_print_defaults qua CHINH co che lib*.so o vong lap
# tren (thanh libmyprintdefaults.so trong nativeLibraryDir, giong 7 binary
# con lai) - roi de start-lamp.sh TAO SYMLINK luc chay (KHONG phai luc build,
# vi duong dan nativeLibraryDir doi moi lan cai dat) tu
# "$MARIADB_BASEDIR/bin/my_print_defaults" tro ve "$BIN/libmyprintdefaults.so"
# that. `test -x` cua shell theo symlink toi TARGET that (nam trong
# nativeLibraryDir, noi CHAC CHAN duoc thuc thi) nen se pass, va thuc thi qua
# symlink cung chinh la thuc thi file that o nativeLibraryDir - khong con phu
# thuoc quyen thuc thi cua file nam trong www.zip nua.

# Auto-Sleep MariaDB khi ranh (xem HANDOFF.md, tinh nang opt-in - xem
# Prefs.KEY_AUTO_SLEEP_ENABLED). wake-mariadb.sh.template + activity-touch.php
# nam trong _supervisor/ (bi chan truy cap ngoai boi nginx.conf.template, xem
# "location ^~ /_supervisor/" - CHI can doc duoc qua filesystem, khong can
# web-accessible). wake-mariadb.php thi NGUOC LAI - PHAI dat o GOC docroot
# (KHONG duoc dat trong _admin/), vi _admin/ chi cho LAN truy cap (xem
# nginx.conf.template) trong khi wake-mariadb.php can duoc kich hoat boi
# CHINH KHACH CONG KHAI (qua Cloudflare Tunnel) - dat nham vao _admin/ se
# lam tinh nang nay khong bao gio hoat dong duoc voi khach that.
cp scripts/runtimes/templates/wake-mariadb.sh.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/activity-touch.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/wake-mariadb.php "$STAGING/wake-mariadb.php"

# CA cert bundle cho PHP (curl.so + stream SSL cua file_get_contents) - can
# cho tinh nang "1-Click Install WordPress" (_admin/install-wp.php, xem
# HANDOFF.md muc 1e) goi HTTPS ra wordpress.org/api.wordpress.org. Day la
# noi DUY NHAT trong du an PHP tu goi mang ra ngoai (khac voi cloudflared,
# vi Go co co che xac thuc TLS rieng khong phu thuoc file nay) nen truoc gio
# chua can, gio moi phat sinh. Tai luc BUILD (GitHub Actions runner co
# internet + CA store that day du) thay vi luc runtime tren dien thoai.
echo "== Tai CA cert bundle cho PHP (curl/openssl) =="
# SUA 1bc: doi chieu SHA-256 curl.se cong bo (cacert.pem.sha256, dang "<hash>  cacert.pem"). Bo CA bi doi la vu khi
# MITM manh nhat (PHP se tin chung chi gia khi 1-Click Install tai WordPress). Sai hash => DUNG build.
_ca_rc=0
fetch_with_sidecar_hash "cacert.pem" "${CACERT_URL:-https://curl.se/ca/cacert.pem}" "${CACERT_URL:-https://curl.se/ca/cacert.pem}.sha256" sha256 "$STAGING/_supervisor/cacert.pem" || _ca_rc=$?
[[ $_ca_rc -eq 0 ]] || echo "CANH BAO: khong tai duoc cacert.pem - 1-Click Install WordPress co the loi SSL, cac chuc nang khac khong anh huong"

# Neu site_source.sh da tao wp-config.php.template (dung MariaDB qua socket) -> giu nguyen.
# Neu chi thay wp-config.php tinh (truong hop khong phai wordpress) -> khong dong gi them.

make_reproducible_zip "$STAGING" "$OUT_DIR/www.zip"  # tai lap duoc (HANDOFF.md muc 1ay)

PORT="$(jq -r '.port // 8080' site.config.json)"

cat > "$OUT_DIR/runtime.json" <<JSON
{
  "port": ${PORT},
  "binary": "libnginx.so",
  "docroot": "www",
  "exec": ["/system/bin/sh", "\${DOCROOT}/_supervisor/start-lamp.sh"],
  "env": {}
}
JSON

echo "Xong: $OUT_DIR (runtime=php, nginx+php-fpm+mariadb)"
