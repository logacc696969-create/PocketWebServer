#!/usr/bin/env bash
# Chuẩn bị runtime PHP "production-capable": nginx + php-fpm + MariaDB thật
# (không phải `php -S` dev server + SQLite như bản đầu) - dùng lại đúng kỹ
# thuật mượn binary Termux đã có, chỉ mượn thêm 3 gói thay vì 1.
#
# Lý do nâng cấp: `php -S` chính PHP.net ghi rõ chỉ để dev/test, xử lý tuần
# tự - nghẽn khi có vài người truy cập cùng lúc. nginx+php-fpm xử lý đồng
# thời đúng nghĩa. MariaDB thật (thay vì SQLite) giúp tương thích các plugin
# WordPress cao cấp giả định có MySQL.
#
# Đánh đổi: nặng RAM/CPU hơn bản cũ - đây là giới hạn phần cứng điện thoại
# thật, không né được bằng phần mềm (xem HANDOFF.md mục giới hạn cứng).
#
# Usage: scripts/runtimes/php.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."   # ve root repo

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh
source scripts/lib/admin_tools.sh

EXTRACT_DIR="$(mktemp -d)"

echo "== Tai php-fpm (+ Depends) =="
termux_download_with_deps php-fpm "$EXTRACT_DIR"
echo "== Tai nginx (+ Depends) =="
termux_download_with_deps nginx "$EXTRACT_DIR"
echo "== Tai mariadb (+ Depends) - co the mat vai phut, goi nang =="
termux_download_with_deps mariadb "$EXTRACT_DIR"
echo "== Tai php (goi mysqli/pdo_mysql, dam bao co du extension) =="
termux_download_with_deps php "$EXTRACT_DIR" php-mysql || true

# --- Doi ten cac binary theo quy uoc lib*.so de PackageManager cai dat thuc thi ---
find_bin() { find "$EXTRACT_DIR" -type f -path "*/bin/$1*" | head -n1; }
find_sbin() { find "$EXTRACT_DIR" -type f \( -path "*/sbin/$1*" -o -path "*/bin/$1*" \) | head -n1; }

PHP_FPM_BIN="$(find_sbin php-fpm)"
NGINX_BIN="$(find_sbin nginx)"
MARIADBD_BIN="$(find_sbin mariadbd)"
[[ -z "$MARIADBD_BIN" ]] && MARIADBD_BIN="$(find_sbin mysqld)"
MARIADB_INSTALL_BIN="$(find_bin mariadb-install-db)"
[[ -z "$MARIADB_INSTALL_BIN" ]] && MARIADB_INSTALL_BIN="$(find_bin mysql_install_db)"
MYSQL_CLI_BIN="$(find_bin mariadb)"
[[ -z "$MYSQL_CLI_BIN" ]] && MYSQL_CLI_BIN="$(find_bin mysql)"
MYSQLDUMP_BIN="$(find_bin mariadb-dump)"
[[ -z "$MYSQLDUMP_BIN" ]] && MYSQLDUMP_BIN="$(find_bin mysqldump)"
# Ten file CHINH XAC "php" (khong dung glob "php*" nhu find_bin/find_sbin -
# se vo tinh khop nham phpize/php-config/phpdbg cung nam trong bin/ cua goi
# Termux "php"). Can cho Dual-Mode PHP-Lite (`php -S`, xem HANDOFF.md muc
# 1e) - TRUOC BAN NAY chua bao gio tai binary CLI nay (du an chi dung
# php-fpm), la 1 lo hong thuc thi neu khong them dong nay.
PHP_CLI_BIN="$(find "$EXTRACT_DIR" -type f -path "*/bin/php" | head -n1)"

for pair in "PHP_FPM_BIN:libphpfpm.so" "NGINX_BIN:libnginx.so" "MARIADBD_BIN:libmariadbd.so" \
            "MARIADB_INSTALL_BIN:libmariadbinstall.so" "MYSQL_CLI_BIN:libmysqlcli.so" \
            "MYSQLDUMP_BIN:libmysqldump.so" "PHP_CLI_BIN:libphpcli.so"; do
  var="${pair%%:*}"; out_name="${pair##*:}"
  val="${!var}"
  if [[ -z "$val" ]]; then
    echo "CANH BAO: khong tim thay binary cho $var - thieu se lam start-lamp.sh loi khi chay, xem HANDOFF.md" >&2
    continue
  fi
  cp "$val" "$OUT_DIR/$out_name"
  chmod 755 "$OUT_DIR/$out_name"
done

echo "== Thu thap toan bo .so phu thuoc (openssl, pcre, sqlite, zlib, oniguruma, mysql client lib...) =="
find "$EXTRACT_DIR" -type f -name '*.so*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true
echo "== Thu thap extension .so cua php (mysqli.so, pdo_mysql.so, mbstring.so...) neu co =="
find "$EXTRACT_DIR" -type f -name '*.so' -path '*/php*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true

# --- Chuan bi website vao staging, chen them _supervisor/ + wp-config template ---
STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"
prepare_admin_tools "$STAGING"

mkdir -p "$STAGING/_supervisor"
cp scripts/runtimes/templates/nginx.conf.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/php-fpm.conf.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/php.ini.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/router-lite.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/start-lamp.sh "$STAGING/_supervisor/start-lamp.sh"
chmod 755 "$STAGING/_supervisor/start-lamp.sh"

# --- Dong goi thu muc "share" cua MariaDB (SQL bootstrap system-tables,
# catalog thong bao loi errmsg.sys, dinh nghia charset) ---
# LY DO THEM (phat hien tu log loi that "mariadb-install-db that bai" o tren
# thiet bi that): dong copy ".so*" phia tren (dong "Thu thap toan bo .so phu
# thuoc") CHI khop ten file ket thuc ".so" - toan bo thu muc share/mariadb/
# (hoac share/mysql/ tuy ban) tai ve cung goi mariadb (nam trong $EXTRACT_DIR)
# bi BO SOT HOAN TOAN, khong dc copy vao OUT_DIR/STAGING o dau ca. Day KHONG
# phai file phu - mariadb-install-db (thuc chat goi mariadbd --bootstrap ben
# trong) doc cac file .sql nay de dung sinh system tables, VA can errmsg.sys
# chi de KHOI DONG duoc (init_errmessage() chay truoc ca buoc bootstrap) - nen
# thieu se loi NGAY LAP TUC, GIONG HET NHAU moi lan chay, bat ke RAM/retry
# (khop dung hien tuong log that: khong phai loi ngau nhien hay do trang thai
# dang do cua lan chay truoc).
# Khong the dua qua co che "lib*.so" nhu cac binary khac (build-apk.yml CHI
# "cp *.so" vao jniLibs/, khong nhan file/thu muc nao khac) - nen phai di qua
# STAGING/www.zip giong cac file cau hinh khac, roi start-lamp.sh tro
# --basedir vao day (xem sua doi tuong ung trong start-lamp.sh).
# SUA LAI (sau khi gap loi cai dat APK that - xem HANDOFF.md muc 1m): BAN DAU
# dinh copy NGUYEN CA thu muc "share" gop chung tu moi goi (nginx/php-fpm/
# mariadb/php) cho AN TOAN ten thu muc con - nhung day la doan CHUA VERIFY
# dung luong ("vai tram KB, khong dang ke" chi la UOC LUONG, khong do that).
# PHP thuong keo theo icu/gettext data (module intl/mbstring) co the nang
# TOI VAI CHUC MB trong share/, cong voi doc/man cua nginx - khong can thiet
# cho muc dich o day (chi can file cua MARIADB). Nen CHI tim va copy DUNG
# thu muc con "mariadb" (hoac "mysql") thay vi ca "share/" de tranh phinh to
# APK khong dang. Neu ten thu muc con khac 2 ten nay (chua tung thay truong
# hop nay voi goi mariadb cua Termux), se in CANH BAO ro rang thay vi am
# tham thieu.
MARIADB_SHARE_DIR="$(find "$EXTRACT_DIR" -type d \( -name mariadb -o -name mysql \) -path '*/share/*' | head -n1)"
if [[ -n "$MARIADB_SHARE_DIR" ]]; then
  DEST_NAME="$(basename "$MARIADB_SHARE_DIR")"
  mkdir -p "$STAGING/_supervisor/mariadb-share/share"
  cp -a "$MARIADB_SHARE_DIR" "$STAGING/_supervisor/mariadb-share/share/$DEST_NAME"
  SHARE_SIZE="$(du -sh "$STAGING/_supervisor/mariadb-share" 2>/dev/null | cut -f1)"
  echo "== Da dong goi $MARIADB_SHARE_DIR vao _supervisor/mariadb-share/share/$DEST_NAME (sql bootstrap + errmsg.sys + charsets cua MariaDB, dung luong: ${SHARE_SIZE:-khong ro}) =="
else
  echo "CANH BAO NGHIEM TRONG: khong tim thay thu muc con 'mariadb' hoac 'mysql' trong bat ky share/ nao cua goi da tai - mariadb-install-db se KHONG the khoi dong (thieu SQL bootstrap + errmsg.sys)" >&2
fi

# Auto-Sleep MariaDB khi ranh (xem HANDOFF.md, tinh nang opt-in - xem
# Prefs.KEY_AUTO_SLEEP_ENABLED). wake-mariadb.sh.template + activity-touch.php
# nam trong _supervisor/ (bi chan truy cap ngoai boi nginx.conf.template, xem
# "location ^~ /_supervisor/" - CHI can doc duoc qua filesystem, khong can
# web-accessible). wake-mariadb.php thi NGUOC LAI - PHAI dat o GOC docroot
# (KHONG duoc dat trong _admin/), vi _admin/ chi cho LAN truy cap (xem
# nginx.conf.template) trong khi wake-mariadb.php can duoc kich hoat boi
# CHINH KHACH CONG KHAI (qua Cloudflare Tunnel) - dat nham vao _admin/ se
# lam tinh nang nay khong bao gio hoat dong duoc voi khach that.
cp scripts/runtimes/templates/wake-mariadb.sh.template "$STAGING/_supervisor/"
cp scripts/runtimes/templates/activity-touch.php "$STAGING/_supervisor/"
cp scripts/runtimes/templates/wake-mariadb.php "$STAGING/wake-mariadb.php"

# CA cert bundle cho PHP (curl.so + stream SSL cua file_get_contents) - can
# cho tinh nang "1-Click Install WordPress" (_admin/install-wp.php, xem
# HANDOFF.md muc 1e) goi HTTPS ra wordpress.org/api.wordpress.org. Day la
# noi DUY NHAT trong du an PHP tu goi mang ra ngoai (khac voi cloudflared,
# vi Go co co che xac thuc TLS rieng khong phu thuoc file nay) nen truoc gio
# chua can, gio moi phat sinh. Tai luc BUILD (GitHub Actions runner co
# internet + CA store that day du) thay vi luc runtime tren dien thoai.
echo "== Tai CA cert bundle cho PHP (curl/openssl) =="
curl -fsSL https://curl.se/ca/cacert.pem -o "$STAGING/_supervisor/cacert.pem" \
  || echo "CANH BAO: khong tai duoc cacert.pem - 1-Click Install WordPress co the loi SSL, cac chuc nang khac khong anh huong"

# Neu site_source.sh da tao wp-config.php.template (dung MariaDB qua socket) -> giu nguyen.
# Neu chi thay wp-config.php tinh (truong hop khong phai wordpress) -> khong dong gi them.

(cd "$STAGING" && zip -qr "$OLDPWD/$OUT_DIR/www.zip" .)

PORT="$(jq -r '.port // 8080' site.config.json)"

cat > "$OUT_DIR/runtime.json" <<JSON
{
  "port": ${PORT},
  "binary": "libnginx.so",
  "docroot": "www",
  "exec": ["/system/bin/sh", "\${DOCROOT}/_supervisor/start-lamp.sh"],
  "env": {}
}
JSON

echo "Xong: $OUT_DIR (runtime=php, nginx+php-fpm+mariadb)"
