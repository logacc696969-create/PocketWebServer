<?php
/**
 * Object cache drop-in dung APCu - de xuat DeepSeek muc I4 (xem HANDOFF.md
 * muc 10 + muc 1as). PHAT HIEN KHI SOAT LAI: vong truoc (muc 1aq) MOI chi
 * BAT extension apcu.so trong php.ini - nhung CHI bat extension KHONG DU de
 * WordPress THAT SU dung APCu, can THEM file nay (drop-in chinh thuc cua
 * WordPress, tu dong nap truoc moi plugin khi dat dung ten
 * "wp-content/object-cache.php") de noi cac ham wp_cache_*() ma WordPress
 * core/plugin goi, toi APCu - neu khong co file nay, APCu "bat nhung khong
 * ai dung toi", khong co loi ich thuc te nao.
 *
 * DA TAI WordPress core THAT (nhanh "trunk" tu
 * github.com/WordPress/wordpress-develop, qua git clone - domain
 * github.com nam san trong danh sach duoc phep cua moi truong soan file
 * nay) de tra cuu CHINH XAC danh sach ham can cai dat
 * (wp-includes/cache.php) va cach WordPress core TU GOI
 * wp_cache_add_non_persistent_groups(array('counts','plugins','theme_json'))
 * (wp-includes/load.php) - khong doan ten/chu ky ham. KHONG dung
 * multisite (du an nay da tu choi multisite - xem HANDOFF.md muc 6) nen BO
 * QUA global_groups (chi co y nghia khi nhieu blog chia se 1 cache).
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Object_Cache
{
    /** Cache runtime (trong 1 request) - luon dung lam lop DAU TIEN truoc
     * khi hoi toi APCu, giong dung thiet ke cua WP_Object_Cache GOC (ngay
     * ca ban KHONG co drop-in cung co 1 lop nay) - tranh goi apcu_fetch()
     * nhieu lan thua cho CUNG 1 key trong CUNG 1 request. */
    private $cache = [];
    private $nonPersistentGroups = [];
    private $cacheHits = 0;
    private $cacheMisses = 0;
    private $apcuAvailable;
    private $prefix;

    public function __construct()
    {
        // apcu_enabled() kiem tra CA extension da nap LAN apc.enabled=1
        // dang bat (khac voi chi function_exists - extension co the nap
        // nhung apc.enabled=0, xem php.ini.template) - tranh goi
        // apcu_fetch()/apcu_store() khi thuc ra khong dung duoc, se loi
        // "Call to undefined function" NEU extension khong nap, hoac tra ve
        // false/khong luu NEU co nap nhung dang tat.
        $this->apcuAvailable = function_exists('apcu_enabled') && apcu_enabled();
        // Tien to theo ABSPATH: site LIVE va site STAGING (xem admin-
        // staging.php, de xuat DeepSeek muc A10) CHAY CHUNG 1 pool php-fpm,
        // tuc la CHUNG 1 vung nho APCu shared memory - KHONG co tien to
        // rieng, cache cua staging co the LAN sang live (hoac nguoc lai),
        // gay nham lan du lieu kho phat hien. ABSPATH khac nhau giua 2 site
        // (duong dan docroot khac nhau) nen md5(ABSPATH) la 1 cach re tien
        // de tach biet.
        $this->prefix = 'wppocket_' . substr(md5((string) ABSPATH), 0, 12) . ':';
        $this->syncEpoch();
    }

    /**
     * VO HIEU HOA CACHE KHI DU LIEU DUOC GHI TU NGOAI POOL PHP-FPM (HANDOFF.md muc 1bd).
     *
     * LOI THAT (chi lo ra khi co apcu.so + drop-in nay - CI truoc 1bd khong cai php-apcu nen khong bao gio thay):
     * APCu la bo nho chia se cua RIENG nhom tien trinh php-fpm. Khi du lieu WordPress bi doi boi 1 tien trinh KHAC
     * (WP-CLI chay bang CLI, Adminer ghi SQL thang, khoi phuc backup nhap SQL vao MariaDB dang chay, promote staging
     * dung SQL) thi WordPress phia php-fpm KHONG biet de xoa cache - ma phan lon muc cache cua WordPress het han = 0
     * (khong bao gio tu het) => site hien DU LIEU CU cho toi khi php-fpm khoi dong lai. Tai hien bang test that:
     * tao bai viet bang tien trinh CLI roi mo trang chu (khong thay bai), doi siteurl bang SQL (van redirect ve URL cu),
     * promote staging (trang LIVE khong doi), WP-Cron qua han khong chay.
     *
     * CO CHE: moi ben ghi du lieu tu ngoai (trang wpcli/staging/rollback/safe-mode, POST cua Adminer, Kotlin khi khoi
     * phuc backup) ghi 1 chuoi DUY NHAT moi vao lamp-run/object-cache-epoch. Moi request, tai day, so chuoi do voi gia
     * tri da thay (luu trong chinh APCu); khac => apcu_clear_cache() 1 lan. Chi phi moi request: doc 1 file vai chuc byte.
     * Khong co APP_HOME / chua tung co file => khong lam gi (giu hanh vi cu).
     */
    private function syncEpoch()
    {
        if (!$this->apcuAvailable) {
            return;
        }
        $home = getenv('APP_HOME');
        if (!$home) {
            return;
        }
        $raw = @file_get_contents(rtrim($home, '/') . '/lamp-run/object-cache-epoch');
        if ($raw === false) {
            return;   // chua tung co ben nao bao hieu => khong co gi de vo hieu hoa
        }
        $epoch = trim($raw);
        $ok = false;
        $seen = apcu_fetch('wppocket_epoch_seen', $ok);
        if ($ok && $seen === $epoch) {
            return;
        }
        apcu_clear_cache();                          // xoa TOAN BO (pool php-fpm la RIENG cua app - xem flush())
        apcu_store('wppocket_epoch_seen', $epoch);   // sau khi xoa, de request ke tiep khong xoa lai
    }

    private function key($key, $group)
    {
        $group = $group !== '' ? $group : 'default';
        return $this->prefix . $group . ':' . $key;
    }

    private function isPersistent($group)
    {
        return $this->apcuAvailable && !in_array($group, $this->nonPersistentGroups, true);
    }

    public function add($key, $data, $group = '', $expire = 0)
    {
        $group = $group !== '' ? $group : 'default';
        $ck = $this->key($key, $group);
        if ($this->isPersistent($group)) {
            // apcu_add() CHI luu neu key CHUA ton tai (dung ngu nghia
            // "add" cua WordPress - khac "set" la luon ghi de) - tra ve
            // false neu da ton tai, khop dung API WordPress mong doi.
            $ok = apcu_add($ck, $data, (int) $expire);
            if ($ok) {
                $this->cache[$ck] = $data;
            }
            return $ok;
        }
        if (array_key_exists($ck, $this->cache)) {
            return false;
        }
        $this->cache[$ck] = $data;
        return true;
    }

    public function replace($key, $data, $group = '', $expire = 0)
    {
        $found = null;
        $this->get($key, $group, true, $found);
        if (!$found) {
            return false;
        }
        return $this->set($key, $data, $group, $expire);
    }

    public function set($key, $data, $group = '', $expire = 0)
    {
        $group = $group !== '' ? $group : 'default';
        $ck = $this->key($key, $group);
        $this->cache[$ck] = $data;
        if ($this->isPersistent($group)) {
            apcu_store($ck, $data, (int) $expire);
        }
        return true;
    }

    public function get($key, $group = '', $force = false, &$found = null)
    {
        $group = $group !== '' ? $group : 'default';
        $ck = $this->key($key, $group);

        if (!$force && array_key_exists($ck, $this->cache)) {
            $found = true;
            $this->cacheHits++;
            return $this->cache[$ck];
        }

        if ($this->isPersistent($group)) {
            $success = false;
            $value = apcu_fetch($ck, $success);
            if ($success) {
                $this->cache[$ck] = $value;
                $found = true;
                $this->cacheHits++;
                return $value;
            }
        }

        $found = false;
        $this->cacheMisses++;
        return false;
    }

    public function delete($key, $group = '')
    {
        $group = $group !== '' ? $group : 'default';
        $ck = $this->key($key, $group);
        unset($this->cache[$ck]);
        if ($this->apcuAvailable) {
            apcu_delete($ck);
        }
        return true;
    }

    public function incr($key, $offset = 1, $group = '')
    {
        $group = $group !== '' ? $group : 'default';
        $found = null;
        $value = $this->get($key, $group, true, $found);
        if (!$found || !is_numeric($value)) {
            return false;
        }
        $value = max(0, (int) $value + (int) $offset);
        $this->set($key, $value, $group);
        return $value;
    }

    public function decr($key, $offset = 1, $group = '')
    {
        return $this->incr($key, -abs((int) $offset), $group);
    }

    public function flush()
    {
        $this->cache = [];
        if ($this->apcuAvailable) {
            // apcu_clear_cache() xoa TOAN BO vung nho APCu - khong chi
            // tien to cua app nay. AN TOAN o day vi pool php-fpm nay la
            // RIENG cho app (khong chia se voi web nao khac tren may), xem
            // php-fpm.conf.template - khac voi 1 may chu chia se nhieu
            // site qua 1 pool chung (khong phai truong hop cua du an nay).
            apcu_clear_cache();
        }
        return true;
    }

    public function flush_runtime()
    {
        $this->cache = [];
        return true;
    }

    public function flush_group($group)
    {
        // APCu KHONG co "xoa theo tien to" built-in re tien (phai duyet
        // toan bo APCUIterator, ton kem) - don gian hoa: coi nhu KHONG ho
        // tro flush theo tung group rieng (tra ve false, giong
        // wp_cache_supports_group_flush() = false ben duoi) - WordPress tu
        // biet dung flush() toan bo hoac tu quan ly key rieng khi can, day
        // la hanh vi HOP LE theo dung tai lieu WordPress (nhieu drop-in that
        // nhu Memcached cung khong ho tro tinh nang nay).
        return false;
    }

    public function supports($feature)
    {
        if ($feature === 'flush_group') {
            return false;
        }
        return false;
    }

    public function add_global_groups($groups)
    {
        // Khong xu ly - du an nay KHONG multisite (xem HANDOFF.md muc 6),
        // global_groups chi co y nghia khi nhieu blog chia se 1 cache.
    }

    public function add_non_persistent_groups($groups)
    {
        $groups = (array) $groups;
        $this->nonPersistentGroups = array_unique(array_merge($this->nonPersistentGroups, $groups));
    }

    public function switch_to_blog($blog_id)
    {
        // Khong multisite - khong lam gi (khop hanh vi "khong ho tro" hop
        // le theo tai lieu WordPress).
    }

    public function close()
    {
        return true;
    }

    public function stats()
    {
        return ['hits' => $this->cacheHits, 'misses' => $this->cacheMisses, 'apcu' => $this->apcuAvailable];
    }
}

global $wp_object_cache;
$wp_object_cache = new WP_Object_Cache();

function wp_cache_init()
{
    global $wp_object_cache;
    if (!($wp_object_cache instanceof WP_Object_Cache)) {
        $wp_object_cache = new WP_Object_Cache();
    }
}

function wp_cache_add($key, $data, $group = '', $expire = 0)
{
    global $wp_object_cache;
    return $wp_object_cache->add($key, $data, $group, $expire);
}

function wp_cache_add_multiple(array $data, $group = '', $expire = 0)
{
    $values = [];
    foreach ($data as $key => $value) {
        $values[$key] = wp_cache_add($key, $value, $group, $expire);
    }
    return $values;
}

function wp_cache_replace($key, $data, $group = '', $expire = 0)
{
    global $wp_object_cache;
    return $wp_object_cache->replace($key, $data, $group, $expire);
}

function wp_cache_set($key, $data, $group = '', $expire = 0)
{
    global $wp_object_cache;
    return $wp_object_cache->set($key, $data, $group, $expire);
}

function wp_cache_set_multiple(array $data, $group = '', $expire = 0)
{
    $values = [];
    foreach ($data as $key => $value) {
        $values[$key] = wp_cache_set($key, $value, $group, $expire);
    }
    return $values;
}

function wp_cache_get($key, $group = '', $force = false, &$found = null)
{
    global $wp_object_cache;
    return $wp_object_cache->get($key, $group, $force, $found);
}

function wp_cache_get_multiple($keys, $group = '', $force = false)
{
    $values = [];
    foreach ($keys as $key) {
        $values[$key] = wp_cache_get($key, $group, $force);
    }
    return $values;
}

function wp_cache_delete($key, $group = '')
{
    global $wp_object_cache;
    return $wp_object_cache->delete($key, $group);
}

function wp_cache_delete_multiple(array $keys, $group = '')
{
    $values = [];
    foreach ($keys as $key) {
        $values[$key] = wp_cache_delete($key, $group);
    }
    return $values;
}

function wp_cache_incr($key, $offset = 1, $group = '')
{
    global $wp_object_cache;
    return $wp_object_cache->incr($key, $offset, $group);
}

function wp_cache_decr($key, $offset = 1, $group = '')
{
    global $wp_object_cache;
    return $wp_object_cache->decr($key, $offset, $group);
}

function wp_cache_flush()
{
    global $wp_object_cache;
    return $wp_object_cache->flush();
}

function wp_cache_flush_runtime()
{
    global $wp_object_cache;
    return $wp_object_cache->flush_runtime();
}

function wp_cache_flush_group($group)
{
    global $wp_object_cache;
    return $wp_object_cache->flush_group($group);
}

function wp_cache_supports($feature)
{
    global $wp_object_cache;
    return $wp_object_cache->supports($feature);
}

function wp_cache_close()
{
    global $wp_object_cache;
    return $wp_object_cache->close();
}

function wp_cache_add_global_groups($groups)
{
    global $wp_object_cache;
    $wp_object_cache->add_global_groups($groups);
}

function wp_cache_add_non_persistent_groups($groups)
{
    global $wp_object_cache;
    $wp_object_cache->add_non_persistent_groups($groups);
}

function wp_cache_switch_to_blog($blog_id)
{
    global $wp_object_cache;
    $wp_object_cache->switch_to_blog($blog_id);
}
