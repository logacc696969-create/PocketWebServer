<?php
// Quan ly phien dang nhap _admin/ - HANDOFF.md muc 1bc (PDF "chat luong tinh phi" G2: danh sach thiet bi, thu hoi, dang xuat).
// Co che so dang ky + dau van tay mat khau nam trong auth.php (xem chu thich dai o do). Trang nay chi la giao dien:
//   * Xem cac phien dang hoat dong (IP, trinh duyet, dang nhap luc nao, hoat dong lan cuoi) - phien HIEN TAI duoc danh dau.
//   * Thu hoi 1 phien; "Dang xuat cac thiet bi khac"; "Dang xuat" (phien hien tai).
// Thu hoi = xoa muc khoi so: phien do bi huy o REQUEST KE TIEP cua no (khong cham vao file phien PHP).
// Doi mat khau (trong app Android) huy TAT CA phien ma khong can bam gi o day.
require __DIR__ . '/auth.php';

/** Rut gon User-Agent thanh "Chrome tren Android" - chi de nguoi dung nhan ra thiet bi, khong can chinh xac tuyet doi. */
function wp_pocket_ua_label(string $ua): string
{
    if ($ua === '') return 'Khong ro';
    $os = 'Khong ro he dieu hanh';
    foreach (['Android' => 'Android', 'iPhone' => 'iPhone', 'iPad' => 'iPad', 'Windows' => 'Windows', 'Macintosh' => 'macOS', 'CrOS' => 'ChromeOS', 'Linux' => 'Linux'] as $needle => $label) {
        if (stripos($ua, $needle) !== false) { $os = $label; break; }
    }
    $browser = 'Trinh duyet khac';
    foreach (['Edg/' => 'Edge', 'OPR/' => 'Opera', 'Firefox/' => 'Firefox', 'Chrome/' => 'Chrome', 'CriOS/' => 'Chrome', 'Safari/' => 'Safari'] as $needle => $label) {
        if (strpos($ua, $needle) !== false) { $browser = $label; break; }
    }
    return $browser . ' tren ' . $os;
}

function wp_pocket_ago(int $ts): string
{
    $d = max(0, time() - $ts);
    if ($d < 90) return $d . ' giay truoc';
    if ($d < 5400) return (int) round($d / 60) . ' phut truoc';
    return (int) round($d / 3600) . ' gio truoc';
}

$message = '';
$error = '';
$myTag = (string) ($_SESSION['wp_pocket_tag'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    if (!wp_pocket_csrf_verify()) {
        $error = 'Token bao mat (CSRF) khong hop le hoac da het han - tai lai trang va thu lai.';
    } elseif ($action === 'logout') {
        // Xoa muc cua phien hien tai khoi so (neu co) roi huy phien PHP + cookie.
        if ($myTag !== '' && $myTag !== '-') {
            wp_pocket_sessions_mutate(function (array $r) use ($myTag) { unset($r[$myTag]); return $r; });
        }
        wp_pocket_session_audit('dang xuat');
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $cp = session_get_cookie_params();
            setcookie(session_name(), '', time() - 3600, $cp['path'], $cp['domain'], $cp['secure'], $cp['httponly']);
        }
        session_destroy();
        header('Location: index.php');
        exit;
    } elseif ($action === 'revoke') {
        $tag = (string) ($_POST['tag'] ?? '');
        if (!preg_match('/^[0-9a-f]{16}$/', $tag)) {
            $error = 'Ma phien khong hop le.';
        } elseif ($tag === $myTag) {
            $error = 'Day la phien cua chinh ban - dung nut "Dang xuat" de thoat.';
        } else {
            $found = false;
            $ok = wp_pocket_sessions_mutate(function (array $r) use ($tag, &$found) {
                if (isset($r[$tag])) { $found = true; unset($r[$tag]); }
                return $r;
            });
            if (!$ok) {
                $error = 'Khong ghi duoc so phien (kiem tra dung luong/quyen ghi filesDir).';
            } elseif ($found) {
                wp_pocket_session_audit('thu hoi phien ' . substr($tag, 0, 6));
                $message = 'Da thu hoi phien. Thiet bi do se bi dang xuat o lan bam ke tiep.';
            } else {
                $message = 'Phien nay da het han hoac da bi thu hoi truoc do.';
            }
        }
    } elseif ($action === 'revoke_others') {
        $count = 0;
        $ok = wp_pocket_sessions_mutate(function (array $r) use ($myTag, &$count) {
            foreach (array_keys($r) as $t) { if ($t !== $myTag) { unset($r[$t]); $count++; } }
            return $r;
        });
        if (!$ok) {
            $error = 'Khong ghi duoc so phien (kiem tra dung luong/quyen ghi filesDir).';
        } else {
            wp_pocket_session_audit('thu hoi tat ca phien khac (' . $count . ')');
            $message = $count > 0 ? "Da dang xuat $count thiet bi khac." : 'Khong co thiet bi nao khac dang dang nhap.';
        }
    }
}

$sessions = wp_pocket_sessions_read();
uasort($sessions, fn($a, $b) => ((int) ($b['last'] ?? 0)) <=> ((int) ($a['last'] ?? 0)));
$unregistered = ($myTag === '-');   // luc dang nhap khong ghi duoc so (xem auth.php)
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Phien dang nhap</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:620px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
p.hint{color:#666;font-size:14px;line-height:1.5}
.msg{padding:10px 14px;border-radius:8px;margin:12px 0;font-size:14px}
.msg.ok{background:#e9f7ef;color:#1d7a3d}
.msg.err{background:#fdecea;color:#a11a0e}
.row{border:1px solid #ddd;border-radius:10px;padding:12px 14px;margin:10px 0;display:flex;gap:12px;align-items:center;justify-content:space-between}
.row.me{border-color:#21759B;background:#eef6fb}
.row b{display:block;font-size:15px}
.row span{display:block;color:#666;font-size:13px;margin-top:2px;word-break:break-all}
.badge{display:inline-block;background:#21759B;color:#fff;border-radius:6px;padding:1px 7px;font-size:12px;margin-left:6px;font-weight:600}
button{padding:10px 14px;border:0;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;color:#fff;background:#c0392b}
button.neutral{background:#555}
.actions{display:flex;gap:10px;margin-top:18px}
.actions form{flex:1}
.actions button{width:100%;padding:13px}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Phien dang nhap _admin/</h1>
<p class="hint">Cac thiet bi dang dang nhap trang quan tri. Neu thay thiet bi la, bam "Thu hoi". Doi mat khau quan tri trong app se dang xuat TAT CA thiet bi.</p>

<?php if ($message !== ''): ?><div class="msg ok"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($error !== ''): ?><div class="msg err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($unregistered): ?>
<div class="msg err">Phien hien tai khong duoc ghi vao so (khong ghi duoc file - co the day bo nho), nen khong the thu hoi tu xa. Dang xuat roi dang nhap lai sau khi don dep.</div>
<?php endif; ?>

<?php if (!$sessions): ?><p class="hint">Chua co phien nao trong so.</p><?php endif; ?>
<?php foreach ($sessions as $tag => $row): $isMe = ((string) $tag === $myTag); ?>
<div class="row<?= $isMe ? ' me' : '' ?>">
    <div>
        <b><?= htmlspecialchars(wp_pocket_ua_label((string) ($row['ua'] ?? '')), ENT_QUOTES, 'UTF-8') ?><?= $isMe ? '<span class="badge">Thiet bi nay</span>' : '' ?></b>
        <span>IP <?= htmlspecialchars((string) ($row['ip'] ?? '?'), ENT_QUOTES, 'UTF-8') ?> &middot; dang nhap luc <?= htmlspecialchars(date('H:i d/m', (int) ($row['since'] ?? 0)), ENT_QUOTES, 'UTF-8') ?> &middot; hoat dong <?= htmlspecialchars(wp_pocket_ago((int) ($row['last'] ?? 0)), ENT_QUOTES, 'UTF-8') ?></span>
    </div>
    <?php if (!$isMe): ?>
    <form method="post">
        <?= wp_pocket_csrf_field() ?>
        <input type="hidden" name="action" value="revoke">
        <input type="hidden" name="tag" value="<?= htmlspecialchars((string) $tag, ENT_QUOTES, 'UTF-8') ?>">
        <button type="submit">Thu hoi</button>
    </form>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<div class="actions">
    <form method="post"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="revoke_others"><button type="submit">Dang xuat cac thiet bi khac</button></form>
    <form method="post"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="logout"><button type="submit" class="neutral">Dang xuat</button></form>
</div>
</body>
</html>
