<?php
/**
 * WP Pocket - toi uu anh khi tai len (PDF 2 muc I4; HANDOFF.md muc 1bq-I). Tuong thich PHP 7.4+ (khong dung match, ?->, kieu hop).
 *
 * Cau hinh (tuy chon) bang hang so trong wp-config.php; gia tri ngoai khoang bi KEP, gia tri la bi bo qua (dung mac dinh):
 *   WPP_IMG_MAX_PX        1920   canh dai toi da cua anh HIEN THI (1024..4096). WordPress co san 2560.
 *   WPP_IMG_QUALITY       82     chat luong JPEG cua cac kich thuoc phu (40..95)
 *   WPP_IMG_WEBP_QUALITY  80     chat luong WebP (40..95)
 *   WPP_IMG_WEBP          true   tao kich thuoc phu dang WebP cho anh JPEG moi tai len (neu may chu ho tro WebP)
 *   WPP_IMG_DROP_ORIGINAL false  XOA ban goc cuc lon sau khi da co ban thu nho (TIET KIEM o dia nhung MAT anh goc - mac dinh TAT)
 * Chi ap dung cho anh tai len SAU khi bat; khong chuyen doi anh cu.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('wpp_img_int')) {
    /** Doc hang so so nguyen, kep vao [min, max]; khong dinh nghia hoac sai kieu -> $default. */
    function wpp_img_int($name, $default, $min, $max)
    {
        $v = defined($name) ? constant($name) : $default;
        if (!is_int($v) && !(is_string($v) && ctype_digit($v))) {
            return $default;
        }
        $v = (int) $v;
        if ($v < $min) {
            return $min;
        }
        if ($v > $max) {
            return $max;
        }
        return $v;
    }
}

if (!function_exists('wpp_img_flag')) {
    /** Doc hang so bat/tat. Chi true/1/'1' la bat; false/0/'0'/gia tri la -> tat (tru khi khong dinh nghia: $default). */
    function wpp_img_flag($name, $default)
    {
        if (!defined($name)) {
            return $default;
        }
        $v = constant($name);
        return $v === true || $v === 1 || $v === '1';
    }
}

// 1) Gioi han kich thuoc anh hien thi (mac dinh WordPress 2560 la qua lon cho dien thoai).
add_filter('big_image_size_threshold', function ($threshold) {
    return wpp_img_int('WPP_IMG_MAX_PX', 1920, 1024, 4096);
}, 20);

// 2) Chat luong nen cho cac kich thuoc phu.
add_filter('wp_editor_set_quality', function ($quality, $mime_type = '') {
    if ($mime_type === 'image/webp') {
        return wpp_img_int('WPP_IMG_WEBP_QUALITY', 80, 40, 95);
    }
    if ($mime_type === 'image/jpeg') {
        return wpp_img_int('WPP_IMG_QUALITY', 82, 40, 95);
    }
    return $quality;
}, 20, 2);

// 3) Anh JPEG moi tai len -> cac kich thuoc phu dang WebP (chi khi may chu thuc su ho tro WebP; khong thi giu nguyen).
add_filter('image_editor_output_format', function ($formats, $filename = '', $mime_type = '') {
    if (!wpp_img_flag('WPP_IMG_WEBP', true)) {
        return $formats;
    }
    if (!function_exists('wp_image_editor_supports') || !wp_image_editor_supports(array('mime_type' => 'image/webp'))) {
        return $formats;
    }
    if (!is_array($formats)) {
        $formats = array();
    }
    if (!isset($formats['image/jpeg'])) {
        $formats['image/jpeg'] = 'image/webp';
    }
    return $formats;
}, 20, 3);

// 4) TUY CHON (mac dinh TAT): xoa ban goc qua lon sau khi WordPress da tao ban thu nho "-scaled". Mat anh goc!
add_filter('wp_generate_attachment_metadata', function ($metadata, $attachment_id = 0) {
    if (!wpp_img_flag('WPP_IMG_DROP_ORIGINAL', false)) {
        return $metadata;
    }
    if (!is_array($metadata) || empty($metadata['original_image']) || empty($metadata['file'])) {
        return $metadata;
    }
    $original = (string) $metadata['original_image'];
    if ($original !== basename($original) || $original === basename((string) $metadata['file'])) {
        return $metadata; // ten co duong dan, hoac ban "scaled" chinh la ban goc: khong dung vao
    }
    $uploads = wp_get_upload_dir();
    $base = rtrim($uploads['basedir'], '/');
    $scaled = $base . '/' . $metadata['file'];
    $orig_path = $base . '/' . dirname((string) $metadata['file']) . '/' . $original;
    if (file_exists($scaled) && file_exists($orig_path)) {
        wp_delete_file($orig_path);
        unset($metadata['original_image']);
    }
    return $metadata;
}, 30, 2);
