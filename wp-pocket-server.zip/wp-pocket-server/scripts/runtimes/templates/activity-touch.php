<?php
/**
 * Chi lam 1 viec DUY NHAT: cap nhat mtime cua "last-php-activity" moi khi co
 * request PHP that (tuc la request CAN MariaDB) - dung boi Auto-Sleep (xem
 * start-lamp.sh) de biet website "ranh" bao lau. Duoc nap TU DONG qua
 * auto_prepend_file trong php.ini (CHI KHI AUTO_SLEEP_ENABLED=1 - xem
 * php.ini.template) - KHONG anh huong gi neu tinh nang nay dang tat.
 *
 * CO Y khong ghi NOI DUNG gi vao file (touch() chi cap nhat mtime, re hon
 * nhieu so ghi 1 dong log moi request) - xem chu thich trong start-lamp.sh
 * ve ly do khong dung access_log lam nguon tin cho viec nay (buffer=...
 * flush=5m cua nginx lam tre toi 5 phut, con ghi khong buffer thi tang hao
 * mon flash - ca 2 deu khong hop voi Auto-Sleep can biet "ranh" trong vai
 * chuc giay-vai phut).
 *
 * KHONG duoc throw loi/warning du bat ky ly do gi (thieu quyen ghi, het
 * dung luong...) - day la script PHU, KHONG duoc lam gian doan hay lam
 * chậm trang chinh cua nguoi dung dang truy cap.
 */
$activityFile = (getenv('APP_HOME') ?: '') . '/lamp-run/last-php-activity';
@touch($activityFile);
