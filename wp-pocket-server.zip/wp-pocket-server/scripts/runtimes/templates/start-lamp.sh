#!/system/bin/sh
# Chạy bằng /system/bin/sh có sẵn trên mọi máy Android - không cần bash.
#
# Sinh config thật từ template (thay __PLACEHOLDER__ bằng đường dẫn thật của
# THIẾT BỊ NÀY - không biết trước lúc CI build vì mỗi máy cài app ở một
# nativeLibraryDir/filesDir khác nhau).
#
# Tự quyết định chạy ở 2 CHẾ ĐỘ (xem HANDOFF.md mục 1e "Dual-Mode PHP-Lite"):
#   - full: nginx + php-fpm + MariaDB thật (mặc định, máy bình thường trở lên)
#   - lite: `php -S` (built-in server) đơn lẻ + SQLite thay MariaDB (máy quá
#     yếu RAM - đánh đổi hiệu năng chịu tải lấy sự ổn định, xem README/
#     HANDOFF.md mục 1e để biết rõ đánh đổi này)
# Quyết định này CHỈ XẢY RA 1 LẦN DUY NHẤT lúc setup đầu tiên (ghi vào
# $DATA/.runtime-mode), CÁC LẦN SAU LUÔN GIỮ NGUYÊN - tránh nguy cơ đổi hạ
# tầng CSDL của 1 site ĐANG CHẠY THẬT (vd từ MariaDB thật sang SQLite giữa
# chừng sẽ làm WordPress mất kết nối database).
set -e

BIN="$LD_LIBRARY_PATH"    # noi chua tat ca binary da tai: libmariadbd.so, libphpfpm.so, libnginx.so, libphpcli.so...
DATA="$HOME"               # filesDir cua app - noi duy nhat ghi duoc
DOCROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"   # thu muc www (cha cua _supervisor)
SUP="$DOCROOT/_supervisor"
RUNDIR="$DATA/lamp-run"

# --- Ho so site luc BUILD (HANDOFF.md muc 1bb, scripts/lib/site_profile.sh) ---
# SITE_PROFILE (wordpress|generic), WEB_SUBDIR (thu muc con lam web root, vd "public") va DB_NAME. Thieu file (APK build tu ban cu)
# thi dung dung gia tri cu: web root = goc www/, CSDL "wordpress". Gia tri da duoc kiem tra an toan luc build.
SITE_PROFILE=wordpress
WEB_SUBDIR=""
DB_NAME=wordpress
if [ -f "$SUP/site-profile.env" ]; then . "$SUP/site-profile.env"; fi
WEBROOT="$DOCROOT"
if [ -n "$WEB_SUBDIR" ]; then WEBROOT="$DOCROOT/$WEB_SUBDIR"; fi
DB_USER="$DB_NAME"      # tai khoan CSDL cuc bo (chi qua unix socket, MariaDB chay --skip-networking): ten = mat khau = ten DB (nhu "wordpress")
DB_PASS="$DB_NAME"

# --- BUG THAT phat hien khi doc lai toan bo code chuan bi cho vong nay
# (khong phai DeepSeek nem ra - tu doc ma thay) ---
# TAT CA file admin-*.php (auth.php, 2fa.php, logs.php, install-wp.php,
# wake-mariadb.php, activity-touch.php...) deu doc "APP_HOME" qua
# getenv('APP_HOME') - nhung bien nay TRUOC BAN NAY chi tung duoc dat bang
# 1 CACH DUY NHAT: dong "env[APP_HOME] = __FILESDIR__" trong
# php-fpm.conf.template (chi ap dung cho tien trinh chay QUA php-fpm). O
# CHE DO LITE (Dual-Mode PHP-Lite, muc 1e - khong co php-fpm, chi "php -S"
# don le) KHONG CO co che nao dat bien nay ca - "DATA=\$HOME" o tren la 1
# BIEN SHELL CUC BO, khong "export" nen KHONG duoc tien trinh con ke thua.
# Hau qua THAT (da kiem chung bang php -S/getenv() that, khong doan): moi
# request vao _admin/ o che do Lite deu bi admin-auth.php tra ve loi 500
# "Chua co mat khau quan tri" (vi getenv('APP_HOME') luon la false ->
# $passwordFile la null) - TOAN BO trang quan tri (File Manager, cai
# WordPress, xem log, 2FA...) khong dung duoc mot chut nao o che do Lite,
# du code cac trang do hoan toan binh thuong. Xuat bien nay ra day (dung
# chung ca 2 che do) de sua dut diem - o che do full van con
# "env[APP_HOME]" trong php-fpm.conf.template (khong thua, php-fpm KHONG
# tu ke thua moi bien moi truong shell theo mac dinh nen giu lai dong do la
# dung), o che do Lite day la bien DUY NHAT giai quyet van de.
export APP_HOME="$DATA"

mkdir -p "$RUNDIR" "$DATA/mysql-data"
# Cho Kotlin (BackupManager) va cac trang _admin biet ten CSDL / loai site luc chay (khong phai doan "wordpress")
echo "$DB_NAME" > "$RUNDIR/db-name" 2>/dev/null || true
echo "$SITE_PROFILE" > "$RUNDIR/site-profile" 2>/dev/null || true
# Page cache (HANDOFF.md muc 1bf): moi lan khoi dong server bat dau voi cache TRONG, tranh phuc vu trang cu sau khi du lieu bi doi/khoi phuc luc server tat.
rm -rf "$RUNDIR/page-cache" 2>/dev/null || true

MYSQL_SOCK="$RUNDIR/mysql.sock"
FPM_SOCK="$RUNDIR/php-fpm.sock"

log() { echo "[start-lamp] $1"; }

# --- Tat SACH nginx/php-fpm/MariaDB khi nhan tin hieu dung (xem HANDOFF.md
# muc 2, tham khao de xuat DeepSeek muc O9) ---
# BUG THAT phat hien khi doc code Kotlin: nut "Tat server" trong app goi
# `Process.destroy()` (xem ServerForegroundService.kt) - lenh nay CHI gui
# SIGTERM cho DUNG 1 tien trinh la "sh" dang chay FILE NAY (con tro truc
# tiep ma Kotlin nam giu), KHONG tu dong chuyen tiep tin hieu cho cac tien
# trinh con chay NEN (`&`) nhu mariadbd/php-fpm/nginx - day la hanh vi
# CHUAN cua Unix (tin hieu gui cho 1 PID khong tu lan sang tien trinh con
# cua no tru phi co code tuong minh lam viec do). Neu KHONG co doan "trap"
# duoi day, shell nay se thoat NGAY LAP TUC khi nhan SIGTERM (hanh vi mac
# dinh) MA KHONG kip tat 3 tien trinh con - chung tro thanh tien trinh MO
# COI (orphan), tiep tuc chay ngam that su du app da hien "Tat server"
# thanh cong tren giao dien - lan "Bat server" sau co the xung dot cong/
# socket voi chinh cac tien trinh mo coi nay, hoac ton pin/RAM vo ich.
# QUAN TRONG voi rieng MariaDB: bi bo roi kieu nay (roi cuoi cung bi
# Android/OS giet cung luc voi toan bo tien trinh app, kieu SIGKILL) co the
# lam hong du lieu InnoDB dang ghi do, khac han duong tat sach da co san cho
# rieng tinh nang Auto-Sleep (`kill -TERM ... ; wait ...` - xem ben duoi
# trong vong lap giam sat) - gio ap dung dung co che tuong tu cho MOI truong
# hop dung server, khong chi luc Auto-Sleep.
#
# --- Bo ham "tat sach" CO TIMEOUT (xem HANDOFF.md muc 1au) ---
# 3 van de cua ban cu (chi "wait $MYSQL_PID" khong gioi han):
#  (a) "wait" CHI hoat dong voi tien trinh la CON TRUC TIEP cua shell nay.
#      Sau lan Auto-Sleep dau tien, wake-mariadb.php (chay boi php-fpm) tu
#      khoi dong mariadbd moi -> MYSQL_PID tro thanh PID KHONG phai con cua
#      shell nay -> "wait" tra ve NGAY LAP TUC (loi 127) ma khong doi gi ca:
#      script tuong MariaDB da thoat trong khi no con dang flush InnoDB. Dung
#      thang tham do "kill -0" (hoat dong voi MOI PID) thay cho "wait".
#  (b) Khong co timeout: mariadbd ket (vd o D-state do I/O flash cham) thi
#      script treo vo han -> Kotlin khong bao gio biet server da tat.
#      Gio: het MARIADB_STOP_TIMEOUT giay thi SIGKILL (InnoDB tu recovery o
#      lan khoi dong sau - chi la phuong an CUOI, khong phai duong chinh).
#  (c) Duong thoat do 1 daemon tu chet (cuoi file) tung "kill" roi "exit 1"
#      NGAY, khong cho - Kotlin restart ngay, mariadbd moi tranh khoa voi ban
#      cu dang flush do.

# pid_alive PID: 0 neu tien trinh con song. "kill -0" thanh cong ca voi
# ZOMBIE (da thoat nhung shell chua thu hoach) -> doc them /proc/PID/stat de
# loai zombie (trang thai Z), neu khong se cho den het timeout vo ly.
pid_alive() {
  [ -n "${1:-}" ] || return 1
  kill -0 "$1" 2>/dev/null || return 1
  case "$(cat "/proc/$1/stat" 2>/dev/null)" in
    *") Z "*) return 1 ;;
  esac
  return 0
}

# wait_pid_exit PID TIMEOUT_GIAY: 0 neu PID da thoat, 1 neu het timeout.
wait_pid_exit() {
  _wp_pid="$1"; _wp_max="${2:-15}"; _wp_i=0
  while pid_alive "$_wp_pid"; do
    [ "$_wp_i" -ge "$_wp_max" ] && return 1
    sleep 1
    _wp_i=$((_wp_i + 1))
  done
  return 0
}

# stop_one NAME PID TIMEOUT: TERM -> doi toi da TIMEOUT giay -> KILL.
stop_one() {
  _so_name="$1"; _so_pid="$2"; _so_max="${3:-5}"
  pid_alive "$_so_pid" || return 0
  kill -TERM "$_so_pid" 2>/dev/null || true
  if ! wait_pid_exit "$_so_pid" "$_so_max"; then
    log "$_so_name (pid=$_so_pid) khong thoat sau ${_so_max}s - buoc phai SIGKILL"
    kill -KILL "$_so_pid" 2>/dev/null || true
  fi
}

# stop_all_gracefully: KHONG exit - de ca duong "bi tin hieu" lan duong "1
# daemon tu chet" dung chung. Thu tu: nginx (het nhan request moi) ->
# php-fpm -> MariaDB CUOI CUNG (cac tang tren con co the dang ghi DB).
stop_all_gracefully() {
  stop_one nginx "${NGINX_PID:-}" 5
  stop_one php-fpm "${FPM_PID:-}" 5
  # Neu MariaDB dang "ngu" (Auto-Sleep), MYSQL_PID la pid CU da chet; nhung
  # wake-mariadb.php co the VUA khoi dong mariadbd moi ma vong giam sat chua
  # kip doc "mariadb-new-pid" -> doc o day de khong bo sot (nguoc lai se de
  # lai mariadbd mo coi, bi he thong giet cung kieu SIGKILL).
  if [ -f "$RUNDIR/mariadb-new-pid" ]; then
    _np=$(cat "$RUNDIR/mariadb-new-pid" 2>/dev/null)
    [ -n "$_np" ] && MYSQL_PID="$_np"
    rm -f "$RUNDIR/mariadb-new-pid"
  fi
  stop_one MariaDB "${MYSQL_PID:-}" "${MARIADB_STOP_TIMEOUT:-20}"
  rm -f "$RUNDIR/graceful-stop-ready" "$RUNDIR/mariadb-asleep" 2>/dev/null || true
}

cleanup_on_signal() {
  log "Nhan yeu cau dung server - dang tat sach nginx/php-fpm/MariaDB..."
  stop_all_gracefully
  log "Da tat xong."
  exit 0
}
trap cleanup_on_signal TERM INT

# stop_requested: ServerForegroundService ghi TOKEN PHIEN (bien WPP_SESSION
# ma chinh no truyen vao) vao $RUNDIR/stop-requested de yeu cau dung SACH
# KHONG phu thuoc Android gui tin hieu gi cho tien trinh nay (Process.destroy()
# la "tuy implementation" - co the SIGKILL, trap o tren se KHONG BAO GIO chay).
# So token voi WPP_SESSION de 1 file co CU (cua phien truoc) khong bao gio
# dung nham phien MOI - khong can xoa file, khong co race khi restart nhanh.
stop_requested() {
  [ -n "${WPP_SESSION:-}" ] || return 1
  [ -f "$RUNDIR/stop-requested" ] || return 1
  [ "$(cat "$RUNDIR/stop-requested" 2>/dev/null)" = "$WPP_SESSION" ]
}

# --- Tao thu vien "dung ten SONAME that" trong 1 thu muc rieng, dua len
# truoc trong LD_LIBRARY_PATH (xem HANDOFF.md muc 1u) ---
# LY DO (bang chung that: mariadbd bao "library libz.so.1 not found" dung
# linker cua chinh Android): build (php.sh) phai doi ten cac file .so
# KHONG ket thuc dung ".so" (vd file SONAME "libz.so.1" -> doi thanh
# "libz_so_1.so") moi qua duoc co che jniLibs (build-apk.yml chi "cp *.so"),
# nhung dynamic linker luc chay lai tim DUNG TEN SONAME GOC ("libz.so.1",
# lay tu muc NEEDED trong ELF header cua binary can no) - ten da doi khong
# khop. nativeLibraryDir KHONG the tao them file/symlink moi luc chay (chi
# Android tu quan ly), nen tao symlink dung ten goc trong 1 thu muc GHI
# DUOC khac ($RUNDIR/compat-libs), tro VE file da doi trong nativeLibraryDir,
# roi dua thu muc nay len TRUOC trong LD_LIBRARY_PATH de linker gap truoc.
# Tao lai (ghi de) MOI LAN start-lamp.sh chay vi $BIN (nativeLibraryDir) doi
# duong dan khac nhau o moi lan cai dat app.
COMPAT_DIR="$RUNDIR/compat-libs"
mkdir -p "$COMPAT_DIR"
SONAME_MAP_FILE="$SUP/soname-map.txt"
if [ -f "$SONAME_MAP_FILE" ]; then
  while IFS=' ' read -r real_name mapped_name; do
    [ -n "$real_name" ] || continue
    ln -sf "$BIN/$mapped_name" "$COMPAT_DIR/$real_name"
  done < "$SONAME_MAP_FILE"
  log "Da tao $(wc -l < "$SONAME_MAP_FILE" | tr -d ' ') symlink ten SONAME that trong $COMPAT_DIR"
fi
export LD_LIBRARY_PATH="$COMPAT_DIR:$BIN"

# ============================================================================
# Dual-Mode PHP-Lite: quyet dinh 1 LAN DUY NHAT, luu lai vinh vien
# ============================================================================
LITE_MODE_THRESHOLD_MB=3072   # PDF de xuat "< 3GB" - sua o day neu can tinh chinh
MODE_FILE="$DATA/.runtime-mode"
LITE_MARKER="$RUNDIR/lite-mode"   # PHP (_admin/index.php) doc file nay de dashboard hien dung trang thai

if [ -f "$MODE_FILE" ]; then
  MODE="$(cat "$MODE_FILE")"
else
  RAM_MB="$DEVICE_RAM_MB"
  case "$RAM_MB" in
    ''|*[!0-9]*)
      # Kotlin khong truyen duoc (vd chay tay qua adb shell de debug) - tu
      # doc /proc/meminfo nhu phuong an du phong.
      RAM_MB="$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null)"
      case "$RAM_MB" in ''|*[!0-9]*) RAM_MB=0 ;; esac
      ;;
  esac

  case "$FORCE_LITE_MODE" in
    on) MODE="lite" ;;
    off) MODE="full" ;;
    *)
      if [ "$RAM_MB" -gt 0 ] && [ "$RAM_MB" -lt "$LITE_MODE_THRESHOLD_MB" ]; then
        MODE="lite"
      else
        MODE="full"
      fi
      ;;
  esac

  echo "$MODE" > "$MODE_FILE"
  log "Quyet dinh CHE DO LAN DAU: $MODE (RAM=${RAM_MB}MB, nguong=${LITE_MODE_THRESHOLD_MB}MB, override=${FORCE_LITE_MODE:-auto})."
  log "Se GIU NGUYEN che do nay ve sau, du RAM/override co doi - chi doi duoc bang cach xoa du lieu app (Cai dat > Ung dung > WP Pocket Server > Xoa du lieu)."
fi

if [ "$MODE" = "lite" ]; then
  touch "$LITE_MARKER"
else
  rm -f "$LITE_MARKER"
fi

# --- php.ini dung chung ca 2 che do ---
# Auto-Sleep (xem Prefs.KEY_AUTO_SLEEP_ENABLED, nginx.conf.template,
# wake-mariadb.php) - CHI bat auto_prepend_file khi nguoi dung tu bat tinh
# nang nay VA dang o che do full (khong phai Lite - Lite dung SQLite, khong
# co MariaDB de "ngu"); mac dinh la 1 dong rong, khong doi hanh vi PHP chut nao.
if [ "$AUTO_SLEEP_ENABLED" = "1" ] && [ "$MODE" != "lite" ]; then
  AUTO_SLEEP_PREPEND_LINE="auto_prepend_file = $SUP/activity-touch.php"
else
  AUTO_SLEEP_PREPEND_LINE=""
fi

# APCu (de xuat DeepSeek muc I4, xem HANDOFF.md muc 10 + muc 1ap) - kiem tra
# THAT co file apcu.so hay khong (co the KHONG co - xem chu thich trong
# php.sh: chua tung chinh tay xac nhan tai duoc tren mang that) TRUOC KHI
# quyet dinh bat. Da tu kiem chung bang php-fpm that (xem chu thich day du
# trong php.ini.template, muc 1ap): thieu/hong file .so chi la WARNING,
# KHONG fatal nhu suy doan ban dau - nhung van giu dieu kien nay de (1)
# tranh spam warning vo ich vao php-error.log, (2) phong truong hop linker
# Android (Bionic) xu ly khac glibc, dieu CHUA kiem chung duoc tren thiet bi
# that.
if [ -f "$BIN/apcu.so" ]; then
  APCU_EXTENSION_LINE="extension=apcu.so"
  APCU_ENABLED_LINE="apc.enabled=1"
  # 16M du cho 1 site WordPress ca nhan (object cache toan bo transient +
  # option autoload) - so voi 512MB-2GB RAM tong cua dien thoai muc thap
  # (xem HANDOFF.md ve gioi han phan cung), khong dang ke.
  APCU_SHM_SIZE_LINE="apc.shm_size=16M"
  # Tat rieng cho CLI SAPI (wp-cron.php goi qua "php" CLI, xem F2 o vong
  # truoc) - moi lan goi CLI la 1 TIEN TRINH MOI, khong chia se duoc bo nho
  # APCu voi cac worker php-fpm (chi cac worker CUNG 1 pool moi chia se
  # duoc) nen bat APCu cho CLI chi ton bo nho khoi tao ma khong co loi ich
  # gi - day la khuyen nghi chuan cua chinh tai lieu APCu, khong phai suy
  # doan rieng cua du an nay.
  APCU_ENABLE_CLI_LINE="apc.enable_cli=0"
else
  APCU_EXTENSION_LINE="; (khong tim thay apcu.so trong may nay - bo qua APCu, xem php.sh)"
  APCU_ENABLED_LINE=""
  APCU_SHM_SIZE_LINE=""
  APCU_ENABLE_CLI_LINE=""
fi

# --- OPcache bat/tat (xem php.ini.template + HANDOFF.md muc 1aw) ---
# OPCACHE_ON=1 -> bat voi lockfile_path = $RUNDIR. Marker "$DATA/opcache-failed"
# (noi dung = mtime cua libphpfpm.so luc that bai) -> da tung that bai VOI CHINH
# BINARY NAY nen tat; khi APK moi doi libphpfpm.so (mtime khac) -> thu lai.
PHPFPM_ID=$(stat -c %Y "$BIN/libphpfpm.so" 2>/dev/null || echo 0)
opcache_vars() {
  if [ "$MODE" = "lite" ]; then
    # Lite chay "exec php -S" (SAPI cli-server, KHONG phai cli nen opcache.enable_cli=0
    # khong tat duoc OPcache o do) va KHONG co vong tu lui o duoi -> neu OPcache hong
    # tren 1 may thi Lite chet han. Lite danh cho may it RAM, khong can OPcache.
    OPCACHE_ON=0
  elif [ -f "$DATA/opcache-failed" ] && [ "$(cat "$DATA/opcache-failed" 2>/dev/null)" = "$PHPFPM_ID" ]; then
    OPCACHE_ON=0
  else
    OPCACHE_ON=1
  fi
  if [ "$OPCACHE_ON" = "1" ]; then
    OPCACHE_ENABLE_LINE="opcache.enable = 1"
    OPCACHE_LOCK_LINE="opcache.lockfile_path = $RUNDIR"
    # 32MB du cho WordPress + vai plugin (mac dinh cua PHP la 128MB - qua dat
    # tren dien thoai); max_accelerated_files 4000 -> PHP lam tron len so nguyen to 7963.
    OPCACHE_MEM_LINE="opcache.memory_consumption = 32"
    OPCACHE_FILE_LINE="opcache.file_cache = $RUNDIR/opcache-file"
  else
    OPCACHE_ENABLE_LINE="opcache.enable = 0"
    OPCACHE_LOCK_LINE=""
    OPCACHE_MEM_LINE=""
    OPCACHE_FILE_LINE=""
  fi
}

# === Ho so hieu nang PHP (PDF 2 R15-R18; HANDOFF.md muc 1bp) ===
# WPP_PHP_PROFILE do app truyen vao: 0 = mac dinh (KHONG doi bat ky byte nao cua php.ini/nginx.conf), 1 = plugin nang
# (WooCommerce/Elementor), 2 = tai/nhap tep lon. Gia tri LA (khong phai 0/1/2, rong, co ky tu thua) = 0 - khong bao gio tiem chuoi
# nguoi dung vao cau hinh. PHP lay dong CUOI cung khi khoa xuat hien nhieu lan, nen khoi ghi de duoc NOI vao cuoi php.ini
# (khong dung toi php.ini.template -> cac test render cau hinh khong bi anh huong).
# Ba tang upload phai KHOP (nginx client_max_body_size >= post_max_size >= upload_max_filesize) va nginx fastcgi_read_timeout
# phai >= max_execution_time, neu khong site bao 413/504 kho hieu - xem scripts/tests/php-tuning-test.py.
php_profile_values() {
  case "${WPP_PHP_PROFILE:-0}" in
    1) PT_MEMORY=256M; PT_EXEC=120; PT_UPLOAD=64 ;;
    2) PT_MEMORY=192M; PT_EXEC=300; PT_UPLOAD=128 ;;
    *) PT_MEMORY=""; PT_EXEC=""; PT_UPLOAD="" ;;
  esac
}
php_tuning_ini() {
  php_profile_values
  [ -n "$PT_MEMORY" ] || return 0
  {
    printf '\n; === Ho so hieu nang PHP (WPP_PHP_PROFILE=%s): ghi de, dong CUOI cung thang ===\n' "$WPP_PHP_PROFILE"
    printf 'memory_limit = %s\n' "$PT_MEMORY"
    printf 'max_execution_time = %s\n' "$PT_EXEC"
    printf 'post_max_size = %sM\n' "$PT_UPLOAD"
    printf 'upload_max_filesize = %sM\n' "$PT_UPLOAD"
  } >> "$RUNDIR/php.ini"
}
php_tuning_nginx() {
  php_profile_values
  [ -n "$PT_MEMORY" ] || return 0
  sed -e "s#client_max_body_size 32m;#client_max_body_size ${PT_UPLOAD}m;#" \
      -e "s#fastcgi_read_timeout 60s;#fastcgi_read_timeout $((PT_EXEC + 10))s;#" \
      "$RUNDIR/nginx.conf" > "$RUNDIR/nginx.conf.tune" && mv "$RUNDIR/nginx.conf.tune" "$RUNDIR/nginx.conf"
}
# === HET ho so hieu nang PHP ===

# === API trang thai chi doc cho LAN (PDF 2 T1; HANDOFF.md muc 1bp-L) ===
# WPP_API_TOKEN do app truyen vao CHI khi nguoi dung bat API. Token hop le = 32..64 ky tu [0-9a-f] (cung quy tac ApiLogic.isValidToken);
# bat ky gia tri nao khac (rong, ky tu la, dau nhay, $, xuong dong, qua ngan/dai) -> KHONG chen gi (nginx.conf giu nguyen tung byte), khong
# bao gio tiem chuoi nguoi dung vao cau hinh. Khoi location duoc chen SAU render, tai dong danh dau WPP-API-INSERT-POINT (chi la chu thich).
# AN TOAN MANG: allow CHI dai rieng 192.168/10/172.16. TUYET DOI KHONG allow 127.0.0.1 - cloudflared noi vao nginx tu 127.0.0.1 nen se mo cho
# CA INTERNET (cung ly do /_fpm-status chi cho dai rieng). Yeu cau tu tunnel co $remote_addr la IP that (realip) hoac 127.0.0.1 -> deu bi chan.
api_token_valid() {
  case "$1" in
    ""|*[!0-9a-f]*) return 1 ;;
  esac
  [ "${#1}" -ge 32 ] && [ "${#1}" -le 64 ]
}
api_status_nginx() {
  api_token_valid "${WPP_API_TOKEN:-}" || return 0
  grep -q "^ *location = /api/v1/status {" "$RUNDIR/nginx.conf" 2>/dev/null && return 0   # da chen roi (chong chen 2 lan -> nginx loi "duplicate location"); CHI khop dong khai bao that, khong khop dong chu thich danh dau
  cat > "$RUNDIR/api-block.conf" <<APIEOF
        location = /api/v1/status {
            allow 192.168.0.0/16;
            allow 10.0.0.0/8;
            allow 172.16.0.0/12;
            deny all;
            if (\$http_authorization != "Bearer ${WPP_API_TOKEN}") { return 401; }
            access_log off;
            default_type application/json;
            add_header Cache-Control "no-store" always;
            add_header X-Content-Type-Options "nosniff" always;
            add_header X-Request-ID \$request_id always;
            alias ${RUNDIR}/api-status.json;
        }
APIEOF
  sed "/WPP-API-INSERT-POINT/r $RUNDIR/api-block.conf" "$RUNDIR/nginx.conf" > "$RUNDIR/nginx.conf.api" && mv "$RUNDIR/nginx.conf.api" "$RUNDIR/nginx.conf"
  rm -f "$RUNDIR/api-block.conf"
}
# === HET API trang thai ===

render_php_ini() {
  sed -e "s#__EXT_DIR__#$BIN#g" \
      -e "s#__RUNDIR__#$RUNDIR#g" \
      -e "s#__AUTO_SLEEP_PREPEND__#$AUTO_SLEEP_PREPEND_LINE#g" \
      -e "s#__APCU_EXTENSION_LINE__#$APCU_EXTENSION_LINE#g" \
      -e "s#__APCU_ENABLED_LINE__#$APCU_ENABLED_LINE#g" \
      -e "s#__APCU_SHM_SIZE_LINE__#$APCU_SHM_SIZE_LINE#g" \
      -e "s#__APCU_ENABLE_CLI_LINE__#$APCU_ENABLE_CLI_LINE#g" \
      -e "s#__OPCACHE_ENABLE_LINE__#$OPCACHE_ENABLE_LINE#g" \
      -e "s#__OPCACHE_LOCK_LINE__#$OPCACHE_LOCK_LINE#g" \
      -e "s#__OPCACHE_MEM_LINE__#$OPCACHE_MEM_LINE#g" \
      -e "s#__OPCACHE_FILE_LINE__#$OPCACHE_FILE_LINE#g" \
      "$SUP/php.ini.template" > "$RUNDIR/php.ini"
  php_tuning_ini   # ho so hieu nang PHP (no-op khi WPP_PHP_PROFILE khong phai 1/2); nam TRONG ham de lan render lai (OPcache) cung giu
}
opcache_vars
render_php_ini
if [ "$OPCACHE_ON" = "1" ]; then
  # Thu muc cache tren dia (opcache.file_cache): PHP can thu muc GOC da ton tai va ghi duoc. Vuot ~100MB (plugin/theme doi nhieu de
  # lai ban dich cu) thi bo han - se tu tao lai khi chay, chi mat loi ich "khoi dong nong" cua 1 lan.
  mkdir -p "$RUNDIR/opcache-file" 2>/dev/null || true
  FC_KB=$(du -sk "$RUNDIR/opcache-file" 2>/dev/null | cut -f1)
  if [ -n "$FC_KB" ] && [ "$FC_KB" -gt 102400 ] 2>/dev/null; then
    rm -rf "$RUNDIR/opcache-file"; mkdir -p "$RUNDIR/opcache-file" 2>/dev/null || true
    log "OPcache file_cache vuot 100MB ($FC_KB KB) - da don"
  fi
  log "OPcache: BAT (lockfile_path=$RUNDIR, file_cache=$RUNDIR/opcache-file)"
elif [ "$MODE" = "lite" ]; then
  log "OPcache: TAT (che do Lite)"
else
  log "OPcache: TAT (da that bai truoc do voi libphpfpm.so nay - xoa $DATA/opcache-failed de thu lai)"
fi

# CA cert bundle (neu co dong goi luc build - xem php.sh). Khong fatal neu
# thieu (|| true): chi anh huong "1-Click Install WordPress"
# (_admin/install-wp.php), cac chuc nang khac khong phu thuoc file nay.
cp "$SUP/cacert.pem" "$RUNDIR/cacert.pem" 2>/dev/null || true

mkdir -p "$RUNDIR/php-sessions"

# --- wp-content/cache -> cacheDir Android (thay the AN TOAN cho y tuong
# "RAM Disk"/OverlayFS that KHONG lam duoc tren Android khong root - xem
# HANDOFF.md muc 1h). CHI ap dung cho thu muc CACHE (du lieu tam, cac plugin
# cache cua WordPress tu tao lai duoc binh thuong neu mat) - TUYET DOI KHONG
# dung cach nay cho wp-content/uploads (anh/video NGUOI DUNG tai len, mat la
# mat that, khac han ban chat voi cache). Dat o day (dung chung ca 2 che do)
# vi ca lite (SQLite) lan full (MariaDB) deu co the dung plugin cache.
if [ -d "$DOCROOT/wp-content" ]; then
  CACHE_TARGET="$TMPDIR/wp-content-cache"
  mkdir -p "$CACHE_TARGET"   # luon dam bao co, du Android co the da xoa cacheDir giua cac lan chay truoc
  if [ ! -L "$DOCROOT/wp-content/cache" ]; then
    rm -rf "$DOCROOT/wp-content/cache" 2>/dev/null || true
    ln -s "$CACHE_TARGET" "$DOCROOT/wp-content/cache"
    log "Da tro wp-content/cache sang cacheDir cua Android (giam ghi flash cho du lieu cache tam)"
  fi
fi

# ============================================================================
# CHE DO LITE: `php -S` don le + SQLite (khong MariaDB, khong nginx, khong php-fpm)
# ============================================================================
if [ "$MODE" = "lite" ]; then
  log "=== CHE DO PHP-LITE (may RAM thap - xem HANDOFF.md muc 1e) ==="
  log "Bo qua MariaDB/nginx/php-fpm - chi chay 1 tien trinh 'php -S' duy nhat, doi lay RAM thap nhat co the."

  if [ ! -f "$BIN/libphpcli.so" ]; then
    log "LOI: khong thay libphpcli.so (binary CLI cua PHP) - xem scripts/runtimes/php.sh, khong the chay che do lite"
    exit 1
  fi

  # Neu la site WordPress (co wp-config-sqlite.php.template) VA CHUA cai dat
  # -> kich hoat SQLite LAN DAU (giong het tinh than "quyet dinh 1 lan" o
  # tren, ap dung rieng cho buoc kich hoat DB nay).
  if [ -f "$DOCROOT/wp-config-sqlite.php.template" ] && [ ! -f "$DOCROOT/wp-config.php" ]; then
    log "Kich hoat SQLite Database Integration (lan dau)..."
    if [ -f "$DOCROOT/wp-content/plugins/sqlite-database-integration/db.copy" ]; then
      cp "$DOCROOT/wp-content/plugins/sqlite-database-integration/db.copy" "$DOCROOT/wp-content/db.php"
    else
      log "CANH BAO: khong thay db.copy cua plugin SQLite (co the tai plugin loi luc build - xem site_source.sh), WordPress se KHONG co database"
    fi
    cp "$DOCROOT/wp-config-sqlite.php.template" "$DOCROOT/wp-config.php"
    # chmod 600 (de xuat DeepSeek muc G1c): wp-config.php chua mat khau DB +
    # salt bi mat - chi chinh tien trinh nay (va php-fpm/php -S chay CUNG
    # user, vi khong co "user ="/"group =" rieng trong cau hinh - xem
    # HANDOFF.md muc 7 diem 0a) can doc duoc, khong ai khac tren may can.
    chmod 600 "$DOCROOT/wp-config.php" 2>/dev/null || true
  fi
  # Don sach file .template con lai (ca 2 loai) - KHONG can nua sau buoc
  # tren, xoa han tranh lo salt qua HTTP (dung ly do da sua o che do full).
  rm -f "$DOCROOT/wp-config.php.template" "$DOCROOT/wp-config-sqlite.php.template"

  log "San sang: php -S, cong=$PORT, che do=lite"
  # "exec" thay the han tien trinh sh nay bang php -S (khong fork tien trinh
  # con) - ServerForegroundService dang waitFor() tren tien trinh nay se
  # thay CHINH php -S thoat neu no chet, dung y het co che phat hien crash o
  # che do full, chi khac la KHONG can vong lap giam sat rieng vi chi co 1
  # tien trinh duy nhat (khong nhu che do full phai theo doi 3 PID).
  exec "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -S "0.0.0.0:$PORT" -t "$WEBROOT" "$SUP/router-lite.php"
fi

# ============================================================================
# CHE DO FULL (mac dinh): nginx + php-fpm + MariaDB that
# ============================================================================
log "=== CHE DO DAY DU (nginx + php-fpm + MariaDB) ==="

# Do "nginx -V" chi in thong tin bien dich roi thoat ngay (khong doc config
# nao ca) nen goi duoc AN TOAN o day, truoc khi nginx.conf ton tai. Xem chu
# thich trong nginx.conf.template ve ly do phai dot truoc thay vi gia dinh.
if "$BIN/libnginx.so" -V 2>&1 | grep -q http_realip_module; then
  log "nginx co module realip - bat khoi phuc IP that cua khach tu Cloudflare"
  CF_REALIP_LINE="set_real_ip_from 127.0.0.1; real_ip_header CF-Connecting-IP; real_ip_recursive off;"
  rm -f "$RUNDIR/realip-missing"
else
  log "CANH BAO: ban nginx nay KHONG co module realip - bo qua khoi phuc IP that, WordPress/log se thay 127.0.0.1 cho moi khach cong khai qua Cloudflare Tunnel (khong anh huong chuc nang khac)"
  CF_REALIP_LINE="# (bo qua: nginx build nay khong co module realip)"
  # Khong co realip => moi khach cong khai la 127.0.0.1 => security-guard.php KHONG the chan IP khach (khong bao gio chan loopback). Ghi co de
  # _admin/security.php bao ro cho chu may thay vi de ho tuong dang duoc bao ve (HANDOFF.md muc 1br).
  : > "$RUNDIR/realip-missing" 2>/dev/null || true
fi

# QUAN TRONG: substitution cua CF_REALIP_LINE dung "|" lam delimiter (thay
# vi "#" nhu cac dong tren) VI nhanh "khong co module" co gia tri BAT DAU
# BANG "#" (dong comment) - dung chung delimiter "#" se lam sed hieu nham
# dau "#" do la dau dong truong thay the, gay loi cu phap "unknown option
# to `s'" va lam TOAN BO script dung (da tu kiem tra bang mo phong truoc
# khi ra soat xong, khong phai gia dinh suong).
# De xuat DeepSeek muc A10 (staging/clone, xem HANDOFF.md muc 10 + muc 1ar)
# - cong staging = cong chinh + 1. Tinh o day (khong phai trong
# nginx.conf.template) vi can 1 con so THAT, khong phai bieu thuc - sed chi
# thay chuoi, khong tinh toan duoc.
STAGING_PORT=$((PORT + 1))

sed -e "s#__DOCROOT__#$DOCROOT#g" \
    -e "s#__WEBROOT__#$WEBROOT#g" \
    -e "s#__PORT__#$PORT#g" \
    -e "s#__STAGING_PORT__#$STAGING_PORT#g" \
    -e "s#__FPM_SOCK__#$FPM_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s|__CF_REALIP_DIRECTIVES__|$CF_REALIP_LINE|g" \
    "$SUP/nginx.conf.template" > "$RUNDIR/nginx.conf"
php_tuning_nginx   # ho so hieu nang PHP: nang client_max_body_size + fastcgi_read_timeout cho khop (no-op o ho so 0)
api_status_nginx   # T1: chen khoi API trang thai khi co WPP_API_TOKEN hop le (no-op neu khong)

sed -e "s#__FPM_SOCK__#$FPM_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s#__FILESDIR__#$DATA#g" \
    -e "s#__EXT_DIR__#$BIN#g" \
    -e "s#__STAGING_PORT__#$STAGING_PORT#g" \
    -e "s#__MYSQL_SOCK__#$MYSQL_SOCK#g" \
    -e "s#__DB_NAME__#$DB_NAME#g" \
    -e "s#__DB_USER__#$DB_USER#g" \
    -e "s#__DB_PASS__#$DB_PASS#g" \
    "$SUP/php-fpm.conf.template" > "$RUNDIR/php-fpm.conf"

# Sinh script khoi dong mariadbd DUNG CHUNG (xem wake-mariadb.sh.template) -
# ca lan khoi dong dau tien (duoi day) LAN wake-mariadb.php (Auto-Sleep, xem
# them trong nginx.conf/php.ini) deu goi CHINH XAC 1 file nay, tranh 2 noi
# chua lenh mariadbd bi lech nhau.
# __MARIADB_BASEDIR__: xem chu thich chi tiet o khoi "Khoi tao MariaDB data
# dir lan dau" ben duoi - dinh nghia truoc o day vi wake-mariadb.sh (sinh
# ngay sau day) va lenh mariadb-install-db (ben duoi) deu can dung CHUNG 1
# gia tri nay, tranh 2 noi tinh duong dan lech nhau.
MARIADB_BASEDIR="$SUP/mariadb-share"
# Kiem tra ngay o day (thay vi de mariadb-install-db/mariadbd tu bao loi mo
# ho) - can cho CA 2: lan dau (mariadb-install-db ben duoi) VA moi lan chay
# binh thuong sau nay (mariadbd that qua wake-mariadb.sh, can basedir nay de
# doc charset/errmsg khi CHAY, khong chi luc cai dat). Neu thay loi nay, APK
# dang dung la ban build TRUOC fix HANDOFF.md muc 1k - build lai tu repo moi
# nhat (php.sh da them buoc dong goi thu muc nay).
if [ ! -d "$MARIADB_BASEDIR" ]; then
  log "LOI: khong thay $MARIADB_BASEDIR (thu muc share/ cua MariaDB, le ra duoc php.sh dong goi vao www.zip) - xem HANDOFF.md muc 1k, co the dang dung ban APK build truoc khi co fix nay."
  exit 1
fi

# --- Tao symlink $MARIADB_BASEDIR/bin/* tro VE FILE THAT trong
# nativeLibraryDir (xem HANDOFF.md muc 1r) ---
# LY DO: mariadb-install-db tu tim my_print_defaults/mariadbd... qua
# "$basedir/bin", "$basedir/extra" (basedir = $MARIADB_BASEDIR, nam trong
# filesDir/www - noi ung dung TU GHI RA luc chay). BAN TRUOC (muc 1p) tung
# COPY THANG file that vao day - build dung, nhung Android/SELinux van tu
# choi cho THUC THI file nam o filesDir DU DA chmod +x (day chinh la ly do
# GOC khien MOI binary khac trong du an nay phai qua co che doi ten
# "lib*.so" de vao nativeLibraryDir - noi DUY NHAT Android chac chan cho
# thuc thi). Giai phap: KHONG copy file that vao day nua (da bo o php.sh) -
# thay vao do TAO SYMLINK moi lan start-lamp.sh chay (KHONG the lam luc
# build, vi $BIN - duong dan nativeLibraryDir - doi moi lan CAI DAT app,
# xem cac gia tri BIN=/data/app/...-<hash khac nhau>==/lib/arm64 da thay
# trong log qua nhieu lan build/cai). `test -x` va viec thuc thi qua
# symlink deu THEO TARGET that (nam trong nativeLibraryDir, noi CHAC CHAN
# duoc thuc thi) - khong con phu thuoc quyen thuc thi cua file trong
# filesDir/www.zip nua. "ln -sf" ghi de moi lan, luon dung du $BIN co doi
# giua cac lan cai dat hay khong.
mkdir -p "$MARIADB_BASEDIR/bin"
ln -sf "$BIN/libmyprintdefaults.so" "$MARIADB_BASEDIR/bin/my_print_defaults"
ln -sf "$BIN/libmariadbd.so" "$MARIADB_BASEDIR/bin/mariadbd"
ln -sf "$BIN/libmariadbinstall.so" "$MARIADB_BASEDIR/bin/mariadb-install-db"
ln -sf "$BIN/libmysqlcli.so" "$MARIADB_BASEDIR/bin/mariadb"
ln -sf "$BIN/libmysqldump.so" "$MARIADB_BASEDIR/bin/mariadb-dump"
ln -sf "$BIN/libresolveip.so" "$MARIADB_BASEDIR/bin/resolveip"
( cd "$MARIADB_BASEDIR" && for d in sbin libexec extra; do ln -sfn bin "$d"; done )
# --- $MARIADB_BASEDIR/data/data/com.termux/files/usr/bin/mariadbd (xem
# HANDOFF.md muc 1t) ---
# LY DO: doc duoc NGUYEN VAN mariadb-install-db that (sau khi bo gioi han in
# log 200 dong) moi thay: trong nhanh "elif test -n \"\$basedir\"", bien
# `mysqld` KHONG duoc gan bang "\$basedir/bin/mariadbd" hay "\$basedir/sbin/..."
# nhu ky vong (kieu duong dan tuong doi binh thuong ma my_print_defaults/
# langdir/srcpkgdatadir van dung, van hoat dong dung) - ma bi dong cung
# thanh "\$basedir//data/data/com.termux/files/usr/bin/mariadbd" NGAY TRONG
# MA NGUON script (ro rang la loi/dac thu tu qua trinh build cua Termux, ghi
# chet 1 duong dan Termux that vao script thay vi dung bien tuong doi nhu
# cho khac) - hoan toan KHONG the doi bang cach truyen `--basedir` khac di,
# vi gia tri nay la CHUOI VAN BAN CO SAN trong file, khong phai suy ra luc
# chay. Cach duy nhat de mariadb-install-db tim thay `mariadbd` la dat dung
# 1 file/symlink tai CHINH XAC duong dan (vo ly nhung co that) nay ben duoi
# $MARIADB_BASEDIR.
mkdir -p "$MARIADB_BASEDIR/data/data/com.termux/files/usr/bin"
ln -sf "$BIN/libmariadbd.so" "$MARIADB_BASEDIR/data/data/com.termux/files/usr/bin/mariadbd"

sed -e "s#__BIN__#$BIN#g" \
    -e "s#__DATA__#$DATA#g" \
    -e "s#__MYSQL_SOCK__#$MYSQL_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s#__MARIADB_BASEDIR__#$MARIADB_BASEDIR#g" \
    "$SUP/wake-mariadb.sh.template" > "$RUNDIR/wake-mariadb.sh"

# Neu co wp-config.php.template (site_source=wordpress) -> sinh wp-config.php
# that voi duong dan socket MySQL that cua thiet bi nay.
if [ -f "$DOCROOT/wp-config.php.template" ]; then
  sed -e "s#__MYSQL_SOCK__#$MYSQL_SOCK#g" \
      "$DOCROOT/wp-config.php.template" > "$DOCROOT/wp-config.php"
  # chmod 600 (de xuat DeepSeek muc G1c): xem chu thich cung dong nay o
  # nhanh che do lite phia tren - ly do giong het, ap dung cho che do full.
  chmod 600 "$DOCROOT/wp-config.php" 2>/dev/null || true
  # QUAN TRONG (bao mat - xem HANDOFF.md muc 1e): file .template nay chua
  # SALT/KHOA BI MAT THAT cua WordPress (sinh luc build boi site_source.sh,
  # lay tu api.wordpress.org that). Da chan bang nginx
  # (location ~* \.template$) nhung xoa han o day la lop bao ve thu 2 - du
  # nginx.conf co bi sua sai/mat dong chan trong tuong lai, file nay cung
  # khong con ton tai de lo ra ngoai. Chi xoa SAU KHI sed thanh cong (dong
  # tren) - "set -e" o dau file da dam bao dung o day neu sed loi.
  rm -f "$DOCROOT/wp-config.php.template"
fi
# Don file .template SQLite (khong dung toi o che do full) neu co, cung ly do bao mat.
rm -f "$DOCROOT/wp-config-sqlite.php.template"

# --- Khoi tao MariaDB data dir lan dau ---
# --basedir: TRUOC BAN NAY khong co co nay - day la NGUYEN NHAN GOC gay loi
# "mariadb-install-db that bai" giong het nhau moi lan chay (xem log that,
# HANDOFF.md muc 1k). Khong truyen --basedir, binary tu doan basedir tu vi
# tri argv0 (thuong la bo "/bin/..." o cuoi duong dan de tim "share/" ke
# ben) - nhung o day binary nam THANG trong nativeLibraryDir (dat ten
# "libmariadbinstall.so" de duoc PackageManager cap quyen thuc thi, xem
# README "vi sao khong hardcode"), KHONG nam trong cau truc "bin/" nao ca,
# nen tu doan sai/that bai, roi rot ve basedir bien dich san cua Termux
# (khong ton tai tren may nay). --basedir tro thang vao $MARIADB_BASEDIR
# (dinh nghia o tren, dong goi tu php.sh vao _supervisor/mariadb-share/share/)
# giai quyet dut diem, vi mariadb-install-db thuc chat goi mariadbd
# --bootstrap ben trong, can doc file .sql o day de sinh system tables VA can
# errmsg.sys chi de khoi dong duoc.
# --tmpdir: rui ro da ghi truoc o HANDOFF.md muc 7 (0b) tu luc chua co log
# that - $TMPDIR da duoc Kotlin set san (ServerForegroundService) nhung
# mariadb-install-db KHONG tu doc bien moi truong nay, phai truyen co tuong
# minh. Them phong ngua dong thoi voi fix --basedir o tren, chua co bang
# chung rieng day la nguyen nhan (chi 1 log loi duy nhat tu nguoi dung, chua
# biet no da het loi hoan toan chua sau khi sua --basedir hay can them
# --tmpdir moi het).
if [ ! -d "$DATA/mysql-data/mysql" ]; then
  # --- Chan doan TRUOC khi goi mariadb-install-db (xem HANDOFF.md muc 1n) ---
  # Log that duy nhat nguoi dung gui cho thay 1 loi KHAC HANG voi gia thuyet
  # o tren (--basedir/--tmpdir): "No such file or directory" ngay khi THUC
  # THI chinh file libmariadbinstall.so - nghia la van de nam o buoc THUC
  # THI BINARY (file khong ton tai sau buoc build/dong goi, hoac ton tai
  # nhung Android khong load duoc, vd thieu dynamic linker/interpreter dung
  # cho binary Termux chay ngoai moi truong Termux) - KHONG lien quan gi toi
  # --basedir/--tmpdir o tren (nhung co van giu lai, khong hai gi). Log thang
  # ra day (nguoi dung xem duoc qua "Xem log" trong app) de biet ngay ket
  # qua, KHONG can dao lai log build tren GitHub Actions.
  log "Chan doan truoc khi khoi tao MariaDB: BIN=$BIN"
  if [ -e "$BIN/libmariadbinstall.so" ]; then
    log "  libmariadbinstall.so TON TAI: $(ls -la "$BIN/libmariadbinstall.so" 2>&1)"
  else
    log "  libmariadbinstall.so KHONG TON TAI tai duong dan tren - loi tu buoc build/dong goi (php.sh), KHONG phai loi basedir/tmpdir"
  fi
  log "  Tong so file trong \$BIN: $(ls "$BIN" 2>/dev/null | wc -l)"

  log "Khoi tao MariaDB lan dau (co the mat vai chuc giay)..."
  "$BIN/libmariadbinstall.so" --datadir="$DATA/mysql-data" \
      --basedir="$MARIADB_BASEDIR" \
      --tmpdir="$TMPDIR" \
      --auth-root-authentication-method=normal > "$RUNDIR/mysql-install.log" 2>&1 \
    || { log "LOI: mariadb-install-db that bai, xem $RUNDIR/mysql-install.log"; exit 1; }
fi

# --- Don socket/PID cu truoc khi khoi dong (de xuat DeepSeek muc O10, xem
# HANDOFF.md muc 10 - truoc ban nay CO Y THUC hoan lai vi "chua co bang
# chung that") ---
# LY DO lam ngay ban nay (khac cac de xuat suy doan khac trong backlog van
# tiep tuc hoan): day la thao tac PHONG THU THUAN TUY, khong doi hanh vi gi
# neu file khong ton tai (`rm -f` im lang bo qua), va khong lam tang rui ro
# nao moi - neu THAT SU co 1 tien trinh mariadbd/php-fpm mo coi con song
# giu socket nay (kich ban hiem, chi co the xay ra neu ca trap SIGTERM o
# tren VA co che Android "Buoc dung" giet ca cgroup deu that bai cung luc),
# xoa file duong dan socket KHONG giet tien trinh do va KHONG lam rui ro
# hong du lieu tang len so voi khong xoa - no chi ngan 1 loi "Address
# already in use"/"bind() failed" hoan toan co the xay ra sau khi
# $RUNDIR (nam trong filesDir, KHONG bi xoa giua cac lan Android SIGKILL ca
# app) con giu lai file .sock cu tu lan chay truoc bi giet dot ngot. An
# toan don gian hon nhieu so voi cac de xuat backlog khac (vd thermal-aware)
# nen lam ngay o day, khong can doi "bang chung that" nhu quy tac chung.
rm -f "$MYSQL_SOCK" "$FPM_SOCK" 2>/dev/null || true

# Cac co so buffer/pool duoi day giam RAM cua mariadbd tu vai tram MB mac
# dinh (thiet ke cho may chu lon) xuong muc toi thieu hop ly cho dien thoai.
# De xuat tu PDF "Toi uu hoa Buffer cua MariaDB" (xem HANDOFF.md muc 1e).
# Da test that bang binary MariaDB 10.11 (Ubuntu x86) - cu phap dung, chi
# chua chay tren chinh binary Termux ARM (xem HANDOFF.md muc 1e). Da bo cờ
# --innodb-buffer-pool-instances sau khi test cho thay no la no-op (bi loai
# bo) tren MariaDB hien dai. (Lenh day du nam trong wake-mariadb.sh, sinh o
# tren - xem chu thich o do.)
/system/bin/sh "$RUNDIR/wake-mariadb.sh" &
MYSQL_PID=$!

log "Cho MariaDB san sang..."
i=0
while [ ! -S "$MYSQL_SOCK" ]; do
  i=$((i + 1))
  if [ "$i" -gt 30 ]; then
    log "LOI: MariaDB khong len sau 30s, xem $RUNDIR/mysqld.log"
    kill "$MYSQL_PID" 2>/dev/null || true
    exit 1
  fi
  sleep 1
done

# Don rac trang thai Auto-Sleep tu 1 lan chay TRUOC (neu app bi Android kill
# dung luc dang "ngu", 2 file nay co the sot lai vi $RUNDIR khong bi xoa
# giua cac lan restart) - lan chay MOI nay vua khoi dong xong mariadbd that
# o tren, chac chan dang THUC, nen phai dam bao khong con file "asleep" gia
# nao khien nginx hieu nham.
rm -f "$RUNDIR/mariadb-asleep" "$RUNDIR/mariadb-new-pid" 2>/dev/null || true

# --- Tao database + user lan dau ---
if [ ! -f "$DATA/.db_initialized" ]; then
  log "Tao database + user $DB_NAME..."
  "$BIN/libmysqlcli.so" --socket="$MYSQL_SOCK" -uroot <<SQL
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
-- De xuat DeepSeek muc A10 (staging/clone, xem HANDOFF.md muc 10 + muc 1ar)
-- - them quyen tren MOI database bat dau bang "wordpress_" (wildcard "\_%"
-- - dau "\" truoc "_" de "_" la KY TU THAT trong ten DB, khong phai wildcard
-- 1-ky-tu cua SQL LIKE) - CHO PHEP user 'wordpress' (khong can quyen root)
-- tu CREATE/DROP DATABASE wordpress_staging cho admin-staging.php, nhung
-- VAN CHAN hoan toan cac database khac (mysql, information_schema, hay ten
-- bat ky khac khong khop pattern) - DA TU KIEM CHUNG THAT bang MariaDB that
-- trong moi truong soan script nay (khong doan): user 'wordpress' tao/dump/
-- import/xoa duoc DB "wordpress_staging" thanh cong, nhung bi tu choi ro
-- rang (Access denied) khi thu vao "mysql" hay tao DB ten "evil" khong khop
-- pattern - xem HANDOFF.md muc 1ar de biet chi tiet lan test that nay VA 1
-- loi thuc su da bat duoc: ban dau tinh THAY THE dong GRANT tren bang dong
-- wildcard nay, nhung the se lam MAT quyen truy cap chinh DB "wordpress"
-- (site dang chay!) - da sua thanh THEM VAO, khong thay the.
GRANT ALL PRIVILEGES ON \`${DB_NAME}\_%\`.* TO '$DB_USER'@'localhost';
-- Don dep nhu mysql_secure_installation (HANDOFF.md muc 1bb, do bang generic-php-test.py): mariadb-install-db tao san database "test"
-- ma MOI tai khoan deu truy cap duoc; khong de tai khoan cua ung dung nhin thay/ghi vao no.
DROP DATABASE IF EXISTS test;
FLUSH PRIVILEGES;
SQL
  touch "$DATA/.db_initialized"
fi

# --- php-fpm ---
start_php_fpm() {
  # ">>" (O_APPEND), KHONG ">": log nay nam trong danh sach bi CAT bang ": >" o khoi rotation (xem F1 ben duoi). Tien trinh mo
  # file KHONG co O_APPEND se ghi tiep o offset cu sau khi cat -> file thanh SPARSE day byte NUL, kich thuoc khong giam
  # (HANDOFF.md muc 1ba, do bang scripts/tests/startlamp-loop-test.py). Cat 1 lan truoc de moi lan khoi dong van la log moi.
  : > "$RUNDIR/php-fpm-stdout.log" 2>/dev/null || true
  "$BIN/libphpfpm.so" --nodaemonize --fpm-config "$RUNDIR/php-fpm.conf" -c "$RUNDIR/php.ini" \
      >> "$RUNDIR/php-fpm-stdout.log" 2>&1 &
  FPM_PID=$!
}
start_php_fpm

log "Cho php-fpm san sang..."
i=0
OPCACHE_RETRIED=0
while [ ! -S "$FPM_SOCK" ]; do
  i=$((i + 1))
  # TU LUI OPcache: php-fpm chet TRUOC khi mo socket trong khi OPcache dang bat ->
  # coi OPcache la nghi pham (loi that tung gap o muc 1y: khong tao duoc lock
  # file), ghi marker, tat OPcache, render lai php.ini va khoi dong lai NGAY trong
  # cung luot (khong cho Kotlin restart + backoff). Chi thu 1 lan.
  if [ "$OPCACHE_ON" = "1" ] && [ "$OPCACHE_RETRIED" = "0" ] && ! pid_alive "$FPM_PID"; then
    log "php-fpm CHET khi OPcache dang BAT - xem noi dung log duoi day roi tat OPcache va thu lai:"
    if [ -s "$RUNDIR/php-fpm-stdout.log" ]; then
      while IFS= read -r line; do log "  $line"; done < "$RUNDIR/php-fpm-stdout.log"
    fi
    printf '%s' "$PHPFPM_ID" > "$DATA/opcache-failed" 2>/dev/null
    OPCACHE_RETRIED=1
    opcache_vars
    render_php_ini
    log "Khoi dong lai php-fpm voi OPcache TAT"
    start_php_fpm
    i=0
    continue
  fi
  if [ "$i" -gt 20 ]; then
    log "LOI: php-fpm khong len sau 20s"
    # In THANG noi dung 2 file log vao day (thay vi chi noi ten file) - vi
    # app (LogViewerActivity.kt) hien CHUA CO tab rieng cho
    # "php-fpm-stdout.log" (chi co tab "PHP-FPM" tro toi php-fpm.log), nen
    # nguoi dung khong co cach nao xem duoc file kia qua UI. In thang vao
    # day de thay ngay trong log chinh (tab "start-lamp.sh", tab dau tien ai
    # cung biet xem) ma khong can build lai/them tab moi.
    if ! kill -0 "$FPM_PID" 2>/dev/null; then
      log "php-fpm (pid=$FPM_PID) da CHET truoc khi kip mo socket - xem noi dung file log ben duoi:"
    else
      log "php-fpm (pid=$FPM_PID) van con song nhung chua mo socket sau 20s - co the dang treo, xem log ben duoi:"
    fi
    log "----- $RUNDIR/php-fpm-stdout.log -----"
    if [ -s "$RUNDIR/php-fpm-stdout.log" ]; then
      while IFS= read -r line; do log "  $line"; done < "$RUNDIR/php-fpm-stdout.log"
    else
      log "  (rong hoac khong ton tai)"
    fi
    log "----- $RUNDIR/php-fpm.log -----"
    if [ -s "$RUNDIR/php-fpm.log" ]; then
      while IFS= read -r line; do log "  $line"; done < "$RUNDIR/php-fpm.log"
    else
      log "  (rong hoac khong ton tai)"
    fi
    kill "$MYSQL_PID" 2>/dev/null || true
    exit 1
  fi
  sleep 1
done

# --- IPv6 co dieu kien (HANDOFF.md muc 1bi) ---
# CHI bat khi may THU BIND DUOC socket IPv6 wildcard (cung kha nang nginx can): may khong co IPv6 ma van "listen [::]" thi nginx CHET
# ("Address family not supported") - sua nhanh: DISABLE_IPV6=1. Neu probe qua ma nginx van chet ngay luc khoi dong (vd chinh sach rieng
# cua ROM) thi tu tat IPv6 va chay lai o duoi. IPv6 chi nhan nguon noi bo (xem geo trong nginx.conf.template).
rm -f "$RUNDIR/ipv6-listen.conf"
if [ "${DISABLE_IPV6:-0}" != "1" ] && [ -f "$BIN/libphpcli.so" ] && \
   "$BIN/libphpcli.so" -n -r 'exit(@stream_socket_server("tcp://[::]:0", $en, $es) ? 0 : 1);' >/dev/null 2>&1; then
  printf 'listen [::]:%s;\n' "$PORT" > "$RUNDIR/ipv6-listen.conf"
  log "IPv6: bind thu duoc -> nginx nghe them [::]:$PORT (chi nhan nguon loopback/link-local/ULA)"
else
  log "IPv6: khong bind duoc (hoac DISABLE_IPV6=1 / khong co php cli) -> chi IPv4 nhu truoc"
fi

# --- mu-plugin Shield (HANDOFF.md muc 1br): dong bo 2 file vao wp-content/mu-plugins moi lan khoi dong ---
# Site WordPress CU (cai truoc khi co Shield) va ban cap nhat ung dung deu nhan ban moi nhat. Chi khi la site WordPress (co wp-load.php); file lamp-run/shield-no-install
# = chu site muon tu quan ly/da go (khong chep nua). Loi chep bi bo qua (lop phu). Quet ma doc nhan biet 2 file nay qua sha1 cua ban goc o _supervisor/ (khong bao "doi").
if [ -f "$DOCROOT/wp-load.php" ] && [ -f "$SUP/wppocket-shield-loader.php" ] && [ -f "$SUP/wppocket-shield-logic.php" ] && [ ! -f "$RUNDIR/shield-no-install" ]; then
  mkdir -p "$DOCROOT/wp-content/mu-plugins/wppocket-shield" 2>/dev/null \
    && cp "$SUP/wppocket-shield-logic.php" "$DOCROOT/wp-content/mu-plugins/wppocket-shield/shield.php" 2>/dev/null \
    && cp "$SUP/wppocket-shield-loader.php" "$DOCROOT/wp-content/mu-plugins/wppocket-shield.php" 2>/dev/null \
    || log "Khong chep duoc mu-plugin Shield (bo qua)"
fi

# --- mu-plugin dang nhap hai buoc TOTP (HANDOFF.md muc 1br-H): cung cach dong bo voi Shield. Tuy chon tung nguoi dung (chua ai bat = khong doi gi).
# lamp-run/twofa-no-install = chu site tu quan ly/da go (khong chep nua); lamp-run/twofa-off = tat khan cap (plugin van nam do nhung bo qua hai buoc).
if [ -f "$DOCROOT/wp-load.php" ] && [ -f "$SUP/wppocket-2fa-loader.php" ] && [ -f "$SUP/wppocket-2fa-logic.php" ] && [ ! -f "$RUNDIR/twofa-no-install" ]; then
  mkdir -p "$DOCROOT/wp-content/mu-plugins/wppocket-2fa" 2>/dev/null \
    && cp "$SUP/wppocket-2fa-logic.php" "$DOCROOT/wp-content/mu-plugins/wppocket-2fa/2fa.php" 2>/dev/null \
    && cp "$SUP/wppocket-2fa-loader.php" "$DOCROOT/wp-content/mu-plugins/wppocket-2fa.php" 2>/dev/null \
    || log "Khong chep duoc mu-plugin hai buoc 2FA (bo qua)"
fi

# --- Lop tu dong chan IP (HANDOFF.md muc 1br, security-guard.php) ---
# nginx.conf co "geo $remote_addr $wp_pocket_banned { include ban-list.conf; }": file PHAI ton tai VA moi dong dung cu phap, neu khong nginx
# KHONG khoi dong. Lam sach truoc (giu chan con han, bo dong sai/IP rieng tu); khong co PHP CLI hoac guard thi chi tao file rong.
# "-d auto_prepend_file=" (rong): php.ini co the co auto_prepend_file = activity-touch.php (Auto-Sleep) - script CLI nao chay qua php_execute_script
# cung nap no va "touch" moc hoat dong, tuc moi lan guard chay (30 giay) se dat lai dong ho ranh va Auto-Sleep khong bao gio ngu.
rm -f "$RUNDIR/ban-reload"
if [ -f "$SUP/security-guard.php" ] && [ -f "$BIN/libphpcli.so" ]; then
  "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -d auto_prepend_file= "$SUP/security-guard.php" "$RUNDIR" sanitize >/dev/null 2>&1 || true
fi
[ -f "$RUNDIR/ban-list.conf" ] || : > "$RUNDIR/ban-list.conf"

# --- nginx ---
: > "$RUNDIR/nginx-stdout.log" 2>/dev/null || true   # log moi moi lan khoi dong; ">>" ben duoi de viec cat log an toan (xem start_php_fpm)
"$BIN/libnginx.so" -p "$RUNDIR/" -c "$RUNDIR/nginx.conf" -g "daemon off;" \
    >> "$RUNDIR/nginx-stdout.log" 2>&1 &
NGINX_PID=$!

# Phong ho cuoi: IPv6 dang bat ma nginx chet ngay luc khoi dong -> bo IPv6, chay lai 1 lan chi voi IPv4.
if [ -f "$RUNDIR/ipv6-listen.conf" ]; then
  sleep 1
  if ! kill -0 "$NGINX_PID" 2>/dev/null; then
    log "IPv6: nginx CHET ngay sau khi khoi dong khi dang bat IPv6 - tat IPv6, chay lai chi voi IPv4 (xem nginx-stdout.log)"
    rm -f "$RUNDIR/ipv6-listen.conf"
    "$BIN/libnginx.so" -p "$RUNDIR/" -c "$RUNDIR/nginx.conf" -g "daemon off;" \
        >> "$RUNDIR/nginx-stdout.log" 2>&1 &
    NGINX_PID=$!
  fi
fi

log "San sang: MariaDB(pid=$MYSQL_PID) php-fpm(pid=$FPM_PID) nginx(pid=$NGINX_PID), cong=$PORT"

# === Cache warming (de xuat DeepSeek muc F4, xem HANDOFF.md muc 10 + muc
# 1as) - CHI co gia tri THAT tu sau khi them object-cache.php (xem
# site_source.sh, de xuat muc I4/1as) - truoc do APCu bat nhung KHONG ai
# dung, "lam am" cung vo nghia. 1 request GET vao trang chu kich hoat
# WordPress chay toan bo bootstrap binh thuong (doc options, plugin dang
# bat, theme...) - cac gia tri nay se duoc object-cache.php luu vao APCu,
# giup request THAT dau tien cua khach khong phai la nguoi "tra gia" cho
# lan khoi tao cache rong.
#
# DUNG PHP CLI qua file_get_contents() (KHONG dung "curl") - giong HET ly
# do + ky thuat da dung cho WP-Cron ngay duoi day (binary "curl" doc lap
# KHONG duoc dong goi trong du an nay, chi co libcurl ben TRONG php).
#
# Chay NGAM (&), KHONG cho vong khoi dong chinh doi - toi uu "co thi tot,
# khong co cung khong sao", khong duoc phep lam cham/chan qua trinh khoi
# dong server THAT.
(
  sleep 1 # nginx/php-fpm vua fork, cho 1 chut cho chac chan san sang nhan ket noi
  "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" \
    -r '@file_get_contents("http://127.0.0.1:'"$PORT"'/");' \
    >/dev/null 2>&1
) &

# === Auto-Sleep MariaDB khi ranh (de xuat PDF "Co che Ngu dong thong minh",
# vong 2 - xem HANDOFF.md) ===
# CHI hoat dong khi AUTO_SLEEP_ENABLED=1 (nguoi dung TU bat trong app, xem
# Prefs.KEY_AUTO_SLEEP_ENABLED) - neu khong, moi bien duoi day khong duoc
# dung toi, vong lap giam sat chay Y HET nhu truoc, KHONG THEM RUI RO GI cho
# ai khong bat tinh nang nay.
#
# CO CHE: file "$ACTIVITY_FILE" duoc 1 script PHP cuc nhe (xem
# activity-touch.php + auto_prepend_file trong php.ini.template) "touch"
# (chi cap nhat mtime, KHONG ghi noi dung - re hon nhieu so voi ghi log moi
# request, do do KHONG mau thuan voi triet ly "giam ghi flash" da co - xem
# nginx.conf.template) MOI LAN co request PHP that (tuc la request CAN
# MariaDB). Vong lap duoi day (da chay san moi 3s de giam sat crash) kiem tra
# them: neu $ACTIVITY_FILE khong doi qua X phut, gui SIGTERM cho mariadbd
# (cho thoat SACH, khong SIGKILL - tranh hong du lieu InnoDB) roi tao file
# "mariadb-asleep" de nginx biet duong "chuyen huong" request PHP tiep theo
# sang wake-mariadb.php (xem nginx.conf.template) thay vi noi thang toi
# php-fpm/MariaDB da tat.
#
# "MARIADB_SLEEPING=1" la co QUAN TRONG NHAT o day: no bao vong lap BEN DUOI
# dung coi "MariaDB da thoat" la crash (truoc day MOI truong hop MariaDB
# thoat deu bi coi la crash -> tat het php-fpm+nginx -> Kotlin restart toan
# cum). Neu KHONG co co nay, chinh Auto-Sleep se tu kich hoat "restart toan
# cum" ngay khi no vua tat MariaDB - phan tac dung hoan toan.
AUTO_SLEEP_IDLE_SEC=$(( ${AUTO_SLEEP_IDLE_MINUTES:-30} * 60 ))
ACTIVITY_FILE="$RUNDIR/last-php-activity"
touch "$ACTIVITY_FILE" 2>/dev/null || true   # moc thoi gian ban dau = luc vua khoi dong xong
MARIADB_SLEEPING=0

# --- Giam sat: bat ky tien trinh nao chet -> thoat het (ServerForegroundService
# dang waitFor() tren chinh tien trinh sh nay, se tu restart toan cum) ---
# LOOP_COUNT: dung de chay WP-Cron/rotate log THUA THOT hon vong lap chinh
# (vong chinh "sleep 3" - chay WP-Cron/rotate log moi lan se lang phi CPU/pin
# vo ich). Xem 2 khoi "moi X vong" ben duoi.
LOOP_COUNT=0
# Bao cho Kotlin biet PHIEN NAY co ho tro "dung sach qua file co" (chi che do
# Full toi duoc day; Lite "exec" thang php -S nen khong co vong lap nay) -
# Kotlin chi cho (toi da vai chuc giay) khi marker khop token phien, neu khong
# (Lite / dang khoi dong) se destroy ngay nhu truoc, khong cho vo ich.
[ -n "${WPP_SESSION:-}" ] && printf '%s' "$WPP_SESSION" > "$RUNDIR/graceful-stop-ready" 2>/dev/null
while true; do
  LOOP_COUNT=$((LOOP_COUNT + 1))

  if stop_requested; then
    log "Nhan co stop-requested tu ung dung (token phien khop)"
    cleanup_on_signal   # tu exit 0
  fi

  # === WP-Cron THAT (xem HANDOFF.md muc 10, de xuat DeepSeek muc F2) ===
  # SUA o vong 21 (HANDOFF.md muc 1az): truoc day goi "wp-cron.php?doing_wp_cron=1". Theo ma nguon wp-cron.php
  # cua WordPress, khi co tham so doing_wp_cron thi file coi do la GOI NOI BO tu spawn_cron() va doi gia tri
  # khop voi khoa "doing_cron" trong DB - "1" khong bao gio khop nen file thoat NGAY, KHONG chay su kien nao
  # (do thuc nghiem tren WordPress 6.8.1 that: staging-realwp-test.py muc 9). Goi tu cron he thong thi KHONG
  # kem tham so: WordPress tu lay khoa roi chay cac su kien den han.
  # WordPress mac dinh chi chay "cron" cua no khi CO KHACH TRUY CAP (kiem tra
  # ngay trong luc tra trang) - site it khach se KHONG BAO GIO chay dung gio:
  # bai viet len lich khong tu dang, plugin backup/don dep khong tu chay.
  # Hosting that co CRON HE THONG rieng goi wp-cron.php dinh ky - o day mo
  # phong bang cach tu goi qua PHP CLI (KHONG dung "curl" - binary nay KHONG
  # duoc dong goi rieng, chi co thu vien libcurl ben trong PHP, khong co
  # chuong trinh dong lap dong lenh "curl" doc lap) moi 100 vong lap (~5 phut
  # voi "sleep 3" - khop dung khuyen nghi pho bien cua WordPress cho cron he
  # thong that). Chi chay khi DOCROOT co wp-cron.php (tuc la site WordPress -
  # khong chay lung tung tren runtime Node/Python/static). Chay NEN ("&") de
  # khong lam cham vong lap giam sat chinh neu wp-cron.php co task nang.
  if [ $((LOOP_COUNT % 100)) -eq 0 ] && [ -f "$DOCROOT/wp-cron.php" ]; then
    "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" \
      -r '@file_get_contents("http://127.0.0.1:'"$PORT"'/wp-cron.php");' \
      >/dev/null 2>&1 &
  fi

  # === Tu dong chan IP do quet / do mat khau (HANDOFF.md muc 1br, security-guard.php) ===
  # Moi 10 vong (~30 giay): doc phan nginx-security.log MOI, cham diem, ghi ban-list.conf. Chay nen (&); khoa flock trong guard chong chay chong.
  # Co "ban-reload" (guard hoac _admin/security.php tao khi danh sach chan DOI) -> HUP cho nginx nap lai (geo chi doc file luc nap cau hinh).
  # Kiem tra co moi vong (re: 1 lenh test) de huy chan tu UI co hieu luc trong ~3 giay. HUP loi/nginx chua san sang: nginx giu cau hinh cu, vo hai.
  if [ -f "$RUNDIR/ban-reload" ]; then
    rm -f "$RUNDIR/ban-reload"
    kill -HUP "$NGINX_PID" 2>/dev/null && log "Danh sach chan IP doi -> gui HUP cho nginx nap lai ban-list.conf"
  fi
  if [ $((LOOP_COUNT % 10)) -eq 5 ] && [ -f "$SUP/security-guard.php" ]; then
    "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -d auto_prepend_file= "$SUP/security-guard.php" "$RUNDIR" >/dev/null 2>&1 &
  fi

  # === Quet ma doc / file la / thay doi diem bam tru (HANDOFF.md muc 1br, security-scan.php) ===
  # Lan dau ~1 phut sau khi khoi dong (LOOP_COUNT=20 de site on dinh), sau do moi 1200 vong (~1 gio), hoac NGAY khi co co "security-scan-now"
  # (_admin/security.php, nut "Quet ngay"). Chay nen + nice (quet doc nhieu file, khong de tranh CPU voi khach). Co duoc xoa TRUOC khi chay de
  # khong lap lai moi 3 giay neu lan quet thoat bat thuong. "-d auto_prepend_file=" giong guard: khong dat lai dong ho Auto-Sleep.
  # Che do scan-fetch: tai checksum loi WordPress (toi da 1 lan/6 gio) roi quet; mang loi thi van quet duoc.
  if [ -f "$SUP/security-scan.php" ] && { [ "$LOOP_COUNT" -eq 20 ] || [ $((LOOP_COUNT % 1200)) -eq 600 ] || [ -f "$RUNDIR/security-scan-now" ]; }; then
    rm -f "$RUNDIR/security-scan-now"
    if command -v nice >/dev/null 2>&1; then
      nice -n 15 "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -d auto_prepend_file= -d memory_limit=128M "$SUP/security-scan.php" "$WEBROOT" "$RUNDIR" scan-fetch >/dev/null 2>&1 &
    else
      "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -d auto_prepend_file= -d memory_limit=128M "$SUP/security-scan.php" "$WEBROOT" "$RUNDIR" scan-fetch >/dev/null 2>&1 &
    fi
  fi

  # === Kiem LO HONG DA BIET cua plugin/theme/loi (HANDOFF.md muc 1br-H, security-vuln.php) - TUY CHON, mac dinh TAT ===
  # Chi chay khi chu site da bat cong lamp-run/vuln-check-on (tinh nang nay gui slug + phien ban toi dich vu ben thu ba - xem PRIVACY.md). Lan dau ~2 phut
  # sau khi khoi dong (LOOP_COUNT=40), sau do moi gio (lech 300 vong so voi quet ma doc de 2 tien trinh nen khong chay cung luc), hoac ngay khi co "vuln-check-now".
  # Chay nen + nice, "-d auto_prepend_file=" giong guard/scan. Mang loi khong sao: ket qua cu van con, thu lai sau.
  if [ -f "$SUP/security-vuln.php" ] && [ -f "$RUNDIR/vuln-check-on" ] && { [ "$LOOP_COUNT" -eq 40 ] || [ $((LOOP_COUNT % 1200)) -eq 900 ] || [ -f "$RUNDIR/vuln-check-now" ]; }; then
    rm -f "$RUNDIR/vuln-check-now"
    if command -v nice >/dev/null 2>&1; then
      nice -n 15 "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -d auto_prepend_file= -d memory_limit=96M "$SUP/security-vuln.php" "$WEBROOT" "$RUNDIR" check >/dev/null 2>&1 &
    else
      "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -d auto_prepend_file= -d memory_limit=96M "$SUP/security-vuln.php" "$WEBROOT" "$RUNDIR" check >/dev/null 2>&1 &
    fi
  fi
  if [ -f "$RUNDIR/vuln-check-now" ] && [ ! -f "$RUNDIR/vuln-check-on" ]; then
    rm -f "$RUNDIR/vuln-check-now"      # co "Kiem ngay" con sot khi tinh nang da tat: bo, khong de lai
  fi

  # === Dashboard metrics theo thoi gian, nhe (xem HANDOFF.md muc 10, de
  # xuat DeepSeek muc A4/A5) ===
  # Chi ghi o CHE DO FULL (vong lap giam sat nay khong ton tai o che do Lite
  # - Lite "exec" thang vao php -S, khong co vong lap nen - day la gioi han
  # CO CHU DICH cua Lite, khong phai thieu sot, dung tinh than "Lite doi lay
  # RAM thap nhat co the" da ghi o tren). Dung PHP CLI (-r, giong het ky
  # thuat WP-Cron ngay tren) thay vi tu parse "df"/awk chua kiem chung tren
  # toolbox/toybox cua Android - ham disk_free_space()/disk_total_space() da
  # DUOC DUNG THAT trong _admin/index.php (admin_tools.sh) tu truoc, tai
  # dung lai ky thuat DA CHUNG MINH thay vi them 1 duong parse moi chua test.
  # Ghi moi 100 vong lap (~5 phut, khop nhip WP-Cron o tren) - du day de thay
  # xu huong theo gio/ngay, khong day den muc ton pin/flash dang ke.
  if [ $((LOOP_COUNT % 100)) -eq 0 ]; then
    "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -r '
      $mem = @file("/proc/meminfo");
      $ramPct = "";
      if ($mem) {
        $vals = [];
        foreach ($mem as $l) {
          if (preg_match("/^(MemTotal|MemAvailable):\s*(\d+)/", $l, $m)) { $vals[$m[1]] = (int) $m[2]; }
        }
        if (isset($vals["MemTotal"], $vals["MemAvailable"]) && $vals["MemTotal"] > 0) {
          $ramPct = round((1 - $vals["MemAvailable"] / $vals["MemTotal"]) * 100, 1);
        }
      }
      $diskPct = "";
      $freeB = @disk_free_space("'"$RUNDIR"'");
      $totalB = @disk_total_space("'"$RUNDIR"'");
      if ($freeB !== false && $totalB) { $diskPct = round((1 - $freeB / $totalB) * 100, 1); }
      $load = "";
      $la = @file_get_contents("/proc/loadavg");
      if ($la) { $parts = explode(" ", trim($la)); $load = $parts[0] ?? ""; }
      $mariadbUp = file_exists("'"$MYSQL_SOCK"'") ? 1 : 0;
      $csv = "'"$RUNDIR"'/metrics.csv";
      if (!file_exists($csv)) { @file_put_contents($csv, "timestamp,ram_pct,disk_pct,load1,mariadb_up\n"); }
      @file_put_contents($csv, time() . "," . $ramPct . "," . $diskPct . "," . $load . "," . $mariadbUp . "\n", FILE_APPEND | LOCK_EX);
    ' >/dev/null 2>&1 &
  fi

  # === Rotation log don gian (xem HANDOFF.md muc 10, de xuat DeepSeek muc F1) ===
  # "buffer=/flush=" trong nginx.conf.template (mUc 1e) chi giam TAN SUAT
  # ghi, KHONG gioi han KICH THUOC file - de nguyen se phinh to vo han qua
  # nhieu thang, an het bo nho dien thoai. KHONG lam GFS retention day du
  # (qua phuc tap cho 1 cong cu 1-nguoi-dung) - chi CAT SACH file nao vuot
  # nguong (giu dung 1 ban hien tai, khong giu ban cu) - "> file" AN TOAN du
  # nginx/php-fpm/mariadbd dang mo file de ghi (O_APPEND ghi tiep o cuoi file,
  # se tu ghi lai tu vi tri 0 sau khi cat, khong can gui tin hieu reload nao).
  # Kiem tra moi 1200 vong lap (~1 gio) - khong can thuong xuyen hon.
  if [ $((LOOP_COUNT % 1200)) -eq 0 ]; then
    # Bo sung (xem HANDOFF.md muc 1au): php-fpm.log, php-fpm-stdout.log,
    # nginx-stdout.log, nginx-staging-error.log truoc day KHONG co trong danh
    # sach nay nen phinh to vo han (php-fpm.log ghi moi lan worker tai sinh).
    for lf in "$RUNDIR/nginx-access.log" "$RUNDIR/nginx-error.log" "$RUNDIR/php-error.log" "$RUNDIR/mysqld.log" "$RUNDIR/php-slow.log" \
              "$RUNDIR/php-fpm.log" "$RUNDIR/php-fpm-stdout.log" "$RUNDIR/nginx-stdout.log" "$RUNDIR/nginx-staging-error.log" "$RUNDIR/mysql-slow.log" \
              "$RUNDIR/nginx-security.log"; do
      if [ -f "$lf" ]; then
        sz=$(wc -c < "$lf" 2>/dev/null || echo 0)
        if [ "$sz" -gt 5242880 ]; then  # 5MB
          : > "$lf"
          log "Da cat log $lf (vuot 5MB)"
        fi
      fi
    done

    # metrics.csv: giu ~7 ngay du lieu (2016 dong, ghi moi 5 phut - xem khoi
    # ghi metrics o tren) + 1 dong header - GFS that su qua phuc tap cho
    # cong cu 1-nguoi-dung (giong ly do da neu voi log thuong), chi can cat
    # bot khi vuot nguong, dung "head + tail" (an toan hon "> file" vi phai
    # GIU LAI header dong 1, khac cac log kia chi can xoa sach).
    # admin-audit.log (nhat ky dang nhap _admin/) truoc day KHONG duoc xoay
    # vong: bi do mat khau tu nhieu IP se phinh vo han. Day la BANG CHUNG bao
    # mat nen KHONG cat sach nhu log thuong - chi giu 2000 dong moi nhat khi
    # vuot 5000 dong (cung ky thuat tail nhu metrics.csv ben duoi, khong can
    # giu header).
    af="$RUNDIR/admin-audit.log"
    if [ -f "$af" ]; then
      alc=$(wc -l < "$af" 2>/dev/null || echo 0)
      if [ "$alc" -gt 5000 ]; then
        tail -n 2000 "$af" > "$af.tmp" 2>/dev/null && mv "$af.tmp" "$af"
        log "Da cat admin-audit.log (giu 2000 dong moi nhat)"
      fi
    fi

    mf="$RUNDIR/metrics.csv"
    if [ -f "$mf" ]; then
      mlc=$(wc -l < "$mf" 2>/dev/null || echo 0)
      if [ "$mlc" -gt 2017 ]; then
        { head -n 1 "$mf"; tail -n 2016 "$mf"; } > "$mf.tmp" 2>/dev/null && mv "$mf.tmp" "$mf"
        log "Da cat metrics.csv (giu ~7 ngay gan nhat)"
      fi
    fi
  fi

  if [ "$AUTO_SLEEP_ENABLED" = "1" ] && [ "$MARIADB_SLEEPING" = "0" ]; then
    NOW=$(date +%s)
    LAST=$(stat -c %Y "$ACTIVITY_FILE" 2>/dev/null || echo "$NOW")
    IDLE=$((NOW - LAST))
    if [ "$IDLE" -ge "$AUTO_SLEEP_IDLE_SEC" ]; then
      log "Auto-Sleep: khong co request PHP nao trong ${IDLE}s (nguong ${AUTO_SLEEP_IDLE_SEC}s) - tat MariaDB de tiet kiem RAM/pin"
      # Dung stop_one (tham do kill -0, co timeout) thay vi "wait": "wait"
      # tra ve NGAY voi mariadbd do wake-mariadb.php khoi dong (khong phai con
      # cua shell nay) -> tu chu ky Auto-Sleep thu 2 tro di, script danh dau
      # "ngu" trong khi MariaDB con dang flush, wake-mariadb.php co the bat
      # ban moi chong len ban cu (xem chu thich o dau bo ham tat sach).
      stop_one MariaDB "$MYSQL_PID" "${MARIADB_STOP_TIMEOUT:-20}"
      MARIADB_SLEEPING=1
      touch "$RUNDIR/mariadb-asleep" 2>/dev/null || true
      log "Auto-Sleep: MariaDB da ngu (pid cu $MYSQL_PID), cho wake-mariadb.php danh thuc khi co request moi"
    fi
  fi

  if [ "$MARIADB_SLEEPING" = "1" ]; then
    # wake-mariadb.php (chay boi php-fpm, VAN THUC du MariaDB dang ngu) ghi
    # PID moi vao day sau khi tu khoi dong lai mariadbd thanh cong - doc lai
    # de vong lap nay tiep tuc giam sat DUNG tien trinh moi, khong con "ngu".
    if [ -f "$RUNDIR/mariadb-new-pid" ]; then
      MYSQL_PID=$(cat "$RUNDIR/mariadb-new-pid" 2>/dev/null)
      rm -f "$RUNDIR/mariadb-new-pid"
      if [ -n "$MYSQL_PID" ] && kill -0 "$MYSQL_PID" 2>/dev/null; then
        MARIADB_SLEEPING=0
        log "Auto-Sleep: wake-mariadb.php da khoi dong lai MariaDB (pid moi=$MYSQL_PID), tiep tuc giam sat binh thuong"
      fi
    fi
  else
    if ! kill -0 "$MYSQL_PID" 2>/dev/null; then log "MariaDB da thoat"; break; fi
  fi

  if ! kill -0 "$FPM_PID" 2>/dev/null; then log "php-fpm da thoat"; break; fi
  if ! kill -0 "$NGINX_PID" 2>/dev/null; then log "nginx da thoat"; break; fi
  sleep 3
done

# 1 daemon tu chet -> don not 2 daemon con lai CHO DEN KHI thoat that (truoc
# day chi "kill" roi exit ngay, khong cho - xem chu thich dau bo ham tat sach).
stop_all_gracefully
rm -f "$RUNDIR/mariadb-new-pid" 2>/dev/null || true
exit 1
