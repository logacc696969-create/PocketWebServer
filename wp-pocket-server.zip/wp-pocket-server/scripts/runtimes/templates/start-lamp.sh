#!/system/bin/sh
# Chạy bằng /system/bin/sh có sẵn trên mọi máy Android - không cần bash.
#
# Sinh config thật từ template (thay __PLACEHOLDER__ bằng đường dẫn thật của
# THIẾT BỊ NÀY - không biết trước lúc CI build vì mỗi máy cài app ở một
# nativeLibraryDir/filesDir khác nhau).
#
# Tự quyết định chạy ở 2 CHẾ ĐỘ (xem HANDOFF.md mục 1e "Dual-Mode PHP-Lite"):
#   - full: nginx + php-fpm + MariaDB thật (mặc định, máy bình thường trở lên)
#   - lite: `php -S` (built-in server) đơn lẻ + SQLite thay MariaDB (máy quá
#     yếu RAM - đánh đổi hiệu năng chịu tải lấy sự ổn định, xem README/
#     HANDOFF.md mục 1e để biết rõ đánh đổi này)
# Quyết định này CHỈ XẢY RA 1 LẦN DUY NHẤT lúc setup đầu tiên (ghi vào
# $DATA/.runtime-mode), CÁC LẦN SAU LUÔN GIỮ NGUYÊN - tránh nguy cơ đổi hạ
# tầng CSDL của 1 site ĐANG CHẠY THẬT (vd từ MariaDB thật sang SQLite giữa
# chừng sẽ làm WordPress mất kết nối database).
set -e

BIN="$LD_LIBRARY_PATH"    # noi chua tat ca binary da tai: libmariadbd.so, libphpfpm.so, libnginx.so, libphpcli.so...
DATA="$HOME"               # filesDir cua app - noi duy nhat ghi duoc
DOCROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"   # thu muc www (cha cua _supervisor)
SUP="$DOCROOT/_supervisor"
RUNDIR="$DATA/lamp-run"

# --- BUG THAT phat hien khi doc lai toan bo code chuan bi cho vong nay
# (khong phai DeepSeek nem ra - tu doc ma thay) ---
# TAT CA file admin-*.php (auth.php, 2fa.php, logs.php, install-wp.php,
# wake-mariadb.php, activity-touch.php...) deu doc "APP_HOME" qua
# getenv('APP_HOME') - nhung bien nay TRUOC BAN NAY chi tung duoc dat bang
# 1 CACH DUY NHAT: dong "env[APP_HOME] = __FILESDIR__" trong
# php-fpm.conf.template (chi ap dung cho tien trinh chay QUA php-fpm). O
# CHE DO LITE (Dual-Mode PHP-Lite, muc 1e - khong co php-fpm, chi "php -S"
# don le) KHONG CO co che nao dat bien nay ca - "DATA=\$HOME" o tren la 1
# BIEN SHELL CUC BO, khong "export" nen KHONG duoc tien trinh con ke thua.
# Hau qua THAT (da kiem chung bang php -S/getenv() that, khong doan): moi
# request vao _admin/ o che do Lite deu bi admin-auth.php tra ve loi 500
# "Chua co mat khau quan tri" (vi getenv('APP_HOME') luon la false ->
# $passwordFile la null) - TOAN BO trang quan tri (File Manager, cai
# WordPress, xem log, 2FA...) khong dung duoc mot chut nao o che do Lite,
# du code cac trang do hoan toan binh thuong. Xuat bien nay ra day (dung
# chung ca 2 che do) de sua dut diem - o che do full van con
# "env[APP_HOME]" trong php-fpm.conf.template (khong thua, php-fpm KHONG
# tu ke thua moi bien moi truong shell theo mac dinh nen giu lai dong do la
# dung), o che do Lite day la bien DUY NHAT giai quyet van de.
export APP_HOME="$DATA"

mkdir -p "$RUNDIR" "$DATA/mysql-data"

MYSQL_SOCK="$RUNDIR/mysql.sock"
FPM_SOCK="$RUNDIR/php-fpm.sock"

log() { echo "[start-lamp] $1"; }

# --- Tat SACH nginx/php-fpm/MariaDB khi nhan tin hieu dung (xem HANDOFF.md
# muc 2, tham khao de xuat DeepSeek muc O9) ---
# BUG THAT phat hien khi doc code Kotlin: nut "Tat server" trong app goi
# `Process.destroy()` (xem ServerForegroundService.kt) - lenh nay CHI gui
# SIGTERM cho DUNG 1 tien trinh la "sh" dang chay FILE NAY (con tro truc
# tiep ma Kotlin nam giu), KHONG tu dong chuyen tiep tin hieu cho cac tien
# trinh con chay NEN (`&`) nhu mariadbd/php-fpm/nginx - day la hanh vi
# CHUAN cua Unix (tin hieu gui cho 1 PID khong tu lan sang tien trinh con
# cua no tru phi co code tuong minh lam viec do). Neu KHONG co doan "trap"
# duoi day, shell nay se thoat NGAY LAP TUC khi nhan SIGTERM (hanh vi mac
# dinh) MA KHONG kip tat 3 tien trinh con - chung tro thanh tien trinh MO
# COI (orphan), tiep tuc chay ngam that su du app da hien "Tat server"
# thanh cong tren giao dien - lan "Bat server" sau co the xung dot cong/
# socket voi chinh cac tien trinh mo coi nay, hoac ton pin/RAM vo ich.
# QUAN TRONG voi rieng MariaDB: bi bo roi kieu nay (roi cuoi cung bi
# Android/OS giet cung luc voi toan bo tien trinh app, kieu SIGKILL) co the
# lam hong du lieu InnoDB dang ghi do, khac han duong tat sach da co san cho
# rieng tinh nang Auto-Sleep (`kill -TERM ... ; wait ...` - xem ben duoi
# trong vong lap giam sat) - gio ap dung dung co che tuong tu cho MOI truong
# hop dung server, khong chi luc Auto-Sleep.
cleanup_on_signal() {
  log "Nhan tin hieu dung server - dang tat sach nginx/php-fpm/MariaDB..."
  [ -n "${NGINX_PID:-}" ] && kill -TERM "$NGINX_PID" 2>/dev/null || true
  [ -n "${FPM_PID:-}" ] && kill -TERM "$FPM_PID" 2>/dev/null || true
  if [ -n "${MYSQL_PID:-}" ]; then
    kill -TERM "$MYSQL_PID" 2>/dev/null || true
    wait "$MYSQL_PID" 2>/dev/null   # doi mariadbd flush InnoDB sach truoc khi thoat
  fi
  log "Da tat xong."
  exit 0
}
trap cleanup_on_signal TERM INT

# --- Tao thu vien "dung ten SONAME that" trong 1 thu muc rieng, dua len
# truoc trong LD_LIBRARY_PATH (xem HANDOFF.md muc 1u) ---
# LY DO (bang chung that: mariadbd bao "library libz.so.1 not found" dung
# linker cua chinh Android): build (php.sh) phai doi ten cac file .so
# KHONG ket thuc dung ".so" (vd file SONAME "libz.so.1" -> doi thanh
# "libz_so_1.so") moi qua duoc co che jniLibs (build-apk.yml chi "cp *.so"),
# nhung dynamic linker luc chay lai tim DUNG TEN SONAME GOC ("libz.so.1",
# lay tu muc NEEDED trong ELF header cua binary can no) - ten da doi khong
# khop. nativeLibraryDir KHONG the tao them file/symlink moi luc chay (chi
# Android tu quan ly), nen tao symlink dung ten goc trong 1 thu muc GHI
# DUOC khac ($RUNDIR/compat-libs), tro VE file da doi trong nativeLibraryDir,
# roi dua thu muc nay len TRUOC trong LD_LIBRARY_PATH de linker gap truoc.
# Tao lai (ghi de) MOI LAN start-lamp.sh chay vi $BIN (nativeLibraryDir) doi
# duong dan khac nhau o moi lan cai dat app.
COMPAT_DIR="$RUNDIR/compat-libs"
mkdir -p "$COMPAT_DIR"
SONAME_MAP_FILE="$SUP/soname-map.txt"
if [ -f "$SONAME_MAP_FILE" ]; then
  while IFS=' ' read -r real_name mapped_name; do
    [ -n "$real_name" ] || continue
    ln -sf "$BIN/$mapped_name" "$COMPAT_DIR/$real_name"
  done < "$SONAME_MAP_FILE"
  log "Da tao $(wc -l < "$SONAME_MAP_FILE" | tr -d ' ') symlink ten SONAME that trong $COMPAT_DIR"
fi
export LD_LIBRARY_PATH="$COMPAT_DIR:$BIN"

# ============================================================================
# Dual-Mode PHP-Lite: quyet dinh 1 LAN DUY NHAT, luu lai vinh vien
# ============================================================================
LITE_MODE_THRESHOLD_MB=3072   # PDF de xuat "< 3GB" - sua o day neu can tinh chinh
MODE_FILE="$DATA/.runtime-mode"
LITE_MARKER="$RUNDIR/lite-mode"   # PHP (_admin/index.php) doc file nay de dashboard hien dung trang thai

if [ -f "$MODE_FILE" ]; then
  MODE="$(cat "$MODE_FILE")"
else
  RAM_MB="$DEVICE_RAM_MB"
  case "$RAM_MB" in
    ''|*[!0-9]*)
      # Kotlin khong truyen duoc (vd chay tay qua adb shell de debug) - tu
      # doc /proc/meminfo nhu phuong an du phong.
      RAM_MB="$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null)"
      case "$RAM_MB" in ''|*[!0-9]*) RAM_MB=0 ;; esac
      ;;
  esac

  case "$FORCE_LITE_MODE" in
    on) MODE="lite" ;;
    off) MODE="full" ;;
    *)
      if [ "$RAM_MB" -gt 0 ] && [ "$RAM_MB" -lt "$LITE_MODE_THRESHOLD_MB" ]; then
        MODE="lite"
      else
        MODE="full"
      fi
      ;;
  esac

  echo "$MODE" > "$MODE_FILE"
  log "Quyet dinh CHE DO LAN DAU: $MODE (RAM=${RAM_MB}MB, nguong=${LITE_MODE_THRESHOLD_MB}MB, override=${FORCE_LITE_MODE:-auto})."
  log "Se GIU NGUYEN che do nay ve sau, du RAM/override co doi - chi doi duoc bang cach xoa du lieu app (Cai dat > Ung dung > WP Pocket Server > Xoa du lieu)."
fi

if [ "$MODE" = "lite" ]; then
  touch "$LITE_MARKER"
else
  rm -f "$LITE_MARKER"
fi

# --- php.ini dung chung ca 2 che do ---
# Auto-Sleep (xem Prefs.KEY_AUTO_SLEEP_ENABLED, nginx.conf.template,
# wake-mariadb.php) - CHI bat auto_prepend_file khi nguoi dung tu bat tinh
# nang nay VA dang o che do full (khong phai Lite - Lite dung SQLite, khong
# co MariaDB de "ngu"); mac dinh la 1 dong rong, khong doi hanh vi PHP chut nao.
if [ "$AUTO_SLEEP_ENABLED" = "1" ] && [ "$MODE" != "lite" ]; then
  AUTO_SLEEP_PREPEND_LINE="auto_prepend_file = $SUP/activity-touch.php"
else
  AUTO_SLEEP_PREPEND_LINE=""
fi

sed -e "s#__EXT_DIR__#$BIN#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s#__AUTO_SLEEP_PREPEND__#$AUTO_SLEEP_PREPEND_LINE#g" \
    "$SUP/php.ini.template" > "$RUNDIR/php.ini"

# CA cert bundle (neu co dong goi luc build - xem php.sh). Khong fatal neu
# thieu (|| true): chi anh huong "1-Click Install WordPress"
# (_admin/install-wp.php), cac chuc nang khac khong phu thuoc file nay.
cp "$SUP/cacert.pem" "$RUNDIR/cacert.pem" 2>/dev/null || true

mkdir -p "$RUNDIR/php-sessions"

# --- wp-content/cache -> cacheDir Android (thay the AN TOAN cho y tuong
# "RAM Disk"/OverlayFS that KHONG lam duoc tren Android khong root - xem
# HANDOFF.md muc 1h). CHI ap dung cho thu muc CACHE (du lieu tam, cac plugin
# cache cua WordPress tu tao lai duoc binh thuong neu mat) - TUYET DOI KHONG
# dung cach nay cho wp-content/uploads (anh/video NGUOI DUNG tai len, mat la
# mat that, khac han ban chat voi cache). Dat o day (dung chung ca 2 che do)
# vi ca lite (SQLite) lan full (MariaDB) deu co the dung plugin cache.
if [ -d "$DOCROOT/wp-content" ]; then
  CACHE_TARGET="$TMPDIR/wp-content-cache"
  mkdir -p "$CACHE_TARGET"   # luon dam bao co, du Android co the da xoa cacheDir giua cac lan chay truoc
  if [ ! -L "$DOCROOT/wp-content/cache" ]; then
    rm -rf "$DOCROOT/wp-content/cache" 2>/dev/null || true
    ln -s "$CACHE_TARGET" "$DOCROOT/wp-content/cache"
    log "Da tro wp-content/cache sang cacheDir cua Android (giam ghi flash cho du lieu cache tam)"
  fi
fi

# ============================================================================
# CHE DO LITE: `php -S` don le + SQLite (khong MariaDB, khong nginx, khong php-fpm)
# ============================================================================
if [ "$MODE" = "lite" ]; then
  log "=== CHE DO PHP-LITE (may RAM thap - xem HANDOFF.md muc 1e) ==="
  log "Bo qua MariaDB/nginx/php-fpm - chi chay 1 tien trinh 'php -S' duy nhat, doi lay RAM thap nhat co the."

  if [ ! -f "$BIN/libphpcli.so" ]; then
    log "LOI: khong thay libphpcli.so (binary CLI cua PHP) - xem scripts/runtimes/php.sh, khong the chay che do lite"
    exit 1
  fi

  # Neu la site WordPress (co wp-config-sqlite.php.template) VA CHUA cai dat
  # -> kich hoat SQLite LAN DAU (giong het tinh than "quyet dinh 1 lan" o
  # tren, ap dung rieng cho buoc kich hoat DB nay).
  if [ -f "$DOCROOT/wp-config-sqlite.php.template" ] && [ ! -f "$DOCROOT/wp-config.php" ]; then
    log "Kich hoat SQLite Database Integration (lan dau)..."
    if [ -f "$DOCROOT/wp-content/plugins/sqlite-database-integration/db.copy" ]; then
      cp "$DOCROOT/wp-content/plugins/sqlite-database-integration/db.copy" "$DOCROOT/wp-content/db.php"
    else
      log "CANH BAO: khong thay db.copy cua plugin SQLite (co the tai plugin loi luc build - xem site_source.sh), WordPress se KHONG co database"
    fi
    cp "$DOCROOT/wp-config-sqlite.php.template" "$DOCROOT/wp-config.php"
  fi
  # Don sach file .template con lai (ca 2 loai) - KHONG can nua sau buoc
  # tren, xoa han tranh lo salt qua HTTP (dung ly do da sua o che do full).
  rm -f "$DOCROOT/wp-config.php.template" "$DOCROOT/wp-config-sqlite.php.template"

  log "San sang: php -S, cong=$PORT, che do=lite"
  # "exec" thay the han tien trinh sh nay bang php -S (khong fork tien trinh
  # con) - ServerForegroundService dang waitFor() tren tien trinh nay se
  # thay CHINH php -S thoat neu no chet, dung y het co che phat hien crash o
  # che do full, chi khac la KHONG can vong lap giam sat rieng vi chi co 1
  # tien trinh duy nhat (khong nhu che do full phai theo doi 3 PID).
  exec "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -S "0.0.0.0:$PORT" -t "$DOCROOT" "$SUP/router-lite.php"
fi

# ============================================================================
# CHE DO FULL (mac dinh): nginx + php-fpm + MariaDB that
# ============================================================================
log "=== CHE DO DAY DU (nginx + php-fpm + MariaDB) ==="

# Do "nginx -V" chi in thong tin bien dich roi thoat ngay (khong doc config
# nao ca) nen goi duoc AN TOAN o day, truoc khi nginx.conf ton tai. Xem chu
# thich trong nginx.conf.template ve ly do phai dot truoc thay vi gia dinh.
if "$BIN/libnginx.so" -V 2>&1 | grep -q http_realip_module; then
  log "nginx co module realip - bat khoi phuc IP that cua khach tu Cloudflare"
  CF_REALIP_LINE="set_real_ip_from 127.0.0.1; real_ip_header CF-Connecting-IP; real_ip_recursive off;"
else
  log "CANH BAO: ban nginx nay KHONG co module realip - bo qua khoi phuc IP that, WordPress/log se thay 127.0.0.1 cho moi khach cong khai qua Cloudflare Tunnel (khong anh huong chuc nang khac)"
  CF_REALIP_LINE="# (bo qua: nginx build nay khong co module realip)"
fi

# QUAN TRONG: substitution cua CF_REALIP_LINE dung "|" lam delimiter (thay
# vi "#" nhu cac dong tren) VI nhanh "khong co module" co gia tri BAT DAU
# BANG "#" (dong comment) - dung chung delimiter "#" se lam sed hieu nham
# dau "#" do la dau dong truong thay the, gay loi cu phap "unknown option
# to `s'" va lam TOAN BO script dung (da tu kiem tra bang mo phong truoc
# khi ra soat xong, khong phai gia dinh suong).
sed -e "s#__DOCROOT__#$DOCROOT#g" \
    -e "s#__PORT__#$PORT#g" \
    -e "s#__FPM_SOCK__#$FPM_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s|__CF_REALIP_DIRECTIVES__|$CF_REALIP_LINE|g" \
    "$SUP/nginx.conf.template" > "$RUNDIR/nginx.conf"

sed -e "s#__FPM_SOCK__#$FPM_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s#__FILESDIR__#$DATA#g" \
    "$SUP/php-fpm.conf.template" > "$RUNDIR/php-fpm.conf"

# Sinh script khoi dong mariadbd DUNG CHUNG (xem wake-mariadb.sh.template) -
# ca lan khoi dong dau tien (duoi day) LAN wake-mariadb.php (Auto-Sleep, xem
# them trong nginx.conf/php.ini) deu goi CHINH XAC 1 file nay, tranh 2 noi
# chua lenh mariadbd bi lech nhau.
# __MARIADB_BASEDIR__: xem chu thich chi tiet o khoi "Khoi tao MariaDB data
# dir lan dau" ben duoi - dinh nghia truoc o day vi wake-mariadb.sh (sinh
# ngay sau day) va lenh mariadb-install-db (ben duoi) deu can dung CHUNG 1
# gia tri nay, tranh 2 noi tinh duong dan lech nhau.
MARIADB_BASEDIR="$SUP/mariadb-share"
# Kiem tra ngay o day (thay vi de mariadb-install-db/mariadbd tu bao loi mo
# ho) - can cho CA 2: lan dau (mariadb-install-db ben duoi) VA moi lan chay
# binh thuong sau nay (mariadbd that qua wake-mariadb.sh, can basedir nay de
# doc charset/errmsg khi CHAY, khong chi luc cai dat). Neu thay loi nay, APK
# dang dung la ban build TRUOC fix HANDOFF.md muc 1k - build lai tu repo moi
# nhat (php.sh da them buoc dong goi thu muc nay).
if [ ! -d "$MARIADB_BASEDIR" ]; then
  log "LOI: khong thay $MARIADB_BASEDIR (thu muc share/ cua MariaDB, le ra duoc php.sh dong goi vao www.zip) - xem HANDOFF.md muc 1k, co the dang dung ban APK build truoc khi co fix nay."
  exit 1
fi

# --- Tao symlink $MARIADB_BASEDIR/bin/* tro VE FILE THAT trong
# nativeLibraryDir (xem HANDOFF.md muc 1r) ---
# LY DO: mariadb-install-db tu tim my_print_defaults/mariadbd... qua
# "$basedir/bin", "$basedir/extra" (basedir = $MARIADB_BASEDIR, nam trong
# filesDir/www - noi ung dung TU GHI RA luc chay). BAN TRUOC (muc 1p) tung
# COPY THANG file that vao day - build dung, nhung Android/SELinux van tu
# choi cho THUC THI file nam o filesDir DU DA chmod +x (day chinh la ly do
# GOC khien MOI binary khac trong du an nay phai qua co che doi ten
# "lib*.so" de vao nativeLibraryDir - noi DUY NHAT Android chac chan cho
# thuc thi). Giai phap: KHONG copy file that vao day nua (da bo o php.sh) -
# thay vao do TAO SYMLINK moi lan start-lamp.sh chay (KHONG the lam luc
# build, vi $BIN - duong dan nativeLibraryDir - doi moi lan CAI DAT app,
# xem cac gia tri BIN=/data/app/...-<hash khac nhau>==/lib/arm64 da thay
# trong log qua nhieu lan build/cai). `test -x` va viec thuc thi qua
# symlink deu THEO TARGET that (nam trong nativeLibraryDir, noi CHAC CHAN
# duoc thuc thi) - khong con phu thuoc quyen thuc thi cua file trong
# filesDir/www.zip nua. "ln -sf" ghi de moi lan, luon dung du $BIN co doi
# giua cac lan cai dat hay khong.
mkdir -p "$MARIADB_BASEDIR/bin"
ln -sf "$BIN/libmyprintdefaults.so" "$MARIADB_BASEDIR/bin/my_print_defaults"
ln -sf "$BIN/libmariadbd.so" "$MARIADB_BASEDIR/bin/mariadbd"
ln -sf "$BIN/libmariadbinstall.so" "$MARIADB_BASEDIR/bin/mariadb-install-db"
ln -sf "$BIN/libmysqlcli.so" "$MARIADB_BASEDIR/bin/mariadb"
ln -sf "$BIN/libmysqldump.so" "$MARIADB_BASEDIR/bin/mariadb-dump"
ln -sf "$BIN/libresolveip.so" "$MARIADB_BASEDIR/bin/resolveip"
( cd "$MARIADB_BASEDIR" && for d in sbin libexec extra; do ln -sfn bin "$d"; done )
# --- $MARIADB_BASEDIR/data/data/com.termux/files/usr/bin/mariadbd (xem
# HANDOFF.md muc 1t) ---
# LY DO: doc duoc NGUYEN VAN mariadb-install-db that (sau khi bo gioi han in
# log 200 dong) moi thay: trong nhanh "elif test -n \"\$basedir\"", bien
# `mysqld` KHONG duoc gan bang "\$basedir/bin/mariadbd" hay "\$basedir/sbin/..."
# nhu ky vong (kieu duong dan tuong doi binh thuong ma my_print_defaults/
# langdir/srcpkgdatadir van dung, van hoat dong dung) - ma bi dong cung
# thanh "\$basedir//data/data/com.termux/files/usr/bin/mariadbd" NGAY TRONG
# MA NGUON script (ro rang la loi/dac thu tu qua trinh build cua Termux, ghi
# chet 1 duong dan Termux that vao script thay vi dung bien tuong doi nhu
# cho khac) - hoan toan KHONG the doi bang cach truyen `--basedir` khac di,
# vi gia tri nay la CHUOI VAN BAN CO SAN trong file, khong phai suy ra luc
# chay. Cach duy nhat de mariadb-install-db tim thay `mariadbd` la dat dung
# 1 file/symlink tai CHINH XAC duong dan (vo ly nhung co that) nay ben duoi
# $MARIADB_BASEDIR.
mkdir -p "$MARIADB_BASEDIR/data/data/com.termux/files/usr/bin"
ln -sf "$BIN/libmariadbd.so" "$MARIADB_BASEDIR/data/data/com.termux/files/usr/bin/mariadbd"

sed -e "s#__BIN__#$BIN#g" \
    -e "s#__DATA__#$DATA#g" \
    -e "s#__MYSQL_SOCK__#$MYSQL_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s#__MARIADB_BASEDIR__#$MARIADB_BASEDIR#g" \
    "$SUP/wake-mariadb.sh.template" > "$RUNDIR/wake-mariadb.sh"

# Neu co wp-config.php.template (site_source=wordpress) -> sinh wp-config.php
# that voi duong dan socket MySQL that cua thiet bi nay.
if [ -f "$DOCROOT/wp-config.php.template" ]; then
  sed -e "s#__MYSQL_SOCK__#$MYSQL_SOCK#g" \
      "$DOCROOT/wp-config.php.template" > "$DOCROOT/wp-config.php"
  # QUAN TRONG (bao mat - xem HANDOFF.md muc 1e): file .template nay chua
  # SALT/KHOA BI MAT THAT cua WordPress (sinh luc build boi site_source.sh,
  # lay tu api.wordpress.org that). Da chan bang nginx
  # (location ~* \.template$) nhung xoa han o day la lop bao ve thu 2 - du
  # nginx.conf co bi sua sai/mat dong chan trong tuong lai, file nay cung
  # khong con ton tai de lo ra ngoai. Chi xoa SAU KHI sed thanh cong (dong
  # tren) - "set -e" o dau file da dam bao dung o day neu sed loi.
  rm -f "$DOCROOT/wp-config.php.template"
fi
# Don file .template SQLite (khong dung toi o che do full) neu co, cung ly do bao mat.
rm -f "$DOCROOT/wp-config-sqlite.php.template"

# --- Khoi tao MariaDB data dir lan dau ---
# --basedir: TRUOC BAN NAY khong co co nay - day la NGUYEN NHAN GOC gay loi
# "mariadb-install-db that bai" giong het nhau moi lan chay (xem log that,
# HANDOFF.md muc 1k). Khong truyen --basedir, binary tu doan basedir tu vi
# tri argv0 (thuong la bo "/bin/..." o cuoi duong dan de tim "share/" ke
# ben) - nhung o day binary nam THANG trong nativeLibraryDir (dat ten
# "libmariadbinstall.so" de duoc PackageManager cap quyen thuc thi, xem
# README "vi sao khong hardcode"), KHONG nam trong cau truc "bin/" nao ca,
# nen tu doan sai/that bai, roi rot ve basedir bien dich san cua Termux
# (khong ton tai tren may nay). --basedir tro thang vao $MARIADB_BASEDIR
# (dinh nghia o tren, dong goi tu php.sh vao _supervisor/mariadb-share/share/)
# giai quyet dut diem, vi mariadb-install-db thuc chat goi mariadbd
# --bootstrap ben trong, can doc file .sql o day de sinh system tables VA can
# errmsg.sys chi de khoi dong duoc.
# --tmpdir: rui ro da ghi truoc o HANDOFF.md muc 7 (0b) tu luc chua co log
# that - $TMPDIR da duoc Kotlin set san (ServerForegroundService) nhung
# mariadb-install-db KHONG tu doc bien moi truong nay, phai truyen co tuong
# minh. Them phong ngua dong thoi voi fix --basedir o tren, chua co bang
# chung rieng day la nguyen nhan (chi 1 log loi duy nhat tu nguoi dung, chua
# biet no da het loi hoan toan chua sau khi sua --basedir hay can them
# --tmpdir moi het).
if [ ! -d "$DATA/mysql-data/mysql" ]; then
  # --- Chan doan TRUOC khi goi mariadb-install-db (xem HANDOFF.md muc 1n) ---
  # Log that duy nhat nguoi dung gui cho thay 1 loi KHAC HANG voi gia thuyet
  # o tren (--basedir/--tmpdir): "No such file or directory" ngay khi THUC
  # THI chinh file libmariadbinstall.so - nghia la van de nam o buoc THUC
  # THI BINARY (file khong ton tai sau buoc build/dong goi, hoac ton tai
  # nhung Android khong load duoc, vd thieu dynamic linker/interpreter dung
  # cho binary Termux chay ngoai moi truong Termux) - KHONG lien quan gi toi
  # --basedir/--tmpdir o tren (nhung co van giu lai, khong hai gi). Log thang
  # ra day (nguoi dung xem duoc qua "Xem log" trong app) de biet ngay ket
  # qua, KHONG can dao lai log build tren GitHub Actions.
  log "Chan doan truoc khi khoi tao MariaDB: BIN=$BIN"
  if [ -e "$BIN/libmariadbinstall.so" ]; then
    log "  libmariadbinstall.so TON TAI: $(ls -la "$BIN/libmariadbinstall.so" 2>&1)"
  else
    log "  libmariadbinstall.so KHONG TON TAI tai duong dan tren - loi tu buoc build/dong goi (php.sh), KHONG phai loi basedir/tmpdir"
  fi
  log "  Tong so file trong \$BIN: $(ls "$BIN" 2>/dev/null | wc -l)"

  log "Khoi tao MariaDB lan dau (co the mat vai chuc giay)..."
  "$BIN/libmariadbinstall.so" --datadir="$DATA/mysql-data" \
      --basedir="$MARIADB_BASEDIR" \
      --tmpdir="$TMPDIR" \
      --auth-root-authentication-method=normal > "$RUNDIR/mysql-install.log" 2>&1 \
    || { log "LOI: mariadb-install-db that bai, xem $RUNDIR/mysql-install.log"; exit 1; }
fi

# --- Don socket/PID cu truoc khi khoi dong (de xuat DeepSeek muc O10, xem
# HANDOFF.md muc 10 - truoc ban nay CO Y THUC hoan lai vi "chua co bang
# chung that") ---
# LY DO lam ngay ban nay (khac cac de xuat suy doan khac trong backlog van
# tiep tuc hoan): day la thao tac PHONG THU THUAN TUY, khong doi hanh vi gi
# neu file khong ton tai (`rm -f` im lang bo qua), va khong lam tang rui ro
# nao moi - neu THAT SU co 1 tien trinh mariadbd/php-fpm mo coi con song
# giu socket nay (kich ban hiem, chi co the xay ra neu ca trap SIGTERM o
# tren VA co che Android "Buoc dung" giet ca cgroup deu that bai cung luc),
# xoa file duong dan socket KHONG giet tien trinh do va KHONG lam rui ro
# hong du lieu tang len so voi khong xoa - no chi ngan 1 loi "Address
# already in use"/"bind() failed" hoan toan co the xay ra sau khi
# $RUNDIR (nam trong filesDir, KHONG bi xoa giua cac lan Android SIGKILL ca
# app) con giu lai file .sock cu tu lan chay truoc bi giet dot ngot. An
# toan don gian hon nhieu so voi cac de xuat backlog khac (vd thermal-aware)
# nen lam ngay o day, khong can doi "bang chung that" nhu quy tac chung.
rm -f "$MYSQL_SOCK" "$FPM_SOCK" 2>/dev/null || true

# Cac co so buffer/pool duoi day giam RAM cua mariadbd tu vai tram MB mac
# dinh (thiet ke cho may chu lon) xuong muc toi thieu hop ly cho dien thoai.
# De xuat tu PDF "Toi uu hoa Buffer cua MariaDB" (xem HANDOFF.md muc 1e).
# Da test that bang binary MariaDB 10.11 (Ubuntu x86) - cu phap dung, chi
# chua chay tren chinh binary Termux ARM (xem HANDOFF.md muc 1e). Da bo cờ
# --innodb-buffer-pool-instances sau khi test cho thay no la no-op (bi loai
# bo) tren MariaDB hien dai. (Lenh day du nam trong wake-mariadb.sh, sinh o
# tren - xem chu thich o do.)
/system/bin/sh "$RUNDIR/wake-mariadb.sh" &
MYSQL_PID=$!

log "Cho MariaDB san sang..."
i=0
while [ ! -S "$MYSQL_SOCK" ]; do
  i=$((i + 1))
  if [ "$i" -gt 30 ]; then
    log "LOI: MariaDB khong len sau 30s, xem $RUNDIR/mysqld.log"
    kill "$MYSQL_PID" 2>/dev/null || true
    exit 1
  fi
  sleep 1
done

# Don rac trang thai Auto-Sleep tu 1 lan chay TRUOC (neu app bi Android kill
# dung luc dang "ngu", 2 file nay co the sot lai vi $RUNDIR khong bi xoa
# giua cac lan restart) - lan chay MOI nay vua khoi dong xong mariadbd that
# o tren, chac chan dang THUC, nen phai dam bao khong con file "asleep" gia
# nao khien nginx hieu nham.
rm -f "$RUNDIR/mariadb-asleep" "$RUNDIR/mariadb-new-pid" 2>/dev/null || true

# --- Tao database + user lan dau ---
if [ ! -f "$DATA/.db_initialized" ]; then
  log "Tao database + user wordpress..."
  "$BIN/libmysqlcli.so" --socket="$MYSQL_SOCK" -uroot <<SQL
CREATE DATABASE IF NOT EXISTS wordpress CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'wordpress'@'localhost' IDENTIFIED BY 'wordpress';
GRANT ALL PRIVILEGES ON wordpress.* TO 'wordpress'@'localhost';
FLUSH PRIVILEGES;
SQL
  touch "$DATA/.db_initialized"
fi

# --- php-fpm ---
"$BIN/libphpfpm.so" --nodaemonize --fpm-config "$RUNDIR/php-fpm.conf" -c "$RUNDIR/php.ini" \
    > "$RUNDIR/php-fpm-stdout.log" 2>&1 &
FPM_PID=$!

log "Cho php-fpm san sang..."
i=0
while [ ! -S "$FPM_SOCK" ]; do
  i=$((i + 1))
  if [ "$i" -gt 20 ]; then
    log "LOI: php-fpm khong len sau 20s"
    # In THANG noi dung 2 file log vao day (thay vi chi noi ten file) - vi
    # app (LogViewerActivity.kt) hien CHUA CO tab rieng cho
    # "php-fpm-stdout.log" (chi co tab "PHP-FPM" tro toi php-fpm.log), nen
    # nguoi dung khong co cach nao xem duoc file kia qua UI. In thang vao
    # day de thay ngay trong log chinh (tab "start-lamp.sh", tab dau tien ai
    # cung biet xem) ma khong can build lai/them tab moi.
    if ! kill -0 "$FPM_PID" 2>/dev/null; then
      log "php-fpm (pid=$FPM_PID) da CHET truoc khi kip mo socket - xem noi dung file log ben duoi:"
    else
      log "php-fpm (pid=$FPM_PID) van con song nhung chua mo socket sau 20s - co the dang treo, xem log ben duoi:"
    fi
    log "----- $RUNDIR/php-fpm-stdout.log -----"
    if [ -s "$RUNDIR/php-fpm-stdout.log" ]; then
      while IFS= read -r line; do log "  $line"; done < "$RUNDIR/php-fpm-stdout.log"
    else
      log "  (rong hoac khong ton tai)"
    fi
    log "----- $RUNDIR/php-fpm.log -----"
    if [ -s "$RUNDIR/php-fpm.log" ]; then
      while IFS= read -r line; do log "  $line"; done < "$RUNDIR/php-fpm.log"
    else
      log "  (rong hoac khong ton tai)"
    fi
    kill "$MYSQL_PID" 2>/dev/null || true
    exit 1
  fi
  sleep 1
done

# --- nginx ---
"$BIN/libnginx.so" -p "$RUNDIR/" -c "$RUNDIR/nginx.conf" -g "daemon off;" \
    > "$RUNDIR/nginx-stdout.log" 2>&1 &
NGINX_PID=$!

log "San sang: MariaDB(pid=$MYSQL_PID) php-fpm(pid=$FPM_PID) nginx(pid=$NGINX_PID), cong=$PORT"

# === Auto-Sleep MariaDB khi ranh (de xuat PDF "Co che Ngu dong thong minh",
# vong 2 - xem HANDOFF.md) ===
# CHI hoat dong khi AUTO_SLEEP_ENABLED=1 (nguoi dung TU bat trong app, xem
# Prefs.KEY_AUTO_SLEEP_ENABLED) - neu khong, moi bien duoi day khong duoc
# dung toi, vong lap giam sat chay Y HET nhu truoc, KHONG THEM RUI RO GI cho
# ai khong bat tinh nang nay.
#
# CO CHE: file "$ACTIVITY_FILE" duoc 1 script PHP cuc nhe (xem
# activity-touch.php + auto_prepend_file trong php.ini.template) "touch"
# (chi cap nhat mtime, KHONG ghi noi dung - re hon nhieu so voi ghi log moi
# request, do do KHONG mau thuan voi triet ly "giam ghi flash" da co - xem
# nginx.conf.template) MOI LAN co request PHP that (tuc la request CAN
# MariaDB). Vong lap duoi day (da chay san moi 3s de giam sat crash) kiem tra
# them: neu $ACTIVITY_FILE khong doi qua X phut, gui SIGTERM cho mariadbd
# (cho thoat SACH, khong SIGKILL - tranh hong du lieu InnoDB) roi tao file
# "mariadb-asleep" de nginx biet duong "chuyen huong" request PHP tiep theo
# sang wake-mariadb.php (xem nginx.conf.template) thay vi noi thang toi
# php-fpm/MariaDB da tat.
#
# "MARIADB_SLEEPING=1" la co QUAN TRONG NHAT o day: no bao vong lap BEN DUOI
# dung coi "MariaDB da thoat" la crash (truoc day MOI truong hop MariaDB
# thoat deu bi coi la crash -> tat het php-fpm+nginx -> Kotlin restart toan
# cum). Neu KHONG co co nay, chinh Auto-Sleep se tu kich hoat "restart toan
# cum" ngay khi no vua tat MariaDB - phan tac dung hoan toan.
AUTO_SLEEP_IDLE_SEC=$(( ${AUTO_SLEEP_IDLE_MINUTES:-30} * 60 ))
ACTIVITY_FILE="$RUNDIR/last-php-activity"
touch "$ACTIVITY_FILE" 2>/dev/null || true   # moc thoi gian ban dau = luc vua khoi dong xong
MARIADB_SLEEPING=0

# --- Giam sat: bat ky tien trinh nao chet -> thoat het (ServerForegroundService
# dang waitFor() tren chinh tien trinh sh nay, se tu restart toan cum) ---
# LOOP_COUNT: dung de chay WP-Cron/rotate log THUA THOT hon vong lap chinh
# (vong chinh "sleep 3" - chay WP-Cron/rotate log moi lan se lang phi CPU/pin
# vo ich). Xem 2 khoi "moi X vong" ben duoi.
LOOP_COUNT=0
while true; do
  LOOP_COUNT=$((LOOP_COUNT + 1))

  # === WP-Cron THAT (xem HANDOFF.md muc 10, de xuat DeepSeek muc F2) ===
  # WordPress mac dinh chi chay "cron" cua no khi CO KHACH TRUY CAP (kiem tra
  # ngay trong luc tra trang) - site it khach se KHONG BAO GIO chay dung gio:
  # bai viet len lich khong tu dang, plugin backup/don dep khong tu chay.
  # Hosting that co CRON HE THONG rieng goi wp-cron.php dinh ky - o day mo
  # phong bang cach tu goi qua PHP CLI (KHONG dung "curl" - binary nay KHONG
  # duoc dong goi rieng, chi co thu vien libcurl ben trong PHP, khong co
  # chuong trinh dong lap dong lenh "curl" doc lap) moi 100 vong lap (~5 phut
  # voi "sleep 3" - khop dung khuyen nghi pho bien cua WordPress cho cron he
  # thong that). Chi chay khi DOCROOT co wp-cron.php (tuc la site WordPress -
  # khong chay lung tung tren runtime Node/Python/static). Chay NEN ("&") de
  # khong lam cham vong lap giam sat chinh neu wp-cron.php co task nang.
  if [ $((LOOP_COUNT % 100)) -eq 0 ] && [ -f "$DOCROOT/wp-cron.php" ]; then
    "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" \
      -r '@file_get_contents("http://127.0.0.1:'"$PORT"'/wp-cron.php?doing_wp_cron=1");' \
      >/dev/null 2>&1 &
  fi

  # === Dashboard metrics theo thoi gian, nhe (xem HANDOFF.md muc 10, de
  # xuat DeepSeek muc A4/A5) ===
  # Chi ghi o CHE DO FULL (vong lap giam sat nay khong ton tai o che do Lite
  # - Lite "exec" thang vao php -S, khong co vong lap nen - day la gioi han
  # CO CHU DICH cua Lite, khong phai thieu sot, dung tinh than "Lite doi lay
  # RAM thap nhat co the" da ghi o tren). Dung PHP CLI (-r, giong het ky
  # thuat WP-Cron ngay tren) thay vi tu parse "df"/awk chua kiem chung tren
  # toolbox/toybox cua Android - ham disk_free_space()/disk_total_space() da
  # DUOC DUNG THAT trong _admin/index.php (admin_tools.sh) tu truoc, tai
  # dung lai ky thuat DA CHUNG MINH thay vi them 1 duong parse moi chua test.
  # Ghi moi 100 vong lap (~5 phut, khop nhip WP-Cron o tren) - du day de thay
  # xu huong theo gio/ngay, khong day den muc ton pin/flash dang ke.
  if [ $((LOOP_COUNT % 100)) -eq 0 ]; then
    "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -r '
      $mem = @file("/proc/meminfo");
      $ramPct = "";
      if ($mem) {
        $vals = [];
        foreach ($mem as $l) {
          if (preg_match("/^(MemTotal|MemAvailable):\s*(\d+)/", $l, $m)) { $vals[$m[1]] = (int) $m[2]; }
        }
        if (isset($vals["MemTotal"], $vals["MemAvailable"]) && $vals["MemTotal"] > 0) {
          $ramPct = round((1 - $vals["MemAvailable"] / $vals["MemTotal"]) * 100, 1);
        }
      }
      $diskPct = "";
      $freeB = @disk_free_space("'"$RUNDIR"'");
      $totalB = @disk_total_space("'"$RUNDIR"'");
      if ($freeB !== false && $totalB) { $diskPct = round((1 - $freeB / $totalB) * 100, 1); }
      $load = "";
      $la = @file_get_contents("/proc/loadavg");
      if ($la) { $parts = explode(" ", trim($la)); $load = $parts[0] ?? ""; }
      $mariadbUp = file_exists("'"$MYSQL_SOCK"'") ? 1 : 0;
      $csv = "'"$RUNDIR"'/metrics.csv";
      if (!file_exists($csv)) { @file_put_contents($csv, "timestamp,ram_pct,disk_pct,load1,mariadb_up\n"); }
      @file_put_contents($csv, time() . "," . $ramPct . "," . $diskPct . "," . $load . "," . $mariadbUp . "\n", FILE_APPEND | LOCK_EX);
    ' >/dev/null 2>&1 &
  fi

  # === Rotation log don gian (xem HANDOFF.md muc 10, de xuat DeepSeek muc F1) ===
  # "buffer=/flush=" trong nginx.conf.template (mUc 1e) chi giam TAN SUAT
  # ghi, KHONG gioi han KICH THUOC file - de nguyen se phinh to vo han qua
  # nhieu thang, an het bo nho dien thoai. KHONG lam GFS retention day du
  # (qua phuc tap cho 1 cong cu 1-nguoi-dung) - chi CAT SACH file nao vuot
  # nguong (giu dung 1 ban hien tai, khong giu ban cu) - "> file" AN TOAN du
  # nginx/php-fpm/mariadbd dang mo file de ghi (O_APPEND ghi tiep o cuoi file,
  # se tu ghi lai tu vi tri 0 sau khi cat, khong can gui tin hieu reload nao).
  # Kiem tra moi 1200 vong lap (~1 gio) - khong can thuong xuyen hon.
  if [ $((LOOP_COUNT % 1200)) -eq 0 ]; then
    for lf in "$RUNDIR/nginx-access.log" "$RUNDIR/nginx-error.log" "$RUNDIR/php-error.log" "$RUNDIR/mysqld.log"; do
      if [ -f "$lf" ]; then
        sz=$(wc -c < "$lf" 2>/dev/null || echo 0)
        if [ "$sz" -gt 5242880 ]; then  # 5MB
          : > "$lf"
          log "Da cat log $lf (vuot 5MB)"
        fi
      fi
    done

    # metrics.csv: giu ~7 ngay du lieu (2016 dong, ghi moi 5 phut - xem khoi
    # ghi metrics o tren) + 1 dong header - GFS that su qua phuc tap cho
    # cong cu 1-nguoi-dung (giong ly do da neu voi log thuong), chi can cat
    # bot khi vuot nguong, dung "head + tail" (an toan hon "> file" vi phai
    # GIU LAI header dong 1, khac cac log kia chi can xoa sach).
    mf="$RUNDIR/metrics.csv"
    if [ -f "$mf" ]; then
      mlc=$(wc -l < "$mf" 2>/dev/null || echo 0)
      if [ "$mlc" -gt 2017 ]; then
        { head -n 1 "$mf"; tail -n 2016 "$mf"; } > "$mf.tmp" 2>/dev/null && mv "$mf.tmp" "$mf"
        log "Da cat metrics.csv (giu ~7 ngay gan nhat)"
      fi
    fi
  fi

  if [ "$AUTO_SLEEP_ENABLED" = "1" ] && [ "$MARIADB_SLEEPING" = "0" ]; then
    NOW=$(date +%s)
    LAST=$(stat -c %Y "$ACTIVITY_FILE" 2>/dev/null || echo "$NOW")
    IDLE=$((NOW - LAST))
    if [ "$IDLE" -ge "$AUTO_SLEEP_IDLE_SEC" ]; then
      log "Auto-Sleep: khong co request PHP nao trong ${IDLE}s (nguong ${AUTO_SLEEP_IDLE_SEC}s) - tat MariaDB de tiet kiem RAM/pin"
      kill -TERM "$MYSQL_PID" 2>/dev/null || true
      wait "$MYSQL_PID" 2>/dev/null   # doi mariadbd tu thoat SACH (flush InnoDB) truoc khi danh dau ngu
      MARIADB_SLEEPING=1
      touch "$RUNDIR/mariadb-asleep" 2>/dev/null || true
      log "Auto-Sleep: MariaDB da ngu (pid cu $MYSQL_PID), cho wake-mariadb.php danh thuc khi co request moi"
    fi
  fi

  if [ "$MARIADB_SLEEPING" = "1" ]; then
    # wake-mariadb.php (chay boi php-fpm, VAN THUC du MariaDB dang ngu) ghi
    # PID moi vao day sau khi tu khoi dong lai mariadbd thanh cong - doc lai
    # de vong lap nay tiep tuc giam sat DUNG tien trinh moi, khong con "ngu".
    if [ -f "$RUNDIR/mariadb-new-pid" ]; then
      MYSQL_PID=$(cat "$RUNDIR/mariadb-new-pid" 2>/dev/null)
      rm -f "$RUNDIR/mariadb-new-pid"
      if [ -n "$MYSQL_PID" ] && kill -0 "$MYSQL_PID" 2>/dev/null; then
        MARIADB_SLEEPING=0
        log "Auto-Sleep: wake-mariadb.php da khoi dong lai MariaDB (pid moi=$MYSQL_PID), tiep tuc giam sat binh thuong"
      fi
    fi
  else
    if ! kill -0 "$MYSQL_PID" 2>/dev/null; then log "MariaDB da thoat"; break; fi
  fi

  if ! kill -0 "$FPM_PID" 2>/dev/null; then log "php-fpm da thoat"; break; fi
  if ! kill -0 "$NGINX_PID" 2>/dev/null; then log "nginx da thoat"; break; fi
  sleep 3
done

kill "$MYSQL_PID" "$FPM_PID" "$NGINX_PID" 2>/dev/null || true
rm -f "$RUNDIR/mariadb-asleep" "$RUNDIR/mariadb-new-pid" 2>/dev/null || true
exit 1
