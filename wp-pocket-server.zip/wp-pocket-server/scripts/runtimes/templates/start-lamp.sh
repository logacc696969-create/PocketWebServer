#!/system/bin/sh
# Chạy bằng /system/bin/sh có sẵn trên mọi máy Android - không cần bash.
#
# Sinh config thật từ template (thay __PLACEHOLDER__ bằng đường dẫn thật của
# THIẾT BỊ NÀY - không biết trước lúc CI build vì mỗi máy cài app ở một
# nativeLibraryDir/filesDir khác nhau).
#
# Tự quyết định chạy ở 2 CHẾ ĐỘ (xem HANDOFF.md mục 1e "Dual-Mode PHP-Lite"):
#   - full: nginx + php-fpm + MariaDB thật (mặc định, máy bình thường trở lên)
#   - lite: `php -S` (built-in server) đơn lẻ + SQLite thay MariaDB (máy quá
#     yếu RAM - đánh đổi hiệu năng chịu tải lấy sự ổn định, xem README/
#     HANDOFF.md mục 1e để biết rõ đánh đổi này)
# Quyết định này CHỈ XẢY RA 1 LẦN DUY NHẤT lúc setup đầu tiên (ghi vào
# $DATA/.runtime-mode), CÁC LẦN SAU LUÔN GIỮ NGUYÊN - tránh nguy cơ đổi hạ
# tầng CSDL của 1 site ĐANG CHẠY THẬT (vd từ MariaDB thật sang SQLite giữa
# chừng sẽ làm WordPress mất kết nối database).
set -e

BIN="$LD_LIBRARY_PATH"    # noi chua tat ca binary da tai: libmariadbd.so, libphpfpm.so, libnginx.so, libphpcli.so...
DATA="$HOME"               # filesDir cua app - noi duy nhat ghi duoc
DOCROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"   # thu muc www (cha cua _supervisor)
SUP="$DOCROOT/_supervisor"
RUNDIR="$DATA/lamp-run"

mkdir -p "$RUNDIR" "$DATA/mysql-data"

MYSQL_SOCK="$RUNDIR/mysql.sock"
FPM_SOCK="$RUNDIR/php-fpm.sock"

log() { echo "[start-lamp] $1"; }

# ============================================================================
# Dual-Mode PHP-Lite: quyet dinh 1 LAN DUY NHAT, luu lai vinh vien
# ============================================================================
LITE_MODE_THRESHOLD_MB=3072   # PDF de xuat "< 3GB" - sua o day neu can tinh chinh
MODE_FILE="$DATA/.runtime-mode"
LITE_MARKER="$RUNDIR/lite-mode"   # PHP (_admin/index.php) doc file nay de dashboard hien dung trang thai

if [ -f "$MODE_FILE" ]; then
  MODE="$(cat "$MODE_FILE")"
else
  RAM_MB="$DEVICE_RAM_MB"
  case "$RAM_MB" in
    ''|*[!0-9]*)
      # Kotlin khong truyen duoc (vd chay tay qua adb shell de debug) - tu
      # doc /proc/meminfo nhu phuong an du phong.
      RAM_MB="$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null)"
      case "$RAM_MB" in ''|*[!0-9]*) RAM_MB=0 ;; esac
      ;;
  esac

  case "$FORCE_LITE_MODE" in
    on) MODE="lite" ;;
    off) MODE="full" ;;
    *)
      if [ "$RAM_MB" -gt 0 ] && [ "$RAM_MB" -lt "$LITE_MODE_THRESHOLD_MB" ]; then
        MODE="lite"
      else
        MODE="full"
      fi
      ;;
  esac

  echo "$MODE" > "$MODE_FILE"
  log "Quyet dinh CHE DO LAN DAU: $MODE (RAM=${RAM_MB}MB, nguong=${LITE_MODE_THRESHOLD_MB}MB, override=${FORCE_LITE_MODE:-auto})."
  log "Se GIU NGUYEN che do nay ve sau, du RAM/override co doi - chi doi duoc bang cach xoa du lieu app (Cai dat > Ung dung > WP Pocket Server > Xoa du lieu)."
fi

if [ "$MODE" = "lite" ]; then
  touch "$LITE_MARKER"
else
  rm -f "$LITE_MARKER"
fi

# --- php.ini dung chung ca 2 che do ---
# Auto-Sleep (xem Prefs.KEY_AUTO_SLEEP_ENABLED, nginx.conf.template,
# wake-mariadb.php) - CHI bat auto_prepend_file khi nguoi dung tu bat tinh
# nang nay VA dang o che do full (khong phai Lite - Lite dung SQLite, khong
# co MariaDB de "ngu"); mac dinh la 1 dong rong, khong doi hanh vi PHP chut nao.
if [ "$AUTO_SLEEP_ENABLED" = "1" ] && [ "$MODE" != "lite" ]; then
  AUTO_SLEEP_PREPEND_LINE="auto_prepend_file = $SUP/activity-touch.php"
else
  AUTO_SLEEP_PREPEND_LINE=""
fi

sed -e "s#__EXT_DIR__#$BIN#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s#__AUTO_SLEEP_PREPEND__#$AUTO_SLEEP_PREPEND_LINE#g" \
    "$SUP/php.ini.template" > "$RUNDIR/php.ini"

# CA cert bundle (neu co dong goi luc build - xem php.sh). Khong fatal neu
# thieu (|| true): chi anh huong "1-Click Install WordPress"
# (_admin/install-wp.php), cac chuc nang khac khong phu thuoc file nay.
cp "$SUP/cacert.pem" "$RUNDIR/cacert.pem" 2>/dev/null || true

mkdir -p "$RUNDIR/php-sessions"

# --- wp-content/cache -> cacheDir Android (thay the AN TOAN cho y tuong
# "RAM Disk"/OverlayFS that KHONG lam duoc tren Android khong root - xem
# HANDOFF.md muc 1h). CHI ap dung cho thu muc CACHE (du lieu tam, cac plugin
# cache cua WordPress tu tao lai duoc binh thuong neu mat) - TUYET DOI KHONG
# dung cach nay cho wp-content/uploads (anh/video NGUOI DUNG tai len, mat la
# mat that, khac han ban chat voi cache). Dat o day (dung chung ca 2 che do)
# vi ca lite (SQLite) lan full (MariaDB) deu co the dung plugin cache.
if [ -d "$DOCROOT/wp-content" ]; then
  CACHE_TARGET="$TMPDIR/wp-content-cache"
  mkdir -p "$CACHE_TARGET"   # luon dam bao co, du Android co the da xoa cacheDir giua cac lan chay truoc
  if [ ! -L "$DOCROOT/wp-content/cache" ]; then
    rm -rf "$DOCROOT/wp-content/cache" 2>/dev/null || true
    ln -s "$CACHE_TARGET" "$DOCROOT/wp-content/cache"
    log "Da tro wp-content/cache sang cacheDir cua Android (giam ghi flash cho du lieu cache tam)"
  fi
fi

# ============================================================================
# CHE DO LITE: `php -S` don le + SQLite (khong MariaDB, khong nginx, khong php-fpm)
# ============================================================================
if [ "$MODE" = "lite" ]; then
  log "=== CHE DO PHP-LITE (may RAM thap - xem HANDOFF.md muc 1e) ==="
  log "Bo qua MariaDB/nginx/php-fpm - chi chay 1 tien trinh 'php -S' duy nhat, doi lay RAM thap nhat co the."

  if [ ! -f "$BIN/libphpcli.so" ]; then
    log "LOI: khong thay libphpcli.so (binary CLI cua PHP) - xem scripts/runtimes/php.sh, khong the chay che do lite"
    exit 1
  fi

  # Neu la site WordPress (co wp-config-sqlite.php.template) VA CHUA cai dat
  # -> kich hoat SQLite LAN DAU (giong het tinh than "quyet dinh 1 lan" o
  # tren, ap dung rieng cho buoc kich hoat DB nay).
  if [ -f "$DOCROOT/wp-config-sqlite.php.template" ] && [ ! -f "$DOCROOT/wp-config.php" ]; then
    log "Kich hoat SQLite Database Integration (lan dau)..."
    if [ -f "$DOCROOT/wp-content/plugins/sqlite-database-integration/db.copy" ]; then
      cp "$DOCROOT/wp-content/plugins/sqlite-database-integration/db.copy" "$DOCROOT/wp-content/db.php"
    else
      log "CANH BAO: khong thay db.copy cua plugin SQLite (co the tai plugin loi luc build - xem site_source.sh), WordPress se KHONG co database"
    fi
    cp "$DOCROOT/wp-config-sqlite.php.template" "$DOCROOT/wp-config.php"
  fi
  # Don sach file .template con lai (ca 2 loai) - KHONG can nua sau buoc
  # tren, xoa han tranh lo salt qua HTTP (dung ly do da sua o che do full).
  rm -f "$DOCROOT/wp-config.php.template" "$DOCROOT/wp-config-sqlite.php.template"

  log "San sang: php -S, cong=$PORT, che do=lite"
  # "exec" thay the han tien trinh sh nay bang php -S (khong fork tien trinh
  # con) - ServerForegroundService dang waitFor() tren tien trinh nay se
  # thay CHINH php -S thoat neu no chet, dung y het co che phat hien crash o
  # che do full, chi khac la KHONG can vong lap giam sat rieng vi chi co 1
  # tien trinh duy nhat (khong nhu che do full phai theo doi 3 PID).
  exec "$BIN/libphpcli.so" -c "$RUNDIR/php.ini" -S "0.0.0.0:$PORT" -t "$DOCROOT" "$SUP/router-lite.php"
fi

# ============================================================================
# CHE DO FULL (mac dinh): nginx + php-fpm + MariaDB that
# ============================================================================
log "=== CHE DO DAY DU (nginx + php-fpm + MariaDB) ==="

# Do "nginx -V" chi in thong tin bien dich roi thoat ngay (khong doc config
# nao ca) nen goi duoc AN TOAN o day, truoc khi nginx.conf ton tai. Xem chu
# thich trong nginx.conf.template ve ly do phai dot truoc thay vi gia dinh.
if "$BIN/libnginx.so" -V 2>&1 | grep -q http_realip_module; then
  log "nginx co module realip - bat khoi phuc IP that cua khach tu Cloudflare"
  CF_REALIP_LINE="set_real_ip_from 127.0.0.1; real_ip_header CF-Connecting-IP; real_ip_recursive off;"
else
  log "CANH BAO: ban nginx nay KHONG co module realip - bo qua khoi phuc IP that, WordPress/log se thay 127.0.0.1 cho moi khach cong khai qua Cloudflare Tunnel (khong anh huong chuc nang khac)"
  CF_REALIP_LINE="# (bo qua: nginx build nay khong co module realip)"
fi

# QUAN TRONG: substitution cua CF_REALIP_LINE dung "|" lam delimiter (thay
# vi "#" nhu cac dong tren) VI nhanh "khong co module" co gia tri BAT DAU
# BANG "#" (dong comment) - dung chung delimiter "#" se lam sed hieu nham
# dau "#" do la dau dong truong thay the, gay loi cu phap "unknown option
# to `s'" va lam TOAN BO script dung (da tu kiem tra bang mo phong truoc
# khi ra soat xong, khong phai gia dinh suong).
sed -e "s#__DOCROOT__#$DOCROOT#g" \
    -e "s#__PORT__#$PORT#g" \
    -e "s#__FPM_SOCK__#$FPM_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s|__CF_REALIP_DIRECTIVES__|$CF_REALIP_LINE|g" \
    "$SUP/nginx.conf.template" > "$RUNDIR/nginx.conf"

sed -e "s#__FPM_SOCK__#$FPM_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    -e "s#__FILESDIR__#$DATA#g" \
    "$SUP/php-fpm.conf.template" > "$RUNDIR/php-fpm.conf"

# Sinh script khoi dong mariadbd DUNG CHUNG (xem wake-mariadb.sh.template) -
# ca lan khoi dong dau tien (duoi day) LAN wake-mariadb.php (Auto-Sleep, xem
# them trong nginx.conf/php.ini) deu goi CHINH XAC 1 file nay, tranh 2 noi
# chua lenh mariadbd bi lech nhau.
sed -e "s#__BIN__#$BIN#g" \
    -e "s#__DATA__#$DATA#g" \
    -e "s#__MYSQL_SOCK__#$MYSQL_SOCK#g" \
    -e "s#__RUNDIR__#$RUNDIR#g" \
    "$SUP/wake-mariadb.sh.template" > "$RUNDIR/wake-mariadb.sh"

# Neu co wp-config.php.template (site_source=wordpress) -> sinh wp-config.php
# that voi duong dan socket MySQL that cua thiet bi nay.
if [ -f "$DOCROOT/wp-config.php.template" ]; then
  sed -e "s#__MYSQL_SOCK__#$MYSQL_SOCK#g" \
      "$DOCROOT/wp-config.php.template" > "$DOCROOT/wp-config.php"
  # QUAN TRONG (bao mat - xem HANDOFF.md muc 1e): file .template nay chua
  # SALT/KHOA BI MAT THAT cua WordPress (sinh luc build boi site_source.sh,
  # lay tu api.wordpress.org that). Da chan bang nginx
  # (location ~* \.template$) nhung xoa han o day la lop bao ve thu 2 - du
  # nginx.conf co bi sua sai/mat dong chan trong tuong lai, file nay cung
  # khong con ton tai de lo ra ngoai. Chi xoa SAU KHI sed thanh cong (dong
  # tren) - "set -e" o dau file da dam bao dung o day neu sed loi.
  rm -f "$DOCROOT/wp-config.php.template"
fi
# Don file .template SQLite (khong dung toi o che do full) neu co, cung ly do bao mat.
rm -f "$DOCROOT/wp-config-sqlite.php.template"

# --- Khoi tao MariaDB data dir lan dau ---
if [ ! -d "$DATA/mysql-data/mysql" ]; then
  log "Khoi tao MariaDB lan dau (co the mat vai chuc giay)..."
  "$BIN/libmariadbinstall.so" --datadir="$DATA/mysql-data" \
      --auth-root-authentication-method=normal > "$RUNDIR/mysql-install.log" 2>&1 \
    || { log "LOI: mariadb-install-db that bai, xem $RUNDIR/mysql-install.log"; exit 1; }
fi

# Cac co so buffer/pool duoi day giam RAM cua mariadbd tu vai tram MB mac
# dinh (thiet ke cho may chu lon) xuong muc toi thieu hop ly cho dien thoai.
# De xuat tu PDF "Toi uu hoa Buffer cua MariaDB" (xem HANDOFF.md muc 1e).
# Da test that bang binary MariaDB 10.11 (Ubuntu x86) - cu phap dung, chi
# chua chay tren chinh binary Termux ARM (xem HANDOFF.md muc 1e). Da bo cờ
# --innodb-buffer-pool-instances sau khi test cho thay no la no-op (bi loai
# bo) tren MariaDB hien dai. (Lenh day du nam trong wake-mariadb.sh, sinh o
# tren - xem chu thich o do.)
/system/bin/sh "$RUNDIR/wake-mariadb.sh" &
MYSQL_PID=$!

log "Cho MariaDB san sang..."
i=0
while [ ! -S "$MYSQL_SOCK" ]; do
  i=$((i + 1))
  if [ "$i" -gt 30 ]; then
    log "LOI: MariaDB khong len sau 30s, xem $RUNDIR/mysqld.log"
    kill "$MYSQL_PID" 2>/dev/null || true
    exit 1
  fi
  sleep 1
done

# Don rac trang thai Auto-Sleep tu 1 lan chay TRUOC (neu app bi Android kill
# dung luc dang "ngu", 2 file nay co the sot lai vi $RUNDIR khong bi xoa
# giua cac lan restart) - lan chay MOI nay vua khoi dong xong mariadbd that
# o tren, chac chan dang THUC, nen phai dam bao khong con file "asleep" gia
# nao khien nginx hieu nham.
rm -f "$RUNDIR/mariadb-asleep" "$RUNDIR/mariadb-new-pid" 2>/dev/null || true

# --- Tao database + user lan dau ---
if [ ! -f "$DATA/.db_initialized" ]; then
  log "Tao database + user wordpress..."
  "$BIN/libmysqlcli.so" --socket="$MYSQL_SOCK" -uroot <<SQL
CREATE DATABASE IF NOT EXISTS wordpress CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'wordpress'@'localhost' IDENTIFIED BY 'wordpress';
GRANT ALL PRIVILEGES ON wordpress.* TO 'wordpress'@'localhost';
FLUSH PRIVILEGES;
SQL
  touch "$DATA/.db_initialized"
fi

# --- php-fpm ---
"$BIN/libphpfpm.so" --nodaemonize --fpm-config "$RUNDIR/php-fpm.conf" -c "$RUNDIR/php.ini" \
    > "$RUNDIR/php-fpm-stdout.log" 2>&1 &
FPM_PID=$!

log "Cho php-fpm san sang..."
i=0
while [ ! -S "$FPM_SOCK" ]; do
  i=$((i + 1))
  if [ "$i" -gt 20 ]; then
    log "LOI: php-fpm khong len sau 20s, xem $RUNDIR/php-fpm.log va $RUNDIR/php-fpm-stdout.log"
    kill "$MYSQL_PID" 2>/dev/null || true
    exit 1
  fi
  sleep 1
done

# --- nginx ---
"$BIN/libnginx.so" -p "$RUNDIR/" -c "$RUNDIR/nginx.conf" -g "daemon off;" \
    > "$RUNDIR/nginx-stdout.log" 2>&1 &
NGINX_PID=$!

log "San sang: MariaDB(pid=$MYSQL_PID) php-fpm(pid=$FPM_PID) nginx(pid=$NGINX_PID), cong=$PORT"

# === Auto-Sleep MariaDB khi ranh (de xuat PDF "Co che Ngu dong thong minh",
# vong 2 - xem HANDOFF.md) ===
# CHI hoat dong khi AUTO_SLEEP_ENABLED=1 (nguoi dung TU bat trong app, xem
# Prefs.KEY_AUTO_SLEEP_ENABLED) - neu khong, moi bien duoi day khong duoc
# dung toi, vong lap giam sat chay Y HET nhu truoc, KHONG THEM RUI RO GI cho
# ai khong bat tinh nang nay.
#
# CO CHE: file "$ACTIVITY_FILE" duoc 1 script PHP cuc nhe (xem
# activity-touch.php + auto_prepend_file trong php.ini.template) "touch"
# (chi cap nhat mtime, KHONG ghi noi dung - re hon nhieu so voi ghi log moi
# request, do do KHONG mau thuan voi triet ly "giam ghi flash" da co - xem
# nginx.conf.template) MOI LAN co request PHP that (tuc la request CAN
# MariaDB). Vong lap duoi day (da chay san moi 3s de giam sat crash) kiem tra
# them: neu $ACTIVITY_FILE khong doi qua X phut, gui SIGTERM cho mariadbd
# (cho thoat SACH, khong SIGKILL - tranh hong du lieu InnoDB) roi tao file
# "mariadb-asleep" de nginx biet duong "chuyen huong" request PHP tiep theo
# sang wake-mariadb.php (xem nginx.conf.template) thay vi noi thang toi
# php-fpm/MariaDB da tat.
#
# "MARIADB_SLEEPING=1" la co QUAN TRONG NHAT o day: no bao vong lap BEN DUOI
# dung coi "MariaDB da thoat" la crash (truoc day MOI truong hop MariaDB
# thoat deu bi coi la crash -> tat het php-fpm+nginx -> Kotlin restart toan
# cum). Neu KHONG co co nay, chinh Auto-Sleep se tu kich hoat "restart toan
# cum" ngay khi no vua tat MariaDB - phan tac dung hoan toan.
AUTO_SLEEP_IDLE_SEC=$(( ${AUTO_SLEEP_IDLE_MINUTES:-30} * 60 ))
ACTIVITY_FILE="$RUNDIR/last-php-activity"
touch "$ACTIVITY_FILE" 2>/dev/null || true   # moc thoi gian ban dau = luc vua khoi dong xong
MARIADB_SLEEPING=0

# --- Giam sat: bat ky tien trinh nao chet -> thoat het (ServerForegroundService
# dang waitFor() tren chinh tien trinh sh nay, se tu restart toan cum) ---
while true; do
  if [ "$AUTO_SLEEP_ENABLED" = "1" ] && [ "$MARIADB_SLEEPING" = "0" ]; then
    NOW=$(date +%s)
    LAST=$(stat -c %Y "$ACTIVITY_FILE" 2>/dev/null || echo "$NOW")
    IDLE=$((NOW - LAST))
    if [ "$IDLE" -ge "$AUTO_SLEEP_IDLE_SEC" ]; then
      log "Auto-Sleep: khong co request PHP nao trong ${IDLE}s (nguong ${AUTO_SLEEP_IDLE_SEC}s) - tat MariaDB de tiet kiem RAM/pin"
      kill -TERM "$MYSQL_PID" 2>/dev/null || true
      wait "$MYSQL_PID" 2>/dev/null   # doi mariadbd tu thoat SACH (flush InnoDB) truoc khi danh dau ngu
      MARIADB_SLEEPING=1
      touch "$RUNDIR/mariadb-asleep" 2>/dev/null || true
      log "Auto-Sleep: MariaDB da ngu (pid cu $MYSQL_PID), cho wake-mariadb.php danh thuc khi co request moi"
    fi
  fi

  if [ "$MARIADB_SLEEPING" = "1" ]; then
    # wake-mariadb.php (chay boi php-fpm, VAN THUC du MariaDB dang ngu) ghi
    # PID moi vao day sau khi tu khoi dong lai mariadbd thanh cong - doc lai
    # de vong lap nay tiep tuc giam sat DUNG tien trinh moi, khong con "ngu".
    if [ -f "$RUNDIR/mariadb-new-pid" ]; then
      MYSQL_PID=$(cat "$RUNDIR/mariadb-new-pid" 2>/dev/null)
      rm -f "$RUNDIR/mariadb-new-pid"
      if [ -n "$MYSQL_PID" ] && kill -0 "$MYSQL_PID" 2>/dev/null; then
        MARIADB_SLEEPING=0
        log "Auto-Sleep: wake-mariadb.php da khoi dong lai MariaDB (pid moi=$MYSQL_PID), tiep tuc giam sat binh thuong"
      fi
    fi
  else
    if ! kill -0 "$MYSQL_PID" 2>/dev/null; then log "MariaDB da thoat"; break; fi
  fi

  if ! kill -0 "$FPM_PID" 2>/dev/null; then log "php-fpm da thoat"; break; fi
  if ! kill -0 "$NGINX_PID" 2>/dev/null; then log "nginx da thoat"; break; fi
  sleep 3
done

kill "$MYSQL_PID" "$FPM_PID" "$NGINX_PID" 2>/dev/null || true
rm -f "$RUNDIR/mariadb-asleep" "$RUNDIR/mariadb-new-pid" 2>/dev/null || true
exit 1
