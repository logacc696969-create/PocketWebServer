<?php
// Dashboard metrics theo thoi gian - xem HANDOFF.md muc 10, de xuat DeepSeek
// muc A4/A5. Doc $RUNDIR/metrics.csv (ghi boi start-lamp.sh, moi ~5 phut,
// CHI o che do Full - xem chu thich trong start-lamp.sh giai thich vi sao
// Lite khong co vong lap nay). Ve sparkline bang SVG thuan PHP, KHONG dung
// Chart.js/thu vien JS ngoai nao (nhe hon nhieu cho dien thoai, dung tinh
// than da noi trong HANDOFF: "khong dung Prometheus/Grafana - qua nang").
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$rundir = $appHome !== '' ? $appHome . '/lamp-run' : null;
$csvFile = $rundir !== null ? $rundir . '/metrics.csv' : null;

$rangeOptions = ['24h' => ['Ngay', 288], '3d' => ['3 ngay', 864], '7d' => ['7 ngay', 2016]];
$range = isset($_GET['range'], $rangeOptions[$_GET['range']]) ? $_GET['range'] : '24h';
$limit = $rangeOptions[$range][1];

$rows = [];
$readError = '';
if ($csvFile === null) {
    $readError = 'Khong doc duoc APP_HOME.';
} elseif (!is_readable($csvFile)) {
    $readError = 'Chua co du lieu metrics (che do Lite khong ghi metrics, hoac may vua khoi dong lai, chua du 5 phut de ghi dong dau tien).';
} else {
    $fh = fopen($csvFile, 'r');
    $header = fgetcsv($fh);
    if (is_array($header)) {
        while (($r = fgetcsv($fh)) !== false) {
            if (count($r) === count($header)) {
                $rows[] = array_combine($header, $r);
            }
        }
    }
    fclose($fh);
    $rows = array_slice($rows, -$limit);
}

/**
 * Ve 1 sparkline SVG don gian tu 1 cot du lieu. Khong dung thu vien ngoai -
 * chi la 1 <polyline> voi toa do tu tinh tay, du de thay xu huong.
 */
function wp_pocket_sparkline(array $rows, string $key, string $color, string $unit = '%'): string
{
    $vals = [];
    foreach ($rows as $r) {
        $v = $r[$key] ?? '';
        $vals[] = ($v === '' || $v === null) ? null : (float) $v;
    }
    $present = array_values(array_filter($vals, static fn ($v) => $v !== null));
    if (count($present) < 2) {
        return '<p style="color:#999;font-size:13px;margin:8px 0">(chua du du lieu de ve bieu do)</p>';
    }
    $min = min($present);
    $max = max($present);
    if ($max <= $min) {
        $max = $min + 1;
    }
    $w = 640;
    $h = 90;
    $pad = 6;
    $n = count($vals);
    $points = [];
    foreach ($vals as $i => $v) {
        if ($v === null) {
            continue;
        }
        $x = $pad + ($n > 1 ? ($i / ($n - 1)) : 0) * ($w - 2 * $pad);
        $y = $h - $pad - (($v - $min) / ($max - $min)) * ($h - 2 * $pad);
        $points[] = round($x, 1) . ',' . round($y, 1);
    }
    $last = end($present);
    $svg = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" preserveAspectRatio="none" style="width:100%;height:90px;display:block;background:#fafafa;border-radius:8px">'
        . '<polyline points="' . htmlspecialchars(implode(' ', $points), ENT_QUOTES, 'UTF-8') . '" fill="none" stroke="' . $color . '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>'
        . '</svg>';
    $info = 'Gan nhat: <b>' . htmlspecialchars((string) $last, ENT_QUOTES, 'UTF-8') . $unit . '</b>'
        . ' &nbsp;&middot;&nbsp; thap nhat ' . htmlspecialchars((string) round($min, 1), ENT_QUOTES, 'UTF-8') . $unit
        . ' &nbsp;&middot;&nbsp; cao nhat ' . htmlspecialchars((string) round($max, 1), ENT_QUOTES, 'UTF-8') . $unit;
    return $svg . '<div style="font-size:12px;color:#666;margin:6px 0 18px">' . $info . '</div>';
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Metrics</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:680px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
h2{font-size:15px;margin:22px 0 4px;color:#333}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.tabs{display:flex;gap:8px;margin:12px 0}
.tabs a{padding:6px 14px;border-radius:20px;text-decoration:none;font-size:13px;color:#333;background:#eee}
.tabs a.active{background:#2d6cdf;color:#fff}
.note{background:#fff8e1;color:#7a5b00;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Thong ke theo thoi gian</h1>

<div class="tabs">
<?php foreach ($rangeOptions as $key => [$label, $n]): ?>
    <a class="<?= $key === $range ? 'active' : '' ?>" href="?range=<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></a>
<?php endforeach; ?>
</div>

<?php if ($readError !== ''): ?>
<div class="note"><?= htmlspecialchars($readError, ENT_QUOTES, 'UTF-8') ?></div>
<?php else: ?>

<h2>RAM da dung (%)</h2>
<?= wp_pocket_sparkline($rows, 'ram_pct', '#c0392b') ?>

<h2>Dung luong dia da dung (%)</h2>
<?= wp_pocket_sparkline($rows, 'disk_pct', '#2d6cdf') ?>

<h2>Load average (1 phut)</h2>
<?= wp_pocket_sparkline($rows, 'load1', '#1d7a3d', '') ?>

<p style="color:#999;font-size:12px">Ghi moi ~5 phut, giu toi da ~7 ngay gan nhat (<?= count($rows) ?> diem du lieu dang hien thi).</p>
<?php endif; ?>
</body>
</html>
