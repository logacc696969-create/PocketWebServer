<?php
// WP-CLI console - de xuat DeepSeek muc A9 (xem HANDOFF.md muc 10 + muc
// 1ap): "Hosting tra phi cho SSH + WP-CLI. Mobile khong co SSH (da tu choi
// o muc 1d), nhung WP-CLI la file PHP (wp-cli.phar) - chay duoc bang
// `php wp-cli.phar`."
//
// GHI CHU BAO MAT (doc truoc khi dung, DA CAP NHAT o muc 1at sau fuzz test
// that - xem bloc preg_match ben duoi): trang nay cho phep chay lenh WP-CLI
// (ke ca `wp eval`/`wp shell` - THUC THI PHP TUY Y trong pham vi WordPress)
// - VE NGUYEN TAC van tuong duong muc rui ro voi Adminer (SQL tuy y) va
// Tiny File Manager (ghi file tuy y) da co san trong _admin/, nen KHONG
// them 1 toggle bat/tat rieng (se khong nhat quan). NHUNG khac Adminer/TFM
// o 1 diem: ten "WP-CLI console" de nguoi dung lam tuong day la cong cu
// GIOI HAN (chi lenh WP-CLI), trong khi ban dau KHONG loc ky tu dieu khien
// shell nen thuc ra la 1 shell console tran - da tu fuzz test THAT (gui
// backtick/$()/; ...) va XAC NHAN khai thac duoc that, khong chi ly thuyet.
// Da vang chan cac ky tu dieu khien shell co ban (xem preg_match duoi day)
// - GIAM rui ro "khoang cach nhan thuc" do, nhung VAN la 1 cong cu quyen
// luc cao (wp eval/wp shell van chay PHP tuy y HOP LE trong pham vi
// WP-CLI, khong qua duong shell) - neu khong yen tam, coi day la 1 ly do
// de BAT 2FA (da co san) thay vi tat han trang nay.
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$extDir = rtrim((string) getenv('EXT_DIR'), '/');
$docroot = $appHome !== '' ? $appHome . '/www' : '';
$phpCliBin = $extDir !== '' ? $extDir . '/libphpcli.so' : '';
$wpCliPhar = $extDir !== '' ? $extDir . '/wp-cli.phar' : '';

$missing = [];
if ($appHome === '') $missing[] = 'bien moi truong APP_HOME';
if ($extDir === '') $missing[] = 'bien moi truong EXT_DIR';
if ($phpCliBin !== '' && !is_file($phpCliBin)) $missing[] = "PHP CLI ($phpCliBin)";
if ($wpCliPhar !== '' && !is_file($wpCliPhar)) $missing[] = "wp-cli.phar ($wpCliPhar) - co the do build khong tai duoc file nay (xem php.sh), khong phai loi cua ban";

function esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

$output = null;
$ranCommand = '';
$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($missing)) {
    if (!wp_pocket_csrf_verify()) {
        // CSRF check (xem HANDOFF.md muc 10, de xuat DeepSeek muc G5) -
        // dung LAI helper CHUNG da co san trong auth.php, khong tu viet
        // rieng.
        $errorMsg = 'Token bao mat (CSRF) khong hop le hoac da het han - tai lai trang va thu lai.';
    } else {
        // 1bd: du lieu/tep WordPress co the vua doi tu ngoai pool php-fpm -> bao object-cache.php (APCu) xoa cache (xem HANDOFF.md muc 1bd).
        register_shutdown_function('wp_pocket_bump_object_cache_epoch');
        $ranCommand = trim((string) ($_POST['cmd'] ?? ''));
        if ($ranCommand === '') {
            $errorMsg = 'Chua nhap lenh.';
        } else {
            // Bo tien to "wp " neu nguoi dung go nham theo thoi quen dong
            // shell that (o day KHONG can go "wp", chi can phan sau, vd
            // "plugin list" thay vi "wp plugin list").
            $ranCommand = preg_replace('/^wp\s+/', '', $ranCommand);
            // G4 (1bk): vet audit gom 2 tu dau cua lenh (vd "plugin install", "user create") - KHONG ghi doi so (co the chua mat khau/URL).
            if (preg_match('/^([a-z][a-z0-9-]*)(?:\s+([a-z][a-z0-9-]*))?/', $ranCommand, $auditCmd)) {
                wp_pocket_session_audit('wp-cli ' . $auditCmd[1] . (isset($auditCmd[2]) ? ' ' . $auditCmd[2] : ''));
            }

            // DINH CHINH (xem HANDOFF.md muc 1at) - ban dau trang nay KHONG
            // loc ky tu dac biet shell (chi escape 3 duong dan co dinh), voi
            // ly do "tuong duong rui ro Adminer/TFM da co san". Fuzz test
            // THAT (gui backtick/$()/;  vao o nay) DA XAC NHAN cu the: co
            // the thoat khoi pham vi lenh WP-CLI du dinh, chay duoc LENH
            // SHELL TUY Y - khac voi "tuong duong Adminer" o 1 diem quan
            // trong: ten "WP-CLI console" de nguoi dung LAM TUONG day la 1
            // cong cu gioi han (chi chay lenh WP-CLI), khong nhan ra day
            // THUC RA la 1 shell console tran - khoang cach nhan thuc do la
            // rui ro rieng, khong chi la "cung muc do voi Adminer". Vi vay
            // CHAN HAN cac ky tu dieu khien shell (khong phai whitelist cu
            // phap WP-CLI - WP-CLI co cu phap da dang, lam whitelist de sai
            // sot hon la chan dung 1 nhom ky tu CO DINH, hiem khi can thiet
            // cho lenh WP-CLI thuc su). Van giu dau nhay don/kep (can cho
            // "search-replace \"old\" \"new\"") va dau gach ngang/cham
            // (--dry-run, wp-content/plugin.php) - chi chan ky tu THUC SU
            // la dieu khien shell.
            // 1br: fuzz ngau nhien co seed (scripts/tests/admin-fuzz-test.py) tim ra byte NUL trong lenh lam shell_exec() nem ValueError (PHP 8) -> Fatal 500
            // (khong chay duoc lenh, nhung la loi that). Chan them MOI ky tu dieu khien (tru tab) va gioi han do dai.
            if (strlen($ranCommand) > 2000) {
                $errorMsg = 'Lenh qua dai (toi da 2000 ky tu).';
            } elseif (preg_match('/[`;&|<>\x00-\x08\x0a-\x1f\x7f]|\$\(/', $ranCommand)) {
                $errorMsg = 'Lenh chua ky tu khong duoc phep (` ; & | < > ky tu dieu khien hoac $(...)) - day la gioi han CO CHU Y de tranh chay lenh shell ngoai y dinh WP-CLI, xem ghi chu bao mat o dau file nguon. Neu that su can lam viec nay, dung File Manager/Adminer da co san trong _admin/.';
            } else {
                $cmdLine = escapeshellarg($phpCliBin) . ' ' . escapeshellarg($wpCliPhar) . ' '
                    . $ranCommand
                    . ' --path=' . escapeshellarg($docroot)
                    . ' --no-color 2>&1';
                $output = @shell_exec($cmdLine);
                if ($output === null) {
                    $errorMsg = 'Khong chay duoc (shell_exec co the da bi vo hieu hoa tren may nay - kiem tra disable_functions trong php.ini).';
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WP-CLI console</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:720px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.note{background:#fff8e1;color:#7a5b00;padding:12px 14px;border-radius:8px;font-size:13px;margin:16px 0;line-height:1.5}
.err{background:#fdecea;color:#8a1c1c;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0}
form{display:flex;gap:8px;margin:16px 0}
input[type=text]{flex:1;padding:10px 12px;border:1px solid #ccc;border-radius:8px;font-family:monospace;font-size:14px}
button{padding:10px 18px;border:0;border-radius:8px;background:#2271b1;color:#fff;font-size:14px;cursor:pointer}
pre{background:#1e1e1e;color:#d4d4d4;padding:14px;border-radius:8px;overflow-x:auto;font-size:13px;white-space:pre-wrap;word-break:break-all}
.examples{font-size:13px;color:#666;margin:8px 0 0}
.examples code{background:#f3f3f3;padding:1px 5px;border-radius:4px}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>WP-CLI console</h1>

<?php if (!empty($missing)): ?>
<div class="note">
  Chua dung duoc: thieu <?= esc(implode(', ', $missing)) ?>.
</div>
<?php else: ?>

<div class="note">
  Chay lenh WP-CLI trong pham vi site nay. KHONG can go chu "wp" o dau -
  vi du go <code>plugin list</code> thay vi <code>wp plugin list</code>.
  Xem ghi chu bao mat o dau file nguon trang nay: console nay manh tuong
  duong Adminer/File Manager da co san, dung chung 1 rao chan dang nhap.
</div>

<?php if ($errorMsg !== ''): ?>
<div class="err"><?= esc($errorMsg) ?></div>
<?php endif; ?>

<form method="post">
  <?= wp_pocket_csrf_field() ?>
  <input type="text" name="cmd" placeholder="vd: plugin list" value="<?= esc($ranCommand) ?>" autofocus>
  <button type="submit">Chay</button>
</form>
<p class="examples">
  Thuong dung: <code>plugin list</code> &middot; <code>theme list</code>
  &middot; <code>core version</code> &middot;
  <code>user create ten ban@vi-du.com --role=administrator</code> &middot;
  <code>search-replace "url-cu" "url-moi"</code> &middot;
  <code>cron event list</code> &middot; <code>cron event run --due-now</code>
  (chay ngay cac tac vu WP-Cron da den han) &middot;
  <b>kiem tra toan ven</b> (PDF 2 G5/R13, ban co the bi hack/loi dia neu bao &quot;does not verify&quot;):
  <code>core verify-checksums</code> &middot; <code>plugin verify-checksums --all</code>
  (so sanh tep voi ban goc tren wordpress.org - can mang)
  &middot; <b>anh</b> (PDF 2 I4): <code>media regenerate --only-missing --yes</code> (tao lai anh thu nho con thieu sau khi doi theme
  hoac bat GD) &middot; <b>child theme</b> (PDF 2 I5): <code>scaffold child-theme ten-moi --parent_theme=ten-theme-cha</code>
  (ten-theme-cha lay tu <code>theme list</code>)
</p>

<?php if ($output !== null): ?>
<h2 style="font-size:15px">Ket qua: <code><?= esc($ranCommand) ?></code></h2>
<pre><?= esc($output) ?></pre>
<?php endif; ?>

<?php endif; ?>
</body>
</html>
