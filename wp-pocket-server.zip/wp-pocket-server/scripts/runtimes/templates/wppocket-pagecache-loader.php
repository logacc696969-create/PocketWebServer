<?php
/**
 * Plugin Name: WP Pocket - xoa page cache khi noi dung cong khai doi
 * Description: Bo sung cho TTL 2 phut cua page cache nginx (HANDOFF.md muc 1bg). Logic nam o wppocket-pagecache/purge.php.
 *
 * Tach 2 file CO CHU DICH: file nap nay cuc ngan va duoc nap boi WordPress cho MOI request - mot loi cu phap o day lam TRANG CA SITE.
 * Logic that nam o purge.php, nap qua try/catch Throwable: loi trong do (ke ca ParseError, la Throwable tu PHP 7) chi lam mat tinh nang
 * xoa cache, KHONG lam hong website.
 */
if (!defined('ABSPATH')) {
    exit;
}
try {
    require __DIR__ . '/wppocket-pagecache/purge.php';
} catch (\Throwable $e) {
    // nuot: tinh nang phu, khong duoc anh huong website
}
