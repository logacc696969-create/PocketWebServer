<?php
// Thong ke truy cap nhe - xem HANDOFF.md muc 10, de xuat DeepSeek muc A5
// ("top pages, top IPs, top 404s, bang thong theo ngay... khong can
// GoAccess - awk + PHP du cho 1 site ca nhan"). CHON PHP THUAN thay vi awk
// (PDF de xuat): tranh phu thuoc 1 binary CHUA XAC NHAN co san tren moi ban
// Termux (xem tinh than chung ca du an - HANDOFF.md nhieu cho nhac "chua
// verify tren thiet bi that, khong doan mu"), va PHP da la ky thuat CHUNG
// MINH hoat dong o day (admin-metrics.php cung tu parse file thuan PHP,
// khong goi binary ngoai).
//
// Doc dung format "wp_pocket" da dinh nghia trong nginx.conf.template (xem
// de xuat DeepSeek muc O8 - them $request_time vao cuoi dong):
//   $remote_addr - $remote_user [$time_local] "$request" $status
//   $body_bytes_sent "$http_referer" "$http_user_agent" rt=$request_time
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$logFile = $appHome !== '' ? $appHome . '/lamp-run/nginx-access.log' : null;

// Doc toi da 2MB CUOI file (giong tinh than "khong nap ca file vao RAM neu
// phinh to bat thuong" da dung trong LogViewerActivity.kt/tailFile()) - du
// an nay tu xoay (rotate) nginx-access.log moi khi vuot 5MB (xem
// start-lamp.sh, de xuat DeepSeek muc F1), nen 2MB cuoi thuong la GAN NHU
// toan bo du lieu con lai sau lan xoay gan nhat.
const MAX_READ_BYTES = 2 * 1024 * 1024;
const TOP_N = 10;

$readError = '';
$lines = [];
if ($logFile === null) {
    $readError = 'Khong doc duoc APP_HOME.';
} elseif (!is_readable($logFile)) {
    $readError = 'Chua co nginx-access.log (may vua khoi dong lai, hoac che do Lite khong chay nginx).';
} else {
    $size = filesize($logFile);
    $fh = fopen($logFile, 'r');
    if ($size > MAX_READ_BYTES) {
        fseek($fh, -MAX_READ_BYTES, SEEK_END);
        fgets($fh); // bo dong dau co the bi cat dang do
    }
    while (($l = fgets($fh)) !== false) {
        $lines[] = $l;
    }
    fclose($fh);
}

$pattern = '/^(\S+) \S+ \S+ \[([^\]]+)\] "([A-Z]+) (\S+)[^"]*" (\d{3}) (\d+) "([^"]*)" "([^"]*)" rt=([\d.]+)/';

$hitsByPath = [];
$hitsByIp = [];
$hits404 = [];
$bytesByDay = [];
$totalRequests = 0;
$total4xx = 0;
$total5xx = 0;
$parsedOk = 0;

foreach ($lines as $line) {
    if (!preg_match($pattern, $line, $m)) {
        continue;
    }
    $parsedOk++;
    [, $ip, $timeLocal, , $path, $status, $bytes] = $m;
    $status = (int) $status;
    $bytes = (int) $bytes;
    $totalRequests++;

    // Bo query string khi dem "top trang" (?, "/bai-viet/?utm=..." va
    // "/bai-viet/" nen tinh chung 1 trang) - giu nguyen cho thong ke 404
    // (loi thuong ro rang hon khi thay ca query string that gay loi).
    $pathNoQuery = strtok($path, '?');
    $hitsByPath[$pathNoQuery] = ($hitsByPath[$pathNoQuery] ?? 0) + 1;
    $hitsByIp[$ip] = ($hitsByIp[$ip] ?? 0) + 1;

    if ($status === 404) {
        $hits404[$path] = ($hits404[$path] ?? 0) + 1;
    }
    if ($status >= 400 && $status < 500) {
        $total4xx++;
    } elseif ($status >= 500) {
        $total5xx++;
    }

    // $time_local dang "28/Sep/2026:14:32:10 +0700" - chi can 10 ky tu dau
    // ("28/Sep/2026") de gom theo ngay, khong can parse day du thanh
    // DateTime (nhe hon, du dung cho muc dich gom nhom o day).
    $day = substr($timeLocal, 0, 11);
    $bytesByDay[$day] = ($bytesByDay[$day] ?? 0) + $bytes;
}

arsort($hitsByPath);
arsort($hitsByIp);
arsort($hits404);
// bytesByDay: KHONG sort theo gia tri (giu thu tu THOI GIAN xuat hien tu
// tren xuong trong log, tuc la cu -> moi, dung thu tu doc tu nhien hon la
// sap xep theo dung luong).

function format_bytes_short($bytes)
{
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 1) . ' ' . $units[$i];
}

function esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Thong ke truy cap</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:680px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
h2{font-size:15px;margin:22px 0 4px;color:#333}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.note{background:#fff8e1;color:#7a5b00;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0}
.summary{display:flex;gap:16px;flex-wrap:wrap;margin:14px 0}
.summary div{background:#f3f6fb;border-radius:8px;padding:10px 14px;font-size:13px;color:#444;min-width:100px}
.summary b{display:block;font-size:18px;color:#222}
table{width:100%;border-collapse:collapse;font-size:13px;margin-bottom:6px}
td,th{padding:5px 6px;border-bottom:1px solid #eee;text-align:left}
th{color:#888;font-weight:normal;font-size:12px}
td.num{text-align:right;white-space:nowrap;color:#555}
td.path{word-break:break-all}
.empty{color:#999;font-size:13px;margin:6px 0 18px}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Thong ke truy cap</h1>

<?php if ($readError !== ''): ?>
<div class="note"><?= esc($readError) ?></div>
<?php else: ?>

<div class="summary">
  <div><b><?= number_format($totalRequests) ?></b>request</div>
  <div><b><?= number_format(count($hitsByIp)) ?></b>IP khac nhau</div>
  <div><b><?= number_format($total4xx) ?></b>loi 4xx</div>
  <div><b><?= number_format($total5xx) ?></b>loi 5xx</div>
</div>
<p class="empty">
  Doc <?= number_format($parsedOk) ?> dong tu file log hien tai (nginx tu
  xoa trang log khi vuot 5MB - xem HANDOFF.md muc 10 - nen day CHUA PHAI
  lich su dai han, chi phan anh tu lan xoay gan nhat).
</p>

<h2>Top <?= TOP_N ?> trang duoc xem nhieu nhat</h2>
<?php if (!$hitsByPath): ?>
<p class="empty">(chua co du lieu)</p>
<?php else: ?>
<table><tr><th>Duong dan</th><th>Luot</th></tr>
<?php foreach (array_slice($hitsByPath, 0, TOP_N, true) as $p => $c): ?>
<tr><td class="path"><?= esc($p) ?></td><td class="num"><?= number_format($c) ?></td></tr>
<?php endforeach; ?>
</table>
<?php endif; ?>

<h2>Top <?= TOP_N ?> IP truy cap nhieu nhat</h2>
<?php if (!$hitsByIp): ?>
<p class="empty">(chua co du lieu)</p>
<?php else: ?>
<table><tr><th>Dia chi IP</th><th>Luot</th></tr>
<?php foreach (array_slice($hitsByIp, 0, TOP_N, true) as $ip => $c): ?>
<tr><td><?= esc($ip) ?></td><td class="num"><?= number_format($c) ?></td></tr>
<?php endforeach; ?>
</table>
<p class="empty">
  Neu toan bo hien "127.0.0.1": ban nginx nay thieu module realip (xem log
  khoi dong) - moi khach qua Cloudflare Tunnel bi thay chung thanh dia chi
  cuc bo, khong phai loi trang nay.
</p>
<?php endif; ?>

<h2>Top <?= TOP_N ?> trang bao loi 404 (khong tim thay)</h2>
<?php if (!$hits404): ?>
<p class="empty">(khong co loi 404 nao trong khoang du lieu dang xem)</p>
<?php else: ?>
<table><tr><th>Duong dan</th><th>Luot</th></tr>
<?php foreach (array_slice($hits404, 0, TOP_N, true) as $p => $c): ?>
<tr><td class="path"><?= esc($p) ?></td><td class="num"><?= number_format($c) ?></td></tr>
<?php endforeach; ?>
</table>
<?php endif; ?>

<h2>Bang thong theo ngay</h2>
<?php if (!$bytesByDay): ?>
<p class="empty">(chua co du lieu)</p>
<?php else: ?>
<table><tr><th>Ngay</th><th>Da gui</th></tr>
<?php foreach ($bytesByDay as $day => $b): ?>
<tr><td><?= esc($day) ?></td><td class="num"><?= esc(format_bytes_short($b)) ?></td></tr>
<?php endforeach; ?>
</table>
<p class="empty">
  Huu ich neu ban chay qua 4G thay vi WiFi - biet dang "dot" bao nhieu du
  lieu di dong moi ngay (xem HANDOFF.md nhom B, toi uu di dong).
</p>
<?php endif; ?>

<?php endif; ?>
</body>
</html>
