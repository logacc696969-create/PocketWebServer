<?php
// Bao ve site + luat IP cua _admin/ - HANDOFF.md muc 1bl (PDF 2: G7 "IP whitelist/blacklist", C10/R19 "rate limit toan site",
// R20 "chan bot xau theo User-Agent"). Moi muc MAC DINH TAT; bat/tat bang file co trong lamp-run/ (cung mau trang bao tri):
//   rate-limit-on   -> nginx.conf.template: limit_req 10 yeu cau PHP/giay/IP (dot 30), tra HTTP 429; /wp-admin/ va file tinh KHONG bi gioi han.
//   block-bots-on   -> nginx.conf.template: tra HTTP 403 cho User-Agent cua cong cu quet lo hong va bot SEO/cao du lieu ngon bang thong.
//   admin-ip-rules.json -> admin-auth.php: allowlist/denylist IP cho CHINH _admin/ (them mot lop ben tren "chi LAN" + mat khau + 2FA).
// nginx doc file co MOI request (open_file_cache_errors off): bat co hieu luc ngay, tat sau toi da ~2 giay (nhu bao tri).
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$rundir = $appHome !== '' ? $appHome . '/lamp-run' : null;
$liteMode = $rundir !== null && file_exists($rundir . '/lite-mode');
$flagRate = $rundir !== null ? $rundir . '/rate-limit-on' : null;
$flagBots = $rundir !== null ? $rundir . '/block-bots-on' : null;
$rulesFile = $rundir !== null ? $rundir . '/admin-ip-rules.json' : null;
$me = (string) ($_SERVER['REMOTE_ADDR'] ?? '');

function esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

/** Luu file luat IP nguyen tu (ghi tmp roi rename) de nginx/PHP khong bao gio doc phai file ghi do dang. */
function wp_pocket_protect_write(string $file, string $content): bool
{
    $tmp = $file . '.tmp';
    if (@file_put_contents($tmp, $content, LOCK_EX) === false) {
        return false;
    }
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

$msg = '';
$err = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    if (!wp_pocket_csrf_verify()) {
        $err = 'Token bao mat (CSRF) khong hop le hoac da het han - tai lai trang va thu lai.';
    } elseif ($rundir === null || !is_dir($rundir)) {
        $err = 'Khong tim thay thu muc lamp-run (APP_HOME chua dat) - hay bat server it nhat 1 lan.';
    } elseif ($action === 'rate_on' || $action === 'rate_off' || $action === 'bots_on' || $action === 'bots_off') {
        $flag = strpos($action, 'rate_') === 0 ? $flagRate : $flagBots;
        $on = substr($action, -3) === '_on';
        if ($on) {
            $ok = @file_put_contents($flag, '') !== false;
        } else {
            $ok = !file_exists($flag) || @unlink($flag);
        }
        if ($ok) {
            $msg = ($flag === $flagRate ? 'Gioi han toc do' : 'Chan bot') . ($on ? ' DA BAT.' : ' da tat.');
        } else {
            $err = 'Khong ghi duoc file co (' . basename((string) $flag) . ') - kiem tra quyen/dung luong.';
        }
    } elseif ($action === 'ip_save') {
        $mode = is_string($_POST['mode'] ?? null) ? $_POST['mode'] : 'off';
        $text = is_string($_POST['entries'] ?? null) ? $_POST['entries'] : '';
        $entries = [];
        $bad = [];
        $lines = preg_split('/\R/', $text, -1, PREG_SPLIT_NO_EMPTY);
        foreach (is_array($lines) ? $lines : [] as $line) {
            $line = trim((string) preg_replace('/#.*$/', '', $line));
            if ($line === '') {
                continue;
            }
            if (strpos($line, '/') !== false) {
                [$base, $bits] = explode('/', $line, 2);
                if (filter_var($base, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false && ctype_digit($bits) && (int) $bits <= 32) {
                    $entries[] = $base . '/' . (int) $bits;
                } else {
                    $bad[] = $line;
                }
            } elseif (filter_var($line, FILTER_VALIDATE_IP) !== false) {
                $entries[] = (string) inet_ntop((string) inet_pton($line));
            } else {
                $bad[] = $line;
            }
        }
        $entries = array_values(array_unique($entries));
        if (!in_array($mode, ['off', 'allow', 'deny'], true)) {
            $err = 'Che do khong hop le.';
        } elseif ($bad) {
            $err = 'Dong khong phai dia chi IP/CIDR IPv4 hop le: ' . implode(', ', array_slice($bad, 0, 5)) . '. Chua luu gi.';
        } elseif (count($entries) > 50) {
            $err = 'Toi da 50 muc. Chua luu gi.';
        } elseif ($mode === 'off') {
            if (!file_exists($rulesFile) || @unlink($rulesFile)) {
                $msg = 'Da TAT luat IP (xoa danh sach).';
            } else {
                $err = 'Khong xoa duoc file luat.';
            }
        } elseif (!$entries) {
            $err = ($mode === 'allow' ? 'Che do "chi cho phep" can it nhat 1 dia chi - neu de trong se khoa tat ca moi nguoi.' : 'Che do "chan" can it nhat 1 dia chi.') . ' Chua luu gi.';
        } elseif ($mode === 'allow' && !wp_pocket_ip_matches($me, $entries)) {
            $err = 'IP hien tai cua ban (' . $me . ') KHONG nam trong danh sach "chi cho phep" - luu se KHOA CHINH BAN. Hay them IP nay roi luu lai.';
        } elseif ($mode === 'deny' && wp_pocket_ip_matches($me, $entries)) {
            $err = 'IP hien tai cua ban (' . $me . ') nam trong danh sach CHAN - luu se khoa chinh ban. Hay bo IP nay roi luu lai.';
        } else {
            $json = json_encode(['mode' => $mode, 'entries' => $entries], JSON_UNESCAPED_SLASHES);
            if (is_string($json) && wp_pocket_protect_write($rulesFile, $json . "\n")) {
                $msg = 'Da luu luat IP: ' . ($mode === 'allow' ? 'CHI cho phep' : 'CHAN') . ' ' . count($entries) . ' muc.';
            } else {
                $err = 'Khong ghi duoc file luat.';
            }
        }
    } else {
        $err = 'Hanh dong khong hop le.';
    }
}

$rateOn = $flagRate !== null && file_exists($flagRate);
$botsOn = $flagBots !== null && file_exists($flagBots);
$rules = wp_pocket_ip_rules_load();
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bao ve site</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:720px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
h2{font-size:16px;margin:0 0 6px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.card{border:1px solid #ddd;border-radius:10px;padding:14px 16px;margin:14px 0}
.state{display:inline-block;font-size:12px;font-weight:700;padding:1px 8px;border-radius:9px;margin-left:6px}
.state.on{background:#e3f4e8;color:#1d7a3d}.state.off{background:#eceff3;color:#556}
.msg{background:#e3f4e8;color:#1d7a3d;padding:10px 14px;border-radius:8px;margin:12px 0;font-size:14px}
.err{background:#fdecea;color:#8a1c1c;padding:10px 14px;border-radius:8px;margin:12px 0;font-size:14px}
.note{background:#fff8e1;color:#7a5b00;padding:10px 14px;border-radius:8px;margin:12px 0;font-size:13px}
p,li{font-size:14px;line-height:1.5}
button{padding:8px 14px;font-size:14px;border:0;border-radius:8px;background:#1a73e8;color:#fff}
button.off{background:#777}
button:disabled{opacity:.45}
textarea{width:100%;box-sizing:border-box;min-height:96px;font-family:ui-monospace,monospace;font-size:13px}
label{display:block;margin:4px 0;font-size:14px}
.small{color:#777;font-size:12px}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Bao ve site</h1>

<?php if ($msg !== ''): ?><div class="msg"><?= esc($msg) ?></div><?php endif; ?>
<?php if ($err !== ''): ?><div class="err"><?= esc($err) ?></div><?php endif; ?>
<?php if ($liteMode): ?>
<div class="note">Che do Lite (khong co nginx): hai muc <b>gioi han toc do</b> va <b>chan bot</b> CHUA co tac dung (chi che do Day du moi co nginx). Luat IP cho <code>_admin/</code> van hoat dong.</div>
<?php endif; ?>

<div class="card">
  <h2>Gioi han toc do toan site <span class="state <?= $rateOn ? 'on' : 'off' ?>"><?= $rateOn ? 'DANG BAT' : 'TAT' ?></span></h2>
  <p>Moi dia chi IP toi da <b>10 yeu cau PHP/giay</b> (cho phep dot ngan 30); vuot thi nhan <b>HTTP 429</b>. Chong tu dong do/spam lam can CPU dien thoai.
  <b>Khong</b> gioi han: <code>/wp-admin/</code> va file tinh (anh, CSS, JS) - mot trang WordPress tai hang chuc file khong bi chan nham.
  IP that cua khach lay tu header <code>CF-Connecting-IP</code> cua Cloudflare (khong co thi dung IP ket noi).</p>
  <form method="post"><?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="<?= $rateOn ? 'rate_off' : 'rate_on' ?>">
    <button type="submit" class="<?= $rateOn ? 'off' : '' ?>"<?= $liteMode ? ' disabled' : '' ?>><?= $rateOn ? 'Tat gioi han toc do' : 'Bat gioi han toc do' ?></button>
  </form>
</div>

<div class="card">
  <h2>Chan bot quet lo hong / cao du lieu <span class="state <?= $botsOn ? 'on' : 'off' ?>"><?= $botsOn ? 'DANG BAT' : 'TAT' ?></span></h2>
  <p>Tra <b>HTTP 403</b> cho User-Agent cua cong cu quet lo hong (sqlmap, nikto, masscan, nmap, zgrab, acunetix, nessus, openvas, wpscan, dirbuster,
  gobuster, havij, netsparker) va bot SEO/cao du lieu ngon nhieu bang thong (AhrefsBot, SemrushBot, MJ12bot, DotBot, PetalBot, BLEXBot, DataForSeoBot, Bytespider).
  <b>Khong</b> chan Googlebot/Bingbot. <span class="small">Gioi han that: chi loc duoc bot tu nhan dung ten; ke tan cong gia User-Agent van qua
  duoc - day la lop giam tai, khong phai tuong lua.</span></p>
  <form method="post"><?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="<?= $botsOn ? 'bots_off' : 'bots_on' ?>">
    <button type="submit" class="<?= $botsOn ? 'off' : '' ?>"<?= $liteMode ? ' disabled' : '' ?>><?= $botsOn ? 'Tat chan bot' : 'Bat chan bot' ?></button>
  </form>
</div>

<div class="card">
  <h2>Luat IP cho trang quan tri <span class="state <?= $rules['mode'] === 'off' ? 'off' : 'on' ?>"><?= $rules['mode'] === 'allow' ? 'CHI CHO PHEP' : ($rules['mode'] === 'deny' ? 'CHAN DANH SACH' : 'TAT') ?></span></h2>
  <p>Them 1 lop tren &quot;chi vao duoc qua LAN&quot; + mat khau + 2FA: chi cho phep (hoac chan) mot so thiet bi trong mang noi bo.
  Moi dong 1 muc: <code>192.168.1.20</code>, <code>192.168.1.0/24</code> (CIDR IPv4) hoac 1 dia chi IPv6; <code>#</code> bat dau ghi chu.
  IP hien tai cua ban: <b><?= esc($me) ?></b>.</p>
  <div class="note"><b>Canh bao tu khoa:</b> may chu thuong cap IP dong (DHCP) cho dien thoai/laptop - doi mang hoac khoi dong lai router co the doi IP cua ban va
  khoa ban khoi trang nay. Cach go: mo app WP Pocket Server tren dien thoai chu &rarr; nut <b>&quot;Xoa luat IP _admin&quot;</b> (hien khi dang co luat).
  Nen gan IP tinh (DHCP reservation) cho thiet bi quan tri truoc khi dung che do &quot;chi cho phep&quot;.</div>
  <form method="post"><?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="ip_save">
    <label><input type="radio" name="mode" value="off"<?= $rules['mode'] === 'off' ? ' checked' : '' ?>> Tat (mac dinh)</label>
    <label><input type="radio" name="mode" value="allow"<?= $rules['mode'] === 'allow' ? ' checked' : '' ?>> CHI cho phep cac IP trong danh sach</label>
    <label><input type="radio" name="mode" value="deny"<?= $rules['mode'] === 'deny' ? ' checked' : '' ?>> CHAN cac IP trong danh sach</label>
    <textarea name="entries" placeholder="192.168.1.20&#10;192.168.1.0/24 # ca mang nha"><?= esc(implode("\n", $rules['entries'])) ?></textarea>
    <p class="small">Trang tu choi luu neu luat se khoa chinh IP ban dang dung. Luat ap dung cho ca Adminer va File Manager (cung qua cong dang nhap).</p>
    <button type="submit">Luu luat IP</button>
  </form>
</div>
</body>
</html>
