<?php
/**
 * Router cho `php -S` (Dual-Mode PHP-Lite, xem HANDOFF.md muc 1e).
 *
 * `php -S` (PHP built-in server) KHONG doc .htaccess/mod_rewrite nhu
 * Apache, cung khong co try_files nhu nginx - neu khong co router nay,
 * "pretty permalinks" cua WordPress (vd /2026/09/ten-bai-viet/) se tra ve
 * 404 vi built-in server chi tim file vat ly dung ten, khong tim thay.
 *
 * Ky thuat nay la CHUAN, duoc chinh PHP.net khuyen dung cho `php -S`
 * (https://www.php.net/manual/en/features.commandline.webserver.php) -
 * KHONG phai tu nghi ra.
 *
 * QUAN TRONG: file nay nam trong _supervisor/ (KHONG phai docroot goc), nen
 * KHONG duoc dung __DIR__ de tinh duong dan (se ra _supervisor/, sai hoan
 * toan) - phai dung $_SERVER['DOCUMENT_ROOT'] (php -S tu dat dung bang
 * tham so -t truyen vao, xem start-lamp.sh). Loi nay TUNG co that va da
 * duoc phat hien + sua qua test thuc te bang php -S that (xem HANDOFF.md
 * muc 1e) - neu sua lai file nay, GIU NGUYEN cach dung DOCUMENT_ROOT.
 */

$docroot = $_SERVER['DOCUMENT_ROOT'] ?? __DIR__;
// === Chuan hoa duong dan TRUOC KHI kiem tra bat ky luat chan nao ===
// (xem HANDOFF.md muc 1av). Truoc day cac luat chan so sanh tren duong dan CHUA
// chuan hoa, trong khi `php -S` tu gap ".." / "." / "%2e" / "//" khi phuc vu
// file -> "/sub/../_supervisor/x" khong bat dau bang "/_supervisor/" nen LOT
// QUA luat chan roi bi phuc vu. Nay: cat query, rawurldecode (KHONG phai
// urldecode: dau "+" khong phai khoang trang, khop cach php -S giai ma), gap
// dau cham, roi moi so khop.
$requestUri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
$qpos = strpos($requestUri, '?');
if ($qpos !== false) {
    $requestUri = substr($requestUri, 0, $qpos);
}
$path = wp_pocket_lite_normalize_path(rawurldecode($requestUri));

function wp_pocket_lite_normalize_path(string $p): string
{
    $out = [];
    foreach (explode('/', $p) as $seg) {
        if ($seg === '' || $seg === '.') {
            continue;
        }
        if ($seg === '..') {
            array_pop($out); // khong lui qua goc: array_pop tren mang rong la no-op
            continue;
        }
        $out[] = $seg;
    }
    $norm = '/' . implode('/', $out);
    if ($out && substr($p, -1) === '/') {
        $norm .= '/'; // giu dau "/" cuoi - dung de nhan biet thu muc o duoi
    }
    return $norm;
}

if (strpos($path, "\0") !== false) {
    http_response_code(400);
    exit('Bad Request');
}

// Chan file nhay cam - DUNG Y HET bo luat cua nginx.conf.template o che do day
// du (che do Lite KHONG co nginx, nen moi luat phai nam o day):
//   - dotfile (.env, .git/, .htaccess...) tru .well-known  <-> location ~ /\.(?!well-known)
//   - .bak/.old/.swp/.orig/.save, KHONG phan biet hoa thuong <-> location ~* \.(bak|old|swp|orig|save)$
//   - *.template (co the chua salt that, vd wp-config.php.template) <-> location ~* \.template$
//   - /_supervisor/ (config goc) <-> location ^~ /_supervisor/
// Truoc day router CHI chan 2 luat sau; 2 luat dau (them o vong R3 cho nginx) khong
// bao gio duoc dong bo sang day -> wp-config.php.bak, .env, .git/config bi tra
// NGUYEN VAN BAN THUAN qua Cloudflare Tunnel o che do Lite.
if (
    $path === '/_supervisor' || strpos($path, '/_supervisor/') === 0
    || preg_match('#/\.(?!well-known)#', $path)
    || preg_match('#\.(bak|old|swp|orig|save|template)$#i', $path)
    // Thu muc sao luu cua plugin + PHP trong uploads/ - dong bo voi nginx.conf.template
    // (xem HANDOFF.md muc 1aw). Che do Lite khong co nginx nen luat phai nam o day.
    || preg_match('#^/(?:wp-content/(?:ai1wm-backups|updraft|backups-dup-lite|backups-dup-pro|wpvividbackups|backupwordpress-[^/]+|uploads/(?:backupbuddy_backups|backwpup-[^/]+|wpvividbackups|sucuri))|wp-snapshots)(?:/|$)#i', $path)
    || preg_match('#^/wp-content/uploads/.*\.(?:php[0-9]*|phtml|phar)$#i', $path)
) {
    http_response_code(403);
    exit('Forbidden');
}

// === Che do bao tri (xem HANDOFF.md muc 10, de xuat DeepSeek muc A8) ===
// Dong bo VOI DUNG QUY UOC file cua nginx.conf.template o che do day du:
// $RUNDIR/maintenance-mode (RUNDIR = APP_HOME/lamp-run, xem cac file
// admin-*.php khac dung getenv('APP_HOME') - CHU Y: bien nay CHI dung duoc
// tu khi start-lamp.sh "export APP_HOME" o dau file, xem chu thich o do)
// - bo qua kiem tra cho /_admin/ de chu site luon vao duoc de tat.
if (strpos($path, '/_admin/') !== 0) {
    $appHomeMaint = getenv('APP_HOME');
    $maintFlag = $appHomeMaint ? rtrim($appHomeMaint, '/') . '/lamp-run/maintenance-mode' : null;
    if ($maintFlag && is_file($maintFlag)) {
        http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Dang bao tri</title><style>body{font-family:system-ui,sans-serif;max-width:480px;margin:80px auto;padding:0 20px;text-align:center;color:#333}h1{font-size:22px;margin-bottom:8px}p{color:#666}</style></head><body><h1>Website dang bao tri</h1><p>Chu site dang cap nhat, vui long quay lai sau it phut.</p></body></html>';
        exit;
    }
}

// === robots.txt tu dong theo loai tunnel (xem HANDOFF.md muc 10, de xuat
// DeepSeek muc G6) - dung CHINH XAC quy uoc file "$RUNDIR/tunnel-named"
// nhu nginx.conf.template o che do day du, de nhat quan giua 2 che do.
// Che do Lite KHONG co WordPress THAT chay duoc (khong co database that)
// nen khong the "uy quyen cho WordPress tu quyet dinh robots.txt" nhu che
// do day du - Named Tunnel o day CHI don gian la "khong can thiep gi", roi
// xuong logic mac dinh ben duoi giong het bat ky duong dan nao khac.
if ($path === '/robots.txt') {
    $appHomeRobots = getenv('APP_HOME');
    $namedFlag = $appHomeRobots ? rtrim($appHomeRobots, '/') . '/lamp-run/tunnel-named' : null;
    if (!($namedFlag && is_file($namedFlag))) {
        header('Content-Type: text/plain; charset=utf-8');
        echo "User-agent: *\nDisallow: /\n";
        exit;
    }
}

$fullPath = $docroot . $path;

if (is_file($fullPath)) {
    // File tinh (anh/css/js) hoac .php that (vd _admin/db.php) - tra ve
    // false de built-in server tu xu ly (no tu thuc thi neu la .php, tu
    // phuc vu neu la file tinh - hanh vi mac dinh cua chinh php -S).
    return false;
}

if (is_dir($fullPath) && is_file(rtrim($fullPath, '/') . '/index.php')) {
    // Duong dan la 1 THU MUC co san index.php rieng (vd /_admin/ ->
    // _admin/index.php) - PHAI xu ly rieng truong hop nay, neu khong se roi
    // xuong nhanh duoi va nap NHAM index.php cua DOCROOT GOC.
    require rtrim($fullPath, '/') . '/index.php';
    return true;
}

// Con lai (permalink WordPress, trang chu /...) -> nap index.php goc, dung
// y het cach Apache mod_rewrite chuyen huong de WordPress tu xu ly routing
// qua $_SERVER['REQUEST_URI'].
require $docroot . '/index.php';
