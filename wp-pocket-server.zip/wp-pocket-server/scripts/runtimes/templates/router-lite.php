<?php
/**
 * Router cho `php -S` (Dual-Mode PHP-Lite, xem HANDOFF.md muc 1e).
 *
 * `php -S` (PHP built-in server) KHONG doc .htaccess/mod_rewrite nhu
 * Apache, cung khong co try_files nhu nginx - neu khong co router nay,
 * "pretty permalinks" cua WordPress (vd /2026/09/ten-bai-viet/) se tra ve
 * 404 vi built-in server chi tim file vat ly dung ten, khong tim thay.
 *
 * Ky thuat nay la CHUAN, duoc chinh PHP.net khuyen dung cho `php -S`
 * (https://www.php.net/manual/en/features.commandline.webserver.php) -
 * KHONG phai tu nghi ra.
 *
 * QUAN TRONG: file nay nam trong _supervisor/ (KHONG phai docroot goc), nen
 * KHONG duoc dung __DIR__ de tinh duong dan (se ra _supervisor/, sai hoan
 * toan) - phai dung $_SERVER['DOCUMENT_ROOT'] (php -S tu dat dung bang
 * tham so -t truyen vao, xem start-lamp.sh). Loi nay TUNG co that va da
 * duoc phat hien + sua qua test thuc te bang php -S that (xem HANDOFF.md
 * muc 1e) - neu sua lai file nay, GIU NGUYEN cach dung DOCUMENT_ROOT.
 */

$docroot = $_SERVER['DOCUMENT_ROOT'] ?? __DIR__;
$path = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Chan _supervisor/ (config goc) + moi file *.template (co the chua salt
// bi mat that, vd wp-config.php.template neu vi ly do gi chua kip xoa) -
// dung y het 2 luat trong nginx.conf.template o che do day du, de nhat
// quan giua 2 che do (xem HANDOFF.md muc 1e).
if (strpos($path, '/_supervisor/') === 0 || substr($path, -9) === '.template') {
    http_response_code(403);
    exit('Forbidden');
}

$fullPath = $docroot . $path;

if (is_file($fullPath)) {
    // File tinh (anh/css/js) hoac .php that (vd _admin/db.php) - tra ve
    // false de built-in server tu xu ly (no tu thuc thi neu la .php, tu
    // phuc vu neu la file tinh - hanh vi mac dinh cua chinh php -S).
    return false;
}

if (is_dir($fullPath) && is_file(rtrim($fullPath, '/') . '/index.php')) {
    // Duong dan la 1 THU MUC co san index.php rieng (vd /_admin/ ->
    // _admin/index.php) - PHAI xu ly rieng truong hop nay, neu khong se roi
    // xuong nhanh duoi va nap NHAM index.php cua DOCROOT GOC.
    require rtrim($fullPath, '/') . '/index.php';
    return true;
}

// Con lai (permalink WordPress, trang chu /...) -> nap index.php goc, dung
// y het cach Apache mod_rewrite chuyen huong de WordPress tu xu ly routing
// qua $_SERVER['REQUEST_URI'].
require $docroot . '/index.php';
