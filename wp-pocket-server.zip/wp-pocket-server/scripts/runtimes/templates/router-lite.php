<?php
/**
 * Router cho `php -S` (Dual-Mode PHP-Lite, xem HANDOFF.md muc 1e).
 *
 * `php -S` (PHP built-in server) KHONG doc .htaccess/mod_rewrite nhu
 * Apache, cung khong co try_files nhu nginx - neu khong co router nay,
 * "pretty permalinks" cua WordPress (vd /2026/09/ten-bai-viet/) se tra ve
 * 404 vi built-in server chi tim file vat ly dung ten, khong tim thay.
 *
 * Ky thuat nay la CHUAN, duoc chinh PHP.net khuyen dung cho `php -S`
 * (https://www.php.net/manual/en/features.commandline.webserver.php) -
 * KHONG phai tu nghi ra.
 *
 * QUAN TRONG: file nay nam trong _supervisor/ (KHONG phai docroot goc), nen
 * KHONG duoc dung __DIR__ de tinh duong dan (se ra _supervisor/, sai hoan
 * toan) - phai dung $_SERVER['DOCUMENT_ROOT'] (php -S tu dat dung bang
 * tham so -t truyen vao, xem start-lamp.sh). Loi nay TUNG co that va da
 * duoc phat hien + sua qua test thuc te bang php -S that (xem HANDOFF.md
 * muc 1e) - neu sua lai file nay, GIU NGUYEN cach dung DOCUMENT_ROOT.
 */

$docroot = $_SERVER['DOCUMENT_ROOT'] ?? __DIR__;
$path = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Chan _supervisor/ (config goc) + moi file *.template (co the chua salt
// bi mat that, vd wp-config.php.template neu vi ly do gi chua kip xoa) -
// dung y het 2 luat trong nginx.conf.template o che do day du, de nhat
// quan giua 2 che do (xem HANDOFF.md muc 1e).
if (strpos($path, '/_supervisor/') === 0 || substr($path, -9) === '.template') {
    http_response_code(403);
    exit('Forbidden');
}

// === Che do bao tri (xem HANDOFF.md muc 10, de xuat DeepSeek muc A8) ===
// Dong bo VOI DUNG QUY UOC file cua nginx.conf.template o che do day du:
// $RUNDIR/maintenance-mode (RUNDIR = APP_HOME/lamp-run, xem cac file
// admin-*.php khac dung getenv('APP_HOME') - CHU Y: bien nay CHI dung duoc
// tu khi start-lamp.sh "export APP_HOME" o dau file, xem chu thich o do)
// - bo qua kiem tra cho /_admin/ de chu site luon vao duoc de tat.
if (strpos($path, '/_admin/') !== 0) {
    $appHomeMaint = getenv('APP_HOME');
    $maintFlag = $appHomeMaint ? rtrim($appHomeMaint, '/') . '/lamp-run/maintenance-mode' : null;
    if ($maintFlag && is_file($maintFlag)) {
        http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Dang bao tri</title><style>body{font-family:system-ui,sans-serif;max-width:480px;margin:80px auto;padding:0 20px;text-align:center;color:#333}h1{font-size:22px;margin-bottom:8px}p{color:#666}</style></head><body><h1>Website dang bao tri</h1><p>Chu site dang cap nhat, vui long quay lai sau it phut.</p></body></html>';
        exit;
    }
}

$fullPath = $docroot . $path;

if (is_file($fullPath)) {
    // File tinh (anh/css/js) hoac .php that (vd _admin/db.php) - tra ve
    // false de built-in server tu xu ly (no tu thuc thi neu la .php, tu
    // phuc vu neu la file tinh - hanh vi mac dinh cua chinh php -S).
    return false;
}

if (is_dir($fullPath) && is_file(rtrim($fullPath, '/') . '/index.php')) {
    // Duong dan la 1 THU MUC co san index.php rieng (vd /_admin/ ->
    // _admin/index.php) - PHAI xu ly rieng truong hop nay, neu khong se roi
    // xuong nhanh duoi va nap NHAM index.php cua DOCROOT GOC.
    require rtrim($fullPath, '/') . '/index.php';
    return true;
}

// Con lai (permalink WordPress, trang chu /...) -> nap index.php goc, dung
// y het cach Apache mod_rewrite chuyen huong de WordPress tu xu ly routing
// qua $_SERVER['REQUEST_URI'].
require $docroot . '/index.php';
