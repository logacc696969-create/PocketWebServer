<?php
// Staging/clone site - de xuat DeepSeek muc A10 (xem HANDOFF.md muc 10 +
// muc 1ar): "Nut 'Tao ban sao de test' -> copy www/ + dump DB vao staging/,
// chay tren port khac. User test plugin/theme moi, ung thi 'promote' nguoc
// lai."
//
// THIET KE (xem chu thich day du trong nginx.conf.template va muc 1ar cua
// HANDOFF.md): KHONG chay 2 bo LAMP song song (2 mariadbd, 2 php-fpm) -
// dung CHUNG 1 tien trinh MariaDB dang chay (them 1 schema
// "wordpress_staging") va CHUNG 1 pool php-fpm dang chay (them 1 server
// block nginx tro toi thu muc "www-staging/" tren cong rieng) - chi phi
// tai nguyen THEM chu yeu la dung luong dia (1 ban sao file + 1 schema DB),
// KHONG phai them tien trinh nao. Da tu kiem chung THAT (khong doan) toan
// bo co che nay bang MariaDB that: user 'wordpress' (khong can quyen root)
// tu tao/dump/import/xoa duoc DB "wordpress_staging" nho GRANT wildcard
// rieng (xem start-lamp.sh), nhung VAN bi chan hoan toan khoi DB he thong
// "mysql" hay bat ky ten DB nao khac khong khop pattern "wordpress_*".
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$extDir = rtrim((string) getenv('EXT_DIR'), '/');
$stagingPort = getenv('STAGING_PORT');
$docroot = $appHome . '/www';
$stagingRoot = $appHome . '/www-staging';
$mysqlSock = $appHome . '/lamp-run/mysql.sock';
$mysqlCli = $extDir . '/libmysqlcli.so';
$mysqldumpBin = $extDir . '/libmysqldump.so';
// Thu muc RIENG cho ban dump "an toan" truoc khi promote - KHAC thu muc
// "backups/" ma app Android dung cho nut "Backup ngay"/"Khoi phuc" (thu muc
// do nam tren External Storage qua getExternalFilesDir(), PHP KHONG co
// duong dan de biet truoc - xem HANDOFF.md muc 1ar) - ban dump o day
// KHONG hien trong man hinh "Khoi phuc" cua app, nhung van nam tren may,
// mo duoc qua File Manager/WP-CLI console neu can khoi phuc tay.
$safetyDir = $appHome . '/staging-safety-backups';

function esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function run($cmd)
{
    return @shell_exec($cmd . ' 2>&1');
}

/**
 * Chay lenh va LAY MA THOAT (shell_exec() khong tra ma thoat nen khong the biet buoc
 * nao that bai - xem HANDOFF.md muc 1ax). $merge=true: gop stderr vao ket qua.
 */
function run_rc($cmd, &$rc, $merge = true)
{
    $lines = [];
    $rc = 1;
    @exec($cmd . ($merge ? ' 2>&1' : ''), $lines, $rc);
    return implode("\n", $lines) . "\n";
}

/** File dump mysqldump co day du khong: mysqldump luon ghi "-- Dump completed" o CUOI khi xong. */
function dump_is_complete($file)
{
    if (!is_file($file) || filesize($file) < 20) {
        return false;
    }
    $fh = @fopen($file, 'rb');
    if (!$fh) {
        return false;
    }
    fseek($fh, max(0, filesize($file) - 400));
    $tail = (string) fread($fh, 400);
    fclose($fh);
    return strpos($tail, '-- Dump completed') !== false;
}

$missing = [];
if ($appHome === '') $missing[] = 'APP_HOME';
if ($extDir === '') $missing[] = 'EXT_DIR';
if ($stagingPort === false || $stagingPort === '') $missing[] = 'STAGING_PORT';
if (!is_file($mysqlCli)) $missing[] = "mysql CLI ($mysqlCli)";
if (!is_file($mysqldumpBin)) $missing[] = "mysqldump ($mysqldumpBin)";
if (!file_exists($mysqlSock)) $missing[] = 'MariaDB socket (che do Lite/SQLite khong co staging - staging can MariaDB that)';

$stagingExists = is_dir($stagingRoot) && is_file($stagingRoot . '/wp-config.php');
$message = '';
$messageIsError = false;
$lastOutput = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($missing)) {
    if (!wp_pocket_csrf_verify()) {
        $message = 'Token bao mat (CSRF) khong hop le - tai lai trang va thu lai.';
        $messageIsError = true;
    } else {
        $action = (string) ($_POST['action'] ?? '');
        // 1bd: du lieu/tep WordPress co the vua doi tu ngoai pool php-fpm -> bao object-cache.php (APCu) xoa cache (xem HANDOFF.md muc 1bd).
        register_shutdown_function('wp_pocket_bump_object_cache_epoch');

        // Cac thao tac DB/file dung chung (moi cai TRA MA THOAT qua &$rc).
        $dbArgs = ' --socket=' . escapeshellarg($mysqlSock) . ' -uwordpress -pwordpress';
        $mysqlE = function ($statement, &$rc) use ($mysqlCli, $dbArgs) {
            return run_rc(escapeshellarg($mysqlCli) . $dbArgs . ' -e ' . escapeshellarg($statement), $rc);
        };
        // Dump RA FILE (stderr tach rieng de khong lan vao dump), roi doc lai stderr.
        $dumpTo = function ($db, $file, &$rc) use ($mysqldumpBin, $dbArgs) {
            $errFile = $file . '.err';
            run_rc(escapeshellarg($mysqldumpBin) . $dbArgs . ' --single-transaction --quick --lock-tables=false '
                . escapeshellarg($db) . ' > ' . escapeshellarg($file) . ' 2> ' . escapeshellarg($errFile), $rc, false);
            $err = is_file($errFile) ? (string) file_get_contents($errFile) : '';
            @unlink($errFile);
            return $err;
        };
        $importFrom = function ($db, $file, &$rc) use ($mysqlCli, $dbArgs) {
            return run_rc(escapeshellarg($mysqlCli) . $dbArgs . ' ' . escapeshellarg($db) . ' < ' . escapeshellarg($file), $rc);
        };
        // Moi buoc phai OK; neu khong -> ghi ly do, DUNG, dung tiep tuc (xem HANDOFF.md muc 1ax).
        $fail = function ($why, $out) use (&$message, &$messageIsError, &$lastOutput) {
            $message = $why;
            $messageIsError = true;
            $lastOutput = $out;
        };

        if ($action === 'clone') {
            if ($stagingExists) {
                $message = 'Da co ban staging roi - xoa ban cu truoc (nut "Xoa staging") neu muon tao lai tu dau.';
                $messageIsError = true;
            } else {
                // Kiem tra dung luong truoc (de xuat DeepSeek muc F7): can it nhat 2.2 lan dung luong www/.
                $wwwSizeOut = trim((string) run('du -sb ' . escapeshellarg($docroot) . ' | cut -f1'));
                $wwwSize = ctype_digit($wwwSizeOut) ? (int) $wwwSizeOut : 0;
                $freeSpace = @disk_free_space($appHome);
                if ($wwwSize > 0 && $freeSpace !== false && $freeSpace < $wwwSize * 2.2) {
                    $message = 'Khong du dung luong trong may (can khoang '
                        . round($wwwSize * 2.2 / 1024 / 1024) . ' MB, con trong '
                        . round($freeSpace / 1024 / 1024) . ' MB).';
                    $messageIsError = true;
                } else {
                    @mkdir($safetyDir, 0700, true);
                    $tmpDump = $safetyDir . '/clone-tmp-' . date('His') . '.sql';
                    // Don sach ban staging DO DANG LAN NAY neu co loi o bat ky buoc nao: truoc day buoc loi
                    // van di tiep roi bao "Da tao xong" - ban staging dang do (DB thieu du lieu) ma sau do
                    // "promote" se GHI DE DB THAT bang du lieu khong day du.
                    $cleanup = function () use ($mysqlE, $stagingRoot, $tmpDump) {
                        $mysqlE('DROP DATABASE IF EXISTS wordpress_staging;', $r);
                        run('rm -rf ' . escapeshellarg($stagingRoot));
                        @unlink($tmpDump);
                    };
                    do {
                        $out = "=== 1. Sao chep file www/ -> www-staging/ ===\n";
                        $out .= run_rc('cp -a ' . escapeshellarg($docroot) . ' ' . escapeshellarg($stagingRoot), $rc);
                        if ($rc !== 0) { $cleanup(); $fail('Khong sao chep duoc file website (xem chi tiet ben duoi) - da don dep, site LIVE khong bi anh huong.', $out); break; }

                        $out .= "\n=== 2. Tao database wordpress_staging (tu xoa neu da co tu lan loi truoc) ===\n";
                        $out .= $mysqlE('DROP DATABASE IF EXISTS wordpress_staging; CREATE DATABASE wordpress_staging CHARACTER SET utf8mb4;', $rc);
                        if ($rc !== 0) { $cleanup(); $fail('Khong tao duoc database staging - da don dep, site LIVE khong bi anh huong.', $out); break; }

                        // --single-transaction --quick --lock-tables=false (de xuat DeepSeek muc O4): khong khoa bang,
                        // khong lam gian doan site LIVE dang chay.
                        $out .= "\n=== 3. Dump database live -> file tam, kiem tra day du, roi nap vao wordpress_staging ===\n";
                        $out .= $dumpTo('wordpress', $tmpDump, $rc);
                        if ($rc !== 0 || !dump_is_complete($tmpDump)) { $cleanup(); $fail('Dump database LIVE khong hoan chinh - da don dep, site LIVE khong bi anh huong.', $out); break; }
                        $out .= $importFrom('wordpress_staging', $tmpDump, $rc);
                        if ($rc !== 0) { $cleanup(); $fail('Khong nap duoc du lieu vao database staging - da don dep, site LIVE khong bi anh huong.', $out); break; }
                        @unlink($tmpDump);

                        $out .= "\n=== 4. Sua wp-config.php cua ban staging (doi ten DB + URL dong theo host that) ===\n";
                        $cfgPath = $stagingRoot . '/wp-config.php';
                        if (is_file($cfgPath)) {
                            $cfg = file_get_contents($cfgPath);
                            $cfg = str_replace("define('DB_NAME', 'wordpress');", "define('DB_NAME', 'wordpress_staging');", $cfg);
                            // AN TOAN (vong 21, HANDOFF.md muc 1az): str_replace KHONG bao loi khi khong khop. Neu wp-config
                            // LIVE bi sua tay thanh dinh dang khac (vd "define( 'DB_NAME', 'wordpress' );" co khoang trang,
                            // giong wp-config-sample.php cua WordPress hoac plugin ghi lai file), ban staging se am tham van
                            // tro vao DB LIVE va moi thao tac tren staging ghi THANG vao du lieu that. Test WordPress that:
                            // scripts/tests/staging-realwp-test.py muc 7.
                            if (strpos($cfg, "define('DB_NAME', 'wordpress_staging');") === false) {
                                $cleanup();
                                $fail("wp-config.php cua site LIVE khong co dong DB_NAME dung dinh dang chuan (define('DB_NAME', 'wordpress');) nen KHONG the tao staging an toan - neu tiep tuc, ban staging se tro nham vao database LIVE va ghi de du lieu that. Hay sua dong do ve dung dinh dang roi thu lai. Da don dep, site LIVE khong bi anh huong.", $out);
                                break;
                            }
                            // WP_HOME/WP_SITEURL doc THEO HOST THAT nguoi dung dang go (khong hardcode IP/port) - ban staging
                            // KHONG di qua Cloudflare Tunnel, nguoi dung luon vao qua IP LAN that cua may.
                            $marker = "// __WP_POCKET_STAGING_DYNAMIC_URL__";
                            if (strpos($cfg, $marker) === false) {
                                $inject = $marker . "\n"
                                    . "\$__wp_pocket_host = isset(\$_SERVER['HTTP_HOST']) ? \$_SERVER['HTTP_HOST'] : 'localhost';\n"
                                    . "define('WP_HOME', 'http://' . \$__wp_pocket_host);\n"
                                    . "define('WP_SITEURL', 'http://' . \$__wp_pocket_host);\n";
                                $cfg = str_replace("require_once ABSPATH . 'wp-settings.php';", $inject . "require_once ABSPATH . 'wp-settings.php';", $cfg);
                            }
                            if (@file_put_contents($cfgPath, $cfg) === false) { $cleanup(); $fail('Khong ghi duoc wp-config.php cua staging - da don dep.', $out); break; }
                            @chmod($cfgPath, 0600);
                            $out .= "Da sua xong.\n";
                        } else {
                            $out .= "CANH BAO: khong thay wp-config.php trong ban sao - staging co the khong hoat dong dung.\n";
                        }

                        $lastOutput = $out;
                        $message = 'Da tao xong ban staging.';
                        $stagingExists = true;
                    } while (false);
                }
            }
        } elseif ($action === 'discard') {
            $out = "=== Xoa database wordpress_staging ===\n";
            $out .= $mysqlE('DROP DATABASE IF EXISTS wordpress_staging;', $rc);
            $out .= "\n=== Xoa file www-staging/ ===\n";
            $out .= run('rm -rf ' . escapeshellarg($stagingRoot));
            $lastOutput = $out;
            $message = 'Da xoa ban staging.';
            $stagingExists = false;
        } elseif ($action === 'promote') {
            if (!$stagingExists) {
                $message = 'Chua co ban staging nao de promote.';
                $messageIsError = true;
            } else {
                // THIET KE (xem HANDOFF.md muc 1ax). Ban cu chay tuan tu qua shell_exec() KHONG kiem tra ma thoat, roi
                // "mv www www.old; cp staging www; rm -rf www.old" VO DIEU KIEN: neu cp loi (het bo nho tren dien thoai)
                // thi www BIEN MAT va ban cu bi xoa nhung van bao "Da promote xong"; dump staging loi giua chung van di
                // tiep ghi de file + xoa DB staging. Nay: kiem tra tung buoc; DUNG ngay khi loi khi chua dong den site
                // LIVE; dung ban moi BEN CANH roi moi hoan doi bang mv (cung filesystem); khoi phuc khi loi.
                @mkdir($safetyDir, 0700, true);
                $ts = date('Y-m-d_His');
                $safetyDump = $safetyDir . "/pre-promote-db-$ts.sql";
                $safetyWww = $safetyDir . "/pre-promote-www-$ts";
                $stagingDump = $safetyDir . "/staging-to-promote-$ts.sql";
                $newWww = $docroot . '.promote-new';
                $oldWww = $docroot . '.old-before-promote';
                $out = '';
                do {
                    $wwwSizeOut = trim((string) run('du -sb ' . escapeshellarg($docroot) . ' | cut -f1'));
                    $wwwSize = ctype_digit($wwwSizeOut) ? (int) $wwwSizeOut : 0;
                    $freeSpace = @disk_free_space($appHome);
                    if ($wwwSize > 0 && $freeSpace !== false && $freeSpace < $wwwSize * 2.4) {
                        $fail('Khong du dung luong de promote an toan (can khoang ' . round($wwwSize * 2.4 / 1024 / 1024)
                            . ' MB cho ban an toan + ban moi, con trong ' . round($freeSpace / 1024 / 1024) . ' MB). Chua thay doi gi.', $out);
                        break;
                    }

                    $out .= "=== 1. Luu ban AN TOAN cua site LIVE (DB + file) - kiem tra day du ===\n";
                    $out .= $dumpTo('wordpress', $safetyDump, $rc);
                    if ($rc !== 0 || !dump_is_complete($safetyDump)) { @unlink($safetyDump); $fail('Khong luu duoc ban an toan cua database LIVE - DUNG, chua thay doi gi.', $out); break; }
                    $out .= run_rc('cp -a ' . escapeshellarg($docroot) . ' ' . escapeshellarg($safetyWww), $rc);
                    if ($rc !== 0) { run('rm -rf ' . escapeshellarg($safetyWww)); $fail('Khong luu duoc ban an toan cua file LIVE - DUNG, chua thay doi gi.', $out); break; }
                    $out .= "Da luu: $safetyDump\n";

                    $out .= "\n=== 2. Dump database STAGING -> file tam, kiem tra day du (CHUA dong den DB LIVE) ===\n";
                    $out .= $dumpTo('wordpress_staging', $stagingDump, $rc);
                    if ($rc !== 0 || !dump_is_complete($stagingDump)) { @unlink($stagingDump); $fail('Dump database staging khong hoan chinh - DUNG, site LIVE va staging van nguyen ven.', $out); break; }

                    $out .= "\n=== 3. Dung ban file moi BEN CANH (www.promote-new/) - chua dong den www/ ===\n";
                    run('rm -rf ' . escapeshellarg($newWww));
                    $out .= run_rc('cp -a ' . escapeshellarg($stagingRoot) . ' ' . escapeshellarg($newWww), $rc);
                    $newCfg = $newWww . '/wp-config.php';
                    if ($rc === 0 && is_file($newCfg)) {
                        $cfg = (string) file_get_contents($newCfg);
                        $cfg = str_replace("define('DB_NAME', 'wordpress_staging');", "define('DB_NAME', 'wordpress');", $cfg);
                        if (strpos($cfg, "define('DB_NAME', 'wordpress');") === false) {
                            // AN TOAN (vong 21): wp-config staging bi sua tay -> khong doi duoc ve DB LIVE. Neu cu promote, site LIVE se
                            // tro vao DB staging (ngay sau do bi xoa) va ngung hoat dong. DUNG o day, truoc khi dong den DB/file LIVE.
                            $out .= "\n!!! wp-config.php cua ban staging khong co dong DB_NAME dung dinh dang chuan (define('DB_NAME', 'wordpress_staging');) - khong the doi ve DB LIVE an toan; promote se lam site LIVE tro vao DB staging va ngung hoat dong. Hay sua dong do ve dung dinh dang roi thu lai.\n";
                            $rc = 1;
                        } else {
                            // Bo dong WP_HOME/WP_SITEURL "dong theo host" da chen luc clone - site LIVE dung co che siteurl
                            // GOC cua WordPress (bang wp_options, duoc F5 tu dong search-replace khi tunnel URL doi).
                            $cfg = preg_replace('/\/\/ __WP_POCKET_STAGING_DYNAMIC_URL__\n.*?define\(\'WP_SITEURL\'.*?\);\n/s', '', $cfg);
                            if (@file_put_contents($newCfg, $cfg) === false) { $rc = 1; }
                            @chmod($newCfg, 0600);
                        }
                    }
                    if ($rc !== 0) { run('rm -rf ' . escapeshellarg($newWww)); $fail('Khong dung duoc ban file moi (co the het bo nho, hoac wp-config.php cua staging sai dinh dang - xem chi tiet o tren) - DUNG, site LIVE va staging van nguyen ven.', $out); break; }

                    $out .= "\n=== 4. Nap du lieu staging vao database LIVE (GHI DE) ===\n";
                    // mysqldump mac dinh tu them "DROP TABLE IF EXISTS" truoc moi "CREATE TABLE" (da kiem chung that o
                    // muc 1ar) nen nap thang se THAY THE noi dung cac bang, khong can DROP DATABASE.
                    $out .= $importFrom('wordpress', $stagingDump, $rc);
                    if ($rc !== 0) {
                        $out .= "\n!!! Nap vao DB LIVE loi - dang KHOI PHUC DB LIVE tu ban an toan...\n";
                        $out .= $importFrom('wordpress', $safetyDump, $rc2);
                        run('rm -rf ' . escapeshellarg($newWww));
                        $fail('Nap staging vao database LIVE that bai. ' . ($rc2 === 0 ? 'Da KHOI PHUC database LIVE tu ban an toan.' : 'KHOI PHUC TU DONG CUNG LOI - hay khoi phuc thu cong tu ban an toan.')
                            . " Ban an toan: $safetyDump. File LIVE chua bi thay.", $out);
                        break;
                    }

                    $out .= "\n=== 5. Hoan doi file bang mv (www -> www.old, www.promote-new -> www) ===\n";
                    run('rm -rf ' . escapeshellarg($oldWww));
                    $out .= run_rc('mv ' . escapeshellarg($docroot) . ' ' . escapeshellarg($oldWww), $rc);
                    if ($rc === 0) {
                        $out .= run_rc('mv ' . escapeshellarg($newWww) . ' ' . escapeshellarg($docroot), $rc);
                        if ($rc !== 0) { // dua ban cu ve cho cu
                            run('mv ' . escapeshellarg($oldWww) . ' ' . escapeshellarg($docroot));
                        }
                    }
                    if ($rc !== 0) {
                        $out .= "\n!!! Hoan doi file loi - KHOI PHUC DB LIVE tu ban an toan...\n";
                        $out .= $importFrom('wordpress', $safetyDump, $rc2);
                        $fail('Hoan doi file that bai - da khoi phuc ' . ($rc2 === 0 ? 'database va giu nguyen file' : 'file (database can khoi phuc thu cong)')
                            . " LIVE. Ban an toan: $safetyDump.", $out);
                        break;
                    }

                    // CHI SAU KHI MOI THU THANH CONG moi don dep (truoc day rm -rf chay VO DIEU KIEN).
                    $out .= "\n=== 6. Don dep (chi sau khi da thanh cong) ===\n";
                    run('rm -rf ' . escapeshellarg($oldWww));
                    $mysqlE('DROP DATABASE IF EXISTS wordpress_staging;', $r);
                    run('rm -rf ' . escapeshellarg($stagingRoot));
                    $lastOutput = $out;
                    $message = 'Da promote xong - staging gio la site LIVE. Ban an toan truoc do luu tai: staging-safety-backups/';
                    $stagingExists = false;
                } while (false);
            }
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Staging / Clone site</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:680px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.note{background:#fff8e1;color:#7a5b00;padding:12px 14px;border-radius:8px;font-size:13px;margin:16px 0;line-height:1.5}
.ok{background:#e8f5e9;color:#1b5e20;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0}
.err{background:#fdecea;color:#8a1c1c;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0}
.card{border:1px solid #ddd;border-radius:10px;padding:16px;margin:12px 0}
.card h2{font-size:15px;margin:0 0 6px}
.card p{font-size:13px;color:#666;margin:0 0 12px}
button{padding:9px 16px;border:0;border-radius:8px;color:#fff;font-size:14px;cursor:pointer}
.btn-primary{background:#2271b1}
.btn-danger{background:#b32d2e}
.btn-promote{background:#1b5e20}
pre{background:#1e1e1e;color:#d4d4d4;padding:14px;border-radius:8px;overflow-x:auto;font-size:12px;white-space:pre-wrap;word-break:break-all;max-height:300px}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Staging / Clone site</h1>

<?php if (!empty($missing)): ?>
<div class="note">Chua dung duoc: thieu <?= esc(implode(', ', $missing)) ?>.</div>
<?php else: ?>

<div class="note">
  Tao 1 ban sao WordPress THAT de thu plugin/theme moi ma khong anh huong
  site dang chay. Ban sao dung CHUNG MariaDB/PHP-FPM dang chay (khong ton
  them RAM dang ke) - chi ton them dung luong o (kiem tra truoc luc tao).
  "Promote" se GHI DE site live bang noi dung staging (co luu ban an toan
  truoc trong <code>staging-safety-backups/</code>).
</div>

<?php if ($message !== ''): ?>
<div class="<?= $messageIsError ? 'err' : 'ok' ?>"><?= esc($message) ?></div>
<?php endif; ?>

<?php if (!$stagingExists): ?>
<div class="card">
  <h2>Chua co ban staging</h2>
  <p>Bam de tao ban sao moi tu site dang chay.</p>
  <form method="post">
    <?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="clone">
    <button type="submit" class="btn-primary">Tao ban sao de test</button>
  </form>
</div>
<?php else: ?>
<div class="card">
  <h2>Da co ban staging</h2>
  <p>Xem tai: <code>http://&lt;IP LAN cua may&gt;:<?= esc($stagingPort) ?>/</code>
     (chi vao duoc tu cung mang LAN, KHONG qua duong link cong khai Internet).</p>
  <form method="post" style="display:inline-block;margin-right:8px">
    <?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="discard">
    <button type="submit" class="btn-danger" onclick="return confirm('Xoa han ban staging nay?')">Xoa staging</button>
  </form>
  <form method="post" style="display:inline-block">
    <?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="promote">
    <button type="submit" class="btn-promote" onclick="return confirm('GHI DE site live bang noi dung staging? (co luu ban an toan truoc)')">Promote len Live</button>
  </form>
</div>
<?php endif; ?>

<?php if ($lastOutput !== ''): ?>
<h2 style="font-size:15px">Chi tiet lan chay gan nhat</h2>
<pre><?= esc($lastOutput) ?></pre>
<?php endif; ?>

<?php endif; ?>
</body>
</html>
