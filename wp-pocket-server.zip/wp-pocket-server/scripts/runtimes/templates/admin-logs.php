<?php
require __DIR__ . '/auth.php';

$appHome = rtrim(getenv('APP_HOME') ?: '', '/');
$rundir = $appHome . '/lamp-run';

$logs = [
    'nginx-loi'      => $rundir . '/nginx-error.log',
    'nginx-truycap'  => $rundir . '/nginx-access.log',
    'php-fpm'        => $rundir . '/php-fpm.log',
    'php-loi'        => $rundir . '/php-error.log',
    'mariadb'        => $rundir . '/mysqld.log',
    'mariadb-caidat' => $rundir . '/mysql-install.log',
    'start-lamp'     => $rundir . '/../start-lamp-stdout.log',
];

$keys = array_keys($logs);
$selected = (isset($_GET['log']) && in_array($_GET['log'], $keys, true)) ? $_GET['log'] : $keys[0];
$lines = isset($_GET['lines']) ? max(10, min(2000, (int) $_GET['lines'])) : 200;

function tail_file(string $path, int $lines): string
{
    if (!is_readable($path)) {
        return "(khong doc duoc hoac chua co: $path)";
    }
    $out = @shell_exec('tail -n ' . (int) $lines . ' ' . escapeshellarg($path));
    if ($out !== null) {
        return $out;
    }
    // Du phong thuan PHP neu shell_exec bi vo hieu hoa
    $content = @file_get_contents($path);
    if ($content === false) {
        return "(khong doc duoc)";
    }
    $arr = explode("\n", $content);
    return implode("\n", array_slice($arr, -$lines));
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Xem log</title>
<style>
  body { font-family: system-ui, sans-serif; margin:0; padding:16px; background:#1e1e1e; color:#ddd; }
  a.back { color:#7ab; font-size:13px; text-decoration:none; }
  nav { margin: 10px 0; }
  nav a { display:inline-block; padding:6px 10px; margin:2px 4px 2px 0; border-radius:6px;
          text-decoration:none; color:#ccc; background:#333; font-size:13px; }
  nav a.active { background:#21759B; color:#fff; }
  pre { background:#111; padding:12px; border-radius:8px; overflow:auto; white-space:pre-wrap;
        word-break:break-all; font-size:12px; max-height:70vh; }
  .lines a { color:#7ab; font-size:12px; margin-right:8px; }
</style>
</head>
<body>
  <p><a class="back" href="index.php">&larr; Quan tri</a></p>
  <h3>Log: <?= htmlspecialchars($selected) ?></h3>
  <nav>
    <?php foreach ($keys as $k): ?>
      <a href="?log=<?= urlencode($k) ?>&lines=<?= $lines ?>" class="<?= $k === $selected ? 'active' : '' ?>"><?= htmlspecialchars($k) ?></a>
    <?php endforeach; ?>
  </nav>
  <div class="lines">
    Hien <?= $lines ?> dong cuoi —
    <a href="?log=<?= urlencode($selected) ?>&lines=200">200</a>
    <a href="?log=<?= urlencode($selected) ?>&lines=500">500</a>
    <a href="?log=<?= urlencode($selected) ?>&lines=2000">2000</a>
  </div>
  <pre><?= htmlspecialchars(tail_file($logs[$selected], $lines)) ?></pre>
</body>
</html>
