#!/system/bin/sh
# Giam sat cho runtime node / python / static (HANDOFF.md muc 1bi). Chay bang: /system/bin/sh <www>/_supervisor/start-generic.sh
# (runtime.json "exec"); Kotlin dat san LD_LIBRARY_PATH=nativeLibraryDir, HOME=filesDir, PORT, cwd=www - giong cac bien start-lamp.sh dung.
#
# LAM 2 VIEC:
#  1) Dung lai symlink dung ten SONAME that (libz.so.1...) trong $RUNDIR/compat-libs roi dua len truoc LD_LIBRARY_PATH - cung co che da chay
#     tren thiet bi that cua start-lamp.sh (COMPAT_DIR). TRUOC ban nay node/python/static chua co: file libz.so.1 khong khop "cp *.so" nen
#     khong vao APK, binary Termux se bao "library libz.so.1 not found" giong het loi mariadbd o vong 1u.
#  2) Che do chay (env GEN_MODE do build ghi vao runtime.json):
#       direct : exec thang app (hanh vi nhu truoc, chi them buoc 1)
#       proxy  : app Node/Python tren cong noi bo PORT+1, nginx (libnginx.so) lang nghe cong cong PORT va chuyen tiep (header bao mat, gzip, WebSocket)
#       static : nginx phuc vu thang thu muc web (khong can app)
#     Hai tien trinh (proxy) duoc theo doi: cai nao chet thi dung cai kia va THOAT khac 0 de Kotlin khoi dong lai ca bo.
set -e

BIN="$LD_LIBRARY_PATH"
DATA="$HOME"
DOCROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
SUP="$DOCROOT/_supervisor"
RUNDIR="$DATA/generic-run"
mkdir -p "$RUNDIR"
log() { echo "[start-generic] $*"; }

# --- Giao thuc DUNG SACH voi ServerForegroundService (HANDOFF.md muc 1au; giong start-lamp.sh) ---
# Tren Android Process.destroy() co the la SIGKILL nen trap TERM KHONG BAO GIO chay -> "Tat server" se de nginx + app mo coi chay tiep.
# Nen Kotlin ghi TOKEN PHIEN (WPP_SESSION) vao filesDir/lamp-run/stop-requested (duong dan CO DINH trong Kotlin) va cho toi da 40s;
# script o che do 2 tien trinh bao "toi ho tro" bang marker graceful-stop-ready (cung token), thay co khop thi tu dung sach roi thoat 0.
# Che do direct la MOT tien trinh (exec) nen destroy() la du: KHONG ghi marker -> Kotlin destroy ngay, khong cho vo ich.
PROTO_DIR="$DATA/lamp-run"
mkdir -p "$PROTO_DIR" 2>/dev/null || true
rm -f "$PROTO_DIR/graceful-stop-ready"     # marker cua phien truoc khong bao gio duoc coi la hop le
stop_requested() {
  [ -n "${WPP_SESSION:-}" ] || return 1
  [ -f "$PROTO_DIR/stop-requested" ] || return 1
  [ "$(cat "$PROTO_DIR/stop-requested" 2>/dev/null)" = "$WPP_SESSION" ]
}
# Song that su: tien trinh con da chet nhung chua duoc don (zombie) van qua "kill -0" - doc trang thai tu /proc.
is_alive() {
  [ -n "$1" ] && [ -d "/proc/$1" ] || return 1
  ! grep -q '^State:.*Z' "/proc/$1/status" 2>/dev/null
}

PORT="${PORT:-8080}"
APP_PORT=$((PORT + 1))
WEBROOT="$DOCROOT"
[ -n "$GEN_WEB_SUBDIR" ] && WEBROOT="$DOCROOT/$GEN_WEB_SUBDIR"

# --- 1) symlink SONAME that ---
COMPAT_DIR="$RUNDIR/compat-libs"
rm -rf "$COMPAT_DIR"; mkdir -p "$COMPAT_DIR"
if [ -f "$SUP/soname-map.txt" ]; then
  while IFS=' ' read -r real_name mapped_name; do
    [ -n "$real_name" ] || continue
    ln -sf "$BIN/$mapped_name" "$COMPAT_DIR/$real_name"
  done < "$SUP/soname-map.txt"
  log "da tao $(wc -l < "$SUP/soname-map.txt" | tr -d ' ') symlink SONAME trong $COMPAT_DIR"
fi
export LD_LIBRARY_PATH="$COMPAT_DIR:$BIN"

# --- Python: thu vien chuan nam trong www/_supervisor/pyhome; cac module mo rong (lib-dynload/*.so) PHAI nam o nativeLibDir (Android khong cho nap
# .so tu thu muc du lieu cua app) nen build doi ten "libpydyn_*.so" - dung lai symlink lib-dynload/<ten goc> -> nativeLibDir/<ten moi> o day.
if [ -f "$SUP/dynload-map.txt" ] && [ -d "$SUP/pyhome/lib" ]; then
  PYVER="$(ls "$SUP/pyhome/lib" | head -1)"
  DYN="$SUP/pyhome/lib/$PYVER/lib-dynload"
  mkdir -p "$DYN"
  while IFS=' ' read -r orig mapped; do
    [ -n "$orig" ] || continue
    ln -sf "$BIN/$mapped" "$DYN/$orig"
  done < "$SUP/dynload-map.txt"
  export PYTHONHOME="$SUP/pyhome"
  log "python: PYTHONHOME=$PYTHONHOME ($PYVER), $(wc -l < "$SUP/dynload-map.txt" | tr -d ' ') module mo rong"
fi

# Thay token trong GEN_APP_ARGS (build khong biet duong dan that / cong luc chay).
ARGS=$(printf '%s' "$GEN_APP_ARGS" | sed -e "s#__PORT__#$PORT#g" -e "s#__APP_PORT__#$APP_PORT#g" -e "s#__DOCROOT__#$DOCROOT#g")

# Don tien trinh mo coi tu lan chay truoc (bi giet cung, khong kip trap): CHI giet khi dung la binary cua minh (kiem /proc/PID/cmdline).
kill_stale() {  # $1=pid file  $2=chuoi phai co trong cmdline
  [ -f "$1" ] || return 0
  OLD="$(cat "$1" 2>/dev/null)"
  case "$OLD" in ''|*[!0-9]*) rm -f "$1"; return 0 ;; esac
  if [ -r "/proc/$OLD/cmdline" ] && tr '\0' ' ' < "/proc/$OLD/cmdline" 2>/dev/null | grep -q "$2"; then
    log "giet tien trinh mo coi pid=$OLD ($2)"; kill "$OLD" 2>/dev/null || true; sleep 1
    # 1bq-E: TERM roi sleep 1 ma tien trinh bo qua TERM (hoac ket) thi truoc day SONG MAI -> ep KILL.
    is_alive "$OLD" && kill -KILL "$OLD" 2>/dev/null
  fi
  rm -f "$1"
}

# 1bq-E (kiem thu hon loan): kill_stale chi dua vao TEP PID - tep hong/mat/bi ghi de (vd bi cat do day o dia) thi tien trinh mo coi SONG MAI.
# Du phong: quet /proc tim tien trinh co cmdline chua DUONG DAN DAY DU binary cua minh ($BIN/ten - duong dan nativeLibraryDir rieng cua app nen khong
# the trung tien trinh khac), bo qua chinh minh. Tien trinh khong lien quan (dung pid trung) khong bao gio khop vi cmdline khong chua duong dan nay.
kill_stale_scan() {  # $1 = duong dan day du cua binary
  [ -n "$1" ] || return 0
  FOUND=""
  for PD in /proc/[0-9]*; do
    SPID="${PD#/proc/}"
    [ "$SPID" = "$$" ] && continue
    [ -r "$PD/cmdline" ] || continue
    if tr '\0' ' ' < "$PD/cmdline" 2>/dev/null | grep -qF -- "$1"; then
      is_alive "$SPID" && FOUND="$FOUND $SPID"
    fi
  done
  [ -n "$FOUND" ] || return 0
  log "quet /proc: giet tien trinh mo coi:$FOUND ($1)"
  for SPID in $FOUND; do kill "$SPID" 2>/dev/null || true; done
  sleep 1
  for SPID in $FOUND; do is_alive "$SPID" && kill -KILL "$SPID" 2>/dev/null; done
  return 0
}

case "${GEN_MODE:-direct}" in
  direct)
    # shellcheck disable=SC2086
    exec "$BIN/$GEN_APP_BIN" $ARGS
    ;;
  proxy|static)
    # Log cua nginx phia truoc: cat khi vuot ~5MB luc khoi dong (Kotlin chi cat start-lamp-stdout.log; cac log nay do nginx ghi).
    for LF in "$RUNDIR/nginx-front-error.log" "$RUNDIR/nginx-front-stdout.log"; do
      if [ -f "$LF" ] && [ "$(wc -c < "$LF" | tr -d ' ')" -gt 5242880 ]; then : > "$LF"; log "da cat $LF (> 5MB)"; fi
    done
    kill_stale "$RUNDIR/front-app.pid" "$GEN_APP_BIN"
    kill_stale "$RUNDIR/nginx-front.pid" "libnginx.so"
    if [ "$GEN_MODE" = "proxy" ]; then kill_stale_scan "$BIN/$GEN_APP_BIN"; fi
    kill_stale_scan "$BIN/libnginx.so"
    APP_PID=""
    NGINX_PID=""
    # HANDOFF.md muc 1bq-E (kiem thu hon loan): "set -e" ma sed/echo/chuyen huong loi GIUA luc khoi dong (day o dia, thieu template...) thoat NGAY
    # trong khi app da chay nen -> app bi bo MO COI vinh vien (chua ghi duoc front-app.pid nen kill_stale cung khong tim thay). Bay gio moi lan
    # thoat truoc khi vong giam sat bat dau deu don nhung gi da khoi dong (TERM, con song sau 2s thi KILL).
    startup_abort() {
      trap - EXIT
      [ -n "$NGINX_PID" ] && kill -TERM "$NGINX_PID" 2>/dev/null
      [ -n "$APP_PID" ] && kill -TERM "$APP_PID" 2>/dev/null
      N=0
      while [ "$N" -lt 4 ]; do
        is_alive "$NGINX_PID" || is_alive "$APP_PID" || break
        sleep 0.5; N=$((N + 1))
      done
      is_alive "$NGINX_PID" && kill -KILL "$NGINX_PID" 2>/dev/null
      is_alive "$APP_PID" && kill -KILL "$APP_PID" 2>/dev/null
      return 0
    }
    trap startup_abort EXIT
    if [ "$GEN_MODE" = "proxy" ]; then
      # shellcheck disable=SC2086
      PORT="$APP_PORT" "$BIN/$GEN_APP_BIN" $ARGS &
      APP_PID=$!
      echo "$APP_PID" > "$RUNDIR/front-app.pid"
      log "app $GEN_APP_BIN pid=$APP_PID tren cong noi bo $APP_PORT"
    fi
    LOC_TPL="$SUP/front-locations-$GEN_MODE.conf.template"
    sed -e "s#__APP_PORT__#$APP_PORT#g" -e "s#__WEBROOT__#$WEBROOT#g" "$LOC_TPL" > "$RUNDIR/front-locations.conf"
    sed -e "s#__RUNDIR__#$RUNDIR#g" -e "s#__PORT__#$PORT#g" "$SUP/nginx-front.conf.template" > "$RUNDIR/nginx-front.conf"
    "$BIN/libnginx.so" -p "$RUNDIR/" -c "$RUNDIR/nginx-front.conf" -g "daemon off;" >> "$RUNDIR/nginx-front-stdout.log" 2>&1 &
    NGINX_PID=$!
    log "nginx phia truoc pid=$NGINX_PID, che do=$GEN_MODE, cong cong cong=$PORT"
    # Dung sach: ca nginx lan app nhan TERM (nginx: dung nhanh - tren dien thoai khong can cho het request); con song sau ~4s thi KILL.
    # KHONG dung QUIT/INT: shell khong tuong tac BO QUA SIGINT/SIGQUIT voi tien trinh nen (&) - POSIX - nen khong dang tin.
    graceful_stop() {
      [ -n "$NGINX_PID" ] && kill -TERM "$NGINX_PID" 2>/dev/null
      [ -n "$APP_PID" ] && kill -TERM "$APP_PID" 2>/dev/null
      N=0
      while [ "$N" -lt 4 ]; do
        is_alive "$NGINX_PID" || is_alive "$APP_PID" || break
        sleep 1; N=$((N + 1))
      done
      is_alive "$NGINX_PID" && kill -KILL "$NGINX_PID" 2>/dev/null
      is_alive "$APP_PID" && kill -KILL "$APP_PID" 2>/dev/null
      rm -f "$PROTO_DIR/graceful-stop-ready"
      exit 0
    }
    trap - EXIT   # ca hai da len: tu day vong giam sat va graceful_stop lo viec don; khong de startup_abort chay lan nua
    trap graceful_stop TERM INT
    # Bao cho Kotlin biet PHIEN NAY ho tro dung sach qua file co (chi khi ca hai da khoi dong).
    [ -n "${WPP_SESSION:-}" ] && printf '%s' "$WPP_SESSION" > "$PROTO_DIR/graceful-stop-ready" 2>/dev/null
    while is_alive "$NGINX_PID" && { [ -z "$APP_PID" ] || is_alive "$APP_PID"; }; do
      if stop_requested; then
        log "Nhan co stop-requested tu ung dung (token phien khop) - dung sach"
        graceful_stop
      fi
      sleep 1
    done
    log "mot tien trinh da chet (nginx=$NGINX_PID app=${APP_PID:-none}) - dung ca bo, Kotlin se khoi dong lai"
    rm -f "$PROTO_DIR/graceful-stop-ready"
    kill $NGINX_PID $APP_PID 2>/dev/null || true
    exit 1
    ;;
  *)
    log "GEN_MODE khong hop le: $GEN_MODE"
    exit 2
    ;;
esac
