<?php
// Rollback WordPress core - de xuat DeepSeek muc P3 (xem HANDOFF.md muc 10
// + muc 1at): "User cai plugin loi -> ... Rollback WordPress core sau
// update: WordPress tu update core. Neu ban moi conflict voi plugin -> site
// hong. Hosting that co snapshot. Can: tu backup wp-admin/ + wp-includes/
// truoc khi core update, nut 'Rollback core' trong app."
//
// Snapshot duoc TAO TU DONG boi mu-plugin wppocket-maintenance.php (hook
// "pre_auto_update", xem site_source.sh) NGAY TRUOC moi lan WordPress tu
// cap nhat core - trang nay CHI la noi XEM + KHOI PHUC snapshot do, khong
// tu tao snapshot.
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$docroot = $appHome . '/www';
$backupDir = $docroot . '/wp-content/wppocket-core-rollback';

function esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function rrmdir($dir)
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (scandir($dir) as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . '/' . $item;
        is_dir($path) ? rrmdir($path) : @unlink($path);
    }
    @rmdir($dir);
}

/**
 * Sao chep de len va TRA VE SO FILE/THU MUC LOI (0 = thanh cong hoan toan). Truoc day ham nay bo qua gia tri
 * tra ve cua copy()/mkdir() nen khi het dung luong van ghi de tung phan roi bao "Da khoi phuc xong", va buoc
 * LUU BAN AN TOAN (cung dung ham nay) loi cung khong ai biet - xem HANDOFF.md muc 1ax.
 */
function copyDirOver($src, $dst)
{
    $failures = 0;
    if (!is_dir($src)) {
        return 0;
    }
    if (!is_dir($dst) && !@mkdir($dst, 0755, true) && !is_dir($dst)) {
        return 1;
    }
    $items = @scandir($src);
    if ($items === false) {
        return 1;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $s = $src . '/' . $item;
        $d = $dst . '/' . $item;
        if (is_dir($s)) {
            $failures += copyDirOver($s, $d);
        } elseif (!@copy($s, $d)) {
            $failures++;
        }
    }
    return $failures;
}

function dirSizeBytes($dir)
{
    $total = 0;
    if (!is_dir($dir)) {
        return 0;
    }
    $items = @scandir($dir) ?: [];
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . '/' . $item;
        if (is_link($path)) {
            continue;
        }
        $total += is_dir($path) ? dirSizeBytes($path) : (int) @filesize($path);
    }
    return $total;
}

$hasSnapshot = is_dir($backupDir) && is_file($backupDir . '/version-before-update.txt');
$snapshotInfo = $hasSnapshot ? trim(file_get_contents($backupDir . '/version-before-update.txt')) : '';

$message = '';
$messageIsError = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $hasSnapshot) {
    if (!wp_pocket_csrf_verify()) {
        $message = 'Token bao mat (CSRF) khong hop le - tai lai trang va thu lai.';
        $messageIsError = true;
    } elseif (($_POST['action'] ?? '') === 'rollback') {
        // 1bd: du lieu/tep WordPress co the vua doi tu ngoai pool php-fpm -> bao object-cache.php (APCu) xoa cache (xem HANDOFF.md muc 1bd).
        register_shutdown_function('wp_pocket_bump_object_cache_epoch');
        // An toan: luu ban HIEN TAI (sau update, truoc khi ghi de lai) vao
        // 1 thu muc tam - neu rollback xong ma VAN loi, it nhat con lai
        // dau vet de so sanh/khoi phuc tay qua File Manager.
        // NGUYEN TAC (HANDOFF.md muc 1ax): KHONG ghi de khi chua co ban an toan DAY DU; KHONG bao thanh cong khi con file loi.
        $safetyDir = $appHome . '/core-rollback-safety-' . date('Y-m-d_His');
        $currentCoreSize = dirSizeBytes($docroot . '/wp-admin') + dirSizeBytes($docroot . '/wp-includes');
        $freeSpace = @disk_free_space($appHome);
        if ($freeSpace !== false && $freeSpace < $currentCoreSize * 1.3 + 5 * 1024 * 1024) {
            $message = 'Khong du dung luong de luu ban an toan truoc khi khoi phuc (can khoang '
                . round(($currentCoreSize * 1.3 + 5 * 1024 * 1024) / 1024 / 1024) . ' MB, con trong '
                . round($freeSpace / 1024 / 1024) . ' MB). DUNG - chua thay doi gi.';
            $messageIsError = true;
        } else {
            @mkdir($safetyDir, 0700, true);
            $safetyFails = copyDirOver($docroot . '/wp-admin', $safetyDir . '/wp-admin')
                + copyDirOver($docroot . '/wp-includes', $safetyDir . '/wp-includes');
            if ($safetyFails > 0) {
                rrmdir($safetyDir);
                $message = 'Khong luu duoc ban an toan cua trang thai hien tai (' . $safetyFails
                    . ' file loi) - DUNG, chua ghi de gi (core van o trang thai hien tai).';
                $messageIsError = true;
            } else {
                $fails = copyDirOver($backupDir . '/wp-admin', $docroot . '/wp-admin')
                    + copyDirOver($backupDir . '/wp-includes', $docroot . '/wp-includes');
                foreach (glob($backupDir . '/root-*.php') ?: [] as $f) {
                    $target = $docroot . '/' . substr(basename($f), strlen('root-'));
                    if (!@copy($f, $target)) {
                        $fails++;
                    }
                }
                if ($fails > 0) {
                    $message = 'Khoi phuc CHUA HOAN TAT: ' . $fails . ' file khong ghi duoc (co the het dung luong) - core dang o trang thai '
                        . 'TRON LAN giua hai phien ban. Ban hien tai truoc khi ghi de duoc luu tai: ' . esc(basename($safetyDir))
                        . '. Hay giai phong bo nho roi chay lai khoi phuc.';
                    $messageIsError = true;
                } else {
                    $message = 'Da khoi phuc xong ve ban truoc do (' . esc($snapshotInfo) . '). Ban SAU khi update (truoc khi rollback) duoc luu tai: ' . esc(basename($safetyDir));
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rollback WordPress core</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:680px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.note{background:#fff8e1;color:#7a5b00;padding:12px 14px;border-radius:8px;font-size:13px;margin:16px 0;line-height:1.5}
.ok{background:#e8f5e9;color:#1b5e20;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0}
.err{background:#fdecea;color:#8a1c1c;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0}
button{padding:9px 16px;border:0;border-radius:8px;background:#b32d2e;color:#fff;font-size:14px;cursor:pointer}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Rollback WordPress core</h1>

<div class="note">
  Snapshot duoc TU DONG tao ngay truoc moi lan WordPress tu cap nhat core
  (WP_AUTO_UPDATE_CORE='minor', ban va cham nho) - trang nay chi dung khi
  ban cap nhat gan nhat lam site loi.
</div>

<?php if ($message !== ''): ?>
<div class="<?= $messageIsError ? 'err' : 'ok' ?>"><?= $message ?></div>
<?php endif; ?>

<?php if (!$hasSnapshot): ?>
<p>Chua co snapshot nao (WordPress chua tu cap nhat core lan nao ke tu khi cai, hoac site dung Dual-Mode Lite - khong tao mu-plugin).</p>
<?php else: ?>
<p>Snapshot gan nhat (truoc khi cap nhat):<br><strong><?= esc($snapshotInfo) ?></strong></p>
<form method="post">
  <?= wp_pocket_csrf_field() ?>
  <input type="hidden" name="action" value="rollback">
  <button type="submit" onclick="return confirm('Khoi phuc wp-admin/wp-includes ve ban TRUOC lan cap nhat gan nhat? Ban hien tai se duoc luu lai truoc khi ghi de.')">Rollback ve ban nay</button>
</form>
<?php endif; ?>
</body>
</html>
