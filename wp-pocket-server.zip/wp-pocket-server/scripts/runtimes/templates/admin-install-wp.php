<?php
require __DIR__ . '/auth.php';

/**
 * "1-Click Installer" WordPress - de xuat tu PDF muc 2 "Tang su Tien loi
 * bang giao dien Web dieu khien tap trung" (xem HANDOFF.md muc 1e).
 *
 * CHI chay duoc khi docroot dang TRONG (chua co wp-config.php hay
 * wp-load.php) - tranh nguy co ghi de/mat du lieu website hien co. Neu ban
 * dat site_source.type=wordpress trong site.config.json (mac dinh cua du
 * an), WordPress da duoc tai san luc BUILD APK roi (xem site_source.sh) -
 * trang nay chi huu ich khi: (a) ban dang dung site_source khac
 * (git/local/zip) nhung muon thu nhanh 1 site WordPress test MA KHONG can
 * sua site.config.json + push GitHub + doi Actions build lai (cham hon
 * nhieu), hoac (b) muon cai lai tu dau sau khi da xoa sach thu muc www/ qua
 * File Manager.
 *
 * Dung LAI database + user 'wordpress' da duoc start-lamp.sh tao san VO
 * DIEU KIEN (khong phu thuoc site_source - xem
 * scripts/runtimes/templates/start-lamp.sh), nen khong can nguoi dung tu
 * nhap thong tin ket noi database.
 *
 * CHUA verify end-to-end tren thiet bi that (giong moi phan PHP moi khac
 * trong du an nay - xem HANDOFF.md muc 8 ve quy uoc "CHUA verify").
 */

set_time_limit(180); // tai + giai nen WordPress qua mang di dong + ghi flash
                      // cham co the qua 60s mac dinh (max_execution_time)

$docroot = dirname(__DIR__);
$appHome = rtrim(getenv('APP_HOME') ?: '', '/');
$mysqlSock = $appHome . '/lamp-run/mysql.sock';

$alreadyInstalled = file_exists($docroot . '/wp-config.php') || file_exists($docroot . '/wp-load.php');
$log = [];
$success = false;

function download_to(string $url, string $destPath, array &$log): bool
{
    if (function_exists('curl_init')) {
        $log[] = "Tai qua PHP curl extension: $url";
        $fp = fopen($destPath, 'wb');
        if (!$fp) {
            $log[] = "LOI: khong mo duoc file dich $destPath";
            return false;
        }
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);
        curl_setopt($ch, CURLOPT_USERAGENT, 'wp-pocket-server-installer');
        $ok = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        fclose($fp);
        if (!$ok) {
            $log[] = "LOI curl: $err";
            return false;
        }
        return true;
    }
    if (ini_get('allow_url_fopen')) {
        $log[] = "Tai qua allow_url_fopen (khong co curl extension): $url";
        $data = @file_get_contents($url);
        if ($data === false) {
            $log[] = 'LOI: file_get_contents that bai';
            return false;
        }
        return file_put_contents($destPath, $data) !== false;
    }
    $log[] = 'LOI: khong co curl extension lan allow_url_fopen - khong the tai file tu Internet';
    return false;
}

function copy_recursive(string $src, string $dst, array &$log): void
{
    if (!is_dir($dst)) {
        mkdir($dst, 0755, true);
    }
    $items = scandir($src);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $s = $src . '/' . $item;
        $d = $dst . '/' . $item;
        if (is_dir($s)) {
            copy_recursive($s, $d, $log);
        } elseif (!copy($s, $d)) {
            $log[] = "CANH BAO: khong chep duoc $item";
        }
    }
}

function remove_dir_recursive(string $dir): void
{
    $items = @scandir($dir);
    if (!$items) {
        return;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $p = $dir . '/' . $item;
        is_dir($p) ? remove_dir_recursive($p) : @unlink($p);
    }
    @rmdir($dir);
}

/**
 * Tai san plugin "Cloudflare" chinh thuc (slug "cloudflare" tren
 * wordpress.org) vao wp-content/plugins/ - CHI TAI FILE, KHONG tu kich hoat.
 *
 * Ly do KHONG tu kich hoat: luc script nay chay, wp-config.php co the vua
 * duoc tao NHUNG database CHUA CO BANG NAO CA (nguoi dung chua di qua man
 * hinh cai dat WordPress 5 phut o wp-admin/install.php) - goi
 * activate_plugin() luc nay se loi vi WordPress chua co "options" table de
 * ghi. Hon nua, chinh trang plugin nay (xem FAQ tren wordpress.org) BAT
 * BUOC nguoi dung tu nhap email + API Token/API Key qua giao dien lan dau
 * kich hoat - khong the tu dong hoa het duoc dau, nen chi tai san file de
 * tiet kiem 1 buoc tai + cho nguoi dung tu bam "Kich hoat" + tu nhap token
 * la xong (xem huong dan ngan o man hinh thanh cong ben duoi).
 *
 * CHUA verify end-to-end tren thiet bi that (dung quy uoc "CHUA verify" cua
 * du an - xem HANDOFF.md muc 8).
 */
function install_cloudflare_plugin(string $docroot, string $tmpBase, array &$log): bool
{
    $pluginsDir = $docroot . '/wp-content/plugins';
    if (!is_dir($pluginsDir) && !mkdir($pluginsDir, 0755, true) && !is_dir($pluginsDir)) {
        $log[] = 'LOI (Cloudflare plugin): khong tao duoc wp-content/plugins';
        return false;
    }
    if (is_dir($pluginsDir . '/cloudflare')) {
        $log[] = 'Plugin Cloudflare da co san trong wp-content/plugins/, bo qua tai lai';
        return true;
    }

    // Uu tien do phien ban moi nhat qua WordPress.org Plugin API (JSON nhe,
    // cung 1 co che ma WordPress dung that de tu kiem tra cap nhat) - neu
    // mang loi hoac API doi dinh dang, du phong bang URL phien ban 4.14.4
    // da biet chac chan ton tai (kiem tra thu cong luc viet code nay,
    // 2026-09). URL du phong co the CU DAN theo thoi gian nhung
    // downloads.wordpress.org van giu lai cac ban cu nen van tai duoc, chi
    // khong phai "moi nhat" - khong lam hong chuc nang gi neu xay ra.
    $downloadUrl = 'https://downloads.wordpress.org/plugin/cloudflare.4.14.4.zip';
    $apiTmp = $tmpBase . '/cf-plugin-api-' . uniqid() . '.json';
    if (download_to('https://api.wordpress.org/plugins/info/1.0/cloudflare.json', $apiTmp, $log)) {
        $info = json_decode((string) @file_get_contents($apiTmp), true);
        @unlink($apiTmp);
        if (!empty($info['download_link']) && is_string($info['download_link'])) {
            $downloadUrl = $info['download_link'];
            $log[] = 'Da do duoc link tai plugin Cloudflare moi nhat qua WordPress.org Plugin API';
        } else {
            $log[] = 'API tra ve nhung khong doc duoc download_link - dung URL du phong (co the khong phai ban moi nhat, van hoat dong binh thuong)';
        }
    } else {
        $log[] = 'Khong goi duoc WordPress.org Plugin API - dung URL du phong (co the khong phai ban moi nhat, van hoat dong binh thuong)';
    }

    $tmpZip = $tmpBase . '/cf-plugin-' . uniqid() . '.zip';
    $tmpExtract = $tmpBase . '/cf-plugin-' . uniqid();
    if (!download_to($downloadUrl, $tmpZip, $log)) {
        $log[] = 'LOI (Cloudflare plugin): tai zip that bai - bo qua, khong anh huong den viec cai WordPress chinh';
        return false;
    }

    $zip = new ZipArchive();
    if ($zip->open($tmpZip) !== true) {
        $log[] = 'LOI (Cloudflare plugin): khong mo duoc zip vua tai';
        @unlink($tmpZip);
        return false;
    }
    mkdir($tmpExtract, 0755, true);
    $zip->extractTo($tmpExtract);
    $zip->close();
    @unlink($tmpZip);

    // Zip cua wordpress.org luon co 1 thu muc con cung ten slug plugin ben
    // trong (vd "cloudflare/cloudflare.php...") - do dung ten thu muc do
    // thay vi gia dinh cung "cloudflare" de an toan neu WordPress.org doi
    // quy uoc dong goi trong tuong lai.
    $entries = array_values(array_diff((array) @scandir($tmpExtract), ['.', '..']));
    $srcDir = null;
    foreach ($entries as $e) {
        if (is_dir($tmpExtract . '/' . $e)) {
            $srcDir = $tmpExtract . '/' . $e;
            break;
        }
    }
    if (!$srcDir) {
        $log[] = 'LOI (Cloudflare plugin): khong thay thu muc plugin sau khi giai nen';
        remove_dir_recursive($tmpExtract);
        return false;
    }

    copy_recursive($srcDir, $pluginsDir . '/' . basename($srcDir), $log);
    remove_dir_recursive($tmpExtract);
    $log[] = 'Da tai san plugin Cloudflare chinh thuc vao wp-content/plugins/ (chua kich hoat)';
    return true;
}

$cloudflarePluginInstalled = false;

if (!$alreadyInstalled && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['confirm'] ?? '') === 'yes') {
    if (!class_exists('ZipArchive')) {
        $log[] = 'LOI: thieu extension zip (ZipArchive) - kiem tra dong "extension = zip.so" trong php.ini.template co load duoc khong (xem $RUNDIR/php-fpm.log)';
    } else {
        // QUAN TRONG: KHONG dung sys_get_temp_dir()/tmpfile() o day. Ly do:
        // php-fpm.conf.template mac dinh clear_env=yes (mac dinh cua chinh
        // php-fpm tu ban 5.3.3, dòng "env[APP_HOME] = ..." la vi du duy nhat
        // duoc "cho qua" danh sach trang do) nen bien moi truong TMPDIR ma
        // Kotlin dat cho TIEN TRINH CHA (ServerForegroundService.runSiteLoop)
        // KHONG tu dong truyen xuong request PHP nay - sys_get_temp_dir() rat
        // co the tra ve "/tmp" (khong ton tai/khong ghi duoc trong sandbox
        // app Android). Dung thang 1 thu muc con trong _admin/ - noi CHAC
        // CHAN ghi duoc vi toan bo app phu thuoc vao dieu do.
        $tmpBase = __DIR__ . '/.install-tmp';
        if (!is_dir($tmpBase) && !mkdir($tmpBase, 0755, true) && !is_dir($tmpBase)) {
            $log[] = "LOI: khong tao duoc thu muc tam $tmpBase (kiem tra quyen ghi _admin/)";
        } else {
            $tmpZip = $tmpBase . '/wp-install-' . uniqid() . '.zip';
            $tmpExtract = $tmpBase . '/wp-install-' . uniqid();

            if (download_to('https://wordpress.org/latest.zip', $tmpZip, $log)) {
                $zip = new ZipArchive();
                if ($zip->open($tmpZip) === true) {
                    mkdir($tmpExtract, 0755, true);
                    $zip->extractTo($tmpExtract);
                    $zip->close();
                    $log[] = 'Da giai nen WordPress';

                    $src = $tmpExtract . '/wordpress';
                    if (is_dir($src)) {
                        copy_recursive($src, $docroot, $log);
                        $log[] = 'Da chep file WordPress vao docroot';

                        $salts = null;
                        $saltTmp = $tmpBase . '/wp-salt-' . uniqid() . '.php';
                        if (download_to('https://api.wordpress.org/secret-key/1.1/salt/', $saltTmp, $log)) {
                            $salts = @file_get_contents($saltTmp);
                            @unlink($saltTmp);
                        }
                        if (!$salts) {
                            // Du phong: tu sinh salt bang random_bytes() neu khong goi
                            // duoc API cua WordPress.org (vd mat mang giua chung) - van
                            // an toan tuong duong, chi khong phai lay tu server chinh chu.
                            $keys = ['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY',
                                     'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT'];
                            $lines = [];
                            foreach ($keys as $k) {
                                $lines[] = "define('$k', '" . bin2hex(random_bytes(32)) . "');";
                            }
                            $salts = implode("\n", $lines);
                            $log[] = 'Khong goi duoc API salt cua WordPress.org - da tu sinh salt bang random_bytes() (van an toan)';
                        }

                        $wpConfig = "<?php\n"
                            . "// Sinh tu dong boi _admin/install-wp.php (1-Click Installer)\n"
                            . "define('DB_NAME', 'wordpress');\n"
                            . "define('DB_USER', 'wordpress');\n"
                            . "define('DB_PASSWORD', 'wordpress');\n"
                            . "define('DB_HOST', 'localhost:" . $mysqlSock . "');\n"
                            . "define('DB_CHARSET', 'utf8mb4');\n"
                            . "define('DB_COLLATE', '');\n\n"
                            . $salts . "\n\n"
                            . "\$table_prefix = 'wp_';\n"
                            . "define('WP_DEBUG', false);\n\n"
                            . "if (!defined('ABSPATH')) { define('ABSPATH', __DIR__ . '/'); }\n"
                            . "require_once ABSPATH . 'wp-settings.php';\n";

                        if (file_put_contents($docroot . '/wp-config.php', $wpConfig) !== false) {
                            $success = true;
                            $log[] = 'Da tao wp-config.php - ket noi database "wordpress" co san (do start-lamp.sh tao truoc do)';

                            if (($_POST['install_cf_plugin'] ?? '') === 'yes') {
                                $cloudflarePluginInstalled = install_cloudflare_plugin($docroot, $tmpBase, $log);
                            }
                        } else {
                            $log[] = 'LOI: khong ghi duoc wp-config.php (kiem tra quyen ghi docroot)';
                        }
                    } else {
                        $log[] = 'LOI: khong thay thu muc wordpress/ sau khi giai nen';
                    }
                } else {
                    $log[] = 'LOI: khong mo duoc file zip vua tai (co the tai loi giua chung)';
                }
            }

            @unlink($tmpZip);
            if (is_dir($tmpExtract)) {
                remove_dir_recursive($tmpExtract);
            }
            // Don sach ca thu muc goc .install-tmp (khong de rac lai trong _admin/
            // sau khi cai xong, kho co the co file rac tu lan chay loi giua chung)
            remove_dir_recursive($tmpBase);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Cai WordPress 1-Click</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 480px; margin: 40px auto; padding: 0 20px; }
  .box { border: 1px solid #ddd; border-radius: 8px; padding: 16px 20px; margin-top: 16px; }
  .ok { color: #1a7a3c; }
  .err { color: #c0392b; }
  button { padding: 10px 16px; font-size: 15px; background: #21759B; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
  pre { background: #111; color: #ddd; padding: 10px; border-radius: 6px; font-size: 12px; overflow: auto; white-space: pre-wrap; word-break: break-all; }
  a.back { font-size: 13px; }
</style>
</head>
<body>
<p><a class="back" href="index.php">&larr; Quan tri</a></p>
<h2>Cai WordPress 1-Click</h2>

<?php if ($alreadyInstalled): ?>
  <div class="box">
    <p class="err">Da thay wp-config.php hoac wp-load.php trong docroot &mdash; website nay
    <b>da co san</b>, khong the cai de tranh mat du lieu.</p>
    <p>Neu ban thuc su muon cai lai tu dau, hay dung <a href="files.php">File Manager</a>
    de xoa hoac doi ten cac file nay truoc, roi quay lai trang nay.</p>
  </div>
<?php elseif ($success): ?>
  <div class="box">
    <p class="ok">Cai dat xong. Database da san sang.</p>
    <p><a href="../">Mo website ngay</a> de hoan tat man hinh cai dat WordPress 5 phut
    quen thuoc (chon ngon ngu, dat ten site + tai khoan admin).</p>
  </div>
  <?php if ($cloudflarePluginInstalled): ?>
  <div class="box">
    <p><b>Buoc tiep theo (tuy chon) - bat Cloudflare APO:</b></p>
    <p style="font-size:13px;">Da tai san plugin Cloudflare vao wp-content/plugins/. Sau khi
    hoan tat man hinh cai dat WordPress 5 phut o tren, lam them 3 buoc sau
    de web chiu duoc luong truy cap lon hon rat nhieu ma khong ton them RAM
    dien thoai (Cloudflare gui trang tinh thay ban tu rieng mang luoi edge
    cua ho):</p>
    <ol style="font-size:13px;">
      <li>Trang quan tri WordPress &rarr; Plugins &rarr; kich hoat "Cloudflare".</li>
      <li>Tao API Token tai <code>dash.cloudflare.com</code> (quyen toi thieu:
      Zone &rarr; Zone Settings &rarr; Edit, Zone &rarr; Zone &rarr; Read), dan
      vao man hinh cai dat cua plugin.</li>
      <li>Trong Cloudflare Dashboard cua domain nay &rarr; tab Speed &rarr;
      bat "Automatic Platform Optimization for WordPress" (mien phi neu dang
      dung goi Pro tro len, 5 USD/thang neu dang dung goi Free).</li>
    </ol>
    <p style="font-size:12px; color:#666;">Luu ý: plugin nay danh gia 3.5/5
    sao tren wordpress.org (mot so review cu phan nan bao tri cham), nhung
    changelog gan day (2025-2026) cho thay van dang duoc cap nhat deu. Khong
    bat buoc phai dung - co the go bo neu khong can.</p>
  </div>
  <?php endif; ?>
<?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
  <div class="box">
    <p class="err">Cai dat that bai. Chi tiet:</p>
    <pre><?= htmlspecialchars(implode("\n", $log)) ?></pre>
    <p><a href="install-wp.php">Thu lai</a></p>
  </div>
<?php else: ?>
  <div class="box">
    <p>Docroot dang trong. Bam nut ben duoi de tai WordPress moi nhat tu
    wordpress.org va tu dong ket noi vao database &quot;wordpress&quot; co san
    tren may (khong can nhap thong tin database thu cong).</p>
    <p>Qua trinh nay tai vai chuc MB qua mang &mdash; co the mat 30 giay den
    2 phut tuy toc do mang cua dien thoai.</p>
    <form method="post">
      <input type="hidden" name="confirm" value="yes">
      <p style="font-size:13px;">
        <label>
          <input type="checkbox" name="install_cf_plugin" value="yes" checked>
          Tai san plugin <b>Cloudflare</b> chinh thuc (de bat Automatic Platform
          Optimization sau nay, giup web nhe ganh hon rat nhieu khi co dong
          truy cap - xem huong dan sau khi cai xong). Chi tai file, ban tu
          kich hoat + nhap API Token sau.
        </label>
      </p>
      <button type="submit">Cai WordPress ngay</button>
    </form>
  </div>
<?php endif; ?>
</body>
</html>
