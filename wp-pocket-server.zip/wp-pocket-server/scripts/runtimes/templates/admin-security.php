<?php
// Trung tam bao mat - HANDOFF.md muc 1br (docs/SECURITY.md). Gom o MOT cho: tinh trang tong quan (tu kiem tra), IP dang bi tu dong chan + huy chan,
// ket qua quet ma doc/file la + cach ly/khoi phuc, tai khoan dang bi phong thu (Shield), cong tat (chan crawler AI, khoa khan cap, cac cho phep cua Shield).
// Moi muc chi DOC file trang thai do supervisor/mu-plugin ghi trong lamp-run/ va ghi cac "file co" - khong dung gi vao nginx/php-fpm/database.
// Thu vien dung chung voi supervisor: security-lib.php (= security-guard.php) va security-scan-lib.php (= security-scan.php), chep boi admin_tools.sh.
// Test: scripts/tests/security-center-test.py (+ admin-security-test.py: LAN-only/CSRF/khong Fatal).
require __DIR__ . '/auth.php';
define('WPP_GUARD_AS_LIB', 1);
define('WPP_SCAN_AS_LIB', 1);
require_once __DIR__ . '/security-lib.php';
require_once __DIR__ . '/security-scan-lib.php';
define('WPP_VULN_AS_LIB', 1);
$hasVulnLib = is_file(__DIR__ . '/security-vuln-lib.php');       // kiem lo hong da biet (1br-H): ban cai cu chua co thu vien nay thi trang van chay, chi khong hien muc do
if ($hasVulnLib) {
    require_once __DIR__ . '/security-vuln-lib.php';
}

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$rundir = $appHome !== '' ? $appHome . '/lamp-run' : null;
$webroot = dirname(__DIR__);
$liteMode = $rundir !== null && file_exists($rundir . '/lite-mode');
$me = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
$now = time();
$isWp = is_file($webroot . '/wp-load.php');

function esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

/** Cong tat (file co trong lamp-run/): ten => [mo ta ngan, mac dinh khi KHONG co file]. Chi cac ten nay moi duoc bat/tat tu form. */
function wp_pocket_sec_flags(): array
{
    return [
        'block-ai-on' => 'Chan crawler AI (GPTBot, ClaudeBot, CCBot, PerplexityBot...) - nginx tra 403',
        'maintenance-mode' => 'KHOA KHAN CAP: khach thay trang "dang bao tri", ban van vao _admin/',
        'shield-off' => 'TAT mu-plugin Shield (chong do tai khoan/mat khau) - chi dung khi no xung dot plugin khac',
        'shield-allow-user-api' => 'Cho KHACH doc danh sach nguoi dung qua REST API (site headless/ung dung can; mac dinh an)',
        'shield-allow-file-edit' => 'Cho sua file plugin/theme ngay trong wp-admin (mac dinh tat: admin bi chiem khong sua duoc ma PHP)',
        'shield-allow-app-passwords' => 'Cho "Mat khau ung dung" cua WordPress (mac dinh tat: la cua hau cho admin bi chiem)',
        'vuln-check-on' => 'Kiem LO HONG DA BIET cua plugin/theme/loi WordPress (GUI danh sach slug + phien ban toi wpvulnerability.net; mac dinh TAT - xem PRIVACY.md)',
        'twofa-off' => 'TAT KHAN CAP dang nhap hai buoc cua WordPress cho CA SITE (dung khi mat dien thoai ma chua dat lai duoc; xoa de bat lai)',
    ];
}

/** Doc-sua-ghi file trang thai dang nhap cua Shield (shield-login.json) duoi flock - cung dinh dang voi wppocket-shield-logic.php. */
function wp_pocket_sec_shield_mutate(string $file, callable $fn): bool
{
    $fh = @fopen($file, 'c+');
    if (!$fh) {
        return false;
    }
    if (!flock($fh, LOCK_EX)) {
        fclose($fh);
        return false;
    }
    $d = json_decode((string) stream_get_contents($fh), true);
    if (!is_array($d) || ($d['v'] ?? 0) !== 1) {
        $d = ['v' => 1, 'u' => [], 'k' => []];
    }
    $d = $fn($d);
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($d));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return true;
}

/** Doc-chi (khong tao file) trang thai Shield: danh sach tai khoan dang phong thu. */
function wp_pocket_sec_shield_locked(?string $file, int $now): array
{
    $d = $file !== null && is_file($file) ? json_decode((string) @file_get_contents($file), true) : null;
    $out = [];
    foreach ((array) ($d['u'] ?? []) as $k => $e) {
        if ((int) ($e['lock'] ?? 0) > $now) {
            $out[(string) $k] = (int) $e['lock'];
        }
    }
    return $out;
}

/** "ban-list/allowlist": moi dong 1 IP hoac CIDR (IPv4 /0-32, IPv6 /0-128), '#' ghi chu. Tra [dong hop le[], dong sai[]]. */
function wp_pocket_sec_parse_allow(string $text): array
{
    $ok = [];
    $bad = [];
    foreach ((array) preg_split('/\R/', $text, -1, PREG_SPLIT_NO_EMPTY) as $line) {
        $line = trim((string) preg_replace('/#.*$/', '', (string) $line));
        if ($line === '') {
            continue;
        }
        $base = $line;
        $bits = null;
        if (strpos($line, '/') !== false) {
            [$base, $bits] = explode('/', $line, 2);
        }
        $v4 = filter_var($base, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
        $v6 = !$v4 && filter_var($base, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
        if (!$v4 && !$v6) {
            $bad[] = $line;
        } elseif ($bits !== null && (!ctype_digit($bits) || (int) $bits > ($v4 ? 32 : 128))) {
            $bad[] = $line;
        } else {
            $ok[] = (string) inet_ntop((string) inet_pton($base)) . ($bits !== null ? '/' . (int) $bits : '');
        }
    }
    return [array_values(array_unique($ok)), $bad];
}

function wp_pocket_sec_audit(?string $rundir, string $ip, string $event): void
{
    if ($rundir !== null && is_dir($rundir)) {
        wp_pocket_audit_log($rundir . '/admin-audit.log', $ip, 'security: ' . preg_replace('/[\r\n]+/', ' ', substr($event, 0, 200)));
    }
}

function wp_pocket_sec_ago(int $ts, int $now): string
{
    $d = max(0, $now - $ts);
    if ($d < 90) return $d . ' giay truoc';
    if ($d < 5400) return (int) round($d / 60) . ' phut truoc';
    if ($d < 129600) return (int) round($d / 3600) . ' gio truoc';
    return (int) round($d / 86400) . ' ngay truoc';
}

$paths = $rundir !== null ? wpp_guard_paths($rundir) : null;
$sp = $rundir !== null ? wpp_scan_paths($rundir) : null;
$flagsDef = wp_pocket_sec_flags();
$msg = '';
$err = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    if (!wp_pocket_csrf_verify()) {
        $err = 'Token bao mat (CSRF) khong hop le hoac da het han - tai lai trang va thu lai.';
    } elseif ($rundir === null || !is_dir($rundir)) {
        $err = 'Khong tim thay thu muc lamp-run (APP_HOME chua dat) - hay bat server it nhat 1 lan.';
    } elseif ($action === 'unban') {
        $key = is_string($_POST['key'] ?? null) ? $_POST['key'] : '';
        $active = wpp_guard_active_bans($rundir, $now);
        if (!isset($active[$key])) {
            $err = 'Muc chan khong con (da het han hoac da go).';
        } elseif (wpp_guard_unban($rundir, $key, $now)) {
            $msg = 'Da huy chan ' . $key . ' - hieu luc sau it giay (nginx nap lai danh sach).';
            wp_pocket_sec_audit($rundir, $me, 'unban ' . $key);
        } else {
            $err = 'Khong huy chan duoc (tien trinh khac dang ghi) - thu lai.';
        }
    } elseif ($action === 'allow_save') {
        [$entries, $bad] = wp_pocket_sec_parse_allow(is_string($_POST['entries'] ?? null) ? $_POST['entries'] : '');
        if ($bad) {
            $err = 'Dong khong phai IP/CIDR hop le: ' . implode(', ', array_slice($bad, 0, 5)) . '. Chua luu gi.';
        } elseif (count($entries) > 100) {
            $err = 'Toi da 100 muc. Chua luu gi.';
        } elseif (!$entries) {
            $msg = !is_file($paths['allow']) || @unlink($paths['allow']) ? 'Da xoa danh sach IP tin cay.' : '';
            $err = $msg === '' ? 'Khong xoa duoc file.' : '';
        } elseif (@file_put_contents($paths['allow'], "# IP tin cay: KHONG BAO GIO bi tu dong chan (sua tu _admin/security.php)\n" . implode("\n", $entries) . "\n", LOCK_EX) !== false) {
            $msg = 'Da luu ' . count($entries) . ' IP tin cay.';
            wp_pocket_sec_audit($rundir, $me, 'allowlist ' . count($entries));
        } else {
            $err = 'Khong ghi duoc file.';
        }
    } elseif ($action === 'scan_now') {
        if ($liteMode) {
            wpp_scan_run($webroot, $rundir);            // che do Lite khong co supervisor: quet ngay trong yeu cau nay (toi da ~45 giay)
            $msg = 'Da quet xong.';
        } elseif (@file_put_contents($sp['now'], (string) $now) !== false) {
            $msg = 'Da yeu cau quet - supervisor se chay trong vai giay, tai lai trang sau 1-2 phut de xem ket qua.';
        } else {
            $err = 'Khong ghi duoc file co quet.';
        }
    } elseif ($action === 'vuln_now') {
        if (!$hasVulnLib || !wpp_vuln_enabled($rundir)) {
            $err = 'Kiem lo hong dang TAT - bat cong "vuln-check-on" truoc.';
        } elseif ($liteMode) {
            wpp_vuln_run($webroot, $rundir);             // che do Lite khong co supervisor: kiem ngay trong yeu cau nay (toi da ~50 giay)
            $msg = 'Da kiem xong.';
        } elseif (@file_put_contents(wpp_vuln_paths($rundir)['now'], (string) $now) !== false) {
            $msg = 'Da yeu cau kiem - supervisor se chay trong vai giay, tai lai trang sau ~1 phut de xem ket qua.';
        } else {
            $err = 'Khong ghi duoc file co kiem.';
        }
    } elseif ($action === 'scan_fetch') {
        $msg = wpp_scan_fetch_core_checksums($webroot, $sp['core']) ? 'Da tai checksum chinh thuc cua WordPress - quet lai de dung.' : '';
        $err = $msg === '' ? 'Khong tai duoc checksum (khong co mang, hoac ban WordPress khong chinh thuc/nightly).' : '';
    } elseif ($action === 'scan_accept') {
        if (wpp_scan_accept($rundir)) {
            @file_put_contents($sp['now'], (string) $now);
            $msg = 'Da dat trang thai hien tai lam MOC moi (diem bam tru + plugin/theme). Chi lam khi ban CHAC CHAN cac thay doi la do ban.';
            wp_pocket_sec_audit($rundir, $me, 'scan baseline accepted');
        } else {
            $err = 'Khong dat lai duoc moc.';
        }
    } elseif ($action === 'quarantine') {
        $file = is_string($_POST['file'] ?? null) ? $_POST['file'] : '';
        $r = wpp_scan_quarantine($webroot, $rundir, $file, $now);
        if ($r['ok']) {
            $msg = 'Da cach ly ' . $file . ' (khoi phuc duoc o muc "Da cach ly"). Quet lai de cap nhat danh sach.';
            wp_pocket_sec_audit($rundir, $me, 'quarantine ' . $file);
        } else {
            $err = 'Khong cach ly duoc: ' . $r['msg'];
        }
    } elseif ($action === 'restore') {
        $r = wpp_scan_restore($webroot, $rundir, is_string($_POST['id'] ?? null) ? $_POST['id'] : '');
        if ($r['ok']) {
            $msg = ucfirst($r['msg']) . '.';
            wp_pocket_sec_audit($rundir, $me, 'restore ' . ($_POST['id'] ?? ''));
        } else {
            $err = 'Khong khoi phuc duoc: ' . $r['msg'];
        }
    } elseif ($action === 'ignore') {
        $file = is_string($_POST['file'] ?? null) ? $_POST['file'] : '';
        $sha = is_string($_POST['sha1'] ?? null) ? $_POST['sha1'] : '';
        if ($file === '' || strlen($file) > 400 || ($sha !== '' && !preg_match('/^[0-9a-f]{40}$/', $sha))) {
            $err = 'Du lieu khong hop le.';
        } elseif (wpp_scan_ignore($rundir, $file, $sha)) {
            $msg = 'Da danh dau an toan (chi cho dung noi dung hien tai cua file) - se het bao o lan quet sau.';
            wp_pocket_sec_audit($rundir, $me, 'ignore ' . $file);
        } else {
            $err = 'Khong ghi duoc.';
        }
    } elseif ($action === 'login_clear') {
        $key = is_string($_POST['key'] ?? null) ? $_POST['key'] : '';
        if (wp_pocket_sec_shield_mutate($rundir . '/shield-login.json', function (array $d) use ($key) {
            if ($key === '') {
                $d['u'] = [];
            } else {
                unset($d['u'][$key]);
            }
            return $d;
        })) {
            $msg = 'Da go trang thai phong thu dang nhap' . ($key !== '' ? ' cua ' . $key : '') . '.';
            wp_pocket_sec_audit($rundir, $me, 'login lock cleared ' . $key);
        } else {
            $err = 'Khong ghi duoc file trang thai.';
        }
    } elseif ($action === 'flag') {
        $name = is_string($_POST['name'] ?? null) ? $_POST['name'] : '';
        $on = ($_POST['value'] ?? '') === 'on';
        if (!isset($flagsDef[$name])) {
            $err = 'Cong tat khong hop le.';
        } else {
            $f = $rundir . '/' . $name;
            $ok = $on ? @file_put_contents($f, '') !== false : (!file_exists($f) || @unlink($f));
            if ($ok) {
                $msg = $name . ($on ? ' DA BAT.' : ' da tat.');
                wp_pocket_sec_audit($rundir, $me, 'flag ' . $name . ' ' . ($on ? 'on' : 'off'));
            } else {
                $err = 'Khong ghi duoc file co.';
            }
        }
    } else {
        $err = 'Hanh dong khong hop le.';
    }
}

// ---------- du lieu hien thi ----------
$status = $paths !== null && is_file($paths['status']) ? json_decode((string) @file_get_contents($paths['status']), true) : null;
$bans = $rundir !== null ? wpp_guard_active_bans($rundir, $now) : [];
$scan = $rundir !== null ? wpp_scan_last_result($rundir) : null;
$quar = $rundir !== null ? wpp_scan_quarantine_index($rundir) : [];
$locked = wp_pocket_sec_shield_locked($rundir !== null ? $rundir . '/shield-login.json' : null, $now);
$allowText = $paths !== null && is_file($paths['allow']) ? (string) @file_get_contents($paths['allow']) : '';
$flagOn = [];
foreach ($flagsDef as $n => $_d) {
    $flagOn[$n] = $rundir !== null && file_exists($rundir . '/' . $n);
}
$events = [];
if ($paths !== null && is_file($paths['events'])) {
    $all = @file($paths['events'], FILE_IGNORE_NEW_LINES) ?: [];
    $events = array_reverse(array_slice($all, -40));
}

$vuln = $hasVulnLib && $rundir !== null ? wpp_vuln_last($rundir) : null;
$vulnOn = $hasVulnLib && $rundir !== null && wpp_vuln_enabled($rundir);
$vulnFindings = $vuln !== null && !empty($vuln['enabled']) ? (array) ($vuln['findings'] ?? []) : [];

// ---------- tu kiem tra ----------
$checks = [];   // [muc: ok|warn|bad, tieu de, chi tiet]
if ($rundir !== null && file_exists($rundir . '/realip-missing') && !$liteMode) {
    $checks[] = ['bad', 'Khong phan biet duoc khach that', 'nginx thieu module realip: moi khach qua Cloudflare hien la 127.0.0.1 nen KHONG chan IP (chan se khoa ca site, nen he thong tu choi chan). Cac lop con lai (quet ma doc, Shield) van hoat dong.'];
}
if ($liteMode) {
    $checks[] = ['warn', 'Che do Lite', 'Khong co nginx: khong co tu dong chan IP, an file nhay cam, chan crawler. Chi con quet ma doc + Shield (neu la WordPress).'];
} elseif ($status === null || !is_array($status) || $now - (int) ($status['at'] ?? 0) > 600) {
    $checks[] = ['warn', 'Tu dong chan IP chua chay gan day', 'Chua co ket qua tu security-guard (server vua bat? hoac vong giam sat khong chay).'];
} else {
    $checks[] = ['ok', 'Tu dong chan IP dang chay', 'Lan chay cuoi ' . wp_pocket_sec_ago((int) $status['at'], $now) . '; ' . count($bans) . ' IP dang bi chan.'];
}
if (is_file($appHome . '/admin-totp-enabled.flag')) {
    $checks[] = ['ok', 'Xac thuc 2 buoc (2FA) cho _admin/ dang bat', ''];
} else {
    $checks[] = ['warn', 'Chua bat 2FA cho trang quan tri', 'Mat khau + 2FA la lop bao ve manh nhat truoc cong cu do mat khau bang AI. Bat o muc "Xac thuc 2 buoc".'];
}
if ($isWp) {
    if (is_file($webroot . '/wp-content/mu-plugins/wppocket-shield.php') && !$flagOn['shield-off']) {
        $checks[] = ['ok', 'Shield (bao ve ben trong WordPress) dang bat', 'Chong do ten tai khoan, phong thu khi bi do mat khau tu nhieu IP, ghi su kien admin moi/plugin moi.'];
    } else {
        $checks[] = ['warn', 'Shield chua hoat dong', $flagOn['shield-off'] ? 'Dang bi tat bang cong "shield-off".' : 'Chua co mu-plugin wppocket-shield.php (se duoc chep khi server khoi dong lai).'];
    }
    if ($flagOn['twofa-off']) {
        $checks[] = ['warn', 'Dang nhap hai buoc cua WordPress dang TAT toan site', 'Cong "twofa-off" dang bat: ai da bat hai buoc cung chi can mat khau. Xoa cong khi da dat lai thiet bi.'];
    } elseif (is_file($webroot . '/wp-content/mu-plugins/wppocket-2fa.php')) {
        $checks[] = ['ok', 'Dang nhap hai buoc (TOTP) cho WordPress san sang', 'Moi nguoi dung tu bat o trang Ho so (Profile); nen bat cho moi tai khoan quan tri.'];
    }
    $cfg = (string) @file_get_contents($webroot . '/wp-config.php', false, null, 0, 65536);
    if (preg_match("/WP_AUTO_UPDATE_CORE['\"]\s*,\s*false/i", $cfg) === 1) {
        $checks[] = ['bad', 'Tu cap nhat ban va bao mat cua WordPress dang TAT', 'wp-config.php co WP_AUTO_UPDATE_CORE = false. Khai thac lo hong moi xay ra trong vai gio sau khi cong bo - nen bat lai tu dong cap nhat ban nho.'];
    }
}
if ($hasVulnLib) {
    if (!$vulnOn) {
        $checks[] = ['warn', 'Chua bat kiem LO HONG DA BIET cua plugin/theme', 'Ke tan cong dung AI khai thac lo hong trong vai gio sau khi cong bo. Bat cong "vuln-check-on" de biet plugin nao dang chay ban co lo hong (se gui slug + phien ban plugin toi wpvulnerability.net, xem PRIVACY.md).'];
    } elseif ($vuln === null || empty($vuln['enabled'])) {
        $checks[] = ['warn', 'Kiem lo hong chua co ket qua', 'Da bat nhung chua chay lan nao (supervisor chay ~2 phut sau khi khoi dong roi moi gio). Bam "Kiem ngay" o muc Lo hong da biet.'];
    } else {
        $vc = (array) ($vuln['counts'] ?? []);
        if ((int) ($vc['critical'] ?? 0) + (int) ($vc['high'] ?? 0) > 0) {
            $checks[] = ['bad', 'Co plugin/theme/loi dang chay ban CO LO HONG nghiem trong', (int) ($vc['critical'] ?? 0) . ' nghiem trong, ' . (int) ($vc['high'] ?? 0) . ' cao - CAP NHAT hoac go bo ngay, xem muc "Lo hong da biet".'];
        } elseif ((int) ($vc['medium'] ?? 0) > 0) {
            $checks[] = ['warn', 'Co ' . (int) $vc['medium'] . ' lo hong muc trung binh', 'Xem muc "Lo hong da biet" va cap nhat plugin/theme.'];
        } else {
            $checks[] = ['ok', 'Khong thay lo hong da biet nao trong ban dang cai', wp_pocket_sec_ago((int) $vuln['at'], $now) . ($vuln['truncated'] ?? false ? ' (CHUA XONG: con muc chua kiem)' : '') . '. Khong biet ve plugin tra phi/tu viet khong co tren wordpress.org.'];
        }
    }
}
if ($scan === null) {
    $checks[] = ['warn', 'Chua quet ma doc/file la', 'Bam "Quet ngay" (supervisor cung tu quet ~1 phut sau khi khoi dong, roi moi gio).'];
} else {
    $age = $now - (int) ($scan['at'] ?? 0);
    $c = (array) ($scan['counts'] ?? []);
    if (((int) ($c['critical'] ?? 0)) + ((int) ($c['high'] ?? 0)) > 0) {
        $checks[] = ['bad', 'Quet thay dau hieu NGUY HIEM', (int) ($c['critical'] ?? 0) . ' nghiem trong, ' . (int) ($c['high'] ?? 0) . ' cao - xem muc "Ket qua quet" ben duoi NGAY.'];
    } elseif ((int) ($c['medium'] ?? 0) > 0) {
        $checks[] = ['warn', 'Quet thay ' . (int) $c['medium'] . ' muc can xem', 'Thuong la plugin/theme moi cai hoac thu vien hop phap - xem muc "Ket qua quet".'];
    } else {
        $checks[] = ['ok', 'Lan quet cuoi sach', wp_pocket_sec_ago((int) $scan['at'], $now) . ', ' . (int) ($scan['files'] ?? 0) . ' file.'];
    }
    if ($age > 21600) {
        $checks[] = ['warn', 'Ket qua quet da cu', 'Lan quet cuoi ' . wp_pocket_sec_ago((int) $scan['at'], $now) . '.'];
    }
    if (!empty($scan['truncated'])) {
        $checks[] = ['warn', 'Lan quet bi cat giua chung', 'Qua nhieu file hoac het thoi gian - mot phan site chua duoc quet va moc chua duoc lap.'];
    }
    if (($scan['profile'] ?? '') === 'wordpress' && empty($scan['core']['verified'])) {
        $checks[] = ['warn', 'Chua doi chieu duoc file loi WordPress voi ban chinh thuc', 'Bam "Tai checksum loi" (can mang). Neu la ban nightly/ngon ngu khong ho tro thi khong the doi chieu.'];
    }
}
if ($rundir !== null && file_exists($rundir . '/maintenance-mode')) {
    $checks[] = ['warn', 'Dang o che do bao tri/khoa khan cap', 'Khach khong thay website.'];
}
$sevLabel = ['critical' => 'NGHIEM TRONG', 'high' => 'CAO', 'medium' => 'TRUNG BINH', 'low' => 'THAP', 'info' => 'thong tin'];
$findings = (array) ($scan['findings'] ?? []);
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Trung tam bao mat</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:860px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
h2{font-size:16px;margin:0 0 6px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.card{border:1px solid #ddd;border-radius:10px;padding:14px 16px;margin:14px 0}
.state{display:inline-block;font-size:12px;font-weight:700;padding:1px 8px;border-radius:9px;margin-left:6px}
.state.on{background:#e3f4e8;color:#1d7a3d}.state.off{background:#eceff3;color:#556}
.msg{background:#e3f4e8;color:#1d7a3d;padding:10px 14px;border-radius:8px;margin:12px 0;font-size:14px}
.err{background:#fdecea;color:#8a1c1c;padding:10px 14px;border-radius:8px;margin:12px 0;font-size:14px}
.note{background:#fff8e1;color:#7a5b00;padding:10px 14px;border-radius:8px;margin:12px 0;font-size:13px}
p,li,td,th{font-size:14px;line-height:1.5}
button{padding:6px 12px;font-size:13px;border:0;border-radius:8px;background:#1a73e8;color:#fff;cursor:pointer}
button.off,button.grey{background:#777}
button.danger{background:#c62828}
textarea{width:100%;box-sizing:border-box;min-height:80px;font-family:ui-monospace,monospace;font-size:13px}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:5px 6px;border-bottom:1px solid #eee;vertical-align:top}
td.f{word-break:break-all;font-family:ui-monospace,monospace;font-size:12px}
.sev{font-size:11px;font-weight:700;padding:1px 6px;border-radius:6px;white-space:nowrap}
.sev.critical{background:#c62828;color:#fff}.sev.high{background:#ef6c00;color:#fff}.sev.medium{background:#fff3cd;color:#7a5b00}.sev.info,.sev.low{background:#eceff3;color:#556}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px}
.dot.ok{background:#2ecc71}.dot.warn{background:#f39c12}.dot.bad{background:#e74c3c}
.small{color:#777;font-size:12px}
form.inl{display:inline}
pre{white-space:pre-wrap;word-break:break-all;font-size:12px;background:#f6f7f9;padding:8px;border-radius:8px;max-height:260px;overflow:auto}
/* Dark mode (HANDOFF.md muc 1bg): cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Trung tam bao mat</h1>

<?php if ($msg !== ''): ?><div class="msg"><?= esc($msg) ?></div><?php endif; ?>
<?php if ($err !== ''): ?><div class="err"><?= esc($err) ?></div><?php endif; ?>

<div class="card">
  <h2>Tinh trang</h2>
  <?php foreach ($checks as [$lv, $title, $detail]): ?>
  <p><span class="dot <?= esc($lv) ?>"></span><b><?= esc($title) ?></b><?php if ($detail !== ''): ?><br><span class="small"><?= esc($detail) ?></span><?php endif; ?></p>
  <?php endforeach; ?>
</div>

<div class="card">
  <h2>Ket qua quet ma doc / file la
    <?php if ($scan !== null): ?><span class="state off"><?= esc(wp_pocket_sec_ago((int) $scan['at'], $now)) ?></span><?php endif; ?></h2>
  <p class="small">So sanh checksum file loi WordPress voi ban chinh thuc, tim PHP trong uploads/, anh gia mao (polyglot), file la o thu muc goc, mu-plugin/drop-in moi, plugin/theme moi, dau hieu web-shell.
  <b>Day la HEURISTIC</b>: co the bao nham thu vien hop phap (dung "Danh dau an toan"); khong bao dong cung KHONG dam bao sach. Khong tu xoa gi - chi cach ly (khoi phuc duoc).</p>
  <form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="scan_now"><button type="submit">Quet ngay</button></form>
  <?php if ($isWp): ?><form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="scan_fetch"><button type="submit" class="grey">Tai checksum loi WordPress</button></form><?php endif; ?>
  <form method="post" class="inl" onsubmit="return confirm('Chap nhan trang thai hien tai lam moc? Chi lam khi ban chac chan cac thay doi la do ban/cap nhat hop le.')"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="scan_accept"><button type="submit" class="grey">Chap nhan trang thai hien tai (dat moc moi)</button></form>
  <?php if ($scan === null): ?>
    <p>Chua co ket qua quet.</p>
  <?php elseif (!$findings): ?>
    <p><b>Khong co phat hien nao.</b> <?= (int) ($scan['files'] ?? 0) ?> file trong <?= esc($scan['duration'] ?? '?') ?>s<?= !empty($scan['baseline_created']) ? '; lan dau: da lap moc de so sanh cac lan sau.' : '.' ?></p>
  <?php else: ?>
    <table>
      <tr><th>Muc</th><th>Loai / File</th><th></th></tr>
      <?php foreach (array_slice($findings, 0, 100) as $f):
          $sev = (string) ($f['sev'] ?? 'info');
          $file = (string) ($f['file'] ?? '');
          $canQ = in_array($sev, ['critical', 'high', 'medium'], true) && $file !== '' && is_file($webroot . '/' . $file) && !is_link($webroot . '/' . $file);
          ?>
      <tr>
        <td><span class="sev <?= esc($sev) ?>"><?= esc($sevLabel[$sev] ?? $sev) ?></span></td>
        <td><b><?= esc($f['kind'] ?? '') ?></b><br><span class="f small"><?= esc($file) ?></span><br><span class="small"><?= esc($f['detail'] ?? '') ?></span></td>
        <td>
          <?php if ($canQ): ?>
          <form method="post" class="inl" onsubmit="return confirm('Cach ly file nay? Website co the loi neu day la file that cua plugin/theme. Khoi phuc duoc.')"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="quarantine"><input type="hidden" name="file" value="<?= esc($file) ?>"><button type="submit" class="danger">Cach ly</button></form>
          <?php endif; ?>
          <form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="ignore"><input type="hidden" name="file" value="<?= esc($file) ?>"><input type="hidden" name="sha1" value="<?= esc($f['sha1'] ?? '') ?>"><button type="submit" class="grey">Danh dau an toan</button></form>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php if (count($findings) > 100): ?><p class="small">Chi hien 100 muc dau (nghiem trong truoc).</p><?php endif; ?>
  <?php endif; ?>

  <?php if ($quar): ?>
  <h2 style="margin-top:14px">Da cach ly</h2>
  <table>
    <?php foreach ($quar as $id => $q): ?>
    <tr><td class="f"><?= esc($q['orig'] ?? '') ?><br><span class="small"><?= esc($id) ?> &middot; <?= (int) ($q['size'] ?? 0) ?> byte</span></td>
      <td><form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?= esc($id) ?>"><button type="submit" class="grey">Khoi phuc</button></form></td></tr>
    <?php endforeach; ?>
  </table>
  <p class="small">File cach ly nam trong lamp-run/quarantine/ (doi duoi .quar, khong chay duoc). Xoa han bang File Manager neu da chac chan la ma doc.</p>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Lo hong da biet cua plugin / theme / loi WordPress
    <span class="state <?= $vulnOn ? 'on' : 'off' ?>"><?= $vulnOn ? 'BAT' : 'TAT' ?></span>
    <?php if ($vuln !== null && !empty($vuln['enabled'])): ?><span class="state off"><?= esc(wp_pocket_sec_ago((int) $vuln['at'], $now)) ?></span><?php endif; ?></h2>
  <?php if (!$hasVulnLib): ?>
    <p>Thu vien kiem lo hong chua co trong ban cai nay (cap nhat ung dung roi khoi dong lai server).</p>
  <?php else: ?>
  <p class="small">Doi chieu phien ban DANG CAI voi co so du lieu lo hong cong khai (WPVulnerability). <b>TUY CHON, mac dinh TAT</b> vi tinh nang nay <b>gui ra www.wpvulnerability.net</b> danh sach
  <i>ten thu muc plugin/theme + phien ban + phien ban WordPress</i> (khong gui ten mien, noi dung site hay IP rieng cua site; xem PRIVACY.md). Bat/tat bang cong "vuln-check-on" o muc Cong tat ben duoi.
  Chi biet plugin/theme CO tren wordpress.org - khong thay lo hong KHONG co nghia la an toan. Cap nhat plugin xong: bam "Kiem ngay", canh bao het ngay (khong cho cache).</p>
  <?php if ($vulnOn): ?>
  <form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="vuln_now"><button type="submit">Kiem ngay</button></form>
  <?php if ($vuln === null || empty($vuln['enabled'])): ?>
    <p>Chua co ket qua.</p>
  <?php else: ?>
    <p class="small">Da kiem loi WordPress <?= esc($vuln['core'] ?? '?') ?>, <?= (int) ($vuln['plugins'] ?? 0) ?> plugin, <?= (int) ($vuln['themes'] ?? 0) ?> theme
    (<?= (int) ($vuln['requests'] ?? 0) ?> yeu cau moi<?= !empty($vuln['failed']) ? ', ' . (int) $vuln['failed'] . ' loi mang' : '' ?><?= !empty($vuln['truncated']) ? ', <b>CHUA XONG</b> - lan sau tiep tuc' : '' ?>).</p>
    <?php if (!$vulnFindings): ?>
      <p><b>Khong thay lo hong nao trong ban dang cai.</b></p>
    <?php else: ?>
    <table>
      <tr><th>Muc</th><th>Thanh phan / Lo hong</th></tr>
      <?php foreach (array_slice($vulnFindings, 0, 60) as $f): $sv = (string) ($f['sev'] ?? 'medium'); ?>
      <tr>
        <td><span class="sev <?= esc($sv) ?>"><?= esc($sevLabel[$sv] ?? $sv) ?></span><?= isset($f['score']) && $f['score'] !== null ? '<br><span class="small">CVSS ' . esc($f['score']) . '</span>' : '' ?></td>
        <td><b><?= esc($f['type'] ?? '') ?> <?= esc($f['slug'] ?? '') ?> <?= esc($f['version'] ?? '') ?></b><?= !empty($f['unfixed']) ? ' <span class="sev critical">CHUA CO BAN VA</span>' : '' ?><br>
          <span class="small"><?= esc($f['title'] ?? '') ?></span>
          <?php foreach ((array) ($f['src'] ?? []) as $sr): $lk = (string) ($sr['link'] ?? ''); if ($lk !== '' && preg_match('~^https?://~', $lk)): ?>
            <br><a class="small" href="<?= esc($lk) ?>" rel="noopener noreferrer nofollow" target="_blank"><?= esc($sr['name'] ?? $lk) ?></a>
          <?php endif; endforeach; ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
    <p class="small">Cach xu ly: cap nhat len ban moi nhat (wp-admin &gt; Cap nhat); neu "CHUA CO BAN VA" hoac plugin da bi dong thi tat/go plugin do va tim ban thay the.</p>
    <?php endif; ?>
    <?php if (!empty($vuln['skipped'])): ?><p class="small">Khong kiem duoc: <?= esc(implode('; ', array_slice((array) $vuln['skipped'], 0, 8))) ?></p><?php endif; ?>
  <?php endif; ?>
  <?php endif; ?>
  <?php endif; ?>
</div>

<div class="card">
  <h2>IP dang bi tu dong chan <span class="state <?= $bans ? 'on' : 'off' ?>"><?= count($bans) ?></span></h2>
  <p class="small">Nguoi do duong dan nhay cam (.env, .git, wp-config...), do mat khau, dung cong cu quet (diem tich luy trong 10 phut) bi chan 1 gio -> 1 ngay -> 7 ngay (tai pham). Khong bao gio chan IP trong mang rieng/loopback.</p>
  <?php if ($bans): ?>
  <table>
    <tr><th>IP / mang</th><th>Ly do</th><th>Het han</th><th></th></tr>
    <?php foreach (array_slice($bans, 0, 60, true) as $k => $b): ?>
    <tr><td class="f"><?= esc($k) ?></td><td><?= esc($b['reason'] ?? '') ?> <span class="small">(<?= (int) ($b['hits'] ?? 0) ?> lan, lan chan thu <?= (int) ($b['n'] ?? 1) ?>)</span></td>
      <td><?= esc(date('d/m H:i', (int) ($b['until'] ?? 0))) ?></td>
      <td><form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="unban"><input type="hidden" name="key" value="<?= esc($k) ?>"><button type="submit" class="grey">Huy chan</button></form></td></tr>
    <?php endforeach; ?>
  </table>
  <?php else: ?><p>Khong co IP nao dang bi chan.</p><?php endif; ?>
  <h2 style="margin-top:14px">IP tin cay (khong bao gio bi chan)</h2>
  <form method="post"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="allow_save">
    <textarea name="entries" placeholder="203.0.113.7&#10;198.51.100.0/24 # van phong"><?= esc(implode("\n", array_filter(array_map('trim', explode("\n", $allowText)), fn($l) => $l !== '' && $l[0] !== '#'))) ?></textarea>
    <p class="small">Moi dong 1 IP hoac CIDR (IPv4/IPv6). Them IP nha/van phong cua ban de tranh tu chan minh khi go sai mat khau nhieu lan. IP hien tai cua ban: <b><?= esc($me) ?></b>.</p>
    <button type="submit">Luu</button>
  </form>
</div>

<div class="card">
  <h2>Tai khoan WordPress dang bi phong thu <span class="state <?= $locked ? 'on' : 'off' ?>"><?= count($locked) ?></span></h2>
  <p class="small">Khi 1 tai khoan bi go sai 20 lan trong 15 phut (tu nhieu IP), Shield chi cho nhung mang DA TUNG dang nhap thanh cong vao tai khoan do (khoang 15 phut, gia han neu con bi do). Chu site tu mang quen khong bi anh huong.</p>
  <?php if ($locked): ?>
  <table>
    <?php foreach ($locked as $k => $until): ?>
    <tr><td class="f"><?= esc($k) ?> <span class="small">(id:N = tai khoan co that; n:ten = ten khong ton tai)</span></td><td>den <?= esc(date('H:i', $until)) ?></td>
      <td><form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="login_clear"><input type="hidden" name="key" value="<?= esc($k) ?>"><button type="submit" class="grey">Go phong thu</button></form></td></tr>
    <?php endforeach; ?>
  </table>
  <?php else: ?><p>Khong co tai khoan nao.</p><?php endif; ?>
</div>

<div class="card">
  <h2>Cong tat</h2>
  <table>
  <?php foreach ($flagsDef as $name => $desc): ?>
    <tr><td><b><?= esc($name) ?></b> <span class="state <?= $flagOn[$name] ? 'on' : 'off' ?>"><?= $flagOn[$name] ? 'BAT' : 'tat' ?></span><br><span class="small"><?= esc($desc) ?></span></td>
      <td><form method="post" class="inl"><?= wp_pocket_csrf_field() ?><input type="hidden" name="action" value="flag"><input type="hidden" name="name" value="<?= esc($name) ?>"><input type="hidden" name="value" value="<?= $flagOn[$name] ? 'off' : 'on' ?>"><button type="submit" class="<?= $flagOn[$name] ? 'off' : '' ?>"><?= $flagOn[$name] ? 'Tat' : 'Bat' ?></button></form></td></tr>
  <?php endforeach; ?>
  </table>
  <p class="small">Chan crawler AI co hieu luc ngay; cac cong "shield-*" co hieu luc o yeu cau WordPress ke tiep.</p>
</div>

<div class="card">
  <h2>Su kien bao mat gan day</h2>
  <?php if ($events): ?><pre><?= esc(implode("\n", $events)) ?></pre><?php else: ?><p>Chua co su kien.</p><?php endif; ?>
</div>
</body>
</html>
