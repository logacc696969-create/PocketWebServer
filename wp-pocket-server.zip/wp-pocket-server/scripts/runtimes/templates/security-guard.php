<?php
/**
 * security-guard.php - TU DONG CHAN IP DO QUET / DO MAT KHAU (fail2ban thu gon, khong can root/iptables).
 * HANDOFF.md muc 1br, docs/SECURITY.md. Test: scripts/tests/security-guard-test.py.
 *
 * BOI CANH: cong cu tan cong dung AI quet va khai thac lo hong vua cong bo trong vai gio, thu hang chuc nghin duong dan (shell.php,
 * .env, readme.txt cua tung plugin de biet phien ban, wp-config.php.bak...) tu IP may chu dam may. Moi lan do goi php-fpm/MariaDB tren 1
 * dien thoai la ton pin + CPU. Con nguoi khong ngoi canh log 24/7 nen viec chan phai tu dong.
 *
 * CACH LAM: nginx ghi nginx-security.log (chi cac request 4xx + request toi cua dang nhap, xem nginx.conf.template). start-lamp.sh goi
 * file nay moi ~30 giay: doc phan log MOI, cham diem tung IP, IP vuot nguong trong cua so truot bi ghi vao ban-list.conf (moi dong
 * "IP 1;" - nginx geo, tra 444 = cat ket noi khong tra loi) roi tao co ban-reload de start-lamp.sh gui HUP cho nginx nap lai.
 * Thoi han chan tang dan theo so lan tai pham (1 gio -> 24 gio -> 7 ngay).
 *
 * AN TOAN (nhung dieu file nay KHONG DUOC lam):
 *  - Khong bao gio chan IP loopback/mang rieng (LAN)/CGNAT/link-local: khi nginx khong co module realip, moi khach cong khai deu hien la
 *    127.0.0.1 - chan no la chan CA SITE. Cung khong chan IP trong security-allow.txt (chu site tu khai bao).
 *  - Chi ghi vao ban-list.conf nhung dong da qua kiem tra cu phap (IP hop le hoac CIDR /64 IPv6): 1 dong sai la nginx khong khoi dong duoc
 *    lan sau (xem wpp_guard_sanitize_file, start-lamp.sh goi truoc khi bat nginx).
 *  - Co lop "chu site da dang nhap": IP vua dang nhap wp-login.php THANH CONG (302) trong 24 gio bi giam nhe diem cac loi hay gap
 *    (404/403/lenh admin-ajax), de chu site mo trinh soan thao/plugin loi khong tu khoa minh. Dau hieu tan cong ro (traversal, SQLi, shell,
 *    .env...) van tinh diem day du.
 *  - Crawler tu nhan dien (Googlebot, Bingbot, UptimeRobot...) khong bi tru diem cho 404/403 thuong (nhung van bi chan neu do duong dan
 *    nhay cam). User-Agent gia mao duoc, nen day chi la lop giam chan nham, khong phai lop bao mat.
 *  - Chay duoi khoa (flock) khong chan: 2 lan chay chong nhau thi lan sau thoat im lang.
 *
 * File nay vua la THU VIEN (admin-security.php nap de huy chan/xem danh sach) vua la CLI: chi chay main khi duoc goi truc tiep tu dong lenh.
 */

if (PHP_SAPI !== 'cli' && !defined('WPP_GUARD_AS_LIB')) {
    // Goi qua web (vd _admin/security-lib.php): chi nap ham, KHONG in gi. require tu admin-security.php da dinh nghia WPP_GUARD_AS_LIB.
    define('WPP_GUARD_AS_LIB', true);
}

const WPP_GUARD_WINDOW = 600;             // cua so cham diem truot (giay)
const WPP_GUARD_THRESHOLD = 10.0;         // diem trong cua so de bi chan
const WPP_GUARD_BAN_SECONDS = [3600, 86400, 604800];   // lan 1 / 2 / 3+
const WPP_GUARD_OFFENSE_MEMORY = 2592000; // nho tien an 30 ngay
const WPP_GUARD_LOGIN_OK_SECONDS = 86400; // IP dang nhap WP thanh cong duoc giam nhe 24 gio
const WPP_GUARD_MAX_BANS = 2000;          // ban-list.conf toi da (nginx geo van nhe, HUP nhanh)
const WPP_GUARD_MAX_STRIKE_KEYS = 5000;   // so IP dang duoc theo doi (bi quet tu nhieu nghin IP khong lam state phinh vo han)
const WPP_GUARD_MAX_READ = 2097152;       // doc toi da 2 MB log moi lan chay
const WPP_GUARD_EVENT_LINES_MAX = 2000;

/** Duong dan file trong thu muc chay. */
function wpp_guard_paths(string $rundir): array
{
    $rd = rtrim($rundir, '/');
    return [
        'log' => $rd . '/nginx-security.log',
        'state' => $rd . '/security-state.json',
        'list' => $rd . '/ban-list.conf',
        'reload' => $rd . '/ban-reload',
        'events' => $rd . '/security-events.log',
        'allow' => $rd . '/security-allow.txt',
        'lock' => $rd . '/security-guard.lock',
        'status' => $rd . '/security-status.json',
        'realip_missing' => $rd . '/realip-missing',
    ];
}

// ------------------------------------------------------------------------------------------------------------------
// IP
// ------------------------------------------------------------------------------------------------------------------

/** IP khong bao gio duoc chan: loopback, mang rieng, link-local, CGNAT, ULA, khong hop le. */
function wpp_guard_ip_is_exempt(string $ip): bool
{
    $bin = @inet_pton($ip);
    if ($bin === false) {
        return true;                                  // khong phai IP -> khong the ghi vao geo -> bo qua
    }
    if (strlen($bin) === 4) {
        $b = array_values(unpack('C4', $bin));
        if ($b[0] === 0 || $b[0] === 10 || $b[0] === 127 || $b[0] >= 224) return true;                   // 0/8, 10/8, loopback, multicast+
        if ($b[0] === 172 && $b[1] >= 16 && $b[1] <= 31) return true;                                      // 172.16/12
        if ($b[0] === 192 && $b[1] === 168) return true;                                                   // 192.168/16
        if ($b[0] === 169 && $b[1] === 254) return true;                                                   // link-local
        if ($b[0] === 100 && $b[1] >= 64 && $b[1] <= 127) return true;                                     // CGNAT 100.64/10 (Tailscale...)
        return false;
    }
    if (strlen($bin) === 16) {
        $b = array_values(unpack('C16', $bin));
        if ($bin === str_repeat("\0", 15) . "\1" || $bin === str_repeat("\0", 16)) return true;          // ::1, ::
        if (($b[0] & 0xFE) === 0xFC) return true;                                                          // fc00::/7 ULA
        if ($b[0] === 0xFE && ($b[1] & 0xC0) === 0x80) return true;                                       // fe80::/10
        if ($b[0] === 0xFF) return true;                                                                   // multicast
        // ::ffff:a.b.c.d (IPv4 nhung trong IPv6): xet nhu IPv4
        if (substr($bin, 0, 12) === str_repeat("\0", 10) . "\xff\xff") {
            return wpp_guard_ip_is_exempt(inet_ntop(substr($bin, 12)));
        }
        return false;
    }
    return true;
}

/** Khoa chan: IPv4 giu nguyen; IPv6 gom ve /64 (ke tan cong doi dia chi trong /64 cua ho). Tra '' neu khong hop le. */
function wpp_guard_ban_key(string $ip): string
{
    $bin = @inet_pton($ip);
    if ($bin === false) {
        return '';
    }
    if (strlen($bin) === 4) {
        return inet_ntop($bin);
    }
    if (substr($bin, 0, 12) === str_repeat("\0", 10) . "\xff\xff") {   // ::ffff:a.b.c.d -> a.b.c.d (neu khong se thanh ::/64 = chan nham ca ::1)
        return inet_ntop(substr($bin, 12));
    }
    $net = substr($bin, 0, 8) . str_repeat("\0", 8);
    return inet_ntop($net) . '/64';
}

/** $ip co nam trong danh sach cho phep (moi dong: IPv4, IPv4/CIDR, IPv6; '#' la chu thich) khong. */
function wpp_guard_in_allowlist(string $ip, array $entries): bool
{
    $ipBin = @inet_pton($ip);
    if ($ipBin === false) {
        return false;
    }
    foreach ($entries as $e) {
        $e = trim((string) $e);
        if ($e === '' || $e[0] === '#') continue;
        $bits = null;
        if (strpos($e, '/') !== false) {
            [$e, $bits] = explode('/', $e, 2);
            if (!ctype_digit($bits)) continue;
            $bits = (int) $bits;
        }
        $eBin = @inet_pton(trim($e));
        if ($eBin === false || strlen($eBin) !== strlen($ipBin)) continue;
        $max = strlen($eBin) * 8;
        if ($bits === null) $bits = $max;
        if ($bits < 0 || $bits > $max) continue;
        $full = intdiv($bits, 8);
        if (substr($eBin, 0, $full) !== substr($ipBin, 0, $full)) continue;
        $rem = $bits % 8;
        if ($rem === 0) return true;
        $mask = (0xFF << (8 - $rem)) & 0xFF;
        if ((ord($eBin[$full]) & $mask) === (ord($ipBin[$full]) & $mask)) return true;
    }
    return false;
}

/** Doi 1 muc ban-key sang dong hop le cho nginx geo, hoac null (khong bao gio ghi dong chua kiem tra). */
function wpp_guard_geo_line(string $key): ?string
{
    if (preg_match('/^([0-9a-f:.]+)(\/64)?$/i', $key, $m) !== 1) {
        return null;
    }
    $ip = $m[1];
    $suffix = $m[2] ?? '';
    $bin = @inet_pton($ip);
    if ($bin === false) {
        return null;
    }
    if (strlen($bin) === 4) {
        return $suffix === '' ? $ip . ' 1;' : null;                      // IPv4 chi ghi tung dia chi (khong CIDR)
    }
    return $suffix === '/64' ? $ip . '/64 1;' : null;                    // IPv6 chi ghi dang /64 (da gom boi wpp_guard_ban_key)
}

// ------------------------------------------------------------------------------------------------------------------
// Doc + cham diem 1 dong log
// ------------------------------------------------------------------------------------------------------------------

/** "<msec> <ip> <status> <method> "<uri>" "<ua>"" -> mang hoac null (dong hong bi bo qua, khong nem loi). */
function wpp_guard_parse_line(string $line): ?array
{
    if (preg_match('/^(\d{9,11})(?:\.\d+)? (\S+) (\d{3}) ([A-Za-z]{1,12}) "([^"]*)" "([^"]*)"\s*$/', $line, $m) !== 1) {
        return null;
    }
    return ['ts' => (int) $m[1], 'ip' => $m[2], 'status' => (int) $m[3], 'method' => strtoupper($m[4]), 'uri' => $m[5], 'ua' => $m[6]];
}

/** URI da giai ma (toi da 3 lop - ke tan cong ma hoa 2 lan de ne bo loc), chu thuong, cat toi 1000 ky tu. */
function wpp_guard_decode_uri(string $uri): string
{
    $u = substr($uri, 0, 1000);
    for ($i = 0; $i < 3; $i++) {
        $d = rawurldecode(str_replace('+', ' ', $u));
        if ($d === $u) break;
        $u = $d;
    }
    $u = preg_replace('/\x00|[\x01-\x08\x0b\x0c\x0e-\x1f]/', '', $u);
    return strtolower((string) $u);
}

/** Cac nhom mau "tan cong ro rang" - dung trong test de kiem tung nhom. */
function wpp_guard_patterns(): array
{
    return [
        // Tep nhay cam/ban sao luu/cau hinh de lai: nguoi that khong bao gio xin cac duong dan nay tren 1 site WordPress
        'tep-nhay-cam' => '~(?:^|/)\.(?:env|git|svn|hg|aws|ssh|htpasswd|htaccess|ds_store|bash_history|npmrc|dockerenv|docker|vscode|idea)(?:[/.?\s]|$)'
            . '|wp-config\.php(?:[\~.]|\.(?:bak|old|save|orig|swp|txt|zip))|wp-config\.(?:bak|old|txt|save|orig|swp|zip)|(?:^|/)(?:config|settings|database|db|dump|backup|site|www|wordpress)\.(?:sql|zip|tar|tar\.gz|tgz|rar|7z|bak|old)(?:\?|$)'
            . '|(?:^|/)(?:composer|package)(?:-lock)?\.json(?:\?|$)|(?:^|/)(?:docker-compose\.ya?ml|id_rsa|credentials|secrets?\.(?:json|ya?ml))~',
        // Cong cu quan tri/phan mem khac ma site WordPress nay khong co
        'cong-cu-la' => '~/(?:phpmyadmin|pma|myadmin|mysqladmin|dbadmin|sqladmin|adminer(?:\.php)?|webmail|cpanel|whm|plesk|phpinfo\.php|info\.php|test\.php)(?:[/.?]|$)'
            . '|/(?:cgi-bin|boaform|hnap1|actuator|solr|jenkins|manager/html|vendor/phpunit|_ignition|owa/|ecp/|autodiscover/|remote/login|dana-na|goform|setup\.cgi|\.well-known/security\.txt\.php)~',
        // Ten web-shell nhieu nguoi biet
        'web-shell' => '~(?:^|/)(?:shell|c99|r57|wso|b374k|alfa|indoxploit|webshell|backdoor|eval-stdin|wp-vcd|xleet|lock360|0x|cmd)\.php(?:\?|$)~',
        // Chuoi tan cong trong URI (duyet thu muc, SQLi, XSS, RCE, Log4Shell, wrapper PHP)
        'tiem-ma' => '~\.\./|\.\.\\\\|/etc/passwd|/proc/self|/windows/win\.ini|php://|data://|expect://|phar://|union(?:\s|/\*.*?\*/)+(?:all\s+)?select|information_schema|(?:sleep|benchmark)\s*\(\s*\d'
            . '|<script|javascript:|onerror\s*=|onload\s*=|\$\{jndi:|base64_decode|eval\s*\(|system\s*\(|passthru|shell_exec|/bin/(?:ba)?sh|cmd\.exe|allow_url_include|auto_prepend_file|(?:wget|curl)\s+https?:~',
        // Do phien ban plugin/theme qua readme/changelog (nginx tra 404 cho cac file nay)
        'do-phien-ban' => '~^/(?:readme\.html|license\.txt|wp-content/(?:plugins|themes)/[^/]+/(?:readme|changelog|license)\.(?:txt|md|html))(?:\?|$)~',
    ];
}

/** UA cong cu quet/tan cong tu dong ro rang. */
const WPP_GUARD_BAD_UA = '~(?:sqlmap|nikto|masscan|nmap|zgrab|acunetix|nessus|openvas|wpscan|dirbuster|gobuster|havij|netsparker|nuclei|feroxbuster|ffuf|wfuzz|hydra|metasploit|zmeu|jaeles|dirsearch|whatweb|arachni|skipfish|w3af)~i';
/** UA crawler/giam sat tu nhan dien: khong tru diem cho 404/403 thuong (UA gia duoc nen KHONG anh huong cac nhom tan cong ro). */
const WPP_GUARD_GOOD_UA = '~(?:googlebot|bingbot|duckduckbot|applebot|yandex(?:bot)?|baiduspider|facebookexternalhit|twitterbot|linkedinbot|slackbot|whatsapp|telegrambot|uptimerobot|pingdom|betteruptime|statuscake|cloudflare|site24x7)~i';

/**
 * Cham diem 1 su kien. Tra ve [diem(float), nhom(string)] hoac [0, '']. $loginOk = IP vua dang nhap WordPress thanh cong (giam nhe diem thuong).
 * Bang diem (so sanh voi nguong 10 trong 10 phut):
 *   tan cong ro (tiem-ma, tep-nhay-cam, cong-cu-la, web-shell, UA cong cu quet)  10  -> chan ngay
 *   do-phien-ban (readme/changelog plugin)                                         5   -> 2 lan la chan
 *   xmlrpc.php (da bi chan, van thu)                                               5
 *   POST wp-login.php that bai (200/429/503)                                       2   -> 5 lan/10 phut la chan
 *   .php khong ton tai (404)                                                       3
 *   403/405/429 thuong                                                             2
 *   404 thuong                                                                     1   (0 neu crawler tu nhan dien)
 *   4xx trong /wp-admin/ hoac /wp-json/ hoac wp-cron                               0.2 (trinh duyet chu site co the gap 403 khi het nonce)
 */
function wpp_guard_score(array $e, bool $loginOk = false): array
{
    $uri = (string) $e['uri'];
    $dec = wpp_guard_decode_uri($uri);
    $path = strtok($dec, '?');
    $status = (int) $e['status'];
    $method = (string) $e['method'];
    $ua = (string) $e['ua'];

    if (preg_match(WPP_GUARD_BAD_UA, $ua) === 1) {
        return [10.0, 'ua-cong-cu-quet'];
    }
    foreach (wpp_guard_patterns() as $name => $rx) {
        if ($name === 'do-phien-ban') continue;
        if (@preg_match($rx, $dec) === 1) {
            return [10.0, $name];
        }
    }
    if (@preg_match(wpp_guard_patterns()['do-phien-ban'], $dec) === 1 && $status >= 400) {
        return [5.0, 'do-phien-ban'];
    }
    if (strpos($path, '/xmlrpc.php') === 0) {
        return [5.0, 'xmlrpc'];
    }
    if ($method === 'POST' && strpos($path, '/wp-login.php') === 0) {
        if ($status === 302 || $status === 301) {
            return [0.0, 'dang-nhap-thanh-cong'];
        }
        return [2.0, 'do-mat-khau-wp'];
    }
    if ($status < 400) {
        return [0.0, ''];
    }
    $good = preg_match(WPP_GUARD_GOOD_UA, $ua) === 1;
    $factor = $loginOk ? 0.2 : 1.0;
    if (strpos($path, '/wp-admin/') === 0 || strpos($path, '/wp-json/') === 0 || strpos($path, '/wp-cron.php') === 0) {
        return [0.2 * $factor, 'loi-4xx-wp'];
    }
    if ($status === 404 && preg_match('~\.(?:php[0-9]?|phtml|phar|asp|aspx|jsp|cgi)$~', $path) === 1) {
        return [$good ? 0.0 : 3.0 * $factor, 'php-khong-ton-tai'];
    }
    if ($status === 403 || $status === 405 || $status === 429) {
        return [$good ? 0.0 : 2.0 * $factor, 'bi-tu-choi-' . $status];
    }
    if ($status === 404) {
        return [$good ? 0.0 : 1.0 * $factor, '404'];
    }
    return [0.0, ''];
}

// ------------------------------------------------------------------------------------------------------------------
// State
// ------------------------------------------------------------------------------------------------------------------

function wpp_guard_state_default(): array
{
    return ['v' => 1, 'offset' => 0, 'sig' => '', 'strikes' => [], 'bans' => [], 'offenses' => [], 'login_ok' => [],
            'totals' => ['lines' => 0, 'bans' => 0, 'runs' => 0]];
}

function wpp_guard_state_load(string $file): array
{
    $raw = is_file($file) ? @file_get_contents($file) : false;
    $d = $raw !== false && $raw !== '' ? json_decode($raw, true) : null;
    if (!is_array($d) || ($d['v'] ?? 0) !== 1) {
        return wpp_guard_state_default();
    }
    return array_replace_recursive(wpp_guard_state_default(), $d);
}

/** Ghi nguyen tu (tep tam + doi ten): doc o giua chung khong bao gio thay file cut cut. */
function wpp_guard_atomic_write(string $file, string $content): bool
{
    $tmp = $file . '.tmp.' . getmypid();
    if (@file_put_contents($tmp, $content) === false) {
        @unlink($tmp);
        return false;
    }
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

function wpp_guard_ban_seconds(int $offenseCount): int
{
    $i = max(0, min($offenseCount, count(WPP_GUARD_BAN_SECONDS)) - 1);
    return WPP_GUARD_BAN_SECONDS[$i];
}

function wpp_guard_fmt_duration(int $sec): string
{
    if ($sec >= 86400) return intdiv($sec, 86400) . ' ngay';
    if ($sec >= 3600) return intdiv($sec, 3600) . ' gio';
    return max(1, intdiv($sec, 60)) . ' phut';
}

/** Noi dung ban-list.conf tu cac muc con hieu luc (da loc cu phap). Tra [noi_dung, so_dong]. */
function wpp_guard_render_list(array $bans, int $now): array
{
    $lines = [];
    foreach ($bans as $key => $b) {
        if ((int) ($b['until'] ?? 0) <= $now) continue;
        $l = wpp_guard_geo_line((string) $key);
        if ($l !== null) $lines[] = $l;
    }
    sort($lines, SORT_STRING);
    $lines = array_slice($lines, 0, WPP_GUARD_MAX_BANS);
    $head = "# Tu dong sinh boi security-guard.php - KHONG sua tay (se bi ghi de). Huy chan: _admin/security.php\n";
    return [$head . ($lines ? implode("\n", $lines) . "\n" : ''), count($lines)];
}

/** Tao/viet lai ban-list.conf neu noi dung doi; neu doi thi tao co ban-reload (start-lamp.sh gui HUP cho nginx). Tra true neu co doi. */
function wpp_guard_write_list(array $paths, array $bans, int $now): bool
{
    [$content] = wpp_guard_render_list($bans, $now);
    $old = is_file($paths['list']) ? @file_get_contents($paths['list']) : false;
    if ($old === $content) {
        return false;
    }
    if (!wpp_guard_atomic_write($paths['list'], $content)) {
        return false;
    }
    @file_put_contents($paths['reload'], (string) $now);
    return true;
}

/**
 * Lam sach file ban-list.conf: chi giu dong hop le. Goi LUC KHOI DONG (truoc khi bat nginx) vi 1 dong sai cu phap lam nginx khong chay.
 * Tra so dong da loai bo. File khong ton tai -> tao file rong (geo include bat buoc file ton tai).
 */
function wpp_guard_sanitize_file(string $file): int
{
    $keep = [];
    $dropped = 0;
    $orig = is_file($file) ? (string) @file_get_contents($file) : '';
    foreach (preg_split('/\R/', $orig) as $line) {
        $t = trim($line);
        if ($t === '') continue;
        if ($t[0] === '#') { $keep[] = $t; continue; }
        if (preg_match('/^([0-9a-f:.]+(?:\/64)?) 1;$/i', $t, $m) === 1 && wpp_guard_geo_line($m[1]) === $m[1] . ' 1;'
            && !wpp_guard_ip_is_exempt(explode('/', $m[1])[0])) {
            $keep[] = $t;
        } else {
            $dropped++;
        }
    }
    $new = $keep ? implode("\n", $keep) . "\n" : '';
    if (!is_file($file) || $new !== $orig) {
        wpp_guard_atomic_write($file, $new);
    }
    return $dropped;
}

// ------------------------------------------------------------------------------------------------------------------
// Vong chinh
// ------------------------------------------------------------------------------------------------------------------

/**
 * 1 lan chay: doc log moi, cham diem, cap nhat chan. $now de test. Tra tom tat:
 *   ['lines'=>so dong da doc, 'new_bans'=>[key=>[...]], 'active'=>so chan con hieu luc, 'changed'=>bool, 'skipped'=>bool (bi khoa chay chong)]
 */
function wpp_guard_run(string $rundir, ?int $now = null): array
{
    $now = $now ?? time();
    $p = wpp_guard_paths($rundir);
    $lockFh = @fopen($p['lock'], 'c');
    if (!$lockFh || !flock($lockFh, LOCK_EX | LOCK_NB)) {
        if ($lockFh) fclose($lockFh);
        return ['lines' => 0, 'new_bans' => [], 'active' => 0, 'changed' => false, 'skipped' => true];
    }
    try {
        $st = wpp_guard_state_load($p['state']);
        $allow = is_file($p['allow']) ? (preg_split('/\R/', (string) @file_get_contents($p['allow'], false, null, 0, 65536)) ?: []) : [];
        $newBans = [];
        $lines = 0;

        // ---- doc phan log moi ----
        clearstatcache(true, $p['log']);
        $size = is_file($p['log']) ? (int) @filesize($p['log']) : 0;
        $offset = (int) $st['offset'];
        // Nhan dien log da bi cat/xoay vong: (1) nho hon vi tri da doc; (2) DONG DAU DOI (start-lamp.sh cat log o 5MB bang "> file"; neu log moc
        // lai nhanh qua vi tri cu trong luc flood thi chi kiem tra kich thuoc se bo sot phan dau - dong dau co timestamp nen khong bao gio trung).
        $sig = '';
        if ($size > 0 && ($fs = @fopen($p['log'], 'r'))) {
            $first = (string) fgets($fs, 4096);
            fclose($fs);
            if (substr($first, -1) === "\n") {
                $sig = md5($first);
            }
        }
        if ($size < $offset || ($sig !== '' && ($st['sig'] ?? '') !== '' && $st['sig'] !== $sig)) {
            $offset = 0;
        }
        $st['sig'] = $sig !== '' ? $sig : (($size < (int) $st['offset']) ? '' : ($st['sig'] ?? ''));
        $chunk = '';
        if ($size > $offset) {
            $start = $offset;
            if ($size - $start > WPP_GUARD_MAX_READ) {
                $start = $size - WPP_GUARD_MAX_READ;      // bi flood: chi xet 2MB cuoi, bo phan cu hon (da du de thay ke tan cong)
            }
            $data = '';
            $fh = @fopen($p['log'], 'r');
            if ($fh) {
                fseek($fh, $start);
                $data = (string) stream_get_contents($fh, $size - $start);
                fclose($fh);
            }
            $skip = 0;
            if ($start !== $offset && $data !== '') {     // bat dau giua dong: bo dong dau bi cat
                $nl = strpos($data, "\n");
                if ($nl === false) {
                    $data = '';
                } else {
                    $skip = $nl + 1;
                    $data = substr($data, $skip);
                }
            }
            $lastNl = strrpos($data, "\n");
            if ($lastNl === false) {
                $st['offset'] = $start;                   // chua co dong tron ven (nginx dang ghi do): doc lai tu day lan sau
            } else {
                $chunk = substr($data, 0, $lastNl + 1);
                $st['offset'] = $start + $skip + $lastNl + 1;
            }
        } else {
            $st['offset'] = $size;
        }

        // ---- cham diem ----
        $cut = $now - WPP_GUARD_WINDOW;
        foreach ($chunk === '' ? [] : explode("\n", $chunk) as $raw) {
            if ($raw === '') continue;
            $e = wpp_guard_parse_line($raw);
            if ($e === null) continue;
            $lines++;
            $ip = $e['ip'];
            if (wpp_guard_ip_is_exempt($ip) || wpp_guard_in_allowlist($ip, $allow)) continue;
            $key = wpp_guard_ban_key($ip);
            if ($key === '') continue;
            $ts = min($e['ts'] > 0 ? $e['ts'] : $now, $now);
            $loginOk = isset($st['login_ok'][$key]) && ($now - (int) $st['login_ok'][$key]) < WPP_GUARD_LOGIN_OK_SECONDS;
            [$pts, $kind] = wpp_guard_score($e, $loginOk);
            if ($kind === 'dang-nhap-thanh-cong') {
                $st['login_ok'][$key] = $ts;
                continue;
            }
            if ($pts <= 0) continue;
            if (isset($st['bans'][$key]) && (int) $st['bans'][$key]['until'] > $now) continue;    // dang bi chan roi
            $st['strikes'][$key][] = [$ts, $pts, $kind];
        }

        // ---- quyet dinh chan ----
        foreach ($st['strikes'] as $key => $rows) {
            $rows = array_values(array_filter($rows, fn($r) => (int) $r[0] >= $cut));
            if (!$rows) {
                unset($st['strikes'][$key]);
                continue;
            }
            $st['strikes'][$key] = $rows;
            $sum = 0.0;
            $kinds = [];
            foreach ($rows as $r) {
                $sum += (float) $r[1];
                $kinds[$r[2]] = ($kinds[$r[2]] ?? 0) + 1;
            }
            if ($sum < WPP_GUARD_THRESHOLD) continue;
            $off = $st['offenses'][$key] ?? ['n' => 0, 'last' => 0];
            $n = ((int) $off['last'] > 0 && $now - (int) $off['last'] < WPP_GUARD_OFFENSE_MEMORY ? (int) $off['n'] : 0) + 1;
            $dur = wpp_guard_ban_seconds($n);
            arsort($kinds);
            $top = array_slice(array_keys($kinds), 0, 3);
            $info = ['at' => $now, 'until' => $now + $dur, 'n' => $n, 'pts' => round($sum, 1), 'reason' => implode(',', $top), 'hits' => count($rows)];
            $st['bans'][$key] = $info;
            $st['offenses'][$key] = ['n' => $n, 'last' => $now];
            unset($st['strikes'][$key]);
            $newBans[$key] = $info;
            $st['totals']['bans'] = (int) $st['totals']['bans'] + 1;
            wpp_guard_event($p['events'], $now, $key, 'IP bi tu dong chan ' . wpp_guard_fmt_duration($dur) . ' (lan thu ' . $n . ', ' . round($sum, 1)
                . ' diem/' . count($rows) . ' request trong ' . intdiv(WPP_GUARD_WINDOW, 60) . ' phut: ' . implode(', ', $top) . ')');
        }

        // ---- don dep ----
        foreach ($st['bans'] as $key => $b) {
            if ((int) $b['until'] <= $now) unset($st['bans'][$key]);
        }
        if (count($st['bans']) > WPP_GUARD_MAX_BANS) {
            uasort($st['bans'], fn($a, $b) => (int) $b['until'] <=> (int) $a['until']);
            $st['bans'] = array_slice($st['bans'], 0, WPP_GUARD_MAX_BANS, true);
        }
        foreach ($st['offenses'] as $key => $o) {
            if ($now - (int) $o['last'] > WPP_GUARD_OFFENSE_MEMORY) unset($st['offenses'][$key]);
        }
        foreach ($st['login_ok'] as $key => $t) {
            if ($now - (int) $t > WPP_GUARD_LOGIN_OK_SECONDS) unset($st['login_ok'][$key]);
        }
        if (count($st['strikes']) > WPP_GUARD_MAX_STRIKE_KEYS) {
            uasort($st['strikes'], fn($a, $b) => (int) end($b)[0] <=> (int) end($a)[0]);
            $st['strikes'] = array_slice($st['strikes'], 0, WPP_GUARD_MAX_STRIKE_KEYS, true);
        }
        $st['totals']['lines'] = (int) $st['totals']['lines'] + $lines;
        $st['totals']['runs'] = (int) $st['totals']['runs'] + 1;

        $changed = wpp_guard_write_list($p, $st['bans'], $now);
        wpp_guard_atomic_write($p['state'], json_encode($st));
        wpp_guard_atomic_write($p['status'], json_encode([
            'at' => $now, 'active_bans' => count($st['bans']), 'tracked' => count($st['strikes']), 'lines_total' => (int) $st['totals']['lines'],
            'bans_total' => (int) $st['totals']['bans'], 'realip_missing' => is_file($p['realip_missing']),
        ]));
        return ['lines' => $lines, 'new_bans' => $newBans, 'active' => count($st['bans']), 'changed' => $changed, 'skipped' => false];
    } finally {
        flock($lockFh, LOCK_UN);
        fclose($lockFh);
    }
}

/** Ghi 1 su kien bao mat (cung dinh dang admin-audit.log: "YYYY-MM-DD HH:MM:SS ip=<ip> <su kien>") va cat con 2000 dong. */
function wpp_guard_event(string $file, int $now, string $ipOrKey, string $event): void
{
    $line = date('Y-m-d H:i:s', $now) . ' ip=' . preg_replace('/[^0-9a-fA-F:.\/]/', '?', $ipOrKey) . ' ' . preg_replace('/[\r\n]+/', ' ', $event) . "\n";
    @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    if (mt_rand(1, 40) === 1 && is_file($file) && @filesize($file) > 262144) {
        $all = @file($file, FILE_IGNORE_NEW_LINES) ?: [];
        if (count($all) > WPP_GUARD_EVENT_LINES_MAX) {
            wpp_guard_atomic_write($file, implode("\n", array_slice($all, -WPP_GUARD_EVENT_LINES_MAX)) . "\n");
        }
    }
}

/** Huy chan thu cong (UI): go khoi state + ban-list + dat co reload. Tra true neu co muc bi go. Dung CHUNG khoa voi wpp_guard_run. */
function wpp_guard_unban(string $rundir, string $key, ?int $now = null): bool
{
    $now = $now ?? time();
    $p = wpp_guard_paths($rundir);
    $lockFh = @fopen($p['lock'], 'c');
    if (!$lockFh || !flock($lockFh, LOCK_EX)) {
        if ($lockFh) fclose($lockFh);
        return false;
    }
    try {
        $st = wpp_guard_state_load($p['state']);
        $hit = isset($st['bans'][$key]);
        unset($st['bans'][$key], $st['offenses'][$key], $st['strikes'][$key]);
        wpp_guard_write_list($p, $st['bans'], $now);
        wpp_guard_atomic_write($p['state'], json_encode($st));
        return $hit;
    } finally {
        flock($lockFh, LOCK_UN);
        fclose($lockFh);
    }
}

/** Danh sach chan dang hieu luc (cho UI): [key => info]. */
function wpp_guard_active_bans(string $rundir, ?int $now = null): array
{
    $now = $now ?? time();
    $st = wpp_guard_state_load(wpp_guard_paths($rundir)['state']);
    $out = [];
    foreach ($st['bans'] as $k => $b) {
        if ((int) $b['until'] > $now) $out[$k] = $b;
    }
    uasort($out, fn($a, $b) => (int) $b['at'] <=> (int) $a['at']);
    return $out;
}

// ------------------------------------------------------------------------------------------------------------------
// CLI: php security-guard.php <rundir> [sanitize]
// ------------------------------------------------------------------------------------------------------------------
if (PHP_SAPI === 'cli' && !defined('WPP_GUARD_AS_LIB') && isset($_SERVER['argv'][0]) && realpath($_SERVER['argv'][0]) === __FILE__) {
    $rd = $_SERVER['argv'][1] ?? '';
    $mode = $_SERVER['argv'][2] ?? 'run';
    if ($rd === '' || !is_dir($rd)) {
        fwrite(STDERR, "dung: php security-guard.php <thu_muc_lamp-run> [run|sanitize]\n");
        exit(2);
    }
    if ($mode === 'sanitize') {
        $dropped = wpp_guard_sanitize_file(wpp_guard_paths($rd)['list']);
        echo "sanitize: loai bo $dropped dong khong hop le\n";
        exit(0);
    }
    $r = wpp_guard_run($rd);
    if (!$r['skipped'] && $r['new_bans']) {
        echo 'chan moi: ' . implode(', ', array_keys($r['new_bans'])) . "\n";
    }
    exit(0);
}
