<?php
// Che do an toan - de xuat DeepSeek muc P2 (xem HANDOFF.md muc 10):
// "User cai plugin loi -> WordPress trang trang, khong vao duoc wp-admin.
// Hosting tra phi co 'recovery mode' (qua SSH). Mobile can: nut 'Vo hieu
// plugin' trong app -> rename wp-content/plugins/ -> plugins.disabled/"
//
// Ky thuat DUNG: doi ten thu muc wp-content/plugins - day la cach CHUAN,
// an toan, nhieu nguoi dung WordPress van lam thu cong qua FTP khi site
// loi (khong dung shell_exec/wp-cli vi du an nay KHONG bundle WP-CLI, xem
// backlog muc A9) - WordPress tu phat hien thu muc plugin "bien mat" va
// COI NHU TAT CA PLUGIN DA TAT, KHONG CAN dung toi database (an toan hon
// nhieu so voi tu sua bang wp_options).
require __DIR__ . '/auth.php';

$docroot = dirname(__DIR__);
$wpConfig = $docroot . '/wp-config.php';
$pluginsDir = $docroot . '/wp-content/plugins';
$isWordPress = file_exists($wpConfig);

$message = '';
$error = '';

/** Tim tat ca thu muc "plugins.disabled-*" hien co (binh thuong chi co
 * toi da 1, nhung liet ke het de khong am tham bo sot neu vi ly do gi do
 * co nhieu hon 1 - vd bam "Vo hieu" nhieu lan ma khong khoi phuc giua
 * cac lan). */
function wp_pocket_find_disabled_dirs(string $docroot): array
{
    $pattern = $docroot . '/wp-content/plugins.disabled-*';
    $dirs = glob($pattern, GLOB_ONLYDIR);
    return $dirs === false ? [] : $dirs;
}

$disabledDirs = $isWordPress ? wp_pocket_find_disabled_dirs($docroot) : [];
$currentlyDisabled = count($disabledDirs) > 0;

if ($isWordPress && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (!wp_pocket_csrf_verify()) {
        $error = 'Token bao mat (CSRF) khong hop le hoac da het han - tai lai trang va thu lai.';
    } elseif ($action === 'disable_all' && !$currentlyDisabled) {
        register_shutdown_function('wp_pocket_bump_object_cache_epoch');   // 1bd (xem HANDOFF.md muc 1bd)
        if (!is_dir($pluginsDir)) {
            $error = 'Khong tim thay thu muc wp-content/plugins - co the site chua co plugin nao.';
        } else {
            $newName = $pluginsDir . '.disabled-' . date('Ymd-His');
            if (@rename($pluginsDir, $newName) && @mkdir($pluginsDir, 0755)) {
                $message = 'Da VO HIEU toan bo plugin. Website + wp-admin gio chi chay theme + WordPress loi, khong con plugin nao can thiep - vao thu wp-admin lai xem da het loi chua. Plugin CHUA bi xoa, chi doi ten, bam "Khoi phuc" o duoi de bat lai khi da tim ra plugin nao gay loi (qua doi ten tung thu muc con trong do bang File Manager, thu bat lai tung cai 1).';
                $disabledDirs = wp_pocket_find_disabled_dirs($docroot);
                $currentlyDisabled = true;
            } else {
                $error = 'Khong doi ten duoc thu muc plugins - kiem tra quyen ghi.';
            }
        }
    } elseif ($action === 'restore' && $currentlyDisabled) {
        register_shutdown_function('wp_pocket_bump_object_cache_epoch');   // 1bd (xem HANDOFF.md muc 1bd)
        // is_string TRUOC basename: restore_dir[]=x (mang) lam basename() nem TypeError
        // tren PHP 8 (Fatal error) - xem scripts/tests/admin-security-test.py.
        $targetRaw = $_POST['restore_dir'] ?? '';
        $target = is_string($targetRaw) ? basename($targetRaw) : ''; // chi lay ten thu muc, chan path traversal
        $fullTarget = $docroot . '/wp-content/' . $target;
        if (!in_array($fullTarget, $disabledDirs, true)) {
            $error = 'Thu muc khong hop le.';
        } elseif (is_dir($pluginsDir) && count(scandir($pluginsDir)) > 2) {
            // scandir luon co it nhat "." va ".." (2 phan tu) - >2 nghia la
            // co file/thu muc THAT ben trong (vd nguoi dung da tu cai
            // plugin moi sau khi bat che do an toan) - KHONG xoa mat, bat
            // nguoi dung tu xu ly qua File Manager de tranh mat du lieu.
            $error = 'Thu muc "plugins" hien tai KHONG RONG (co the ban da cai plugin moi sau khi bat che do an toan) - de an toan, KHONG tu dong khoi phuc. Dung File Manager de tu doi ten/gop thu cong.';
        } else {
            if ((!is_dir($pluginsDir) || @rmdir($pluginsDir)) && @rename($fullTarget, $pluginsDir)) {
                $message = 'Da KHOI PHUC lai toan bo plugin nhu truoc khi bat che do an toan.';
                $disabledDirs = wp_pocket_find_disabled_dirs($docroot);
                $currentlyDisabled = count($disabledDirs) > 0;
            } else {
                $error = 'Khong khoi phuc duoc - kiem tra quyen ghi.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Che do an toan</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:560px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.status{padding:14px 16px;border-radius:10px;margin:16px 0;font-weight:600}
.status.on{background:#fdecea;color:#a11a0e;border:1px solid #f3b8b0}
.status.off{background:#e9f7ef;color:#1d7a3d;border:1px solid #bfe6cc}
.msg{padding:10px 14px;border-radius:8px;margin:12px 0;font-size:14px;line-height:1.5}
.msg.ok{background:#e9f7ef;color:#1d7a3d}
.msg.err{background:#fdecea;color:#a11a0e}
.note{background:#fff8e1;color:#7a5b00;padding:12px 14px;border-radius:8px;font-size:14px;margin:16px 0;line-height:1.5}
button{width:100%;padding:14px;border:0;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;color:#fff;margin-top:8px}
button.disable{background:#c0392b}
button.restore{background:#1d7a3d}
.dirname{font-family:monospace;font-size:12px;color:#666;word-break:break-all}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Che do an toan</h1>

<?php if (!$isWordPress): ?>
<div class="note">Khong tim thay wp-config.php - tinh nang nay chi ap dung cho site WordPress.</div>
<?php else: ?>

<p style="color:#666;font-size:14px;line-height:1.5">Dung khi 1 plugin nao do lam website hoac wp-admin bi trang/loi khong vao duoc. Vo hieu se tam TAT HET plugin (doi ten thu muc, KHONG xoa) de ban vao lai duoc wp-admin va tu tim plugin gay loi.</p>

<div class="status <?= $currentlyDisabled ? 'on' : 'off' ?>">
    Trang thai: <?= $currentlyDisabled ? 'DANG O CHE DO AN TOAN (plugin dang bi tat)' : 'Binh thuong (plugin dang chay nhu thuong le)' ?>
</div>

<?php if ($message !== ''): ?>
<div class="msg ok"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>
<?php if ($error !== ''): ?>
<div class="msg err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<?php if (!$currentlyDisabled): ?>
<form method="post" onsubmit="return confirm('Tat het plugin ngay bay gio? Website se chay khong co plugin nao cho toi khi ban bam Khoi phuc.');">
    <?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="disable_all">
    <button type="submit" class="disable">Vo hieu toan bo plugin ngay</button>
</form>
<?php else: ?>
<?php foreach ($disabledDirs as $dir): ?>
<form method="post" style="margin-top:16px">
    <?= wp_pocket_csrf_field() ?>
    <input type="hidden" name="action" value="restore">
    <input type="hidden" name="restore_dir" value="<?= htmlspecialchars(basename($dir), ENT_QUOTES, 'UTF-8') ?>">
    <p class="dirname">wp-content/<?= htmlspecialchars(basename($dir), ENT_QUOTES, 'UTF-8') ?></p>
    <button type="submit" class="restore">Khoi phuc lai plugin nay</button>
</form>
<?php endforeach; ?>
<div class="note">Muon bat lai TUNG plugin rieng le de tim ra plugin nao gay loi? Dung File Manager, vao thu muc <span class="dirname">wp-content/<?= htmlspecialchars(basename($disabledDirs[0] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>, doi ten TUNG thu muc con (moi thu muc con la 1 plugin) sang <span class="dirname">wp-content/plugins/</span>, thu 1 cai xem site co loi lai khong, roi moi thu cai tiep theo.</div>
<?php endif; ?>

<?php endif; ?>
</body>
</html>
