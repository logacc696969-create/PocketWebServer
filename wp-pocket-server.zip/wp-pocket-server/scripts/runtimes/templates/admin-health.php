<?php
// Suc khoe site + trang thai WP-Cron - HANDOFF.md muc 1bk (PDF 2: C9 "Site health", I8 "Scheduled posts verification", Q12 "Low storage",
// R15/R17 "memory_limit / upload size", O1 "3 gioi han upload phai khop"). CHI DOC: khong co POST/hanh dong nao nen khong co
// be mat CSRF; khong ghi gi vao DB/file. Mot muc khong doc duoc thi hien "khong ro" chu khong lam hong ca trang.
//
// Doc DB bang mysqli qua unix socket (MariaDB chay --skip-networking), tai khoan lay tu wp-config.php cua site (khong hardcode).
// Khong cham DB khi MariaDB dang NGU (Auto-Sleep, file lamp-run/mariadb-asleep) - ket noi se danh thuc/treo vo ich.
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$rundir = $appHome !== '' ? $appHome . '/lamp-run' : '';
$docroot = $appHome !== '' ? $appHome . '/www' : '';

function esc($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

/** "128M" / "1G" / "-1" -> so byte; -1 = khong gioi han (PHP_INT_MAX). */
function wp_pocket_health_bytes($v): int
{
    $v = trim((string) $v);
    if ($v === '' || $v === '-1') {
        return PHP_INT_MAX;
    }
    $n = (float) $v;
    $u = strtolower(substr($v, -1));
    if ($u === 'g') {
        $n *= 1073741824;
    } elseif ($u === 'm') {
        $n *= 1048576;
    } elseif ($u === 'k') {
        $n *= 1024;
    }
    return (int) $n;
}

function wp_pocket_health_fmt_bytes($b): string
{
    $b = (float) $b;
    if ($b >= 1073741824) {
        return round($b / 1073741824, 1) . ' GB';
    }
    if ($b >= 1048576) {
        return round($b / 1048576, 1) . ' MB';
    }
    return round($b / 1024, 1) . ' KB';
}

/** Doc toi da $max byte dau cua file; chuoi rong neu khong doc duoc. */
function wp_pocket_health_read(string $path, int $max = 65536): string
{
    if ($path === '' || !is_file($path) || !is_readable($path)) {
        return '';
    }
    $s = @file_get_contents($path, false, null, 0, $max);
    return is_string($s) ? $s : '';
}

/** post_date_gmt ("Y-m-d H:i:s", UTC) -> epoch; false neu rong/"0000-..."/sai dinh dang (strtotime(' UTC') se tra gio hien tai, sai). */
function wp_pocket_health_gmt($s)
{
    $s = trim((string) $s);
    if (!preg_match('/^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$/', $s)) {
        return false;
    }
    return strtotime($s . ' UTC');
}

/** "sau 5 phut" / "tre 12 phut" tu so giay chenh lech (duong = tuong lai). */
function wp_pocket_health_rel(int $delta): string
{
    $abs = abs($delta);
    if ($abs < 90) {
        $txt = $abs . ' giay';
    } elseif ($abs < 5400) {
        $txt = round($abs / 60) . ' phut';
    } elseif ($abs < 172800) {
        $txt = round($abs / 3600, 1) . ' gio';
    } else {
        $txt = round($abs / 86400) . ' ngay';
    }
    return $delta >= 0 ? 'sau ' . $txt : 'tre ' . $txt;
}

function wp_pocket_health_db($sock, $user, $pass, $name)
{
    if (!function_exists('mysqli_init') || !file_exists($sock)) {
        return null;
    }
    try {
        mysqli_report(MYSQLI_REPORT_OFF);
        $link = mysqli_init();
        if (!$link) {
            return null;
        }
        mysqli_options($link, MYSQLI_OPT_CONNECT_TIMEOUT, 3);
        if (!@mysqli_real_connect($link, 'localhost', $user, $pass, $name, 0, $sock)) {
            return null;
        }
        @mysqli_set_charset($link, 'utf8mb4');
        return $link;
    } catch (Throwable $e) {
        return null;
    }
}

function wp_pocket_health_rows($db, string $sql): array
{
    $out = [];
    try {
        $res = @mysqli_query($db, $sql);
        if ($res) {
            while (count($out) < 200) {
                $r = mysqli_fetch_assoc($res);
                if (!is_array($r)) {
                    break;
                }
                $out[] = $r;
            }
            mysqli_free_result($res);
        }
    } catch (Throwable $e) {
        return [];
    }
    return $out;
}

/** @var array<int,array{0:string,1:string,2:string}> [muc, trang thai ok|warn|bad|info, noi dung] */
/**
 * "Diem suc khoe" gop 0-100 (HANDOFF.md muc 1br, PDF 2 H4): moi muc "bad" tru 20, moi "warn" tru 6, san 0. Muc "ok"/"info" khong tru.
 * Xep loai: >= 90 tot, >= 70 can chu y, con lai kem. Chi la tong hop cac muc ben duoi de nhin nhanh - khong thay cho doc tung muc.
 * @return array{0:int,1:string} [diem, nhan]
 */
function wp_pocket_health_score(array $checks): array
{
    $score = 100;
    foreach ($checks as $c) {
        $score -= ($c[1] ?? '') === 'bad' ? 20 : (($c[1] ?? '') === 'warn' ? 6 : 0);
    }
    $score = max(0, $score);
    return [$score, $score >= 90 ? 'Tot' : ($score >= 70 ? 'Can chu y' : 'Kem')];
}

$checks = [];
function wp_pocket_health_add(array &$checks, string $label, string $state, string $text): void
{
    $checks[] = [$label, $state, $text];
}

$now = time();

// ---------- PHP + gioi han ----------
wp_pocket_health_add($checks, 'PHP', 'info', PHP_VERSION . ' (' . PHP_SAPI . ')');

$mem = wp_pocket_health_bytes(ini_get('memory_limit'));
if ($mem === PHP_INT_MAX) {
    wp_pocket_health_add($checks, 'memory_limit', 'info', 'khong gioi han');
} elseif ($mem < 64 * 1048576) {
    wp_pocket_health_add($checks, 'memory_limit', 'warn', (string) ini_get('memory_limit') . ' - thap, WordPress + plugin co the het bo nho (khuyen nghi tu 128M).');
} elseif ($mem < 128 * 1048576) {
    wp_pocket_health_add($checks, 'memory_limit', 'info', (string) ini_get('memory_limit') . ' - du cho site nho; WooCommerce/Elementor thuong can 256M tro len.');
} else {
    wp_pocket_health_add($checks, 'memory_limit', 'ok', (string) ini_get('memory_limit'));
}

$upload = wp_pocket_health_bytes(ini_get('upload_max_filesize'));
$post = wp_pocket_health_bytes(ini_get('post_max_size'));
$nginxMax = null;
if (preg_match('/client_max_body_size\s+(\d+)\s*([kKmMgG]?)\s*;/', wp_pocket_health_read($rundir . '/nginx.conf'), $m)) {
    $nginxMax = wp_pocket_health_bytes($m[1] . $m[2]);
}
$limitText = 'PHP upload_max_filesize ' . ini_get('upload_max_filesize') . ', post_max_size ' . ini_get('post_max_size')
    . ($nginxMax !== null ? ', nginx client_max_body_size ' . wp_pocket_health_fmt_bytes($nginxMax) : '');
if ($post !== PHP_INT_MAX && $upload !== PHP_INT_MAX && $post < $upload) {
    wp_pocket_health_add($checks, 'Gioi han upload', 'warn', $limitText . ' - post_max_size nho hon upload_max_filesize: tep lon se tai len that bai du PHP cho phep.');
} elseif ($nginxMax !== null && $upload !== PHP_INT_MAX && $nginxMax < $upload) {
    wp_pocket_health_add($checks, 'Gioi han upload', 'warn', $limitText . ' - nginx chan o ' . wp_pocket_health_fmt_bytes($nginxMax) . ' truoc khi PHP thay tep (tep lon hon se bao loi 413).');
} else {
    wp_pocket_health_add($checks, 'Gioi han upload', 'ok', $limitText . ' (3 tang khop nhau)');
}

$maxExec = (int) ini_get('max_execution_time');
wp_pocket_health_add($checks, 'max_execution_time', $maxExec !== 0 && $maxExec < 30 ? 'warn' : 'info', $maxExec === 0 ? 'khong gioi han' : $maxExec . ' giay');

$extNeed = ['mysqli' => 'ket noi MariaDB', 'mbstring' => 'chu da ngon ngu', 'curl' => 'goi HTTP (cap nhat, SMTP API)', 'xml' => 'RSS/XML', 'zip' => 'giai nen plugin/theme', 'gd' => 'anh thu nho'];
$extMissing = [];
foreach ($extNeed as $ext => $why) {
    if (!extension_loaded($ext)) {
        $extMissing[] = $ext . ' (' . $why . ')';
    }
}
$liteMode = $rundir !== '' && file_exists($rundir . '/lite-mode');   // cung marker voi _admin/index.php
if ($extMissing) {
    wp_pocket_health_add($checks, 'Extension PHP', 'warn', 'thieu: ' . implode(', ', $extMissing) . ($liteMode ? ' (che do Lite co the khong nap mysqli - binh thuong)' : ''));
} else {
    wp_pocket_health_add($checks, 'Extension PHP', 'ok', 'du: ' . implode(', ', array_keys($extNeed)));
}
wp_pocket_health_add($checks, 'Cache', 'info', 'OPcache ' . (extension_loaded('Zend OPcache') ? 'co' : 'khong') . ', APCu ' . (extension_loaded('apcu') ? 'co' : 'khong'));

// ---------- Dung luong ----------
$free = $appHome !== '' ? @disk_free_space($appHome) : false;
$total = $appHome !== '' ? @disk_total_space($appHome) : false;
if ($free !== false && $total !== false && $total > 0) {
    $usedPct = round((1 - $free / $total) * 100, 1);
    $txt = 'con trong ' . wp_pocket_health_fmt_bytes($free) . ' / tong ' . wp_pocket_health_fmt_bytes($total) . ' (da dung ' . $usedPct . '%)';
    if ($free < 524288000 || $usedPct >= 95) {
        wp_pocket_health_add($checks, 'Dung luong', 'bad', $txt . ' - SAP DAY: backup, upload va MariaDB co the hong. Xoa bot du lieu ngay.');
    } elseif ($free < 1073741824 || $usedPct >= 90) {
        wp_pocket_health_add($checks, 'Dung luong', 'warn', $txt . ' - duoi 1GB hoac tren 90%.');
    } else {
        wp_pocket_health_add($checks, 'Dung luong', 'ok', $txt);
    }
} else {
    wp_pocket_health_add($checks, 'Dung luong', 'info', 'khong doc duoc');
}

// ---------- Trang thai van hanh (cac file co cua app) ----------
// Bao mat (HANDOFF.md muc 1br): ket qua quet ma doc gan nhat do supervisor ghi (security-scan.json) + so IP dang bi tu dong chan (security-status.json).
$secScan = $rundir !== '' && is_file($rundir . '/security-scan.json') ? json_decode((string) @file_get_contents($rundir . '/security-scan.json'), true) : null;
if (is_array($secScan) && isset($secScan['counts'])) {
    $sc = (array) $secScan['counts'];
    $sBad = (int) ($sc['critical'] ?? 0) + (int) ($sc['high'] ?? 0);
    $sMed = (int) ($sc['medium'] ?? 0);
    $sAge = max(0, time() - (int) ($secScan['at'] ?? 0));
    $sTxt = 'quet ' . (int) ($secScan['files'] ?? 0) . ' file cach day ' . ($sAge < 5400 ? (int) round($sAge / 60) . ' phut' : (int) round($sAge / 3600) . ' gio') . ': ' . (int) ($sc['critical'] ?? 0) . ' nghiem trong, ' . (int) ($sc['high'] ?? 0) . ' cao, ' . $sMed . ' trung binh - chi tiet o "Trung tam bao mat"';
    wp_pocket_health_add($checks, 'Quet ma doc', $sBad > 0 ? 'bad' : ($sMed > 0 || $sAge > 21600 ? 'warn' : 'ok'), $sTxt);
} else {
    wp_pocket_health_add($checks, 'Quet ma doc', $liteMode ? 'info' : 'warn', 'chua co ket qua quet (supervisor quet sau ~1 phut khi bat server, roi moi gio) - xem "Trung tam bao mat"');
}
if ($rundir !== '' && is_file($rundir . '/realip-missing') && !$liteMode) {
    wp_pocket_health_add($checks, 'IP khach that', 'bad', 'nginx thieu module realip: khong chan duoc IP tan cong (moi khach hien la 127.0.0.1) - xem "Trung tam bao mat"');
}
wp_pocket_health_add($checks, 'Tunnel', 'info', is_file($rundir . '/tunnel-named') ? 'Named Tunnel (ten mien co dinh)' : 'Quick Tunnel hoac chua bat (URL doi moi lan bat; robots.txt chan Google)');
wp_pocket_health_add($checks, 'Che do bao tri', is_file($rundir . '/maintenance-mode') ? 'warn' : 'ok', is_file($rundir . '/maintenance-mode') ? 'DANG BAT - khach thay trang "dang bao tri"' : 'tat');
wp_pocket_health_add($checks, 'Cache trang (nginx)', 'info', is_file($rundir . '/page-cache-on') ? 'dang bat' : 'tat (mac dinh)');

// ---------- Uptime 24h (tu uptime.csv, xem metrics.php) ----------
$upN = 0;
$upOk = 0;
foreach (explode("\n", wp_pocket_health_read($rundir . '/uptime.csv', 262144)) as $line) {
    $p = explode(',', trim($line));
    if (count($p) === 2 && ctype_digit(trim($p[0])) && ($p[1] === '0' || $p[1] === '1')) {
        $t = (int) trim($p[0]);
        if ($t <= $now && $now - $t <= 86400) {
            $upN++;
            if ($p[1] === '1') {
                $upOk++;
            }
        }
    }
}
if ($upN > 0) {
    $pct = $upOk * 100 / $upN;
    wp_pocket_health_add($checks, 'Uptime 24 gio', $pct >= 99 ? 'ok' : ($pct >= 90 ? 'warn' : 'bad'), number_format($pct, 1, '.', '') . '% (' . $upOk . '/' . $upN . ' lan kiem tra) - chi tiet o "Thong ke theo thoi gian"');
} else {
    wp_pocket_health_add($checks, 'Uptime 24 gio', 'info', 'chua co du lieu (app tu kiem tra moi ~15 phut khi server dang bat)');
}

// ---------- WordPress ----------
$wpInstalled = $docroot !== '' && is_file($docroot . '/wp-includes/version.php');
$cfg = $wpInstalled ? wp_pocket_health_read($docroot . '/wp-config.php') : '';
$wpVersion = '';
if ($wpInstalled && preg_match('/\$wp_version\s*=\s*[\'"]([0-9A-Za-z.\-]+)[\'"]/', wp_pocket_health_read($docroot . '/wp-includes/version.php', 16384), $m)) {
    $wpVersion = $m[1];
}
$dbRows = null;      // null = khong co/khong doc duoc DB
$dbNote = '';
$cronEvents = [];
$cronOk = false;
$futurePosts = [];
$dbSize = null;
$autoload = null;
if ($wpInstalled) {
    wp_pocket_health_add($checks, 'WordPress', 'info', $wpVersion !== '' ? 'ban ' . $wpVersion . ' (kiem tra ban moi: WP-CLI console -> core check-update)' : 'da cai, khong doc duoc phien ban');
    if (preg_match('/define\(\s*[\'"]WP_DEBUG[\'"]\s*,\s*true\s*\)/i', $cfg)) {
        wp_pocket_health_add($checks, 'WP_DEBUG', 'warn', 'DANG BAT trong wp-config.php - loi PHP co the hien ra cho khach; chi nen bat khi dang sua loi.');
    }
    $okCfg = preg_match('/define\(\s*[\'"]DB_NAME[\'"]\s*,\s*[\'"]([^\'"]{1,64})[\'"]\s*\)/', $cfg, $mn)
        && preg_match('/define\(\s*[\'"]DB_USER[\'"]\s*,\s*[\'"]([^\'"]{1,64})[\'"]\s*\)/', $cfg, $mu)
        && preg_match('/define\(\s*[\'"]DB_PASSWORD[\'"]\s*,\s*[\'"]([^\'"]{0,128})[\'"]\s*\)/', $cfg, $mp)
        && preg_match('/\$table_prefix\s*=\s*[\'"]([A-Za-z0-9_]{1,40})[\'"]/', $cfg, $mx);
    if (!$okCfg) {
        $dbNote = 'Khong doc duoc thong tin DB tu wp-config.php (che do Lite/SQLite hoac cau hinh khac).';
    } elseif (is_file($rundir . '/mariadb-asleep')) {
        $dbNote = 'MariaDB dang NGU (Auto-Sleep) - mo trang chu website de danh thuc roi tai lai trang nay de xem muc DB/WP-Cron.';
    } else {
        $db = wp_pocket_health_db($rundir . '/mysql.sock', $mu[1], $mp[1], $mn[1]);
        if ($db === null) {
            $dbNote = 'Khong ket noi duoc MariaDB (che do Lite khong co MariaDB, hoac DB chua khoi dong xong).';
        } else {
            $dbRows = true;
            $prefix = $mx[1];
            $name = mysqli_real_escape_string($db, $mn[1]);
            $sz = wp_pocket_health_rows($db, "SELECT SUM(data_length + index_length) AS b FROM information_schema.tables WHERE table_schema = '" . $name . "'");
            $dbSize = isset($sz[0]['b']) && $sz[0]['b'] !== null ? (float) $sz[0]['b'] : null;
            $al = wp_pocket_health_rows($db, "SELECT SUM(LENGTH(option_value)) AS b FROM `" . $prefix . "options` WHERE autoload IN ('yes','on','auto-yes','auto-on')");
            $autoload = isset($al[0]['b']) && $al[0]['b'] !== null ? (float) $al[0]['b'] : null;
            $cr = wp_pocket_health_rows($db, "SELECT option_value FROM `" . $prefix . "options` WHERE option_name = 'cron' LIMIT 1");
            if (isset($cr[0]['option_value'])) {
                $arr = @unserialize((string) $cr[0]['option_value'], ['allowed_classes' => false]);
                if (is_array($arr)) {
                    $cronOk = true;
                    foreach ($arr as $ts => $hooks) {
                        if (is_int($ts) && is_array($hooks)) {
                            foreach ($hooks as $hook => $unused) {
                                if (is_string($hook) && count($cronEvents) < 500) {
                                    $cronEvents[] = [$ts, $hook];
                                }
                            }
                        }
                    }
                    usort($cronEvents, static function ($a, $b) {
                        return $a[0] <=> $b[0];
                    });
                }
            }
            $futurePosts = wp_pocket_health_rows($db, "SELECT ID, post_title, post_date_gmt FROM `" . $prefix . "posts` WHERE post_status = 'future' ORDER BY post_date_gmt ASC LIMIT 10");
            mysqli_close($db);
        }
    }
    if ($dbSize !== null) {
        wp_pocket_health_add($checks, 'Kich thuoc database', 'info', wp_pocket_health_fmt_bytes($dbSize));
    }
    if ($autoload !== null) {
        $st = $autoload > 3145728 ? 'bad' : ($autoload > 1048576 ? 'warn' : 'ok');
        wp_pocket_health_add($checks, 'Autoload options', $st, wp_pocket_health_fmt_bytes($autoload) . ($st === 'ok' ? '' : ' - qua lon, moi luot tai trang deu phai doc het; xoa option rac cua plugin da go (Adminer) hoac dung WP-CLI.'));
    }
    if ($dbNote !== '') {
        wp_pocket_health_add($checks, 'Database / WP-Cron', 'info', $dbNote);
    }
} else {
    wp_pocket_health_add($checks, 'WordPress', 'info', 'chua cai (hoac site khong phai WordPress) - cac muc DB/WP-Cron bi bo qua');
}

// ---------- WP-Cron: tom tat canh bao ----------
$overdue = [];
foreach ($cronEvents as $ev) {
    if ($ev[0] < $now - 600) {
        $overdue[] = $ev;
    }
}
$overduePosts = [];
foreach ($futurePosts as $fp) {
    $t = wp_pocket_health_gmt($fp['post_date_gmt'] ?? '');
    if ($t !== false && $t < $now - 600) {
        $overduePosts[] = $fp;
    }
}
if ($cronOk) {
    if ($overduePosts) {
        wp_pocket_health_add($checks, 'WP-Cron', 'bad', count($overduePosts) . ' bai hen gio DA QUA gio dang > 10 phut ma chua len - WP-Cron khong chay. Thu: WP-CLI console -> cron event run --due-now');
    } elseif (count($overdue) > 0) {
        wp_pocket_health_add($checks, 'WP-Cron', 'warn', count($overdue) . ' tac vu qua han > 10 phut chua chay (co the do may vua ngu/Doze). Neu keo dai: WP-CLI console -> cron event run --due-now');
    } else {
        wp_pocket_health_add($checks, 'WP-Cron', 'ok', count($cronEvents) . ' tac vu dang cho, khong cai nao qua han > 10 phut');
    }
}

$labels = ['ok' => 'OK', 'warn' => 'CHU Y', 'bad' => 'LOI', 'info' => 'THONG TIN'];
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Suc khoe site</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:720px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
h2{font-size:15px;margin:24px 0 6px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.row{display:flex;gap:10px;align-items:flex-start;padding:9px 0;border-bottom:1px solid #eee;font-size:14px;line-height:1.45}
.row .k{flex:0 0 132px;font-weight:600}
.row .v{flex:1;min-width:0;word-break:break-word}
.tag{display:inline-block;font-size:11px;font-weight:700;padding:1px 7px;border-radius:9px;margin-right:6px}
.tag.ok{background:#e3f4e8;color:#1d7a3d}.tag.warn{background:#fff3cd;color:#856404}.tag.bad{background:#fdecea;color:#8a1c1c}.tag.info{background:#eceff3;color:#556}
table{border-collapse:collapse;width:100%;font-size:13px}
td,th{text-align:left;padding:6px 6px;border-bottom:1px solid #eee}
th{color:#666;font-size:12px}
.late{color:#8a1c1c;font-weight:600}
.muted{color:#999;font-size:12px;margin-top:8px}
.score{font-size:18px;margin:4px 0 14px}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Suc khoe site</h1>
<?php [$healthScore, $healthLabel] = wp_pocket_health_score($checks); ?>
<p class="score"><b id="health-score"><?= (int) $healthScore ?></b>/100 <span class="tag <?= $healthScore >= 90 ? 'ok' : ($healthScore >= 70 ? 'warn' : 'bad') ?>"><?= esc($healthLabel) ?></span> <span class="muted">diem gop cua cac muc ben duoi (muc do tru 20, canh bao tru 6)</span></p>

<?php foreach ($checks as $c): ?>
<div class="row">
  <div class="k"><?= esc($c[0]) ?></div>
  <div class="v"><span class="tag <?= esc($c[1]) ?>"><?= esc($labels[$c[1]] ?? '') ?></span><?= esc($c[2]) ?></div>
</div>
<?php endforeach; ?>

<?php if ($cronOk): ?>
<h2>WP-Cron: tac vu sap toi (toi da 10)</h2>
<?php if (count($cronEvents) === 0): ?>
<p class="muted">Khong co tac vu nao dang cho.</p>
<?php else: ?>
<table>
<tr><th>Tac vu</th><th>Khi nao</th></tr>
<?php foreach (array_slice($cronEvents, 0, 10) as $ev): ?>
<tr><td><?= esc($ev[1]) ?></td><td class="<?= $ev[0] < $now - 600 ? 'late' : '' ?>"><?= esc(wp_pocket_health_rel($ev[0] - $now)) ?></td></tr>
<?php endforeach; ?>
</table>
<?php endif; ?>
<?php endif; ?>

<?php if (count($futurePosts) > 0): ?>
<h2>Bai hen gio dang (toi da 10)</h2>
<table>
<tr><th>Bai viet</th><th>Gio dang</th></tr>
<?php foreach ($futurePosts as $fp):
    $t = wp_pocket_health_gmt($fp['post_date_gmt'] ?? '');
    $title = (string) ($fp['post_title'] ?? '');
    $title = function_exists('mb_substr') ? mb_substr($title, 0, 60) : substr($title, 0, 60); ?>
<tr><td><?= esc($title !== '' ? $title : '(khong tieu de)') ?></td>
<td class="<?= ($t !== false && $t < $now - 600) ? 'late' : '' ?>"><?= $t === false ? '?' : esc(wp_pocket_health_rel($t - $now)) ?></td></tr>
<?php endforeach; ?>
</table>
<?php endif; ?>

<p class="muted">Trang chi doc. WP-Cron tren may nay duoc app goi dinh ky (khong phu thuoc co khach truy cap); gio hien theo UTC cua may.</p>
</body>
</html>
