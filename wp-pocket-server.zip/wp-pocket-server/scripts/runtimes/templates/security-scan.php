<?php
/**
 * security-scan.php - QUET MA DOC / FILE LA / THAY DOI DIEM BAM TRU tren site WordPress (va PHP chung). HANDOFF.md muc 1br, docs/SECURITY.md.
 * Test: scripts/tests/security-scan-test.py.
 *
 * BOI CANH: ke tan cong (nhat la cong cu tu dong dung AI) sau khi vao duoc 1 lan thuong de lai "chan sau": web-shell trong uploads/, plugin gia
 * mao, file PHP la o goc site, sua file loi cua WordPress, mu-plugin/drop-in tu nap moi lan site chay (bai bao thang 7/2026 ghi nhan hon 100
 * tai khoan admin tao ngam + plugin gia chua web-shell sau dot khai thac WordPress). Chu site khong co thoi gian doc tung file nen can may quet.
 *
 * 5 LOP KIEM TRA (tu chinh xac nhat xuong "nghi ngo"):
 *  1. Loi cua WordPress: so MD5 tung file .php trong wp-admin/ va wp-includes/ voi checksum CHINH THUC cua wordpress.org (giong "wp core
 *     verify-checksums"); file sai checksum hoac file la moc them vao 2 thu muc nay => CAO. Khong can baseline nen khong bi bao nham sau khi cap nhat.
 *  2. Vi tri khong bao gio hop le: file PHP (.php/.phtml/.phar...) trong wp-content/uploads/ => NGHIEM TRONG; anh chua "<?php" (polyglot) => CAO.
 *  3. Diem bam tru (so voi lan quet dau lam moc): file .php o goc site, wp-config.php, drop-in wp-content/*.php, wp-content/mu-plugins/ - cac cho
 *     ke tan cong dat ma tu nap khi chu site khong de y; doi/moi => CAO. Chu site bam "Chap nhan" sau thay doi co chu dich (cap nhat, cai them).
 *  4. Plugin/theme MOI xuat hien so voi lan quet truoc => TRUNG BINH (chu site xem co phai minh cai khong).
 *  5. Dau hieu ma doc trong noi dung (eval(base64_decode(..)), goi ham he thong tu $_POST, ten web-shell noi tieng, chuoi base64 dai...): tinh DIEM,
 *     du nguong => CAO/TRUNG BINH. Day la HEURISTIC: co the bao nham (thu vien hop phap dung eval/base64); co danh sach "bo qua" theo (file + sha1).
 *
 * KHONG tu xoa gi. Hanh dong duy nhat la CACH LY (doi ten sang .quar trong lamp-run/quarantine/, khoi phuc duoc) va chi voi file DANG nam trong
 * ket qua quet gan nhat (khong the dung de di chuyen file tuy y nhu wp-config.php).
 *
 * File nay vua la thu vien (admin-security.php nap de hien/cach ly) vua la CLI: php security-scan.php <docroot> <rundir> [scan|scan-fetch|accept|fetch-core].
 */

const WPP_SCAN_MAX_FILES = 25000;
const WPP_SCAN_MAX_BYTES = 2097152;       // doc toi da 2MB noi dung moi file de quet mau (file lon hon chi xet vi tri)
const WPP_SCAN_TIME_BUDGET = 45;          // giay: het gio thi dung va danh dau "truncated" (dien thoai cham, khong de treo may)
const WPP_SCAN_EXT_RX = '~\.(?:php[0-9]?|phtml|pht|phar|phps|inc)$~i';
const WPP_SCAN_HIGH_SCORE = 8.0;
const WPP_SCAN_MED_SCORE = 5.0;

function wpp_scan_paths(string $rundir): array
{
    $rd = rtrim($rundir, '/');
    return [
        'result' => $rd . '/security-scan.json', 'baseline' => $rd . '/security-baseline.json', 'seen' => $rd . '/security-seen.json',
        'ignore' => $rd . '/security-ignore.json', 'events' => $rd . '/security-events.log', 'core' => $rd . '/wp-core-checksums.json',
        'quarantine' => $rd . '/quarantine', 'qindex' => $rd . '/quarantine/index.json', 'lock' => $rd . '/security-scan.lock',
        'now' => $rd . '/security-scan-now',
    ];
}

/** Thu muc/tien to khong duyet (bo nho dem, ban sao luu, ma ben thu 3 khong phai cua site, thu muc cua chinh du an nay). */
function wpp_scan_skip_dir(string $rel): bool
{
    static $skip = [
        '_admin', '_supervisor', '.git', 'node_modules', 'wp-content/cache', 'wp-content/upgrade', 'wp-content/ai1wm-backups', 'wp-content/updraft',
        'wp-content/wpvividbackups', 'wp-content/backups-dup-lite', 'wp-content/backups-dup-pro', 'wp-snapshots', 'wp-content/languages',
    ];
    foreach ($skip as $s) {
        if ($rel === $s || strpos($rel, $s . '/') === 0) return true;
    }
    return (bool) preg_match('~(?:^|/)node_modules(?:/|$)~', $rel);
}

/** Plugin bao mat tu chua chu ky ma doc trong chinh ma nguon cua no: bo qua buoc heuristic noi dung (van xet vi tri). */
function wpp_scan_is_security_plugin(string $rel): bool
{
    return (bool) preg_match('~^wp-content/plugins/(?:wordfence|sucuri-scanner|all-in-one-wp-security-and-firewall|better-wp-security|ithemes-security[a-z-]*|wp-security-audit-log|malcare-security|ninjafirewall|wp-cerber|patchstack|really-simple-ssl|jetpack|jetpack-protect|defender-security|solid-security)/~', $rel);
}

/** Nhom mau ma doc (ten, trong so, regex). Tong >= 8: CAO, >= 5: TRUNG BINH. */
function wpp_scan_signatures(): array
{
    return [
        ['eval-giai-ma', 6.0, '~\beval\s*\(\s*(?:@\s*)?(?:base64_decode|gzinflate|gzuncompress|gzdecode|str_rot13|rawurldecode|convert_uudecode|hex2bin|strrev)\s*\(~i'],
        ['ham-nguy-hiem-tu-request', 8.0, '~\b(?:assert|eval|system|exec|passthru|shell_exec|popen|proc_open|pcntl_exec|create_function)\s*\(\s*(?:@\s*)?(?:\$_(?:POST|GET|REQUEST|COOKIE|SERVER)|base64_decode\s*\(\s*\$_(?:POST|GET|REQUEST|COOKIE))~i'],
        // Phat hien khi dung WordPress THAT + plugin gia (1br-H): `$f = $_POST['k']; $f($_POST['v']);` - web shell kinh dien, goi ham qua BIEN gan tu request - khong khop
        // 'goi-gia-tri-request-nhu-ham' (goi truc tiep $_POST[..](..)). (?<![>:]) loai `$this->$method()` / `Foo::$method()` (goi phuong thuc dong hop phap); `[@$"'\d]` sau dau "(" loai cau van xuoi trong chu thich ("must match $doing_wp_cron (the key)" o wp-cron.php that).
        ['goi-qua-bien-tu-request', 9.0, '~\$(\w{1,30})\s*=\s*(?:@\s*)?\$_(?:POST|GET|REQUEST|COOKIE)\s*\[[^\]]{1,60}\]\s*;.{0,400}?(?<![>:\w$])\$\1\s*\(\s*[@$"\'\d]~is'],
        // Ham nhan "callback": dua gia tri tu request vao vi tri callback = chay ham tuy y (array_map($_GET['f'], ..), usort($a, $_POST['f']), call_user_func($_REQUEST['f'], ..)).
        ['callback-tu-request', 8.0, '~\b(?:call_user_func(?:_array)?|array_map|register_shutdown_function|register_tick_function|forward_static_call(?:_array)?|iterator_apply)\s*\(\s*(?:@\s*)?\$_(?:POST|GET|REQUEST|COOKIE)\s*\['
            . '|\b(?:usort|uasort|uksort|array_walk(?:_recursive)?|array_filter|array_reduce|preg_replace_callback)\s*\(\s*[^,;()]{1,80},\s*(?:@\s*)?\$_(?:POST|GET|REQUEST|COOKIE)\s*\[~i'],
        ['goi-gia-tri-request-nhu-ham', 9.0, '~\$_(?:POST|GET|REQUEST|COOKIE)\s*\[[^\]]{1,60}\]\s*\(~i'],
        ['include-tu-request', 6.0, '~\b(?:include|require)(?:_once)?\s*\(?\s*\$_(?:GET|POST|REQUEST|COOKIE)~i'],
        ['preg-replace-/e', 7.0, '~preg_replace\s*\(\s*[\'"][^\'"]{1,200}/[a-z]*e[a-z]*[\'"]\s*,~i'],
        ['ghi-file-php-tu-request', 8.0, '~file_put_contents\s*\([^;]{0,160}\.php[^;]{0,160}\$_(?:POST|GET|REQUEST)~is'],
        // CHI chuoi thoat hex cua ky tu IN DUOC (0x20-0x7f: "\x65\x76\x61\x6c" = eval): ke tan cong giau ten ham. Chuoi hex NHI PHAN (\x00-\x1f, \x80-\xff:
        // bang tra, magic byte, hang so mat ma) rat pho bien trong thu vien hop phap - tren WordPress 7.1.4 THAT, quy tac cu (moi \xNN) bao 15 file loi that
        // (SimplePie, sodium_compat, getID3, HTML API) khi chua co checksum. Chuoi hex nhi phan chi con +1 diem (cong don voi dau hieu khac).
        ['ten-ham-ma-hoa-hex', 5.0, '~(?:\\\\x[2-7][0-9a-f]){8,}~i'],
        ['chuoi-hex-dai', 1.0, '~(?:\\\\x[0-9a-f]{2}){8,}~i'],
        ['ten-ham-ma-hoa-bat-phan', 5.0, '~(?:\\\\(?:0[4-7][0-7]|1[0-7][0-7])){8,}~'],
        ['ghep-chr', 5.0, '~(?:chr\s*\(\s*\d{1,3}\s*\)\s*\.\s*){6,}~i'],
        ['blob-base64-dai', 4.0, '~[A-Za-z0-9+/]{2400,}+~'],
        ['ten-web-shell', 10.0, '~c99shell|r57shell|b374k|wso\s*shell|FilesMan|Cyb3r\s*Shell|IndoXploit|WebShell\s+by|Mini\s*Shell|PHP\s*Shell\s*v|Hacked\s*by\s|uname\s*-a[^<]{0,200}<form|\bphpspy\b~i'],
        ['goi-lenh-he-thong', 3.0, '~\b(?:shell_exec|passthru|proc_open|popen|pcntl_exec)\s*\(~i'],
        ['eval-don', 2.0, '~\beval\s*\(~i'],
        ['base64-decode', 1.0, '~\bbase64_decode\s*\(~i'],
    ];
}

/** Cham diem noi dung 1 file -> [diem, [nhom...]]. */
function wpp_scan_score_content(string $content): array
{
    $total = 0.0;
    $hits = [];
    foreach (wpp_scan_signatures() as [$name, $w, $rx]) {
        $r = @preg_match($rx, $content);
        if ($r === 1) {
            $total += $w;
            $hits[] = $name;
        }
    }
    return [$total, $hits];
}

function wpp_scan_sev_rank(string $sev): int
{
    return ['critical' => 4, 'high' => 3, 'medium' => 2, 'info' => 1][$sev] ?? 0;
}

function wpp_scan_finding(string $sev, string $kind, string $file, string $detail, string $sha1 = '', int $size = 0): array
{
    return ['sev' => $sev, 'kind' => $kind, 'file' => $file, 'detail' => $detail, 'sha1' => $sha1, 'size' => $size];
}

/** Nhan dien site WordPress + phien ban/ngon ngu goi tu wp-includes/version.php. */
function wpp_scan_wp_info(string $docroot): ?array
{
    $v = $docroot . '/wp-includes/version.php';
    if (!is_file($docroot . '/wp-load.php') || !is_file($v)) {
        return null;
    }
    $t = (string) @file_get_contents($v, false, null, 0, 20000);
    if (preg_match('/\$wp_version\s*=\s*\'([0-9][0-9A-Za-z.\-]*)\'/', $t, $m) !== 1) {
        return null;
    }
    $loc = preg_match('/\$wp_local_package\s*=\s*\'([A-Za-z_]+)\'/', $t, $l) === 1 ? $l[1] : 'en_US';
    return ['version' => $m[1], 'locale' => $loc];
}

/** Doc checksum cache ({version, locale, checksums{path=>md5}}); null neu khong co/khong khop phien ban. */
function wpp_scan_core_checksums(string $coreFile, array $wp): ?array
{
    $d = is_file($coreFile) ? json_decode((string) @file_get_contents($coreFile), true) : null;
    if (!is_array($d) || ($d['version'] ?? '') !== $wp['version'] || !is_array($d['checksums'] ?? null) || count($d['checksums']) < 100) {
        return null;
    }
    return $d['checksums'];
}

/** Tai checksum chinh thuc (can mang; goi tu supervisor/UI, KHONG goi luc quet de quet khong phu thuoc mang). Tra true neu da luu cache. */
function wpp_scan_fetch_core_checksums(string $docroot, string $coreFile): bool
{
    $wp = wpp_scan_wp_info($docroot);
    if (!$wp) return false;
    $url = 'https://api.wordpress.org/core/checksums/1.0/?version=' . rawurlencode($wp['version']) . '&locale=' . rawurlencode($wp['locale']);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true, 'header' => "User-Agent: WPPocketServer-SecurityScan\r\n"]]);
    $raw = @file_get_contents($url, false, $ctx);
    $d = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($d) || !is_array($d['checksums'] ?? null) || count($d['checksums']) < 100) {
        return false;     // vd ban "nightly"/ngon ngu khong ho tro: API tra false
    }
    $ok = array_filter($d['checksums'], fn($h, $k) => is_string($h) && preg_match('/^[0-9a-f]{32}$/', $h) && is_string($k), ARRAY_FILTER_USE_BOTH);
    return (bool) @file_put_contents($coreFile, json_encode(['version' => $wp['version'], 'locale' => $wp['locale'], 'fetched' => time(), 'checksums' => $ok]));
}

/** 1 lan quet: tra mang ket qua (da ghi security-scan.json, cap nhat baseline lan dau, ghi su kien cho phat hien MOI). */
/**
 * $managed: ['duong/dan/tuong/doi' => sha1 ban goc] - file do CHINH UNG DUNG dong bo (mu-plugin Shield) nen sha1 khop ban goc la hop le (nhu da khop checksum
 * loi WordPress): cap nhat ung dung khong bi bao "doi/moi".
 */
function wpp_scan_run(string $docroot, string $rundir, ?int $now = null, array $managed = []): array
{
    $now = $now ?? time();
    $t0 = microtime(true);
    $p = wpp_scan_paths($rundir);
    $docroot = rtrim((string) (realpath($docroot) ?: $docroot), '/');
    $lock = @fopen($p['lock'], 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
        if ($lock) fclose($lock);
        return ['skipped' => true];
    }
    @ini_set('pcre.backtrack_limit', '300000');
    $findings = [];
    $wp = wpp_scan_wp_info($docroot);
    $core = $wp ? wpp_scan_core_checksums($p['core'], $wp) : null;
    $ignore = is_file($p['ignore']) ? (json_decode((string) @file_get_contents($p['ignore']), true) ?: []) : [];
    $baselineOld = is_file($p['baseline']) ? json_decode((string) @file_get_contents($p['baseline']), true) : null;
    $points = [];              // diem bam tru hien tai: rel => sha1
    $okNow = [];               // trong do: file da khop checksum chinh thuc
    $pluginDirs = [];
    $files = 0;
    $truncated = false;
    $coreSeen = [];
    $rootKnown = ['index.php', 'wp-activate.php', 'wp-blog-header.php', 'wp-comments-post.php', 'wp-config.php', 'wp-config-sample.php', 'wp-cron.php',
                  'wp-links-opml.php', 'wp-load.php', 'wp-login.php', 'wp-mail.php', 'wp-settings.php', 'wp-signup.php', 'wp-trackback.php', 'xmlrpc.php',
                  'wake-mariadb.php'];

    try {
        foreach (['wp-content/plugins' => 'plugin', 'wp-content/themes' => 'theme'] as $dir => $type) {
            $list = @scandir($docroot . '/' . $dir);
            foreach ($list === false ? [] : $list as $n) {
                if ($n !== '' && $n[0] !== '.' && is_dir($docroot . '/' . $dir . '/' . $n)) $pluginDirs[$type . ':' . $n] = true;
            }
        }
        $stack = [''];
        while ($stack) {
            $rel = array_pop($stack);
            $abs = $docroot . ($rel === '' ? '' : '/' . $rel);
            $names = @scandir($abs);
            if ($names === false) continue;
            foreach ($names as $n) {
                if ($n === '.' || $n === '..') continue;
                $r = $rel === '' ? $n : $rel . '/' . $n;
                $a = $abs . '/' . $n;
                if (is_link($a)) continue;
                if (is_dir($a)) {
                    if (!wpp_scan_skip_dir($r)) $stack[] = $r;
                    continue;
                }
                if (!is_file($a)) continue;
                $isPhp = preg_match(WPP_SCAN_EXT_RX, $n) === 1;
                $inUploads = strpos($r, 'wp-content/uploads/') === 0;
                $size = (int) @filesize($a);
                if (!$isPhp && !($inUploads && $size > 0 && $size < 5242880 && preg_match('~\.(?:jpe?g|png|gif|ico|webp|svg|bmp|txt|pdf)$~i', $n)) && !($inUploads && $n === '.htaccess')) {
                    continue;
                }
                if (++$files > WPP_SCAN_MAX_FILES || (microtime(true) - $t0) > WPP_SCAN_TIME_BUDGET) {
                    $truncated = true;
                    break 2;
                }
                if ($inUploads && !$isPhp) {
                    $head = (string) @file_get_contents($a, false, null, 0, 4096);
                    if ($n === '.htaccess') {
                        if (preg_match('~AddType|AddHandler|SetHandler|php_value|php_flag|auto_prepend_file~i', $head) === 1) {
                            $findings[] = wpp_scan_finding('high', 'htaccess-trong-uploads', $r, '.htaccess trong uploads/ co chi thi chay ma/doi cau hinh PHP', sha1($head), $size);
                        }
                    } elseif (preg_match('~<\?(?:php|=)|<script\s+language\s*=\s*[\'"]?php~i', $head) === 1) {
                        $findings[] = wpp_scan_finding('high', 'anh-chua-ma-php', $r, 'tep "' . pathinfo($n, PATHINFO_EXTENSION) . '" trong uploads/ co chua the PHP (polyglot - thuong dung de lach bo loc tai len)', sha1_file($a) ?: '', $size);
                    }
                    continue;
                }

                // ---- tu day la file PHP ----
                $sha1 = (string) @sha1_file($a);     // 1 lan doc them: can cho ket qua + moc (quet chu yeu doc file 1 lan nhieu hon moi thu khac)
                if ($inUploads) {
                    $findings[] = wpp_scan_finding('critical', 'php-trong-uploads', $r, 'File PHP trong uploads/ - WordPress khong bao gio de PHP o day (nginx da chan chay nhung file van la dau hieu bi xam nhap)', $sha1, $size);
                }
                // diem bam tru
                $isRootPhp = strpos($r, '/') === false;
                $isDropin = (bool) preg_match('~^wp-content/[^/]+\.php$~', $r);
                $isMu = strpos($r, 'wp-content/mu-plugins/') === 0;
                $isPoint = $wp !== null && ($isRootPhp || $isDropin || $isMu);     // site khong phai WordPress: chu site sua file goc thuong xuyen -> khong theo doi doi-noi-dung
                if ($isPoint) {
                    $points[$r] = $sha1;
                }
                if ($wp && $isRootPhp && !in_array($n, $rootKnown, true)) {
                    $findings[] = wpp_scan_finding('medium', 'php-la-o-goc-site', $r, 'File PHP o thu muc goc khong thuoc loi WordPress (xem co phai ban cai khong)', $sha1, $size);
                }
                // loi WordPress theo checksum chinh thuc
                $isCore = $core !== null && (strpos($r, 'wp-admin/') === 0 || strpos($r, 'wp-includes/') === 0 || ($isRootPhp && $n !== 'wp-config.php'));
                $coreOk = false;
                if ($isCore) {
                    $coreSeen[$r] = true;
                    $want = $core[$r] ?? null;
                    if ($want === null) {
                        if (!$isRootPhp && $r !== 'wp-includes/version.php') {
                            $findings[] = wpp_scan_finding('high', 'core-file-la', $r, 'File PHP trong ' . dirname($r) . '/ khong co trong ban WordPress ' . $wp['version'] . ' chinh thuc', $sha1, $size);
                        }
                    } elseif (!hash_equals($want, (string) @md5_file($a))) {
                        $findings[] = wpp_scan_finding('high', 'core-bi-sua', $r, 'File loi WordPress ' . $wp['version'] . ' khac checksum chinh thuc cua wordpress.org', $sha1, $size);
                    } else {
                        $coreOk = true;
                    }
                }
                if ($isPoint && !$coreOk && isset($managed[$r]) && $managed[$r] !== '' && hash_equals((string) $managed[$r], $sha1)) {
                    $coreOk = true;            // file do ung dung dong bo, khop ban goc
                }
                if ($isPoint && $coreOk) {
                    $okNow[$r] = true;         // file loi da khop checksum chinh thuc: cap nhat WordPress hop phap khong bi bao la "doi/moi"
                }
                // noi dung
                if ($coreOk || ($size > WPP_SCAN_MAX_BYTES) || wpp_scan_is_security_plugin($r)) {
                    continue;
                }
                $content = (string) @file_get_contents($a, false, null, 0, WPP_SCAN_MAX_BYTES);
                [$score, $hits] = wpp_scan_score_content($content);
                if ($score >= WPP_SCAN_HIGH_SCORE) {
                    $findings[] = wpp_scan_finding('high', 'nghi-web-shell', $r, 'Dau hieu ma doc (diem ' . $score . '): ' . implode(', ', $hits), $sha1, $size);
                } elseif ($score >= WPP_SCAN_MED_SCORE) {
                    $findings[] = wpp_scan_finding('medium', 'ma-dang-ngo', $r, 'Mau dang ngo (diem ' . $score . '): ' . implode(', ', $hits) . ' - co the la thu vien hop phap', $sha1, $size);
                }
            }
        }

        // thieu file loi (xoa/doi ten): chi bao khi checksum co va file bien mat o thu muc loi
        if ($core !== null && !$truncated) {
            $missing = [];
            foreach ($core as $path => $_md5) {
                if (preg_match(WPP_SCAN_EXT_RX, $path) && (strpos($path, 'wp-admin/') === 0 || strpos($path, 'wp-includes/') === 0) && !isset($coreSeen[$path])
                    && !is_file($docroot . '/' . $path)) {
                    $missing[] = $path;
                }
            }
            if (count($missing) > 0) {
                $findings[] = wpp_scan_finding('medium', 'core-thieu-file', $missing[0], count($missing) . ' file loi WordPress bi mat (vd ' . $missing[0] . ') - site co the loi hoac bi go de lach quet', '', 0);
            }
        }

        // ---- so voi moc (diem bam tru + plugin moi) ----
        $baselineCreated = false;
        $newBaseline = null;
        if ($wp === null) {
            // khong phai WordPress (hoac chua cai): khong lap moc - tranh moc rong roi cai WordPress xong bi bao "moi" hang loat
        } elseif (!is_array($baselineOld) || ($baselineOld['v'] ?? 0) !== 1) {
            if (!$truncated) {      // quet do dang thi moc thieu -> lan sau se bao nham
                $baselineCreated = true;
                $newBaseline = ['v' => 1, 'at' => $now, 'wp' => $core !== null ? $wp['version'] : '', 'points' => $points, 'plugins' => array_keys($pluginDirs)];
            }
        } else {
            $verChanged = ($baselineOld['wp'] ?? '') !== '' && $baselineOld['wp'] !== $wp['version'] && $core === null;
            $refresh = $baselineOld;
            $dirty = false;
            foreach ($points as $r => $h) {
                $old = $baselineOld['points'][$r] ?? null;
                if (isset($okNow[$r])) {
                    // dung checksum chinh thuc -> hop le; cap nhat moc de lan sau (neu mat checksum) khong bao nham
                    if ($old !== $h) { $refresh['points'][$r] = $h; $dirty = true; }
                } elseif ($old === null) {
                    $findings[] = wpp_scan_finding('high', 'diem-bam-tru-moi', $r, 'File PHP MOI o cho tu nap/goc site tu lan quet moc (' . gmdate('Y-m-d', (int) $baselineOld['at']) . ')', $h);
                } elseif ($old !== $h) {
                    if ($verChanged && in_array($r, $rootKnown, true)) {
                        $findings[] = wpp_scan_finding('medium', 'loi-doi-chua-xac-minh', $r, 'WordPress doi phien ban (' . $baselineOld['wp'] . ' -> ' . $wp['version'] . ') nen file goc doi la binh thuong, nhung chua tai duoc checksum de xac minh - bam "Tai checksum loi" roi quet lai', $h);
                    } else {
                        $findings[] = wpp_scan_finding('high', 'diem-bam-tru-doi', $r, 'File o cho tu nap/goc site DA DOI noi dung tu lan quet moc', $h);
                    }
                }
            }
            foreach ((array) $baselineOld['points'] as $r => $h) {
                if (!isset($points[$r]) && !$truncated && !is_file($docroot . '/' . $r)) {
                    $findings[] = wpp_scan_finding('info', 'diem-bam-tru-mat', (string) $r, 'File o cho tu nap/goc site da bi xoa so voi lan quet moc');
                }
            }
            foreach (array_diff(array_keys($pluginDirs), (array) ($baselineOld['plugins'] ?? [])) as $k) {
                [$type, $slug] = explode(':', $k, 2);
                $findings[] = wpp_scan_finding('medium', $type . '-moi', 'wp-content/' . $type . 's/' . $slug, ucfirst($type) . ' "' . $slug . '" moi xuat hien tu lan quet moc - neu ban khong cai, hay xoa (ke tan cong hay cai plugin gia)');
            }
            if ($core !== null && ($baselineOld['wp'] ?? '') !== $wp['version']) {
                $refresh['wp'] = $wp['version'];
                $dirty = true;
            }
            if ($dirty && !$truncated) {
                $newBaseline = $refresh;
            }
        }
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }

    // bo qua (chu site da xac nhan an toan theo file + sha1)
    $findings = array_values(array_filter($findings, fn($f) => !isset($ignore[$f['file'] . '|' . $f['sha1']])));
    usort($findings, fn($a, $b) => wpp_scan_sev_rank($b['sev']) <=> wpp_scan_sev_rank($a['sev']) ?: strcmp($a['file'], $b['file']));
    $counts = ['critical' => 0, 'high' => 0, 'medium' => 0, 'info' => 0];
    foreach ($findings as $f) $counts[$f['sev']]++;

    $result = [
        'v' => 1, 'at' => $now, 'duration' => round(microtime(true) - $t0, 2), 'files' => $files, 'truncated' => $truncated,
        'profile' => $wp ? 'wordpress' : 'generic',
        'core' => ['version' => $wp['version'] ?? null, 'verified' => $core !== null, 'checksums' => $core !== null ? count($core) : 0],
        'baseline_created' => $baselineCreated, 'counts' => $counts, 'findings' => array_slice($findings, 0, 300),
    ];
    wpp_scan_write($p['result'], json_encode($result));
    if ($newBaseline !== null) {
        wpp_scan_write($p['baseline'], json_encode($newBaseline));
    }
    wpp_scan_events($p, $findings, $now);
    @unlink($p['now']);
    return $result;
}

function wpp_scan_write(string $file, string $content): bool
{
    $tmp = $file . '.tmp.' . getmypid();
    if (@file_put_contents($tmp, $content) === false) {
        @unlink($tmp);
        return false;
    }
    return @rename($tmp, $file) ?: (@unlink($tmp) && false);
}

/** Ghi su kien cho phat hien NGHIEM TRONG/CAO MOI (chua thay lan quet truoc): dinh dang audit "ip=- ..." de Telegram doc. */
function wpp_scan_events(array $p, array $findings, int $now): void
{
    $seen = is_file($p['seen']) ? (json_decode((string) @file_get_contents($p['seen']), true) ?: []) : [];
    $new = [];
    foreach ($findings as $f) {
        if (wpp_scan_sev_rank($f['sev']) < 3) continue;
        $k = $f['kind'] . '|' . $f['file'] . '|' . $f['sha1'];
        if (!isset($seen[$k])) {
            $new[] = $f;
            $seen[$k] = $now;
        }
    }
    foreach (array_slice($new, 0, 10) as $f) {
        $line = date('Y-m-d H:i:s', $now) . ' ip=- PHAT HIEN MA DOC/THAY DOI LA (' . $f['sev'] . '): ' . preg_replace('/[\r\n]+/', ' ', substr($f['file'], 0, 120)) . ' [' . $f['kind'] . "]\n";
        @file_put_contents($p['events'], $line, FILE_APPEND | LOCK_EX);
    }
    if (count($new) > 10) {
        @file_put_contents($p['events'], date('Y-m-d H:i:s', $now) . ' ip=- PHAT HIEN MA DOC/THAY DOI LA (' . (count($new) - 10) . " muc nua - xem _admin/security.php)\n", FILE_APPEND | LOCK_EX);
    }
    if (count($seen) > 2000) {
        asort($seen);
        $seen = array_slice($seen, -1500, null, true);
    }
    wpp_scan_write($p['seen'], json_encode($seen));
}

/** Chap nhan trang thai hien tai lam moc moi (xoa baseline -> lan quet sau tao lai). */
function wpp_scan_accept(string $rundir): bool
{
    $p = wpp_scan_paths($rundir);
    return !is_file($p['baseline']) || @unlink($p['baseline']);
}

/** Danh dau 1 phat hien la an toan: ghi (file|sha1) vao security-ignore.json. */
function wpp_scan_ignore(string $rundir, string $file, string $sha1): bool
{
    $p = wpp_scan_paths($rundir);
    $d = is_file($p['ignore']) ? (json_decode((string) @file_get_contents($p['ignore']), true) ?: []) : [];
    $d[$file . '|' . $sha1] = time();
    return wpp_scan_write($p['ignore'], json_encode(array_slice($d, -500, null, true)));
}

function wpp_scan_last_result(string $rundir): ?array
{
    $f = wpp_scan_paths($rundir)['result'];
    $d = is_file($f) ? json_decode((string) @file_get_contents($f), true) : null;
    return is_array($d) ? $d : null;
}

// ------------------------------------------------------------------------------------------------------------------
// Cach ly
// ------------------------------------------------------------------------------------------------------------------

function wpp_scan_quarantine_index(string $rundir): array
{
    $f = wpp_scan_paths($rundir)['qindex'];
    $d = is_file($f) ? json_decode((string) @file_get_contents($f), true) : null;
    return is_array($d) ? $d : [];
}

/**
 * Cach ly 1 file DANG nam trong ket qua quet gan nhat. Tra ['ok'=>bool,'msg'=>string,'id'=>string]. Tu choi: duong dan co ".."/NUL/tuyet doi/lien ket,
 * file ngoai docroot (realpath), khong phai file thuong, hoac KHONG nam trong danh sach phat hien (de UI khong the dung ham nay di chuyen
 * wp-config.php hay file tuy y). Doi ten (cung o dia) -> .quar nen khong the chay; chmod 0600.
 */
function wpp_scan_quarantine(string $docroot, string $rundir, string $rel, ?int $now = null): array
{
    $now = $now ?? time();
    $p = wpp_scan_paths($rundir);
    $fail = fn(string $m) => ['ok' => false, 'msg' => $m, 'id' => ''];
    if ($rel === '' || strlen($rel) > 400 || strpos($rel, "\0") !== false || $rel[0] === '/' || preg_match('~(?:^|/)\.\.(?:/|$)~', $rel) === 1) {
        return $fail('duong dan khong hop le');
    }
    $res = wpp_scan_last_result($rundir);
    $listed = false;
    foreach ((array) ($res['findings'] ?? []) as $f) {
        if (($f['file'] ?? null) === $rel && in_array($f['sev'] ?? '', ['critical', 'high', 'medium'], true)) { $listed = true; break; }
    }
    if (!$listed) {
        return $fail('file khong nam trong ket qua quet gan nhat - hay quet lai truoc');
    }
    $root = realpath($docroot);
    $abs = $root ? $root . '/' . $rel : false;
    if ($abs === false || is_link($abs) || !is_file($abs)) {
        return $fail('khong thay file (da bi xoa?)');
    }
    $real = realpath($abs);
    if ($real === false || strpos($real, $root . '/') !== 0) {
        return $fail('file nam ngoai thu muc website');
    }
    if (!is_dir($p['quarantine']) && !@mkdir($p['quarantine'], 0700, true)) {
        return $fail('khong tao duoc thu muc cach ly');
    }
    $sha = (string) @sha1_file($real);
    $id = date('Ymd-His', $now) . '-' . substr($sha, 0, 8);
    $dest = $p['quarantine'] . '/' . $id . '-' . preg_replace('/[^A-Za-z0-9._-]/', '_', substr(basename($rel), 0, 60)) . '.quar';
    if (!@rename($real, $dest)) {
        if (!@copy($real, $dest) || !@unlink($real)) {
            @unlink($dest);
            return $fail('khong di chuyen duoc file (quyen/dia day)');
        }
    }
    @chmod($dest, 0600);
    $idx = wpp_scan_quarantine_index($rundir);
    $idx[$id] = ['orig' => $rel, 'file' => basename($dest), 'at' => $now, 'sha1' => $sha, 'size' => (int) @filesize($dest)];
    wpp_scan_write($p['qindex'], json_encode($idx));
    return ['ok' => true, 'msg' => 'da cach ly', 'id' => $id];
}

/** Khoi phuc file da cach ly ve cho cu (khong ghi de file dang co). */
function wpp_scan_restore(string $docroot, string $rundir, string $id): array
{
    $p = wpp_scan_paths($rundir);
    $idx = wpp_scan_quarantine_index($rundir);
    if (!isset($idx[$id]) || preg_match('/^[0-9]{8}-[0-9]{6}-[0-9a-f]{8}$/', $id) !== 1) {
        return ['ok' => false, 'msg' => 'khong co muc cach ly nay'];
    }
    $e = $idx[$id];
    $src = $p['quarantine'] . '/' . basename((string) $e['file']);
    $root = realpath($docroot);
    $rel = (string) $e['orig'];
    if (!$root || !is_file($src) || strpos($rel, '..') !== false || $rel === '' || $rel[0] === '/') {
        return ['ok' => false, 'msg' => 'khong khoi phuc duoc (mat file/duong dan khong hop le)'];
    }
    $dest = $root . '/' . $rel;
    if (file_exists($dest)) {
        return ['ok' => false, 'msg' => 'o cu da co file - khong ghi de'];
    }
    $dir = dirname($dest);
    if (!is_dir($dir) || strpos((string) realpath($dir), $root) !== 0) {
        return ['ok' => false, 'msg' => 'thu muc cu khong con'];
    }
    if (!@rename($src, $dest) && (!@copy($src, $dest) || !@unlink($src))) {
        return ['ok' => false, 'msg' => 'khong di chuyen duoc'];
    }
    unset($idx[$id]);
    wpp_scan_write($p['qindex'], json_encode($idx));
    return ['ok' => true, 'msg' => 'da khoi phuc ' . $rel];
}

// ------------------------------------------------------------------------------------------------------------------
// CLI
// ------------------------------------------------------------------------------------------------------------------
if (PHP_SAPI === 'cli' && !defined('WPP_SCAN_AS_LIB') && isset($_SERVER['argv'][0]) && realpath($_SERVER['argv'][0]) === __FILE__) {
    $docroot = $_SERVER['argv'][1] ?? '';
    $rundir = $_SERVER['argv'][2] ?? '';
    $mode = $_SERVER['argv'][3] ?? 'scan';
    if ($docroot === '' || $rundir === '' || !is_dir($docroot) || !is_dir($rundir)) {
        fwrite(STDERR, "dung: php security-scan.php <docroot> <thu_muc_lamp-run> [scan|scan-fetch|accept|fetch-core]\n");
        exit(2);
    }
    if ($mode === 'accept') {
        echo wpp_scan_accept($rundir) ? "da dat lai moc\n" : "khong dat lai duoc moc\n";
        exit(0);
    }
    if ($mode === 'scan-fetch') {
        // lay checksum neu chua co/khong khop phien ban, roi quet (supervisor goi mode nay; mang loi khong lam hong lan quet)
        // toi da 1 lan thu/6 gio (ban nightly/ngon ngu khong ho tro se luon that bai - dung goi API moi gio)
        $pp = wpp_scan_paths($rundir);
        $wpi = wpp_scan_wp_info($docroot);
        $try = $pp['core'] . '.try';
        if ($wpi && wpp_scan_core_checksums($pp['core'], $wpi) === null && (!is_file($try) || (time() - (int) @filemtime($try)) > 21600)) {
            @touch($try);
            wpp_scan_fetch_core_checksums($docroot, $pp['core']);
        }
    }
    if ($mode === 'fetch-core') {
        $ok = wpp_scan_fetch_core_checksums($docroot, wpp_scan_paths($rundir)['core']);
        echo $ok ? "da luu checksum loi WordPress\n" : "khong tai duoc checksum (mang/phien ban khong chinh thuc)\n";
        exit($ok ? 0 : 1);
    }
    $managed = [];
    foreach (['wp-content/mu-plugins/wppocket-shield.php' => 'wppocket-shield-loader.php', 'wp-content/mu-plugins/wppocket-shield/shield.php' => 'wppocket-shield-logic.php',
                'wp-content/mu-plugins/wppocket-2fa.php' => 'wppocket-2fa-loader.php', 'wp-content/mu-plugins/wppocket-2fa/2fa.php' => 'wppocket-2fa-logic.php'] as $rel => $tpl) {
        if (is_file(__DIR__ . '/' . $tpl)) {
            $managed[$rel] = (string) sha1_file(__DIR__ . '/' . $tpl);
        }
    }
    $r = wpp_scan_run($docroot, $rundir, null, $managed);
    if (!empty($r['skipped'])) {
        exit(0);
    }
    echo sprintf("quet %d file trong %.1fs: %d nghiem trong, %d cao, %d trung binh\n", $r['files'], $r['duration'], $r['counts']['critical'], $r['counts']['high'], $r['counts']['medium']);
    exit(0);
}
