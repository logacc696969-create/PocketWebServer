<?php
require __DIR__ . '/auth.php';
require __DIR__ . '/totp-lib.php';

// (xem HANDOFF.md muc 10, de xuat DeepSeek muc A7) Mat khau 16 ky tu ngau
// nhien da manh, nhung neu bi lo (vd ai do chup duoc man hinh, xem trom luc
// dang go) la mat het - 2FA (ma 6 so doi moi 30 giay tu app Authenticator)
// la 1 lop bao ve THEM, khong thay the mat khau.
//
// AN TOAN CHONG TU KHOA MINH: chi thuc su BAT 2FA (tao file
// admin-totp-enabled.flag) SAU KHI nguoi dung nhap dung 1 ma 6 so tu chinh
// secret vua sinh - dam bao ho da cai dung vao app Authenticator TRUOC khi
// no tro thanh bat buoc. Neu van lo bi khoa (mat dien thoai chua
// Authenticator...), co nut "Tat 2FA khan cap" NGAY TRONG APP ANDROID (xem
// MainActivity.kt) - khong phu thuoc web/mat khau/ma TOTP nao ca, vi da co
// quyen mo app tren chinh dien thoai la da du tin cay.

$appHome = rtrim(getenv('APP_HOME') ?: '', '/');
$secretFile = $appHome . '/admin-totp-secret.txt';
$enabledFile = $appHome . '/admin-totp-enabled.flag';
$enabled = file_exists($enabledFile);
$message = '';
$messageIsError = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'generate' && !$enabled) {
        $newSecret = wp_pocket_generate_totp_secret();
        file_put_contents($secretFile, $newSecret, LOCK_EX);
        // Chi sinh secret MOI, CHUA bat - nguoi dung phai nhap dung 1 ma o
        // buoc duoi day moi thuc su bat.
    } elseif ($action === 'confirm' && !$enabled && is_readable($secretFile)) {
        $pendingSecret = trim(file_get_contents($secretFile));
        $code = (string) ($_POST['code'] ?? '');
        if ($pendingSecret !== '' && wp_pocket_totp_verify($pendingSecret, $code)) {
            file_put_contents($enabledFile, "1", LOCK_EX);
            $enabled = true;
            $message = 'Da BAT 2FA thanh cong. Tu lan dang nhap sau, can nhap them ma 6 so tu app Authenticator.';
        } else {
            $messageIsError = true;
            $message = 'Ma khong dung (hoac dong ho dien thoai/app Authenticator bi lech gio qua nhieu). Thu lai.';
        }
    } elseif ($action === 'disable' && $enabled) {
        @unlink($enabledFile);
        @unlink($secretFile);
        $enabled = false;
        $message = 'Da TAT 2FA. Chi con can mat khau de dang nhap.';
    }
}

$pendingSecret = (!$enabled && is_readable($secretFile)) ? trim(file_get_contents($secretFile)) : null;
$otpauthUri = $pendingSecret
    ? 'otpauth://totp/WP%20Pocket%20Server?secret=' . $pendingSecret . '&issuer=WP%20Pocket%20Server'
    : null;
?>
<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>2FA - Quan tri</title>
<style>
body{font-family:system-ui,sans-serif;max-width:420px;margin:60px auto;padding:0 20px}
a{color:#21759B}
.card{padding:16px;margin-bottom:12px;border:1px solid #ddd;border-radius:8px}
.msg{padding:10px 14px;border-radius:6px;margin-bottom:16px;font-size:14px}
.msg.ok{background:#d4edda;color:#155724}
.msg.err{background:#f8d7da;color:#721c24}
code{background:#f0f0f0;padding:2px 6px;border-radius:4px;font-size:15px;word-break:break-all}
input[type=text]{font-size:18px;letter-spacing:2px;padding:8px;width:100%;box-sizing:border-box;margin:8px 0}
button{padding:10px 16px;border:0;border-radius:6px;background:#21759B;color:#fff;font-size:14px;cursor:pointer}
button.danger{background:#c0392b}
</style></head><body>
<p><a href="index.php">&larr; Quay lai trang quan tri</a></p>
<h2>Xac thuc 2 buoc (2FA)</h2>
<?php if ($message): ?>
<div class="msg <?= $messageIsError ? 'err' : 'ok' ?>"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if ($enabled): ?>
  <div class="card">
    <b>2FA dang BAT.</b> Moi lan dang nhap can nhap them ma 6 so tu app Authenticator, ngoai mat khau.
  </div>
  <form method="post" onsubmit="return confirm('Tat 2FA? Tu do chi can mat khau la dang nhap duoc.');">
    <input type="hidden" name="action" value="disable">
    <button type="submit" class="danger">Tat 2FA</button>
  </form>
<?php elseif ($pendingSecret): ?>
  <div class="card">
    <p><b>Buoc 1:</b> Mo app Authenticator (Google Authenticator, Authy...) tren dien thoai khac (hoac chinh may nay neu dung app rieng) - chon "Nhap ma thu cong" (manual entry) va nhap:</p>
    <p><code><?= htmlspecialchars($pendingSecret) ?></code></p>
    <p style="font-size:12px;color:#666">(Trang nay khong tu sinh ma QR - nhap tay khoa tren vao app Authenticator, hau het app deu ho tro cach nay)</p>
  </div>
  <div class="card">
    <p><b>Buoc 2:</b> Nhap ma 6 so app vua tao ra de xac nhan da cai dung:</p>
    <form method="post">
      <input type="hidden" name="action" value="confirm">
      <input type="text" name="code" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="123456" required autofocus>
      <button type="submit">Xac nhan &amp; Bat 2FA</button>
    </form>
  </div>
<?php else: ?>
  <div class="card">
    <p>2FA dang TAT. Chi can mat khau la dang nhap duoc.</p>
    <form method="post">
      <input type="hidden" name="action" value="generate">
      <button type="submit">Bat 2FA</button>
    </form>
  </div>
<?php endif; ?>

<p style="font-size:12px;color:#666;margin-top:24px">
Lo dien thoai chua Authenticator, khong dang nhap duoc nua? Mo app WP Pocket Server tren chinh dien thoai nay, bam "Tat 2FA khan cap" - khong can mat khau hay ma nao ca.
</p>
</body></html>
