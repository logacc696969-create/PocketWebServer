<?php
/**
 * Xoa page cache cua nginx khi noi dung CONG KHAI thay doi (HANDOFF.md muc 1bg): bai viet them/sua/xoa, binh luan duoc duyet, doi
 * theme/plugin/menu/danh muc... hien ra ngay thay vi doi het TTL 2 phut. Khong co nginx cache dang bat thi khong lam gi.
 * Chi xoa FILE trong lamp-run/page-cache (khong xoa thu muc - nginx dang giu). Moi loi bi nuot (tinh nang phu).
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('wppocket_purge_page_cache')) {
    function wppocket_purge_page_cache()
    {
        static $done = false;
        if ($done) {
            return; // moi request chi xoa 1 lan du nhieu hook ban lien tuc
        }
        $done = true;
        $home = getenv('APP_HOME');
        if (!is_string($home) || $home === '') {
            return;
        }
        $dir = rtrim($home, '/') . '/lamp-run/page-cache';
        if (!is_dir($dir)) {
            return;
        }
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($it as $f) {
                if ($f->isFile() && !$f->isLink()) {
                    @unlink($f->getPathname());
                }
            }
        } catch (\Throwable $e) {
            // nuot
        }
    }
}

foreach (array(
    'save_post', 'deleted_post', 'trashed_post', 'untrashed_post',
    'wp_set_comment_status', 'edit_comment', 'deleted_comment',
    'switch_theme', 'activated_plugin', 'deactivated_plugin', 'customize_save_after', 'wp_update_nav_menu',
    'created_term', 'edited_term', 'delete_term',
) as $wppocketHook) {
    add_action($wppocketHook, 'wppocket_purge_page_cache');
}

// Binh luan moi chi doi trang cong khai khi duoc duyet ngay (approved = 1); cho duyet/spam thi khong can xoa
// (cung tranh viec nguoi la gui binh luan rac de lien tuc lam moi cache).
add_action('comment_post', function ($commentId, $approved) {
    if ((string) $approved === '1') {
        wppocket_purge_page_cache();
    }
}, 10, 2);
