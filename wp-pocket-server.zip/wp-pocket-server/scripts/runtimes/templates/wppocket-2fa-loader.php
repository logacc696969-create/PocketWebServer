<?php
/**
 * Plugin Name: WP Pocket - Dang nhap hai buoc (TOTP) cho WordPress
 * Description: Tuy chon CHO TUNG NGUOI DUNG: bat o trang Ho so, dung ung dung Authenticator (Google Authenticator, Aegis, Authy...). Khong ai bi ep. Xem docs/SECURITY.md.
 *
 * Tach 2 file CO CHU DICH (cung cach voi Shield/pagecache/images): file nap nay cuc ngan va duoc WordPress nap cho MOI request - mot loi cu phap o day
 * lam TRANG CA SITE. Logic that o 2fa.php, nap qua try/catch Throwable: loi trong do (ke ca ParseError) chi lam mat lop hai buoc, KHONG lam hong website.
 * (Han che: neu logic loi LUC DANG NHAP thi nguoi da bat hai buoc tam thoi chi can mat khau - dieu nay nhat quan voi muc tieu "khong khoa chu site".)
 * Tat khan cap: tao file lamp-run/twofa-off (khong can vao WordPress).
 */
if (!defined('ABSPATH')) {
    exit;
}
try {
    require_once __DIR__ . '/wppocket-2fa/2fa.php';
} catch (\Throwable $e) {
    // nuot: lop phu, khong duoc anh huong website
}
