<?php
require __DIR__ . '/auth.php';
phpinfo();
