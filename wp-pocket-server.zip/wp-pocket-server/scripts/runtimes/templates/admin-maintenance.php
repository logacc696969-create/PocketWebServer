<?php
// Che do bao tri - xem HANDOFF.md muc 10, de xuat DeepSeek muc A8.
// Bat = tao file $RUNDIR/maintenance-mode (chi 1 file rong, khong noi dung).
// nginx.conf.template (che do Full) va router-lite.php (che do Lite) deu
// kiem tra DUNG 1 file nay va deu bo qua /_admin/ - nen sua o day la du,
// khong can dong bo gi them.
require __DIR__ . '/auth.php';

$appHome = rtrim((string) getenv('APP_HOME'), '/');
$rundir = $appHome !== '' ? $appHome . '/lamp-run' : null;
$flagFile = $rundir !== null ? $rundir . '/maintenance-mode' : null;
$enabled = $flagFile !== null && file_exists($flagFile);
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($flagFile === null) {
        $error = 'Khong doc duoc APP_HOME - khong the bat/tat che do bao tri.';
    } elseif ($action === 'enable' && !$enabled) {
        if (!is_dir($rundir)) {
            @mkdir($rundir, 0777, true);
        }
        if (@touch($flagFile)) {
            $enabled = true;
            $message = 'Da BAT che do bao tri. Khach se thay trang "dang bao tri", ban van vao duoc _admin/ nhu binh thuong de lam viec.';
        } else {
            $error = 'Khong ghi duoc file co - kiem tra quyen ghi filesDir.';
        }
    } elseif ($action === 'disable' && $enabled) {
        if (@unlink($flagFile)) {
            $enabled = false;
            $message = 'Da TAT che do bao tri. Website hoat dong binh thuong tro lai voi khach.';
        } else {
            $error = 'Khong xoa duoc file co.';
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Che do bao tri</title>
<style>
body{font-family:system-ui,-apple-system,sans-serif;max-width:520px;margin:24px auto;padding:0 16px;color:#222}
h1{font-size:20px}
.back{display:inline-block;margin-bottom:16px;color:#666;text-decoration:none}
.status{padding:14px 16px;border-radius:10px;margin:16px 0;font-weight:600}
.status.on{background:#fdecea;color:#a11a0e;border:1px solid #f3b8b0}
.status.off{background:#e9f7ef;color:#1d7a3d;border:1px solid #bfe6cc}
.msg{padding:10px 14px;border-radius:8px;margin:12px 0;font-size:14px}
.msg.ok{background:#e9f7ef;color:#1d7a3d}
.msg.err{background:#fdecea;color:#a11a0e}
p.hint{color:#666;font-size:14px;line-height:1.5}
button{width:100%;padding:14px;border:0;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;color:#fff}
button.enable{background:#c0392b}
button.disable{background:#1d7a3d}
</style>
</head>
<body>
<a class="back" href="index.php">&larr; Quay lai</a>
<h1>Che do bao tri</h1>
<p class="hint">Khi bat, moi khach (tru ban vao qua _admin/) se thay 1 trang "dang bao tri" tinh thay vi website that. Dung khi ban dang cap nhat WordPress/plugin va chua muon khach thay giao dien do dang.</p>

<div class="status <?= $enabled ? 'on' : 'off' ?>">
    Trang thai hien tai: <?= $enabled ? 'DANG BAT (khach thay trang bao tri)' : 'DANG TAT (website hoat dong binh thuong)' ?>
</div>

<?php if ($message !== ''): ?>
<div class="msg ok"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>
<?php if ($error !== ''): ?>
<div class="msg err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<form method="post">
<?php if ($enabled): ?>
    <input type="hidden" name="action" value="disable">
    <button type="submit" class="disable">Tat che do bao tri</button>
<?php else: ?>
    <input type="hidden" name="action" value="enable">
    <button type="submit" class="enable">Bat che do bao tri</button>
<?php endif; ?>
</form>
</body>
</html>
