<?php
/**
 * Plugin Name: WP Pocket - toi uu anh khi tai len
 * Description: Anh JPEG tai len duoc tao them ban WebP (nhe hon), gioi han kich thuoc anh hien thi, chinh chat luong nen. Xem docs/IMAGE_OPTIMIZATION.md (HANDOFF.md muc 1bq-I). Logic o wppocket-images/optimize.php.
 *
 * Tach 2 file CO CHU DICH (cung cach voi wppocket-pagecache): file nap nay cuc ngan va duoc WordPress nap cho MOI request - mot loi cu phap o day lam
 * TRANG CA SITE. Logic that nam o optimize.php, nap qua try/catch Throwable: loi trong do (ke ca ParseError) chi lam mat tinh nang toi uu anh,
 * KHONG lam hong website.
 */
if (!defined('ABSPATH')) {
    exit;
}
try {
    require __DIR__ . '/wppocket-images/optimize.php';
} catch (\Throwable $e) {
    // nuot: tinh nang phu, khong duoc anh huong website
}
