<?php
/**
 * Thu vien TOTP thuan PHP (RFC 6238 / RFC 4226 - chuan Google Authenticator
 * dung), khong can thu vien ngoai. Xem HANDOFF.md muc 10, de xuat DeepSeek
 * muc A7.
 *
 * QUAN TRONG: thuat toan (base32 decode + HMAC-SHA1 dynamic truncation) da
 * duoc KIEM CHUNG rieng bang Python truoc khi viet file nay, doi chieu dung
 * ca 3 test vector chinh thuc trong RFC 6238 Appendix B (T=59/1111111109/
 * 1111111111) VA doi chieu voi thu vien base64.b32decode chuan cua Python -
 * khop 100% - day KHONG phai thuat toan tu doan, ma la chuyen dich lai
 * chinh xac tu logic da xac nhan dung. Van CHUA build-test tren dien thoai
 * that voi 1 app Authenticator that (Google Authenticator/Authy...) - neu
 * ma khong khop khi test that, kiem tra lai chenh lech GIO cua may (TOTP
 * RAT NHAY VOI GIO SAI - xem $window trong wp_pocket_totp_verify).
 */

function wp_pocket_base32_decode(string $b32): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $b32));
    $bits = '';
    foreach (str_split($b32) as $char) {
        $val = strpos($alphabet, $char);
        if ($val === false) {
            continue;
        }
        $bits .= str_pad(decbin($val), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    // Bo phan du cuoi KHONG du 8 bit (padding tu nhien cua base32, khong
    // phai loi) - vd 16 ky tu base32 = 80 bit = dung 10 byte, khong du.
    for ($i = 0; $i + 8 <= strlen($bits); $i += 8) {
        $bytes .= chr(bindec(substr($bits, $i, 8)));
    }
    return $bytes;
}

/** Sinh 1 khoa bi mat ngau nhien 16 ky tu base32 (80 bit entropy - du manh,
 * dung do dai chuan ma hau het app Authenticator ky vong). */
function wp_pocket_generate_totp_secret(): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = '';
    for ($i = 0; $i < 16; $i++) {
        $secret .= $alphabet[random_int(0, 31)];
    }
    return $secret;
}

/** Tinh ma 6 chu so tai 1 thoi diem cu the (mac dinh: bay gio). $secretBase32
 * la chuoi base32 (dang nguoi dung nhap vao app Authenticator). */
function wp_pocket_totp_code(string $secretBase32, ?int $timestamp = null): string
{
    $timestamp = $timestamp ?? time();
    $key = wp_pocket_base32_decode($secretBase32);
    $counter = intdiv($timestamp, 30);
    // 8 byte big-endian: 4 byte dau LUON la 0 (counter khong the vuot 32-bit
    // cho toi nam ~4147), pack('N', x) cua PHP la dung 4 byte big-endian.
    $counterBin = pack('N', 0) . pack('N', $counter);
    $hash = hash_hmac('sha1', $counterBin, $key, true); // raw 20 byte
    $offset = ord(substr($hash, -1)) & 0x0F;
    $truncated =
        ((ord($hash[$offset]) & 0x7F) << 24) |
        (ord($hash[$offset + 1]) << 16) |
        (ord($hash[$offset + 2]) << 8) |
        ord($hash[$offset + 3]);
    $code = $truncated % 1000000;
    return str_pad((string) $code, 6, '0', STR_PAD_LEFT);
}

/**
 * Tim buoc thoi gian (counter = floor(time/30)) ma nguoi dung nhap khop, cho phep lech +-$window buoc (30 giay/buoc) de bu dong ho
 * dien thoai/may chu lech nhau chut it (rat pho bien, KHONG phai lo hong). Tra ve counter khop hoac null. Tra counter (khong chi true/false)
 * de nguoi goi chan DUNG LAI ma da dung (xem wp_pocket_totp_consume) - HANDOFF.md muc 1br.
 */
function wp_pocket_totp_match(string $secretBase32, string $inputCode, int $window = 1): ?int
{
    $inputCode = preg_replace('/[^0-9]/', '', $inputCode);
    if (strlen($inputCode) !== 6) {
        return null;
    }
    $now = time();
    $found = null;
    for ($i = -$window; $i <= $window; $i++) {
        $expected = wp_pocket_totp_code($secretBase32, $now + ($i * 30));
        // Khong "return som" khi khop: thoi gian chay khong phu thuoc ma dung o buoc nao (hash_equals da la hang so thoi gian cho tung so sanh).
        if (hash_equals($expected, $inputCode) && $found === null) {
            $found = intdiv($now + ($i * 30), 30);
        }
    }
    return $found;
}

/** Kiem tra 1 ma nguoi dung nhap co dung khong (KHONG chan dung lai - dung wp_pocket_totp_match + wp_pocket_totp_consume o cong dang nhap). */
function wp_pocket_totp_verify(string $secretBase32, string $inputCode, int $window = 1): bool
{
    return wp_pocket_totp_match($secretBase32, $inputCode, $window) !== null;
}

/**
 * Danh dau buoc $step da duoc dung. Tra ve false neu buoc nay (hoac buoc CU HON) da duoc dung roi -> ma bi dung lai (replay) phai bi tu choi
 * (RFC 6238 muc 5.2: moi ma chi duoc xac nhan thanh cong MOT lan). Doc-so sanh-ghi trong 1 khoa doc quyen nen 2 request song song cung gui 1 ma
 * chi co 1 request thang. Khong co APP_HOME/khong ghi duoc => cho qua (khong khoa chu may ngoai vi loi dia).
 */
function wp_pocket_totp_consume(int $step): bool
{
    $home = getenv('APP_HOME');
    if (!$home) {
        return true;
    }
    $dir = rtrim($home, '/') . '/lamp-run';
    if (!is_dir($dir)) {
        return true;
    }
    $fh = @fopen($dir . '/admin-totp-last-step.txt', 'c+');
    if (!$fh) {
        return true;
    }
    if (!flock($fh, LOCK_EX)) {
        fclose($fh);
        return true;
    }
    $last = (int) trim((string) stream_get_contents($fh));
    $ok = $step > $last;
    if ($ok) {
        ftruncate($fh, 0);
        rewind($fh);
        fwrite($fh, (string) $step);
        fflush($fh);
    }
    flock($fh, LOCK_UN);
    fclose($fh);
    return $ok;
}
