<?php
/**
 * Thu vien TOTP thuan PHP (RFC 6238 / RFC 4226 - chuan Google Authenticator
 * dung), khong can thu vien ngoai. Xem HANDOFF.md muc 10, de xuat DeepSeek
 * muc A7.
 *
 * QUAN TRONG: thuat toan (base32 decode + HMAC-SHA1 dynamic truncation) da
 * duoc KIEM CHUNG rieng bang Python truoc khi viet file nay, doi chieu dung
 * ca 3 test vector chinh thuc trong RFC 6238 Appendix B (T=59/1111111109/
 * 1111111111) VA doi chieu voi thu vien base64.b32decode chuan cua Python -
 * khop 100% - day KHONG phai thuat toan tu doan, ma la chuyen dich lai
 * chinh xac tu logic da xac nhan dung. Van CHUA build-test tren dien thoai
 * that voi 1 app Authenticator that (Google Authenticator/Authy...) - neu
 * ma khong khop khi test that, kiem tra lai chenh lech GIO cua may (TOTP
 * RAT NHAY VOI GIO SAI - xem $window trong wp_pocket_totp_verify).
 */

function wp_pocket_base32_decode(string $b32): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $b32));
    $bits = '';
    foreach (str_split($b32) as $char) {
        $val = strpos($alphabet, $char);
        if ($val === false) {
            continue;
        }
        $bits .= str_pad(decbin($val), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    // Bo phan du cuoi KHONG du 8 bit (padding tu nhien cua base32, khong
    // phai loi) - vd 16 ky tu base32 = 80 bit = dung 10 byte, khong du.
    for ($i = 0; $i + 8 <= strlen($bits); $i += 8) {
        $bytes .= chr(bindec(substr($bits, $i, 8)));
    }
    return $bytes;
}

/** Sinh 1 khoa bi mat ngau nhien 16 ky tu base32 (80 bit entropy - du manh,
 * dung do dai chuan ma hau het app Authenticator ky vong). */
function wp_pocket_generate_totp_secret(): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = '';
    for ($i = 0; $i < 16; $i++) {
        $secret .= $alphabet[random_int(0, 31)];
    }
    return $secret;
}

/** Tinh ma 6 chu so tai 1 thoi diem cu the (mac dinh: bay gio). $secretBase32
 * la chuoi base32 (dang nguoi dung nhap vao app Authenticator). */
function wp_pocket_totp_code(string $secretBase32, ?int $timestamp = null): string
{
    $timestamp = $timestamp ?? time();
    $key = wp_pocket_base32_decode($secretBase32);
    $counter = intdiv($timestamp, 30);
    // 8 byte big-endian: 4 byte dau LUON la 0 (counter khong the vuot 32-bit
    // cho toi nam ~4147), pack('N', x) cua PHP la dung 4 byte big-endian.
    $counterBin = pack('N', 0) . pack('N', $counter);
    $hash = hash_hmac('sha1', $counterBin, $key, true); // raw 20 byte
    $offset = ord(substr($hash, -1)) & 0x0F;
    $truncated =
        ((ord($hash[$offset]) & 0x7F) << 24) |
        (ord($hash[$offset + 1]) << 16) |
        (ord($hash[$offset + 2]) << 8) |
        ord($hash[$offset + 3]);
    $code = $truncated % 1000000;
    return str_pad((string) $code, 6, '0', STR_PAD_LEFT);
}

/** Kiem tra 1 ma nguoi dung nhap co dung khong - cho phep lech +-1 buoc (30
 * giay) de bu dong ho dien thoai/may chu lech nhau chut it (rat pho bien,
 * KHONG phai lo hong bao mat - moi ma van chi dung dung 1 lan trong ~90
 * giay tong cong). */
function wp_pocket_totp_verify(string $secretBase32, string $inputCode, int $window = 1): bool
{
    $inputCode = preg_replace('/[^0-9]/', '', $inputCode);
    if (strlen($inputCode) !== 6) {
        return false;
    }
    $now = time();
    for ($i = -$window; $i <= $window; $i++) {
        $expected = wp_pocket_totp_code($secretBase32, $now + ($i * 30));
        if (hash_equals($expected, $inputCode)) {
            return true;
        }
    }
    return false;
}
