<?php
/**
 * Auto-Sleep - "danh thuc" MariaDB (xem HANDOFF.md, de xuat PDF vong 2 "Co
 * che Ngu dong thong minh"). nginx.conf tu dong rewrite MOI request .php
 * toi day KHI file "mariadb-asleep" ton tai (xem nginx.conf.template) - tuc
 * la start-lamp.sh vua tat MariaDB do khong ai truy cap 1 thoi gian (xem
 * start-lamp.sh). Chi CHAY khi AUTO_SLEEP_ENABLED=1 (nguoi dung tu bat).
 *
 * KHONG truy cap truc tiep tu ben ngoai duoc (nginx dat "internal;" cho
 * location nay - xem nginx.conf.template).
 */

set_time_limit(20); // du 1 khoang du de doi mariadbd len (~2-8s thuc te),
                     // khong phu thuoc gia tri max_execution_time chung.

$appHome = rtrim(getenv('APP_HOME') ?: '', '/');
$rundir = $appHome . '/lamp-run';
$sleepFlag = $rundir . '/mariadb-asleep';
$lockFile = $rundir . '/mariadb-waking.lock';
$socketPath = $rundir . '/mysql.sock';

// nginx truyen URI GOC (truoc khi bi rewrite toi day) qua fastcgi_param rieng
// "ORIGINAL_URI" (xem nginx.conf.template, location = /wake-mariadb.php) -
// $_SERVER['REQUEST_URI'] luc nay se la "/wake-mariadb.php", KHONG phai
// trang nguoi dung muon xem.
$originalUri = $_SERVER['ORIGINAL_URI'] ?? '/';
if ($originalUri === '' || $originalUri[0] !== '/') {
    $originalUri = '/'; // phong ngua header bi thao tung/thieu, khong redirect ra ngoai site
}

/** Kiem tra MariaDB da THAT SU nhan ket noi duoc chua (khong chi la file
 * socket ton tai - giua luc socket vua tao va luc mariadbd san sang nhan
 * dang nhap van co 1 khoang tre ngan).
 *
 * Dung DUNG 1 kieu goi mysqli_connect() nhu wp-config.php.template dang
 * dung that cho ca website (DB_HOST dang "localhost:duong_dan_socket") -
 * KHONG dung kieu tham so $socket rieng (`mysqli_connect(null,...,$socket)`)
 * du ca hai deu dung theo tai lieu PHP, vi kieu nay chua co bang chung hoat
 * dong that trong chinh du an nay, con kieu "localhost:socket" thi CHAC
 * CHAN hoat dong (WordPress dang dung moi ngay).
 */
function mariadbReady(string $socketPath): bool
{
    if (!file_exists($socketPath)) {
        return false;
    }
    $mysqli = @mysqli_connect('localhost:' . $socketPath, 'wordpress', 'wordpress', 'wordpress');
    if ($mysqli instanceof mysqli) {
        mysqli_close($mysqli);
        return true;
    }
    return false;
}

function serveWaitPage(string $redirectTo): void
{
    http_response_code(503);
    header('Retry-After: 2');
    header('Content-Type: text/html; charset=utf-8');
    $safeUrl = htmlspecialchars($redirectTo, ENT_QUOTES);
    echo '<!doctype html><html><head><meta charset="utf-8">'
        . '<meta http-equiv="refresh" content="2;url=' . $safeUrl . '">'
        . '<title>Dang khoi dong...</title>'
        . '<style>body{font-family:sans-serif;text-align:center;padding-top:15vh;color:#555}</style>'
        . '</head><body>'
        . '<p>Website vua duoc "danh thuc" sau mot thoi gian khong co ai truy cap.</p>'
        . '<p>Trang se tu tai lai sau giay lat...</p>'
        . '</body></html>';
}

if (!file_exists($sleepFlag)) {
    // Nguoi khac vua danh thuc xong (hoac co dieu kien hiem gap) - quay lai ngay
    header('Location: ' . $originalUri, true, 302);
    exit;
}

// Khoa nhe (advisory, khong phai co che chinh chong dung do - ban than
// mariadbd TU CHOI khoi dong 2 lan tren cung 1 datadir/socket, day chi giup
// giam so lan spawn thua + log rac khi nhieu nguoi cung ghe dung luc website
// vua "thuc giac"). fopen(..., 'x') tao file THAT BAI ngay neu da ton tai -
// dam bao chi 1 request thuc su di spawn, cac request khac chi cho.
$lockHandle = @fopen($lockFile, 'x');
$isLockOwner = $lockHandle !== false;

$ready = false;

if ($isLockOwner) {
    try {
        $cmd = 'nohup /system/bin/sh ' . escapeshellarg($rundir . '/wake-mariadb.sh')
            . ' > /dev/null 2>&1 & echo $!';
        $pidOutput = trim((string) @shell_exec($cmd));
        $pid = (int) $pidOutput;
        if ($pid > 0) {
            @file_put_contents($rundir . '/mariadb-new-pid', (string) $pid);
        }

        for ($i = 0; $i < 16; $i++) { // toi da ~8s (16 x 0.5s)
            usleep(500000);
            if (mariadbReady($socketPath)) {
                $ready = true;
                break;
            }
        }

        if ($ready) {
            @unlink($sleepFlag);
        }
    } finally {
        @fclose($lockHandle);
        @unlink($lockFile);
    }
} else {
    // Request khac dang lo spawn roi - doi ngan 1 chut xem co kip xong khong,
    // khong thi rot ve trang cho (nguoi dung se duoc refresh lai sau).
    for ($i = 0; $i < 6; $i++) { // toi da ~3s
        usleep(500000);
        if (!file_exists($sleepFlag)) {
            $ready = true;
            break;
        }
    }
}

if ($ready) {
    header('Location: ' . $originalUri, true, 302);
    exit;
}

serveWaitPage($originalUri);
