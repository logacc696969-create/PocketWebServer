<?php
/**
 * Cổng xác thực cho các công cụ quản trị (_admin/db.php, _admin/files.php).
 * Được require ở ĐẦU mỗi file quản trị (xem scripts/lib/admin_tools.sh).
 *
 * Mật khẩu KHÔNG hardcode, KHÔNG có giá trị mặc định - được app Android
 * (ServerForegroundService.kt) sinh ngẫu nhiên (SecureRandom) lúc server
 * chạy lần đầu trên từng máy, ghi vào $APP_HOME/admin-password.txt. Người
 * dùng xem mật khẩu này trong chính app, mục "Mật khẩu quản trị".
 *
 * Lớp bảo vệ IP-LAN: bình thường nginx.conf.template (location /_admin/)
 * đã chặn IP ngoài LAN trước khi request chạm tới PHP. NHƯNG ở chế độ
 * Dual-Mode PHP-Lite (xem HANDOFF.md mục 1e) không có nginx — `php -S` tự
 * phục vụ trực tiếp, không có lớp chặn IP nào cả nếu không tự làm ở đây.
 * Nên kiểm tra lại NGAY TRONG PHP (dùng chung cho CẢ 2 chế độ — ở chế độ
 * đầy đủ, đây là lớp phòng thủ kép vô hại, phòng khi nginx.conf lỡ bị sửa
 * sai sau này) thay vì chỉ dựa vào nginx.
 *
 * 2FA (xem HANDOFF.md muc 10, de xuat DeepSeek muc A7, va totp-lib.php cho
 * chi tiet thuat toan): lop bao ve THEM, tuy chon (bat/tat qua 2fa.php) -
 * yeu cau them 1 ma 6 so tu app Authenticator SAU KHI mat khau da dung.
 */

// require_once: 2fa.php va cac trang khac cung nap totp-lib.php - xem chu thich o 2fa.php.
require_once __DIR__ . '/totp-lib.php';

/**
 * Tach PHIEN PHP RIENG cho cong cu ben thu 3 (Adminer db.php, Tiny File Manager
 * files.php) - duoc admin_tools.sh/inject_require.php chen goi ngay SAU dong
 * "require auth.php" (xem HANDOFF.md muc 1aw).
 *
 * LOI THAT da tai hien (nhieu phien, PHP 8): auth.php goi session_start() TRUOC nen
 * session_name() rieng cua tung cong cu bi bo qua, ca hai dung CHUNG 1 phien PHP va cung
 * khoa $_SESSION['token'] voi dinh dang KHAC NHAU (Adminer: so nguyen rand(1,1e6);
 * TFM: chuoi 64 hex). Hau qua: mo TFM truoc roi Adminer -> Adminer Fatal "Unsupported
 * operand types: int ^ string" (4/10 phien - khi chuoi hex bat dau bang chu cai);
 * mo Adminer truoc roi TFM -> moi hanh dong POST cua TFM (xoa/doi ten/upload...) tra 500.
 *
 * Cach sua: dong phien cua cong (da luu last_activity...), mo phien KHAC TEN cho
 * cong cu. CAM BAY: sau session_write_close() thi session_id() VAN GIU id cu, nen chi
 * doi session_name() la van tro vao CUNG file phien (cung du lieu, loi y nguyen) - phai
 * dat session_id() tuong minh (cookie cua chinh cong cu, hoac id moi). Adminer chi tu
 * mo phien neu !defined("SID"), TFM chi neu session_status()==NONE: ca hai deu dung phien
 * dang mo nay va luu duoc.
 */
function wp_pocket_isolate_tool_session(string $file): void
{
    $name = 'wpp_' . preg_replace('/[^A-Za-z0-9]/', '', basename($file, '.php'));
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    session_name($name);
    $cookie = isset($_COOKIE[$name]) && is_string($_COOKIE[$name]) ? $_COOKIE[$name] : '';
    session_id(preg_match('/^[A-Za-z0-9,-]{22,128}$/', $cookie) ? $cookie : session_create_id());
    session_start();
}

function wp_pocket_ip_in_private_lan(string $ip): bool
{
    $ranges = [
        ['192.168.0.0', 16],
        ['10.0.0.0', 8],
        ['172.16.0.0', 12],
    ];
    $ipLong = ip2long($ip);
    if ($ipLong === false) {
        return false; // IPv6 hoac khong hop le - tu choi cho chac (giong hanh vi nginx hien tai, cung chi allow IPv4)
    }
    foreach ($ranges as [$base, $bits]) {
        $baseLong = ip2long($base);
        $mask = -1 << (32 - $bits);
        if (($ipLong & $mask) === ($baseLong & $mask)) {
            return true;
        }
    }
    return false;
}

/**
 * G7 (PDF 2, HANDOFF 1bl): $ip co khop 1 muc nao khong. Muc = IPv4 don, IPv4/CIDR (0..32) hoac IPv6 don (so sanh nhi phan;
 * KHONG ho tro CIDR IPv6 - _admin/ vao qua LAN IPv4 la chinh). Muc hong bi BO QUA (khong nem loi, khong khop).
 */
function wp_pocket_ip_matches(string $ip, array $entries): bool
{
    $ipBin = @inet_pton($ip);
    if ($ipBin === false) {
        return false;
    }
    foreach ($entries as $e) {
        if (!is_string($e)) {
            continue;
        }
        $e = trim($e);
        if (strpos($e, '/') !== false) {
            [$base, $bits] = explode('/', $e, 2);
            $baseBin = @inet_pton($base);
            if ($baseBin === false || strlen($baseBin) !== 4 || strlen($ipBin) !== 4 || !ctype_digit($bits) || (int) $bits > 32) {
                continue;
            }
            $n = (int) $bits;
            $mask = $n === 0 ? 0 : ((-1 << (32 - $n)) & 0xFFFFFFFF);
            $a = unpack('N', $ipBin)[1];
            $b = unpack('N', $baseBin)[1];
            if (($a & $mask) === ($b & $mask)) {
                return true;
            }
        } else {
            $eBin = @inet_pton($e);
            if ($eBin !== false && $eBin === $ipBin) {
                return true;
            }
        }
    }
    return false;
}

/** Nap lamp-run/admin-ip-rules.json -> ['mode' => off|allow|deny, 'entries' => [...]]. File thieu/hong/khong hop le => TAT (khong tu khoa). */
function wp_pocket_ip_rules_load(): array
{
    $off = ['mode' => 'off', 'entries' => []];
    $home = getenv('APP_HOME');
    if (!$home) {
        return $off;
    }
    $f = rtrim($home, '/') . '/lamp-run/admin-ip-rules.json';
    if (!is_file($f)) {
        return $off;
    }
    $raw = @file_get_contents($f, false, null, 0, 65536);
    $d = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($d) || !in_array($d['mode'] ?? '', ['allow', 'deny'], true) || !is_array($d['entries'] ?? null)) {
        return $off;
    }
    $entries = [];
    foreach ($d['entries'] as $e) {
        if (is_string($e) && strlen($e) <= 64) {
            $entries[] = $e;
        }
    }
    $entries = array_slice($entries, 0, 100);
    // Che do "allow" ma danh sach rong khong the la y dinh (se khoa tat ca) -> coi nhu TAT.
    if ($d['mode'] === 'allow' && !$entries) {
        return $off;
    }
    return ['mode' => $d['mode'], 'entries' => $entries];
}

$remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '';
if (!wp_pocket_ip_in_private_lan($remoteAddr)) {
    http_response_code(403);
    echo '<p>Trang quan tri chi vao duoc qua mang LAN (WiFi/mang noi bo), khong qua URL cong khai.</p>';
    exit;
}

/**
 * Host hop le cho trang quan tri (HANDOFF.md muc 1br) - chong DNS REBINDING: trang web doc hai mo tren Internet doi ban ghi DNS cua
 * "evil.example" sang IP LAN cua dien thoai (192.168.x.x); trinh duyet cua BAN (dang o trong LAN) gui request toi _admin/ voi
 * "Host: evil.example", qua kiem tra IP LAN o tren (vi nguon la may ban), roi doc ket qua nhu cung nguon goc. Chi nhan Host la:
 * dia chi IP (v4/v6), "localhost", ten 1 nhan (mDNS/NetBIOS), duoi .local/.lan/.localdomain/.home.arpa/.internal, hoac ten chu may TU KHAI BAO
 * trong lamp-run/admin-allowed-hosts.txt (moi dong 1 ten). Header Host rong (HTTP/1.0, curl) cho qua: trinh duyet luon gui Host.
 */
function wp_pocket_host_is_allowed(string $hostHeader, array $extra = []): bool
{
    $h = strtolower(trim($hostHeader));
    if ($h === '') {
        return true;
    }
    if (strlen($h) > 255) {
        return false;
    }
    if ($h[0] === '[') {                                  // [IPv6]:cong
        $end = strpos($h, ']');
        if ($end === false) {
            return false;
        }
        $rest = substr($h, $end + 1);
        return filter_var(substr($h, 1, $end - 1), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false
            && ($rest === '' || preg_match('/^:[0-9]{1,5}$/', $rest) === 1);
    }
    $host = $h;
    $colon = strrpos($h, ':');
    if ($colon !== false) {
        $port = substr($h, $colon + 1);
        if (!ctype_digit($port) || strlen($port) > 5) {
            return false;
        }
        $host = substr($h, 0, $colon);
    }
    if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false || $host === 'localhost') {
        return true;
    }
    if (preg_match('/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*\.?$/', $host) !== 1) {
        return false;
    }
    $host = rtrim($host, '.');
    if (strpos($host, '.') === false) {
        return true;                                      // ten 1 nhan: khong the la ten mien cong khai
    }
    foreach (['.local', '.lan', '.localdomain', '.home.arpa', '.internal'] as $suffix) {
        if (str_ends_with($host, $suffix)) {
            return true;
        }
    }
    return in_array($host, $extra, true);
}

function wp_pocket_admin_extra_hosts(): array
{
    $home = getenv('APP_HOME');
    $f = $home ? rtrim($home, '/') . '/lamp-run/admin-allowed-hosts.txt' : null;
    $raw = ($f && is_readable($f)) ? @file_get_contents($f, false, null, 0, 8192) : '';
    $out = [];
    foreach (preg_split('/\R/', (string) $raw) as $line) {
        $line = strtolower(trim($line));
        if ($line !== '' && $line[0] !== '#' && strlen($line) <= 255) {
            $out[] = $line;
        }
    }
    return array_slice($out, 0, 20);
}

$wpPocketHostHeader = (string) ($_SERVER['HTTP_HOST'] ?? '');
if (!wp_pocket_host_is_allowed($wpPocketHostHeader, wp_pocket_admin_extra_hosts())) {
    wp_pocket_session_audit('chan Host la: ' . substr((string) preg_replace('/[^A-Za-z0-9.:\[\]-]/', '?', $wpPocketHostHeader), 0, 80) . ' (nghi DNS rebinding)');
    http_response_code(400);
    echo '<p>Ten truy cap (Host) khong hop le cho trang quan tri. Hay mo bang dia chi IP cua dien thoai (vd http://192.168.1.5:8080/_admin/). Neu ban dung ten rieng, them vao lamp-run/admin-allowed-hosts.txt.</p>';
    exit;
}

// G7: luat IP tuy chon (mac dinh TAT) - chay SAU kiem tra LAN, TRUOC session/dang nhap => IP bi chan khong cham duoc form dang nhap.
// Tu khoa minh: nut "Xoa luat IP _admin" tren man hinh chinh cua app xoa file luat (khong can vao duoc _admin/).
$wpPocketIpRules = wp_pocket_ip_rules_load();
if ($wpPocketIpRules['mode'] !== 'off') {
    $wpPocketIpHit = wp_pocket_ip_matches($remoteAddr, $wpPocketIpRules['entries']);
    if (($wpPocketIpRules['mode'] === 'allow' && !$wpPocketIpHit) || ($wpPocketIpRules['mode'] === 'deny' && $wpPocketIpHit)) {
        wp_pocket_session_audit('chan theo luat IP (' . $wpPocketIpRules['mode'] . ')');
        http_response_code(403);
        echo '<p>Dia chi IP cua ban bi chan boi luat IP cua trang quan tri. Chu may co the xoa luat bang nut "Xoa luat IP _admin" trong app.</p>';
        exit;
    }
}

// Cookie phien: JS khong doc duoc, SameSite=Lax, khong chap nhan ma phien do ke tan cong dat san. php.ini.template da dat cung gia tri;
// dat lai o day vi che do Lite/ban build khac co the khong nap php.ini (phong thu hai lop, vo hai khi trung).
if (session_status() !== PHP_SESSION_ACTIVE) {
    @ini_set('session.use_strict_mode', '1');
    @session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
}
session_start();

// --- Session timeout (xem HANDOFF.md muc 10, de xuat DeepSeek muc G5) ---
// Truoc day session song MAI MAI (PHP mac dinh - session.gc_maxlifetime
// thuong la 1440s NHUNG chi anh huong khi GC don rac chay, khong dam bao
// het han dung luc) - neu ai do de dien thoai/may tinh da dang nhap
// _admin/ mo cong khai (quen dong tab, cho muon may...), phien do song
// VO THOI HAN. "Sliding window" - moi request THANH CONG lai gia han them
// 30 phut, khong phai "toi da 30 phut du dang dung lien tuc".
const WP_POCKET_SESSION_IDLE_SECONDS = 1800; // 30 phut
if (!empty($_SESSION['wp_pocket_admin_authed'])) {
    $lastActivity = $_SESSION['wp_pocket_last_activity'] ?? 0;
    if (time() - $lastActivity > WP_POCKET_SESSION_IDLE_SECONDS) {
        // Het han that su - huy sach session cu, mo session MOI (rong) de
        // phan con lai cua file (form dang nhap) chay binh thuong.
        $_SESSION = [];
        session_destroy();
        session_start();
    } else {
        $_SESSION['wp_pocket_last_activity'] = time();
    }
}

// --- QUAN LY PHIEN: so dang ky + huy phien khi doi mat khau (HANDOFF.md muc 1bc; PDF "chat luong tinh phi" G2) ---
// LOI THAT da xac nhan o code truoc 1bc: (1) doi mat khau (app Android ghi de admin-password.txt) KHONG huy phien dang nhap cu
// - chinh comment trong MainActivity.kt ghi "phien cu van con hieu luc ... khong phai loi" - nhung phien nay "truot" 30 phut
// moi request nen ke da dang nhap o lai VO THOI HAN du chu may da doi mat khau vi nghi lo; (2) _admin/ khong co cach DANG XUAT;
// (3) khong biet thiet bi nao dang dang nhap. Cach lam (khong them DB, 1 file JSON nho + flock nhu bo dem khoa IP):
//   * Moi lan dang nhap thanh cong: sinh "tag" ngau nhien, ghi vao so lam-run/admin-sessions.json {tag: {ip, ua, since, last}},
//     va luu vao PHIEN PHP: tag + DAU VAN TAY mat khau (HMAC-SHA256 cua mat khau hien tai).
//   * MOI request da dang nhap: dau van tay khac (mat khau da doi) HOAC tag khong con trong so (bi thu hoi) => huy phien.
//   * Thu hoi 1 phien / tat ca phien khac / dang xuat: xem sessions.php (chi xoa muc khoi so, khong cham file phien PHP).
// Fail-OPEN co chu y khi KHONG ghi duoc so (dia day/khong co APP_HOME): tag = '-' => bo qua kiem so (tranh khoa chu may ngoai
// trang quan tri dung luc can don dep dia). Phien tao TRUOC khi nang cap (khong co dau van tay) bi buoc dang nhap lai 1 lan.
// LUU Y: hang so phai khai bao TRUOC lenh `return` som o duoi (const chay luc runtime, khac function duoc hoist).
const WP_POCKET_SESSION_REGISTRY_MAX = 20;   // toi da so phien luu trong so (cu nhat bi bo)
const WP_POCKET_SESSION_TOUCH_SECONDS = 60;  // chi ghi lai "hoat dong lan cuoi" vao so toi da 1 lan/phut/phien (do ghi dia)

function wp_pocket_session_registry_file(): ?string
{
    $home = getenv('APP_HOME');
    return $home ? rtrim($home, '/') . '/lamp-run/admin-sessions.json' : null;
}

/**
 * Bao cho object-cache.php (APCu) biet "du lieu WordPress vua bi doi tu ngoai pool php-fpm, hay xoa cache" - xem chu thich
 * dai o object-cache.php::syncEpoch() va HANDOFF.md muc 1bd. Ghi NGUYEN TU (tep tam + doi ten) 1 chuoi duy nhat moi.
 * Goi bang register_shutdown_function() o cac trang co the doi du lieu (de chay SAU khi lenh xong, ke ca khi exit/loi).
 */
function wp_pocket_bump_object_cache_epoch(): void
{
    $home = getenv('APP_HOME');
    if (!$home) return;
    $dir = rtrim($home, '/') . '/lamp-run';
    if (!is_dir($dir)) return;
    $tmp = $dir . '/object-cache-epoch.tmp.' . getmypid();
    if (@file_put_contents($tmp, hrtime(true) . '-' . getmypid() . '-' . bin2hex(random_bytes(4))) !== false) {
        @rename($tmp, $dir . '/object-cache-epoch');
    }
    @unlink($tmp);
}

/** Dau van tay mat khau: doi mat khau => doi gia tri => moi phien cu mat hieu luc. Null neu khong doc duoc mat khau. */
function wp_pocket_password_fingerprint(): ?string
{
    $home = getenv('APP_HOME');
    $f = $home ? rtrim($home, '/') . '/admin-password.txt' : null;
    if (!$f || !is_readable($f)) return null;
    $pw = trim((string) @file_get_contents($f));
    return $pw === '' ? null : hash_hmac('sha256', 'wp-pocket-admin-session-v1', $pw);
}

function wp_pocket_session_audit(string $event): void
{
    $home = getenv('APP_HOME');
    if (!$home) return;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '?';
    @file_put_contents(rtrim($home, '/') . '/lamp-run/admin-audit.log', date('Y-m-d H:i:s') . " ip=$ip $event\n", FILE_APPEND | LOCK_EX);
}

/** Doc so phien (da cat muc het han). Tra ve [] neu khong co/hong. */
function wp_pocket_sessions_read(): array
{
    $f = wp_pocket_session_registry_file();
    if (!$f || !is_file($f)) return [];
    $fh = @fopen($f, 'r');
    if (!$fh) return [];
    flock($fh, LOCK_SH);
    $raw = stream_get_contents($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    $d = json_decode((string) $raw, true);
    return is_array($d) ? $d : [];
}

/**
 * Doc-sua-ghi so phien trong MOT khoa doc quyen. $fn(array $reg): array tra ve so MOI. Tra ve false neu khong ghi duoc.
 * Tu dong bo muc khong con hoat dong qua WP_POCKET_SESSION_IDLE_SECONDS (phien do da het han that) va cat con toi da MAX muc.
 */
function wp_pocket_sessions_mutate(callable $fn): bool
{
    $f = wp_pocket_session_registry_file();
    if (!$f) return false;
    $fh = @fopen($f, 'c+');
    if (!$fh) return false;
    if (!flock($fh, LOCK_EX)) { fclose($fh); return false; }
    $d = json_decode((string) stream_get_contents($fh), true);
    $reg = $fn(is_array($d) ? $d : []);
    $now = time();
    foreach ($reg as $tag => $row) {
        if (!is_array($row) || ($now - (int) ($row['last'] ?? 0)) > WP_POCKET_SESSION_IDLE_SECONDS) unset($reg[$tag]);
    }
    if (count($reg) > WP_POCKET_SESSION_REGISTRY_MAX) {
        uasort($reg, fn($a, $b) => ((int) ($b['last'] ?? 0)) <=> ((int) ($a['last'] ?? 0)));
        $reg = array_slice($reg, 0, WP_POCKET_SESSION_REGISTRY_MAX, true);
    }
    $ok = ftruncate($fh, 0) && rewind($fh) && fwrite($fh, json_encode($reg)) !== false && fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return (bool) $ok;
}

/** Goi NGAY SAU KHI xac thuc thanh cong (sau session_regenerate_id): gan tag + dau van tay vao phien PHP, ghi vao so. */
function wp_pocket_session_register(): void
{
    $tag = bin2hex(random_bytes(8));
    $ua = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200);
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    $now = time();
    $ok = wp_pocket_sessions_mutate(function (array $reg) use ($tag, $ua, $ip, $now) {
        $reg[$tag] = ['ip' => $ip, 'ua' => $ua, 'since' => $now, 'last' => $now];
        return $reg;
    });
    $_SESSION['wp_pocket_tag'] = $ok ? $tag : '-';   // '-' = khong ghi duoc so => bo qua kiem so (fail-open, xem tren)
    $_SESSION['wp_pocket_pwfp'] = wp_pocket_password_fingerprint() ?? '';
}

/** null = phien hop le; chuoi = ly do phai huy. Cung cap nhat "hoat dong lan cuoi" (gioi han tan suat ghi). */
function wp_pocket_session_invalid_reason(): ?string
{
    $fp = wp_pocket_password_fingerprint();
    $stored = (string) ($_SESSION['wp_pocket_pwfp'] ?? '');
    if ($fp !== null) {
        if ($stored === '') return 'phien cu (truoc khi co quan ly phien) - dang nhap lai';
        if (!hash_equals($fp, $stored)) return 'mat khau quan tri da doi';
    }
    $tag = (string) ($_SESSION['wp_pocket_tag'] ?? '');
    if ($tag === '-') return null;                       // luc dang nhap khong ghi duoc so (fail-open)
    if ($tag === '' ) return 'phien khong co the dinh danh - dang nhap lai';
    if (!wp_pocket_session_registry_file()) return null; // khong co APP_HOME (khong the co so)
    $reg = wp_pocket_sessions_read();
    if (!isset($reg[$tag])) return 'phien da bi thu hoi';
    if (time() - (int) ($reg[$tag]['last'] ?? 0) >= WP_POCKET_SESSION_TOUCH_SECONDS) {
        wp_pocket_sessions_mutate(function (array $r) use ($tag) { if (isset($r[$tag])) $r[$tag]['last'] = time(); return $r; });
    }
    return null;
}

if (!empty($_SESSION['wp_pocket_admin_authed'])) {
    $wpPocketWhy = wp_pocket_session_invalid_reason();
    if ($wpPocketWhy !== null) {
        wp_pocket_session_audit('phien bi huy: ' . $wpPocketWhy);
        $_SESSION = [];
        session_destroy();
        session_start();
    }
}

// Adminer (db.php) ghi SQL thang vao DB: moi POST co the doi du lieu WordPress ma cache APCu cua php-fpm khong biet
// (vd sua siteurl/home trong wp_options - cach sua URL kinh dien). Bump SAU request: thua (xoa cache oan khi chi dang nhap/xem)
// con hon thieu (site hien du lieu cu). Chi khi phien hop le (khach chua dang nhap khong the kich hoat viec xoa cache).
if (!empty($_SESSION['wp_pocket_admin_authed']) && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
    && basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')) === 'db.php') {
    register_shutdown_function('wp_pocket_bump_object_cache_epoch');
}

// G4 (1bl): vet TRUY CAP Adminer (db.php) va Tiny File Manager (files.php) - 2 cong cu quyen luc cao nhung co giao thuc rieng
// (nhieu POST/GET moi thao tac) nen KHONG ghi tung truy van/thao tac, chi ghi "co nguoi mo cong cu" toi da 1 dong / 10 phut / phien.
// Chay khi auth.php van dang giu phien cong (wp_pocket_isolate_tool_session duoc goi SAU require nay) nen moc thoi gian duoc luu.
if (!empty($_SESSION['wp_pocket_admin_authed'])) {
    $wppTool = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    if ($wppTool === 'db.php' || $wppTool === 'files.php') {
        $wppToolKey = 'wp_pocket_audit_tool_' . $wppTool;
        if (time() - (int) ($_SESSION[$wppToolKey] ?? 0) >= 600) {
            $_SESSION[$wppToolKey] = time();
            wp_pocket_session_audit('truy cap ' . $wppTool . ($wppTool === 'db.php' ? ' (Adminer)' : ' (File Manager)') . ' - ghi toi da 1 lan/10 phut, khong ghi tung thao tac');
        }
    }
}

// --- CSRF token dung chung cho moi form POST trong _admin/ (xem
// HANDOFF.md muc 10, de xuat DeepSeek muc G5) - dat o day (file auth.php,
// duoc require DAU TIEN boi MOI trang quan tri) de dung 1 token CHUNG cho
// ca phien, khong can moi trang tu sinh rieng. Ham khai bao o day VAN
// dung duoc tu file goi (index.php, install-wp.php...) du auth.php co the
// "return" som ben duoi - PHP dang ky function ngay luc include/require,
// khong phu thuoc dong "return" co chay toi hay khong.
function wp_pocket_csrf_token(): string
{
    if (empty($_SESSION['wp_pocket_csrf'])) {
        $_SESSION['wp_pocket_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['wp_pocket_csrf'];
}

/** In san 1 the <input type="hidden"> - dan vao ben trong <form>...</form>. */
function wp_pocket_csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(wp_pocket_csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

/** Goi o DAU khoi xu ly POST cua tung trang - tra ve false neu token sai/thieu. */
function wp_pocket_csrf_verify(): bool
{
    $token = (string) ($_POST['csrf_token'] ?? '');
    $ok = !empty($_SESSION['wp_pocket_csrf']) && $token !== '' && hash_equals($_SESSION['wp_pocket_csrf'], $token);
    if ($ok) {
        // G4 (PDF 2, HANDOFF 1bk): ghi vet THAO TAC nhay cam (bat/tat bao tri, 2FA, safe mode, staging, WP-CLI, cai WP, rollback core...).
        // Moi trang POST deu goi ham nay DUNG 1 LAN o dau khoi xu ly => 1 diem ghi chung, khong sua tung trang. CHI ghi ten trang +
        // gia tri `action` (da loc ve [a-z0-9_-], toi da 24 ky tu): KHONG ghi gia tri truong khac (co the chua mat khau/lenh/token).
        // Dong khong bat dau bang "dang nhap sai" / "sai ma 2FA" / "BI KHOA TAM" nen khong lam sai bo dem canh bao (MonitorLogic.scanAudit).
        $rawAct = $_POST['action'] ?? '';   // truong dang mang (action[]=x) -> bo qua, tranh "Array to string conversion"
        $act = is_string($rawAct) ? substr((string) preg_replace('/[^a-z0-9_-]/i', '', $rawAct), 0, 24) : '';
        wp_pocket_session_audit('thao tac ' . basename((string) ($_SERVER['SCRIPT_NAME'] ?? '?')) . ($act !== '' ? ' action=' . $act : ''));
    }
    return $ok;
}

if (!empty($_SESSION['wp_pocket_admin_authed'])) {
    return; // da dang nhap trong phien nay VA CHUA het han, cho qua
}

// --- Chong do mat khau + nhat ky dang nhap (xem HANDOFF.md muc 10, de xuat
// DeepSeek muc A6/G4) ---
// Truoc day chi co DUY NHAT 1 lop mat khau, khong gioi han so lan thu, khong
// ghi lai ai da thu dang nhap - neu mat khau 16 ky tu bi lo (vd chup man
// hinh), khong co gi ngan ke tan cong do lai bang script tu dong, va chu
// nha cung khong biet co ai dang do hay khong. Dung file JSON don gian
// (KHONG can them SQLite/DB - cong cu 1-chu-so-huu, du du lieu nho) +
// flock() de an toan khi co nhieu tab trinh duyet cung luc.
$appHomeForAudit = getenv('APP_HOME');
$rundirForAudit = $appHomeForAudit ? rtrim($appHomeForAudit, '/') . '/lamp-run' : null;
$lockoutFile = $rundirForAudit ? $rundirForAudit . '/admin-login-attempts.json' : null;
$auditLogFile = $rundirForAudit ? $rundirForAudit . '/admin-audit.log' : null;
$totpSecretFile = $appHomeForAudit ? rtrim($appHomeForAudit, '/') . '/admin-totp-secret.txt' : null;
$totpEnabledFile = $appHomeForAudit ? rtrim($appHomeForAudit, '/') . '/admin-totp-enabled.flag' : null;
$totpEnabled = $totpEnabledFile && file_exists($totpEnabledFile);
const WP_POCKET_MAX_FAILED_ATTEMPTS = 5;
const WP_POCKET_LOCKOUT_SECONDS = 900; // 15 phut
const WP_POCKET_FAIL_DELAY_US = 400000; // tre 0,4 giay sau moi lan sai: lam cham do tuan tu, khong anh huong nguoi go sai vai lan
const WP_POCKET_LOCKOUT_MAX_ENTRIES = 2000; // toi da so IP luu trong bo dem (bi do tu hang nghin IP van khong lam file phinh vo han)

/** Doc bo dem khoa IP duoi khoa CHIA SE: cho ghi xong (khoa doc quyen) roi moi doc, nen KHONG BAO GIO thay file rong giua chung. */
function wp_pocket_read_lockout_data(?string $file): array
{
    if (!$file || !is_file($file)) return [];
    $fh = @fopen($file, 'r');
    if (!$fh) return [];
    flock($fh, LOCK_SH);
    $raw = stream_get_contents($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    $data = $raw ? json_decode($raw, true) : null;
    return is_array($data) ? $data : [];
}

/**
 * 1br (HANDOFF.md muc 1br): doc-sua-ghi bo dem khoa IP trong MOT khoa doc quyen (flock EX). $fn(array &$data) sua $data tai cho va
 * tra gia tri bat ky (tra lai cho nguoi goi). Ban cu (3 loi that, da tai hien bang test song song):
 *  (1) doc file KHONG khoa -> tinh -> ghi: 2 request song song cung doc "count=2" va deu ghi "count=3" (mat 1 lan dem);
 *  (2) file_put_contents(..., LOCK_EX) cat file ve 0 byte TRUOC khi ghi, nen request doc dung luc do thay file RONG = "chua tung sai"
 *      va ghi de bo dem ve 0 (xoa sach lich su khoa cua moi IP khac);
 *  (3) quan trong nhat: kiem tra "dang khoa chua" nam TRUOC buoc so mat khau va khong gan voi viec dem. 100 request song song cung qua
 *      cua kiem tra, ca 100 deu duoc so mat khau, roi moi dem => 100 lan thu thay vi 5. Cong cu do mat khau chay SONG SONG nen day la
 *      duong tan cong that. Cach sua: DAT CHO (tang dem) trong khoa TRUOC khi so mat khau (xem wp_pocket_lockout_begin).
 * Khong mo/khoa duoc file (dia day, khong co APP_HOME) => chay $fn tren mang rong (giu hanh vi cu: khong khoa, khong chan chu may).
 */
function wp_pocket_lockout_mutate(?string $file, callable $fn)
{
    $data = [];
    $fh = $file ? @fopen($file, 'c+') : false;
    $locked = $fh && flock($fh, LOCK_EX);
    if ($locked) {
        $raw = stream_get_contents($fh);
        $d = ($raw !== false && $raw !== '') ? json_decode($raw, true) : [];
        $data = is_array($d) ? $d : [];
    }
    $result = $fn($data);
    if ($locked) {
        if (count($data) > WP_POCKET_LOCKOUT_MAX_ENTRIES) {
            // Bo muc cu nhat (theo "at"), uu tien giu IP dang bi khoa.
            uasort($data, function ($x, $y) {
                $kx = ((int) ($x['locked_until'] ?? 0) > time() ? PHP_INT_MAX : (int) ($x['at'] ?? 0));
                $ky = ((int) ($y['locked_until'] ?? 0) > time() ? PHP_INT_MAX : (int) ($y['at'] ?? 0));
                return $ky <=> $kx;
            });
            $data = array_slice($data, 0, WP_POCKET_LOCKOUT_MAX_ENTRIES, true);
        }
        ftruncate($fh, 0);
        rewind($fh);
        fwrite($fh, json_encode($data));
        fflush($fh);
    }
    if ($fh) {
        if ($locked) flock($fh, LOCK_UN);
        fclose($fh);
    }
    return $result;
}

/**
 * DAT CHO 1 lan thu (tang dem NGAY, trong khoa) truoc khi so mat khau/ma 2FA. Tra ve ['allowed'=>false,'remain_min'=>N] neu IP dang
 * bi khoa hoac da het luot dat cho (dot thu hien tai dang duoc xu ly); ['allowed'=>true,'n'=>k] voi k = so thu tu lan thu (1..MAX).
 * Toi da MAX lan so mat khau trong 1 dot bat ke so request song song.
 */
function wp_pocket_lockout_begin(?string $file, string $ip, int $now): array
{
    return wp_pocket_lockout_mutate($file, function (array &$data) use ($ip, $now) {
        $rec = $data[$ip] ?? ['count' => 0, 'locked_until' => 0];
        $until = (int) ($rec['locked_until'] ?? 0);
        if ($until > $now) {
            return ['allowed' => false, 'remain_min' => (int) ceil(($until - $now) / 60)];
        }
        if ($until > 0) {   // da het thoi gian khoa: dem lai tu dau
            $rec = ['count' => 0, 'locked_until' => 0];
        }
        $n = (int) ($rec['count'] ?? 0);
        if ($n >= WP_POCKET_MAX_FAILED_ATTEMPTS) {   // du MAX luot da duoc dat cho, chua co ket qua nao chot khoa
            return ['allowed' => false, 'remain_min' => 1];
        }
        $rec['count'] = $n + 1;
        $rec['at'] = $now;
        $data[$ip] = $rec;
        return ['allowed' => true, 'n' => $n + 1];
    });
}

/** Chot 1 lan thu SAI: lan thu thu MAX (duy nhat trong 1 dot) dat moc khoa. Tra ve true neu lan nay vua khoa IP. */
function wp_pocket_lockout_fail(?string $file, string $ip, int $now, int $n): bool
{
    if ($n < WP_POCKET_MAX_FAILED_ATTEMPTS) return false;
    return (bool) wp_pocket_lockout_mutate($file, function (array &$data) use ($ip, $now) {
        $data[$ip] = ['count' => 0, 'locked_until' => $now + WP_POCKET_LOCKOUT_SECONDS, 'at' => $now];   // reset dem, dem lai sau khi het khoa
        return true;
    });
}

/** Dang nhap dung: xoa dem sai cua IP nay. */
function wp_pocket_lockout_clear(?string $file, string $ip): void
{
    wp_pocket_lockout_mutate($file, function (array &$data) use ($ip) {
        unset($data[$ip]);
        return null;
    });
}

function wp_pocket_audit_log(?string $file, string $ip, string $event): void
{
    if (!$file) return;
    $line = date('Y-m-d H:i:s') . " ip=$ip $event\n";
    @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

$now = time();
$lockoutData = wp_pocket_read_lockout_data($lockoutFile);
$ipRecord = $lockoutData[$remoteAddr] ?? ['count' => 0, 'locked_until' => 0];

/** Tra loi 429 "dang khoa" roi dung (dung chung cho kiem tra som va cho nhanh het luot dat cho). */
function wp_pocket_locked_response(int $remainMin): void
{
    http_response_code(429);
    echo '<p>Da nhap sai mat khau qua ' . WP_POCKET_MAX_FAILED_ATTEMPTS . ' lan. ' .
         'Vui long thu lai sau khoang ' . max(1, $remainMin) . ' phut.</p>';
    exit;
}

// Neu dang bi khoa, chan LUON - khong doc/kiem tra mat khau POST len nua
// (tranh ke tan cong tiep tuc do trong luc bi khoa).
if (($ipRecord['locked_until'] ?? 0) > $now) {
    wp_pocket_locked_response((int) ceil((($ipRecord['locked_until'] ?? 0) - $now) / 60));
}

$appHome = getenv('APP_HOME');
$passwordFile = $appHome ? rtrim($appHome, '/') . '/admin-password.txt' : null;
$realPassword = ($passwordFile && is_readable($passwordFile))
    ? trim(file_get_contents($passwordFile))
    : null;

$error = '';
$awaitingTotp = !empty($_SESSION['wp_pocket_password_ok']) && $totpEnabled;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $awaitingTotp && isset($_POST['totp_code'])) {
    // --- Buoc 2 (chi khi 2FA dang BAT): mat khau da dung o buoc 1, gio
    // kiem tra ma 6 so tu app Authenticator ---
    // Dat cho luot thu TRUOC khi kiem tra ma (xem wp_pocket_lockout_mutate): ma TOTP chi 6 chu so nen do song song la nguy co that.
    $att = wp_pocket_lockout_begin($lockoutFile, $remoteAddr, $now);
    if (!$att['allowed']) {
        wp_pocket_locked_response((int) $att['remain_min']);
    }
    $pendingSecret = ($totpSecretFile && is_readable($totpSecretFile)) ? trim(file_get_contents($totpSecretFile)) : null;
    // Ma TOTP chi dung DUOC 1 LAN (RFC 6238 muc 5.2): ma bi lo/nhin lom qua vai tuy cua nguoi khac khong dung lai duoc trong cua so ~90 giay.
    $totpStep = $pendingSecret !== null ? wp_pocket_totp_match($pendingSecret, (string) $_POST['totp_code']) : null;
    $totpFresh = $totpStep !== null && wp_pocket_totp_consume($totpStep);
    if ($totpFresh) {
        session_regenerate_id(true);
        $_SESSION['wp_pocket_admin_authed'] = true;
        $_SESSION['wp_pocket_last_activity'] = time();
        wp_pocket_session_register();
        unset($_SESSION['wp_pocket_password_ok']);
        wp_pocket_lockout_clear($lockoutFile, $remoteAddr);
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'dang nhap THANH CONG (mat khau + 2FA)');
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
    // Ma TOTP sai (hoac DUNG nhung da dung roi = replay) - dung CHUNG bo dem/khoa voi mat khau sai (1 IP do sai o
    // buoc nao cung tinh nhu nhau, tranh phai lam rieng 1 bo dem thu 2).
    if (wp_pocket_lockout_fail($lockoutFile, $remoteAddr, $now, (int) $att['n'])) {
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'BI KHOA TAM (sai ma 2FA qua ' . WP_POCKET_MAX_FAILED_ATTEMPTS . ' lan)');
    } else {
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'sai ma 2FA (' . $att['n'] . '/' . WP_POCKET_MAX_FAILED_ATTEMPTS . ')' . ($totpStep !== null ? ' - ma da duoc dung roi (replay)' : ''));
    }
    usleep(WP_POCKET_FAIL_DELAY_US);
    $error = 'Sai ma 2FA.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && !$awaitingTotp && isset($_POST['admin_password'])) {
    // Dat cho luot thu TRUOC khi so mat khau: toi da MAX request duoc so mat khau trong 1 dot, ke ca khi ke tan cong gui song song.
    $att = wp_pocket_lockout_begin($lockoutFile, $remoteAddr, $now);
    if (!$att['allowed']) {
        wp_pocket_locked_response((int) $att['remain_min']);
    }
    $submitted = (string) $_POST['admin_password'];
    if ($realPassword !== null && hash_equals($realPassword, $submitted)) {
        wp_pocket_lockout_clear($lockoutFile, $remoteAddr); // dang nhap dung - xoa dem sai cu cua IP nay
        if ($totpEnabled) {
            // Mat khau dung nhung CHUA xong - can them ma 2FA (buoc 2 o tren).
            // KHONG danh dau admin_authed voi, tranh bo qua han 2FA.
            session_regenerate_id(true);
            $_SESSION['wp_pocket_password_ok'] = true;
            wp_pocket_audit_log($auditLogFile, $remoteAddr, 'mat khau dung, cho nhap ma 2FA');
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit;
        }
        session_regenerate_id(true);
        $_SESSION['wp_pocket_admin_authed'] = true;
        $_SESSION['wp_pocket_last_activity'] = time();
        wp_pocket_session_register();
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'dang nhap THANH CONG');
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
    if (wp_pocket_lockout_fail($lockoutFile, $remoteAddr, $now, (int) $att['n'])) {
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'BI KHOA TAM (qua ' . WP_POCKET_MAX_FAILED_ATTEMPTS . ' lan sai)');
    } else {
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'dang nhap sai (' . $att['n'] . '/' . WP_POCKET_MAX_FAILED_ATTEMPTS . ')');
    }
    usleep(WP_POCKET_FAIL_DELAY_US);
    $error = 'Sai mat khau.';
}

if (!empty($_SESSION['wp_pocket_admin_authed'])) {
    return;
}

if ($realPassword === null) {
    http_response_code(500);
    echo '<p>Chua co mat khau quan tri - mo app WP Pocket Server tren dien thoai, ' .
         'bat server it nhat 1 lan de app tu sinh mat khau.</p>';
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dang nhap quan tri</title>
<style>
  body { font-family: system-ui, sans-serif; background:#f2f2f2; display:flex;
         align-items:center; justify-content:center; height:100vh; margin:0; }
  form { background:#fff; padding:24px 28px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,.1); min-width:260px; }
  input[type=password] { width:100%; padding:10px; font-size:16px; margin:10px 0 16px;
         box-sizing:border-box; border:1px solid #ccc; border-radius:6px; }
  button { width:100%; padding:10px; font-size:16px; background:#21759B; color:#fff;
         border:none; border-radius:6px; cursor:pointer; }
  .err { color:#c0392b; font-size:14px; margin-top:-6px; margin-bottom:10px; }
  h2 { margin-top:0; font-size:18px; }
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style>
</head>
<body>
  <form method="post">
    <?php if ($awaitingTotp): ?>
      <h2>Nhap ma 2FA</h2>
      <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <input type="text" name="totp_code" inputmode="numeric" pattern="[0-9]*" maxlength="6"
             placeholder="Ma 6 so tu app Authenticator" autofocus
             style="width:100%;padding:10px;font-size:18px;letter-spacing:3px;margin:10px 0 16px;box-sizing:border-box;border:1px solid #ccc;border-radius:6px;">
      <button type="submit">Vao</button>
    <?php else: ?>
      <h2>Trang quan tri - can mat khau</h2>
      <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <input type="password" name="admin_password" placeholder="Mat khau (xem trong app)" autofocus>
      <button type="submit">Vao</button>
    <?php endif; ?>
  </form>
</body>
</html>
<?php
exit;
