<?php
/**
 * Cổng xác thực cho các công cụ quản trị (_admin/db.php, _admin/files.php).
 * Được require ở ĐẦU mỗi file quản trị (xem scripts/lib/admin_tools.sh).
 *
 * Mật khẩu KHÔNG hardcode, KHÔNG có giá trị mặc định - được app Android
 * (ServerForegroundService.kt) sinh ngẫu nhiên (SecureRandom) lúc server
 * chạy lần đầu trên từng máy, ghi vào $APP_HOME/admin-password.txt. Người
 * dùng xem mật khẩu này trong chính app, mục "Mật khẩu quản trị".
 *
 * Lớp bảo vệ IP-LAN: bình thường nginx.conf.template (location /_admin/)
 * đã chặn IP ngoài LAN trước khi request chạm tới PHP. NHƯNG ở chế độ
 * Dual-Mode PHP-Lite (xem HANDOFF.md mục 1e) không có nginx — `php -S` tự
 * phục vụ trực tiếp, không có lớp chặn IP nào cả nếu không tự làm ở đây.
 * Nên kiểm tra lại NGAY TRONG PHP (dùng chung cho CẢ 2 chế độ — ở chế độ
 * đầy đủ, đây là lớp phòng thủ kép vô hại, phòng khi nginx.conf lỡ bị sửa
 * sai sau này) thay vì chỉ dựa vào nginx.
 *
 * 2FA (xem HANDOFF.md muc 10, de xuat DeepSeek muc A7, va totp-lib.php cho
 * chi tiet thuat toan): lop bao ve THEM, tuy chon (bat/tat qua 2fa.php) -
 * yeu cau them 1 ma 6 so tu app Authenticator SAU KHI mat khau da dung.
 */

require __DIR__ . '/totp-lib.php';

function wp_pocket_ip_in_private_lan(string $ip): bool
{
    $ranges = [
        ['192.168.0.0', 16],
        ['10.0.0.0', 8],
        ['172.16.0.0', 12],
    ];
    $ipLong = ip2long($ip);
    if ($ipLong === false) {
        return false; // IPv6 hoac khong hop le - tu choi cho chac (giong hanh vi nginx hien tai, cung chi allow IPv4)
    }
    foreach ($ranges as [$base, $bits]) {
        $baseLong = ip2long($base);
        $mask = -1 << (32 - $bits);
        if (($ipLong & $mask) === ($baseLong & $mask)) {
            return true;
        }
    }
    return false;
}

$remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '';
if (!wp_pocket_ip_in_private_lan($remoteAddr)) {
    http_response_code(403);
    echo '<p>Trang quan tri chi vao duoc qua mang LAN (WiFi/mang noi bo), khong qua URL cong khai.</p>';
    exit;
}

session_start();

if (!empty($_SESSION['wp_pocket_admin_authed'])) {
    return; // da dang nhap trong phien nay, cho qua
}

// --- Chong do mat khau + nhat ky dang nhap (xem HANDOFF.md muc 10, de xuat
// DeepSeek muc A6/G4) ---
// Truoc day chi co DUY NHAT 1 lop mat khau, khong gioi han so lan thu, khong
// ghi lai ai da thu dang nhap - neu mat khau 16 ky tu bi lo (vd chup man
// hinh), khong co gi ngan ke tan cong do lai bang script tu dong, va chu
// nha cung khong biet co ai dang do hay khong. Dung file JSON don gian
// (KHONG can them SQLite/DB - cong cu 1-chu-so-huu, du du lieu nho) +
// flock() de an toan khi co nhieu tab trinh duyet cung luc.
$appHomeForAudit = getenv('APP_HOME');
$rundirForAudit = $appHomeForAudit ? rtrim($appHomeForAudit, '/') . '/lamp-run' : null;
$lockoutFile = $rundirForAudit ? $rundirForAudit . '/admin-login-attempts.json' : null;
$auditLogFile = $rundirForAudit ? $rundirForAudit . '/admin-audit.log' : null;
$totpSecretFile = $appHomeForAudit ? rtrim($appHomeForAudit, '/') . '/admin-totp-secret.txt' : null;
$totpEnabledFile = $appHomeForAudit ? rtrim($appHomeForAudit, '/') . '/admin-totp-enabled.flag' : null;
$totpEnabled = $totpEnabledFile && file_exists($totpEnabledFile);
const WP_POCKET_MAX_FAILED_ATTEMPTS = 5;
const WP_POCKET_LOCKOUT_SECONDS = 900; // 15 phut

function wp_pocket_read_lockout_data(?string $file): array
{
    if (!$file || !is_file($file)) return [];
    $raw = @file_get_contents($file);
    $data = $raw ? json_decode($raw, true) : null;
    return is_array($data) ? $data : [];
}

function wp_pocket_write_lockout_data(?string $file, array $data): void
{
    if (!$file) return;
    @file_put_contents($file, json_encode($data), LOCK_EX);
}

function wp_pocket_audit_log(?string $file, string $ip, string $event): void
{
    if (!$file) return;
    $line = date('Y-m-d H:i:s') . " ip=$ip $event\n";
    @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

$now = time();
$lockoutData = wp_pocket_read_lockout_data($lockoutFile);
$ipRecord = $lockoutData[$remoteAddr] ?? ['count' => 0, 'locked_until' => 0];

// Neu dang bi khoa, chan LUON - khong doc/kiem tra mat khau POST len nua
// (tranh ke tan cong tiep tuc do trong luc bi khoa).
if (($ipRecord['locked_until'] ?? 0) > $now) {
    $remainMin = (int) ceil((($ipRecord['locked_until'] ?? 0) - $now) / 60);
    http_response_code(429);
    echo '<p>Da nhap sai mat khau qua ' . WP_POCKET_MAX_FAILED_ATTEMPTS . ' lan. ' .
         'Vui long thu lai sau khoang ' . $remainMin . ' phut.</p>';
    exit;
}

$appHome = getenv('APP_HOME');
$passwordFile = $appHome ? rtrim($appHome, '/') . '/admin-password.txt' : null;
$realPassword = ($passwordFile && is_readable($passwordFile))
    ? trim(file_get_contents($passwordFile))
    : null;

$error = '';
$awaitingTotp = !empty($_SESSION['wp_pocket_password_ok']) && $totpEnabled;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $awaitingTotp && isset($_POST['totp_code'])) {
    // --- Buoc 2 (chi khi 2FA dang BAT): mat khau da dung o buoc 1, gio
    // kiem tra ma 6 so tu app Authenticator ---
    $pendingSecret = ($totpSecretFile && is_readable($totpSecretFile)) ? trim(file_get_contents($totpSecretFile)) : null;
    if ($pendingSecret !== null && wp_pocket_totp_verify($pendingSecret, (string) $_POST['totp_code'])) {
        session_regenerate_id(true);
        $_SESSION['wp_pocket_admin_authed'] = true;
        unset($_SESSION['wp_pocket_password_ok']);
        unset($lockoutData[$remoteAddr]);
        wp_pocket_write_lockout_data($lockoutFile, $lockoutData);
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'dang nhap THANH CONG (mat khau + 2FA)');
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
    // Ma TOTP sai - dung CHUNG bo dem/khoa voi mat khau sai (1 IP do sai o
    // buoc nao cung tinh nhu nhau, tranh phai lam rieng 1 bo dem thu 2).
    $ipRecord['count'] = ($ipRecord['count'] ?? 0) + 1;
    if ($ipRecord['count'] >= WP_POCKET_MAX_FAILED_ATTEMPTS) {
        $ipRecord['locked_until'] = $now + WP_POCKET_LOCKOUT_SECONDS;
        $ipRecord['count'] = 0;
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'BI KHOA TAM (sai ma 2FA qua ' . WP_POCKET_MAX_FAILED_ATTEMPTS . ' lan)');
    } else {
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'sai ma 2FA (' . $ipRecord['count'] . '/' . WP_POCKET_MAX_FAILED_ATTEMPTS . ')');
    }
    $lockoutData[$remoteAddr] = $ipRecord;
    wp_pocket_write_lockout_data($lockoutFile, $lockoutData);
    $error = 'Sai ma 2FA.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && !$awaitingTotp && isset($_POST['admin_password'])) {
    $submitted = (string) $_POST['admin_password'];
    if ($realPassword !== null && hash_equals($realPassword, $submitted)) {
        unset($lockoutData[$remoteAddr]); // dang nhap dung - xoa dem sai cu cua IP nay
        wp_pocket_write_lockout_data($lockoutFile, $lockoutData);
        if ($totpEnabled) {
            // Mat khau dung nhung CHUA xong - can them ma 2FA (buoc 2 o tren).
            // KHONG danh dau admin_authed voi, tranh bo qua han 2FA.
            session_regenerate_id(true);
            $_SESSION['wp_pocket_password_ok'] = true;
            wp_pocket_audit_log($auditLogFile, $remoteAddr, 'mat khau dung, cho nhap ma 2FA');
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit;
        }
        session_regenerate_id(true);
        $_SESSION['wp_pocket_admin_authed'] = true;
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'dang nhap THANH CONG');
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
    $ipRecord['count'] = ($ipRecord['count'] ?? 0) + 1;
    if ($ipRecord['count'] >= WP_POCKET_MAX_FAILED_ATTEMPTS) {
        $ipRecord['locked_until'] = $now + WP_POCKET_LOCKOUT_SECONDS;
        $ipRecord['count'] = 0; // reset dem, dem lai tu dau sau khi het khoa
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'BI KHOA TAM (qua ' . WP_POCKET_MAX_FAILED_ATTEMPTS . ' lan sai)');
    } else {
        wp_pocket_audit_log($auditLogFile, $remoteAddr, 'dang nhap sai (' . $ipRecord['count'] . '/' . WP_POCKET_MAX_FAILED_ATTEMPTS . ')');
    }
    $lockoutData[$remoteAddr] = $ipRecord;
    wp_pocket_write_lockout_data($lockoutFile, $lockoutData);
    $error = 'Sai mat khau.';
}

if (!empty($_SESSION['wp_pocket_admin_authed'])) {
    return;
}

if ($realPassword === null) {
    http_response_code(500);
    echo '<p>Chua co mat khau quan tri - mo app WP Pocket Server tren dien thoai, ' .
         'bat server it nhat 1 lan de app tu sinh mat khau.</p>';
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dang nhap quan tri</title>
<style>
  body { font-family: system-ui, sans-serif; background:#f2f2f2; display:flex;
         align-items:center; justify-content:center; height:100vh; margin:0; }
  form { background:#fff; padding:24px 28px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,.1); min-width:260px; }
  input[type=password] { width:100%; padding:10px; font-size:16px; margin:10px 0 16px;
         box-sizing:border-box; border:1px solid #ccc; border-radius:6px; }
  button { width:100%; padding:10px; font-size:16px; background:#21759B; color:#fff;
         border:none; border-radius:6px; cursor:pointer; }
  .err { color:#c0392b; font-size:14px; margin-top:-6px; margin-bottom:10px; }
  h2 { margin-top:0; font-size:18px; }
</style>
</head>
<body>
  <form method="post">
    <?php if ($awaitingTotp): ?>
      <h2>Nhap ma 2FA</h2>
      <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <input type="text" name="totp_code" inputmode="numeric" pattern="[0-9]*" maxlength="6"
             placeholder="Ma 6 so tu app Authenticator" autofocus
             style="width:100%;padding:10px;font-size:18px;letter-spacing:3px;margin:10px 0 16px;box-sizing:border-box;border:1px solid #ccc;border-radius:6px;">
      <button type="submit">Vao</button>
    <?php else: ?>
      <h2>Trang quan tri - can mat khau</h2>
      <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <input type="password" name="admin_password" placeholder="Mat khau (xem trong app)" autofocus>
      <button type="submit">Vao</button>
    <?php endif; ?>
  </form>
</body>
</html>
<?php
exit;
