<?php
/**
 * WP Pocket 2FA - dang nhap hai buoc (TOTP, RFC 6238) cho WordPress (HANDOFF.md muc 1br-H, docs/SECURITY.md). Test: scripts/tests/wp-2fa-test.py (WordPress THAT).
 *
 * Tai sao: mat khau lo (dung lai o noi khac, bi doan, bi hut qua SQL injection) la duong chiem site pho bien nhat; ke tan cong dung AI thu hang loat
 * mat khau da lo. Ma TOTP tu dien thoai chan duoc ca khi ke do da biet DUNG mat khau.
 *
 * Nguyen tac thiet ke - TRANH KHOA CHU SITE (day la ly do tinh nang nay tung bi hoan lai den khi co WordPress that de kiem):
 *  - TUY CHON TUNG NGUOI: khong ai bi ep bat. Chua bat = dang nhap nhu cu, khong co tac dung phu.
 *  - Bat phai NHAP DUNG 1 MA (chung minh da quet duoc bi mat) truoc khi co hieu luc; tat can ma/ma khoi phuc; hien 8 ma khoi phuc dung 1 lan.
 *  - Cong tat khan cap NGOAI WordPress: tao file lamp-run/twofa-off => toan site bo qua hai buoc (xoa file de bat lai).
 *  - Admin khac dat lai hai buoc cua nguoi dung (mat thiet bi) o trang sua ho so. Tu WP-CLI: wp user meta delete <id> wppocket_2fa.
 *  - Khong giai ma duoc bi mat (doi muoi AUTH_KEY...) => KHONG khoa (cho vao khong can ma) + ghi su kien khan "2FA KHONG DOC DUOC".
 *  - Moi ma chi dung 1 lan (chong lap lai trong cua so 30 giay); sai ma tinh vao bo dem khoa tai khoan cua Shield (wp_login_failed).
 *  - Thong bao that bai GIONG NHAU cho moi truong hop (sai ten/mat khau/ma) khi co nguoi dung bat hai buoc => khong lo "mat khau dung".
 *  - Bi mat luu MA HOA (libsodium secretbox, khoa suy ra tu AUTH_KEY + SECURE_AUTH_KEY): doc duoc bang SQL injection cung khong dung duoc.
 * Chi ap dung cho dang nhap bang bieu mau (wp-login.php, WooCommerce...) - REST/XML-RPC khong qua bieu mau (XML-RPC bi Shield tat; mat khau ung dung do
 * Shield tat, neu chu site bat lai thi co chu dich bo qua hai buoc nhu moi plugin 2FA khac).
 */
if (!defined('ABSPATH')) {
    exit;
}

const WPPOCKET_2FA_META = 'wppocket_2fa';
const WPPOCKET_2FA_PENDING = 'wppocket_2fa_pending';
const WPPOCKET_2FA_RECOVERY_COUNT = 8;
const WPPOCKET_2FA_PENDING_TTL = 3600;
const WPPOCKET_2FA_MSG = 'Sign-in failed. Check your username, password and authentication code.';

if (!function_exists('wppocket_2fa_home')) {

    function wppocket_2fa_home(): string
    {
        $h = getenv('APP_HOME');
        if (!is_string($h) || $h === '') {
            return '';
        }
        $d = rtrim($h, '/') . '/lamp-run';
        return is_dir($d) ? $d : '';
    }

    function wppocket_2fa_flag(string $name): bool
    {
        $d = wppocket_2fa_home();
        return $d !== '' && is_file($d . '/' . $name);
    }

    function wppocket_2fa_event(string $msg): void
    {
        $d = wppocket_2fa_home();
        if ($d === '') {
            return;
        }
        $ip = isset($_SERVER['REMOTE_ADDR']) && is_string($_SERVER['REMOTE_ADDR']) && filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP) !== false ? $_SERVER['REMOTE_ADDR'] : '-';
        $msg = preg_replace('/[\x00-\x1f\x7f]+/', ' ', $msg);
        @file_put_contents($d . '/security-events.log', date('Y-m-d H:i:s') . ' ip=' . $ip . ' ' . substr((string) $msg, 0, 240) . "\n", FILE_APPEND | LOCK_EX);
    }

    // ---------------------------------------------------------------- TOTP (RFC 4226/6238, giong admin-totp-lib.php)
    function wppocket_2fa_b32_encode(string $bin): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $bits = '';
        foreach (str_split($bin) as $c) {
            $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            $out .= $alphabet[bindec(str_pad($chunk, 5, '0'))];
        }
        return $out;
    }

    function wppocket_2fa_b32_decode(string $b32): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $b32 = strtoupper((string) preg_replace('/[^A-Za-z2-7]/', '', $b32));
        $bits = '';
        foreach (str_split($b32) as $c) {
            $v = strpos($alphabet, $c);
            if ($v !== false) {
                $bits .= str_pad(decbin($v), 5, '0', STR_PAD_LEFT);
            }
        }
        $bin = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) {
                $bin .= chr(bindec($byte));
            }
        }
        return $bin;
    }

    function wppocket_2fa_hotp(string $key, int $counter): string
    {
        $h = hash_hmac('sha1', pack('J', $counter), $key, true);
        $o = ord($h[19]) & 0x0f;
        $v = ((ord($h[$o]) & 0x7f) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
        return str_pad((string) ($v % 1000000), 6, '0', STR_PAD_LEFT);
    }

    /** Buoc thoi gian (30 giay) khop voi ma, hoac null. Cua so +-1 buoc (lech dong ho ~30 giay). Duyet het cac buoc (khong thoat som). */
    function wppocket_2fa_match(string $secretBin, string $input, int $now, int $window = 1): ?int
    {
        $input = (string) preg_replace('/\D/', '', $input);
        if (strlen($input) !== 6 || $secretBin === '') {
            return null;
        }
        $t = intdiv($now, 30);
        $hit = null;
        for ($i = -$window; $i <= $window; $i++) {
            if (hash_equals(wppocket_2fa_hotp($secretBin, $t + $i), $input)) {
                $hit = $t + $i;
            }
        }
        return $hit;
    }

    // ---------------------------------------------------------------- ma hoa bi mat
    function wppocket_2fa_key(): string
    {
        $a = defined('AUTH_KEY') ? (string) AUTH_KEY : '';
        $b = defined('SECURE_AUTH_KEY') ? (string) SECURE_AUTH_KEY : '';
        return hash('sha256', 'wppocket-2fa|' . $a . '|' . $b, true);
    }

    function wppocket_2fa_crypto_ok(): bool
    {
        return function_exists('sodium_crypto_secretbox') || (function_exists('openssl_encrypt') && in_array('aes-256-gcm', (array) openssl_get_cipher_methods(), true));
    }

    function wppocket_2fa_encrypt(string $plain): string
    {
        $key = wppocket_2fa_key();
        if (function_exists('sodium_crypto_secretbox')) {
            $n = random_bytes(24);
            return 's1:' . base64_encode($n . sodium_crypto_secretbox($plain, $n, $key));
        }
        if (function_exists('openssl_encrypt') && in_array('aes-256-gcm', (array) openssl_get_cipher_methods(), true)) {
            $iv = random_bytes(12);
            $tag = '';
            $c = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            return $c === false ? '' : 'o1:' . base64_encode($iv . $tag . $c);
        }
        return '';
    }

    function wppocket_2fa_decrypt(string $blob): string
    {
        $key = wppocket_2fa_key();
        $kind = substr($blob, 0, 3);
        $raw = base64_decode(substr($blob, 3), true);
        if ($raw === false) {
            return '';
        }
        if ($kind === 's1:' && function_exists('sodium_crypto_secretbox_open') && strlen($raw) > 24) {
            $p = sodium_crypto_secretbox_open(substr($raw, 24), substr($raw, 0, 24), $key);
            return $p === false ? '' : $p;
        }
        if ($kind === 'o1:' && function_exists('openssl_decrypt') && strlen($raw) > 28) {
            $p = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
            return $p === false ? '' : $p;
        }
        return '';
    }

    // ---------------------------------------------------------------- trang thai
    /** Mang trang thai neu nguoi dung DA BAT hai buoc, nguoc lai null. Khoa: s=bi mat ma hoa, r=bam ma khoi phuc, l=buoc TOTP dung gan nhat, at=luc bat. */
    function wppocket_2fa_load(int $uid): ?array
    {
        $raw = get_user_meta($uid, WPPOCKET_2FA_META, true);
        $d = is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
        return is_array($d) && !empty($d['on']) ? $d : null;
    }

    function wppocket_2fa_save(int $uid, array $d): void
    {
        update_user_meta($uid, WPPOCKET_2FA_META, wp_slash((string) wp_json_encode($d)));
    }

    function wppocket_2fa_any_enabled(): bool
    {
        static $c = null;
        if ($c === null) {
            $ids = get_users(array('meta_key' => WPPOCKET_2FA_META, 'fields' => 'ID', 'number' => 1, 'count_total' => false));
            $c = is_array($ids) && count($ids) > 0;
        }
        return $c;
    }

    function wppocket_2fa_recovery_norm(string $code): string
    {
        return strtolower((string) preg_replace('/[^A-Za-z0-9]/', '', $code));
    }

    function wppocket_2fa_recovery_hash(string $code): string
    {
        return hash_hmac('sha256', wppocket_2fa_recovery_norm($code), wppocket_2fa_key());
    }

    /** @return string[] ma khoi phuc dang "xxxxx-xxxxx" (khong gom ky tu de nham 0/o/1/l/i). */
    function wppocket_2fa_make_recovery_codes(): array
    {
        $al = 'abcdefghjkmnpqrstuvwxyz23456789';
        $out = array();
        for ($i = 0; $i < WPPOCKET_2FA_RECOVERY_COUNT; $i++) {
            $c = '';
            for ($j = 0; $j < 10; $j++) {
                $c .= $al[random_int(0, strlen($al) - 1)];
            }
            $out[] = substr($c, 0, 5) . '-' . substr($c, 5);
        }
        return $out;
    }

    /**
     * Kiem tra 1 ma nguoi dung nhap (TOTP hoac ma khoi phuc) voi trang thai $d. Tra ['ok'=>bool,'kind'=>'totp'|'recovery'|'','step'=>int,'d'=>mang moi].
     * KHONG ghi gi - noi goi quyet dinh (de dung chung cho dang nhap, tat, tao lai ma).
     */
    function wppocket_2fa_check(array $d, string $input, int $now): array
    {
        $none = array('ok' => false, 'kind' => '', 'step' => 0, 'd' => $d);
        $secret = wppocket_2fa_decrypt((string) ($d['s'] ?? ''));
        if ($secret === '') {
            return $none;
        }
        $input = trim($input);
        $step = wppocket_2fa_match($secret, $input, $now);
        if ($step !== null) {
            if ($step <= (int) ($d['l'] ?? 0)) {
                return $none;      // ma da dung (chong lap lai)
            }
            $d['l'] = $step;
            return array('ok' => true, 'kind' => 'totp', 'step' => $step, 'd' => $d);
        }
        if (strlen(wppocket_2fa_recovery_norm($input)) === 10) {
            $h = wppocket_2fa_recovery_hash($input);
            $found = -1;
            foreach ((array) ($d['r'] ?? array()) as $i => $stored) {
                if (is_string($stored) && hash_equals($stored, $h)) {
                    $found = (int) $i;
                }
            }
            if ($found >= 0) {
                $r = (array) $d['r'];
                unset($r[$found]);
                $d['r'] = array_values($r);
                return array('ok' => true, 'kind' => 'recovery', 'step' => 0, 'd' => $d);
            }
        }
        return $none;
    }

    // ---------------------------------------------------------------- dang nhap
    function wppocket_2fa_authenticate($user, $username = '', $password = '')
    {
        if (!($user instanceof WP_User) || wppocket_2fa_flag('twofa-off')) {
            return $user;
        }
        if (defined('XMLRPC_REQUEST') || defined('REST_REQUEST') || did_action('application_password_did_authenticate')) {
            return $user;
        }
        // Khong ten + khong mat khau = lop cookie cua loi WordPress (da dang nhap san), khong phai buoc nhap mat khau - khong doi ma.
        if ((string) $username === '' && (string) $password === '') {
            return $user;
        }
        $d = wppocket_2fa_load((int) $user->ID);
        if ($d === null) {
            return $user;
        }
        if (wppocket_2fa_decrypt((string) ($d['s'] ?? '')) === '') {
            // moi tai khoan toi da 1 su kien/gio (ke tan cong thu mat khau lien tuc khong duoc lam tran nhat ky)
            if (get_transient('wppocket_2fa_unreadable_' . (int) $user->ID) === false) {
                set_transient('wppocket_2fa_unreadable_' . (int) $user->ID, 1, 3600);
                wppocket_2fa_event('2FA KHONG DOC DUOC bi mat cua ' . $user->user_login . ' (doi muoi AUTH_KEY? sua meta?) - dang nhap tai khoan nay tam KHONG can ma');
            }
            return $user;
        }
        $in = isset($_POST['wppocket_otp']) && is_string($_POST['wppocket_otp']) ? substr(trim((string) wp_unslash($_POST['wppocket_otp'])), 0, 40) : '';
        if ($in !== '') {
            $r = wppocket_2fa_check($d, $in, time());
            if ($r['ok']) {
                wppocket_2fa_save((int) $user->ID, $r['d']);
                if ($r['kind'] === 'recovery') {
                    wppocket_2fa_event('2FA MA KHOI PHUC DA DUNG: ' . $user->user_login . ' (con ' . count((array) $r['d']['r']) . ' ma)');
                }
                return $user;
            }
        }
        $GLOBALS['wppocket_2fa_failed'] = true;
        return new WP_Error('wppocket_2fa', WPPOCKET_2FA_MSG);
    }

    function wppocket_2fa_login_field(): void
    {
        if (wppocket_2fa_flag('twofa-off') || !wppocket_2fa_any_enabled()) {
            return;
        }
        echo '<p><label for="wppocket_otp">Authentication code<br><input type="text" name="wppocket_otp" id="wppocket_otp" class="input" value="" size="20" maxlength="20" inputmode="numeric" autocomplete="one-time-code"></label>'
            . '<span style="display:block;color:#646970;font-size:12px;margin-top:2px">Only if you turned on two-step sign-in. Otherwise leave empty.</span></p>';
    }

    function wppocket_2fa_login_errors($e)
    {
        if (wppocket_2fa_flag('twofa-off') || !wppocket_2fa_any_enabled() || !is_string($e) || $e === '' || stripos($e, 'too many') !== false) {
            return $e;
        }
        $action = isset($_REQUEST['action']) && is_string($_REQUEST['action']) ? $_REQUEST['action'] : 'login';
        return ($action === 'login' || $action === '') ? WPPOCKET_2FA_MSG : $e;
    }

    // ---------------------------------------------------------------- giao dien ho so
    function wppocket_2fa_pending_secret(int $uid): string
    {
        $raw = get_user_meta($uid, WPPOCKET_2FA_PENDING, true);
        $d = is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
        if (is_array($d) && time() - (int) ($d['at'] ?? 0) < WPPOCKET_2FA_PENDING_TTL) {
            $bin = wppocket_2fa_decrypt((string) ($d['s'] ?? ''));
            if (strlen($bin) === 20) {
                return $bin;
            }
        }
        $bin = random_bytes(20);
        update_user_meta($uid, WPPOCKET_2FA_PENDING, wp_slash((string) wp_json_encode(array('s' => wppocket_2fa_encrypt($bin), 'at' => time()))));
        return $bin;
    }

    function wppocket_2fa_render_profile($user): void
    {
        if (!($user instanceof WP_User)) {
            return;
        }
        $self = get_current_user_id() === (int) $user->ID;
        echo '<h2>Two-step sign-in</h2><table class="form-table" role="presentation"><tr><th>Status</th><td>';
        if (wppocket_2fa_flag('twofa-off')) {
            echo '<p><strong>Switched off for the whole site</strong> (file <code>twofa-off</code> exists in the app data folder).</p></td></tr></table>';
            return;
        }
        if (!wppocket_2fa_crypto_ok()) {
            echo '<p>Not available: this PHP has neither libsodium nor OpenSSL AES-GCM.</p></td></tr></table>';
            return;
        }
        $d = wppocket_2fa_load((int) $user->ID);
        $codes = $self ? get_transient('wppocket_2fa_codes_' . $user->ID) : false;
        if ($self && is_string($codes) && $codes !== '') {
            delete_transient('wppocket_2fa_codes_' . $user->ID);
            $list = array_filter(explode(',', wppocket_2fa_decrypt($codes)));
            if ($list) {
                echo '<div class="notice notice-warning inline"><p><strong>Save these recovery codes now - they are shown only once.</strong> Each works one time if you lose your phone.</p><pre id="wppocket-2fa-codes" style="font-size:15px">'
                    . esc_html(implode("\n", $list)) . '</pre></div>';
            }
        }
        if ($d !== null) {
            echo '<p><strong>ON</strong> for this account. Recovery codes left: ' . (int) count((array) ($d['r'] ?? array())) . '.</p>';
            if ($self) {
                echo '<p><label for="wppocket_2fa_code">Current code (or a recovery code), needed for the two actions below</label><br>'
                    . '<input type="text" name="wppocket_2fa_code" id="wppocket_2fa_code" class="regular-text" autocomplete="off" inputmode="numeric"></p>'
                    . '<p><label><input type="checkbox" name="wppocket_2fa_disable" value="1"> Turn two-step sign-in <strong>off</strong></label></p>'
                    . '<p><label><input type="checkbox" name="wppocket_2fa_regen" value="1"> Make new recovery codes (old ones stop working)</label></p>';
            } elseif (current_user_can('edit_users')) {
                echo '<p><label><input type="checkbox" name="wppocket_2fa_reset" value="1"> Reset two-step sign-in for this user (lost phone). They sign in with password only until they set it up again.</label></p>';
            }
        } elseif ($self) {
            $secret = wppocket_2fa_b32_encode(wppocket_2fa_pending_secret((int) $user->ID));
            $label = rawurlencode(wp_parse_url(home_url(), PHP_URL_HOST) . ':' . $user->user_login);
            $uri = 'otpauth://totp/' . $label . '?secret=' . $secret . '&issuer=' . rawurlencode((string) wp_parse_url(home_url(), PHP_URL_HOST)) . '&algorithm=SHA1&digits=6&period=30';
            echo '<p>OFF. To turn on: add this account to an authenticator app (Google Authenticator, Aegis, Authy...), then type the 6-digit code it shows.</p>'
                . '<p>On this phone just tap: <a href="' . esc_attr($uri) . '">add to authenticator app</a>. Otherwise choose "enter a setup key" and type:</p>'
                . '<p><code id="wppocket-2fa-secret" style="font-size:16px;letter-spacing:2px">' . esc_html(trim(chunk_split($secret, 4, ' '))) . '</code> (time-based, 6 digits)</p>'
                . '<p><label for="wppocket_2fa_confirm">Code from the app</label><br><input type="text" name="wppocket_2fa_confirm" id="wppocket_2fa_confirm" class="regular-text" autocomplete="off" inputmode="numeric"></p>'
                . '<p class="description">Then press "Update Profile". It turns on only if the code is right. Keep the recovery codes that appear.</p>';
        } else {
            echo '<p>OFF for this account.</p>';
        }
        echo '</td></tr></table>';
    }

    /**
     * Hien loi o dau trang ho so khi ma sai. THU TU cua user-edit.php: personal_options_update (apply, ben duoi) chay TRUOC user_profile_update_errors, nen
     * viec kiem ma chi lam MOT lan o apply va de ket qua vao $GLOBALS (kiem lai o day se that bai vi ma vua dung da bi danh dau da dung).
     */
    function wppocket_2fa_profile_errors($errors, $update, $user)
    {
        $r = isset($GLOBALS['wppocket_2fa_result']) && is_string($GLOBALS['wppocket_2fa_result']) ? $GLOBALS['wppocket_2fa_result'] : '';
        if ($r === 'bad_confirm') {
            $errors->add('wppocket_2fa', 'The authentication code is wrong, so two-step sign-in was NOT turned on. Check the phone clock and try again.');
        } elseif ($r === 'bad_code') {
            $errors->add('wppocket_2fa', 'The code is wrong (or was already used), so two-step sign-in was NOT changed. Wait for the next code and try again.');
        }
    }

    /** Ap dung khi ho so duoc luu (WordPress da xac thuc nonce update-user_<id> va quyen sua ho so truoc khi goi hook nay). */
    function wppocket_2fa_profile_apply($uid): void
    {
        $uid = (int) $uid;
        $GLOBALS['wppocket_2fa_result'] = '';
        if (wppocket_2fa_flag('twofa-off') || !wppocket_2fa_crypto_ok()) {
            return;
        }
        $u = get_userdata($uid);
        if (!$u) {
            return;
        }
        $self = get_current_user_id() === $uid;
        $post = function (string $k): string {
            return isset($_POST[$k]) && is_string($_POST[$k]) ? substr(trim((string) wp_unslash($_POST[$k])), 0, 40) : '';
        };
        $d = wppocket_2fa_load($uid);
        if (!$self) {
            if ($d !== null && !empty($_POST['wppocket_2fa_reset']) && current_user_can('edit_users') && current_user_can('edit_user', $uid)) {
                delete_user_meta($uid, WPPOCKET_2FA_META);
                $who = wp_get_current_user();
                wppocket_2fa_event('2FA BI DAT LAI: ' . $u->user_login . ' (boi quan tri ' . ($who instanceof WP_User ? $who->user_login : '?') . ')');
            }
            return;
        }
        if ($d === null) {
            $c = $post('wppocket_2fa_confirm');
            if ($c === '') {
                return;
            }
            $bin = wppocket_2fa_pending_secret($uid);
            $step = wppocket_2fa_match($bin, $c, time());
            if ($step === null) {
                $GLOBALS['wppocket_2fa_result'] = 'bad_confirm';
                return;
            }
            $codes = wppocket_2fa_make_recovery_codes();
            wppocket_2fa_save($uid, array('v' => 1, 'on' => 1, 's' => wppocket_2fa_encrypt($bin), 'r' => array_map('wppocket_2fa_recovery_hash', $codes), 'l' => $step, 'at' => time()));
            delete_user_meta($uid, WPPOCKET_2FA_PENDING);
            set_transient('wppocket_2fa_codes_' . $uid, wppocket_2fa_encrypt(implode(',', $codes)), 300);
            wppocket_2fa_event('2FA DA BAT: ' . $u->user_login);
            $GLOBALS['wppocket_2fa_result'] = 'on';
            return;
        }
        if (empty($_POST['wppocket_2fa_disable']) && empty($_POST['wppocket_2fa_regen'])) {
            return;
        }
        $r = wppocket_2fa_check($d, $post('wppocket_2fa_code'), time());
        if (!$r['ok']) {
            $GLOBALS['wppocket_2fa_result'] = 'bad_code';
            return;
        }
        if (!empty($_POST['wppocket_2fa_disable'])) {
            delete_user_meta($uid, WPPOCKET_2FA_META);
            wppocket_2fa_event('2FA DA TAT: ' . $u->user_login . ' (chinh nguoi dung, co ma)');
            $GLOBALS['wppocket_2fa_result'] = 'off';
            return;
        }
        $codes = wppocket_2fa_make_recovery_codes();
        $nd = $r['d'];
        $nd['r'] = array_map('wppocket_2fa_recovery_hash', $codes);
        wppocket_2fa_save($uid, $nd);
        set_transient('wppocket_2fa_codes_' . $uid, wppocket_2fa_encrypt(implode(',', $codes)), 300);
        wppocket_2fa_event('2FA MA KHOI PHUC DA TAO LAI: ' . $u->user_login);
        $GLOBALS['wppocket_2fa_result'] = 'regen';
    }

    function wppocket_2fa_register(): void
    {
        add_filter('authenticate', 'wppocket_2fa_authenticate', 40, 3);
        add_action('login_form', 'wppocket_2fa_login_field');
        add_action('woocommerce_login_form', 'wppocket_2fa_login_field');
        add_filter('login_errors', 'wppocket_2fa_login_errors', 99);
        add_action('show_user_profile', 'wppocket_2fa_render_profile');
        add_action('edit_user_profile', 'wppocket_2fa_render_profile');
        add_action('user_profile_update_errors', 'wppocket_2fa_profile_errors', 10, 3);
        add_action('personal_options_update', 'wppocket_2fa_profile_apply');
        add_action('edit_user_profile_update', 'wppocket_2fa_profile_apply');
    }
}

if (function_exists('add_filter')) {
    wppocket_2fa_register();
}
