<?php
/**
 * security-vuln.php - KIEM LO HONG DA BIET (CVE) cua loi WordPress / plugin / theme DANG CAI. HANDOFF.md muc 1br-H, docs/SECURITY.md.
 * Test: scripts/tests/security-vuln-test.py (may chu gia lap dung du lieu tu soan, KHONG goi mang that).
 *
 * BOI CANH: bai bao thang 7/2026 (WordPress 7.0.2/6.9.5) ghi nhan ke tan cong dung AI khai thac lo hong trong 90 phut - 5 gio sau khi cong bo. Quet ma doc
 * (security-scan.php) chi thay duoc SAU KHI da bi cai ma doc; viec nen lam TRUOC la biet plugin nao dang chay ban co lo hong da cong bo de cap nhat/go ngay.
 *
 * TUY CHON, MAC DINH TAT: bat bang file co lamp-run/vuln-check-on (Trung tam bao mat). Ly do tat mac dinh: tinh nang nay GUI ra dich vu ben thu ba
 * (www.wpvulnerability.net, API mien phi cua du an ma nguon mo WPVulnerability) danh sach slug + phien ban plugin/theme + phien ban WordPress cua may chu.
 * KHONG gui ten mien, IP rieng, noi dung site. Co the tro sang may chu rieng/ban sao bang file lamp-run/vuln-api-base (xem docs/PRIVACY.md).
 *
 * CACH LAM: hoi API theo {core|plugin|theme}/<slug hoac phien ban>/ (cau truc ban ghi lay tu ma nguon plugin WPVulnerability: operator.min/max_version +
 * min/max_operator theo version_compare cua PHP, unfixed/closed, impact.cvss.score/severity, source[]). Luu BAN GHI NEN gon vao cache 12 gio (that bai: thu lai
 * sau 1 gio) va doi chieu voi phien ban DANG CAI moi lan chay - nen cap nhat plugin xong chay lai la het canh bao ngay, khong phai doi cache het han.
 * Gioi han: toi da WPP_VULN_MAX_REQ yeu cau/lan, WPP_VULN_TIME_BUDGET giay (het gio thi dung, lan sau tiep tuc nho cache); chi plugin co thu muc rieng
 * (plugin 1 file nhu hello.php va plugin tra phi khong co tren wordpress.org thi API khong biet -> khong bao gi, KHONG co nghia la an toan).
 *
 * File nay vua la thu vien (admin-security.php nap de hien) vua la CLI: php security-vuln.php <docroot> <rundir> [check|status].
 */

const WPP_VULN_CACHE_OK = 43200;       // giay: ket qua API hop le dung lai trong 12 gio
const WPP_VULN_CACHE_FAIL = 3600;      // giay: that bai mang/API -> thu lai sau 1 gio (khong dap may chu moi 3 giay)
const WPP_VULN_MAX_REQ = 80;
const WPP_VULN_TIME_BUDGET = 50;
const WPP_VULN_MAX_BODY = 2097152;
const WPP_VULN_DEFAULT_BASE = 'https://www.wpvulnerability.net';

function wpp_vuln_paths(string $rundir): array
{
    $rd = rtrim($rundir, '/');
    return [
        'flag' => $rd . '/vuln-check-on', 'now' => $rd . '/vuln-check-now', 'base' => $rd . '/vuln-api-base', 'cache' => $rd . '/vuln-cache.json',
        'result' => $rd . '/security-vuln.json', 'seen' => $rd . '/vuln-seen.json', 'events' => $rd . '/security-events.log', 'lock' => $rd . '/vuln-check.lock',
    ];
}

function wpp_vuln_enabled(string $rundir): bool
{
    return is_file(wpp_vuln_paths($rundir)['flag']);
}

/** Dia chi goc cua API. File vuln-api-base (1 dong) chi duoc chap nhan neu la http(s)://host[:port][/duong-dan], khong chua khoang trang/tham so/kiem soat. */
function wpp_vuln_api_base(string $rundir): string
{
    $f = wpp_vuln_paths($rundir)['base'];
    $t = is_file($f) ? trim((string) @file_get_contents($f, false, null, 0, 300)) : '';
    if ($t !== '' && strlen($t) <= 200 && preg_match('~^https?://[A-Za-z0-9.\-]+(?::[0-9]{1,5})?(?:/[A-Za-z0-9._\-/]*)?$~', $t) === 1) {
        return rtrim($t, '/');
    }
    return WPP_VULN_DEFAULT_BASE;
}

function wpp_vuln_valid_slug(string $s): bool
{
    return preg_match('/^[a-z0-9][a-z0-9._\-]{0,99}$/', $s) === 1;
}

function wpp_vuln_valid_version(string $v): bool
{
    return preg_match('/^[0-9][0-9A-Za-z.\-+_]{0,40}$/', $v) === 1;
}

/** Gia tri 1 truong tieu de ("Version:", "Plugin Name:") trong 8KB dau cua file. */
function wpp_vuln_header(string $file, string $key): string
{
    $t = (string) @file_get_contents($file, false, null, 0, 8192);
    if (preg_match('/^[ \t\/*#@]*' . preg_quote($key, '/') . ':[ \t]*(.+)$/mi', $t, $m) === 1) {
        return trim(preg_replace('/[\x00-\x1f\x7f]+/', ' ', $m[1]));
    }
    return '';
}

/**
 * Kiem ke: ['core' => phien ban|null, 'plugins' => [slug => ['name','version']], 'themes' => [slug => ['name','version']], 'skipped' => [mo ta ngan]].
 * Plugin = thu muc trong wp-content/plugins co file .php o cap 1 mang "Plugin Name:" + "Version:"; slug = ten thu muc (nhu wordpress.org).
 */
function wpp_vuln_inventory(string $docroot): array
{
    $inv = ['core' => null, 'plugins' => [], 'themes' => [], 'skipped' => []];
    $vf = $docroot . '/wp-includes/version.php';
    if (is_file($docroot . '/wp-load.php') && is_file($vf)) {
        $t = (string) @file_get_contents($vf, false, null, 0, 20000);
        if (preg_match('/\$wp_version\s*=\s*\'([0-9][0-9A-Za-z.\-]*)\'/', $t, $m) === 1 && wpp_vuln_valid_version($m[1])) {
            $inv['core'] = $m[1];
        }
    }
    foreach ((array) @scandir($docroot . '/wp-content/plugins') as $d) {
        if (!is_string($d) || $d === '' || $d[0] === '.' || !is_dir($docroot . '/wp-content/plugins/' . $d)) {
            continue;
        }
        if (!wpp_vuln_valid_slug($d)) {
            $inv['skipped'][] = 'plugin ten la: ' . substr($d, 0, 40);
            continue;
        }
        $found = false;
        $n = 0;
        foreach ((array) @scandir($docroot . '/wp-content/plugins/' . $d) as $f) {
            if (!is_string($f) || !preg_match('/\.php$/i', $f) || ++$n > 30) {
                continue;
            }
            $p = $docroot . '/wp-content/plugins/' . $d . '/' . $f;
            if (!is_file($p) || wpp_vuln_header($p, 'Plugin Name') === '') {
                continue;
            }
            $ver = wpp_vuln_header($p, 'Version');
            if (wpp_vuln_valid_version($ver)) {
                $inv['plugins'][$d] = ['name' => substr(wpp_vuln_header($p, 'Plugin Name'), 0, 100), 'version' => $ver];
            } else {
                $inv['skipped'][] = 'plugin ' . $d . ': khong doc duoc phien ban';
            }
            $found = true;
            break;
        }
        if (!$found) {
            $inv['skipped'][] = 'plugin ' . $d . ': khong tim thay tep tieu de';
        }
    }
    foreach ((array) @scandir($docroot . '/wp-content/themes') as $d) {
        if (!is_string($d) || $d === '' || $d[0] === '.' || !is_file($docroot . '/wp-content/themes/' . $d . '/style.css')) {
            continue;
        }
        $css = $docroot . '/wp-content/themes/' . $d . '/style.css';
        $ver = wpp_vuln_header($css, 'Version');
        if (wpp_vuln_valid_slug($d) && wpp_vuln_valid_version($ver)) {
            $inv['themes'][$d] = ['name' => substr(wpp_vuln_header($css, 'Theme Name'), 0, 100), 'version' => $ver];
        } else {
            $inv['skipped'][] = 'theme ' . substr($d, 0, 40) . ': ten/phien ban khong hop le';
        }
    }
    return $inv;
}

const WPP_VULN_OPS = ['lt', 'le', 'gt', 'ge', 'eq', 'ne', '<', '<=', '>', '>=', '==', '!='];

/** Ban ghi (da chuan hoa o wpp_vuln_compact) co ap dung cho phien ban $version khong. Khong co can nao => KHONG (nhu plugin WPVulnerability goc). */
function wpp_vuln_applicable(array $r, string $version): bool
{
    $op = (array) ($r['op'] ?? []);
    $min = (string) ($op['min_version'] ?? '');
    $max = (string) ($op['max_version'] ?? '');
    $minOp = (string) ($op['min_operator'] ?? '');
    $maxOp = (string) ($op['max_operator'] ?? '');
    // Toan tu RONG = can do khong ton tai (giong plugin WPVulnerability goc: isset(operator) la null thi bo qua). Toan tu CO NHUNG la/khong di kem phien ban = ban ghi
    // hong -> KHONG ap dung (tuyet doi khong "bo can roi coi nhu trung": se bao nham ca plugin sach).
    foreach ([[$minOp, $min], [$maxOp, $max]] as [$o, $v]) {
        if ($o !== '' && ($v === '' || !in_array($o, WPP_VULN_OPS, true))) {
            return false;
        }
    }
    $hasMin = $minOp !== '';
    $hasMax = $maxOp !== '';
    if (!$hasMin && !$hasMax) {
        return false;
    }
    if ($hasMin && !version_compare($version, $min, $minOp)) {
        return false;
    }
    if ($hasMax && !version_compare($version, $max, $maxOp)) {
        return false;
    }
    return true;
}

function wpp_vuln_clean(string $s, int $max): string
{
    return substr(trim((string) preg_replace('/[\x00-\x1f\x7f]+/', ' ', $s)), 0, $max);
}

/** Rut gon 1 ban ghi lo hong cua API thanh dang nho de luu cache (bo mo ta dai; gioi han do dai moi truong - du lieu tu ben ngoai la KHONG TIN CAY). */
function wpp_vuln_compact(array $v): ?array
{
    if (!isset($v['operator']) || !is_array($v['operator'])) {
        return null;
    }
    $o = $v['operator'];
    $sev = '';
    $score = null;
    $cv = $v['impact']['cvss'] ?? null;
    if (is_array($cv)) {
        $sev = strtolower(substr((string) ($cv['severity'] ?? ''), 0, 1));
        $score = isset($cv['score']) && is_numeric($cv['score']) ? round((float) $cv['score'], 1) : null;
    }
    if (!in_array($sev, ['c', 'h', 'm', 'l', 'n'], true)) {
        $sev = $score === null ? '' : ($score >= 9.0 ? 'c' : ($score >= 7.0 ? 'h' : ($score >= 4.0 ? 'm' : ($score > 0 ? 'l' : 'n'))));
    }
    $src = [];
    foreach (array_slice((array) ($v['source'] ?? []), 0, 3) as $s) {
        if (!is_array($s)) {
            continue;
        }
        $link = (string) ($s['link'] ?? '');
        $src[] = ['name' => wpp_vuln_clean((string) ($s['name'] ?? $s['id'] ?? ''), 40), 'link' => preg_match('~^https?://[^\s<>"\']{1,300}$~', $link) === 1 ? $link : ''];
    }
    $g = fn($k) => wpp_vuln_clean((string) ($o[$k] ?? ''), 41);
    return [
        'n' => wpp_vuln_clean((string) ($v['name'] ?? ''), 200),
        'op' => ['min_version' => $g('min_version'), 'min_operator' => $g('min_operator'), 'max_version' => $g('max_version'), 'max_operator' => $g('max_operator')],
        'unfixed' => !empty($o['unfixed']) ? 1 : 0, 'closed' => !empty($o['closed']) ? 1 : 0,
        'sev' => $sev, 'score' => $score, 'src' => $src,
    ];
}

/** Hoi API 1 lan. Tra ['ok'=>bool,'v'=>ban ghi nen[]]. ok=false = loi mang/ma tra ve/JSON hong (khong cache lau). "Khong biet plugin nay" la ok=true, v rong. */
function wpp_vuln_fetch(string $base, string $type, string $slug): array
{
    $url = $base . '/' . $type . '/' . rawurlencode($slug) . '/';
    $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true, 'max_redirects' => 2, 'header' => "User-Agent: WPPocketServer-VulnCheck\r\nAccept: application/json\r\n"]]);
    $raw = @file_get_contents($url, false, $ctx, 0, WPP_VULN_MAX_BODY);
    $code = 0;
    if (isset($http_response_header[0]) && preg_match('~^HTTP/\S+\s+(\d{3})~', (string) $http_response_header[0], $m) === 1) {
        $code = (int) $m[1];
    }
    if (!is_string($raw) || $raw === '' || ($code !== 0 && ($code < 200 || $code >= 300) && $code !== 404)) {
        return ['ok' => false, 'v' => []];
    }
    $d = json_decode($raw, true);
    if (!is_array($d)) {
        return ['ok' => false, 'v' => []];
    }
    $list = $d['data']['vulnerability'] ?? [];
    $out = [];
    foreach (is_array($list) ? array_slice($list, 0, 150) : [] as $v) {
        $c = is_array($v) ? wpp_vuln_compact($v) : null;
        if ($c !== null) {
            $out[] = $c;
        }
    }
    return ['ok' => true, 'v' => $out];
}

function wpp_vuln_write(string $file, string $content): bool
{
    $tmp = $file . '.tmp.' . getmypid();
    if (@file_put_contents($tmp, $content) === false) {
        @unlink($tmp);
        return false;
    }
    return @rename($tmp, $file) ?: (@unlink($tmp) && false);
}

function wpp_vuln_sev_name(string $c): string
{
    return ['c' => 'critical', 'h' => 'high', 'm' => 'medium', 'l' => 'low', 'n' => 'low', '' => 'medium'][$c] ?? 'medium';
}

/**
 * 1 lan kiem. $fetch: ham thay the cho wpp_vuln_fetch (de test). Tra mang ket qua da ghi vao security-vuln.json (ke ca khi tat: {enabled:false}).
 * Khong bat: chi ghi {enabled:false}, KHONG mo ket noi nao.
 */
function wpp_vuln_run(string $docroot, string $rundir, ?int $now = null, ?callable $fetch = null): array
{
    $now = $now ?? time();
    $p = wpp_vuln_paths($rundir);
    if (!wpp_vuln_enabled($rundir)) {
        $r = ['at' => $now, 'enabled' => false, 'findings' => [], 'counts' => ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0]];
        wpp_vuln_write($p['result'], json_encode($r));
        return $r;
    }
    $fetch = $fetch ?? 'wpp_vuln_fetch';
    $base = wpp_vuln_api_base($rundir);
    $inv = wpp_vuln_inventory($docroot);
    $cache = is_file($p['cache']) ? (json_decode((string) @file_get_contents($p['cache']), true) ?: []) : [];
    $started = microtime(true);
    $req = 0;
    $failed = 0;
    $truncated = false;
    $targets = [];
    if ($inv['core'] !== null) {
        $targets[] = ['core', $inv['core'], $inv['core'], 'WordPress ' . $inv['core']];
    }
    foreach ($inv['plugins'] as $slug => $i) {
        $targets[] = ['plugin', $slug, $i['version'], $i['name']];
    }
    foreach ($inv['themes'] as $slug => $i) {
        $targets[] = ['theme', $slug, $i['version'], $i['name']];
    }
    $findings = [];
    foreach ($targets as [$type, $slug, $version, $name]) {
        $key = $type . ':' . $slug;
        $c = $cache[$key] ?? null;
        $age = is_array($c) ? $now - (int) ($c['at'] ?? 0) : PHP_INT_MAX;
        $fresh = is_array($c) && $age >= 0 && $age < (!empty($c['ok']) ? WPP_VULN_CACHE_OK : WPP_VULN_CACHE_FAIL);
        if (!$fresh) {
            if ($req >= WPP_VULN_MAX_REQ || microtime(true) - $started > WPP_VULN_TIME_BUDGET) {
                $truncated = true;
            } else {
                $req++;
                $r = $fetch($base, $type, $slug);
                $c = ['at' => $now, 'ok' => !empty($r['ok']) ? 1 : 0, 'v' => $r['v'] ?? []];
                if (!$c['ok']) {
                    $failed++;
                    $c['v'] = is_array($cache[$key]['v'] ?? null) ? $cache[$key]['v'] : [];      // giu du lieu cu khi mang loi (van canh bao theo ban da biet)
                }
                $cache[$key] = $c;
            }
        }
        foreach ((array) ($c['v'] ?? []) as $rec) {
            if (!is_array($rec) || !wpp_vuln_applicable($rec, $version)) {
                continue;
            }
            $findings[] = [
                'sev' => wpp_vuln_sev_name((string) ($rec['sev'] ?? '')), 'kind' => 'lo-hong-' . $type, 'type' => $type, 'slug' => $slug, 'name' => (string) $name,
                'version' => $version, 'title' => (string) ($rec['n'] ?? ''), 'score' => $rec['score'] ?? null, 'unfixed' => (int) ($rec['unfixed'] ?? 0),
                'closed' => (int) ($rec['closed'] ?? 0), 'src' => (array) ($rec['src'] ?? []),
                'fixed_before' => (string) ($rec['op']['max_version'] ?? '') . ' (' . (string) ($rec['op']['max_operator'] ?? '') . ')',
            ];
        }
    }
    // cache: bo muc khong con trong kiem ke (plugin da go), gioi han kich thuoc
    $live = [];
    foreach ($targets as [$type, $slug]) {
        if (isset($cache[$type . ':' . $slug])) {
            $live[$type . ':' . $slug] = $cache[$type . ':' . $slug];
        }
    }
    wpp_vuln_write($p['cache'], json_encode($live));
    $rank = ['critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1];
    usort($findings, fn($a, $b) => ($rank[$b['sev']] <=> $rank[$a['sev']]) ?: strcmp($a['slug'], $b['slug']));
    $counts = ['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0];
    foreach ($findings as $f) {
        $counts[$f['sev']]++;
    }
    $res = [
        'at' => $now, 'enabled' => true, 'base' => $base, 'core' => $inv['core'], 'plugins' => count($inv['plugins']), 'themes' => count($inv['themes']),
        'requests' => $req, 'failed' => $failed, 'truncated' => $truncated, 'skipped' => array_slice($inv['skipped'], 0, 20), 'counts' => $counts, 'findings' => array_slice($findings, 0, 200),
    ];
    wpp_vuln_write($p['result'], json_encode($res));
    wpp_vuln_events($p, $findings, $now);
    return $res;
}

/** Su kien cho phat hien MOI (chua bao truoc do): nghiem trong/cao => "LO HONG NGHIEM TRONG" (khan), trung binh => "LO HONG PLUGIN" (luu y); thap khong bao. Toi da 5/lan. */
function wpp_vuln_events(array $p, array $findings, int $now): void
{
    $seen = is_file($p['seen']) ? (json_decode((string) @file_get_contents($p['seen']), true) ?: []) : [];
    $new = [];
    foreach ($findings as $f) {
        if ($f['sev'] === 'low') {
            continue;
        }
        $k = $f['type'] . '|' . $f['slug'] . '|' . $f['version'] . '|' . substr(sha1($f['title']), 0, 12);
        if (!isset($seen[$k])) {
            $seen[$k] = $now;
            $new[] = $f;
        }
    }
    foreach (array_slice($new, 0, 5) as $f) {
        $urgent = in_array($f['sev'], ['critical', 'high'], true);
        $cve = '';
        foreach ($f['src'] as $s) {
            if (preg_match('/^CVE-\d{4}-\d{3,7}$/', (string) ($s['name'] ?? '')) === 1) {
                $cve = ' ' . $s['name'];
                break;
            }
        }
        $line = date('Y-m-d H:i:s', $now) . ' ip=- ' . ($urgent ? 'LO HONG NGHIEM TRONG' : 'LO HONG PLUGIN') . ' (' . $f['sev'] . '): ' . $f['type'] . ' ' . $f['slug'] . ' ' . $f['version']
            . ($f['unfixed'] ? ' [CHUA CO BAN VA]' : '') . $cve . ' - ' . wpp_vuln_clean($f['title'], 100) . "\n";
        @file_put_contents($p['events'], $line, FILE_APPEND | LOCK_EX);
    }
    if (count($new) > 5) {
        @file_put_contents($p['events'], date('Y-m-d H:i:s', $now) . ' ip=- LO HONG PLUGIN: ' . (count($new) - 5) . " muc nua - xem _admin/security.php\n", FILE_APPEND | LOCK_EX);
    }
    if (count($seen) > 2000) {
        asort($seen);
        $seen = array_slice($seen, -1500, null, true);
    }
    wpp_vuln_write($p['seen'], json_encode($seen));
}

function wpp_vuln_last(string $rundir): ?array
{
    $f = wpp_vuln_paths($rundir)['result'];
    $d = is_file($f) ? json_decode((string) @file_get_contents($f), true) : null;
    return is_array($d) ? $d : null;
}

// ------------------------------------------------------------------------------------------------------------------
// CLI
// ------------------------------------------------------------------------------------------------------------------
if (PHP_SAPI === 'cli' && !defined('WPP_VULN_AS_LIB') && isset($_SERVER['argv'][0]) && realpath($_SERVER['argv'][0]) === __FILE__) {
    $docroot = $_SERVER['argv'][1] ?? '';
    $rundir = $_SERVER['argv'][2] ?? '';
    $mode = $_SERVER['argv'][3] ?? 'check';
    if ($docroot === '' || $rundir === '' || !is_dir($docroot) || !is_dir($rundir)) {
        fwrite(STDERR, "dung: php security-vuln.php <docroot> <thu_muc_lamp-run> [check|status]\n");
        exit(2);
    }
    if ($mode === 'status') {
        $r = wpp_vuln_last($rundir);
        echo $r === null ? "chua kiem lan nao\n" : json_encode(['at' => $r['at'] ?? 0, 'enabled' => $r['enabled'] ?? false, 'counts' => $r['counts'] ?? []]) . "\n";
        exit(0);
    }
    $lp = wpp_vuln_paths($rundir)['lock'];
    $lh = @fopen($lp, 'c');
    if ($lh && !flock($lh, LOCK_EX | LOCK_NB)) {
        echo "dang co lan kiem khac chay\n";
        exit(0);
    }
    @unlink(wpp_vuln_paths($rundir)['now']);
    $r = wpp_vuln_run($docroot, $rundir);
    if (empty($r['enabled'])) {
        echo "kiem lo hong dang TAT (tao lamp-run/vuln-check-on de bat)\n";
        exit(0);
    }
    echo sprintf("kiem %d plugin, %d theme, loi lo %s: %d nghiem trong, %d cao, %d trung binh, %d thap (%d yeu cau, %d loi mang%s)\n", $r['plugins'], $r['themes'], (string) $r['core'],
        $r['counts']['critical'], $r['counts']['high'], $r['counts']['medium'], $r['counts']['low'], $r['requests'], $r['failed'], $r['truncated'] ? ', CHUA XONG (het gio/han muc, lan sau tiep tuc)' : '');
    exit(0);
}
