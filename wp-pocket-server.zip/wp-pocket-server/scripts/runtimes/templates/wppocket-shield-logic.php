<?php
/**
 * WP Pocket Shield - lop bao ve BEN TRONG WordPress (mu-plugin, HANDOFF.md muc 1br, docs/SECURITY.md). Test: scripts/tests/shield-test.py.
 *
 * Bo sung cho lop nginx/guard (chan o cua): nhung viec chi WordPress biet moi lam duoc.
 *  1. Chong DO TEN TAI KHOAN: an /wp-json/wp/v2/users cho khach, chan ?author=N, bo "users" khoi sitemap, thong bao dang nhap sai chung chung
 *     (khong tiet lo "ten khong ton tai" hay "sai mat khau"). Ke tan cong (nhat la cong cu AI) can ten tai khoan that truoc khi do mat khau.
 *  2. Chong DO MAT KHAU PHAN TAN: ke tan cong dung hang tram IP cloud, moi IP chi thu vai lan nen nginx/guard (tinh theo IP) khong thay. O day dem
 *     theo TAI KHOAN: qua nhieu lan sai (bat ke IP nao) -> tai khoan vao "che do phong thu" ~15 phut: chi IP/mang (/24, /48 voi IPv6) DA TUNG dang nhap
 *     thanh cong moi duoc vao. Chu site tu mang quen thuoc khong bi anh huong.
 *  3. Nhat ky su kien nhay cam (tai khoan quan tri MOI / cap quyen quan tri / doi email quan tri / bat plugin / admin dang nhap tu mang la) ghi vao
 *     lamp-run/security-events.log de ung dung canh bao (vu khai thac WordPress 7/2026: >100 tai khoan admin tao ngam).
 *  4. Giam dau van tay phien ban: bo the generator, bam ma "?ver=" cua script/style (van doi khi cap nhat de trinh duyet tai lai), tat sua file
 *     plugin/theme trong trang quan tri (DISALLOW_FILE_EDIT) - 1 admin bi chiem khong con sua thang ma PHP duoc, XML-RPC tat.
 *
 * KHONG lam: khoa IP (viec cua nginx), xoa tai khoan/plugin (chi ghi su kien), thay doi du lieu WordPress.
 * Cong tat: file co trong lamp-run/ (dat/xoa tu _admin/security.php):  shield-off (tat het),  shield-allow-user-api (cho khach doc REST users:
 * site headless/ung dung), shield-allow-file-edit (cho sua file trong admin), shield-allow-app-passwords (cho mat khau ung dung). Moi loi trong file nay duoc loader nuot (try/catch Throwable).
 */
if (!defined('ABSPATH')) {
    exit;
}

const WPPOCKET_SHIELD_WINDOW = 900;           // giay: cua so dem lan sai
const WPPOCKET_SHIELD_USER_LIMIT = 20;        // so lan sai (bat ke IP) vao cua so -> phong thu tai khoan
const WPPOCKET_SHIELD_IP_LIMIT = 8;           // so lan sai cua MOT mang vao 1 tai khoan trong cua so -> chan mang do
const WPPOCKET_SHIELD_LOCK_SECONDS = 900;     // thoi gian phong thu (gia han khi con bi do tiep)
const WPPOCKET_SHIELD_KNOWN_DAYS = 60;        // mang "quen" het han sau chung nay ngay khong dang nhap
const WPPOCKET_SHIELD_MAX_USERS = 300;        // so tai khoan toi da luu (chong phinh file bang ten tai khoan ngau nhien)

if (!function_exists('wppocket_shield_home')) {

    /** Thu muc lamp-run (qua APP_HOME) hoac '' khi khong co (vd chay ngoai ung dung). */
    function wppocket_shield_home(): string
    {
        $h = getenv('APP_HOME');
        if (!is_string($h) || $h === '') {
            return '';
        }
        $d = rtrim($h, '/') . '/lamp-run';
        return is_dir($d) ? $d : '';
    }

    function wppocket_shield_flag(string $name): bool
    {
        static $cache = array();
        if (!isset($cache[$name])) {
            $d = wppocket_shield_home();
            $cache[$name] = $d !== '' && is_file($d . '/' . $name);
        }
        return $cache[$name];
    }

    /** IP khach (REMOTE_ADDR sau realip) hop le, hoac ''. */
    function wppocket_shield_ip(): string
    {
        $ip = isset($_SERVER['REMOTE_ADDR']) && is_string($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
        return filter_var($ip, FILTER_VALIDATE_IP) !== false ? $ip : '';
    }

    /** IP loopback/LAN/CGNAT/link-local: khi thieu realip moi khach cong khai deu hien thanh 127.0.0.1 -> khong the phan biet nguoi, khong ap dung chan. */
    function wppocket_shield_ip_is_private(string $ip): bool
    {
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
            return true;
        }
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
            $l = ip2long($ip);
            return $l !== false && ($l & 0xFFC00000) === 0x64400000;     // 100.64.0.0/10
        }
        return false;
    }

    /** Khoa mang: IPv4 /24, IPv6 /48 bam HMAC (khong luu IP that trong file trang thai). '' neu IP rieng/khong hop le. */
    function wppocket_shield_ip_key(string $ip): string
    {
        if ($ip === '' || wppocket_shield_ip_is_private($ip)) {
            return '';
        }
        $bin = @inet_pton($ip);
        if ($bin === false) {
            return '';
        }
        $prefix = strlen($bin) === 4 ? substr($bin, 0, 3) : substr($bin, 0, 6);
        $salt = defined('AUTH_SALT') ? (string) AUTH_SALT : 'wppocket-shield';
        return substr(hash_hmac('sha256', $prefix . (strlen($bin) === 4 ? '4' : '6'), $salt), 0, 12);
    }

    function wppocket_shield_store_path(): string
    {
        $d = wppocket_shield_home();
        return $d === '' ? '' : $d . '/shield-login.json';
    }

    /**
     * Doc-sua-ghi nguyen tu duoi flock. $fn nhan mang trang thai, tra mang moi (hoac null = khong ghi). Tra gia tri $fn tra ve qua $out.
     * Dung chung file voi _admin/security.php (xem muc "Trang thai dang nhap" - chi doc/xoa).
     */
    function wppocket_shield_store(string $file, callable $fn, &$out = null): bool
    {
        if ($file === '') {
            return false;
        }
        $fh = @fopen($file, 'c+');
        if (!$fh) {
            return false;
        }
        if (!flock($fh, LOCK_EX)) {
            fclose($fh);
            return false;
        }
        $d = json_decode((string) stream_get_contents($fh), true);
        if (!is_array($d) || ($d['v'] ?? 0) !== 1) {
            $d = array('v' => 1, 'u' => array(), 'k' => array());
        }
        $new = $fn($d, $out);
        if (is_array($new)) {
            // gioi han kich thuoc: bo tai khoan it hoat dong nhat
            if (count($new['u']) > WPPOCKET_SHIELD_MAX_USERS) {
                uasort($new['u'], function ($a, $b) {
                    return ((int) ($b['last'] ?? 0)) <=> ((int) ($a['last'] ?? 0));
                });
                $new['u'] = array_slice($new['u'], 0, WPPOCKET_SHIELD_MAX_USERS, true);
            }
            if (count($new['k']) > WPPOCKET_SHIELD_MAX_USERS) {
                $new['k'] = array_slice($new['k'], 0, WPPOCKET_SHIELD_MAX_USERS, true);
            }
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, json_encode($new));
            fflush($fh);
            @chmod($file, 0600);
        }
        flock($fh, LOCK_UN);
        fclose($fh);
        return true;
    }

    /** Khoa tai khoan: 'id:N' neu ton tai (gom ten dang nhap + email), neu khong 'n:ten' (chu thuong). */
    function wppocket_shield_user_key($typed): string
    {
        $t = strtolower(trim((string) $typed));
        if ($t === '') {
            return '';
        }
        $t = substr($t, 0, 100);
        if (function_exists('get_user_by')) {
            $u = strpos($t, '@') !== false ? get_user_by('email', $t) : get_user_by('login', $t);
            if ($u && !empty($u->ID)) {
                return 'id:' . (int) $u->ID;
            }
        }
        return 'n:' . $t;
    }

    function wppocket_shield_prune(array $times, int $now, int $window = WPPOCKET_SHIELD_WINDOW): array
    {
        return array_values(array_filter($times, function ($t) use ($now, $window) {
            return is_int($t) && $t > $now - $window && $t <= $now + 5;
        }));
    }

    /** Ghi 1 lan dang nhap SAI. Tra ['locked'=>bool,'new_lock'=>bool,'until'=>int,'ip_blocked'=>bool]. Khong lam gi (tra false het) neu khong biet IP. */
    function wppocket_shield_record_failure(string $file, string $ukey, string $ipk, int $now): array
    {
        $res = array('locked' => false, 'new_lock' => false, 'until' => 0, 'ip_blocked' => false);
        if ($ukey === '' || $ipk === '') {
            return $res;
        }
        $out = null;
        wppocket_shield_store($file, function (array $d, &$out) use ($ukey, $ipk, $now) {
            $e = $d['u'][$ukey] ?? array('f' => array(), 'i' => array(), 'lock' => 0);
            $e['f'] = wppocket_shield_prune((array) ($e['f'] ?? array()), $now);
            $e['f'][] = $now;
            $e['f'] = array_slice($e['f'], -200);
            $ips = (array) ($e['i'] ?? array());
            $ips[$ipk] = wppocket_shield_prune((array) ($ips[$ipk] ?? array()), $now);
            $ips[$ipk][] = $now;
            $ips[$ipk] = array_slice($ips[$ipk], -50);
            foreach ($ips as $k => $v) {                                     // mang het han: bo
                if (!$v || end($v) <= $now - WPPOCKET_SHIELD_WINDOW) {
                    unset($ips[$k]);
                }
            }
            $ips = array_slice($ips, -30, null, true);
            $e['i'] = $ips;
            $wasLocked = (int) ($e['lock'] ?? 0) > $now;
            if (count($e['f']) >= WPPOCKET_SHIELD_USER_LIMIT) {
                $e['lock'] = $now + WPPOCKET_SHIELD_LOCK_SECONDS;
            }
            $e['last'] = $now;
            $out = array(
                'locked' => (int) $e['lock'] > $now,
                'new_lock' => !$wasLocked && (int) $e['lock'] > $now,
                'until' => (int) $e['lock'],
                'ip_blocked' => count($ips[$ipk] ?? array()) >= WPPOCKET_SHIELD_IP_LIMIT,
            );
            $d['u'][$ukey] = $e;
            return $d;
        }, $out);
        return is_array($out) ? $out : $res;
    }

    /** Ghi dang nhap THANH CONG: nho mang nay la "quen" cua tai khoan. Tra true neu mang nay LA MOI (truoc do tai khoan da co mang quen khac). */
    function wppocket_shield_record_success(string $file, string $ukey, string $ipk, int $now): bool
    {
        if ($ukey === '' || $ipk === '') {
            return false;
        }
        $isNew = false;
        $out = null;
        wppocket_shield_store($file, function (array $d, &$out) use ($ukey, $ipk, $now, &$isNew) {
            $known = (array) ($d['k'][$ukey] ?? array());
            $cut = $now - WPPOCKET_SHIELD_KNOWN_DAYS * 86400;
            foreach ($known as $k => $t) {
                if (!is_int($t) || $t < $cut) {
                    unset($known[$k]);
                }
            }
            $isNew = !isset($known[$ipk]) && count($known) > 0;
            $known[$ipk] = $now;
            if (count($known) > 20) {
                asort($known);
                $known = array_slice($known, -20, null, true);
            }
            $d['k'][$ukey] = $known;
            if (isset($d['u'][$ukey]['i'][$ipk])) {
                unset($d['u'][$ukey]['i'][$ipk]);            // mang quen dang nhap dung thi het "so lan sai" cua rieng mang do
            }
            return $d;
        }, $out);
        return $isNew;
    }

    /** Dang nhap nay co bi chan truoc khi kiem tra mat khau khong? Tra '' (cho qua), 'user' (tai khoan dang phong thu, mang la) hoac 'ip' (mang do qua nhieu). */
    function wppocket_shield_blocked(string $file, string $ukey, string $ipk, int $now): string
    {
        if ($ukey === '' || $ipk === '' || $file === '' || !is_file($file)) {
            return '';
        }
        $why = '';
        $out = null;
        wppocket_shield_store($file, function (array $d, &$out) use ($ukey, $ipk, $now, &$why) {
            $known = isset($d['k'][$ukey][$ipk]) && is_int($d['k'][$ukey][$ipk]) && $d['k'][$ukey][$ipk] > $now - WPPOCKET_SHIELD_KNOWN_DAYS * 86400;
            if ($known) {
                return null;                                  // mang quen: khong bao gio bi chan boi lop nay
            }
            $e = $d['u'][$ukey] ?? null;
            if (!is_array($e)) {
                return null;
            }
            if ((int) ($e['lock'] ?? 0) > $now) {
                $why = 'user';
            } elseif (count(wppocket_shield_prune((array) ($e['i'][$ipk] ?? array()), $now)) >= WPPOCKET_SHIELD_IP_LIMIT) {
                $why = 'ip';
            }
            return null;
        }, $out);
        return $why;
    }

    /** Xoa trang thai phong thu (UI). $ukey '' = xoa het. */
    function wppocket_shield_clear(string $file, string $ukey = ''): bool
    {
        $out = null;
        return wppocket_shield_store($file, function (array $d, &$out) use ($ukey) {
            if ($ukey === '') {
                $d['u'] = array();
            } else {
                unset($d['u'][$ukey]);
            }
            return $d;
        }, $out);
    }

    /** Ghi su kien vao lamp-run/security-events.log (cung dinh dang voi security-guard/security-scan). Tu cat khi file qua lon. */
    function wppocket_shield_event(string $msg): void
    {
        $d = wppocket_shield_home();
        if ($d === '') {
            return;
        }
        $file = $d . '/security-events.log';
        $ip = wppocket_shield_ip();
        $msg = preg_replace('/[\x00-\x1f\x7f]+/', ' ', $msg);
        $line = date('Y-m-d H:i:s') . ' ip=' . ($ip !== '' ? $ip : '-') . ' ' . substr((string) $msg, 0, 240) . "\n";
        @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
        if (mt_rand(1, 40) === 1 && @filesize($file) > 262144) {
            $all = @file($file, FILE_IGNORE_NEW_LINES) ?: array();
            if (count($all) > 1500) {
                @file_put_contents($file, implode("\n", array_slice($all, -1000)) . "\n", LOCK_EX);
            }
        }
    }

    function wppocket_shield_mask_email($e): string
    {
        $e = (string) $e;
        $p = strpos($e, '@');
        return $p === false || $p < 1 ? '***' : substr($e, 0, 1) . '***' . substr($e, $p);
    }

    /** ?author=<so> (do ten tai khoan qua chuyen huong /author/ten/). Chi so thuan; ?author_name va duong dan dep khong dung. */
    function wppocket_shield_is_author_enum(array $query): bool
    {
        return isset($query['author']) && is_scalar($query['author']) && preg_match('/^\d{1,10}$/', (string) $query['author']) === 1;
    }

    /** Thay "ver=X" thanh "ver=<bam 10 ky tu>": van doi khi phien ban doi (trinh duyet tai lai) nhung khong lo so phien ban WordPress/plugin. */
    function wppocket_shield_hide_ver($src): string
    {
        $src = (string) $src;
        $salt = defined('AUTH_SALT') ? (string) AUTH_SALT : 'wppocket-shield';
        return preg_replace_callback('/([?&])ver=([^&#]*)/', function ($m) use ($salt) {
            return $m[1] . 'ver=' . substr(hash_hmac('sha256', $m[2], $salt), 0, 10);
        }, $src) ?? $src;
    }

    function wppocket_shield_login_message(bool $locked): string
    {
        return $locked ? 'Too many failed sign-in attempts. Please try again in a few minutes.' : 'Sign-in failed. Check your username and password.';
    }

    function wppocket_shield_register(): void
    {
        if (wppocket_shield_flag('shield-off')) {
            return;
        }
        if (!defined('DISALLOW_FILE_EDIT') && !wppocket_shield_flag('shield-allow-file-edit')) {
            define('DISALLOW_FILE_EDIT', true);
        }

        // ---- 1) chong do ten tai khoan ----
        add_filter('rest_endpoints', function ($eps) {
            if (is_array($eps) && !wppocket_shield_flag('shield-allow-user-api') && !(function_exists('is_user_logged_in') && is_user_logged_in())) {
                unset($eps['/wp/v2/users'], $eps['/wp/v2/users/(?P<id>[\d]+)']);
            }
            return $eps;
        });
        add_action('template_redirect', function () {
            if (!(function_exists('is_user_logged_in') && is_user_logged_in()) && wppocket_shield_is_author_enum($_GET)) {
                wp_safe_redirect(home_url('/'), 301);
                exit;
            }
        }, 1);
        add_filter('wp_sitemaps_add_provider', function ($provider, $name) {
            return $name === 'users' ? false : $provider;
        }, 10, 2);
        add_filter('login_errors', function ($errors) {
            // chi man hinh DANG NHAP (khong dung vao quen mat khau/dat lai - thong bao rieng cua man hinh do giu nguyen)
            $action = isset($_REQUEST['action']) && is_string($_REQUEST['action']) ? $_REQUEST['action'] : 'login';
            if ($action !== 'login' && $action !== '') {
                return $errors;
            }
            return wppocket_shield_login_message(!empty($GLOBALS['wppocket_shield_locked']));
        });
        add_filter('xmlrpc_enabled', '__return_false');
        // Phat hien khi dung WordPress THAT (1br-H): xmlrpc_enabled=false chi chan cac ham can dang nhap; system.listMethods/system.multicall van tra loi cho khach.
        // Bo het ham de XML-RPC khong con dung duoc (nginx Full da chan xmlrpc.php; day la lop thu hai cho che do Lite/khi nginx khong chan).
        add_filter('xmlrpc_methods', '__return_empty_array');
        if (!wppocket_shield_flag('shield-allow-app-passwords')) {
            add_filter('wp_is_application_passwords_available', '__return_false');   // mat khau ung dung = cua hau cho admin bi chiem (qua mat 2FA/chan dang nhap)
        }

        // ---- 4) giam dau van tay ----
        remove_action('wp_head', 'wp_generator');
        add_filter('the_generator', '__return_empty_string');
        add_filter('style_loader_src', 'wppocket_shield_hide_ver', 20);
        add_filter('script_loader_src', 'wppocket_shield_hide_ver', 20);

        // ---- 2) chong do mat khau phan tan ----
        $guard = function ($user, $ukey) {
            $ipk = wppocket_shield_ip_key(wppocket_shield_ip());
            $why = wppocket_shield_blocked(wppocket_shield_store_path(), $ukey, $ipk, time());
            if ($why === '') {
                return $user;
            }
            $GLOBALS['wppocket_shield_locked'] = true;
            return new WP_Error('wppocket_locked', wppocket_shield_login_message(true));
        };
        // truoc khi kiem tra mat khau (tiet kiem CPU bam mat khau) - chi khi tai khoan co that
        add_filter('wp_authenticate_user', function ($user, $password) use ($guard) {
            if ($user instanceof WP_User) {
                return $guard($user, 'id:' . (int) $user->ID);
            }
            return $user;
        }, 1, 2);
        // sau cung (lop xac thuc khac co the thay ket qua loi bang WP_User): ten + mat khau co gui moi xet, khong chan dang nhap bang cookie
        add_filter('authenticate', function ($user, $username, $password) use ($guard) {
            if ($user instanceof WP_User && (string) $username !== '' && (string) $password !== '') {
                return $guard($user, wppocket_shield_user_key($username));
            }
            return $user;
        }, 99, 3);
        add_action('wp_login_failed', function ($username) {
            $ip = wppocket_shield_ip();
            $ukey = wppocket_shield_user_key($username);
            $r = wppocket_shield_record_failure(wppocket_shield_store_path(), $ukey, wppocket_shield_ip_key($ip), time());
            if ($r['new_lock']) {
                wppocket_shield_event('TAM KHOA DANG NHAP tai khoan ' . ($ukey === '' ? '?' : $ukey) . ' (qua nhieu lan sai tu nhieu mang) ~' . (int) (WPPOCKET_SHIELD_LOCK_SECONDS / 60) . ' phut');
            }
        });
        add_action('wp_login', function ($login, $user) {
            $ipk = wppocket_shield_ip_key(wppocket_shield_ip());
            $uid = is_object($user) && !empty($user->ID) ? (int) $user->ID : 0;
            if ($uid === 0 || $ipk === '') {
                return;
            }
            $newNet = wppocket_shield_record_success(wppocket_shield_store_path(), 'id:' . $uid, $ipk, time());
            if ($newNet && function_exists('user_can') && user_can($user, 'manage_options')) {
                wppocket_shield_event('DANG NHAP QUAN TRI TU MANG MOI: ' . $login . ' (id ' . $uid . ')');
            }
        }, 10, 2);

        // ---- 3) su kien nhay cam ----
        add_action('user_register', function ($uid) {
            $u = function_exists('get_userdata') ? get_userdata($uid) : false;
            if ($u && in_array('administrator', (array) $u->roles, true)) {
                wppocket_shield_event('TAI KHOAN QUAN TRI MOI: ' . $u->user_login . ' (id ' . (int) $uid . ')');
            }
        });
        $roleEvt = function ($uid, $role) {
            if ($role === 'administrator') {
                $u = function_exists('get_userdata') ? get_userdata($uid) : false;
                wppocket_shield_event('QUYEN QUAN TRI DUOC CAP CHO: ' . ($u ? $u->user_login : '?') . ' (id ' . (int) $uid . ')');
            }
        };
        add_action('set_user_role', $roleEvt, 10, 2);
        add_action('add_user_role', $roleEvt, 10, 2);
        add_action('update_option_admin_email', function ($old, $new) {
            wppocket_shield_event('EMAIL QUAN TRI DA DOI: ' . wppocket_shield_mask_email($old) . ' -> ' . wppocket_shield_mask_email($new));
        }, 10, 2);
        add_action('activated_plugin', function ($plugin) {
            wppocket_shield_event('PLUGIN VUA DUOC KICH HOAT: ' . $plugin);
        });
    }
}

if (function_exists('add_filter')) {
    wppocket_shield_register();
}
