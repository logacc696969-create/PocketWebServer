<?php
/**
 * Plugin Name: WP Pocket - Shield (bao ve WordPress chong do tai khoan/mat khau, ghi su kien nhay cam)
 * Description: Chan do ten tai khoan, phong thu tai khoan khi bi do mat khau tu nhieu IP, ghi nhat ky tai khoan quan tri moi/plugin moi kich hoat, giau phien ban. Xem docs/SECURITY.md (HANDOFF.md muc 1br). Logic o wppocket-shield/shield.php.
 *
 * Tach 2 file CO CHU DICH (cung cach voi wppocket-pagecache/wppocket-images): file nap nay cuc ngan va duoc WordPress nap cho MOI request - mot loi cu
 * phap o day lam TRANG CA SITE. Logic that nam o shield.php, nap qua try/catch Throwable: loi trong do (ke ca ParseError) chi lam mat lop bao ve
 * phu nay, KHONG lam hong website (nginx + guard van chay). Tat khan cap: tao file lamp-run/shield-off.
 */
if (!defined('ABSPATH')) {
    exit;
}
try {
    require_once __DIR__ . '/wppocket-shield/shield.php';
} catch (\Throwable $e) {
    // nuot: lop bao ve phu, khong duoc anh huong website
}
