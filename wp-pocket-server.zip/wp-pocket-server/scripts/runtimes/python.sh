#!/usr/bin/env bash
# Chuẩn bị runtime Python: tải binary python từ Termux + mã nguồn website +
# sinh runtime.json. Dùng khi site.config.json có "runtime": "python".
#
# Nếu có "entry" (vd "app.py") -> chạy thẳng file đó (app tự bind PORT qua
# biến môi trường PORT). Nếu không có entry -> dùng http.server có sẵn của
# Python để phục vụ file tĩnh (không cần code gì thêm).
#
# Usage: scripts/runtimes/python.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh

EXTRACT_DIR="$(mktemp -d)"
termux_download_with_deps python "$EXTRACT_DIR"

PY_BIN="$(termux_find_binary "$EXTRACT_DIR" python3)"
[[ -z "$PY_BIN" ]] && PY_BIN="$(termux_find_binary "$EXTRACT_DIR" python)"
if [[ -z "$PY_BIN" ]]; then
  echo "LOI: khong tim thay binary python sau khi tai tu Termux" >&2
  exit 1
fi
cp "$PY_BIN" "$OUT_DIR/libruntimesrv.so"
chmod 755 "$OUT_DIR/libruntimesrv.so"
find "$EXTRACT_DIR" -type f -name '*.so*' -exec cp -n {} "$OUT_DIR/" \; 2>/dev/null || true

STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"
(cd "$STAGING" && zip -qr "$OLDPWD/$OUT_DIR/www.zip" .)

PORT="$(jq -r '.port // 8080' site.config.json)"
ENTRY="$(jq -r '.entry // ""' site.config.json)"
[[ "$ENTRY" == "null" ]] && ENTRY=""

if [[ -n "$ENTRY" ]]; then
  EXEC_JSON="[\"\${BIN}\", \"\${DOCROOT}/${ENTRY}\"]"
else
  EXEC_JSON="[\"\${BIN}\", \"-m\", \"http.server\", \"\${PORT}\", \"--directory\", \"\${DOCROOT}\", \"--bind\", \"0.0.0.0\"]"
fi

cat > "$OUT_DIR/runtime.json" <<JSON
{
  "port": ${PORT},
  "binary": "libruntimesrv.so",
  "docroot": "www",
  "exec": ${EXEC_JSON},
  "env": {
    "PYTHONUNBUFFERED": "1"
  }
}
JSON

echo "Xong: $OUT_DIR (runtime=python, entry='${ENTRY:-<mac dinh: http.server tinh>}')"
