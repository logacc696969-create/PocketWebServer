#!/usr/bin/env bash
# Chuẩn bị runtime Python: tải binary python từ Termux + mã nguồn website +
# sinh runtime.json. Dùng khi site.config.json có "runtime": "python".
#
# Nếu có "wsgi" (vd "app:app" cho Flask, "mysite.wsgi:application" cho Django) -> chạy bằng máy chủ WSGI đi kèm
# scripts/runtimes/wpp_wsgi.py (chỉ dùng thư viện chuẩn, không cần gunicorn). Nếu có "entry" (vd "app.py") -> chạy thẳng
# file đó (app tự bind PORT qua biến môi trường PORT). Nếu không có gì -> dùng http.server có sẵn của Python để phục vụ
# file tĩnh (không cần code gì thêm). "wsgi" và "entry" loại trừ nhau.
#
# Usage: scripts/runtimes/python.sh <termux_arch: aarch64|arm> <out_dir>
set -euo pipefail
cd "$(dirname "$0")/../.."

TERMUX_ARCH="${1:-aarch64}"
OUT_DIR="${2:-./runtime-out}"
mkdir -p "$OUT_DIR"

source scripts/lib/termux_fetch.sh
source scripts/lib/site_source.sh
source scripts/lib/site_deps.sh
source scripts/lib/reproducible_zip.sh
source scripts/lib/collect_libs.sh
source scripts/lib/generic_runtime.sh

EXTRACT_DIR="$(mktemp -d)"
termux_download_with_deps python "$EXTRACT_DIR"

PY_BIN="$(termux_find_binary "$EXTRACT_DIR" python3)"
[[ -z "$PY_BIN" ]] && PY_BIN="$(termux_find_binary "$EXTRACT_DIR" python)"
if [[ -z "$PY_BIN" ]]; then
  echo "LOI: khong tim thay binary python sau khi tai tu Termux" >&2
  exit 1
fi
cp "$PY_BIN" "$OUT_DIR/libruntimesrv.so"
chmod 755 "$OUT_DIR/libruntimesrv.so"

STAGING="$(mktemp -d)"
fetch_site_source "$STAGING"
install_site_deps python "$STAGING"   # pip install requirements.txt -> .pylibs lac BUILD (HANDOFF.md muc 1ba)

# THU VIEN CHUAN + module mo rong cua Python (HANDOFF.md muc 1bi): truoc day chi copy binary + *.so nen KHONG co "os", "encodings"...
# trong APK - python khong khoi dong duoc. Phai chay TRUOC collect_shared_libs (no go lib-dynload khoi extract de khong copy nhan doi).
PYVER="$(generic_bundle_python_stdlib "$EXTRACT_DIR" "$OUT_DIR" "$STAGING")"
SONAME_MAP="$(mktemp)"
collect_shared_libs "$EXTRACT_DIR" "$OUT_DIR" "$SONAME_MAP"
FRONT="$(generic_front_proxy)"
if [[ "$FRONT" == "true" ]]; then generic_bundle_nginx "$OUT_DIR" "$SONAME_MAP"; fi
# entry / wsgi duoc doc TRUOC khi dong goi www.zip: may chu WSGI di kem phai nam trong goi (HANDOFF.md muc 1bq-C).
ENTRY="$(jq -r '.entry // ""' site.config.json)"
[[ "$ENTRY" == "null" ]] && ENTRY=""
WSGI="$(jq -r '.wsgi // ""' site.config.json)"
[[ "$WSGI" == "null" ]] && WSGI=""
ASGI="$(jq -r '.asgi // ""' site.config.json)"
[[ "$ASGI" == "null" ]] && ASGI=""
N_DECLARED=0
[[ -n "$ENTRY" ]] && N_DECLARED=$((N_DECLARED + 1))
[[ -n "$WSGI" ]] && N_DECLARED=$((N_DECLARED + 1))
[[ -n "$ASGI" ]] && N_DECLARED=$((N_DECLARED + 1))
if [[ "$N_DECLARED" -gt 1 ]]; then
  echo "LOI: site.config.json khai bao nhieu hon mot trong \"entry\", \"wsgi\", \"asgi\" - chi dung mot" >&2
  exit 1
fi
generic_install_supervisor "$STAGING" "$SONAME_MAP" "$FRONT"
if [[ -n "$WSGI" || -n "$ASGI" ]]; then generic_install_wsgi_server "$STAGING"; fi
make_reproducible_zip "$STAGING" "$OUT_DIR/www.zip"  # tai lap duoc (HANDOFF.md muc 1ay)

PORT="$(jq -r '.port // 8080' site.config.json)"

MODE=direct; [[ "$FRONT" == "true" ]] && MODE=proxy
APP_ARGS="$(generic_python_app_args "$MODE" "$ENTRY" "$WSGI" "$ASGI")"

# Co .pylibs (da cai o tren) -> dua vao PYTHONPATH ("${DOCROOT}" duoc RuntimeConfig thay luc chay)
EXTRA_ENV='"PYTHONUNBUFFERED": "1"'
[[ -d "$STAGING/.pylibs" ]] && EXTRA_ENV="$EXTRA_ENV"', "PYTHONPATH": "${DOCROOT}/.pylibs"'

generic_write_runtime_json "$OUT_DIR" "$PORT" libruntimesrv.so "$MODE" libruntimesrv.so "$APP_ARGS" "" "$EXTRA_ENV"

echo "Xong: $OUT_DIR (runtime=python $PYVER, wsgi='${WSGI:-<khong>}', asgi='${ASGI:-<khong>}', entry='${ENTRY:-<mac dinh: http.server tinh>}', che do=$MODE)"
