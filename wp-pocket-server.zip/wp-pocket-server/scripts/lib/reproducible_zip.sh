#!/usr/bin/env bash
# make_reproducible_zip <thu_muc_nguon> <file_zip_dich>
# Tao zip TAI LAP DUOC (cung noi dung -> cung byte) - HANDOFF.md muc 1ay (de xuat DeepSeek muc L5).
# `zip -qr out .` truoc day: (1) thu tu file = thu tu doc thu muc cua he tep (khong xac dinh), (2) moi muc luu
# mtime that cua file (doi moi lan checkout/tai) => www.zip khac nhau giua 2 lan build cung commit, kho so
# sanh/debug. Nay: dat mtime = SOURCE_DATE_EPOCH (mac dinh thoi diem commit, roi hang so), liet ke file THEO
# THU TU CO DINH (LC_ALL=C sort), -X bo thuoc tinh mo rong (uid/gid/mtime phu). Giu nguyen hanh vi cu:
# KHONG dung -y nen van theo symlink (nhu truoc), giu bit thuc thi, giu thu muc rong.
make_reproducible_zip() {
  local src="$1" out="$2" epoch out_abs
  epoch="${SOURCE_DATE_EPOCH:-$(git log -1 --format=%ct 2>/dev/null || true)}"
  [[ "$epoch" =~ ^[0-9]+$ ]] || epoch=1700000000
  out_abs="$(cd "$(dirname "$out")" && pwd)/$(basename "$out")"
  rm -f "$out_abs"
  # -h: khong theo symlink khi dat mtime (khong dung vao file ngoai thu muc nguon)
  find "$src" -exec touch -h -d "@$epoch" {} + 2>/dev/null || true
  (cd "$src" && find . -mindepth 1 | LC_ALL=C sort | zip -qX@ "$out_abs")
}
