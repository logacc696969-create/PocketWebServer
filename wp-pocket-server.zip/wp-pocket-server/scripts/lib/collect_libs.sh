#!/usr/bin/env bash
# Thu vien dung chung, KHONG chay truc tiep - source boi scripts/runtimes/{node,python,static}.sh (HANDOFF.md muc 1bi).
#
# collect_shared_libs <extract_dir> <out_dir> <soname_map_file>
# Gom MOI thu vien .so (ke ca ten co so phien ban/symlink, vd "libz.so.1") tu cac goi Termux da giai nen vao <out_dir> sao cho:
#  - moi file ket thuc dung ".so" (build-apk.yml CHI "cp *.so" vao jniLibs - file "libz.so.1" se bi bo sot, roi luc chay linker bao
#    "library libz.so.1 not found": loi that da gap o vong 1u voi mariadbd);
#  - cac TEN KHAC NHAU cung tro ve 1 file that (chuoi symlink libicudata.so -> .so.75 -> .so.75.1) chi copy MOT LAN (khu trung theo readlink -f,
#    neu khong APK phinh 2-3 lan: 94MB -> 161MB o vong 1v);
#  - ghi <soname_map_file>: moi dong "TEN_SONAME_THAT TEN_DA_DOI" de start-generic.sh tao lai symlink dung ten luc chay (giong COMPAT_DIR cua start-lamp.sh).
# DAY LA BAN SAO CO CHU DICH cua doan "Thu thap toan bo .so phu thuoc" trong scripts/runtimes/php.sh (cung thuat toan, cung ket qua): KHONG
# refactor php.sh de khong co rui ro nao cho duong PHP da chay tren thiet bi that. Neu sua thuat toan, sua CA HAI cho (test: collect-libs-test.sh).
collect_shared_libs() {
  local extract="$1" out="$2" map="$3"
  : > "$map"
  local -A seen=()
  local f bn real target existing
  while IFS= read -r -d '' f; do
    bn="$(basename "$f")"
    real="$(readlink -f "$f" 2>/dev/null || echo "$f")"
    if [[ "$bn" == *.so ]]; then target="$bn"; else target="$(echo "$bn" | tr '.' '_').so"; fi
    if [[ -n "${seen[$real]:-}" ]]; then
      existing="${seen[$real]}"
      [[ "$bn" != "$existing" ]] && echo "$bn $existing" >> "$map"
      continue
    fi
    if [[ -e "$out/$target" ]]; then
      seen[$real]="$target"
      [[ "$bn" != "$target" ]] && echo "$bn $target" >> "$map"
      continue
    fi
    cp "$f" "$out/$target" 2>/dev/null || continue
    seen[$real]="$target"
    [[ "$bn" != "$target" ]] && echo "$bn $target" >> "$map"
  done < <(find "$extract" \( -type f -o -type l \) -name '*.so*' -print0)
  return 0
}
