<?php
/**
 * inject_require.php <file.php>
 *
 * Chen "require __DIR__ . '/auth.php';" vào NGAY VỊ TRÍ HỢP LỆ ĐẦU TIÊN
 * của 1 file PHP - dùng cho _admin/db.php (Adminer) và _admin/files.php
 * (Tiny File Manager), gọi từ scripts/lib/admin_tools.sh::inject_auth_guard().
 *
 * BUG THẬT đã sửa (xem HANDOFF.md, tìm theo "namespace declaration") - bản
 * cũ dùng awk, chỉ chèn ngay sau "<?php" đầu tiên. Việc này ĐÚNG với
 * Adminer 4.x (không dùng namespace) nhưng SAI với Adminer 5.x - Adminer
 * chuyển sang dùng `namespace Adminer;` từ bản 5.0 (xác nhận qua PR cộng
 * đồng "Update to work with Adminer 5.0.5 Namespace Compatibility"). PHP
 * BẮT BUỘC "namespace ...;" phải là statement ĐẦU TIÊN trong file (chỉ cho
 * phép "declare(...)" đứng trước) - chèn "require" trước nó gây:
 *   PHP Fatal error: Namespace declaration statement has to be the very
 *   first statement or after any declare call in the script
 * Vì php.ini.template có display_errors=Off, lỗi Fatal này KHÔNG hiện ra
 * trình duyệt, người dùng chỉ thấy trang trắng lỗi 500 - đúng triệu chứng
 * report thật (xem HANDOFF.md).
 *
 * Đã KIỂM CHỨNG THẬT (không đoán) bằng file adminer-5.4.2.php tải thật từ
 * GitHub release (github.com/vrana/adminer/releases) - file này bị MINIFY
 * NẶNG (nhiều statement chung 1 dòng, "namespace" tách dòng khác thường,
 * ngay sau dấu đóng comment không có khoảng trắng), nên cách cũ (awk theo
 * DÒNG văn bản) không đủ tin cậy để phát hiện đúng ranh giới statement dù
 * đã thử vá thêm nhiều lần (bỏ qua dòng trống, comment nhiều dòng...) - vẫn
 * chèn sai vị trí với chính file thật này. Giải pháp: dùng token_get_all()
 * CHÍNH THỨC của PHP để đọc đúng cấu trúc ngữ pháp, không đoán theo dòng.
 * Đã test qua pipeline nginx+php-fpm+auth.php THẬT với file Adminer 5.4.2
 * thật: HTTP 200, không còn Fatal error trong log.
 *
 * GitHub Actions "ubuntu-latest" (runner build APK) có sẵn PHP theo tài
 * liệu chính thức của GitHub runner-images, nên dùng "php" làm công cụ lúc
 * build là an toàn - không phải dependency mới cần cài thêm (project đã
 * dùng "php -r" làm công cụ dòng lệnh ở nhiều nơi khác, vd start-lamp.sh).
 */

function inject_require(string $file, string $requireLine): void
{
    $src = file_get_contents($file);
    if ($src === false) {
        fwrite(STDERR, "inject_require: khong doc duoc $file\n");
        exit(1);
    }
    $tokens = token_get_all($src);
    $n = count($tokens);

    // Buoc 1: tim vi tri (byte offset trong $src) NGAY SAU token "<?php"
    // dau tien - day la diem chen MAC DINH neu file khong co declare/namespace.
    $i = 0;
    $insertOffset = null;
    while ($i < $n) {
        $tok = $tokens[$i];
        if (is_array($tok) && $tok[0] === T_OPEN_TAG) {
            $insertOffset = strlen($tok[1]); // T_OPEN_TAG luon la token dau file
            $i++;
            break;
        }
        $i++;
    }
    if ($insertOffset === null) {
        fwrite(STDERR, "inject_require: khong tim thay the <?php trong $file\n");
        exit(1);
    }

    // Buoc 2: LAP LAI toi khi token "thuc" (bo qua whitespace/comment) tiep
    // theo KHONG con la T_DECLARE hay T_NAMESPACE nua - moi lan gap 1 trong
    // 2 loai nay, day diem chen ve NGAY SAU dau ";" ket thuc statement do
    // (PHP cho phep "declare(...); namespace X;" ca 2 cung dung dau, phai
    // xu ly duoc CA HAI, khong chi 1).
    $changed = true;
    while ($changed) {
        $changed = false;
        $j = $i;
        while ($j < $n) {
            $tok = $tokens[$j];
            if (is_array($tok) && in_array($tok[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
                $j++;
                continue;
            }
            break;
        }
        if ($j < $n && is_array($tokens[$j]) && in_array($tokens[$j][0], [T_DECLARE, T_NAMESPACE], true)) {
            $k = $j;
            while ($k < $n) {
                $tok = $tokens[$k];
                if (!is_array($tok) && $tok === ';') {
                    break;
                }
                $k++;
            }
            if ($k < $n) {
                // Cong don do dai TAT CA token tu dau file toi het dau ";"
                // nay (k) de ra offset CHINH XAC - khong dung strpos() vi
                // noi dung giong het co the lap lai o nhieu cho khac trong
                // file (vd hang chuc dau ";" khac nhau).
                $offsetAcc = 0;
                for ($m = 0; $m <= $k; $m++) {
                    $t = $tokens[$m];
                    $offsetAcc += is_array($t) ? strlen($t[1]) : strlen($t);
                }
                $insertOffset = $offsetAcc;
                $i = $k + 1;
                $changed = true;
            }
        }
    }

    $newSrc = substr($src, 0, $insertOffset) . $requireLine . substr($src, $insertOffset);
    if (file_put_contents($file, $newSrc) === false) {
        fwrite(STDERR, "inject_require: khong ghi duoc $file\n");
        exit(1);
    }
}

if ($argc < 2) {
    fwrite(STDERR, "Dung: php inject_require.php <file.php>\n");
    exit(1);
}
inject_require($argv[1], "require __DIR__ . '/auth.php';");
