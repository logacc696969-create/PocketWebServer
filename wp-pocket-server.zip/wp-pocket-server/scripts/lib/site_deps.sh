#!/usr/bin/env bash
# Cai DEPENDENCY CUA WEBSITE luc BUILD (tren CI, truoc khi dong goi www.zip) - HANDOFF.md muc 1ba (PDF DeepSeek muc H1/H5).
#
# Truoc day: node.sh chi IN CANH BAO "hay commit node_modules"; python.sh/php.sh khong xu ly requirements.txt/composer.json.
# Nguoi dung phai tu commit ca node_modules/vendor/thu vien Python vao repo - khong thuc te.
#
# Nguyen tac (an toan truoc, tien loi sau):
#   * CHI chay tren may build (CI), KHONG tren dien thoai (khong co npm/pip/composer o do);
#   * KHONG chay script cua goi: npm --ignore-scripts, pip chi nhan WHEEL (--only-binary=:all:, khong setup.py),
#     composer --no-scripts --no-plugins. Goi can build native thi khong cai duoc -> bao loi ro rang thay vi am tham chay ma la;
#   * Ma NATIVE (addon .node, .so cua Python) duoc build cho may CI (x86_64/glibc) nen KHONG nap duoc tren Android:
#     Node -> CANH BAO ten goi; Python -> XOA cac tep .so (goi co duong lui Python thuan nhu MarkupSafe van chay) + canh bao;
#     PHP -> liet ke ext-* can co o PHP cua Termux;
#   * Da co san thu muc (node_modules / .pylibs / vendor) -> coi la nguoi dung tu cai, bo qua;
#   * Cai LOI -> build THAT BAI (ro rang ngay) thay vi ra APK chay hong. Tat bang site.config.json: "install_deps": false.
#
# Dung: source scripts/lib/site_deps.sh; install_site_deps <node|python|php> <thu_muc_nguon>
# Test: scripts/tests/site-deps-test.py

_deps_warn() { echo "CANH BAO: $*" >&2; }

site_deps_enabled() {
  local cfg="${SITE_CONFIG:-site.config.json}"
  [[ -f "$cfg" ]] || return 0
  # CHU Y: KHONG dung '.install_deps // true' - toan tu // cua jq coi false la "khong co gia tri" nen false // true = true
  # (tat se khong bao gio co tac dung; test site-deps-test.py bat duoc).
  if [[ "$(jq -r 'if .install_deps == false then "false" else "true" end' "$cfg" 2>/dev/null)" == "false" ]]; then
    echo "== install_deps=false trong site.config.json - bo qua cai dependency =="
    return 1
  fi
  return 0
}

site_deps_node() {
  local dir="$1"
  [[ -f "$dir/package.json" ]] || return 0
  if [[ -d "$dir/node_modules" ]]; then
    echo "== (goi y) da co san node_modules trong nguon - bo qua npm =="
    return 0
  fi
  command -v npm >/dev/null 2>&1 || { echo "LOI: co package.json nhung may build khong co npm (hoac dat install_deps=false)" >&2; return 1; }
  local cmd=(npm install)
  [[ -f "$dir/package-lock.json" || -f "$dir/npm-shrinkwrap.json" ]] && cmd=(npm ci)
  echo "== npm: ${cmd[1]} luc BUILD (--omit=dev --ignore-scripts) =="
  if ! (cd "$dir" && "${cmd[@]}" --omit=dev --ignore-scripts --no-audit --no-fund --no-progress); then
    echo "LOI: npm that bai. Sua package.json/lock, hoac dat \"install_deps\": false va tu commit node_modules." >&2
    return 1
  fi
  # Addon native: --ignore-scripts khong sinh .node, nhung binding.gyp (hoac .node co san) cho biet goi can ma native.
  local native
  native="$(cd "$dir" && find -L node_modules \( -name '*.node' -o -name 'binding.gyp' \) -print 2>/dev/null \
            | sed -E 's#^node_modules/((@[^/]+/)?[^/]+)/.*#\1#' | sort -u | tr '\n' ' ')"
  if [[ -n "$native" ]]; then
    _deps_warn "co goi can MA NATIVE (se KHONG chay tren Android, ma build cho may CI): ${native}- chi dung goi JS thuan, hoac thay bang ban thuan JS."
  fi
  return 0
}

site_deps_python() {
  local dir="$1" req="$1/requirements.txt"
  [[ -f "$req" ]] || return 0
  if [[ -d "$dir/.pylibs" ]]; then
    echo "== (goi y) da co san .pylibs trong nguon - bo qua pip =="
    return 0
  fi
  command -v python3 >/dev/null 2>&1 || { echo "LOI: co requirements.txt nhung may build khong co python3 (hoac dat install_deps=false)" >&2; return 1; }
  echo "== pip: cai requirements.txt luc BUILD vao .pylibs (chi wheel, khong chay setup.py) =="
  if ! python3 -m pip install --no-input --disable-pip-version-check --no-compile --only-binary=:all: \
        --target "$dir/.pylibs" -r "$req"; then
    echo "LOI: pip that bai (goi chi co ma nguon sdist, hoac khong ton tai?). Sua requirements.txt, hoac dat \"install_deps\": false." >&2
    return 1
  fi
  # Module bien dich cho may CI khong nap duoc tren Android (khac kien truc/libc/phien ban Python) -> xoa, de goi tu lui
  # ve ban Python thuan neu co (vd MarkupSafe); goi BAT BUOC co ma bien dich se bao ImportError ro rang khi chay.
  local so pk
  so="$(cd "$dir/.pylibs" && find . \( -name '*.so' -o -name '*.so.*' -o -name '*.pyd' \) -print 2>/dev/null)"
  if [[ -n "$so" ]]; then
    pk="$(echo "$so" | sed -E 's#^\./([^/]+)/.*#\1#; s#^\./([^/]+)$#\1#' | sort -u | tr '\n' ' ')"
    (cd "$dir/.pylibs" && find . \( -name '*.so' -o -name '*.so.*' -o -name '*.pyd' \) -delete 2>/dev/null)
    _deps_warn "da XOA module bien dich (khong nap duoc tren Android) trong: ${pk}- goi co ban Python thuan se tu dung; goi bat buoc co ma bien dich se loi ImportError luc chay."
  fi
  find "$dir/.pylibs" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
  return 0
}

site_deps_php() {
  local dir="$1"
  [[ -f "$dir/composer.json" ]] || return 0
  if [[ -f "$dir/wp-includes/version.php" ]]; then
    echo "== (goi y) day la WordPress - bo qua composer (WordPress khong dung composer o thu muc goc) =="
    return 0
  fi
  if [[ -d "$dir/vendor" ]]; then
    echo "== (goi y) da co san vendor/ trong nguon - bo qua composer =="
    return 0
  fi
  local composer_bin="${COMPOSER_BIN:-composer}"
  command -v "$composer_bin" >/dev/null 2>&1 || { echo "LOI: co composer.json nhung may build khong co composer (hoac dat install_deps=false)" >&2; return 1; }
  echo "== composer: install luc BUILD (--no-dev --no-scripts --no-plugins) =="
  # --ignore-platform-reqs: PHP/extension cua may CI khac Termux; ext-* can co duoc liet ke ben duoi de nguoi dung tu doi chieu.
  if ! (cd "$dir" && "$composer_bin" install --no-dev --no-interaction --no-scripts --no-plugins --prefer-dist \
          --optimize-autoloader --ignore-platform-reqs --no-progress); then
    echo "LOI: composer that bai. Sua composer.json/lock, hoac dat \"install_deps\": false va tu commit vendor/." >&2
    return 1
  fi
  local exts
  exts="$( (cd "$dir" && jq -r '[.require // {} | keys[] | select(startswith("ext-"))] | join(" ")' composer.json 2>/dev/null) || true)"
  [[ -n "$exts" ]] && _deps_warn "ung dung yeu cau extension PHP: ${exts}- build KHONG kiem tra duoc; hay doi chieu voi PHP cua Termux (php -m)."
  return 0
}

install_site_deps() {
  local runtime="$1" dir="$2"
  site_deps_enabled || return 0
  case "$runtime" in
    node)   site_deps_node "$dir" ;;
    python) site_deps_python "$dir" ;;
    php)    site_deps_php "$dir" ;;
    *)      return 0 ;;
  esac
}
