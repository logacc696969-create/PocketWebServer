#!/usr/bin/env bash
# HO SO SITE (site profile) cho runtime PHP - HANDOFF.md muc 1bb: bien du an tu "WordPress-first" thanh server DA DUNG.
#
# Truoc day: docroot luon la goc cua www/ (Laravel/Symfony/Slim can public/ khong chay duoc nguyen trang), menu _admin/ luon hien
# WP-CLI/Staging/Rollback va - khi khong co wp-config.php - nut "Cai WordPress moi" ngay ca voi app khong phai WordPress, ten CSDL
# co dinh "wordpress".
#
# Cau hinh (site.config.json, deu TUY CHON, mac dinh giu nguyen hanh vi cu):
#   "docroot": ""            thu muc con duoc phuc vu lam web root (vd "public", "web", "dist"); "" = goc
#   "profile": "auto"        auto | wordpress | generic
#                            auto = wordpress neu type=wordpress, hoac nguon co dau hieu WordPress, hoac nguon TRONG (giu 1-click cai WP);
#                            nguoc lai generic
#   "db_name": ""            ten database tao san; "" = "wordpress" (profile wordpress) hoac "app" (generic)
#
# Dung: source scripts/lib/site_profile.sh
#   site_docroot_subdir            -> in thu muc con da chuan hoa (hoac rong); loi -> return 1
#   site_resolve_profile <dir>     -> in wordpress|generic
#   site_resolve_db_name <profile> -> in ten DB hop le
#   site_write_profile_env <staging> <profile> <subdir> <dbname>
# Test: scripts/tests/site-profile-test.py

_sp_cfg() { # _sp_cfg <jq-filter> -> gia tri chuoi hoac rong
  local cfg="${SITE_CONFIG:-site.config.json}"
  [[ -f "$cfg" ]] || return 0
  jq -r "$1 // empty" "$cfg" 2>/dev/null || true
}

site_docroot_subdir() {
  local raw sub
  raw="$(_sp_cfg '.docroot')"
  sub="${raw#./}"
  while [[ "$sub" == /* ]]; do sub="${sub#/}"; done
  while [[ "$sub" == */ ]]; do sub="${sub%/}"; done
  [[ -z "$sub" || "$sub" == "." ]] && return 0
  # Chi cho phep [A-Za-z0-9._-] va dau '/', moi thanh phan khong rong, khong bat dau bang '-' (khong giong tuy chon dong lenh) va khong phai '..' - gia tri nay duoc chen vao duong dan
  # nginx/shell/JSON nen khong cho khoang trang, dau nhay, '$', '..'.
  if [[ ! "$sub" =~ ^[A-Za-z0-9._][A-Za-z0-9._-]*(/[A-Za-z0-9._][A-Za-z0-9._-]*)*$ ]] || [[ "/$sub/" == *"/../"* ]] || [[ "/$sub/" == *"/./"* ]]; then
    echo "LOI: site.config.json docroot=\"$raw\" khong hop le (chi [A-Za-z0-9._-] va '/', khong '..', khong rong giua hai '/')" >&2
    return 1
  fi
  echo "$sub"
}

site_resolve_profile() {
  local dir="$1" want type
  want="$(_sp_cfg '.profile')"; want="${want:-auto}"
  case "$want" in
    wordpress|generic) echo "$want"; return 0 ;;
    auto) ;;
    *) echo "LOI: site.config.json profile=\"$want\" khong hop le (auto | wordpress | generic)" >&2; return 1 ;;
  esac
  type="$(_sp_cfg '.site_source.type')"
  if [[ "$type" == "wordpress" ]] \
     || [[ -f "$dir/wp-includes/version.php" || -f "$dir/wp-load.php" || -f "$dir/wp-config.php" || -f "$dir/wp-config.php.template" || -d "$dir/wp-content" ]]; then
    echo wordpress; return 0
  fi
  # Nguon TRONG (chi co dotfile nhu .gitkeep): giu hanh vi cu - _admin/ cho cai WordPress 1-click
  if [[ -z "$(find "$dir" -mindepth 1 -maxdepth 1 -not -name '.*' -print -quit 2>/dev/null)" ]]; then
    echo wordpress; return 0
  fi
  echo generic
}

site_resolve_db_name() {
  local profile="$1" name
  name="$(_sp_cfg '.db_name')"
  if [[ -z "$name" ]]; then
    [[ "$profile" == "wordpress" ]] && name=wordpress || name=app
  fi
  if [[ ! "$name" =~ ^[A-Za-z][A-Za-z0-9_]{0,31}$ ]]; then
    echo "LOI: site.config.json db_name=\"$name\" khong hop le (chu cai dau, chi [A-Za-z0-9_], toi da 32 ky tu)" >&2
    return 1
  fi
  case "${name,,}" in
    mysql|information_schema|performance_schema|sys|test)
      echo "LOI: db_name=\"$name\" trung ten database he thong cua MariaDB" >&2; return 1 ;;
  esac
  # Profile wordpress: ten DB PHAI la "wordpress" - staging/backup/WP-CLI cua cac trang _admin dua vao ten nay
  if [[ "$profile" == "wordpress" && "$name" != "wordpress" ]]; then
    echo "LOI: profile wordpress yeu cau db_name=\"wordpress\" (hoac de trong); dang la \"$name\". Dung profile generic cho ung dung khac." >&2
    return 1
  fi
  echo "$name"
}

site_write_profile_env() {
  local staging="$1" profile="$2" sub="$3" dbname="$4"
  mkdir -p "$staging/_supervisor"
  {
    echo "# Sinh luc BUILD boi scripts/lib/site_profile.sh - start-lamp.sh doc bang '.' (gia tri da kiem tra an toan)"
    echo "SITE_PROFILE='$profile'"
    echo "WEB_SUBDIR='$sub'"
    echo "DB_NAME='$dbname'"
  } > "$staging/_supervisor/site-profile.env"
}
