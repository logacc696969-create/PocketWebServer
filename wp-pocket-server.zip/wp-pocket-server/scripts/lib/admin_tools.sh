#!/usr/bin/env bash
# Thư viện dùng chung, KHÔNG chạy trực tiếp - được source bởi scripts/runtimes/php.sh
#
# prepare_admin_tools <staging_dir> [thu_muc_con_web_root] [profile]
#   thu_muc_con_web_root: docroot cua site.config.json (vd "public"); _admin/ duoc dat BEN TRONG web root do. Mac dinh rong = goc.
#   profile: wordpress (mac dinh, giu hanh vi cu) | generic - generic KHONG trien khai/hien cac trang chi co nghia voi WordPress
#   (install-wp, wpcli, staging, core-rollback, safe-mode); HANDOFF.md muc 1bb.
# Tải Adminer (quản lý database, 1 file PHP chính thức từ adminer.org) và
# Tiny File Manager (mã nguồn mở, 1 file PHP - https://github.com/prasathmani/tinyfilemanager)
# vào <staging_dir>/_admin/, gắn cổng xác thực (admin-auth.php) vào đầu mỗi
# file bằng cách chèn dòng `require` ngay sau thẻ "<?php" đầu tiên.
#
# BẢO MẬT: 2 file này CHỈ vào được qua mạng LAN (chặn ở nginx.conf, xem
# location /_admin/) + cần mật khẩu riêng sinh ngẫu nhiên mỗi máy (xem
# admin-auth.php). Không expose ra Cloudflare Tunnel public.
set -euo pipefail

# Xac minh toan ven + phien ban GHIM (HANDOFF.md muc 1bc, de xuat Z2): xem scripts/lib/pins.env va verify_download.sh.
_ADMIN_TOOLS_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=verify_download.sh
source "$_ADMIN_TOOLS_LIB_DIR/verify_download.sh"
# shellcheck source=pins.env
source "${PINS_FILE:-$_ADMIN_TOOLS_LIB_DIR/pins.env}"

prepare_admin_tools() {
  local staging="$1" sub="${2:-}" profile="${3:-wordpress}"
  local webroot="$staging${sub:+/$sub}"
  local admin_dir="$webroot/_admin"
  mkdir -p "$admin_dir"

  cp scripts/runtimes/templates/admin-auth.php "$admin_dir/auth.php"
  cp scripts/runtimes/templates/admin-totp-lib.php "$admin_dir/totp-lib.php"
  cp scripts/runtimes/templates/admin-2fa.php "$admin_dir/2fa.php"
  cp scripts/runtimes/templates/admin-logs.php "$admin_dir/logs.php"
  cp scripts/runtimes/templates/admin-info.php "$admin_dir/info.php"
  # De xuat DeepSeek muc A8/A4/A5 (xem HANDOFF.md muc 10) - da tao/test that
  # o vong nay, xem chu thich chi tiet trong chinh 2 file duoi day.
  cp scripts/runtimes/templates/admin-maintenance.php "$admin_dir/maintenance.php"
  cp scripts/runtimes/templates/admin-metrics.php "$admin_dir/metrics.php"
  # HANDOFF.md muc 1bk (PDF 2 C9/I8): suc khoe site + trang thai WP-Cron/bai hen gio (chi doc; moi profile deu dung duoc, muc WordPress tu bo qua neu khong co WP).
  cp scripts/runtimes/templates/admin-health.php "$admin_dir/health.php"
  # HANDOFF.md muc 1bl (PDF 2 G7/C10/R19/R20): luat IP cho _admin + gioi han toc do + chan bot (bat/tat bang file co; mac dinh TAT).
  cp scripts/runtimes/templates/admin-protect.php "$admin_dir/protect.php"
  # HANDOFF.md muc 1br: Trung tam bao mat (IP bi tu dong chan, ket qua quet ma doc + cach ly, phong thu dang nhap, cong tat). 2 thu vien = ban sao
  # CUNG file voi supervisor (security-guard.php / security-scan.php): trang va supervisor dung chung logic, khong lech nhau.
  cp scripts/runtimes/templates/admin-security.php "$admin_dir/security.php"
  cp scripts/runtimes/templates/security-guard.php "$admin_dir/security-lib.php"
  cp scripts/runtimes/templates/security-scan.php "$admin_dir/security-scan-lib.php"
  cp scripts/runtimes/templates/security-vuln.php "$admin_dir/security-vuln-lib.php"      # 1br-H: kiem lo hong da biet (tuy chon); trang van chay neu thieu file nay
  # HANDOFF.md muc 1bc (PDF "chat luong tinh phi" G2): xem/thu hoi phien dang nhap + dang xuat (co che nam trong auth.php).
  cp scripts/runtimes/templates/admin-sessions.php "$admin_dir/sessions.php"
  # De xuat DeepSeek muc A5 (xem HANDOFF.md muc 10) - da tao/test that o
  # vong nay, xem chu thich chi tiet trong chinh file duoi day.
  cp scripts/runtimes/templates/admin-analytics.php "$admin_dir/analytics.php"
  # De xuat DeepSeek muc A9 - da tao/test that o vong nay (xem HANDOFF.md
  # muc 1ap va chu thich bao mat ngay trong file nguon duoi day).
  # De xuat DeepSeek muc A10 - da tao/test that o vong nay (xem HANDOFF.md
  # muc 1ar va chu thich day du trong chinh file nguon).
  # De xuat DeepSeek muc P3 - da tao/test that o vong nay (xem HANDOFF.md
  # muc 1at). Snapshot duoc mu-plugin (site_source.sh) tu tao, trang nay
  # chi doc/khoi phuc.
  # De xuat DeepSeek muc P2 (xem HANDOFF.md muc 10) - da tao/test that o
  # vong nay, xem chu thich chi tiet trong chinh file duoi day.

  # Cac trang CHI CO NGHIA voi WordPress (WP-CLI, staging, rollback core, che do an toan plugin, cai WP 1-click): chi trien khai khi
  # profile=wordpress. Chu thich lich su cua tung trang xem trong chinh file nguon (A9 muc 1ap, A10 muc 1ar, P3 muc 1at, P2).
  if [[ "$profile" == "wordpress" ]]; then
    cp scripts/runtimes/templates/admin-install-wp.php "$admin_dir/install-wp.php"
    cp scripts/runtimes/templates/admin-wpcli.php "$admin_dir/wpcli.php"
    cp scripts/runtimes/templates/admin-staging.php "$admin_dir/staging.php"
    cp scripts/runtimes/templates/admin-core-rollback.php "$admin_dir/core-rollback.php"
    cp scripts/runtimes/templates/admin-safe-mode.php "$admin_dir/safe-mode.php"
  else
    echo "== profile=$profile: bo qua 5 trang chi danh cho WordPress =="
  fi

  echo "== Tai Adminer ${ADMINER_VERSION:-?} (quan ly database) - phien ban + SHA256 GHIM SAN (scripts/lib/pins.env) =="
  # SUA 1bc: truoc day tai "https://www.adminer.org/latest.php" - ma doi ma khong ai duyet, khong kiem toan ven.
  # (Lich su: URL GitHub releases cu "adminer.php" tung tra 404 vi asset doi ten kem so phien ban - HANDOFF.md muc 2a;
  # nay dung dung ten co phien ban "adminer-X.Y.Z.php" nen khong con rui ro do.)
  # Tra 3 = khong tai duoc (bo qua cong cu, nhu truoc). Hash SAI => verify_file DUNG build.
  local rc=0
  download_pinned "adminer-${ADMINER_VERSION:-?}" "${ADMINER_URL:-https://www.adminer.org/latest.php}" "${ADMINER_SHA256:-}" "$admin_dir/db.php" || rc=$?
  if [[ $rc -eq 0 ]]; then
    inject_auth_guard "$admin_dir/db.php"
    echo "  -> OK: _admin/db.php"
  else
    echo "  CANH BAO: khong tai duoc Adminer, bo qua (khong chan build chinh)" >&2
    rm -f "$admin_dir/db.php"
  fi

  echo "== Tai Tiny File Manager ${TFM_VERSION:-?} (quan ly file) - GHIM SAN =="
  # SUA 1bc: truoc day tai nhanh "master" (code CHUA phat hanh, doi lien tuc; da do: master != tag 2.6). Nay ghim tag + SHA256.
  rc=0
  download_pinned "tinyfilemanager-${TFM_VERSION:-?}" "${TFM_URL:-https://raw.githubusercontent.com/prasathmani/tinyfilemanager/master/tinyfilemanager.php}" "${TFM_SHA256:-}" "$admin_dir/files.php" || rc=$?
  if [[ $rc -eq 0 ]]; then
    inject_auth_guard "$admin_dir/files.php"
    # Tat man hinh dang nhap RIENG cua Tiny File Manager (bien $use_auth) -
    # da co admin-auth.php gac cong truoc roi, khong can dang nhap 2 lan.
    # Da tra cuu xac nhan ten bien dung la $use_auth (khong phai hang so).
    sed -i 's/use_auth = true;/use_auth = false;/' "$admin_dir/files.php" || true
    # Web root la thu muc con (vd public/) -> File Manager phai thay CA DU AN (composer.json, .env, vendor/...), khong chi public/.
    # Bien goc cua TFM la $root_path = $_SERVER['DOCUMENT_ROOT']; (da kiem tra tren ban that).
    if [[ -n "$sub" ]]; then
      local ups; ups="$(echo "$sub" | awk -F/ '{s=""; for(i=1;i<=NF;i++) s=s "/.."; print substr(s,2)}')"
      sed -i "s#^\$root_path = \$_SERVER\['DOCUMENT_ROOT'\];#\$root_path = realpath(\$_SERVER['DOCUMENT_ROOT'] . '/$ups');#" "$admin_dir/files.php" || true
    fi
    echo "  -> OK: _admin/files.php"
  else
    echo "  CANH BAO: khong tai duoc Tiny File Manager, bo qua" >&2
    rm -f "$admin_dir/files.php"
  fi

  cat > "$admin_dir/index.php" <<'PHP'
<?php
require __DIR__ . '/auth.php';

function format_bytes($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) { $bytes /= 1024; $i++; }
    return round($bytes, 1) . ' ' . $units[$i];
}

// RAM cua CA THIET BI (khong phai rieng tien trinh PHP) - doc /proc/meminfo,
// file the-gioi-doc-duoc tren Android (khong can quyen root), dung cach cac
// app "system monitor" van doc duoc ma khong can quyen dac biet. De xuat tu
// PDF "Thanh trang thai he thong gon nhe" (xem HANDOFF.md muc 1e). CHUA
// verify /proc/meminfo co doc duoc tren MOI ban Android/kernel hay khong -
// neu khong, ham nay tra ve null va phan RAM don gian bi an di, khong lam
// loi trang.
function read_meminfo() {
    $path = '/proc/meminfo';
    if (!is_readable($path)) return null;
    $lines = @file($path);
    if (!$lines) return null;
    $out = [];
    foreach ($lines as $line) {
        if (preg_match('/^(MemTotal|MemAvailable|MemFree):\s*(\d+)\s*kB/', $line, $m)) {
            $out[$m[1]] = (int) $m[2] * 1024;
        }
    }
    return $out;
}

$path = __DIR__;
$free = @disk_free_space($path);
$total = @disk_total_space($path);
$mem = read_meminfo();

$appHome = rtrim(getenv('APP_HOME') ?: '', '/');
$mariadbUp = $appHome !== '' && file_exists($appHome . '/lamp-run/mysql.sock');
$mariadbSleeping = $appHome !== '' && file_exists($appHome . '/lamp-run/mariadb-asleep');
$liteMode = $appHome !== '' && file_exists($appHome . '/lamp-run/lite-mode');
$maintenanceOn = $appHome !== '' && file_exists($appHome . '/lamp-run/maintenance-mode');

// docroot la thu muc cha cua _admin/ (xem nginx.conf.template: root __DOCROOT__)
$docroot = dirname(__DIR__);
$wpInstalled = file_exists($docroot . '/wp-config.php') || file_exists($docroot . '/wp-load.php');
// Ho so site NUONG luc build (scripts/lib/site_profile.sh): wordpress | generic. Chi site WordPress moi thay cac the WP.
$isWp = ('__SITE_PROFILE__' === 'wordpress');
$safeModeOn = $wpInstalled && count(glob($docroot . '/wp-content/plugins.disabled-*', GLOB_ONLYDIR) ?: []) > 0;
?>
<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quan tri</title>
<style>
body{font-family:system-ui,sans-serif;max-width:420px;margin:60px auto;padding:0 20px}
a.card{display:block;padding:16px;margin-bottom:12px;border:1px solid #ddd;border-radius:8px;
text-decoration:none;color:#222}
a.card:hover{background:#f7f7f7}
a.card b{display:block;font-size:16px}
a.card span{font-size:13px;color:#666}
a.card.highlight{border-color:#21759B;background:#f3f9fc}
.stats{font-size:13px;color:#666;margin-top:24px;padding-top:16px;border-top:1px solid #eee;line-height:1.8}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:4px}
.dot.up{background:#2ecc71}
.dot.down{background:#e74c3c}
.dot.sleep{background:#f39c12}
.badge{display:inline-block;font-size:11px;background:#fff3cd;color:#856404;padding:2px 8px;border-radius:10px;margin-left:6px}
/* Dark mode (HANDOFF.md muc 1bg): theo cai dat sang/toi cua may. Dao mau toan trang + xoay sac do de mau trang thai (do/xanh) van dung nghia; cung 1 dong cho moi trang _admin. */
@media (prefers-color-scheme:dark){html{background:#fff;filter:invert(1) hue-rotate(180deg)}}
</style></head><body>
<h2>Cong cu quan tri<?php if ($liteMode): ?><span class="badge">Che do PHP-Lite</span><?php endif; ?></h2>
<a class="card" href="db.php"><b>Database (Adminer)</b><span><?= $liteMode ? 'SQLite (khong dung MariaDB o che do Lite)' : 'Xem/sua bang MySQL truc tiep' ?></span></a>
<a class="card" href="files.php"><b>File Manager</b><span>Duyet/sua file website</span></a>
<a class="card" href="logs.php"><b>Log</b><span>Xem log nginx/php-fpm/mariadb</span></a>
<a class="card" href="info.php"><b>PHP Info</b><span>Xem cau hinh/extension PHP dang chay</span></a>
<a class="card" href="2fa.php"><b>Xac thuc 2 buoc (2FA)</b><span>Them 1 lop bao ve ngoai mat khau</span></a>
<a class="card" href="sessions.php"><b>Phien dang nhap</b><span>Xem thiet bi dang dang nhap, thu hoi, dang xuat</span></a>
<a class="card<?= $maintenanceOn ? ' highlight' : '' ?>" href="maintenance.php"><b>Che do bao tri<?= $maintenanceOn ? ' (DANG BAT)' : '' ?></b><span>An website voi khach, chi minh ban vao duoc qua day</span></a>
<a class="card" href="health.php"><b>Suc khoe site</b><span>Kiem tra cau hinh, dung luong, WP-Cron va bai hen gio</span></a>
<a class="card" href="protect.php"><b>Bao ve site</b><span>Gioi han toc do, chan bot, luat IP cho trang quan tri</span></a>
<a class="card" href="security.php"><b>Trung tam bao mat</b><span>IP bi tu dong chan, quet ma doc/file la, phong thu dang nhap, khoa khan cap</span></a>
<a class="card" href="metrics.php"><b>Thong ke theo thoi gian</b><span>Uptime 24h/7d/30d + bieu do RAM/dia/load ~7 ngay gan nhat</span></a>
<a class="card" href="analytics.php"><b>Thong ke truy cap</b><span>Top trang/IP/404, bang thong theo ngay</span></a>
<?php if ($isWp): ?>
<a class="card" href="wpcli.php"><b>WP-CLI console</b><span>Chay lenh WP-CLI (plugin, theme, user...)</span></a>
<a class="card" href="staging.php"><b>Staging / Clone site</b><span>Tao ban sao de test plugin/theme an toan</span></a>
<a class="card" href="core-rollback.php"><b>Rollback WordPress core</b><span>Khoi phuc ve ban truoc lan tu cap nhat gan nhat</span></a>
<?php endif; ?>
<?php if ($isWp && $wpInstalled): ?>
<a class="card<?= $safeModeOn ? ' highlight' : '' ?>" href="safe-mode.php"><b>Che do an toan<?= $safeModeOn ? ' (DANG BAT)' : '' ?></b><span>Tat het plugin khi 1 cai nao do lam site/wp-admin trang trang</span></a>
<?php endif; ?>
<?php if ($isWp && !$wpInstalled): ?>
<a class="card highlight" href="install-wp.php"><b>Cai WordPress moi (1-Click)</b><span>Docroot dang trong - tai + ket noi database co san, khong can build lai APK</span></a>
<?php endif; ?>
<div class="stats">
<?php if ($free !== false && $total !== false && $total > 0):
    $usedPct = round((1 - $free / $total) * 100, 1); ?>
  Dung luong: con trong <?= format_bytes($free) ?> / tong <?= format_bytes($total) ?> (da dung <?= $usedPct ?>%)<br>
<?php endif; ?>
<?php if ($mem && isset($mem['MemAvailable'], $mem['MemTotal'])): ?>
  RAM may: con trong <?= format_bytes($mem['MemAvailable']) ?> / tong <?= format_bytes($mem['MemTotal']) ?><br>
<?php endif; ?>
<?php if ($liteMode): ?>
  Dich vu: <span class="dot up"></span>php -S don le (che do Lite - da tat MariaDB/nginx/php-fpm de tiet kiem RAM)
<?php else: ?>
  Dich vu: <span class="dot up"></span>Nginx + PHP-FPM (dang phuc vu trang nay)
  &middot; <span class="dot <?= $mariadbUp ? 'up' : ($mariadbSleeping ? 'sleep' : 'down') ?>"></span>MariaDB <?= $mariadbUp ? 'dang chay' : ($mariadbSleeping ? 'dang ngu (Auto-Sleep - se tu thuc khi co truy cap)' : 'khong thay socket') ?>
<?php endif; ?>
</div>
</body></html>
PHP

  # Nuong ho so site vao menu (heredoc o tren la 'PHP' co dau nhay nen khong noi suy bien shell)
  sed -i "s/__SITE_PROFILE__/$profile/" "$admin_dir/index.php"

  echo "== Xong: cong cu quan tri o _admin/ (chi truy cap duoc qua LAN, xem nginx.conf) =="
}

# inject_auth_guard <file_php>
# Chèn "require __DIR__.'/auth.php';" vào vị trí hợp lệ đầu tiên của file.
#
# BUG THẬT đã sửa (xem HANDOFF.md, mục "namespace declaration" - report
# thật từ người dùng: bấm vào "Database" trong app báo lỗi 500): bản CŨ
# dùng awk chèn ngay sau "<?php" đầu tiên - ĐÚNG với Adminer 4.x nhưng SAI
# với Adminer 5.x (dùng `namespace Adminer;`, PHP bắt buộc namespace phải
# là statement đầu tiên - chèn require trước nó gây Fatal error thật,
# php.ini có display_errors=Off nên chỉ hiện trang trắng 500, không rõ lý
# do). adminer.org/latest.php LUÔN trả bản MỚI NHẤT nên build nào cũng có
# thể dính, không phải lỗi ngẫu nhiên. Sửa bằng script PHP dùng
# token_get_all() thật (scripts/lib/inject_require.php) thay vì đoán theo
# dòng văn bản - đã KIỂM CHỨNG với file adminer-5.4.2.php tải thật từ GitHub
# release, xem chi tiết trong chính file đó.
inject_auth_guard() {
  local file="$1"
  php scripts/lib/inject_require.php "$file"
}
