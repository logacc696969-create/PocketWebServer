#!/usr/bin/env bash
# Thư viện dùng chung, KHÔNG chạy trực tiếp - được source bởi scripts/runtimes/php.sh
#
# prepare_admin_tools <staging_dir>
# Tải Adminer (quản lý database, 1 file PHP chính thức từ adminer.org) và
# Tiny File Manager (mã nguồn mở, 1 file PHP - https://github.com/prasathmani/tinyfilemanager)
# vào <staging_dir>/_admin/, gắn cổng xác thực (admin-auth.php) vào đầu mỗi
# file bằng cách chèn dòng `require` ngay sau thẻ "<?php" đầu tiên.
#
# BẢO MẬT: 2 file này CHỈ vào được qua mạng LAN (chặn ở nginx.conf, xem
# location /_admin/) + cần mật khẩu riêng sinh ngẫu nhiên mỗi máy (xem
# admin-auth.php). Không expose ra Cloudflare Tunnel public.
set -euo pipefail

prepare_admin_tools() {
  local staging="$1"
  local admin_dir="$staging/_admin"
  mkdir -p "$admin_dir"

  cp scripts/runtimes/templates/admin-auth.php "$admin_dir/auth.php"
  cp scripts/runtimes/templates/admin-logs.php "$admin_dir/logs.php"
  cp scripts/runtimes/templates/admin-info.php "$admin_dir/info.php"
  cp scripts/runtimes/templates/admin-install-wp.php "$admin_dir/install-wp.php"

  echo "== Tai Adminer (quan ly database) =="
  # SUA (xem HANDOFF.md muc 2a): URL GitHub releases cu (adminer.php dinh
  # kem release) dang tra ve 404 that trong log build (asset co the da doi
  # ten kem so phien ban thay vi ten co dinh "adminer.php"). Doi sang URL
  # chinh thuc adminer.org danh RIENG cho muc dich script tu dong hoa (luon
  # tro toi ban .php don file moi nhat, khong doi ten theo phien ban) - xem
  # vd https://github.com/geerlingguy/ansible-role-adminer dung cung URL nay
  # lam mac dinh.
  if curl -fsSL -o "$admin_dir/db.php" "https://www.adminer.org/latest.php"; then
    inject_auth_guard "$admin_dir/db.php"
    echo "  -> OK: _admin/db.php"
  else
    echo "  CANH BAO: khong tai duoc Adminer, bo qua (khong chan build chinh)" >&2
    rm -f "$admin_dir/db.php"
  fi

  echo "== Tai Tiny File Manager (quan ly file) =="
  if curl -fsSL -o "$admin_dir/files.php" "https://raw.githubusercontent.com/prasathmani/tinyfilemanager/master/tinyfilemanager.php"; then
    inject_auth_guard "$admin_dir/files.php"
    # Tat man hinh dang nhap RIENG cua Tiny File Manager (bien $use_auth) -
    # da co admin-auth.php gac cong truoc roi, khong can dang nhap 2 lan.
    # Da tra cuu xac nhan ten bien dung la $use_auth (khong phai hang so).
    sed -i 's/use_auth = true;/use_auth = false;/' "$admin_dir/files.php" || true
    echo "  -> OK: _admin/files.php"
  else
    echo "  CANH BAO: khong tai duoc Tiny File Manager, bo qua" >&2
    rm -f "$admin_dir/files.php"
  fi

  cat > "$admin_dir/index.php" <<'PHP'
<?php
require __DIR__ . '/auth.php';

function format_bytes($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) { $bytes /= 1024; $i++; }
    return round($bytes, 1) . ' ' . $units[$i];
}

// RAM cua CA THIET BI (khong phai rieng tien trinh PHP) - doc /proc/meminfo,
// file the-gioi-doc-duoc tren Android (khong can quyen root), dung cach cac
// app "system monitor" van doc duoc ma khong can quyen dac biet. De xuat tu
// PDF "Thanh trang thai he thong gon nhe" (xem HANDOFF.md muc 1e). CHUA
// verify /proc/meminfo co doc duoc tren MOI ban Android/kernel hay khong -
// neu khong, ham nay tra ve null va phan RAM don gian bi an di, khong lam
// loi trang.
function read_meminfo() {
    $path = '/proc/meminfo';
    if (!is_readable($path)) return null;
    $lines = @file($path);
    if (!$lines) return null;
    $out = [];
    foreach ($lines as $line) {
        if (preg_match('/^(MemTotal|MemAvailable|MemFree):\s*(\d+)\s*kB/', $line, $m)) {
            $out[$m[1]] = (int) $m[2] * 1024;
        }
    }
    return $out;
}

$path = __DIR__;
$free = @disk_free_space($path);
$total = @disk_total_space($path);
$mem = read_meminfo();

$appHome = rtrim(getenv('APP_HOME') ?: '', '/');
$mariadbUp = $appHome !== '' && file_exists($appHome . '/lamp-run/mysql.sock');
$mariadbSleeping = $appHome !== '' && file_exists($appHome . '/lamp-run/mariadb-asleep');
$liteMode = $appHome !== '' && file_exists($appHome . '/lamp-run/lite-mode');

// docroot la thu muc cha cua _admin/ (xem nginx.conf.template: root __DOCROOT__)
$docroot = dirname(__DIR__);
$wpInstalled = file_exists($docroot . '/wp-config.php') || file_exists($docroot . '/wp-load.php');
?>
<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quan tri</title>
<style>
body{font-family:system-ui,sans-serif;max-width:420px;margin:60px auto;padding:0 20px}
a.card{display:block;padding:16px;margin-bottom:12px;border:1px solid #ddd;border-radius:8px;
text-decoration:none;color:#222}
a.card:hover{background:#f7f7f7}
a.card b{display:block;font-size:16px}
a.card span{font-size:13px;color:#666}
a.card.highlight{border-color:#21759B;background:#f3f9fc}
.stats{font-size:13px;color:#666;margin-top:24px;padding-top:16px;border-top:1px solid #eee;line-height:1.8}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:4px}
.dot.up{background:#2ecc71}
.dot.down{background:#e74c3c}
.dot.sleep{background:#f39c12}
.badge{display:inline-block;font-size:11px;background:#fff3cd;color:#856404;padding:2px 8px;border-radius:10px;margin-left:6px}
</style></head><body>
<h2>Cong cu quan tri<?php if ($liteMode): ?><span class="badge">Che do PHP-Lite</span><?php endif; ?></h2>
<a class="card" href="db.php"><b>Database (Adminer)</b><span><?= $liteMode ? 'SQLite (khong dung MariaDB o che do Lite)' : 'Xem/sua bang MySQL truc tiep' ?></span></a>
<a class="card" href="files.php"><b>File Manager</b><span>Duyet/sua file website</span></a>
<a class="card" href="logs.php"><b>Log</b><span>Xem log nginx/php-fpm/mariadb</span></a>
<a class="card" href="info.php"><b>PHP Info</b><span>Xem cau hinh/extension PHP dang chay</span></a>
<?php if (!$wpInstalled): ?>
<a class="card highlight" href="install-wp.php"><b>Cai WordPress moi (1-Click)</b><span>Docroot dang trong - tai + ket noi database co san, khong can build lai APK</span></a>
<?php endif; ?>
<div class="stats">
<?php if ($free !== false && $total !== false && $total > 0):
    $usedPct = round((1 - $free / $total) * 100, 1); ?>
  Dung luong: con trong <?= format_bytes($free) ?> / tong <?= format_bytes($total) ?> (da dung <?= $usedPct ?>%)<br>
<?php endif; ?>
<?php if ($mem && isset($mem['MemAvailable'], $mem['MemTotal'])): ?>
  RAM may: con trong <?= format_bytes($mem['MemAvailable']) ?> / tong <?= format_bytes($mem['MemTotal']) ?><br>
<?php endif; ?>
<?php if ($liteMode): ?>
  Dich vu: <span class="dot up"></span>php -S don le (che do Lite - da tat MariaDB/nginx/php-fpm de tiet kiem RAM)
<?php else: ?>
  Dich vu: <span class="dot up"></span>Nginx + PHP-FPM (dang phuc vu trang nay)
  &middot; <span class="dot <?= $mariadbUp ? 'up' : ($mariadbSleeping ? 'sleep' : 'down') ?>"></span>MariaDB <?= $mariadbUp ? 'dang chay' : ($mariadbSleeping ? 'dang ngu (Auto-Sleep - se tu thuc khi co truy cap)' : 'khong thay socket') ?>
<?php endif; ?>
</div>
</body></html>
PHP

  echo "== Xong: cong cu quan tri o _admin/ (chi truy cap duoc qua LAN, xem nginx.conf) =="
}

# inject_auth_guard <file_php>
# Chèn "require __DIR__.'/auth.php';" ngay sau thẻ "<?php" ĐẦU TIÊN của file.
inject_auth_guard() {
  local file="$1"
  # Chi thay occurrence DAU TIEN cua "<?php" - dung awk de an toan hon sed
  # voi file lon (Adminer/TinyFileManager la file PHP kha dai, nhieu the <?php khac trong string).
  awk '
    !done && /<\?php/ {
      sub(/<\?php/, "<?php require __DIR__ . \x27/auth.php\x27; ")
      done = 1
    }
    { print }
  ' "$file" > "$file.tmp" && mv "$file.tmp" "$file"
}
