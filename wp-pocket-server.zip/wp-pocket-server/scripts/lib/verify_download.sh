#!/usr/bin/env bash
# Thư viện dùng chung, KHÔNG chạy trực tiếp - được source bởi mọi script có tải file từ internet
# (termux_fetch.sh, prepare_cloudflared.sh, site_source.sh, admin_tools.sh, php.sh).
# Xem HANDOFF.md mục 1bc (đề xuất Z1-Z3 của PDF "chất lượng tính phí").
#
# CHÍNH SÁCH (cố ý bất đối xứng):
#   * Hash SAI (mismatch)            -> LUÔN dừng build (exit 1). File đã bị đổi hoặc hỏng; tiếp tục = đóng gói
#                                       mã không rõ nguồn gốc vào APK chạy trên máy người dùng.
#   * KHÔNG có hash để đối chiếu     -> cảnh báo + ghi "UNVERIFIED" vào báo cáo; dừng nếu VERIFY_STRICT=1.
#                                       (Nguồn công bố hash tạm không truy cập được không nên làm gãy build.)
#
# GIỚI HẠN THẬT (nói thẳng): hash lấy từ CÙNG nhà phát hành với file => chống được file hỏng/cắt dở, CDN/cache lỗi,
# mirror bị đổi, và thay riêng file tải; KHÔNG chống được việc chính nhà phát hành bị chiếm quyền (cần chữ ký GPG + khoá
# đã ghim sẵn - xem HANDOFF.md mục 1bc phần "chưa làm").
#
# Báo cáo: nếu đặt $VERIFY_REPORT, mỗi file ghi 1 dòng TSV: nhãn<TAB>trạng thái<TAB>thuật toán<TAB>hash thực<TAB>nguồn hash
# (trạng thái: OK | UNVERIFIED | RECORDED | MISMATCH). CI lưu vào artifact build-inputs.

# verify_hash_of <algo> <file>  -> in hash thực của file
verify_hash_of() {
  case "$1" in
    sha256) sha256sum "$2" | awk '{print $1}' ;;
    sha1)   sha1sum "$2"   | awk '{print $1}' ;;
    *) echo "verify: thuat toan khong ho tro: $1" >&2; return 2 ;;
  esac
}

# verify_extract_hash <algo>   (đọc stdin) -> in token hex ĐẦU TIÊN đúng độ dài, chữ thường.
# Dùng ranh giới ký tự: chuỗi sha256 (64) nằm trong chuỗi sha512 (128) KHÔNG bị nhận nhầm.
verify_extract_hash() {
  local len
  case "$1" in sha256) len=64 ;; sha1) len=40 ;; *) return 2 ;; esac
  tr 'A-F' 'a-f' | grep -oE "(^|[^0-9a-f])[0-9a-f]{$len}([^0-9a-f]|$)" | head -n1 | grep -oE "[0-9a-f]{$len}"
}

# verify_record <nhan> <trang_thai> <algo> <hash_thuc> <nguon>
verify_record() {
  [[ -n "${VERIFY_REPORT:-}" ]] || return 0
  printf '%s\t%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" "${5:-}" >> "$VERIFY_REPORT"
}

# verify_matches <algo> <file> <expected>   -> 0 nếu khớp, 1 nếu không (KHÔNG in, KHÔNG thoát; dùng cho nhánh thử lại)
verify_matches() {
  local actual expected
  actual="$(verify_hash_of "$1" "$2" 2>/dev/null)" || return 1
  expected="$(printf '%s' "$3" | tr 'A-F' 'a-f')"
  [[ -n "$expected" && "$actual" == "$expected" ]]
}

# verify_file <nhan> <file> <algo> <expected_hoac_rong> [nguon]
#   0 = khớp (hoặc chưa có hash để đối chiếu và không strict). THOÁT 1 nếu sai hash / strict mà thiếu hash.
verify_file() {
  local label="$1" file="$2" algo="$3" expected="${4:-}" source="${5:-}" actual
  actual="$(verify_hash_of "$algo" "$file")" || { echo "!!! verify [$label]: khong tinh duoc $algo cua $file" >&2; exit 1; }
  if [[ -z "$expected" ]]; then
    echo "  !!! CANH BAO [$label]: KHONG co $algo de doi chieu - file CHUA duoc xac minh ($algo thuc te: $actual)" >&2
    verify_record "$label" UNVERIFIED "$algo" "$actual" "$source"
    if [[ "${VERIFY_STRICT:-0}" == "1" ]]; then
      echo "!!! VERIFY_STRICT=1 -> dung build vi [$label] khong xac minh duoc" >&2
      exit 1
    fi
    return 0
  fi
  expected="$(printf '%s' "$expected" | tr 'A-F' 'a-f')"
  if [[ "$actual" == "$expected" ]]; then
    echo "  -> da xac minh $algo [$label]: $actual"
    verify_record "$label" OK "$algo" "$actual" "$source"
    return 0
  fi
  echo "!!! LOI [$label]: $algo KHONG KHOP - file da bi doi hoac hong, DUNG build." >&2
  echo "      mong doi : $expected" >&2
  echo "      thuc te  : $actual" >&2
  echo "      nguon hash: ${source:-?}" >&2
  verify_record "$label" MISMATCH "$algo" "$actual" "$source"
  exit 1
}

# verify_note <nhan> <file> [nguon]   -> chỉ GHI hash sha256 (không đối chiếu được vì nhà phát hành không công bố).
# Để lần sau còn dấu vết kiểm toán: "build này đã đóng gói đúng file có hash X".
verify_note() {
  local actual
  actual="$(verify_hash_of sha256 "$2" 2>/dev/null)" || return 0
  verify_record "$1" RECORDED sha256 "$actual" "${3:-khong co hash cong bo}"
}

# verify_elf <file>  -> 0 nếu file bắt đầu bằng magic ELF (chặn trường hợp lưu nhầm trang lỗi HTML thành binary)
verify_elf() {
  [[ "$(od -An -tx1 -N4 "$1" 2>/dev/null | tr -d ' \n')" == "7f454c46" ]]
}

# fetch_with_sidecar_hash <nhan> <url> <url_hash> <algo> <file_ra>
#   Tải file + tải file hash công bố KÈM THEO (sidecar, vd latest.zip.sha1). Thử lại 1 lần khi lệch (CDN có thể trả
#   file mới nhưng hash cũ trong vài phút). Trả 3 nếu KHÔNG tải được file chính (người gọi quyết định bỏ qua/dừng);
#   thoát 1 nếu hash sai sau khi thử lại.
fetch_with_sidecar_hash() {
  local label="$1" url="$2" side="$3" algo="$4" out="$5" attempt expected=""
  for attempt in 1 2; do
    curl -fsSL --retry 2 -o "$out.part" "$url" 2>/dev/null || { rm -f "$out.part"; return 3; }
    expected="$(curl -fsSL --retry 2 "$side" 2>/dev/null | verify_extract_hash "$algo" || true)"
    [[ -z "$expected" ]] && break
    verify_matches "$algo" "$out.part" "$expected" && break
    if [[ $attempt -eq 1 ]]; then
      echo "  (hash lech lan 1 [$label] - co the do CDN/cache; doi ${VERIFY_RETRY_SLEEP:-15}s roi tai lai 1 lan)" >&2
      sleep "${VERIFY_RETRY_SLEEP:-15}"
    fi
  done
  verify_file "$label" "$out.part" "$algo" "$expected" "$side"
  mv -f "$out.part" "$out"
}

# download_pinned <nhan> <url> <sha256_da_ghim> <file_ra>
#   Tải file với hash ĐÃ GHI SẴN trong scripts/lib/pins.env. Trả 3 nếu không tải được (người gọi bỏ qua công cụ);
#   thoát 1 nếu hash sai. Hash ghim rỗng -> UNVERIFIED (xem verify_file).
download_pinned() {
  local label="$1" url="$2" pin="$3" out="$4"
  curl -fsSL --retry 2 -o "$out.part" "$url" 2>/dev/null || { rm -f "$out.part"; return 3; }
  verify_file "$label" "$out.part" sha256 "$pin" "pins.env ($url)"
  mv -f "$out.part" "$out"
}
