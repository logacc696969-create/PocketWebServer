#!/usr/bin/env bash
# Ham dung chung cho scripts/runtimes/{node,python,static}.sh - dong goi thu vien + giam sat start-generic.sh (HANDOFF.md muc 1bi). Source, khong chay truc tiep.
# Yeu cau da source: scripts/lib/collect_libs.sh (collect_shared_libs) va scripts/lib/termux_fetch.sh (termux_download_with_deps, termux_find_binary).

GEN_TPL_DIR="scripts/runtimes/templates"

# generic_front_proxy [mac_dinh=false] -> in "true"/"false" theo site.config.json "front_proxy" (co khoa thi dung gia tri do, khong co thi dung mac dinh).
# node/python: mac dinh false (khong doi hanh vi cu ngoai viec dong goi thu vien). static: mac dinh true (nginx phuc vu file tinh nhe/nhanh hon php -S).
# Luu y: KHONG dung ".front_proxy // true" - jq coi false la "khong co" nen se tra true ca khi nguoi dung dat false.
generic_front_proxy() {
  local d="${1:-false}" v
  v="$(jq -r --argjson d "$d" 'if has("front_proxy") then .front_proxy else $d end' site.config.json 2>/dev/null || echo "$d")"
  [[ "$v" == "true" ]] && echo true || echo false
}

# generic_bundle_nginx <out_dir> <soname_map>   (can mang) - tai nginx tu Termux, dat libnginx.so, gom thu vien phu thuoc CUNG soname_map.
generic_bundle_nginx() {
  local out="$1" map="$2" ex nbin
  ex="$(mktemp -d)"
  termux_download_with_deps nginx "$ex"
  nbin="$(termux_find_binary "$ex" nginx)"
  if [[ -z "$nbin" ]]; then echo "LOI: khong tim thay binary nginx sau khi tai tu Termux" >&2; return 1; fi
  cp "$nbin" "$out/libnginx.so"; chmod 755 "$out/libnginx.so"
  local m2; m2="$(mktemp)"
  collect_shared_libs "$ex" "$out" "$m2"
  cat "$m2" >> "$map"
}

# generic_bundle_python_stdlib <extract_dir> <out_dir> <staging> - Termux python can THU VIEN CHUAN (lib/python3.x/*.py) va cac module mo rong
# (lib-dynload/*.so). Truoc ban nay runtime python chi copy binary + *.so => khong co "os", "encodings"... nen khong chay duoc.
#  - stdlib thuan .py -> <staging>/_supervisor/pyhome/lib/python3.x (se vao www.zip; .py khong bi han che thuc thi cua Android) - bo test/idlelib/tkinter...
#  - lib-dynload/*.so -> <out_dir>/libpydyn_<ten>.so (PHAI bat dau "lib" va ket thuc ".so" thi moi vao nativeLibDir) + <staging>/_supervisor/dynload-map.txt
#    ("ten goc ten moi"): start-generic.sh dung lai symlink lib-dynload/<ten goc> -> nativeLibDir/<ten moi> luc chay.
# Xoa lib-dynload khoi extract_dir sau khi xu ly de collect_shared_libs khong copy lan nua (tranh nhan doi dung luong).
generic_bundle_python_stdlib() {
  local ex="$1" out="$2" staging="$3" lib ver dst f bn stem
  lib="$(find "$ex" -type d -name 'python3.*' -path '*/lib/*' ! -path '*/site-packages/*' 2>/dev/null | awk '{print length, $0}' | sort -n | head -1 | cut -d' ' -f2-)"
  if [[ -z "$lib" ]]; then echo "LOI: khong thay thu muc lib/python3.x trong goi python cua Termux" >&2; return 1; fi
  ver="$(basename "$lib")"
  dst="$staging/_supervisor/pyhome/lib/$ver"
  mkdir -p "$dst" "$staging/_supervisor"
  : > "$staging/_supervisor/dynload-map.txt"
  if [[ -d "$lib/lib-dynload" ]]; then
    while IFS= read -r -d '' f; do
      bn="$(basename "$f")"; stem="${bn%.so}"; stem="$(echo "$stem" | tr '.' '_')"
      cp "$f" "$out/libpydyn_${stem}.so" 2>/dev/null || continue
      echo "$bn libpydyn_${stem}.so" >> "$staging/_supervisor/dynload-map.txt"
    done < <(find "$lib/lib-dynload" -maxdepth 1 \( -type f -o -type l \) -name '*.so' -print0)
    rm -rf "$lib/lib-dynload"
  fi
  # Copy stdlib, bo phan nang va khong can o runtime.
  ( cd "$lib" && tar -cf - --exclude='__pycache__' --exclude='*.pyc' --exclude='test' --exclude='tests' --exclude='idlelib' --exclude='tkinter' \
      --exclude='turtledemo' --exclude='lib2to3' --exclude='site-packages' --exclude='config-*' . ) | ( cd "$dst" && tar -xf - )
  mkdir -p "$dst/lib-dynload"
  echo "$ver"
}

# generic_install_supervisor <staging> <soname_map> <front: true|false> - dat start-generic.sh + soname-map (+ mau nginx neu front) vao <staging>/_supervisor.
generic_install_supervisor() {
  local staging="$1" map="$2" front="$3" sup
  sup="$staging/_supervisor"; mkdir -p "$sup"
  cp "$GEN_TPL_DIR/start-generic.sh" "$sup/start-generic.sh"; chmod 755 "$sup/start-generic.sh"
  sort -u "$map" > "$sup/soname-map.txt"
  if [[ "$front" == "true" ]]; then
    cp "$GEN_TPL_DIR/nginx-front.conf.template" "$GEN_TPL_DIR/front-locations-proxy.conf.template" "$GEN_TPL_DIR/front-locations-static.conf.template" "$sup/"
  fi
}

# generic_python_app_args <mode: direct|proxy> <entry> <wsgi> [asgi] - in tham so dua cho binary python (HANDOFF.md muc 1bq-C). Token __PORT__ / __APP_PORT__ /
# __DOCROOT__ do start-generic.sh thay luc chay. Thu tu uu tien: asgi / wsgi (may chu di kem; loai tru nhau) > entry (chay thang file) > http.server tinh.
# wsgi o che do proxy: nghe 127.0.0.1:APP_PORT va TIN X-Forwarded-* (chi tu nginx phia truoc); che do direct: nghe 0.0.0.0:PORT, KHONG tin header.
generic_python_app_args() {
  local mode="$1" entry="${2:-}" wsgi="${3:-}" asgi="${4:-}"
  if [[ -n "$asgi" ]]; then
    # ASGI (Starlette, FastAPI...): cung may chu, them --asgi (cau noi ASGI->WSGI, lifespan, phan hoi duoc gom het roi moi gui).
    if [[ "$mode" == "proxy" ]]; then
      echo "__DOCROOT__/_supervisor/wpp_wsgi.py $asgi --asgi --port __APP_PORT__ --bind 127.0.0.1 --trust-proxy"
    else
      echo "__DOCROOT__/_supervisor/wpp_wsgi.py $asgi --asgi --port __PORT__ --bind 0.0.0.0"
    fi
  elif [[ -n "$wsgi" ]]; then
    if [[ "$mode" == "proxy" ]]; then
      echo "__DOCROOT__/_supervisor/wpp_wsgi.py $wsgi --port __APP_PORT__ --bind 127.0.0.1 --trust-proxy"
    else
      echo "__DOCROOT__/_supervisor/wpp_wsgi.py $wsgi --port __PORT__ --bind 0.0.0.0"
    fi
  elif [[ -n "$entry" ]]; then
    echo "__DOCROOT__/${entry}"
  elif [[ "$mode" == "proxy" ]]; then
    echo "-m http.server __APP_PORT__ --directory __DOCROOT__ --bind 127.0.0.1"
  else
    echo "-m http.server __PORT__ --directory __DOCROOT__ --bind 0.0.0.0"
  fi
}

# generic_install_wsgi_server <staging> - dat may chu WSGI di kem vao <staging>/_supervisor/wpp_wsgi.py (chi dung stdlib Python).
generic_install_wsgi_server() {
  local sup="$1/_supervisor"
  mkdir -p "$sup"
  cp scripts/runtimes/wpp_wsgi.py "$sup/wpp_wsgi.py"
  chmod 644 "$sup/wpp_wsgi.py"
}

# generic_write_runtime_json <out_dir> <port> <binary> <mode> <app_bin> <app_args> <web_subdir> <extra_env_json_fragment>
# extra_env_json_fragment: chuoi dang '"KEY": "value", "K2": "v2"' (khong co dau phay cuoi, co the rong).
generic_write_runtime_json() {
  local out="$1" port="$2" binary="$3" mode="$4" app_bin="$5" app_args="$6" web="$7" extra="${8:-}"
  python3 - "$out/runtime.json" "$port" "$binary" "$mode" "$app_bin" "$app_args" "$web" "$extra" <<'PY'
import json, sys
path, port, binary, mode, app_bin, app_args, web, extra = sys.argv[1:9]
env = {"GEN_MODE": mode, "GEN_APP_BIN": app_bin, "GEN_APP_ARGS": app_args, "GEN_WEB_SUBDIR": web}
if extra.strip():
    env.update(json.loads('{' + extra + '}'))
doc = {"port": int(port), "binary": binary, "docroot": "www",
       "exec": ["/system/bin/sh", "${DOCROOT}/_supervisor/start-generic.sh"], "env": env}
json.dump(doc, open(path, 'w'), indent=2, ensure_ascii=False)
PY
}
