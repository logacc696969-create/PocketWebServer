#!/usr/bin/env bash
# ==========================================================================
# Thư viện dùng chung, KHÔNG chạy trực tiếp - được source bởi các script
# trong scripts/runtimes/*.sh
#
# CANH BAO: binary lay tu kho goi Termux (https://github.com/termux/termux-packages)
# duoc build de chay dung layout thu muc cua Termux. Khi tach ra dung o app
# khac, co the thieu vai thu vien .so phu thuoc giam tiep hoac sai duong dan
# config mac dinh (vi du php.ini). Day la ban chat ky thuat cua viec tai su
# dung mot binary Linux-target ben ngoai moi truong goc, khong phai loi rieng
# cua cach lam nay. Neu logcat bao "cannot open shared object" / "undefined
# symbol", them goi Termux chua thu vien do vao TERMUX_EXTRA_DEPS roi chay lai.
# ==========================================================================

TERMUX_REPO="https://packages.termux.dev/apt/termux-main"

# termux_get_field <ten_goi> <ten_truong>
termux_get_field() {
  local pkg="$1" field="$2:"
  awk -v pkg="$pkg" -v field="$field" '
    $0=="Package: "pkg {f=1; next}
    f && index($0, field)==1 {sub("^"field" *",""); print; exit}
    f && $0=="" {f=0}
  ' "$TERMUX_PACKAGES_INDEX"
}

# termux_download_pkg <ten_goi> <thu_muc_giai_nen>
termux_download_pkg() {
  local pkg="$1" extract_dir="$2"
  local filename
  filename="$(termux_get_field "$pkg" "Filename")"
  if [[ -z "$filename" ]]; then
    echo "  (bo qua: khong thay goi Termux '$pkg')" >&2
    return 0
  fi
  echo "  -> tai goi Termux: $pkg"
  local tmp_deb="$TERMUX_WORK/pkg_${pkg}.deb"
  curl -fsSL -o "$tmp_deb" "$TERMUX_REPO/$filename"
  (cd "$TERMUX_WORK" && ar x "pkg_${pkg}.deb")
  tar -xf "$TERMUX_WORK"/data.tar.* -C "$extract_dir" 2>/dev/null || true
  rm -f "$TERMUX_WORK"/data.tar.* "$TERMUX_WORK"/control.tar.* "$TERMUX_WORK"/debian-binary "$tmp_deb"
}

# termux_download_with_deps <ten_goi_chinh> <thu_muc_giai_nen> [them_goi_phu ...]
# Tải gói chính + walk qua truong "Depends" (1 cap, khong de quy) + cac goi
# phu bo sung thu cong (neu logcat bao thieu .so nao do).
termux_download_with_deps() {
  local main_pkg="$1" extract_dir="$2"
  shift 2
  local extra_deps=("$@")

  TERMUX_WORK="$(mktemp -d)"
  mkdir -p "$extract_dir"
  TERMUX_PACKAGES_INDEX="$TERMUX_WORK/Packages"

  echo "== Lay danh sach goi Termux ($TERMUX_ARCH) =="
  curl -fsSL -o "$TERMUX_WORK/Packages.gz" "$TERMUX_REPO/dists/stable/main/binary-$TERMUX_ARCH/Packages.gz"
  gunzip -f "$TERMUX_WORK/Packages.gz"

  echo "== Tai goi chinh: $main_pkg =="
  termux_download_pkg "$main_pkg" "$extract_dir"

  local depends_raw
  depends_raw="$(termux_get_field "$main_pkg" "Depends" || true)"
  echo "== $main_pkg phu thuoc: ${depends_raw:-'(khong co)'} =="

  IFS=',' read -ra dep_items <<< "${depends_raw:-}"
  for item in "${dep_items[@]:-}"; do
    local dep_name
    dep_name="$(echo "$item" | sed -E 's/^[[:space:]]*([a-zA-Z0-9._+-]+).*/\1/')"
    [[ -z "$dep_name" ]] && continue
    termux_download_pkg "$dep_name" "$extract_dir"
  done

  for extra in "${extra_deps[@]:-}"; do
    [[ -z "$extra" ]] && continue
    termux_download_pkg "$extra" "$extract_dir"
  done
}

# termux_find_binary <thu_muc_giai_nen> <ten_binary>
termux_find_binary() {
  local extract_dir="$1" bin_name="$2"
  find "$extract_dir" -type f -path "*/bin/${bin_name}*" | head -n1
}
