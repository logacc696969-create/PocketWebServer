#!/usr/bin/env bash
# ==========================================================================
# Thư viện dùng chung, KHÔNG chạy trực tiếp - được source bởi các script
# trong scripts/runtimes/*.sh
#
# CANH BAO: binary lay tu kho goi Termux (https://github.com/termux/termux-packages)
# duoc build de chay dung layout thu muc cua Termux. Khi tach ra dung o app
# khac, co the thieu vai thu vien .so phu thuoc giam tiep hoac sai duong dan
# config mac dinh (vi du php.ini). Day la ban chat ky thuat cua viec tai su
# dung mot binary Linux-target ben ngoai moi truong goc, khong phai loi rieng
# cua cach lam nay. Neu logcat bao "cannot open shared object" / "undefined
# symbol", them goi Termux chua thu vien do vao TERMUX_EXTRA_DEPS roi chay lai.
# ==========================================================================

TERMUX_REPO="${TERMUX_REPO:-https://packages.termux.dev/apt/termux-main}"   # ghi de duoc de test bang kho gia (scripts/tests/supply-chain-test.py)

# Xac minh toan ven goi .deb voi SHA256 trong index (HANDOFF.md muc 1bc, de xuat Z1) - truoc day index chi duoc GHI LAI
# (termux_record_pkg) chu KHONG BAO GIO doi chieu voi file tai ve.
# shellcheck source=verify_download.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/verify_download.sh"

# termux_get_field <ten_goi> <ten_truong>
termux_get_field() {
  local pkg="$1" field="$2:"
  awk -v pkg="$pkg" -v field="$field" '
    $0=="Package: "pkg {f=1; next}
    f && index($0, field)==1 {sub("^"field" *",""); print; exit}
    f && $0=="" {f=0}
  ' "$TERMUX_PACKAGES_INDEX"
}

# termux_record_pkg <ten_goi>: GHI NHAN "arch, goi, phien ban, sha256" cua goi se tai vao
# $TERMUX_MANIFEST (TSV: pkg<TAB>version<TAB>sha256<TAB>arch). scripts/lib/termux_lock.py
# so sanh tep nay voi termux-packages.lock va BAO LOI khi major.minor cua goi QUAN TRONG
# (php, php-fpm, mariadb, nginx) doi - xem HANDOFF.md muc 1ay. Day la PHUONG AN THAY THE cho
# "ghim phien ban" (kho Termux chi giu ban MOI NHAT nen khong the "apt install pkg=version"):
# khong chan viec tai ban moi, nhung KHONG de ban doi am tham ma khong ai test.
termux_record_pkg() {
  [[ -n "${TERMUX_MANIFEST:-}" ]] || return 0
  local pkg="$1" ver sha
  ver="$(termux_get_field "$pkg" "Version")"
  sha="$(termux_get_field "$pkg" "SHA256")"
  printf '%s\t%s\t%s\t%s\n' "$pkg" "$ver" "$sha" "${TERMUX_ARCH:-unknown}" >> "$TERMUX_MANIFEST"
}

# termux_download_pkg <ten_goi> <thu_muc_giai_nen>
# De xuat DeepSeek muc P1 (xem HANDOFF.md muc 10 + muc 1at) - "Ghim phien
# ban Termux package (thay vi luon 'latest') - tranh site hong khi Termux
# doi ban ABI/build khac giua 2 lan build CI". Tham so thu 3 ($3) la phien
# ban MONG MUON (TUY CHON, de trong = giu hanh vi cu, luon dung ban MOI
# NHAT hien co trong index). Neu co truyen vao VA phien ban THAT SU trong
# index KHAC voi phien ban mong muon, CHI CANH BAO ro trong log build
# (KHONG lam fail build tu dong) - vi moi truong dung de soan ham nay
# KHONG truy cap duoc packages.termux.dev (xem HANDOFF.md muc 1) de tu xac
# nhan dung so phien ban THAT dang co san o thoi diem viet - ghi ham nay
# truoc, de nguoi co quyen truy cap that tu dien cac gia tri phien ban cu
# the sau (hien CHUA co loi goi nao truyen tham so nay trong php.sh, day
# la ha tang san sang dung, chua phai da ap dung xong toan bo P1).
termux_download_pkg() {
  local pkg="$1" extract_dir="$2" expected_version="${3:-}"
  local filename
  filename="$(termux_get_field "$pkg" "Filename")"
  if [[ -z "$filename" ]]; then
    echo "  (bo qua: khong thay goi Termux '$pkg')" >&2
    return 0
  fi
  termux_record_pkg "$pkg"
  if [[ -n "$expected_version" ]]; then
    local actual_version
    actual_version="$(termux_get_field "$pkg" "Version")"
    if [[ "$actual_version" != "$expected_version" ]]; then
      echo "  !!! CANH BAO: '$pkg' mong doi phien ban '$expected_version' nhung repo Termux dang co '$actual_version' - van tiep tuc tai (khong fail build), nhung NEN kiem tra lai thu cong neu site hong sau build nay." >&2
    fi
  fi
  local tmp_deb="$TERMUX_WORK/pkg_${pkg}.deb" expected_sha
  expected_sha="$(termux_get_field "$pkg" "SHA256")"
  # De xuat DeepSeek muc L3 (xem HANDOFF.md muc 10 + muc 1at) - CHI tai lai qua mang neu CHUA co san trong TERMUX_WORK
  # (vd duoc actions/cache khoi phuc tu lan chay CI truoc). SUA 1bc: truoc day chi kiem "-s" (ton tai, > 0 byte) nen 1 file
  # BI CAT DO tu lan chay truoc van lot qua; gio doi chieu SHA256 voi index, cache hong thi XOA va tai lai.
  if [[ -s "$tmp_deb" ]]; then
    if [[ -n "$expected_sha" ]] && ! verify_matches sha256 "$tmp_deb" "$expected_sha"; then
      echo "  !!! cache hong/cu cua $pkg (SHA256 khong khop index) - xoa va tai lai" >&2
      rm -f "$tmp_deb"
    else
      echo "  -> dung ban cache san co: $pkg (khong tai lai qua mang)"
    fi
  fi
  if [[ ! -s "$tmp_deb" ]]; then
    echo "  -> tai goi Termux: $pkg"
    # Tai vao .part roi doi ten: lan tai bi ngat KHONG de lai file cut do mang ten that trong cache.
    curl -fsSL --retry 2 -o "$tmp_deb.part" "$TERMUX_REPO/$filename" || { rm -f "$tmp_deb.part"; echo "LOI: tai '$pkg' that bai" >&2; exit 1; }
    mv -f "$tmp_deb.part" "$tmp_deb"
  fi
  # SAI hash -> verify_file DUNG build (file xau con trong cache se bi phat hien va xoa o dau ham, lan chay sau).
  # Thieu hash trong index -> UNVERIFIED (VERIFY_STRICT=1 thi dung).
  verify_file "termux:$pkg" "$tmp_deb" sha256 "$expected_sha" "Packages index ($TERMUX_REPO)"

  (cd "$TERMUX_WORK" && ar x "pkg_${pkg}.deb")
  # SUA 1bc: truoc day "2>/dev/null || true" nuot MOI loi giai nen (goi hong => giai nen mot nua, im lang). Van khong lam
  # fail build (tar co the tra loi vo hai khi nhieu goi ghi de symlink cung ten) nhung IN RA de ai doc log cung thay.
  local tar_err
  if ! tar_err="$(tar -xf "$TERMUX_WORK"/data.tar.* -C "$extract_dir" 2>&1)"; then
    echo "  !!! CANH BAO: tar bao loi khi giai nen '$pkg' (khong dung build): $(printf '%s' "$tar_err" | head -n2 | tr '\n' ' ')" >&2
  fi
  # CHI xoa 2 file trung gian (tar con lai sau khi "ar x", tai tao lai duoc
  # NGAY tu chinh file .deb da co san) - GIU LAI "$tmp_deb" (khac ban truoc
  # vong nay, da tung xoa luon) de actions/cache luu lai cho lan chay sau.
  rm -f "$TERMUX_WORK"/data.tar.* "$TERMUX_WORK"/control.tar.* "$TERMUX_WORK"/debian-binary
}

# termux_download_with_deps <ten_goi_chinh> <thu_muc_giai_nen> [them_goi_phu ...]
# Tải gói chính + walk qua truong "Depends" (1 cap, khong de quy) + cac goi
# phu bo sung thu cong (neu logcat bao thieu .so nao do).
termux_download_with_deps() {
  local main_pkg="$1" extract_dir="$2"
  shift 2
  local extra_deps=("$@")

  # De xuat DeepSeek muc L3 (xem HANDOFF.md muc 10 + muc 1at) - cho phep
  # NGUOI GOI (vd build-apk.yml) tu dat san TERMUX_WORK thanh 1 duong dan CO
  # DINH (thay vi luon random qua mktemp) de actions/cache co the cache/
  # khoi phuc dung thu muc nay giua cac lan chay CI - giam thoi gian tai lai
  # cac goi .deb (Termux) khong doi moi lan build. KHONG anh huong bat ky
  # noi goi nao khac KHONG dat bien nay (van mktemp -d nhu truoc, hanh vi cu
  # giu nguyen 100%).
  TERMUX_WORK="${TERMUX_WORK:-$(mktemp -d)}"
  mkdir -p "$TERMUX_WORK"
  mkdir -p "$extract_dir"
  TERMUX_PACKAGES_INDEX="$TERMUX_WORK/Packages"
  # Ghi nhan phien ban/sha256 tung goi (xem termux_record_pkg + termux_lock.py). Tep RIENG theo arch
  # va xoa dau moi lan khoi tao de khong lan ban ghi cu khi TERMUX_WORK duoc actions/cache giu lai.
  TERMUX_MANIFEST="${TERMUX_MANIFEST:-$TERMUX_WORK/termux-manifest-${TERMUX_ARCH:-unknown}.tsv}"
  : > "$TERMUX_MANIFEST"

  echo "== Lay danh sach goi Termux ($TERMUX_ARCH) =="
  curl -fsSL -o "$TERMUX_WORK/Packages.gz" "$TERMUX_REPO/dists/stable/main/binary-$TERMUX_ARCH/Packages.gz"
  gunzip -f "$TERMUX_WORK/Packages.gz"

  echo "== Tai goi chinh: $main_pkg =="
  termux_download_pkg "$main_pkg" "$extract_dir"

  local depends_raw
  depends_raw="$(termux_get_field "$main_pkg" "Depends" || true)"
  echo "== $main_pkg phu thuoc: ${depends_raw:-'(khong co)'} =="

  IFS=',' read -ra dep_items <<< "${depends_raw:-}"
  for item in "${dep_items[@]:-}"; do
    local dep_name
    dep_name="$(echo "$item" | sed -E 's/^[[:space:]]*([a-zA-Z0-9._+-]+).*/\1/')"
    [[ -z "$dep_name" ]] && continue
    termux_download_pkg "$dep_name" "$extract_dir"
  done

  for extra in "${extra_deps[@]:-}"; do
    [[ -z "$extra" ]] && continue
    termux_download_pkg "$extra" "$extract_dir"
  done
}

# termux_find_binary <thu_muc_giai_nen> <ten_binary>
termux_find_binary() {
  local extract_dir="$1" bin_name="$2"
  find "$extract_dir" -type f -path "*/bin/${bin_name}*" | head -n1
}
