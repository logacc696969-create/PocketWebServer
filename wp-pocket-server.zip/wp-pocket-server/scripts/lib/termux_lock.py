#!/usr/bin/env python3
"""So sanh phien ban goi Termux da TAI voi tep khoa (termux-packages.lock) - HANDOFF.md muc 1ay.

Kho Termux chi giu ban MOI NHAT nen khong the "ghim" bang `apt install pkg=version`. Thay vao do:
  termux_lock.py update <manifest.tsv...> <lock>   ghi/cap nhat tep khoa tu cac manifest (sau khi DA TEST ban moi)
  termux_lock.py check  <manifest.tsv...> <lock>   so sanh; thoat 1 neu major.minor cua goi QUAN TRONG doi
Manifest: pkg<TAB>version<TAB>sha256<TAB>arch (do termux_fetch.sh ghi). Lock: arch<TAB>pkg<TAB>version<TAB>sha256.
Ma thoat: 0 = ok/chi canh bao; 1 = lech major.minor goi quan trong (tru khi ALLOW_TERMUX_DRIFT=1); 2 = loi dung.
"""
import os, re, sys

# Goi ma doi major.minor co the lam hong APK/site (ABI cua extension PHP, dinh dang du lieu MariaDB...).
CRITICAL = {'php', 'php-fpm', 'mariadb', 'nginx'}


def read_manifest(paths):
    rows = {}
    for path in paths:
        if not os.path.exists(path):
            continue
        for line in open(path, encoding='utf-8'):
            parts = line.rstrip('\n').split('\t')
            if len(parts) >= 4 and parts[0]:
                pkg, ver, sha, arch = parts[:4]
                rows[(arch, pkg)] = (ver, sha)  # ban ghi sau thang (cung goi/arch)
    return rows


def read_lock(path):
    rows = {}
    if not os.path.exists(path):
        return None
    for line in open(path, encoding='utf-8'):
        if line.startswith('#') or not line.strip():
            continue
        parts = line.rstrip('\n').split('\t')
        if len(parts) >= 4:
            arch, pkg, ver, sha = parts[:4]
            rows[(arch, pkg)] = (ver, sha)
    return rows


def major_minor(ver):
    """'8.5.1' -> (8,5); '1:8.5.1-2' -> (8,5) (bo epoch); khong phan tich duoc -> None."""
    m = re.match(r'^(?:\d+:)?(\d+)\.(\d+)', ver or '')
    return (int(m.group(1)), int(m.group(2))) if m else None


def check(manifest, lock, allow=False):
    """Tra ve (ma_thoat, [dong_thong_bao])."""
    out = []
    if lock is None:
        out.append('NOI: chua co tep khoa termux-packages.lock - khong co gi de so sanh. Sau khi test ban hien tai, '
                   'chay `termux_lock.py update <manifest...> termux-packages.lock` roi commit.')
        return 0, out
    hard = 0
    for key in sorted(manifest):
        arch, pkg = key
        ver, sha = manifest[key]
        if key not in lock:
            out.append('NOI: [%s] %s %s la goi MOI (chua co trong tep khoa)' % (arch, pkg, ver))
            continue
        lver, lsha = lock[key]
        if ver == lver:
            if sha and lsha and sha != lsha:
                out.append('CANH BAO: [%s] %s cung phien ban %s nhung SHA-256 khac (Termux dung lai ban dung)' % (arch, pkg, ver))
            continue
        old, new = major_minor(lver), major_minor(ver)
        if pkg in CRITICAL and (old is None or new is None or old != new):
            hard += 1
            out.append('LOI: [%s] %s doi %s -> %s (major.minor KHAC) - goi QUAN TRONG, can test lai truoc khi phat hanh' % (arch, pkg, lver, ver))
        else:
            out.append('CANH BAO: [%s] %s doi %s -> %s' % (arch, pkg, lver, ver))
    for key in sorted(lock):
        if key not in manifest:
            out.append('NOI: [%s] %s co trong tep khoa nhung khong con duoc tai' % key)
    if hard and allow:
        out.append('CHO PHEP (ALLOW_TERMUX_DRIFT=1): bo qua %d loi lech phien ban goi quan trong' % hard)
        return 0, out
    return (1 if hard else 0), out


def update(manifest, lock_path):
    lines = ['# termux-packages.lock - sinh boi scripts/lib/termux_lock.py update. Cap nhat SAU KHI da test ban Termux moi.',
             '# arch<TAB>goi<TAB>phien_ban<TAB>sha256']
    for (arch, pkg) in sorted(manifest):
        ver, sha = manifest[(arch, pkg)]
        lines.append('%s\t%s\t%s\t%s' % (arch, pkg, ver, sha))
    open(lock_path, 'w', encoding='utf-8', newline='\n').write('\n'.join(lines) + '\n')
    return len(manifest)


def main(argv):
    if len(argv) < 4 or argv[1] not in ('check', 'update'):
        print(__doc__); return 2
    manifest = read_manifest(argv[2:-1]); lock_path = argv[-1]
    if not manifest:
        print('LOI: manifest rong/khong ton tai (%s) - buoc tai goi Termux chua chay?' % ', '.join(argv[2:-1])); return 2
    if argv[1] == 'update':
        print('Da ghi %d goi vao %s' % (update(manifest, lock_path), lock_path)); return 0
    code, msgs = check(manifest, read_lock(lock_path), os.environ.get('ALLOW_TERMUX_DRIFT') == '1')
    print('\n'.join(msgs) if msgs else 'OK: phien ban cac goi Termux khop tep khoa (%d goi)' % len(manifest))
    return code


if __name__ == '__main__':
    sys.exit(main(sys.argv))
