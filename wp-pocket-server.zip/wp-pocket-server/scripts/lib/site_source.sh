#!/usr/bin/env bash
# Thư viện dùng chung, KHÔNG chạy trực tiếp - được source bởi scripts/runtimes/*.sh
#
# fetch_site_source <staging_dir>
# Đọc site.config.json (đường dẫn qua biến SITE_CONFIG, mặc định ở root repo)
# và tải mã nguồn website vào <staging_dir> theo đúng site_source.type.
set -euo pipefail

SITE_CONFIG="${SITE_CONFIG:-site.config.json}"

fetch_site_source() {
  local staging="$1"
  mkdir -p "$staging"

  local type
  type="$(jq -r '.site_source.type' "$SITE_CONFIG")"

  case "$type" in
    wordpress)
      echo "== Nguon website: WordPress (tai moi nhat tu wordpress.org) =="
      curl -fsSL -o /tmp/wordpress.zip https://wordpress.org/latest.zip
      unzip -q /tmp/wordpress.zip -d /tmp/wp-extract
      cp -r /tmp/wp-extract/wordpress/. "$staging"/

      echo "== Cai san plugin WP Mail SMTP (nguoi dung tu dien SMTP that vao wp-admin sau) =="
      echo "   Dien thoai/moi server (kem ca VPS that) deu can SMTP ngoai (Gmail/Brevo/SES...)"
      echo "   de gui mail that - day KHONG phai gioi han rieng cua server nay."
      curl -fsSL -o /tmp/wp-mail-smtp.zip https://downloads.wordpress.org/plugin/wp-mail-smtp.zip \
        && unzip -q /tmp/wp-mail-smtp.zip -d "$staging/wp-content/plugins/" \
        || echo "   (bo qua neu tai plugin loi - khong chan build chinh)"

      echo "== Dong goi san plugin SQLite Database Integration (CHUA kich hoat) =="
      echo "   Dung cho Dual-Mode PHP-Lite (HANDOFF.md muc 1e) - chi start-lamp.sh moi"
      echo "   tu kich hoat (copy db.copy -> wp-content/db.php) NEU may qua yeu RAM,"
      echo "   va CHI 1 LAN DUY NHAT luc setup dau tien. Plugin nam san day trong"
      echo "   wp-content/plugins/ khong tu kich hoat gi ca nen KHONG anh huong che do"
      echo "   MariaDB binh thuong (WordPress chi doc wp-content/db.php NEU no ton tai)."
      curl -fsSL -o /tmp/sqlite-integration.zip https://downloads.wordpress.org/plugin/sqlite-database-integration.zip \
        && unzip -q /tmp/sqlite-integration.zip -d "$staging/wp-content/plugins/" \
        || echo "   CANH BAO: tai plugin SQLite loi - Dual-Mode PHP-Lite se khong hoat dong tren cac may qua yeu RAM, cac che do khac khong anh huong"

      echo "== Tao wp-config.php.template - dung MariaDB that qua unix socket =="
      # Duong dan socket that chi biet duoc luc app chay tren THIET BI THAT
      # (moi may cai app o filesDir khac nhau) - nen day la TEMPLATE, script
      # scripts/runtimes/templates/start-lamp.sh se thay __MYSQL_SOCK__ bang
      # duong dan that va sinh wp-config.php that o lan chay dau tien.
      local salts
      salts="$(curl -fsSL https://api.wordpress.org/secret-key/1.1/salt/)"
      cat > "$staging/wp-config.php.template" <<PHP
<?php
// Sinh tu template boi scripts/lib/site_source.sh + start-lamp.sh luc runtime.
// DB_HOST dang "localhost:__MYSQL_SOCK__" la cu phap chuan mysqli/PDO de noi
// qua unix socket thay vi TCP (mariadbd chay --skip-networking, chi mo unix
// socket rieng cho app - khong lo port TCP local bi truy cap ngoai y muon).
define('DB_NAME', 'wordpress');
define('DB_USER', 'wordpress');
define('DB_PASSWORD', 'wordpress');
define('DB_HOST', 'localhost:__MYSQL_SOCK__');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

${salts}

\$table_prefix = 'wp_';
define('WP_DEBUG', false);

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
PHP

      echo "== Tao wp-config-sqlite.php.template - ban thay the cho Dual-Mode PHP-Lite =="
      # Khong can placeholder duong dan (SQLite la file, khong phai socket TCP/unix
      # can biet truoc). Chi dung khi start-lamp.sh xac dinh may qua yeu RAM VA day
      # la LAN SETUP DAU TIEN (xem HANDOFF.md muc 1e ve co che "quyet dinh 1 lan").
      cat > "$staging/wp-config-sqlite.php.template" <<PHP
<?php
// Ban thay the cho wp-config.php.template, dung khi Dual-Mode PHP-Lite kich
// hoat (may qua yeu RAM). Can wp-content/db.php duoc start-lamp.sh copy tu
// plugin sqlite-database-integration TRUOC KHI file nay duoc dung.
define('DB_ENGINE', 'sqlite');

${salts}

\$table_prefix = 'wp_';
define('WP_DEBUG', false);

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
PHP
      ;;

    git)
      local repo branch
      repo="$(jq -r '.site_source.repo' "$SITE_CONFIG")"
      branch="$(jq -r '.site_source.branch // "main"' "$SITE_CONFIG")"
      echo "== Nguon website: git clone $repo ($branch) =="
      if [[ -z "$repo" || "$repo" == "null" ]]; then
        echo "LOI: site_source.type=git nhung thieu site_source.repo trong site.config.json" >&2
        exit 1
      fi
      git clone --depth 1 --branch "$branch" "$repo" "$staging"
      rm -rf "$staging/.git"
      ;;

    local)
      local path
      path="$(jq -r '.site_source.path // "site"' "$SITE_CONFIG")"
      echo "== Nguon website: thu muc local '$path' (commit san trong repo) =="
      if [[ ! -d "$path" ]]; then
        echo "LOI: khong thay thu muc '$path' - hay commit code website vao dung duong dan nay" >&2
        exit 1
      fi
      cp -r "$path"/. "$staging"/
      ;;

    zip)
      local url
      url="$(jq -r '.site_source.url' "$SITE_CONFIG")"
      echo "== Nguon website: tai zip tu $url =="
      if [[ -z "$url" || "$url" == "null" ]]; then
        echo "LOI: site_source.type=zip nhung thieu site_source.url" >&2
        exit 1
      fi
      curl -fsSL -o /tmp/site-source.zip "$url"
      unzip -q /tmp/site-source.zip -d "$staging"
      ;;

    *)
      echo "LOI: site_source.type='$type' khong duoc ho tro (xem site.config.json)" >&2
      exit 1
      ;;
  esac
}
