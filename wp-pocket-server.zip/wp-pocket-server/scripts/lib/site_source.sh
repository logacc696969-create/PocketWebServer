#!/usr/bin/env bash
# Thư viện dùng chung, KHÔNG chạy trực tiếp - được source bởi scripts/runtimes/*.sh
#
# fetch_site_source <staging_dir>
# Đọc site.config.json (đường dẫn qua biến SITE_CONFIG, mặc định ở root repo)
# và tải mã nguồn website vào <staging_dir> theo đúng site_source.type.
set -euo pipefail

SITE_CONFIG="${SITE_CONFIG:-site.config.json}"

# Xac minh toan ven file tai ve (HANDOFF.md muc 1bc). Dung chung voi cac script khac.
# shellcheck source=verify_download.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/verify_download.sh"

fetch_site_source() {
  local staging="$1"
  mkdir -p "$staging"

  local type
  type="$(jq -r '.site_source.type' "$SITE_CONFIG")"

  case "$type" in
    wordpress)
      echo "== Nguon website: WordPress (tai moi nhat tu wordpress.org) =="
      # SUA 1bc: doi chieu SHA-1 do wordpress.org cong bo (latest.zip.sha1). SHA-1 yeu ve mat mat ma nhung o day chi dung de
      # phat hien file hong/bi doi khi tai (wordpress.org khong cong bo SHA-256). Khong tai duoc file => dung build (nhu truoc).
      fetch_with_sidecar_hash "wordpress-latest.zip" "${WP_DOWNLOAD_BASE:-https://wordpress.org}/latest.zip" \
        "${WP_DOWNLOAD_BASE:-https://wordpress.org}/latest.zip.sha1" sha1 /tmp/wordpress.zip \
        || { echo "LOI: khong tai duoc WordPress" >&2; exit 1; }
      unzip -q /tmp/wordpress.zip -d /tmp/wp-extract
      cp -r /tmp/wp-extract/wordpress/. "$staging"/

      echo "== Cai san plugin WP Mail SMTP (nguoi dung tu dien SMTP that vao wp-admin sau) =="
      echo "   Dien thoai/moi server (kem ca VPS that) deu can SMTP ngoai (Gmail/Brevo/SES...)"
      echo "   de gui mail that - day KHONG phai gioi han rieng cua server nay."
      curl -fsSL -o /tmp/wp-mail-smtp.zip https://downloads.wordpress.org/plugin/wp-mail-smtp.zip \
        && verify_note "plugin:wp-mail-smtp" /tmp/wp-mail-smtp.zip \
        && unzip -q /tmp/wp-mail-smtp.zip -d "$staging/wp-content/plugins/" \
        || echo "   (bo qua neu tai plugin loi - khong chan build chinh)"

      echo "== Dong goi san plugin SQLite Database Integration (CHUA kich hoat) =="
      echo "   Dung cho Dual-Mode PHP-Lite (HANDOFF.md muc 1e) - chi start-lamp.sh moi"
      echo "   tu kich hoat (copy db.copy -> wp-content/db.php) NEU may qua yeu RAM,"
      echo "   va CHI 1 LAN DUY NHAT luc setup dau tien. Plugin nam san day trong"
      echo "   wp-content/plugins/ khong tu kich hoat gi ca nen KHONG anh huong che do"
      echo "   MariaDB binh thuong (WordPress chi doc wp-content/db.php NEU no ton tai)."
      curl -fsSL -o /tmp/sqlite-integration.zip https://downloads.wordpress.org/plugin/sqlite-database-integration.zip \
        && verify_note "plugin:sqlite-database-integration" /tmp/sqlite-integration.zip \
        && unzip -q /tmp/sqlite-integration.zip -d "$staging/wp-content/plugins/" \
        || echo "   CANH BAO: tai plugin SQLite loi - Dual-Mode PHP-Lite se khong hoat dong tren cac may qua yeu RAM, cac che do khac khong anh huong"

      echo "== Tao wp-config.php.template - dung MariaDB that qua unix socket =="
      # Duong dan socket that chi biet duoc luc app chay tren THIET BI THAT
      # (moi may cai app o filesDir khac nhau) - nen day la TEMPLATE, script
      # scripts/runtimes/templates/start-lamp.sh se thay __MYSQL_SOCK__ bang
      # duong dan that va sinh wp-config.php that o lan chay dau tien.
      local salts
      salts="$(curl -fsSL https://api.wordpress.org/secret-key/1.1/salt/)"
      cat > "$staging/wp-config.php.template" <<PHP
<?php
// Sinh tu template boi scripts/lib/site_source.sh + start-lamp.sh luc runtime.
// DB_HOST dang "localhost:__MYSQL_SOCK__" la cu phap chuan mysqli/PDO de noi
// qua unix socket thay vi TCP (mariadbd chay --skip-networking, chi mo unix
// socket rieng cho app - khong lo port TCP local bi truy cap ngoai y muon).
define('DB_NAME', 'wordpress');
define('DB_USER', 'wordpress');
define('DB_PASSWORD', 'wordpress');
define('DB_HOST', 'localhost:__MYSQL_SOCK__');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

${salts}

\$table_prefix = 'wp_';
define('WP_DEBUG', false);

// --- Hardening co ban (xem HANDOFF.md muc 2, tham khao phan tich DeepSeek) ---
// FS_METHOD='direct': KHONG co FTP tren Android - neu thieu dong nay,
// WordPress se HOI THONG TIN DANG NHAP FTP moi khi update plugin/theme (vi no
// tu kiem tra quyen ghi va mac dinh nghi ngo can FTP) - nguoi dung se ket
// (khong co FTP server nao ca) ma khong hieu vi sao. File da thuoc so huu
// dung tien trinh php-fpm (khong phai user khac) nen ghi truc tiep la an
// toan va la lua chon DUY NHAT hop ly o day.
define('FS_METHOD', 'direct');
// DISALLOW_FILE_EDIT: tat trinh sua theme/plugin ngay tren wp-admin. Neu tai
// khoan admin bi lo mat khau, ke tan cong KHONG the sua file PHP truc tiep
// qua giao dien (1 vector tan cong pho bien de cai "shell"). Muon sua code
// van sua binh thuong qua File Manager trong trang quan tri (_admin/).
define('DISALLOW_FILE_EDIT', true);
// Tu dong cai ban va bao mat nho (khong tu nang phien ban lon - vd 6.4.1 len
// 6.4.2 thi tu dong, 6.4 len 6.5 thi KHONG) - giam rui ro chay ban WordPress
// co lo hong da biet ma nguoi dung quen bam "Cap nhat".
define('WP_AUTO_UPDATE_CORE', 'minor');

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
PHP

      echo "== Tao wp-config-sqlite.php.template - ban thay the cho Dual-Mode PHP-Lite =="
      # Khong can placeholder duong dan (SQLite la file, khong phai socket TCP/unix
      # can biet truoc). Chi dung khi start-lamp.sh xac dinh may qua yeu RAM VA day
      # la LAN SETUP DAU TIEN (xem HANDOFF.md muc 1e ve co che "quyet dinh 1 lan").
      cat > "$staging/wp-config-sqlite.php.template" <<PHP
<?php
// Ban thay the cho wp-config.php.template, dung khi Dual-Mode PHP-Lite kich
// hoat (may qua yeu RAM). Can wp-content/db.php duoc start-lamp.sh copy tu
// plugin sqlite-database-integration TRUOC KHI file nay duoc dung.
define('DB_ENGINE', 'sqlite');

${salts}

\$table_prefix = 'wp_';
define('WP_DEBUG', false);

// Hardening giong het wp-config.php.template - xem chu thich day du o do.
define('FS_METHOD', 'direct');
define('DISALLOW_FILE_EDIT', true);
define('WP_AUTO_UPDATE_CORE', 'minor');

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
PHP

      echo "== Tao mu-plugin bao tri dinh ky (xoa revision cu + OPTIMIZE TABLE) =="
      # De xuat DeepSeek muc F3 - xem HANDOFF.md muc 10. QUAN TRONG: phan
      # "xoa transient het han" trong de xuat GOC cua DeepSeek KHONG can lam
      # rieng - WordPress core TU DONG lam viec nay tu ban 4.9 (hook
      # "delete_expired_transients", tu dang ky trong wp-admin/admin.php)
      # MIEN LA WP-Cron THAT SU chay duoc - dieu ma vong sua truoc (de xuat
      # DeepSeek muc F2, xem start-lamp.sh) vua moi dam bao. Viet them code
      # rieng cho viec nay se la LAM TRUNG LAP voi core, khong can thiet. mu-
      # plugins (wp-content/mu-plugins/) la thu muc DAC BIET cua WordPress -
      # moi file .php truc tiep trong do TU DONG duoc nap, KHONG can "kich
      # hoat" qua wp-admin (khac han plugin thuong) - phu hop de bundle san
      # 1 tac vu bao tri "cua chinh nen tang hosting" (dung cach cac hosting
      # tra phi that nhu WP Engine/Kinsta lam, theo PDF).
      mkdir -p "$staging/wp-content/mu-plugins"
      cat > "$staging/wp-content/mu-plugins/wppocket-maintenance.php" <<'PHP'
<?php
/**
 * Plugin Name: WP Pocket Server - Bao tri dinh ky
 * Description: Xoa post revision cu (>60 ngay) + OPTIMIZE TABLE hang tuan.
 *   Xem HANDOFF.md muc 10, de xuat DeepSeek muc F3. Chay qua WP-Cron THAT
 *   (xem start-lamp.sh, de xuat muc F2) - KHONG can may chu ngoai nao.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * B6 (HANDOFF.md muc 1az) - "viec nang chi khi dang sac". Ung dung Android ghi co
 * lamp-run/defer-heavy-jobs (va LAM MOI mtime moi ~15 phut) khi nguoi dung bat tuy chon
 * "Viec nang chi khi sac" VA may khong cam nguon. Co CU hon 2 gio (app chet/khong cap
 * nhat duoc) bi coi la HET HIEU LUC -> viec nang tu chay lai thay vi bi hoan vo han
 * ("fail-open"). Khong co APP_HOME (khong chay trong app) -> khong hoan gi.
 */
function wppocket_heavy_jobs_deferred() {
    $home = getenv('APP_HOME');
    if (!$home) {
        return false;
    }
    $m = @filemtime(rtrim($home, '/') . '/lamp-run/defer-heavy-jobs');
    return $m !== false && (time() - $m) < 2 * HOUR_IN_SECONDS;
}

// Tu dong cap nhat (loi/plugin/theme/ban dich) cung la viec nang (tai ve + giai nen + chep
// de len nhieu file, kem chup nhanh loi ben duoi). Tra false -> WordPress bo qua LUOT NAY va
// tu thu lai o lan kiem tra ke tiep (2 lan/ngay) - khi may da cam sac se chay binh thuong.
// Cac filter auto_update_{core,plugin,theme,translation} la API chinh thuc tu WP 3.7; gia tri
// tra ve ghi de ca cong tac trong wp-admin (da tra cuu - xem HANDOFF.md muc 1az).
foreach (['auto_update_core', 'auto_update_plugin', 'auto_update_theme', 'auto_update_translation'] as $wppocket_filter) {
    add_filter($wppocket_filter, function ($update) {
        return wppocket_heavy_jobs_deferred() ? false : $update;
    }, 99);
}

add_filter('cron_schedules', function ($schedules) {
    // WordPress mac dinh chi co hourly/twicedaily/daily - can them "weekly"
    // cho tac vu nay (khong can chay thuong xuyen hon, du an nay VON DA
    // giai thich trong HANDOFF.md ve nguyen tac "dot vao golden time, tranh
    // lam viec khi khong can thiet" cho pin/CPU dien thoai).
    if (!isset($schedules['wppocket_weekly'])) {
        $schedules['wppocket_weekly'] = [
            'interval' => 7 * DAY_IN_SECONDS,
            'display'  => 'Moi tuan (WP Pocket Server bao tri)',
        ];
    }
    return $schedules;
});

add_action('init', function () {
    if (!wp_next_scheduled('wppocket_db_maintenance')) {
        wp_schedule_event(time(), 'wppocket_weekly', 'wppocket_db_maintenance');
    }
});

add_action('wppocket_db_maintenance', function () {
    global $wpdb;

    // B6: dang hoan viec nang (may khong sac, nguoi dung da bat tuy chon) -> khong lam gi
    // luc nay, hen thu lai sau 1 gio. WP-Cron da tu dat lich cho LAN SAU (7 ngay) TRUOC khi
    // goi handler nay, nen su kien don le nay chi thay cho lan chay tuan nay - khong chong chat.
    if (wppocket_heavy_jobs_deferred()) {
        wp_schedule_single_event(time() + HOUR_IN_SECONDS, 'wppocket_db_maintenance');
        return;
    }

    // --- 1) Xoa post revision cu hon 60 ngay ---
    // Dung wp_delete_post_revision() (API chinh thuc cua core) thay vi tu
    // viet cau DELETE thang vao wp_posts - ham nay tu don dep CA postmeta
    // lien quan + goi dung cac hook "delete_post"/"deleted_post" ma cac
    // plugin khac co the dang lang nghe, an toan hon nhieu so voi xoa tay.
    // Gioi han 200 ban ghi/lan chay (~1 tuan/lan) - du an nay dat
    // max_execution_time=60s trong php.ini (xem php.ini.template), can
    // tran an toan de khong bao gio cham nguong do tren 1 site ca nhan
    // binh thuong; se tu don not dan qua nhieu tuan neu co "no" backlog.
    $oldRevisionIds = $wpdb->get_col($wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts}
         WHERE post_type = 'revision'
           AND post_modified_gmt < %s
         ORDER BY post_modified_gmt ASC
         LIMIT 200",
        gmdate('Y-m-d H:i:s', time() - 60 * DAY_IN_SECONDS)
    ));
    foreach ($oldRevisionIds as $id) {
        wp_delete_post_revision((int) $id);
    }

    // --- 2) OPTIMIZE TABLE cho moi bang cua site (dung prefix that, KHONG
    // gia dinh "wp_" cung cung - table_prefix nguoi dung co the da doi) ---
    // CHI chay khi dang dung MariaDB THAT (che do Full) - "OPTIMIZE TABLE"
    // la cu phap RIENG cua MySQL/MariaDB, KHONG ton tai trong SQLite. Neu
    // Dual-Mode dang o che do Lite (xem HANDOFF.md muc 1e), wp-config-
    // sqlite.php.template dinh nghia hang so DB_ENGINE=sqlite - kiem tra
    // hang so nay TRUOC de tranh goi cau lenh sai cu phap vao SQLite (plugin
    // SQLite Database Integration dich lai query MySQL->SQLite nhung KHONG
    // chac chan xu ly duoc cau lenh quan tri rieng cua MySQL nay - chua
    // kiem chung, an toan hon la bo qua han o che do Lite). Phan xoa
    // revision o tren (1) van chay binh thuong o CA 2 che do vi
    // wp_delete_post_revision() la ham cua core, khong phu thuoc DB engine.
    if (!defined('DB_ENGINE') || DB_ENGINE !== 'sqlite') {
        $tables = $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($wpdb->prefix) . '%'));
        foreach (array_slice($tables, 0, 50) as $table) {
            $wpdb->query('OPTIMIZE TABLE `' . esc_sql($table) . '`');
        }
    }
});

// --- De xuat DeepSeek muc P3 (xem HANDOFF.md muc 10 + muc 1at) - chup
// nhanh wp-admin/ + wp-includes/ + file PHP cap goc NGAY TRUOC khi
// WordPress tu dong cap nhat core (WP_AUTO_UPDATE_CORE='minor' - xem
// wp-config.php.template), de co duong lui neu ban moi gay loi. Hook
// "pre_auto_update" la hook CHINH THUC cua core (tra cuu that qua
// wp-admin/includes/class-wp-automatic-updater.php, khong doan) - bat luc
// WordPress DA QUYET DINH se cap nhat (ngay truoc khi thuc su tai ve/ghi
// de). Dung ham PHP thuan tu viet (KHONG dung $wp_filesystem cua core) vi
// $wp_filesystem co the CHUA duoc khoi tao dung luc hook nay chay trong
// ngu canh auto-update (chay qua WP-Cron, khong phai qua man hinh
// wp-admin), tranh phu thuoc 1 thanh phan chua chac san sang.
function wppocket_rrmdir($dir)
{
    if (!is_dir($dir)) {
        return;
    }
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            wppocket_rrmdir($path);
        } else {
            @unlink($path);
        }
    }
    @rmdir($dir);
}

function wppocket_copy_dir($src, $dst)
{
    if (!is_dir($src)) {
        return;
    }
    if (!is_dir($dst)) {
        mkdir($dst, 0755, true);
    }
    $items = scandir($src);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $s = $src . '/' . $item;
        $d = $dst . '/' . $item;
        if (is_dir($s)) {
            wppocket_copy_dir($s, $d);
        } else {
            copy($s, $d);
        }
    }
}

add_action('pre_auto_update', function ($type, $item, $context) {
    if ($type !== 'core') {
        return;
    }
    global $wp_version;

    $backupDir = WP_CONTENT_DIR . '/wppocket-core-rollback';
    // CHI giu 1 ban GAN NHAT (khong phai nhieu ban) - don gian hoa, tranh
    // ton dung luong cho 1 tinh nang chi dung khi THAT SU can (ban cap
    // nhat gan nhat gay loi) - xem HANDOFF.md muc 10, F1/F7 ve tinh than
    // "dung luong dien thoai co han" xuyen suot du an.
    wppocket_rrmdir($backupDir);
    mkdir($backupDir, 0755, true);

    file_put_contents(
        $backupDir . '/version-before-update.txt',
        $wp_version . "\n" . gmdate('Y-m-d H:i:s') . " UTC\n"
    );

    wppocket_copy_dir(ABSPATH . 'wp-admin', $backupDir . '/wp-admin');
    wppocket_copy_dir(ABSPATH . 'wp-includes', $backupDir . '/wp-includes');
    foreach (glob(ABSPATH . '*.php') ?: [] as $f) {
        $name = basename($f);
        // KHONG BAO GIO chep wp-config.php vao day - file do chua mat
        // khau DB that + salt, va la cau hinh RIENG cua may nay, khong
        // phai 1 phan "core" can rollback.
        if ($name === 'wp-config.php') {
            continue;
        }
        copy($f, $backupDir . '/root-' . $name);
    }
}, 10, 3);
PHP

      echo "== Cai object-cache.php (de xuat DeepSeek muc I4, xem HANDOFF.md"
      echo "   muc 10 + muc 1as) - de APCu THAT SU duoc WordPress dung,"
      echo "   khong chi 'bat extension suong' nhu vong truoc =="
      # wp-content/object-cache.php la ten DAC BIET WordPress tu nhan dien
      # (drop-in chinh thuc, nap TRUOC moi plugin) - CHEP file co san (da
      # test rieng that bang APCu that + mo phong dung cach WordPress core
      # goi, xem HANDOFF.md muc 1as), KHONG viet lai bang heredoc nhu mu-
      # plugin o tren, tranh trung lap noi dung dai o 2 noi.
      cp scripts/runtimes/templates/object-cache.php "$staging/wp-content/object-cache.php"

      echo "== Cai mu-plugin xoa page cache khi noi dung doi (HANDOFF.md muc 1bg) =="
      # 2 file CO CHU DICH: file nap cuc ngan o thu muc mu-plugins (WordPress chi nap file .php o TOP-LEVEL), logic nam o thu muc con va
      # duoc nap qua try/catch Throwable - loi o logic khong lam hong website. Test: scripts/tests/pagecache-purge-test.py.
      mkdir -p "$staging/wp-content/mu-plugins/wppocket-pagecache"
      cp scripts/runtimes/templates/wppocket-pagecache-loader.php "$staging/wp-content/mu-plugins/wppocket-pagecache.php"
      cp scripts/runtimes/templates/wppocket-pagecache-purge.php "$staging/wp-content/mu-plugins/wppocket-pagecache/purge.php"

      echo "== Cai mu-plugin toi uu anh khi tai len (HANDOFF.md muc 1bq-I) =="
      # Cung kieu 2 file voi pagecache: loader cuc ngan + logic nap qua try/catch Throwable. Mac dinh an toan (KHONG xoa anh goc); xem docs/IMAGE_OPTIMIZATION.md.
      mkdir -p "$staging/wp-content/mu-plugins/wppocket-images"
      cp scripts/runtimes/templates/wppocket-images-loader.php "$staging/wp-content/mu-plugins/wppocket-images.php"
      cp scripts/runtimes/templates/wppocket-images-optimize.php "$staging/wp-content/mu-plugins/wppocket-images/optimize.php"

      echo "== Cai mu-plugin Shield: chong do tai khoan/mat khau, ghi su kien nhay cam (HANDOFF.md muc 1br) =="
      # Cung kieu 2 file (loader cuc ngan + logic nap qua try/catch). start-lamp.sh con dong bo lai 2 file nay moi lan khoi dong (site cu/cap nhat ung dung).
      # Test: scripts/tests/shield-test.py. Tat khan cap: tao file lamp-run/shield-off.
      mkdir -p "$staging/wp-content/mu-plugins/wppocket-shield"
      cp scripts/runtimes/templates/wppocket-shield-loader.php "$staging/wp-content/mu-plugins/wppocket-shield.php"
      cp scripts/runtimes/templates/wppocket-shield-logic.php "$staging/wp-content/mu-plugins/wppocket-shield/shield.php"

      echo "== Cai mu-plugin dang nhap hai buoc (TOTP) - TUY CHON tung nguoi dung, mac dinh khong ai bi ep (HANDOFF.md muc 1br-H) =="
      # Cung kieu 2 file. Chua ai bat thi dang nhap nhu cu. Test tren WordPress that: scripts/tests/wp-2fa-test.py. Tat khan cap: tao file lamp-run/twofa-off.
      mkdir -p "$staging/wp-content/mu-plugins/wppocket-2fa"
      cp scripts/runtimes/templates/wppocket-2fa-loader.php "$staging/wp-content/mu-plugins/wppocket-2fa.php"
      cp scripts/runtimes/templates/wppocket-2fa-logic.php "$staging/wp-content/mu-plugins/wppocket-2fa/2fa.php"
      ;;

    git)
      local repo branch
      repo="$(jq -r '.site_source.repo' "$SITE_CONFIG")"
      branch="$(jq -r '.site_source.branch // "main"' "$SITE_CONFIG")"
      echo "== Nguon website: git clone $repo ($branch) =="
      if [[ -z "$repo" || "$repo" == "null" ]]; then
        echo "LOI: site_source.type=git nhung thieu site_source.repo trong site.config.json" >&2
        exit 1
      fi
      git clone --depth 1 --branch "$branch" "$repo" "$staging"
      rm -rf "$staging/.git"
      ;;

    local)
      local path
      path="$(jq -r '.site_source.path // "site"' "$SITE_CONFIG")"
      echo "== Nguon website: thu muc local '$path' (commit san trong repo) =="
      if [[ ! -d "$path" ]]; then
        echo "LOI: khong thay thu muc '$path' - hay commit code website vao dung duong dan nay" >&2
        exit 1
      fi
      cp -r "$path"/. "$staging"/
      ;;

    zip)
      local url
      url="$(jq -r '.site_source.url' "$SITE_CONFIG")"
      echo "== Nguon website: tai zip tu $url =="
      if [[ -z "$url" || "$url" == "null" ]]; then
        echo "LOI: site_source.type=zip nhung thieu site_source.url" >&2
        exit 1
      fi
      curl -fsSL -o /tmp/site-source.zip "$url"
      # TUY CHON (HANDOFF.md muc 1bc): site_source.sha256 = SHA-256 cua file zip -> sai thi DUNG build. Khong khai bao thi
      # chi GHI hash vao bao cao (UNVERIFIED neu VERIFY_STRICT=1 se dung build).
      local zip_sha
      zip_sha="$(jq -r '.site_source.sha256 // empty' "$SITE_CONFIG")"
      verify_file "site-source.zip" /tmp/site-source.zip sha256 "$zip_sha" "site.config.json:site_source.sha256"
      unzip -q /tmp/site-source.zip -d "$staging"
      ;;

    *)
      echo "LOI: site_source.type='$type' khong duoc ho tro (xem site.config.json)" >&2
      exit 1
      ;;
  esac
}
