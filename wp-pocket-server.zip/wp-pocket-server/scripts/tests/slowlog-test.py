#!/usr/bin/env python3
"""Kiem thu SLOW QUERY LOG cua MariaDB (HANDOFF.md muc 1be) qua DUNG dong lenh khoi dong cua du an.

Khac fullstack-realwp-test.py (tu goi mariadbd voi co rieng): test nay render wake-mariadb.sh.template BANG DANH SACH sed THAT cua
start-lamp.sh (lamp_render.py) roi chay mariadbd THAT qua chinh script do - nen sai ten co/loi cu phap trong template la test do ngay
(MariaDB khong khoi dong duoc = loi nang nhat), khong phai doi nguoi dung gap tren dien thoai.
Phan 1 (tinh) chay duoc moi noi; phan 2 can mariadbd + mariadb-install-db + client (mariadb|mysql), thieu thi bo qua (exit 0).
"""
import getpass, os, re, shutil, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lamp_render as lr
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:300]) if d else ''))
def which(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p
def main():
    tpl = open(os.path.join(lr.TPLDIR, 'wake-mariadb.sh.template'), encoding='utf-8').read()
    tmp = tempfile.mkdtemp(prefix='slowlog-'); os.chmod(tmp, 0o755)
    run, data, binp, sock, mtmp = (os.path.join(tmp, d) for d in ('run', 'data', 'bin', 'run/mysql.sock', 'tmp'))
    for d in (run, data, binp, mtmp): os.makedirs(d, exist_ok=True)
    mariadbd = which('mariadbd', 'mysqld'); install = which('mariadb-install-db', 'mysql_install_db'); cli = which('mariadb', 'mysql')
    db = None
    try:
        print('== 1. Render + cu phap (khong can MariaDB) ==')
        vals = dict(BIN=binp, DATA=data, MYSQL_SOCK=sock, RUNDIR=run, MARIADB_BASEDIR='/usr')
        try: script = lr.render(tpl, 'wake-mariadb.sh.template', vals)
        except Exception as e: check('render wake-mariadb.sh.template bang danh sach sed THAT cua start-lamp.sh (khong con placeholder)', False, e); return 1
        check('render wake-mariadb.sh.template bang danh sach sed THAT cua start-lamp.sh (khong con placeholder)', True)
        for flag in ('--slow-query-log=1', '--slow-query-log-file="%s/mysql-slow.log"' % run, '--long-query-time=2'):
            check('script render co co %s' % flag.split('=')[0], flag in script, flag)
        open(os.path.join(tmp, 'wake.sh'), 'w').write(script)
        sh = subprocess.run(['sh', '-n', os.path.join(tmp, 'wake.sh')], capture_output=True, text=True)
        check('wake-mariadb.sh render qua `sh -n`', sh.returncode == 0, sh.stderr)
        sl = open(os.path.join(lr.TPLDIR, 'start-lamp.sh'), encoding='utf-8').read()
        check('start-lamp.sh cat mysql-slow.log khi > 5MB (nam trong danh sach log xoay vong)', re.search(r'for\s+\w+\s+in\b[^;]*"\$RUNDIR/mysql-slow\.log"[^;]*;\s*do', sl) is not None)
        pl = open(os.path.join(lr.TPLDIR, 'admin-logs.php'), encoding='utf-8').read()
        check("_admin/logs.php co log 'mariadb-cham' tro dung mysql-slow.log", "'mariadb-cham'" in pl and "/mysql-slow.log'" in pl)
        kt = open(os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java', 'com', 'wppocket', 'server', 'LogViewerActivity.kt'), encoding='utf-8').read()
        check('LogViewerActivity (app) co log lamp-run/mysql-slow.log', '"lamp-run/mysql-slow.log"' in kt)

        print('== 2. MariaDB THAT qua script do ==')
        if not (mariadbd and install and cli):
            print('(bo qua phan 2: thieu mariadbd / mariadb-install-db / client)'); return 0 if FAIL == 0 else 1
        osuser = 'root' if os.geteuid() == 0 else getpass.getuser()
        os.symlink(os.path.realpath(mariadbd), os.path.join(binp, 'libmariadbd.so'))
        r = subprocess.run([install, '--user=' + osuser, '--datadir=' + os.path.join(data, 'mysql-data'), '--auth-root-authentication-method=normal'], capture_output=True, text=True)
        if r.returncode != 0:
            print('(bo qua phan 2: khong khoi tao duoc MariaDB: %s)' % r.stderr[-120:]); return 0 if FAIL == 0 else 1
        # CHI khi chay bang root (runner CI/sandbox): mariadbd tu choi chay root neu khong co --user. May Android that khong chay root.
        if os.geteuid() == 0:
            script = script.replace('--skip-networking', '--skip-networking --user=root', 1)
            open(os.path.join(tmp, 'wake.sh'), 'w').write(script)
        env = dict(os.environ, TMPDIR=mtmp)
        db = subprocess.Popen(['sh', os.path.join(tmp, 'wake.sh')], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        up = False
        for _ in range(120):
            if os.path.exists(sock) and subprocess.run([cli, '--socket=' + sock, '-uroot', '-e', 'select 1'], capture_output=True).returncode == 0: up = True; break
            if db.poll() is not None: break
            time.sleep(0.5)
        errlog = open(os.path.join(run, 'mysqld.log'), errors='replace').read()[-600:] if os.path.exists(os.path.join(run, 'mysqld.log')) else ''
        check('MariaDB KHOI DONG DUOC qua wake-mariadb.sh da render (co slow log khong lam DB chet)', up, errlog)
        if not up: return 1
        def sql(q): return subprocess.run([cli, '--socket=' + sock, '-uroot', '-N', '-B', '-e', q], capture_output=True, text=True).stdout.strip()
        check('slow_query_log = ON', sql("SELECT @@slow_query_log") == '1', sql("SELECT @@slow_query_log"))
        check('long_query_time = 2', float(sql("SELECT @@long_query_time") or 0) == 2.0, sql("SELECT @@long_query_time"))
        slow = os.path.join(run, 'mysql-slow.log')
        check('slow_query_log_file tro vao RUNDIR/mysql-slow.log', sql("SELECT @@slow_query_log_file") == slow, sql("SELECT @@slow_query_log_file"))
        sql("SELECT 'WPP_FAST_QUERY_MARK'")                       # doi chung am: truy van nhanh KHONG duoc ghi
        sql("SELECT 'WPP_SLOW_QUERY_MARK', SLEEP(2.3)")           # > 2 giay -> phai ghi
        txt = ''
        for _ in range(20):
            txt = open(slow, errors='replace').read() if os.path.exists(slow) else ''
            if 'WPP_SLOW_QUERY_MARK' in txt: break
            time.sleep(0.5)
        check('truy van > 2 giay DUOC ghi vao mysql-slow.log', 'WPP_SLOW_QUERY_MARK' in txt, txt[-200:])
        check('truy van nhanh KHONG bi ghi (nguong long_query_time co tac dung)', 'WPP_FAST_QUERY_MARK' not in txt)
        sql('SHUTDOWN')
    finally:
        if db is not None:
            try: db.wait(timeout=15)
            except Exception: db.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
