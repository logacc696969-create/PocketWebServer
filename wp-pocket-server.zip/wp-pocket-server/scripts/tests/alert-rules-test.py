#!/usr/bin/env python3
"""H5 + AE5 (PDF 2; HANDOFF.md muc 1bq-B): kiem chung nguong canh bao chinh duoc + bo quy tac canh bao.

1. Ban Java SAT NGUYEN BAN (scripts/tests/java/AlertRulesPort.java) chay tren JDK that: cu phap, moi ma loi, danh gia (for/cooldown/dong ho lui/gia tri hong), nguong.
2. Doi chieu van ban Kotlin <-> Java (hang so, bang chi so, regex) de hai ban khong lech.
3. Noi day (tinh): Monitoring/MainActivity/BackupWorker/BackupVerifier dung nguong nguoi dung, khong con goi isHot/isWarm kieu cu, tin nhan khong con so 40/45 cung.
4. Tai nguyen: moi ma loi co chuoi vi+en; nut + listener; tai lieu.
Khong co JDK day du -> bo qua phan 1 (thoat 0, in ly do); CI co JDK.
"""
import os, re, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
K = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/")
RES = os.path.join(ROOT, "app/src/main/res/")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, extra)


def rd(p):
    return open(p, encoding="utf-8").read()


ar, at = rd(K + "AlertRules.kt"), rd(K + "AlertThresholds.kt")
jv = rd(os.path.join(ROOT, "scripts/tests/java/AlertRulesPort.java"))
ml, mon, ma = rd(K + "MonitorLogic.kt"), rd(K + "Monitoring.kt"), rd(K + "MainActivity.kt")
bw, bv, prefs = rd(K + "BackupWorker.kt"), rd(K + "BackupVerifier.kt"), rd(K + "Prefs.kt")

# ---------------------------------------------------------------- 1. Java tren JDK that
try:
    mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception:
    mods = ""
if "jdk.compiler" in mods:
    r = subprocess.run(["java", os.path.join(ROOT, "scripts/tests/java/AlertRulesPort.java")], capture_output=True, text=True, timeout=300)
    m = re.search(r"pass=(\d+) fail=(\d+)", r.stdout)
    check("AlertRulesPort tren JDK that: %s kiem tra, 0 loi (cu phap, ma loi, danh gia for/cooldown, trang thai, nguong)" % (m.group(1) if m else "?"),
          r.returncode == 0 and m is not None and m.group(2) == "0" and int(m.group(1)) >= 40, r.stdout[-500:] + r.stderr[-300:])
else:
    print("(bo qua chay Java: can JDK day du)")

# ---------------------------------------------------------------- 2. Kotlin <-> Java
def kt_consts(src):
    return {n: int(v) for n, v in re.findall(r"const val ([A-Z_]+)\s*(?::\s*Int)?\s*=\s*(-?\d+)", src)}

def java_consts(src):
    out = {}
    for decl in re.findall(r"static final int ([^;]+);", src):
        for part in decl.split(","):
            mm = re.match(r"\s*([A-Z_]+)\s*=\s*(-?\d+)\s*$", part)
            if mm:
                out[mm.group(1)] = int(mm.group(2))
    return out

kc, jc = {**kt_consts(ar), **kt_consts(at)}, java_consts(jv)
check("hang so so nguyen giong het giua Kotlin va Java (%d hang so)" % len(kc), len(kc) >= 18 and kc == {k: jc.get(k) for k in kc}, str({k: (kc[k], jc.get(k)) for k in kc if kc[k] != jc.get(k)}))

def metrics_kt(src):
    return re.findall(r'([A-Z_0-9]+)\("([a-z_0-9]+)",\s*(-?[\d.]+),\s*(-?[\d.]+)\)', src)

mk = metrics_kt(ar)
mj = metrics_kt(jv)
check("bang 6 chi so (ten, khoang) giong het giua Kotlin va Java", len(mk) == 6 and mk == mj, "%s vs %s" % (mk, mj))
for name in ("NAME_RE", "LINE_RE", "NUMBER_RE", "DUR_RE"):
    km = re.search(r"val %s = Regex\(\"((?:[^\"\\]|\\.)*)\"\)" % name, ar)
    jm = re.search(r"%s = Pattern\.compile\(\"((?:[^\"\\]|\\.)*)\"\)" % name, jv)
    check("regex %s giong het giua Kotlin va Java" % name, km is not None and jm is not None and km.group(1) == jm.group(1))
check("AlertRules.kt / AlertThresholds.kt thuan: khong import android.* (kiem duoc tren JVM)", re.search(r"^import android", ar, re.M) is None and re.search(r"^import android", at, re.M) is None)

# mac dinh trong MonitorLogic khop nguon duy nhat AlertThresholds
cm = kt_consts(ml)
check("MonitorLogic.TEMP_WARM_TENTHS / TEMP_HOT_TENTHS / BATTERY_CRITICAL_PCT khop mac dinh cua AlertThresholds (khong lech 2 nguon)",
      cm.get("TEMP_WARM_TENTHS") == kc["WARM_DEFAULT"] * 10 and cm.get("TEMP_HOT_TENTHS") == kc["HOT_DEFAULT"] * 10 and cm.get("BATTERY_CRITICAL_PCT") == kc["BATT_CRIT_DEFAULT"])
check("mac dinh dia 85 giu nguyen (khop FAILURE_MODES.md qua docs-consistency-test)", kc["DISK_DEFAULT"] == 85)

# ---------------------------------------------------------------- 3. noi day
check("Monitoring: khong con hang so DISK_ALERT_PCT cung (doc nguong qua thresholds(context))", "DISK_ALERT_PCT" not in mon and "thresholds(context).diskPct" in mon)
check("Monitoring.thresholds kep gia tri qua AlertThresholds.sanitize (gia tri hong trong prefs khong lam hong canh bao)", re.search(r"fun thresholds\(context: Context\)[\s\S]{0,400}AlertThresholds\.sanitize\(", mon) is not None)
check("runPeriodic goi checkAlertRules (trong try rieng, loi khong chan viec khac)", re.search(r"try \{ checkAlertRules\(context\) \} catch", mon) is not None)
check("checkEnvironment truyen nguong nguoi dung vao envIssues va envMessage", "MonitorLogic.envIssues(snap, th)" in mon and "envMessage(issue, snap, th)" in mon)
single_ishot = re.compile(r"\bis(?:Hot|Warm)\(\s*[^,()]*(?:\([^()]*\))?\s*\)")
check("khong con goi isHot/isWarm kieu 1 doi so o Monitoring/BackupWorker/BackupVerifier/MainActivity (tru dinh nghia mac dinh trong MonitorLogic)",
      not any(single_ishot.search(t) for t in (mon, bw, bv, ma)), [m.group(0) for t in (mon, bw, bv, ma) for m in single_ishot.finditer(t)][:3])
msgs = re.findall(r'EnvIssue\.DEVICE_(?:WARM|HOT) ->[\s\S]{0,700}?(?=\n    \}|\n        MonitorLogic\.EnvIssue\.)', mon)
check("tin nhan nong/am dung ${th.warmC}/${th.hotC}, khong con '>= 40'/'>= 45'/'Qua 45' cung", len(msgs) >= 1 and all(">= 40" not in t and ">= 45" not in t and "Qua 45" not in t for t in msgs) and "${th.warmC}" in mon and "${th.hotC}" in mon)
check("BackupVerifier/BackupWorker/MainActivity doc nguong qua Monitoring.thresholds", "Monitoring.thresholds(" in bv and "Monitoring.thresholds(" in bw and ma.count("Monitoring.thresholds(") >= 3)
check("BackupVerifier khong con ghi cung 'nong >= 45'", ">= 45" not in bv)
cr = re.search(r"fun checkAlertRules[\s\S]*?\n    \}\n", mon).group(0)
check("checkAlertRules: chi markAlerted KHI notifyTelegram thanh cong", re.search(r"if \(notifyTelegram\([^\n]*\)\) \{\s*next = AlertRules\.markAlerted\(next, now\)", cr) is not None)
check("checkAlertRules: don trang thai quy tac da xoa/doi ten + chi so null khong bao gio gay canh bao", "stale" in cr and "ev.fire && value != null" in cr)
check("doc 6 chi so: moi Metric deu duoc readRuleMetrics gan", all(("AlertRules.Metric.%s" % n) in mon for n, *_ in mk))
check("ram_percent/load_avg_1m doc qua ham thuan co kiem thu (ramPercent/parseLoadAvg), loi -> null", "AlertRules.ramPercent(" in mon and "AlertRules.parseLoadAvg(" in mon and mon.count("} catch (e: Exception) { null }") >= 3)
keys = dict(re.findall(r'const val (KEY_[A-Z_0-9]+) = "([a-z_0-9]+)"', prefs))
want_keys = ["KEY_ALERT_DISK_PCT", "KEY_ALERT_BATT_CRIT_PCT", "KEY_ALERT_WARM_C", "KEY_ALERT_HOT_C", "KEY_ALERT_RULES", "KEY_ALERT_RULE_STATE_PREFIX"]
check("Prefs: 6 khoa nguong/quy tac co mat va GIA TRI khong trung khoa nao khac trong Prefs.kt", all(k in keys for k in want_keys) and len(set(keys.values())) == len(keys), "trung: %s" % [v for v in set(keys.values()) if list(keys.values()).count(v) > 1])
check("hop thoai LUU chi khi tat ca hop le: parseField x4 + hot > warm + AlertRules.parse truoc prefs.edit", re.search(r"parseField[\s\S]*parseField[\s\S]*parseField[\s\S]*parseField[\s\S]*hot!! <= warm!![\s\S]*AlertRules\.parse\([\s\S]*prefs\.edit\(\)", ma) is not None)
check("hop thoai khong dong khi nhap sai (nut gan lai trong setOnShowListener)", "setOnShowListener" in ma and ma.count("return@setOnClickListener") >= 3)

# ---------------------------------------------------------------- 4. tai nguyen + tai lieu
vi, en = rd(RES + "values/strings.xml"), rd(RES + "values-en/strings.xml")
codes = re.findall(r"^\s*([A-Z_]+),?\s*$|ErrorCode \{([^}]*)\}", ar, re.M)
enum_body = re.search(r"enum class ErrorCode \{([^}]*)\}", ar).group(1)
names = re.findall(r"[A-Z_]{3,}", enum_body)
check("ErrorCode co 12 ma", len(names) == 12, str(names))
missing = [n for n in names if ('name="alert_err_%s"' % n.lower()) not in vi or ('name="alert_err_%s"' % n.lower()) not in en or ("AlertRules.ErrorCode.%s ->" % n) not in ma]
check("moi ma loi co chuoi vi+en va nhanh trong ruleErrorText", not missing, str(missing))
for nm in ("btn_alert_settings", "alert_dialog_title", "alert_rules_help", "alert_field_disk", "alert_field_batt", "alert_field_warm", "alert_field_hot", "alert_rules_label", "alert_rules_hint", "alert_saved", "btn_save", "btn_reset_defaults", "alert_err_field", "alert_err_hot_le_warm", "alert_err_rule_line"):
    check("chuoi '%s' co o CA vi va en" % nm, ('name="%s"' % nm) in vi and ('name="%s"' % nm) in en)
lay = rd(RES + "layout/activity_main.xml")
check("nut btnAlertSettings co trong layout va listener goi showAlertSettings", 'android:id="@+id/btnAlertSettings"' in lay and "btnAlertSettings.setOnClickListener { showAlertSettings() }" in ma)
doc = rd(os.path.join(ROOT, "docs/ALERT_RULES.md"))
check("docs/ALERT_RULES.md liet ke du 6 chi so va 4 nguong va tu khoa for/cooldown", all(("`%s`" % key) in doc for _, key, *_ in mk) and "cooldown" in doc and "Pin quá nóng" in doc)
check("docs/ALERT_RULES.md ghi dung gioi han tu ma (20 quy tac, 15m..7d, 4000 ky tu)", "20" in doc and "15m đến 7d" in doc and "4000" in doc and kc["MAX_RULES"] == 20 and kc["MIN_COOLDOWN_MIN"] == 15 and kc["MAX_COOLDOWN_MIN"] == 10080 and kc["MAX_TEXT_CHARS"] == 4000)
check("docs/ALERT_RULES.md: bang nguong ghi dung mac dinh va khoang cua ma", all(s in doc for s in ("| 85 | 50–99 |", "| 5 | 1–30 |", "| 40 | 30–55 |", "| 45 | 35–65 |")))

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
