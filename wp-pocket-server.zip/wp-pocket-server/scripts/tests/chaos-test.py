#!/usr/bin/env python3
"""AA2 (PDF 2; HANDOFF.md muc 1bq-E): KIEM THU HON LOAN cho bo giam sat start-generic.sh - chay duoc o moi noi co sh va /proc.

Khong chen loi vao mot ban sao: chay DUNG script that (scripts/runtimes/templates/start-generic.sh) nhieu vong voi tien trinh gia, moi vong
mot su co NGAU NHIEN (co seed -> tai lap duoc): giet cung app / nginx / chinh bo giam sat, SIGTERM, dong bang app (SIGSTOP), tep pid hong hoac
tro toi tien trinh KHONG lien quan, app chet ngay khi khoi dong (crash loop), day o dia luc khoi dong (ulimit -f). Sau moi vong va o cuoi kiem
CAC BAT BIEN: khong bao gio de lai tien trinh mo coi sau lan khoi dong tiep theo, khong giet nham tien trinh khong lien quan, thoat dung ma,
khong treo, so tien trinh khong tich luy.

    CHAOS_SEED=123 CHAOS_ROUNDS=60 python3 scripts/tests/chaos-test.py     # tuy chinh (mac dinh seed 20261026, 28 vong)

KHONG kiem duoc o day (can dien thoai + MariaDB + Kotlin): rut mang giua luc upload backup, tat app giua luc restore, day dia giua luc mysqldump,
giet MariaDB giua luc ghi -> xem scripts/chaos/chaos-device.sh va docs/CHAOS_TESTING.md.
"""
import os, random, shutil, signal, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, "..", "runtimes", "templates"))
SEED = int(os.environ.get("CHAOS_SEED", "20261026"))
ROUNDS = int(os.environ.get("CHAOS_ROUNDS", "28"))
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def alive(pid):
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        with open("/proc/%d/stat" % pid) as f:
            return f.read().rsplit(")", 1)[1].split()[0] not in ("Z", "X")
    except OSError:
        return False


def cmdline(pid):
    try:
        with open("/proc/%d/cmdline" % pid, "rb") as f:
            return f.read().replace(b"\0", b" ").decode("utf-8", "replace")
    except OSError:
        return ""


def live_fakes(root):
    """Moi tien trinh con song cua bai kiem nay (cmdline chua duong dan thu muc thu + libapp.so/libnginx.so)."""
    out = []
    for p in os.listdir("/proc"):
        if p.isdigit() and alive(int(p)):
            c = cmdline(int(p))
            if root in c and ("libapp.so" in c or "libnginx.so" in c):
                out.append(int(p))
    return out


def wait_until(fn, timeout=6.0):
    end = time.time() + timeout
    while time.time() < end:
        if fn():
            return True
        time.sleep(0.03)
    return False


tmp = tempfile.mkdtemp(prefix="chaos-")
d = os.path.join(tmp, "s")
www, home, binp = os.path.join(d, "www"), os.path.join(d, "home"), os.path.join(d, "bin")
sup = os.path.join(www, "_supervisor")
for x in (sup, binp, home):
    os.makedirs(x)
shutil.copy(os.path.join(TPL, "start-generic.sh"), sup)
for t in ("nginx-front.conf.template", "front-locations-proxy.conf.template", "front-locations-static.conf.template"):
    shutil.copy(os.path.join(TPL, t), sup)
started = os.path.join(d, "started.log")
open(started, "w").close()
run_dir = os.path.join(home, "generic-run")


def script(name, body):
    p = os.path.join(binp, name)
    with open(p, "w") as f:
        f.write("#!/bin/sh\n" + body)
    os.chmod(p, 0o755)


LOOP = "echo \"%s $$ ${CHAOS_ROUND:-0}\" >> \"" + started + "\"\ntrap 'exit 0' TERM\nwhile :; do sleep 0.2; done\n"
CRASH = "echo \"%s $$ ${CHAOS_ROUND:-0}\" >> \"" + started + "\"\nexit 1\n"


# nginx THAT tu ghi pid file cua no (chi thi "pid RUNDIR/nginx-front.pid;" trong cau hinh) - ban gia phai lam dung viec do, neu khong kill_stale khong the tim thay.
NGINX_LOOP = "mkdir -p \"" + os.path.join(run_dir, "") + "\"; echo $$ > \"" + os.path.join(run_dir, "nginx-front.pid") + "\"\n" + LOOP


def install(app_ok=True):
    script("libapp.so", (LOOP if app_ok else CRASH) % "app")
    script("libnginx.so", NGINX_LOOP % "nginx")


install()
env = {k: v for k, v in os.environ.items() if not k.startswith("GEN_")}
env.update(LD_LIBRARY_PATH=binp, HOME=home, PORT="9000", GEN_MODE="proxy", GEN_APP_BIN="libapp.so", GEN_APP_ARGS="x")


CUR_ROUND = [0]


def start_supervisor(extra_env=None, ulimit_f=None):
    e = dict(env)
    e["CHAOS_ROUND"] = str(CUR_ROUND[0])
    if extra_env:
        e.update(extra_env)
    cmd = ["sh", os.path.join(sup, "start-generic.sh")]
    if ulimit_f is not None:
        cmd = ["sh", "-c", 'trap "" XFSZ; ulimit -f %d; exec sh "%s"' % (ulimit_f, os.path.join(sup, "start-generic.sh"))]
    return subprocess.Popen(cmd, env=e, cwd=www, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def lines():
    # Tolerant: vong 'disk-full-start' chay voi ulimit -f nen dong ghi co the bi cat ngan -> bo dong khong du 3 truong / pid khong phai so.
    out = []
    for l in open(started).read().splitlines():
        t = l.split()
        if len(t) == 3 and t[0] in ("app", "nginx") and t[1].isdigit() and t[2].isdigit():
            out.append(t)
    return out


def wait_started(n_before, n_new=2, timeout=6.0):
    return wait_until(lambda: len(lines()) >= n_before + n_new, timeout)


def wait_exit(p, timeout=8.0):
    try:
        return p.wait(timeout)
    except subprocess.TimeoutExpired:
        return None


bystander = subprocess.Popen(["sleep", "600"], start_new_session=True)
FAULTS = ["kill-app", "kill-nginx", "term-sup", "kill9-sup", "stop-app", "garbage-pidfiles", "crash-loop", "disk-full-start"]
rng = random.Random(SEED)
schedule = FAULTS * 2
schedule += [rng.choice(FAULTS) for _ in range(max(0, ROUNDS - len(schedule)))]
rng.shuffle(schedule)
print("seed=%d, %d vong: %s" % (SEED, len(schedule), ",".join(schedule)))

pending_orphans = []     # pid cua tien trinh con bi bo lai sau khi giet cung bo giam sat
bad = []
for i, fault in enumerate(schedule):
    tag = "vong %d (%s)" % (i + 1, fault)
    CUR_ROUND[0] = i + 1
    n0 = len(lines())
    garbage = None
    if fault == "garbage-pidfiles":
        os.makedirs(run_dir, exist_ok=True)
        garbage = rng.choice(["", "abc", "-1", "0", "1", "12 34", "99999999999", "%d" % bystander.pid, "%d\n%d" % (bystander.pid, bystander.pid), "\x00\x01"])
        for f in ("front-app.pid", "nginx-front.pid"):
            with open(os.path.join(run_dir, f), "w", errors="ignore") as fh:
                fh.write(garbage)
    if fault == "crash-loop":
        install(app_ok=False)
        codes = []
        for _ in range(4):
            p = start_supervisor()
            codes.append(wait_exit(p, 8))
        install(app_ok=True)
        time.sleep(0.3)
        if not all(c == 1 for c in codes):
            bad.append((tag, "ma thoat %s (can 1 moi lan)" % codes))
        leaked = live_fakes(d)
        # sau crash-loop co the con orphan cu tu vong truoc (se duoc don o lan khoi dong ke) - chi kiem khong TICH LUY them
        if len(leaked) > 2 + len(pending_orphans):
            bad.append((tag, "tich luy tien trinh: %s" % leaked))
        continue
    if fault == "disk-full-start":
        p = start_supervisor(ulimit_f=1)
        t0 = time.time()
        rc = wait_exit(p, 10)
        time.sleep(0.3)
        started_new = len(lines()) - n0
        # day o dia ngay luc render cau hinh: phai THOAT KHONG 0 NHANH va KHONG bo lai tien trinh moi.
        if rc is None:
            p.kill()
            bad.append((tag, "bo giam sat TREO khi day o dia"))
        elif rc == 0:
            bad.append((tag, "thoat 0 du khong ghi duoc cau hinh"))
        # Loi that tim thay o seed 1 (truoc khi sua startup_abort trong start-generic.sh): app da chay bi BO MO COI vinh vien khi khoi dong that bai giua chung.
        leaked = wait_until(lambda: not [q for q in live_fakes(d) if q not in pending_orphans], 4.0)
        if not leaked:
            bad.append((tag, "khoi dong that bai (day o dia) de lai tien trinh mo coi: %s" % [q for q in live_fakes(d) if q not in pending_orphans]))
        continue

    p = start_supervisor()
    ok = wait_started(n0)
    if not ok:
        bad.append((tag, "khong khoi dong du 2 tien trinh (started=%s)" % lines()[n0:]))
        p.kill()
        wait_exit(p, 3)
        continue
    new = lines()[n0:]
    app_pid = [int(x[1]) for x in new if x[0] == "app"][-1]
    ngx_pid = [int(x[1]) for x in new if x[0] == "nginx"][-1]
    time.sleep(0.15)
    # bat bien 1: tien trinh mo coi tu vong truoc (supervisor bi giet cung) PHAI bi don o lan khoi dong nay
    if pending_orphans:
        gone = wait_until(lambda: not any(alive(q) for q in pending_orphans), 3.0)
        if not gone:
            bad.append((tag, "tien trinh mo coi chua bi don: %s" % [q for q in pending_orphans if alive(q)]))
        pending_orphans = []
    # bat bien 2: khong giet nham tien trinh khong lien quan, du tep pid tro toi no
    if garbage is not None and not alive(bystander.pid):
        bad.append((tag, "GIET NHAM tien trinh khong lien quan (pid %d) do tep pid tro toi no" % bystander.pid))
        bystander = subprocess.Popen(["sleep", "600"], start_new_session=True)
    # bat bien 3: ngay sau khi len, dung 2 tien trinh cua minh song
    n_live = len(live_fakes(d))
    if n_live != 2:
        bad.append((tag, "sau khi khoi dong co %d tien trinh (can dung 2): %s" % (n_live, live_fakes(d))))

    if fault == "kill-app":
        os.kill(app_pid, signal.SIGKILL)
        rc = wait_exit(p)
        time.sleep(0.3)
        if rc != 1:
            bad.append((tag, "ma thoat %s (can 1 de Kotlin khoi dong lai)" % rc))
        if alive(ngx_pid):
            bad.append((tag, "nginx van song sau khi app chet (mo coi)"))
    elif fault == "kill-nginx":
        os.kill(ngx_pid, signal.SIGKILL)
        rc = wait_exit(p)
        time.sleep(0.3)
        if rc != 1:
            bad.append((tag, "ma thoat %s (can 1)" % rc))
        if alive(app_pid):
            bad.append((tag, "app van song sau khi nginx chet (mo coi)"))
    elif fault == "term-sup":
        p.send_signal(signal.SIGTERM)
        rc = wait_exit(p)
        time.sleep(0.3)
        if rc != 0:
            bad.append((tag, "SIGTERM -> ma thoat %s (can 0)" % rc))
        if alive(app_pid) or alive(ngx_pid):
            bad.append((tag, "con tien trinh mo coi sau SIGTERM"))
    elif fault == "kill9-sup":
        p.send_signal(signal.SIGKILL)
        rc = wait_exit(p, 4)
        time.sleep(0.4)
        if rc != -signal.SIGKILL:
            bad.append((tag, "ma thoat %s" % rc))
        # SIGKILL khong chay trap: 2 tien trinh con SE mo coi - day la nguy co that, lan khoi dong ke phai don
        if alive(app_pid) and alive(ngx_pid):
            pending_orphans = [app_pid, ngx_pid]
        else:
            bad.append((tag, "gia dinh sai: sau SIGKILL bo giam sat con tien trinh con song? app=%s nginx=%s" % (alive(app_pid), alive(ngx_pid))))
    elif fault == "stop-app":
        os.kill(app_pid, signal.SIGSTOP)
        time.sleep(1.0)
        still_up = p.poll() is None
        os.kill(app_pid, signal.SIGCONT)
        time.sleep(0.3)
        if not still_up:
            bad.append((tag, "bo giam sat thoat khi app chi bi DONG BANG (khong chet)"))
        p.send_signal(signal.SIGTERM)
        rc = wait_exit(p)
        time.sleep(0.3)
        if rc != 0 or alive(app_pid) or alive(ngx_pid):
            bad.append((tag, "sau SIGSTOP/SIGCONT roi SIGTERM: rc=%s con song=%s" % (rc, [q for q in (app_pid, ngx_pid) if alive(q)])))
    elif fault == "garbage-pidfiles":
        p.send_signal(signal.SIGTERM)
        rc = wait_exit(p)
        time.sleep(0.3)
        if rc != 0 or alive(app_pid) or alive(ngx_pid):
            bad.append((tag, "tep pid hong %r: SIGTERM rc=%s con song=%s" % (garbage, rc, [q for q in (app_pid, ngx_pid) if alive(q)])))

# ---------------------------------------------------------------- don dep cuoi: 1 lan khoi dong sach + SIGTERM -> khong con gi
n0 = len(lines())
p = start_supervisor()
wait_started(n0)
time.sleep(0.2)
if pending_orphans:
    check("lan khoi dong cuoi don duoc tien trinh mo coi con ton dong", wait_until(lambda: not any(alive(q) for q in pending_orphans), 3.0), pending_orphans)
p.send_signal(signal.SIGTERM)
rc = wait_exit(p)
time.sleep(0.5)
all_pids = {int(x[1]) for x in lines()}

check("%d vong hon loan (seed %d) khong vi pham bat bien nao" % (len(schedule), SEED), not bad, "\n   ".join("%s: %s" % b for b in bad[:8]))
check("lan khoi dong cuoi + SIGTERM: thoat 0", rc == 0, rc)
survivors = [q for q in all_pids if alive(q)]
who = {int(x[1]): "%s do vong %s (%s)" % (x[0], x[2], schedule[int(x[2]) - 1] if 0 < int(x[2]) <= len(schedule) else "cuoi") for x in lines()}
check("SAU TAT CA: moi tien trinh app/nginx tung duoc khoi dong (%d tien trinh) deu da chet - khong ro ri" % len(all_pids), not survivors, [(q, who.get(q), cmdline(q)[-60:]) for q in survivors])
check("tien trinh KHONG lien quan (tep pid tro toi no) van song suot cac vong", alive(bystander.pid))
kinds = {s for s in schedule}
check("lich co du %d loai su co (moi loai >= 2 lan)" % len(FAULTS), kinds == set(FAULTS) and all(schedule.count(f) >= 2 for f in FAULTS), sorted(kinds))
# tai lap duoc: cung seed -> cung lich
rng2 = random.Random(SEED)
s2 = FAULTS * 2
s2 += [rng2.choice(FAULTS) for _ in range(max(0, ROUNDS - len(s2)))]
rng2.shuffle(s2)
check("co seed: cung seed cho CUNG lich su co (tai lap duoc loi neu co)", s2 == schedule)

bystander.kill()
bystander.wait()
shutil.rmtree(tmp, ignore_errors=True)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
