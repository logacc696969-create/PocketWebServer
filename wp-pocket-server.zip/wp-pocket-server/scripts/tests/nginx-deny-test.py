#!/usr/bin/env python3
"""Kiem thu luat chan cua nginx.conf.template (che do Full) bang nginx THAT + php-fpm THAT.
Render day du gabarit that, nen thu tu 'location' (regex khop theo thu tu xuat hien) duoc kiem dung.
Xem HANDOFF.md muc 1aw. Can: nginx, php-fpm (php-fpm8.x), python3. Thieu thi bo qua (exit 0).
"""
import http.client, os, re, shutil, socket, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.environ.get('NGINX_TPL') or os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates', 'nginx.conf.template'))  # NGINX_TPL: doi chung am voi ban cu
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:160]) if d else ''))
def which(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p
def get(port, path):
    c = http.client.HTTPConnection('127.0.0.1', port, timeout=20)
    c.putrequest('GET', path); c.endheaders(); r = c.getresponse(); b = r.read().decode('utf-8', 'replace'); c.close()
    return r.status, b
def wr(root, rel, txt):
    p = os.path.join(root, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(txt)
def main():
    nginx = which('nginx'); fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    if not nginx or not fpm:
        print('(bo qua: thieu nginx hoac php-fpm)'); return 0
    tmp = tempfile.mkdtemp(prefix='nginxtest-'); doc = os.path.join(tmp, 'www'); run = os.path.join(tmp, 'run')
    os.chmod(tmp, 0o755)  # mkdtemp tao 0700: worker nginx chay bang 'nobody' se bi Permission denied
    os.makedirs(run); os.makedirs(os.path.join(tmp, 'stg'))
    wr(doc, 'index.php', '<?php echo "INDEX-OK";\n')
    for rel in ('wp-content/ai1wm-backups/site.wpress', 'wp-content/updraft/backup_db.gz', 'wp-content/backups-dup-lite/x.zip',
                'wp-content/backups-dup-pro/x.zip', 'wp-content/uploads/backupbuddy_backups/x.zip', 'wp-snapshots/x.zip',
                'wp-content/backupwordpress-abc123-backups/x.zip', 'wp-content/uploads/backwpup-9f8e7d-backups/x.zip',
                'wp-content/wpvividbackups/x.zip'):
        wr(doc, rel, 'SECRET-BACKUP')
    wr(doc, 'wp-content/uploads/shell.php', '<?php echo "SECRET-SHELL-EXECUTED";\n')
    wr(doc, 'wp-content/uploads/Sub/X.PHTML', '<?php echo "SECRET-PHTML-EXECUTED";\n')
    wr(doc, 'wp-content/uploads/archive.zip', 'ZIP-OK')
    wr(doc, 'wp-content/uploads/pic.jpg', 'JPG-OK')
    wr(doc, 'wp-content/plugins/updraftplus/readme.txt', 'PLUGIN-README')
    wr(doc, 'wp-content/plugins/updraftplus/notes.txt', 'PLUGIN-NOTES')
    # HANDOFF.md muc 1br: che dau van tay / file ro ri / PHP khong duoc goi truc tiep
    for rel, body in (('readme.html', 'WP-README'), ('license.txt', 'WP-LICENSE'), ('wp-content/debug.log', 'SECRET-DEBUGLOG'),
                      ('wp-content/uploads/dump.sql', 'SECRET-SQL'), ('.env', 'SECRET-ENV'), ('wp-config.php.bak', 'SECRET-BAK'),
                      ('wp-content/themes/t1/CHANGELOG.md', 'THEME-CHANGELOG'), ('wp-content/uploads/data.json', 'JSON-OK'),
                      ('wp-includes/load.php', '<?php echo "SECRET-INCLUDES-EXECUTED";\n'),
                      ('wp-includes/js/tinymce/wp-tinymce.php', '<?php echo "TINYMCE-OK";\n'),
                      ('wp-content/mu-plugins/x.php', '<?php echo "SECRET-MU-EXECUTED";\n')):
        wr(doc, rel, body)
    wr(doc, 'wp-content/plugins/hello/endpoint.php', '<?php echo "PLUGIN-EXEC";\n')
    s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
    s = socket.socket(); s.bind(('127.0.0.1', 0)); sport = s.getsockname()[1]; s.close()
    sock = os.path.join(run, 'fpm.sock')
    conf = open(TPL, encoding='utf-8').read()
    for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)),
                 ('__FPM_SOCK__', sock), ('__CF_REALIP_DIRECTIVES__', '')):
        conf = conf.replace(k, v)
    conf = conf.replace('__STAGING_DOCROOT__', os.path.join(tmp, 'stg'))
    open(os.path.join(tmp, 'nginx.conf'), 'w').write(conf)
    open(os.path.join(run, 'ban-list.conf'), 'a').close()   # geo include (HANDOFF.md muc 1br) can file ton tai luc nginx khoi dong
    for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
        os.makedirs(m, exist_ok=True)
    open(os.path.join(tmp, 'fpm.conf'), 'w').write('[global]\npid=%s/fpm.pid\nerror_log=%s/fpm.log\ndaemonize=no\n[www]\nuser=root\ngroup=root\nlisten=%s\nlisten.mode=0666\npm=static\npm.max_children=2\n' % (tmp, tmp, sock))
    open(os.path.join(tmp, 'php.ini'), 'w').write('cgi.fix_pathinfo=0\n')
    procs = []
    try:
        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        for _ in range(100):  # cho php-fpm mo socket TRUOC khi test (neu khong moi ket qua deu la 502 va vo gia tri)
            if os.path.exists(sock): break
            time.sleep(0.1)
        sc, b = get(port, '/'); check('nginx+php-fpm that hoat dong (GET / -> INDEX-OK)', sc == 200 and 'INDEX-OK' in b, (sc, b[:60]))
        if not (sc == 200 and 'INDEX-OK' in b):
            for f in ('fpm.log',):
                fp = os.path.join(tmp, f)
                print('--- %s ---' % f); print(open(fp).read()[-600:] if os.path.exists(fp) else '(khong co)')
            for f in os.listdir(run):
                if f.endswith('error.log'): print('--- %s ---' % f); print(open(os.path.join(run, f)).read()[-600:])
            print('socket ton tai:', os.path.exists(sock)); print('=> DUNG: moi ket qua phia sau khong dang tin'); return 1
        print('== luat chan thu muc sao luu (nginx that) ==')
        for p in ['/wp-content/ai1wm-backups/site.wpress', '/wp-content/updraft/backup_db.gz', '/wp-content/backups-dup-lite/x.zip',
                  '/wp-content/backups-dup-pro/x.zip', '/wp-content/uploads/backupbuddy_backups/x.zip', '/wp-snapshots/x.zip',
                  '/wp-content/backupwordpress-abc123-backups/x.zip', '/wp-content/uploads/backwpup-9f8e7d-backups/x.zip',
                  '/wp-content/wpvividbackups/x.zip', '/WP-CONTENT/UPDRAFT/backup_db.gz', '/wp-content/%75pdraft/backup_db.gz',
                  '/wp-content/uploads/../updraft/backup_db.gz', '//wp-content//updraft//backup_db.gz']:
            sc, b = get(port, p); check('chan %s' % p, sc in (403, 404) and 'SECRET' not in b, (sc, b[:50]))
        print('== PHP trong uploads KHONG duoc chay ==')
        for p in ['/wp-content/uploads/shell.php', '/wp-content/uploads/Sub/X.PHTML', '/wp-content/uploads/sub/../shell.php',
                  '/wp-content/uploads/SHELL.PHP', '/wp-content/%75ploads/shell.php']:
            sc, b = get(port, p); check('khong thuc thi %s' % p, 'EXECUTED' not in b, (sc, b[:50]))
        print('== cai hop le van hoat dong ==')
        for p, m in [('/wp-content/uploads/archive.zip', 'ZIP-OK'), ('/wp-content/uploads/pic.jpg', 'JPG-OK'),
                     ('/wp-content/plugins/updraftplus/notes.txt', 'PLUGIN-NOTES'), ('/wp-content/plugins/hello/endpoint.php', 'PLUGIN-EXEC'),
                     ('/wp-content/uploads/data.json', 'JSON-OK'), ('/wp-includes/js/tinymce/wp-tinymce.php', 'TINYMCE-OK')]:
            sc, b = get(port, p); check('van phuc vu %s' % p, sc == 200 and m in b, (sc, b[:50]))
        print('== che dau van tay + file ro ri + PHP truc tiep (HANDOFF.md muc 1br) ==')
        for p in ['/readme.html', '/license.txt', '/README.HTML', '/wp-content/plugins/updraftplus/readme.txt', '/wp-content/themes/t1/CHANGELOG.md',
                  '/wp-content/debug.log', '/wp-content/uploads/dump.sql', '/.env', '/wp-config.php.bak',
                  '/wp-includes/load.php', '/wp-includes/js/tinymce/../../load.php', '/wp-content/mu-plugins/x.php']:
            sc, b = get(port, p); check('che/chan %s' % p, sc in (403, 404) and 'SECRET' not in b and 'WP-' not in b and 'PLUGIN-README' not in b and 'THEME-' not in b, (sc, b[:50]))
        sc, b = get(port, '/readme.html'); check('readme.html tra 404 (khong xac nhan file co that)', sc == 404, sc)
        sc, b = get(port, '/wp-content/debug.log'); check('debug.log tra 404', sc == 404, sc)
        print('== .php khong ton tai bi nginx tra 404 ngay (khong goi php-fpm) ==')
        sc, b = get(port, '/khong-co-file-nay.php'); check('/khong-co-file-nay.php -> 404', sc == 404, sc)
        check('... va do NGINX tra (khong phai "File not found." cua php-fpm)', 'File not found' not in b, b[:80])
        sc, b = get(port, '/wp-content/uploads/pic.jpg/x.php'); check('cat chuoi PATH_INFO (/pic.jpg/x.php) -> khong thuc thi, khong lo noi dung', sc in (403, 404) and 'JPG-OK' not in b, (sc, b[:50]))
        print('== phuong thuc la bi tu choi som; header khong lo phien ban ==')
        for meth in ('TRACE', 'PROPFIND', 'FOO'):
            c = http.client.HTTPConnection('127.0.0.1', port, timeout=20); c.putrequest(meth, '/'); c.endheaders(); r = c.getresponse(); r.read(); c.close()
            check('phuong thuc %s -> 405' % meth, r.status == 405, r.status)
        c = http.client.HTTPConnection('127.0.0.1', port, timeout=20); c.putrequest('GET', '/khong-co.html'); c.endheaders(); r = c.getresponse(); body = r.read().decode('utf-8', 'replace'); c.close()
        srv = r.getheader('Server') or ''
        check('header Server khong chua phien ban (server_tokens off): %r' % srv, not re.search(r'nginx/\d', srv), srv)
        check('trang loi 404 khong chua phien ban nginx', not re.search(r'nginx/\d', body), body[-120:])
    finally:
        for pr in procs:
            pr.terminate()
        for pr in procs:
            try: pr.wait(timeout=5)
            except Exception: pr.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
