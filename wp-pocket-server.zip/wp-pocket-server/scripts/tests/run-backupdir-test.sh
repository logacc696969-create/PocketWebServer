#!/bin/sh
# Chay kiem thu JVM cho BackupDirLogic.kt (can kotlinc + java). HANDOFF.md muc 1bp-K.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/BackupDirLogic.kt" "$HERE/BackupDirLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" BackupDirLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
