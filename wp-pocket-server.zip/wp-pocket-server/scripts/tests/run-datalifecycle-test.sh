#!/bin/sh
# Chay kiem thu JVM cho DataLifecycle.kt (can kotlinc + java). Khong can Android SDK. HANDOFF.md muc 1bo.
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../../app/src/main/java/com/wppocket/server"
OUT="$(mktemp -d)"
kotlinc -nowarn "$SRC/BackupLogic.kt" "$SRC/DataLifecycle.kt" "$HERE/DataLifecycleTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" DataLifecycleTestKt
rc=$?; rm -rf "$OUT"; exit $rc
