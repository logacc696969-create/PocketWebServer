#!/bin/sh
# Kiem thu scripts/tools/loadtest.sh voi php -S that (HANDOFF.md muc 1ay). Can: php, ab (apache2-utils). Thieu -> bo qua.
HERE="$(cd "$(dirname "$0")" && pwd)"; LT="$HERE/../tools/loadtest.sh"
command -v php >/dev/null && command -v ab >/dev/null || { echo "(bo qua: can php + ab)"; exit 0; }
W="$(mktemp -d)"; pass=0; fail=0
ok() { if [ "$1" = 0 ]; then echo "PASS: $2"; pass=$((pass+1)); else echo "FAIL: $2"; fail=$((fail+1)); fi; }
printf '<?php echo "OK";\n' > "$W/index.php"; printf '<?php http_response_code(500); echo "ERR";\n' > "$W/err.php"
PORT=$(python3 -c "import socket;s=socket.socket();s.bind(('127.0.0.1',0));print(s.getsockname()[1])")
php -S 127.0.0.1:$PORT -t "$W" >/dev/null 2>&1 & SP=$!
i=0; while ! python3 -c "import socket;socket.create_connection(('127.0.0.1',$PORT),timeout=0.2)" 2>/dev/null && [ $i -lt 30 ]; do sleep 0.2; i=$((i+1)); done
export LOADTEST_PAUSE=0
OUT=$(sh "$LT" "http://127.0.0.1:$PORT/" 60 "1 4" 2>&1); RC=$?
[ $RC = 0 ]; ok $? "trang binh thuong: thoat 0 (rc=$RC)"
[ "$(echo "$OUT" | grep -c '^[0-9]')" = 2 ]; ok $? "in dung 2 dong ket qua (muc 1 va 4)"
echo "$OUT" | awk '/^[0-9]/{ if ($2+0 <= 0) bad=1 } END{exit bad}'; ok $? "req/s la so duong o moi muc"
echo "$OUT" | awk '/^[0-9]/{ if ($3+0 <= 0 && $3 != "0") bad=1; if ($4+0 < $3+0) bad=1 } END{exit bad}'; ok $? "p95 >= p50 (do tre hop ly)"
OUT=$(sh "$LT" "http://127.0.0.1:$PORT" 40 "2" 2>&1); [ $? = 0 ] && echo "$OUT" | grep -q '^2 '; ok $? "URL KHONG co duong dan van chay (tu them '/')"
OUT=$(sh "$LT" "http://127.0.0.1:$PORT/" 20 "1 5 50" 2>&1); [ "$(echo "$OUT" | grep -c '^[0-9]')" = 2 ]; ok $? "muc dong thoi > so request bi bo qua (ab yeu cau -c <= -n), khong lam hong lan chay"
OUT=$(sh "$LT" "http://127.0.0.1:$PORT/err.php" 40 "2" 2>&1); RC=$?
[ $RC = 1 ] && echo "$OUT" | grep -q 'LOI'; ok $? "trang tra 500: thoat 1 + bao co request LOI (rc=$RC)"
echo "$OUT" | awk '/^2 /{exit !($7+0 > 0)}'; ok $? "cot non2xx dem dung so response 500"
sh "$LT" >/dev/null 2>&1; [ $? = 2 ]; ok $? "khong tham so: thoat 2 + in huong dan"
sh "$LT" "ftp://x/" >/dev/null 2>&1; [ $? = 2 ]; ok $? "URL sai scheme: thoat 2"
PATH=/nonexistent /bin/sh "$LT" "http://127.0.0.1:$PORT/" >/dev/null 2>&1; [ $? = 2 ]; ok $? "thieu ab: thoat 2 + huong dan cai (khong chay am tham)"
kill $SP 2>/dev/null; wait $SP 2>/dev/null; rm -rf "$W"
echo; echo "TONG KET: pass=$pass fail=$fail"; [ $fail = 0 ]
