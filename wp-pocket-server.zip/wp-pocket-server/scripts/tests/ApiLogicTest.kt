import com.wppocket.server.ApiLogic
import java.security.SecureRandom

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun main() {
    val r = SecureRandom(); val seen = HashSet<String>(); var allValid = true
    for (i in 0 until 200) { val t = ApiLogic.generateToken(r); seen.add(t); allValid = allValid && t.length == 64 && ApiLogic.isValidToken(t) }
    check("200 token hop le, khong trung", allValid && seen.size == 200)
    check("isValidToken bien 32/64", ApiLogic.isValidToken("a".repeat(32)) && ApiLogic.isValidToken("0".repeat(64)) && !ApiLogic.isValidToken("a".repeat(31)) && !ApiLogic.isValidToken("a".repeat(65)))
    check("ky tu la/chu hoa/nhay/\$/;/khoang trang/rong/null bi tu choi", !ApiLogic.isValidToken("A".repeat(40)) && !ApiLogic.isValidToken("a".repeat(39) + "\"") && !ApiLogic.isValidToken("a".repeat(39) + "\$") && !ApiLogic.isValidToken("a".repeat(39) + ";") && !ApiLogic.isValidToken("a".repeat(39) + " ") && !ApiLogic.isValidToken("") && !ApiLogic.isValidToken(null))
    check("jsonEscape", ApiLogic.jsonEscape("a\"b\\c\nd\te\u0001") == "a\\\"b\\\\c\\nd\\te\\u0001")
    val j = ApiLogic.buildStatusJson(1_700_000_000L, true, 83, true, 41, 1_699_990_000L, 5, "1.2.3")
    check("JSON day du", j == "{\"schema\":\"wp-pocket-status/1\",\"generated_at\":1700000000,\"server_running\":true,\"battery_pct\":83,\"charging\":true,\"disk_used_pct\":41,\"last_backup_at\":1699990000,\"backup_count\":5,\"app_version\":\"1.2.3\"}")
    val n = ApiLogic.buildStatusJson(1L, false, -1, false, -1, 0L, -1, "")
    check("gia tri khong biet -> null", n.contains("\"battery_pct\":null") && n.contains("\"disk_used_pct\":null") && n.contains("\"last_backup_at\":null") && n.contains("\"backup_count\":0"))
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
