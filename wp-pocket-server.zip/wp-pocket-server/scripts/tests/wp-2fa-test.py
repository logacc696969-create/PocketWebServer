#!/usr/bin/env python3
"""Kiem thu dang nhap HAI BUOC (TOTP) tren WORDPRESS THAT (HANDOFF.md muc 1br-H, docs/SECURITY.md muc 4).

Vi sao tren WordPress that: tinh nang nay nam tren duong dang nhap - loi o day co the KHOA CHU SITE. Test gia lap khong bat duoc loi thu tu hook
(personal_options_update chay TRUOC user_profile_update_errors), nonce, thong bao dang nhap that, cookie, Shield cung hoat dong. Phan thuan (RFC 6238,
ma hoa) kiem rieng bang PHP khong can WordPress.

Can nhu wp-real-test.py: WP_REAL_SRC, WP_SQLITE_SRC (xem dau file do), php CLI co pdo_sqlite. Thieu thi bo qua (exit 0). Neu co kotlinc+kotlin: kiem them
rang moi dong su kien 2FA do PHP that ghi ra deu duoc ung dung Android (MonitorLogic.scanSecurityEvents) phan loai.
Moc thoi gian: replay-protection can buoc 30 giay moi -> test chu dong dat lai moc 'l' (qua CLI) o cac muc khong thu replay, de khong phai cho.
"""
import base64, hashlib, hmac, html.parser, importlib.util, json, os, re, shutil, struct, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
SRC = os.path.normpath(os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java', 'com', 'wppocket', 'server'))
_spec = importlib.util.spec_from_file_location('wprealtest', os.path.join(HERE, 'wp-real-test.py'))
WR = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(WR)
LOGIC = os.environ.get('WP2FA_LOGIC') or os.path.join(TPL, 'wppocket-2fa-logic.php')     # chi de chay "doi chung am": bien the co chu y gay loi phai lam test THAT BAI
PW = 'Pa55word-Test!'
MSG = 'Sign-in failed. Check your username, password and authentication code.'
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:300]) if d else ''))


# ----------------------------------------------------------------------------- TOTP doc lap (khong dung ma PHP de kiem PHP)
def b32dec(s):
    s = re.sub(r'[^A-Z2-7]', '', s.upper())
    return base64.b32decode(s + '=' * (-len(s) % 8))


def hotp(key, counter):
    h = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
    o = h[19] & 15
    return '%06d' % ((struct.unpack('>I', h[o:o + 4])[0] & 0x7fffffff) % 1000000)


def totp(secret_b32, offset_steps=0, now=None):
    t = int((time.time() if now is None else now) // 30) + offset_steps
    return hotp(b32dec(secret_b32), t)


def wrong_code(secret_b32):
    ok = {totp(secret_b32, i) for i in range(-3, 4)}
    for n in range(100000, 999999, 7919):
        if '%06d' % n not in ok:
            return '%06d' % n


# ----------------------------------------------------------------------------- form HTML
class FormScraper(html.parser.HTMLParser):
    def __init__(self, form_id):
        super().__init__(convert_charrefs=True)
        self.fid, self.inside, self.fields, self.action, self.sel, self.ta = form_id, False, {}, '', None, None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'form' and a.get('id') == self.fid:
            self.inside, self.action = True, a.get('action', '')
            return
        if not self.inside:
            return
        if tag == 'input' and a.get('name'):
            t = (a.get('type') or 'text').lower()
            if t in ('submit', 'button', 'image', 'file', 'reset'):
                return
            if t in ('checkbox', 'radio') and 'checked' not in a:
                return
            self.fields[a['name']] = a.get('value', '')
        elif tag == 'select' and a.get('name'):
            self.sel = a['name']
            self.fields.setdefault(self.sel, '')
        elif tag == 'option' and self.sel:
            if 'selected' in a or not self.fields.get(self.sel):
                self.fields[self.sel] = a.get('value', '')
        elif tag == 'textarea' and a.get('name'):
            self.ta = a['name']
            self.fields[self.ta] = ''

    def handle_endtag(self, tag):
        if tag == 'form':
            self.inside = False
        elif tag == 'select':
            self.sel = None
        elif tag == 'textarea':
            self.ta = None

    def handle_data(self, data):
        if self.inside and self.ta:
            self.fields[self.ta] += data


def scrape(page, form_id='your-profile'):
    p = FormScraper(form_id)
    p.feed(page)
    return p.fields


def text_of(page):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', page))


class T:
    """Moi truong test: 1 WordPress that + Shield + 2FA."""

    def __init__(self, S):
        self.S = S
        self.n = 0

    def ip(self):
        self.n += 1
        return '45.60.%d.%d' % (self.n % 250 + 1, self.n // 250 + 1)

    def login(self, user, pwd, otp=None, ip=None):
        jar = {'wordpress_test_cookie': 'WP%20Cookie%20check'}
        data = {'log': user, 'pwd': pwd, 'wp-submit': 'Log In', 'redirect_to': self.S.base + '/wp-admin/', 'testcookie': '1'}
        if otp is not None:
            data['wppocket_otp'] = otp
        st, txt, jar, loc = self.S.req('POST', '/wp-login.php', ip or self.ip(), data, jar)
        ok = st == 302 and any(k.startswith('wordpress_logged_in_') for k in jar)
        m = re.search(r'(?s)id="login_error"[^>]*>(.*?)</div>', txt)
        err = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', m.group(1))).strip() if m else ''
        return ok, err, jar

    def profile(self, jar, path='/wp-admin/profile.php', ip='203.0.113.10'):
        st, page, _, _ = self.S.req('GET', path, ip, jar=jar)
        return st, page

    def post_profile(self, jar, page, extra, path='/wp-admin/profile.php', ip='203.0.113.10', form_id='your-profile'):
        f = scrape(page, form_id)
        f.update(extra)
        st, txt, _, loc = self.S.req('POST', path, ip, f, jar)
        return st, txt, loc

    def meta(self, uid):
        return self.S.cli("echo (string) get_user_meta(%d, 'wppocket_2fa', true);" % uid)

    def reset_step(self, uid):
        """Dat lai moc replay (gia lap 'da qua 30 giay') de khong phai cho; KHONG dung o muc thu replay."""
        self.S.cli("$r = json_decode((string) get_user_meta(%d, 'wppocket_2fa', true), true); if (is_array($r)) { $r['l'] = 0; update_user_meta(%d, 'wppocket_2fa', wp_slash(wp_json_encode($r))); }" % (uid, uid))

    def secret_from(self, page):
        m = re.search(r'id="wppocket-2fa-secret"[^>]*>([^<]+)<', page)
        return re.sub(r'\s+', '', m.group(1)) if m else ''

    def codes_from(self, page):
        m = re.search(r'(?s)id="wppocket-2fa-codes"[^>]*>(.*?)</pre>', page)
        return [x.strip() for x in m.group(1).split('\n') if x.strip()] if m else []


def unit_tests():
    """Phan thuan: RFC 6238/4226, base32, ma hoa, kiem ma, hai che do ma hoa - khong can WordPress."""
    print('== 1. phan thuan (khong can WordPress) ==')
    prelude = ("define('ABSPATH','/'); define('AUTH_KEY','khoa-A'); define('SECURE_AUTH_KEY','khoa-B'); require %r;\n" % LOGIC)

    def php(code, ini=()):
        args = ['php'] + [x for i in ini for x in ('-d', i)] + ['-r', prelude + code]
        r = subprocess.run(args, capture_output=True, text=True, timeout=60)
        return (r.stdout + r.stderr).strip()

    k = '12345678901234567890'
    out = php("foreach ([[59,'287082'],[1111111109,'081804'],[1111111111,'050471'],[1234567890,'005924'],[2000000000,'279037'],[20000000000,'353130']] as $v) {"
              " echo wppocket_2fa_hotp('%s', intdiv($v[0], 30)) === $v[1] ? 'Y' : 'N'; }" % k)
    check('HOTP/TOTP khop 6 vector chinh thuc RFC 6238 (Phu luc B, 6 chu so cuoi cua ma 8 chu so)', out == 'YYYYYY', out)
    out = php("echo wppocket_2fa_b32_encode('%s'), ' ', bin2hex(wppocket_2fa_b32_decode('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ'));" % k)
    check('base32 theo RFC 4648 (vector 12345678901234567890) khop ca hai chieu', out == 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ ' + k.encode().hex(), out)
    out = php("$s = random_bytes(20); echo wppocket_2fa_b32_decode(wppocket_2fa_b32_encode($s)) === $s ? 'Y' : 'N';")
    check('base32 ma hoa roi giai ma tra lai dung bi mat ngau nhien 20 byte', out == 'Y', out)
    out = php("$s = random_bytes(20); $e = wppocket_2fa_encrypt($s); echo (wppocket_2fa_decrypt($e) === $s ? 'Y' : 'N'), (strpos($e, 's1:') === 0 ? 'S' : '?'), ($e !== wppocket_2fa_encrypt($s) ? 'U' : 'x');")
    check('ma hoa libsodium: khu hoi dung, tien to s1:, moi lan ma hoa ra gia tri khac nhau (nonce ngau nhien)', out == 'YSU', out)
    out = php("$s = random_bytes(20); $e = wppocket_2fa_encrypt($s); $raw = base64_decode(substr($e, 3)); $raw[30] = chr(ord($raw[30]) ^ 1); echo wppocket_2fa_decrypt('s1:' . base64_encode($raw)) === '' ? 'Y' : 'N';")
    check('ban ma bi sua 1 bit: giai ma tu choi (tra rong), khong tra rac', out == 'Y', out)
    out = php("$e = wppocket_2fa_encrypt('x'); echo wppocket_2fa_decrypt('s1:@@@'), '|', wppocket_2fa_decrypt(''), '|', wppocket_2fa_decrypt('zz:abcd'), '|', wppocket_2fa_decrypt('s1:' . base64_encode('ngan')), '|ok';")
    check('du lieu hong/rong/tien to la/qua ngan: tra rong, khong loi/canh bao', out == '|||ok' or out == '|||' + '|ok', out)
    out = php("$s = random_bytes(20); echo strpos(wppocket_2fa_encrypt($s), 'o1:') === 0 ? 'Y' : 'N', wppocket_2fa_decrypt(wppocket_2fa_encrypt($s)) === $s ? 'Y' : 'N';",
              ['disable_functions=sodium_crypto_secretbox,sodium_crypto_secretbox_open'])
    check('khong co libsodium: tu chuyen sang OpenSSL AES-256-GCM (tien to o1:) va giai ma dung', out == 'YY', out)
    out = php("echo wppocket_2fa_crypto_ok() ? 'Y' : 'N';", ['disable_functions=sodium_crypto_secretbox,sodium_crypto_secretbox_open,openssl_encrypt'])
    check('khong co ca hai thu vien ma hoa: bao khong dung duoc (khong bat 2FA khi khong luu an toan duoc)', out == 'N', out)
    # kiem ma + replay + ma khoi phuc
    code = (r'''$bin = random_bytes(20); $now = 1700000010; $t = intdiv($now, 30);
      $d = array('s' => wppocket_2fa_encrypt($bin), 'r' => array(wppocket_2fa_recovery_hash('abcde-23456'), wppocket_2fa_recovery_hash('fghjk-78923')), 'l' => 0);
      $c = fn(int $s) => wppocket_2fa_hotp($bin, $s);
      $o = array();
      $r = wppocket_2fa_check($d, $c($t), $now); $o[] = $r['ok'] && $r['kind'] === 'totp' && $r['d']['l'] === $t ? 'Y' : 'N';          // 0 dung
      $r2 = wppocket_2fa_check($r['d'], $c($t), $now); $o[] = !$r2['ok'] ? 'Y' : 'N';                                                  // 1 replay cung buoc
      $r3 = wppocket_2fa_check($r['d'], $c($t - 1), $now); $o[] = !$r3['ok'] ? 'Y' : 'N';                                              // 2 buoc cu hon
      $r4 = wppocket_2fa_check($r['d'], $c($t + 1), $now); $o[] = $r4['ok'] ? 'Y' : 'N';                                               // 3 buoc ke tiep (lech dong ho +30s)
      $o[] = wppocket_2fa_check($d, $c($t - 1), $now)['ok'] ? 'Y' : 'N';                                                                // 4 lech -30s van duoc
      $o[] = !wppocket_2fa_check($d, $c($t + 2), $now)['ok'] && !wppocket_2fa_check($d, $c($t - 2), $now)['ok'] ? 'Y' : 'N';            // 5 ngoai cua so bi tu choi
      $o[] = wppocket_2fa_check($d, substr($c($t), 0, 3) . ' ' . substr($c($t), 3), $now)['ok'] ? 'Y' : 'N';                            // 6 co dau cach
      $o[] = !wppocket_2fa_check($d, '', $now)['ok'] && !wppocket_2fa_check($d, '12345', $now)['ok'] && !wppocket_2fa_check($d, '1234567', $now)['ok'] ? 'Y' : 'N';   // 7 rong/ngan/dai
      $rr = wppocket_2fa_check($d, 'ABCDE-23456', $now); $o[] = $rr['ok'] && $rr['kind'] === 'recovery' && count($rr['d']['r']) === 1 ? 'Y' : 'N';   // 8 ma khoi phuc (khong phan biet hoa/thuong)
      $o[] = !wppocket_2fa_check($rr['d'], 'abcde-23456', $now)['ok'] ? 'Y' : 'N';                                                       // 9 dung 1 lan
      $o[] = wppocket_2fa_check($rr['d'], 'fghjk78923', $now)['ok'] ? 'Y' : 'N';                                                          // 10 ma con lai, bo dau gach
      $o[] = !wppocket_2fa_check($d, 'abcde-23457', $now)['ok'] ? 'Y' : 'N';                                                              // 11 sai 1 ky tu
      $bad = $d; $bad['s'] = 'rac'; $o[] = !wppocket_2fa_check($bad, $c($t), $now)['ok'] ? 'Y' : 'N';                                     // 12 bi mat hong -> khong cho qua
      echo implode('', $o);''')
    out = php(code)
    check('kiem ma: dung/replay/buoc cu/lech dong ho +-30s/ngoai cua so/dau cach/rong-ngan-dai/ma khoi phuc 1 lan/bi mat hong (13 truong hop)', out == 'YYYYYYYYYYYYY', out)
    out = php("$c = wppocket_2fa_make_recovery_codes(); echo count($c), ' ', count(array_unique($c)), ' ', (int) !array_filter($c, fn($x) => !preg_match('/^[a-hj-km-np-z2-9]{5}-[a-hj-km-np-z2-9]{5}$/', $x));")
    check('ma khoi phuc: 8 ma khac nhau, dang xxxxx-xxxxx, khong co ky tu de nham (0 o 1 l i)', out == '8 8 1', out)
    out = php("$h = wppocket_2fa_recovery_hash('abcde-23456'); echo (strlen($h) === 64 ? 'Y' : 'N'), ($h === wppocket_2fa_recovery_hash('ABCDE23456') ? 'Y' : 'N'), (strpos($h, 'abcde') === false ? 'Y' : 'N');")
    check('ma khoi phuc luu dang bam HMAC-SHA256 (khong ban ro), chuan hoa hoa/thuong va dau gach', out == 'YYY', out)


def main():
    wp_src, sq_src = os.environ.get('WP_REAL_SRC', ''), os.environ.get('WP_SQLITE_SRC', '')
    unit_tests()
    if not (os.path.isfile(os.path.join(wp_src, 'wp-load.php')) and os.path.isdir(os.path.join(sq_src, 'packages', 'plugin-sqlite-database-integration'))):
        print('(bo qua phan WordPress that: dat WP_REAL_SRC va WP_SQLITE_SRC - xem dau file wp-real-test.py)')
        print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
        return 0 if FAIL == 0 else 1
    ext = subprocess.run(['php', '-r', 'echo extension_loaded("pdo_sqlite") ? "1" : "0";'], capture_output=True, text=True).stdout
    if ext != '1':
        print('(bo qua phan WordPress that: PHP thieu pdo_sqlite)')
        print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
        return 0 if FAIL == 0 else 1
    S = WR.Site(wp_src, sq_src)
    X = T(S)
    try:
        ok, out = S.install()
        check('cai WordPress THAT (SQLite)', ok, out)
        if not ok:
            return 1
        S.install_shield()
        mu = os.path.join(S.site, 'wp-content', 'mu-plugins')
        os.makedirs(os.path.join(mu, 'wppocket-2fa'), exist_ok=True)
        shutil.copy(os.path.join(TPL, 'wppocket-2fa-loader.php'), os.path.join(mu, 'wppocket-2fa.php'))
        shutil.copy(LOGIC, os.path.join(mu, 'wppocket-2fa', '2fa.php'))
        S.cli("wp_insert_user(['user_login'=>'bob','user_pass'=>'Bob-Pa55-word!','user_email'=>'bob@example.test','role'=>'editor']);")
        out = S.cli("echo defined('WPPOCKET_2FA_META') && function_exists('wppocket_2fa_authenticate') ? 'LOADED' : 'NO';")
        check('mu-plugin 2FA nap duoc trong WordPress that (cung Shield)', out.endswith('LOADED'), out)
        check('server php -S len', S.start())
        store = os.path.join(S.run, 'shield-login.json')

        print('== 2. chua ai bat: dang nhap y het cu, khong co tac dung phu ==')
        st, page, _, _ = S.req('GET', '/wp-login.php')
        check('trang dang nhap KHONG co o nhap ma khi chua ai bat hai buoc', st == 200 and 'wppocket_otp' not in page, st)
        ok, e, jar = X.login('owner', PW, ip='203.0.113.10')
        check('dang nhap bang mat khau nhu cu', ok, e)
        ok2, e2, _ = X.login('owner', 'sai-roi')
        check('sai mat khau: thong bao cua Shield khong doi (chung chung, khong nhac "authentication code")', not ok2 and 'authentication code' not in e2 and e2 != '', e2)

        print('== 3. bat hai buoc qua trang Ho so (nonce that, hook that) ==')
        st, page = X.profile(jar)
        check('trang Ho so hien muc "Two-step sign-in" + trang thai OFF + khoa cai dat', st == 200 and 'Two-step sign-in' in page and 'OFF.' in page and len(X.secret_from(page)) >= 32, st)
        secret = X.secret_from(page)
        check('co lien ket otpauth:// (cham mot lan tren dien thoai) voi cung khoa, SHA1/6 so/30 giay', ('otpauth://totp/' in page) and ('secret=' + secret) in page and 'digits=6' in page and 'period=30' in page)
        before = X.meta(1)
        st, page2, loc = X.post_profile(jar, page, {'wppocket_2fa_confirm': wrong_code(secret)})
        check('nhap SAI ma xac nhan: KHONG bat (thong bao ro rang), trang van 200 voi loi', st == 200 and 'NOT turned on' in page2, (st, text_of(page2)[:300]))
        check('... va khong luu gi vao ho so nguoi dung', X.meta(1) == before == '', X.meta(1)[:80])
        st, page3 = X.profile(jar)
        check('khoa cai dat GIU NGUYEN sau lan sai (ban quet tren dien thoai khong bi mat gia tri)', X.secret_from(page3) == secret)
        st, _, loc = X.post_profile(jar, page3, {'wppocket_2fa_confirm': totp(secret)})
        check('nhap DUNG ma: ho so luu thanh cong (302)', st == 302, (st, loc))
        st, page4 = X.profile(jar, '/wp-admin/profile.php?updated=true')
        codes = X.codes_from(page4)
        check('hien 8 ma khoi phuc dang xxxxx-xxxxx MOT LAN, trang bao "ON"', len(codes) == 8 and 'ON</strong> for this account' in page4 and all(re.match(r'^[a-z0-9]{5}-[a-z0-9]{5}$', c) for c in codes), codes)
        st, page5 = X.profile(jar)
        check('tai lai trang: ma khoi phuc KHONG hien lai, con 8 ma', not X.codes_from(page5) and 'Recovery codes left: 8' in page5)
        raw = X.meta(1)
        d = json.loads(raw) if raw else {}
        check('meta luu: bat, 8 ma khoi phuc dang bam, bi mat o dang ma hoa (s1:/o1:)', d.get('on') == 1 and len(d.get('r', [])) == 8 and re.match(r'^(s1|o1):', d.get('s', '')), raw[:120])
        dbp = os.path.join(S.site, 'wp-content', 'database')
        blob = b''.join(open(os.path.join(d0, f), 'rb').read() for d0, _ds, fs in os.walk(dbp) for f in fs)      # SQLite plugin dat CSDL o .ht.<bam ngau nhien>/.ht.sqlite
        check('co so du lieu KHONG chua bi mat TOTP o dang ro (base32 hoac nhi phan) ma chi chua ban ma hoa', secret.encode() not in blob and b32dec(secret) not in blob and len(blob) > 100000, (secret.encode() in blob, b32dec(secret) in blob, len(blob), os.listdir(dbp)))
        check('... cung khong chua ma khoi phuc ro (chi bam)', not any(c.encode() in blob or c.replace('-', '').encode() in blob for c in codes))
        ev = S.events()
        check('su kien "2FA DA BAT: owner" duoc ghi; khong lo bi mat/ma trong nhat ky', '2FA DA BAT: owner' in ev and secret not in ev and not any(c in ev for c in codes), ev[-200:])
        st, page6 = X.profile(jar, '/wp-admin/')
        check('phien dang nhap dang co van dung duoc sau khi bat (khong tu dang xuat)', st == 200 and 'Dashboard' in page6)
        st, page7, _, _ = S.req('GET', '/wp-login.php')
        check('trang dang nhap GIO hien o "Authentication code" (vi co nguoi dung da bat)', 'name="wppocket_otp"' in page7 and 'Authentication code' in page7)
        store_clear = lambda: os.path.exists(store) and os.remove(store)

        print('== 4. dang nhap khi da bat hai buoc ==')
        store_clear()
        okA, eA, _ = X.login('owner', PW)
        okB, eB, _ = X.login('owner', PW, wrong_code(secret))
        okC, eC, _ = X.login('owner', 'sai-mat-khau', totp(secret, 1))
        okD, eD, _ = X.login('khong-ton-tai-xyz', 'sai-mat-khau', '123456')
        okE, eE, _ = X.login('owner', PW, 'abc')
        check('DUNG mat khau nhung KHONG ma -> khong dang nhap', not okA, eA)
        check('DUNG mat khau nhung ma SAI -> khong dang nhap', not okB, eB)
        check('SAI mat khau + ma dung -> khong dang nhap', not okC, eC)
        check('ma khong phai so ("abc") -> khong dang nhap', not okE, eE)
        check('4 truong hop that bai co thong bao GIONG HET nhau (khong lo "mat khau dung roi")', eA == eB == eC == eD == eE == MSG, (eA, eB, eC, eD, eE))
        check('thong bao khong lo ten tai khoan/ly do cu the', not re.search(r'incorrect|not registered|owner|invalid', eA, re.I), eA)
        okF, eF, jarF = X.login('owner', PW, totp(secret, 1))
        check('DUNG mat khau + DUNG ma (buoc ke tiep, dong ho lech 30 giay van duoc) -> vao duoc', okF, eF)
        st, p, _, _ = S.req('GET', '/wp-admin/', '203.0.113.10', jar=jarF)
        check('phien moi vao duoc /wp-admin/ (Dashboard)', st == 200 and 'Dashboard' in p, st)
        okG, eG, _ = X.login('owner', PW, totp(secret, 1))
        check('DUNG LAI ma vua dung (replay cung buoc) -> bi tu choi', not okG and eG == MSG, eG)
        okH, eH, _ = X.login('owner', PW, totp(secret, 0))
        check('ma cua buoc CU HON buoc da dung -> bi tu choi', not okH, eH)
        okB2, eB2, _ = X.login('bob', 'Bob-Pa55-word!')
        check('nguoi dung KHAC chua bat hai buoc van chi can mat khau', okB2, eB2)

        print('== 5. ma khoi phuc ==')
        store_clear()
        ok1, e1, _ = X.login('owner', PW, codes[0])
        check('ma khoi phuc dau tien -> vao duoc', ok1, e1)
        ok1b, e1b, _ = X.login('owner', PW, codes[0])
        check('DUNG LAI cung ma khoi phuc -> bi tu choi (dung 1 lan)', not ok1b and e1b == MSG, e1b)
        ok2, e2, _ = X.login('owner', PW, codes[1].upper().replace('-', ' '))
        check('ma khoi phuc go IN HOA, thay gach bang dau cach -> van nhan (de go tren dien thoai)', ok2, e2)
        st, page = X.profile(jar)
        check('trang Ho so dem dung con 6 ma', 'Recovery codes left: 6' in page, re.findall(r'Recovery codes left: \d+', page))
        check('su kien "2FA MA KHOI PHUC DA DUNG" duoc ghi (khong kem ma)', S.events().count('2FA MA KHOI PHUC DA DUNG: owner') == 2 and codes[0] not in S.events() and codes[1] not in S.events())
        X.reset_step(1)
        ok3, e3, _ = X.login('owner', PW, totp(secret)[:3] + ' ' + totp(secret)[3:])
        check('ma TOTP go co dau cach ("123 456") van nhan', ok3, e3)

        print('== 6. doi cai dat tu Ho so: tao lai ma / tat ==')
        store_clear()
        X.reset_step(1)
        st, page = X.profile(jar)
        st, txt, loc = X.post_profile(jar, page, {'wppocket_2fa_regen': '1', 'wppocket_2fa_code': wrong_code(secret)})
        check('tao lai ma khoi phuc voi ma SAI: bi tu choi (thong bao ro rang), ma cu con nguyen', st == 200 and 'NOT changed' in txt and json.loads(X.meta(1))['r'].__len__() == 6, (st, text_of(txt)[:200]))
        X.reset_step(1)
        st, page = X.profile(jar)
        st, txt, loc = X.post_profile(jar, page, {'wppocket_2fa_regen': '1', 'wppocket_2fa_code': totp(secret)})
        check('tao lai voi ma DUNG: luu thanh cong (302), KHONG hien nham loi "NOT changed" (loi thu tu hook da gap khi viet)', st == 302, (st, text_of(txt)[:200]))
        st, page = X.profile(jar, '/wp-admin/profile.php?updated=true')
        codes2 = X.codes_from(page)
        check('hien 8 ma MOI, khac hoan toan ma cu', len(codes2) == 8 and not set(codes2) & set(codes), codes2)
        store_clear()
        ok, e, _ = X.login('owner', PW, codes[2])
        check('ma khoi phuc CU (chua dung) khong con tac dung sau khi tao lai', not ok, e)
        ok, e, _ = X.login('owner', PW, codes2[0])
        check('ma khoi phuc MOI dung duoc', ok, e)
        X.reset_step(1)
        st, page = X.profile(jar)
        st, txt, loc = X.post_profile(jar, page, {'wppocket_2fa_disable': '1', 'wppocket_2fa_code': wrong_code(secret)})
        check('tat hai buoc voi ma SAI: van BAT (an toan khi ke chiem phien thu tat)', st == 200 and 'NOT changed' in txt and X.meta(1) != '', st)
        okno, eno, _ = X.login('owner', PW)
        check('... va dang nhap van doi ma', not okno)
        X.reset_step(1)
        st, page = X.profile(jar)
        st, txt, loc = X.post_profile(jar, page, {'wppocket_2fa_disable': '1', 'wppocket_2fa_code': totp(secret)})
        check('tat hai buoc voi ma DUNG: thanh cong (302), meta bi xoa', st == 302 and X.meta(1) == '', (st, X.meta(1)[:60]))
        ok, e, _ = X.login('owner', PW)
        check('sau khi tat: chi can mat khau lai', ok, e)
        st, page, _, _ = S.req('GET', '/wp-login.php')
        check('khong con ai bat: o nhap ma bien mat khoi trang dang nhap', 'wppocket_otp' not in page)
        check('su kien "2FA DA TAT" duoc ghi', '2FA DA TAT: owner' in S.events())

        print('== 7. Shield: doan ma bi tinh vao bo dem khoa tai khoan ==')
        # bat lai nhanh bang CLI (khong lap lai luong Ho so)
        secret2 = base64.b32encode(hashlib.sha256(b'seed-2').digest()[:20]).decode().rstrip('=')
        store_clear()
        okk, ek, _ = X.login('owner', PW, ip='203.0.113.20')      # (luc nay owner chua bat) dang nhap that tu mang quen -> Shield ghi nho mang 203.0.113.0/24
        check('chuan bi: owner dang nhap thanh cong tu mang quen truoc khi bi do', okk, ek)
        S.cli("$bin = hash('sha256', 'seed-2', true); $bin = substr($bin, 0, 20); wppocket_2fa_save(1, array('v'=>1,'on'=>1,'s'=>wppocket_2fa_encrypt($bin),'r'=>array(),'l'=>0,'at'=>time()));")
        for i in range(1, 26):
            X.login('owner', PW, wrong_code(secret2), ip='46.70.%d.9' % i)      # ke tan cong BIET mat khau, doan ma tu 25 mang
        ok, e, _ = X.login('owner', PW, totp(secret2), ip='46.71.1.1')
        check('sau 25 lan doan ma sai: DUNG mat khau + DUNG ma tu mang la van bi khoa (chan do ma 6 so)', not ok and 'Too many' in e, (ok, e))
        check('su kien "TAM KHOA DANG NHAP" duoc ghi', 'TAM KHOA DANG NHAP' in S.events())
        ok, e, _ = X.login('owner', PW, totp(secret2), ip='203.0.113.55')
        check('chu site tu mang quen (da dang nhap truoc do) van vao duoc voi ma dung khi dang bi do', ok, e)
        store_clear()

        print('== 8. quan tri vien dat lai hai buoc cua nguoi khac (mat dien thoai) ==')
        okb, eb, jarb = X.login('bob', 'Bob-Pa55-word!')          # bob vao truoc khi bat, giu phien
        out = S.cli("$bin = substr(hash('sha256','seed-bob',true),0,20); wppocket_2fa_save(2, array('v'=>1,'on'=>1,'s'=>wppocket_2fa_encrypt($bin),'r'=>array(),'l'=>0,'at'=>time())); echo 'OK';")
        okb2, eb2, _ = X.login('bob', 'Bob-Pa55-word!')
        check('bob (bat hai buoc bang CLI) khong vao duoc chi bang mat khau', okb2 is False and eb2 == MSG, eb2)
        X.reset_step(1)
        ok, e, jar = X.login('owner', PW, totp(secret2), ip='203.0.113.10')
        check('owner dang nhap (co ma) de dat lai cho bob', ok, e)
        st, page = X.profile(jar, '/wp-admin/user-edit.php?user_id=2')
        check('admin thay muc "Reset two-step sign-in" trong ho so cua bob', st == 200 and 'wppocket_2fa_reset' in page, st)
        st, txt, loc = X.post_profile(jar, page, {'wppocket_2fa_reset': '1'}, '/wp-admin/user-edit.php', form_id='your-profile')
        check('dat lai: 302, meta cua bob bi xoa, bob vao lai chi bang mat khau', st == 302 and X.meta(2) == '' and X.login('bob', 'Bob-Pa55-word!')[0], (st, X.meta(2)[:50]))
        ev = S.events()
        check('su kien khan "2FA BI DAT LAI: bob (boi quan tri owner)" duoc ghi', '2FA BI DAT LAI: bob (boi quan tri owner)' in ev, ev[-300:])
        check('tai khoan KHAC khong bi anh huong: hai buoc cua owner van bat', X.meta(1) != '')
        # kiem am: nguoi dung quyen thap khong the dat lai hai buoc cua quan tri
        out = S.cli("$bin = substr(hash('sha256','seed-bob',true),0,20); wppocket_2fa_save(2, array('v'=>1,'on'=>1,'s'=>wppocket_2fa_encrypt($bin),'r'=>array(),'l'=>0,'at'=>time())); echo 'OK';")
        meta_owner = X.meta(1)
        st, page = X.profile(jarb, '/wp-admin/user-edit.php?user_id=1')
        check('KIEM AM: editor (bob) khong mo duoc ho so cua owner de dat lai', 'wppocket_2fa_reset' not in page and ('not allowed' in page.lower() or st in (302, 403)), st)
        f = {'action': 'update', 'user_id': '1', 'wppocket_2fa_reset': '1', '_wpnonce': 'sai'}
        st, txt, _, _ = S.req('POST', '/wp-admin/user-edit.php', '203.0.113.10', f, jarb)
        check('KIEM AM: bob POST thang dat lai cho owner -> that bai, hai buoc cua owner con nguyen', X.meta(1) == meta_owner and meta_owner != '', st)
        st, pagebob = X.profile(jarb)
        check('bob thay trang thai ON cua CHINH minh (khong thay cua nguoi khac)', st == 200 and 'ON</strong> for this account' in pagebob and 'wppocket_2fa_reset' not in pagebob, st)

        print('== 9. cong tat khan cap lamp-run/twofa-off ==')
        S.flag('twofa-off')
        ok, e, _ = X.login('owner', PW, ip='203.0.113.11')
        check('co twofa-off: DUNG mat khau la vao duoc du da bat hai buoc', ok, e)
        st, page, _, _ = S.req('GET', '/wp-login.php')
        check('co twofa-off: o nhap ma bien mat', 'wppocket_otp' not in page)
        st, page = X.profile(jar)
        check('co twofa-off: trang Ho so noi ro dang tat toan site', 'Switched off for the whole site' in page, st)
        S.flag('twofa-off', False)
        ok, e, _ = X.login('owner', PW, ip='203.0.113.11')
        check('xoa co: hai buoc doi lai ngay', not ok and e == MSG, e)

        print('== 10. bi mat khong giai ma duoc (doi muoi AUTH_KEY, sua meta): KHONG khoa chu site ==')
        cfg = os.path.join(S.site, 'wp-config.php')
        orig = open(cfg).read()
        before = S.events()
        open(cfg, 'w').write(orig.replace("define('AUTH_KEY','a')", "define('AUTH_KEY','muoi-moi')"))
        ok, e, _ = X.login('owner', PW, ip='203.0.113.12')
        check('doi AUTH_KEY lam bi mat khong doc duoc: owner van dang nhap duoc chi bang mat khau (khong tu khoa)', ok, e)
        ok, e, _ = X.login('owner', PW, ip='203.0.113.12')
        evn = S.events()[len(before):]
        check('su kien khan "2FA KHONG DOC DUOC" ghi DUNG 1 LAN (khong tran nhat ky khi bi thu lien tuc)', evn.count('2FA KHONG DOC DUOC') == 1, evn[:300])
        open(cfg, 'w').write(orig)
        ok, e, _ = X.login('owner', PW, ip='203.0.113.12')
        check('khoi phuc dung AUTH_KEY: hai buoc doi lai', not ok and e == MSG, e)
        S.cli("update_user_meta(1, 'wppocket_2fa', wp_slash(wp_json_encode(array('v'=>1,'on'=>1,'s'=>'s1:@@rac','r'=>array(),'l'=>0))));")
        ok, e, _ = X.login('owner', PW, ip='203.0.113.12')
        check('meta bi sua thanh rac: cung KHONG khoa (mat khau dang nhap duoc)', ok, e)
        S.cli("update_user_meta(1, 'wppocket_2fa', 'khong-phai-json');")
        ok, e, _ = X.login('owner', PW, ip='203.0.113.12')
        check('meta khong phai JSON: coi nhu chua bat (khong loi, khong khoa)', ok, e)

        print('== 11. lop nap nuot loi: logic hong KHONG lam hong ca site ==')
        logic = os.path.join(mu, 'wppocket-2fa', '2fa.php')
        good = open(logic).read()
        for label, body in (('loi cu phap (ParseError)', '<?php\nthis is not { php ((('), ('nem ngoai le', '<?php\nthrow new RuntimeException("x");'), ('goi ham khong ton tai', '<?php\nundefined_function_zzz();')):
            open(logic, 'w').write(body)
            st, page, _, _ = S.req('GET', '/')
            stl, pagel, _, _ = S.req('GET', '/wp-login.php')
            ok, e, _ = X.login('bob', 'Bob-Pa55-word!', ip='203.0.113.13')
            check('logic %s: trang chu 200, trang dang nhap 200, dang nhap van chay (chi mat lop hai buoc)' % label, st == 200 and stl == 200 and ok, (st, stl, e))
        open(logic, 'w').write(good)
        S.cli("update_user_meta(1, 'wppocket_2fa', wp_slash(wp_json_encode(array('v'=>1,'on'=>1,'s'=>'s1:@@rac','r'=>array(),'l'=>0))));")
        S.cli("delete_user_meta(1, 'wppocket_2fa');")

        print('== 12. bo quet ma doc nhan biet 2 file 2FA la file cua he thong ==')
        res, out = WR.scan(S)
        mine = [f for f in res.get('findings', []) if 'wppocket-2fa' in json.dumps(f)]
        check('quet: 2 file 2FA nguyen ban KHONG bi bao (khong bao nham file cua chinh app)', res != {} and not mine, mine)
        open(logic, 'a').write("\n@eval($_POST['x']);\n")
        res, out = WR.scan(S)
        mine = [f for f in res.get('findings', []) if 'wppocket-2fa' in json.dumps(f)]
        check('quet: sua file 2FA (them eval tu request) -> bi bao muc cao tro len', any(f.get('sev') in ('critical', 'high') for f in mine), mine)
        open(logic, 'w').write(good)

        print('== 13. moi dong su kien 2FA do PHP that ghi duoc ung dung Android phan loai ==')
        lines = [l for l in S.events().split('\n') if l.strip()]
        check('co su kien 2FA that trong nhat ky', sum(1 for l in lines if ' 2FA ' in l) >= 6, len(lines))
        kt = open(os.path.join(SRC, 'MonitorLogic.kt'), encoding='utf-8').read()
        urg = re.findall(r'"([^"]+)"', re.search(r'SECURITY_URGENT = listOf\(([^)]*)\)', kt).group(1))
        note = re.findall(r'"([^"]+)"', re.search(r'SECURITY_NOTICE = listOf\(([^)]*)\)', kt).group(1))
        evs = [re.search(r'ip=\S+\s+(.*)', l).group(1) for l in lines if re.search(r'ip=\S+\s+(.*)', l)]
        two = [e for e in evs if e.startswith('2FA ')]
        unclassified = [e for e in two if not any(e.startswith(p) for p in urg + note)]
        check('Python: moi su kien "2FA ..." khop mot tien to nghiem trong/luu y trong MonitorLogic.kt', not unclassified, unclassified[:3])
        if shutil.which('kotlinc') and shutil.which('kotlin'):
            eu = sum(1 for e in evs if any(e.startswith(p) for p in urg))
            en = sum(1 for e in evs if any(e.startswith(p) for p in note))
            eb = sum(1 for e in evs if e.startswith('IP bi tu dong chan'))
            out = tempfile.mkdtemp(prefix='twofa-kt-')
            try:
                r = subprocess.run(['kotlinc', '-nowarn', os.path.join(SRC, 'MonitorLogic.kt'), os.path.join(SRC, 'AlertThresholds.kt'), os.path.join(HERE, 'SecurityEventsContractTest.kt'), '-d', out], capture_output=True, text=True)
                check('Kotlin bien dich', r.returncode == 0, r.stderr[-300:])
                if r.returncode == 0:
                    r = subprocess.run(['kotlin', '-cp', out, 'SecurityEventsContractTestKt', os.path.join(S.run, 'security-events.log'), str(eu), str(en), str(eb)], capture_output=True, text=True)
                    check('Kotlin: nhat ky do PHP that + WordPress that ghi -> moi dong duoc phan loai, so dem khop', r.returncode == 0 and 'FAIL' not in r.stdout, r.stdout[-500:] + r.stderr[-200:])
            finally:
                shutil.rmtree(out, ignore_errors=True)
        else:
            print('(bo qua phan Kotlin: khong co kotlinc/kotlin)')
        perr = os.path.join(S.tmp, 'php-error.log')
        errs = open(perr).read() if os.path.exists(perr) else ''
        errs = '\n'.join(l for l in errs.split('\n') if 'wppocket-2fa' in l and 'RuntimeException' not in l and 'undefined_function_zzz' not in l and 'not { php' not in l and 'syntax error' not in l.lower() and 'Call to undefined function undefined' not in l)
        check('nhat ky loi PHP khong co canh bao/loi nao tu file 2FA hop le (ngoai cac loi chu y gay o muc 11)', errs.strip() == '', errs[:300])
    finally:
        S.stop()
        shutil.rmtree(S.tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
