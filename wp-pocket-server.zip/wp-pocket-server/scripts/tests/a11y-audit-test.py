#!/usr/bin/env python3
"""J8 (PDF 2; HANDOFF.md muc 1bq-H): kiem chung ra soat tro nang - layout that SACH, bo ra soat KHONG bi mu (doi chung am tren ban sao layout that),
cac hop thoai tao bang ma (QR, nguong canh bao) co mo ta cho TalkBack. Khong thay the thu bang TalkBack that."""
import copy, os, re, subprocess, sys
import xml.etree.ElementTree as ET

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "tools"))
import a11y_audit as A  # noqa: E402

pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


RES = os.path.join(ROOT, "app/src/main/res")
r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts/tools/a11y_audit.py"), "--self-test"], capture_output=True, text=True)
check("self-test cua bo ra soat: bat du 8/8 ma loi tren layout co loi co chu y va khong bao nham layout dung", r.returncode == 0 and "OK" in r.stdout and r.stdout.count("OK") == 2, r.stdout)
found = A.audit_dir(RES)
check("layout THAT (moi thu muc layout*) sach: 0 vi pham", not found, found[:5])

# ---------------------------------------------------------------- doi chung am tren ban sao layout that
main = ET.parse(os.path.join(RES, "layout/activity_main.xml")).getroot()
ids = {(e.get(A.ANDROID + "id") or "").replace("@+id/", ""): e for e in main.iter()}
base_ok = not A.audit_tree(main, "main")
check("layout chinh sach truoc khi bi pha", base_ok)


def mutate(fn, code, why):
    root = copy.deepcopy(main)
    byid = {(e.get(A.ANDROID + "id") or "").replace("@+id/", ""): e for e in root.iter()}
    fn(byid)
    codes = {c for c, _, _ in A.audit_tree(root, "mut")}
    check("DOI CHUNG AM: %s -> bi bat ma %s" % (why, code), code in codes, codes)


NS = A.ANDROID
mutate(lambda b: b["btnShareUrl"].set(NS + "minHeight", "0dp"), "A2", "dat lai minHeight=0dp cho nut Chia se lien ket")
mutate(lambda b: b["btnCopyAdminPassword"].set(NS + "minWidth", "20dp"), "A2", "thu nho nut Sao chep mat khau (minWidth 20dp)")
mutate(lambda b: b["tvStatus"].attrib.pop(NS + "accessibilityLiveRegion"), "A6", "bo accessibilityLiveRegion cua trang thai server")
mutate(lambda b: b["lblAutoSleepMinutes"].attrib.pop(NS + "labelFor"), "A3", "bo labelFor cua o nhap so phut Auto-Sleep")
mutate(lambda b: b["etBackupIntervalHours"].set(NS + "hint", "Gio giua cac backup"), "A8", "hint chuoi cung thay vi @string/")
mutate(lambda b: b["tvStatus"].set(NS + "textSize", "18dp"), "A5", "doi textSize sang dp (khong theo co chu nguoi dung)")
mutate(lambda b: b["btnShareUrl"].set(NS + "importantForAccessibility", "no"), "A7", "an nut bam duoc khoi TalkBack")
check("khong phai moi 'thay doi' deu bi bao: tvDeviceStatus KHONG co live region (co y - doi nhiet do lien tuc) va khong bi bao nham", "tvDeviceStatus" in ids and "accessibilityLiveRegion" not in str(ids["tvDeviceStatus"].attrib))

# ---------------------------------------------------------------- hop thoai tao bang ma (khong co layout XML de ra soat)
ma = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/MainActivity.kt"), encoding="utf-8").read()
qr_block = ma[ma.index("private fun shareUrl()"): ma.index("private fun showAlertSettings()")]
check("hop thoai QR: ImageView co contentDescription lay tu @string (qr_content_desc co URL)", re.search(r"ImageView\(this\)\.apply \{[\s\S]*?contentDescription = getString\(R\.string\.qr_content_desc, url\)", qr_block) is not None)
al_block = ma[ma.index("private fun showAlertSettings()"): ma.index("private fun ruleErrorText")]
check("hop thoai nguong canh bao: moi o so tao bang field() deu dat contentDescription = nhan; o quy tac co hint", "contentDescription = label" in al_block and "hint = getString(R.string.alert_rules_hint)" in al_block)
check("loi nhap hien tai o (EditText.error) thay vi chi Toast: TalkBack doc duoc loi va vi tri", al_block.count(".error = ") >= 3)
check("rung (haptic) co trong MainActivity (J1) va KHONG la kenh thong tin duy nhat: moi nut van co chu", "performHapticFeedback" in ma)

# ---------------------------------------------------------------- tai lieu
doc = open(os.path.join(ROOT, "docs/ACCESSIBILITY.md"), encoding="utf-8").read()
for tok in ("a11y_audit.py", "48dp", "TalkBack", "accessibilityLiveRegion", "Chưa kiểm", "200%", "độ tương phản"):
    check("docs/ACCESSIBILITY.md nhac '%s'" % tok, tok.lower() in doc.lower())
rules = sorted(set(re.findall(r"\bA[1-8]\b", open(os.path.join(ROOT, "scripts/tools/a11y_audit.py"), encoding="utf-8").read().split('"""')[1])))
check("moi ma A1..A8 duoc mo ta trong ACCESSIBILITY.md", all(c in doc for c in rules) and len(rules) == 8, rules)

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
