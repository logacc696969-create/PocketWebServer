#!/usr/bin/env python3
"""H2 (PDF 1; HANDOFF.md muc 1bq-C): kiem chung DAY NOI cua may chu WSGI vao quy trinh build Python.

1. validate_config / apply_preset chap nhan va tu choi dung khoa "wsgi" (module:callable, loai tru entry, chi runtime python, chan chen lenh).
2. Ham bash generic_python_app_args dung cho 3 che do x 2 kieu (va GIU NGUYEN hanh vi cu cua entry / http.server).
3. MO PHONG TRIEN KHAI: dat wpp_wsgi.py vao <staging>/_supervisor nhu build, thay token __PORT__/__APP_PORT__/__DOCROOT__ GIONG HET start-generic.sh,
   chay lenh THAT voi cwd = docroot, goi HTTP that: che do proxy tin X-Forwarded-For, che do direct thi khong.
4. python.sh: doc wsgi/entry va cai may chu TRUOC khi dong goi www.zip; chan khai bao ca hai; runtime.json giu nguyen ky tu dac biet.
"""
import json, os, re, shutil, signal, socket, subprocess, sys, tempfile, time, http.client

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
os.chdir(ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts", "tools"))
import validate_config as vc  # noqa: E402

pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, extra)


def rd(p):
    return open(os.path.join(ROOT, p), encoding="utf-8").read()


def bash(script):
    r = subprocess.run(["bash", "-c", "set -u; cd %s; source scripts/lib/generic_runtime.sh; %s" % (ROOT, script)], capture_output=True, text=True, timeout=60)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


# ---------------------------------------------------------------- 1. cau hinh
base = json.load(open(os.path.join(ROOT, "presets", "python-wsgi.json"), encoding="utf-8"))
check("preset python-wsgi hop le (validate_config), co wsgi=app:app, entry rong, front_proxy=true", vc.check_text(json.dumps(base)) == [] and base["wsgi"] == "app:app" and base["entry"] == "" and base["front_proxy"] is True)
for ok_val in ("app:app", "mysite.wsgi:application", "app:create_app()", "pkg.sub.mod:obj.attr", "_x1:_y2"):
    c = dict(base, wsgi=ok_val)
    check("wsgi %r hop le" % ok_val, vc.check_text(json.dumps(c)) == [], str(vc.check_text(json.dumps(c))))
for bad in ("app", "app:", ":app", "app app", "app:app; rm -rf /", "app:app$(id)", "1app:app", "app:app()()", "app:app()x", "a" * 120 + ":app", "app:app\n", "../x:app", "app:../x"):
    errs = vc.check_text(json.dumps(dict(base, wsgi=bad)))
    check("wsgi %r bi tu choi" % bad[:30], any("wsgi" in e for e in errs), str(errs))
check("wsgi + entry cung luc bi tu choi (thong bao liet ke 'entry, wsgi')", any("MOT trong entry, wsgi hoac asgi" in e and "entry" in e and "wsgi" in e for e in vc.check_text(json.dumps(dict(base, entry="app.py")))))
abase = json.load(open(os.path.join(ROOT, "presets", "python-asgi.json"), encoding="utf-8"))
check("preset python-asgi hop le: asgi=app:app, wsgi/entry rong, front_proxy=true", vc.check_text(json.dumps(abase)) == [] and abase["asgi"] == "app:app" and abase["wsgi"] == "" and abase["entry"] == "" and abase["front_proxy"] is True)
check("asgi + wsgi / asgi + entry / ca ba cung luc bi tu choi", all(any("MOT trong entry, wsgi hoac asgi" in e for e in vc.check_text(json.dumps(c))) for c in (dict(abase, wsgi="app:app"), dict(abase, entry="app.py"), dict(abase, wsgi="a:b", entry="x.py"))))
for bad in ("app", "app app", "app:app; rm -rf /", "1app:app", "app:app$(id)", "a" * 120 + ":app"):
    check("asgi %r bi tu choi" % bad[:30], any("asgi" in e for e in vc.check_text(json.dumps(dict(abase, asgi=bad)))))
check("asgi voi runtime node/php/static bi tu choi; asgi khong phai chuoi (5, [], true) bi tu choi", all(any("chi ap dung cho runtime python" in e for e in vc.check_text(json.dumps(dict(abase, runtime=rt)))) for rt in ("node", "php", "static")) and all(any("asgi phai la chuoi" in e for e in vc.check_text(json.dumps(dict(abase, asgi=v)))) for v in (5, ["a:b"], True)))
check("khoa asgi co trong TOP_KEYS; go sai 'asig' bi bat", "asgi" in vc.TOP_KEYS and any("asgi" in e and "asig" in e for e in vc.check_text(json.dumps(dict(abase, asig="app:app")))))
check("wsgi voi runtime node/php/static bi tu choi", all(any("chi ap dung cho runtime python" in e for e in vc.check_text(json.dumps(dict(base, runtime=rt)))) for rt in ("node", "php", "static")))
check("wsgi khong phai chuoi (5, [], true) bi tu choi", all(any("wsgi phai la chuoi" in e for e in vc.check_text(json.dumps(dict(base, wsgi=v)))) for v in (5, ["a:b"], True)))
check("go sai 'wsig' bi bat kem goi y 'wsgi'", any("wsgi" in e and "wsig" in e for e in vc.check_text(json.dumps(dict(base, wsig="app:app")))))
check("khoa wsgi co trong TOP_KEYS cua validate_config", "wsgi" in vc.TOP_KEYS)
check("khong khai bao wsgi: cau hinh cu (python-local) van hop le", vc.check_text(open(os.path.join(ROOT, "presets", "python-local.json")).read()) == [])

# ---------------------------------------------------------------- 2. ham dung tham so
cases = [
    ("proxy", "", "app:app", "__DOCROOT__/_supervisor/wpp_wsgi.py app:app --port __APP_PORT__ --bind 127.0.0.1 --trust-proxy"),
    ("direct", "", "app:app", "__DOCROOT__/_supervisor/wpp_wsgi.py app:app --port __PORT__ --bind 0.0.0.0"),
    ("proxy", "app.py", "", "__DOCROOT__/app.py"),
    ("direct", "app.py", "", "__DOCROOT__/app.py"),
    ("proxy", "", "", "-m http.server __APP_PORT__ --directory __DOCROOT__ --bind 127.0.0.1"),
    ("direct", "", "", "-m http.server __PORT__ --directory __DOCROOT__ --bind 0.0.0.0"),
    ("proxy", "", "app:create_app()", "__DOCROOT__/_supervisor/wpp_wsgi.py app:create_app() --port __APP_PORT__ --bind 127.0.0.1 --trust-proxy"),
]
asgi_cases = [
    ("proxy", "", "", "app:app", "__DOCROOT__/_supervisor/wpp_wsgi.py app:app --asgi --port __APP_PORT__ --bind 127.0.0.1 --trust-proxy"),
    ("direct", "", "", "app:app", "__DOCROOT__/_supervisor/wpp_wsgi.py app:app --asgi --port __PORT__ --bind 0.0.0.0"),
    ("proxy", "", "", "main:create()", "__DOCROOT__/_supervisor/wpp_wsgi.py main:create() --asgi --port __APP_PORT__ --bind 127.0.0.1 --trust-proxy"),
    ("proxy", "", "w:w", "a:a", "__DOCROOT__/_supervisor/wpp_wsgi.py a:a --asgi --port __APP_PORT__ --bind 127.0.0.1 --trust-proxy"),  # asgi thang wsgi neu lot qua validate (phong ho)
]
for mode, entry, wsgi, want in cases:
    rc, out, err = bash("generic_python_app_args '%s' '%s' '%s'" % (mode, entry, wsgi))
    check("generic_python_app_args %s entry=%r wsgi=%r" % (mode, entry, wsgi), rc == 0 and out == want, "%r != %r %s" % (out, want, err))
for mode, entry, wsgi, asgi, want in asgi_cases:
    rc, out, err = bash("generic_python_app_args '%s' '%s' '%s' '%s'" % (mode, entry, wsgi, asgi))
    check("generic_python_app_args %s asgi=%r (kem --asgi)" % (mode, asgi), rc == 0 and out == want, "%r != %r %s" % (out, want, err))
rc, out, err = bash("generic_python_app_args proxy '' 'app:app'")
check("goi cu 3 doi so (khong asgi) van chay dung nhu truoc (khong co --asgi)", rc == 0 and "--asgi" not in out and out.endswith("--trust-proxy"))
check("tin X-Forwarded-* CHI o che do proxy (--trust-proxy khong xuat hien o direct)", "--trust-proxy" not in cases[1][3] and "--trust-proxy" in cases[0][3])
check("direct bind 0.0.0.0 cong PORT; proxy bind 127.0.0.1 cong APP_PORT (khach khong vao thang may chu WSGI khi co nginx)", "--bind 127.0.0.1" in cases[0][3] and "__APP_PORT__" in cases[0][3] and "--bind 0.0.0.0" in cases[1][3] and "__PORT__" in cases[1][3])

# ---------------------------------------------------------------- 3. mo phong trien khai
sg = rd("scripts/runtimes/templates/start-generic.sh")
sed_expr = re.search(r'sed -e "s#__PORT__#\$PORT#g" -e "s#__APP_PORT__#\$APP_PORT#g" -e "s#__DOCROOT__#\$DOCROOT#g"', sg)
check("start-generic.sh thay token bang dung 3 bieu thuc sed ma bai kiem nay mo phong", sed_expr is not None)

W = tempfile.mkdtemp()
stg = os.path.join(W, "www")
os.makedirs(stg)
rc, out, err = bash("generic_install_wsgi_server '%s'" % stg)
inst = os.path.join(stg, "_supervisor", "wpp_wsgi.py")
check("generic_install_wsgi_server dat wpp_wsgi.py vao <staging>/_supervisor, noi dung giong het ban goc", rc == 0 and os.path.exists(inst) and open(inst, "rb").read() == open(os.path.join(ROOT, "scripts/runtimes/wpp_wsgi.py"), "rb").read(), err)
with open(os.path.join(stg, "app.py"), "w") as f:
    f.write("def app(environ, start_response):\n    body = ('%s|%s|%s' % (environ['PATH_INFO'], environ['REMOTE_ADDR'], environ['wsgi.url_scheme'])).encode()\n    start_response('200 OK', [('Content-Type','text/plain'), ('Content-Length', str(len(body)))])\n    return [body]\n\ndef create_app():\n    return app\n")


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def deploy(mode, wsgi, asgi=""):
    port, app_port = free_port(), free_port()
    rc, args, err = bash("generic_python_app_args '%s' '' '%s' '%s'" % (mode, wsgi, asgi))
    # GIONG HET start-generic.sh: sed thay token roi "$ARGS" bi shell tach tu
    sub = subprocess.run(["sed", "-e", "s#__PORT__#%d#g" % port, "-e", "s#__APP_PORT__#%d#g" % app_port, "-e", "s#__DOCROOT__#%s#g" % stg], input=args, capture_output=True, text=True).stdout
    # Giong het start-generic.sh: ARGS la BIEN, `exec "$BIN" $ARGS` chi tach tu (khong phan tich lai cu phap: "()" cua app:create_app() la ky tu thuong).
    cmd = 'exec "$0" $1   # ARGS=' + sub
    p = subprocess.Popen(["sh", "-c", 'exec "$0" $1', sys.executable, sub], cwd=stg, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    line = p.stdout.readline()
    if not line:  # tien trinh thoat truoc khi in "listening": tra stderr de loi hien ro thay vi "Connection refused" kho hieu
        line = "(thoat som) " + p.stderr.read() + " cmd=" + cmd
    return p, (app_port if mode == "proxy" else port), line


def get(port, path, headers=None):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    c.request("GET", path, headers=headers or {})
    r = c.getresponse()
    body = r.read().decode()
    c.close()
    return r.status, body


for wsgi in ("app:app", "app:create_app()"):
    p, port, line = deploy("proxy", wsgi)
    st, body = get(port, "/x", {"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})
    check("trien khai PROXY %s: lenh that (sau sed + shell tach tu) chay, nghe 127.0.0.1:APP_PORT, tin X-Forwarded-* -> '/x|203.0.113.9|https'" % wsgi, "listening 127.0.0.1:%d" % port in line and st == 200 and body == "/x|203.0.113.9|https", "%s %s %s" % (line, st, body))
    p.send_signal(signal.SIGTERM)
    check("proxy %s: SIGTERM -> thoat ma 0" % wsgi, p.wait(5) == 0)
with open(os.path.join(stg, "asgi_app.py"), "w") as f:
    f.write("async def app(scope, receive, send):\n    if scope['type'] == 'lifespan':\n        while True:\n            m = await receive()\n            if m['type'] == 'lifespan.startup':\n                await send({'type': 'lifespan.startup.complete'})\n            else:\n                await send({'type': 'lifespan.shutdown.complete'})\n                return\n    await receive()\n    body = ('%s|%s|%s' % (scope['path'], scope['client'][0], scope['scheme'])).encode()\n    await send({'type': 'http.response.start', 'status': 200, 'headers': [(b'content-type', b'text/plain')]})\n    await send({'type': 'http.response.body', 'body': body})\n\ndef create_app():\n    return app\n")
for asgi in ("asgi_app:app", "asgi_app:create_app()"):
    p, port, line = deploy("proxy", "", asgi)
    st, body = get(port, "/x", {"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})
    check("trien khai PROXY ASGI %s: lenh that (sau sed + shell tach tu) chay voi --asgi, nghe 127.0.0.1:APP_PORT, tin X-Forwarded-* -> '/x|203.0.113.9|https'" % asgi, "listening 127.0.0.1:%d" % port in line and "asgi_app" in line and st == 200 and body == "/x|203.0.113.9|https", "%s %s %s" % (line, st, body))
    p.send_signal(signal.SIGTERM)
    check("proxy ASGI %s: SIGTERM -> thoat ma 0" % asgi, p.wait(5) == 0)
p, port, line = deploy("direct", "", "asgi_app:app")
st, body = get(port, "/y", {"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})
check("trien khai DIRECT ASGI: nghe 0.0.0.0:PORT, KHONG tin X-Forwarded-* -> '/y|127.0.0.1|http'", "listening 0.0.0.0:%d" % port in line and st == 200 and body == "/y|127.0.0.1|http", "%s %s" % (line, body))
p.send_signal(signal.SIGTERM)
p.wait(5)
p, port, line = deploy("direct", "app:app")
st, body = get(port, "/y", {"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})
check("trien khai DIRECT: nghe 0.0.0.0:PORT, KHONG tin X-Forwarded-* (chong gia IP) -> '/y|127.0.0.1|http'", "listening 0.0.0.0:%d" % port in line and st == 200 and body == "/y|127.0.0.1|http", "%s %s" % (line, body))
p.send_signal(signal.SIGTERM)
p.wait(5)
shutil.rmtree(W, ignore_errors=True)

# ---------------------------------------------------------------- 4. python.sh + runtime.json
sh = rd("scripts/runtimes/python.sh")
check("python.sh doc wsgi/entry TRUOC generic_install_supervisor, cai may chu WSGI TRUOC make_reproducible_zip (nam trong www.zip)",
      sh.index('WSGI="$(jq') < sh.index("generic_install_supervisor") < sh.index("generic_install_wsgi_server") < sh.index("make_reproducible_zip"))
check("python.sh tu choi khai bao nhieu hon MOT trong entry/wsgi/asgi (lop bao ve thu hai ngoai validate_config): dem N_DECLARED > 1 roi exit 1", 'N_DECLARED=$((N_DECLARED + 1))' in sh and sh.count("N_DECLARED=$((N_DECLARED + 1))") == 3 and re.search(r'if \[\[ "\$N_DECLARED" -gt 1 \]\]; then[\s\S]{0,200}exit 1', sh) is not None)
check("python.sh cai may chu di kem khi co wsgi HOAC asgi (truoc make_reproducible_zip) va truyen ASGI vao generic_python_app_args", 'if [[ -n "$WSGI" || -n "$ASGI" ]]; then generic_install_wsgi_server' in sh and '"$ENTRY" "$WSGI" "$ASGI"' in sh and sh.index("generic_install_wsgi_server") < sh.index("make_reproducible_zip"))
check("python.sh dung generic_python_app_args (khong con nhanh http.server/entry tu viet lai)", "generic_python_app_args" in sh and "-m http.server" not in sh)
rc, out, err = bash("W=$(mktemp -d); generic_write_runtime_json \"$W\" 8080 libruntimesrv.so proxy libruntimesrv.so \"$(generic_python_app_args proxy '' 'app:create_app()')\" '' '\"PYTHONUNBUFFERED\": \"1\"'; cat \"$W/runtime.json\"")
d = json.loads(out) if rc == 0 else {}
check("runtime.json: GEN_APP_ARGS giu nguyen 'app:create_app()' va token __APP_PORT__/__DOCROOT__ (JSON that)", rc == 0 and "wpp_wsgi.py app:create_app() --port __APP_PORT__" in d.get("env", {}).get("GEN_APP_ARGS", "") and d["env"]["GEN_MODE"] == "proxy", out[:200] + err)
ci = rd(".github/workflows/build-apk.yml")
check("CI chay wsgi-server-test.py, asgi-server-test.py va wsgi-wiring-test.py", "wsgi-server-test.py" in ci and "asgi-server-test.py" in ci and "wsgi-wiring-test.py" in ci)
check("docs/PYTHON_WSGI.md ton tai, noi ro WSGI (khong ASGI/WebSocket) va cach dung", os.path.exists(os.path.join(ROOT, "docs/PYTHON_WSGI.md")) and "ASGI" in rd("docs/PYTHON_WSGI.md") and '"wsgi": "app:app"' in rd("docs/PYTHON_WSGI.md"))
check("wpp_wsgi.py nam trong danh sach tep CI cua shellcheck/pyflakes neu co (khong bat buoc) - python compile", subprocess.run([sys.executable, "-m", "py_compile", os.path.join(ROOT, "scripts/runtimes/wpp_wsgi.py")], capture_output=True).returncode == 0)

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
