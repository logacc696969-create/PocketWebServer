#!/usr/bin/env python3
"""I4 (PDF 2; HANDOFF.md muc 1bq-I): kiem chung mu-plugin toi uu anh WordPress BANG PHAN TICH VAN BAN (khong co PHP trong moi truong phat trien).

KHONG chay duoc plugin voi WordPress that - bai nay chi bat loi cu phap/an toan/hop dong hook; neu co PHP thi chay them 'php -l'. Phan ket luan 'chay dung' phai
cho CI/may that. Bat: dau ngoac mat can bang, ham ngoai danh sach cho phep, ham nguy hiem, cu phap PHP > 7.4, sai ten hook/so tham so, xoa tep khi chua bat
tuy chon, mac dinh/khoang lech tai lieu.
"""
import os, re, shutil, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
T = os.path.join(ROOT, "scripts/runtimes/templates/")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def rd(p):
    return open(p, encoding="utf-8").read()


loader, logic = rd(T + "wppocket-images-loader.php"), rd(T + "wppocket-images-optimize.php")


def strip_php(src):
    """Bo chu thich va noi dung chuoi (giu dau nhay) de dem ngoac / tim ham chinh xac. Tra ve (code, loi)."""
    out, i, n, err = [], 0, len(src), None
    while i < n:
        c = src[i]
        if src.startswith("/*", i):
            j = src.find("*/", i + 2)
            if j < 0:
                return "".join(out), "chu thich /* khong dong"
            i = j + 2
        elif src.startswith("//", i) or c == "#":
            j = src.find("\n", i)
            i = n if j < 0 else j
        elif c in "'\"":
            q, j = c, i + 1
            while j < n and src[j] != q:
                j += 2 if src[j] == "\\" else 1
            if j >= n:
                return "".join(out), "chuoi %s khong dong" % q
            out.append(q + q)
            i = j + 1
        else:
            out.append(c)
            i += 1
    return "".join(out), err


def balanced(code):
    stack, pairs = [], {")": "(", "]": "[", "}": "{"}
    for ch in code:
        if ch in "([{":
            stack.append(ch)
        elif ch in ")]}":
            if not stack or stack.pop() != pairs[ch]:
                return False
    return not stack


# ---------------------------------------------------------------- 1. cau truc 2 tep + cai dat
check("ca 2 tep bat dau dung '<?php' va KHONG co '?>' dong (tranh in ky tu thua lam hong header)", loader.startswith("<?php\n") and logic.startswith("<?php\n") and "?>" not in loader.replace("?->", "") and "?>" not in logic)
check("ca 2 tep co chan ABSPATH (khong chay duoc neu goi truc tiep)", "if (!defined('ABSPATH'))" in loader and "if (!defined('ABSPATH'))" in logic)
check("loader NAP logic qua try/catch Throwable (loi cu phap/ParseError trong logic khong lam hong ca site)", re.search(r"try \{\s*require __DIR__ \. '/wppocket-images/optimize\.php';\s*\} catch \(\\Throwable \$e\)", loader) is not None)
check("loader cuc ngan (< 25 dong code) - moi request deu nap no", len([l for l in loader.split("\n") if l.strip() and not l.strip().startswith(("*", "/*", "//"))]) < 25)
ss = rd(os.path.join(ROOT, "scripts/lib/site_source.sh"))
check("site_source.sh cai du 2 tep dung duong dan (loader -> mu-plugins/wppocket-images.php, logic -> mu-plugins/wppocket-images/optimize.php)", 'cp scripts/runtimes/templates/wppocket-images-loader.php "$staging/wp-content/mu-plugins/wppocket-images.php"' in ss and 'cp scripts/runtimes/templates/wppocket-images-optimize.php "$staging/wp-content/mu-plugins/wppocket-images/optimize.php"' in ss and 'mkdir -p "$staging/wp-content/mu-plugins/wppocket-images"' in ss)
check("cai dat nam TRONG nhanh WordPress (sau pagecache, truoc ';;' cua nhanh), khong lam anh huong runtime khac", ss.index("wppocket-images-optimize.php") > ss.index("wppocket-pagecache-purge.php") and ss.index("wppocket-images-optimize.php") < ss.index("    git)"))

# ---------------------------------------------------------------- 2. phan tich van ban
code, err = strip_php(logic)
check("logic: khong co chu thich/chuoi bi bo ngo, ngoac () [] {} can bang", err is None and balanced(code), err)
lcode, lerr = strip_php(loader)
check("loader: ngoac can bang", lerr is None and balanced(lcode), lerr)
KEYWORDS = {"if", "function", "array", "isset", "empty", "unset", "exit", "require", "return", "elseif", "while", "for", "foreach", "switch", "catch", "try", "echo", "list"}
ALLOWED = {"defined", "constant", "is_int", "is_string", "ctype_digit", "function_exists", "wp_image_editor_supports", "is_array", "basename", "wp_get_upload_dir", "rtrim", "dirname", "file_exists", "wp_delete_file", "add_filter", "wpp_img_int", "wpp_img_flag"}
calls = set(re.findall(r"(?<![>:$\w])\b([a-z_][a-z0-9_]*)\s*\(", re.sub(r"\bfunction\s+[a-z_0-9]+\s*\(", "function (", code))) - KEYWORDS
check("moi ham duoc goi nam trong danh sach cho phep (ham PHP/WordPress co that): %s" % sorted(calls), calls <= ALLOWED, sorted(calls - ALLOWED))
danger = [f for f in ("eval", "exec", "system", "shell_exec", "passthru", "popen", "proc_open", "file_put_contents", "unlink", "fopen", "file_get_contents", "curl_init", "include", "include_once", "require_once", "base64_decode", "assert", "create_function", "preg_replace") if re.search(r"(?<![>:$\w])\b%s\s*\(" % f, code)]
check("khong co ham nguy hiem (eval/exec/system/unlink/fopen/curl/include/base64_decode...)", not danger, danger)
check("tuong thich PHP 7.4: khong dung match, ?->, enum, readonly, kieu hop (int|string), tham so dat ten, kieu tra ve 'static'/'mixed'", not re.search(r"\bmatch\s*\(|\?->|\benum\b|\breadonly\b|\(\s*[a-z]+\s*\|\s*[a-z]+|\bmixed\b|\bnever\b|\w+:\s*(?=\$?\w+,)(?<!\?)\b[a-z_]+:\s", code), re.findall(r"\bmatch\s*\(|\?->|\benum\b|\breadonly\b", code))

hooks = re.findall(r"add_filter\('([a-z_]+)',\s*function \(([^)]*)\)\s*\{[\s\S]*?\},\s*(\d+)(?:,\s*(\d+))?\);", logic)
spec = {"big_image_size_threshold": (1, 1), "wp_editor_set_quality": (2, 2), "image_editor_output_format": (3, 3), "wp_generate_attachment_metadata": (2, 2)}
check("dung 4 filter, ten dung hook cua WordPress core: %s" % [h[0] for h in hooks], sorted(h[0] for h in hooks) == sorted(spec))
bad = []
for name, params, prio, acc in hooks:
    n_params = len([p for p in params.split(",") if p.strip()])
    n_acc = int(acc) if acc else 1
    if n_params != spec[name][0] or n_acc != spec[name][1]:
        bad.append((name, n_params, n_acc))
check("so tham so closure == accepted_args == so tham so WordPress goi (1/2/3/2)", not bad and len(hooks) == 4, bad)
check("moi closure co tham so thu 2+ deu co gia tri mac dinh (WordPress cu goi it tham so hon van khong loi)", all(all("=" in p for p in params.split(",")[1:] if p.strip()) for _, params, _, _ in hooks))
check("uu tien (priority) >= 20: chay SAU mac dinh cua WordPress/plugin khac", all(int(h[2]) >= 20 for h in hooks))

# ---------------------------------------------------------------- 3. an toan du lieu
i_flag = logic.index("wpp_img_flag('WPP_IMG_DROP_ORIGINAL', false)")
i_del = logic.index("wp_delete_file(")
check("wp_delete_file chi xuat hien 1 lan va SAU chan 'WPP_IMG_DROP_ORIGINAL' mac dinh false (khong xoa gi khi chua bat)", logic.count("wp_delete_file(") == 1 and i_flag < i_del and re.search(r"if \(!wpp_img_flag\('WPP_IMG_DROP_ORIGINAL', false\)\) \{\s*return \$metadata;", logic) is not None)
body = logic[logic.index("wp_generate_attachment_metadata"):]
check("chi xoa khi: ten goc khong chua duong dan, KHAC ban scaled, ban scaled VA ban goc deu ton tai", "$original !== basename($original)" in body and "$original === basename((string) $metadata['file'])" in body and "file_exists($scaled) && file_exists($orig_path)" in body)
check("duong dan xoa luon duoi thu muc uploads (basedir + file/dirname cua WordPress), khong dung du lieu tu nguoi dung", "$uploads['basedir']" in body and "wp_get_upload_dir()" in body and "$_GET" not in logic and "$_POST" not in logic and "$_REQUEST" not in logic and "$_FILES" not in logic)
check("chat luong/kich thuoc luon qua wpp_img_int (kep khoang): 3 lan goi voi (mac dinh, min, max)", len(re.findall(r"wpp_img_int\('WPP_IMG_[A-Z_]+', \d+, \d+, \d+\)", logic)) == 3)
check("chi doi JPEG -> WebP (khong dong vao PNG/GIF), va chi khi wp_image_editor_supports WebP", "$formats['image/jpeg'] = 'image/webp'" in logic and "image/png" not in logic and "wp_image_editor_supports(array('mime_type' => 'image/webp'))" in logic)
check("khong ghi de cau hinh dinh dang co san cua plugin khac (chi dat khi chua co isset)", "if (!isset($formats['image/jpeg']))" in logic)

# ---------------------------------------------------------------- 4. tai lieu khop ma
doc = rd(os.path.join(ROOT, "docs/IMAGE_OPTIMIZATION.md"))
ints = re.findall(r"wpp_img_int\('(WPP_IMG_[A-Z_]+)', (\d+), (\d+), (\d+)\)", logic)
okdoc = True
for name, d, lo, hi in ints:
    row = [l for l in doc.split("\n") if ("`%s`" % name) in l and l.startswith("|")]
    if not row or ("| %s |" % d) not in row[0].replace("**", "") and ("%s px" % d) not in row[0].replace("**", "") and (" %s |" % d) not in row[0].replace("**", "") or ("(%s–%s)" % (lo, hi)) not in row[0]:
        okdoc = False
        print("   lech tai lieu:", name, d, lo, hi, row[:1])
check("tai lieu liet ke dung 3 hang so so nguyen voi mac dinh va khoang KHOP ma", okdoc and len(ints) == 3)
check("tai lieu: 2 co WPP_IMG_WEBP (mac dinh Bat) va WPP_IMG_DROP_ORIGINAL (mac dinh TAT, canh bao mat anh goc)", "`WPP_IMG_WEBP`" in doc and "**Bật**" in doc and "`WPP_IMG_DROP_ORIGINAL`" in doc and "**TẮT**" in doc and "mất ảnh gốc" in doc.lower())
check("tai lieu noi thang: chua chay voi WordPress that / khong co PHP trong moi truong phat trien", "chưa được chạy" in doc and "PHP không có sẵn" in doc)
check("docs-consistency: mac dinh 1920 > 1024 va <= 4096, WordPress mac dinh 2560 duoc ghi", "2560" in doc and "1920" in doc)

# ---------------------------------------------------------------- 5. php -l neu co
php = shutil.which("php")
if php:
    ok = all(subprocess.run([php, "-l", p], capture_output=True).returncode == 0 for p in (T + "wppocket-images-loader.php", T + "wppocket-images-optimize.php"))
    check("php -l (that) cho 2 tep", ok)
else:
    print("(khong co php: bo qua 'php -l' - CI se chay)")

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
