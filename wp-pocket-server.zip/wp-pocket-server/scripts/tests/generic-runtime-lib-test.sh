#!/usr/bin/env bash
# Kiem thu scripts/lib/generic_runtime.sh tren cay thu muc GIA kieu Termux (khong can mang). HANDOFF.md muc 1bi.
# Chay tu goc repo: bash scripts/tests/generic-runtime-lib-test.sh
set -u
cd "$(dirname "$0")/../.."
source scripts/lib/collect_libs.sh
source scripts/lib/termux_fetch.sh 2>/dev/null || true
source scripts/lib/generic_runtime.sh
pass=0; fail=0
ok() { if [ "$1" = 0 ]; then pass=$((pass+1)); echo "PASS: $2"; else fail=$((fail+1)); echo "FAIL: $2"; fi; }
W="$(mktemp -d)"
PYL="$W/ex/usr/lib/python3.12"; mkdir -p "$PYL/lib-dynload" "$PYL/encodings" "$PYL/test" "$PYL/tkinter" "$PYL/idlelib" "$PYL/__pycache__" "$PYL/site-packages/pip"
echo "# os" > "$PYL/os.py"; echo "# enc" > "$PYL/encodings/__init__.py"; echo "# t" > "$PYL/test/test_x.py"; echo "# tk" > "$PYL/tkinter/__init__.py"
echo "x" > "$PYL/__pycache__/os.cpython-312.pyc"; echo "# pip" > "$PYL/site-packages/pip/__init__.py"
echo SOCK > "$PYL/lib-dynload/_socket.cpython-312-aarch64-linux-android.so"; echo MATH > "$PYL/lib-dynload/math.cpython-312-aarch64-linux-android.so"
mkdir -p "$W/ex/usr/lib"; echo ZLIB > "$W/ex/usr/lib/libz.so.1.3.1"; ln -s libz.so.1.3.1 "$W/ex/usr/lib/libz.so.1"
OUT="$W/out"; STG="$W/stg"; mkdir -p "$OUT" "$STG"

echo "== A. generic_bundle_python_stdlib =="
VER="$(generic_bundle_python_stdlib "$W/ex" "$OUT" "$STG")"; [ "$VER" = "python3.12" ]; ok $? "nhan ra phien ban thu muc stdlib: python3.12 (duoc: $VER)"
H="$STG/_supervisor/pyhome/lib/python3.12"
[ -f "$H/os.py" ] && [ -f "$H/encodings/__init__.py" ]; ok $? "stdlib .py (os, encodings) co trong pyhome"
[ ! -e "$H/test" ] && [ ! -e "$H/tkinter" ] && [ ! -e "$H/idlelib" ] && [ ! -e "$H/site-packages" ] && [ -z "$(find "$H" -name '*.pyc' -o -name __pycache__ | head -1)" ]; ok $? "da loai test/tkinter/idlelib/site-packages/__pycache__ (giam dung luong)"
[ -f "$OUT/libpydyn__socket_cpython-312-aarch64-linux-android.so" ] && [ -f "$OUT/libpydyn_math_cpython-312-aarch64-linux-android.so" ]; ok $? "module mo rong duoc doi ten libpydyn_*.so trong out (bat dau lib, ket thuc .so)"
[ "$(cat "$OUT/libpydyn_math_cpython-312-aarch64-linux-android.so")" = "MATH" ]; ok $? "noi dung module duoc copy dung"
grep -q '^math.cpython-312-aarch64-linux-android.so libpydyn_math_cpython-312-aarch64-linux-android.so$' "$STG/_supervisor/dynload-map.txt"; ok $? "dynload-map.txt co dong anh xa ten goc -> ten moi"
[ ! -d "$PYL/lib-dynload" ]; ok $? "lib-dynload bi xoa khoi extract (de collect_shared_libs khong copy nhan doi)"
[ -d "$H/lib-dynload" ] && [ -z "$(ls "$H/lib-dynload")" ]; ok $? "pyhome co thu muc lib-dynload RONG san (supervisor se tao symlink luc chay)"
collect_shared_libs "$W/ex" "$OUT" "$W/map.txt"
[ -z "$(ls "$OUT" | grep -i 'cpython.*cpython')" ] && [ "$(ls "$OUT" | grep -c 'socket')" = 1 ]; ok $? "collect_shared_libs KHONG copy lai module lib-dynload (khong nhan doi)"
grep -q '^libz.so.1 ' "$W/map.txt"; ok $? "libz.so.1 van vao soname-map"
# khong co python3.x
mkdir -p "$W/ex2/usr/lib"; generic_bundle_python_stdlib "$W/ex2" "$OUT" "$STG" 2>/dev/null; [ $? != 0 ]; ok $? "khong co lib/python3.x -> bao loi (khong im lang)"

echo "== B. generic_install_supervisor =="
printf 'b a\nb a\nc d\n' > "$W/m.txt"
generic_install_supervisor "$STG" "$W/m.txt" false
S="$STG/_supervisor"
[ -x "$S/start-generic.sh" ] && [ "$(cat "$S/soname-map.txt")" = "$(printf 'b a\nc d')" ]; ok $? "front=false: co start-generic.sh (chay duoc), soname-map da sort -u"
[ ! -e "$S/nginx-front.conf.template" ]; ok $? "front=false: KHONG co mau nginx (APK khong mang them)"
generic_install_supervisor "$STG" "$W/m.txt" true
[ -f "$S/nginx-front.conf.template" ] && [ -f "$S/front-locations-proxy.conf.template" ] && [ -f "$S/front-locations-static.conf.template" ]; ok $? "front=true: du 3 mau nginx"

echo "== C. generic_write_runtime_json =="
generic_write_runtime_json "$W" 8080 libruntimesrv.so direct libruntimesrv.so '__DOCROOT__/server.js' '' '"NODE_ENV": "production"'
python3 - "$W/runtime.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
assert d['port'] == 8080 and d['binary'] == 'libruntimesrv.so' and d['docroot'] == 'www', d
assert d['exec'] == ['/system/bin/sh', '${DOCROOT}/_supervisor/start-generic.sh'], d['exec']
assert d['env']['GEN_MODE'] == 'direct' and d['env']['GEN_APP_ARGS'] == '__DOCROOT__/server.js' and d['env']['NODE_ENV'] == 'production' and d['env']['GEN_WEB_SUBDIR'] == '', d['env']
PY
ok $? "runtime.json hop le: exec = sh start-generic.sh, env GEN_* + NODE_ENV (JSON that, khong phai chuoi noi)"
generic_write_runtime_json "$W" 9090 libnginx.so static '' '' 'dist' ''
python3 -c "
import json; d=json.load(open('$W/runtime.json')); assert d['port']==9090 and d['binary']=='libnginx.so' and d['env']['GEN_MODE']=='static' and d['env']['GEN_WEB_SUBDIR']=='dist'" ; ok $? "che do static: binary=libnginx.so, GEN_WEB_SUBDIR=dist"
generic_write_runtime_json "$W" 8080 libruntimesrv.so proxy libruntimesrv.so '-m http.server __APP_PORT__ --directory __DOCROOT__' '' '"PYTHONUNBUFFERED": "1", "PYTHONPATH": "${DOCROOT}/.pylibs"'
python3 -c "
import json; d=json.load(open('$W/runtime.json')); assert d['env']['PYTHONPATH']=='\${DOCROOT}/.pylibs' and '__APP_PORT__' in d['env']['GEN_APP_ARGS']"; ok $? "ky tu dac biet (\${DOCROOT}, __APP_PORT__) duoc giu nguyen trong JSON"
rm -rf "$W"
echo; echo "TONG KET: pass=$pass fail=$fail"; [ $fail = 0 ]
