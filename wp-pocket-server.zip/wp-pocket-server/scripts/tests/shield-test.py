#!/usr/bin/env python3
"""Kiem thu mu-plugin wppocket-shield (HANDOFF.md muc 1br) bang PHP CLI THAT + WordPress GIA LAP toi thieu (add_filter/add_action/WP_User...).
Khong can WordPress/MariaDB/nginx/mang. Xem docs/SECURITY.md.

Trong tam (nhung dieu NGUY HIEM neu sai):
  1) KHONG lam hong website: loi (ke ca loi cu phap) trong shield.php bi loader nuot; co tat khan cap "shield-off";
  2) KHONG khoa chu site: mang da tung dang nhap thanh cong khong bao gio bi chan boi lop nay; khong ap dung khi IP la loopback/LAN (thieu realip);
  3) CHAN duoc do mat khau phan tan (20 lan sai tu nhieu mang -> tai khoan phong thu; 8 lan tu 1 mang -> chan mang do) va do ten tai khoan;
  4) file trang thai khong phinh, khong mat cap nhat khi nhieu tien trinh ghi cung luc, khong tiet lo IP that (bam HMAC), quyen 0600;
  5) nhat ky su kien khong bi chen dong gia (CR/LF) va khong ghi email day du.
"""
import json, os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:300]) if detail else ''))


PRELUDE = r'''<?php
error_reporting(E_ALL); ini_set('display_errors', '1');
define('ABSPATH', '/tmp/fake-wp/');
if (!getenv('NO_SALT')) { define('AUTH_SALT', 'test-salt'); }
$GLOBALS['H'] = ['f' => [], 'a' => [], 'removed' => []];
function add_filter($h, $cb, $p = 10, $n = 1) { $GLOBALS['H']['f'][$h][] = [$p, $cb, $n]; }
function add_action($h, $cb, $p = 10, $n = 1) { $GLOBALS['H']['a'][$h][] = [$p, $cb, $n]; }
function remove_action($h, $cb) { $GLOBALS['H']['removed'][] = $h . ':' . $cb; }
function __return_false() { return false; }
function __return_empty_string() { return ''; }
class WP_Error { public $code; public $msg; function __construct($c = '', $m = '') { $this->code = $c; $this->msg = $m; } }
class WP_User { public $ID; public $user_login; public $roles; public $user_email;
  function __construct($id, $login, $roles = ['subscriber'], $email = '') { $this->ID = $id; $this->user_login = $login; $this->roles = $roles; $this->user_email = $email; } }
$GLOBALS['USERS'] = [1 => new WP_User(1, 'admin', ['administrator'], 'boss@example.com'), 2 => new WP_User(2, 'editor1', ['editor'], 'ed@example.com')];
function get_user_by($f, $v) { foreach ($GLOBALS['USERS'] as $u) { if (($f === 'login' && strtolower($u->user_login) === $v) || ($f === 'email' && strtolower($u->user_email) === $v)) return $u; } return false; }
function get_userdata($id) { return $GLOBALS['USERS'][$id] ?? false; }
function user_can($u, $cap) { return in_array('administrator', (array) $u->roles, true); }
function is_user_logged_in() { return !empty($GLOBALS['LOGGED']); }
class RedirectEx extends Exception {}
function wp_safe_redirect($u, $s = 302) { throw new RedirectEx($s . ' ' . $u); }
function home_url($p = '') { return 'https://example.test' . $p; }
function hooks_sorted($kind, $h) { $l = $GLOBALS['H'][$kind][$h] ?? []; $i = 0; foreach ($l as &$x) { $x[3] = $i++; } unset($x); usort($l, fn($a, $b) => [$a[0], $a[3]] <=> [$b[0], $b[3]]); return $l; }
function apply($h, array $args) { $v = $args[0]; foreach (hooks_sorted('f', $h) as [$p, $cb, $n]) { $a = array_slice(array_merge([$v], array_slice($args, 1)), 0, $n); $v = call_user_func_array($cb, $a); } return $v; }
function fire($h, array $args = []) { foreach (hooks_sorted('a', $h) as [$p, $cb, $n]) { call_user_func_array($cb, array_slice($args, 0, $n)); } }
function has_cb($kind, $h, $prio = null) { foreach ($GLOBALS['H'][$kind][$h] ?? [] as $x) { if ($prio === null || $x[0] === $prio) return true; } return false; }
'''


class Env:
    def __init__(self):
        self.tmp = tempfile.mkdtemp(prefix='shield-')
        self.home = os.path.join(self.tmp, 'home')
        self.run = os.path.join(self.home, 'lamp-run')
        os.makedirs(self.run)
        self.mu = os.path.join(self.tmp, 'mu-plugins')
        os.makedirs(os.path.join(self.mu, 'wppocket-shield'))
        shutil.copy(os.path.join(TPL, 'wppocket-shield-loader.php'), os.path.join(self.mu, 'wppocket-shield.php'))
        shutil.copy(os.path.join(TPL, 'wppocket-shield-logic.php'), os.path.join(self.mu, 'wppocket-shield', 'shield.php'))
        self.loader = os.path.join(self.mu, 'wppocket-shield.php')
        self.logic = os.path.join(self.mu, 'wppocket-shield', 'shield.php')
        self.n = 0

    def php(self, snippet, ip='198.51.100.9', extra_env=None, loader=True, home=True):
        self.n += 1
        f = os.path.join(self.tmp, 's%d.php' % self.n)
        body = PRELUDE + "\n$_SERVER['REMOTE_ADDR'] = " + json.dumps(ip) + ";\n" + ("require " + json.dumps(self.loader) + ";\n" if loader else '') + snippet
        open(f, 'w').write(body)
        env = dict(os.environ)
        env.pop('APP_HOME', None)
        if home:
            env['APP_HOME'] = self.home
        env['TZ'] = 'UTC'
        if extra_env:
            env.update(extra_env)
        r = subprocess.run(['php', f], capture_output=True, text=True, env=env)
        return r.stdout, r.stderr, r.returncode

    def js(self, snippet, **kw):
        out, err, rc = self.php(snippet, **kw)
        try:
            return json.loads(out)
        except ValueError:
            return {'_raw': out, '_err': err, '_rc': rc}

    def flag(self, name, on=True):
        p = os.path.join(self.run, name)
        if on:
            open(p, 'w').write('1')
        elif os.path.exists(p):
            os.remove(p)

    def events(self):
        p = os.path.join(self.run, 'security-events.log')
        return open(p).read() if os.path.exists(p) else ''

    def clean(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def main():
    for f in ('wppocket-shield-loader.php', 'wppocket-shield-logic.php'):
        r = subprocess.run(['php', '-l', os.path.join(TPL, f)], capture_output=True, text=True)
        check('php -l ' + f, r.returncode == 0, r.stdout + r.stderr)

    e = Env()
    try:
        # ===== 1) Dang ky hook =====
        d = e.js(r'''echo json_encode(['f' => array_keys($H['f']), 'a' => array_keys($H['a']), 'removed' => $H['removed'], 'fe' => defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT,
          'auth99' => has_cb('f', 'authenticate', 99), 'wau1' => has_cb('f', 'wp_authenticate_user', 1)]);''')
        for h in ('rest_endpoints', 'wp_sitemaps_add_provider', 'login_errors', 'xmlrpc_enabled', 'xmlrpc_methods', 'wp_is_application_passwords_available', 'the_generator', 'style_loader_src', 'script_loader_src', 'authenticate', 'wp_authenticate_user'):
            check('dang ky filter ' + h, h in d.get('f', []), d)
        for h in ('template_redirect', 'wp_login_failed', 'wp_login', 'user_register', 'set_user_role', 'add_user_role', 'update_option_admin_email', 'activated_plugin'):
            check('dang ky action ' + h, h in d.get('a', []), d)
        check('authenticate o uu tien 99 (sau cung), wp_authenticate_user o uu tien 1 (truoc khi bam mat khau)', d.get('auth99') and d.get('wau1'), d)
        check('go the generator + bat DISALLOW_FILE_EDIT', 'wp_head:wp_generator' in d.get('removed', []) and d.get('fe') is True, d)

        # ===== 2) Cong tat =====
        e.flag('shield-off')
        d = e.js(r'''echo json_encode(['n' => count($H['f']) + count($H['a']), 'fe' => defined('DISALLOW_FILE_EDIT')]);''')
        check('shield-off: khong dang ky hook nao, khong dinh nghia DISALLOW_FILE_EDIT', d == {'n': 0, 'fe': False}, d)
        e.flag('shield-off', False)
        e.flag('shield-allow-file-edit')
        e.flag('shield-allow-user-api')
        e.flag('shield-allow-app-passwords')
        d = e.js(r'''echo json_encode(['fe' => defined('DISALLOW_FILE_EDIT'), 'eps' => array_keys(apply('rest_endpoints', [['/wp/v2/users' => 1, '/wp/v2/posts' => 1]])), 'app' => has_cb('f', 'wp_is_application_passwords_available')]);''')
        check('co shield-allow-file-edit / -user-api / -app-passwords: giu nguyen (khong chan)', d == {'fe': False, 'eps': ['/wp/v2/users', '/wp/v2/posts'], 'app': False}, d)
        for n in ('shield-allow-file-edit', 'shield-allow-user-api', 'shield-allow-app-passwords'):
            e.flag(n, False)
        d = e.js(r'''echo json_encode(['n' => count($H['f'])]);''', home=False)
        check('khong co APP_HOME (chay ngoai ung dung): van nap, khong loi', d.get('n', 0) > 0, d)

        # ===== 3) Chan do ten tai khoan =====
        d = e.js(r'''echo json_encode(['anon' => array_keys(apply('rest_endpoints', [['/wp/v2/users' => 1, '/wp/v2/users/(?P<id>[\d]+)' => 1, '/wp/v2/users/me' => 1, '/wp/v2/posts' => 1]])),
          'auth' => (function () { $GLOBALS['LOGGED'] = true; return array_keys(apply('rest_endpoints', [['/wp/v2/users' => 1, '/wp/v2/posts' => 1]])); })()]);''')
        check('REST: khach mat /wp/v2/users va /users/<id>, GIU /users/me va /posts', d.get('anon') == ['/wp/v2/users/me', '/wp/v2/posts'], d)
        check('REST: nguoi dang nhap giu day du', d.get('auth') == ['/wp/v2/users', '/wp/v2/posts'], d)
        d = e.js(r'''$o = [];
          foreach ([['author' => '1'], ['author' => '1234567890'], ['author' => '1abc'], ['author' => '-1'], ['author' => ['1']], ['author_name' => 'admin'], [], ['author' => ''], ['author' => '12345678901']] as $q) { $o[] = wppocket_shield_is_author_enum($q); }
          echo json_encode($o);''')
        check('is_author_enum: chi so thuan <=10 chu so', d == [True, True, False, False, False, False, False, False, False], d)
        out, err, rc = e.php(r'''$_GET['author'] = '1'; try { fire('template_redirect'); echo "NO-REDIRECT"; } catch (RedirectEx $x) { echo $x->getMessage(); }''')
        check('?author=1 (khach): chuyen 301 ve trang chu', out == '301 https://example.test/', (out, err))
        out, err, rc = e.php(r'''$_GET['author'] = '1'; $GLOBALS['LOGGED'] = true; try { fire('template_redirect'); echo "NO-REDIRECT"; } catch (RedirectEx $x) { echo $x->getMessage(); }''')
        check('?author=1 (da dang nhap): khong chuyen', out == 'NO-REDIRECT', (out, err))
        out, err, rc = e.php(r'''$_GET['s'] = 'x'; try { fire('template_redirect'); echo "NO-REDIRECT"; } catch (RedirectEx $x) { echo $x->getMessage(); }''')
        check('khong co tham so author: khong chuyen', out == 'NO-REDIRECT', (out, err))
        d = e.js(r'''echo json_encode([apply('wp_sitemaps_add_provider', ['PROVIDER', 'users']), apply('wp_sitemaps_add_provider', ['PROVIDER', 'posts'])]);''')
        check('sitemap: bo "users", giu "posts"', d == [False, 'PROVIDER'], d)
        d = e.js(r'''$o = [apply('login_errors', ['<b>Error:</b> The password you entered for the username <b>admin</b> is incorrect.'])];
          $GLOBALS['wppocket_shield_locked'] = true; $o[] = apply('login_errors', ['x']);
          $GLOBALS['wppocket_shield_locked'] = false; $_REQUEST['action'] = 'lostpassword'; $o[] = apply('login_errors', ['Error: There is no account with that username or email address.']);
          echo json_encode($o);''')
        check('thong bao dang nhap sai: chung chung, khong nhac "mat khau"/ten tai khoan', d[0] == 'Sign-in failed. Check your username and password.' and 'admin' not in d[0], d)
        check('thong bao khi bi khoa: noi "Too many"', d[1].startswith('Too many failed'), d)
        check('man hinh quen mat khau: giu nguyen thong bao goc (khong doi nham)', d[2].startswith('Error: There is no account'), d)

        # ===== 4) Giau phien ban =====
        d = e.js(r'''echo json_encode([wppocket_shield_hide_ver('https://x/a.js?ver=6.9.5'), wppocket_shield_hide_ver('https://x/a.js?ver=6.9.6'), wppocket_shield_hide_ver('https://x/a.js?ver=6.9.5'),
          wppocket_shield_hide_ver('https://x/a.css?x=1&ver=2.3.4#h'), wppocket_shield_hide_ver('https://x/a.js'), wppocket_shield_hide_ver('https://x/a.js?server=1'),
          apply('style_loader_src', ['https://x/s.css?ver=5.0.1', 'handle']), apply('the_generator', ['<meta name="generator" content="WordPress 6.9.5">'])]);''')
        a, b, c, dd, ee, ff, gg, hh = d
        check('hide_ver: khong con so phien ban, co 10 ky tu hex', re.fullmatch(r'https://x/a\.js\?ver=[0-9a-f]{10}', a) and '6.9.5' not in a, a)
        check('hide_ver: doi phien ban -> doi gia tri (van pha cache khi cap nhat); cung phien ban -> on dinh', a != b and a == c, (a, b, c))
        check('hide_ver: giu tham so khac + #fragment; khong dong vao "server=" hay URL khong co ver', re.fullmatch(r'https://x/a\.css\?x=1&ver=[0-9a-f]{10}#h', dd) and ee == 'https://x/a.js' and ff == 'https://x/a.js?server=1', (dd, ee, ff))
        check('filter style_loader_src (voi 2 doi so) va the_generator hoat dong', re.fullmatch(r'https://x/s\.css\?ver=[0-9a-f]{10}', gg) and hh == '', (gg, hh))

        # ===== 5) IP / khoa mang =====
        d = e.js(r'''$k = fn($i) => wppocket_shield_ip_key($i);
          echo json_encode(['same4' => $k('45.10.1.7') === $k('45.10.1.200') && $k('45.10.1.7') !== '', 'diff4' => $k('45.10.1.7') !== $k('45.10.2.7'),
            'same6' => $k('2a00:1450:4001:81b::200e') === $k('2a00:1450:4001:81b:ffff::1') && $k('2a00:1450:4001:81b::200e') !== '', 'diff6' => $k('2a00:1450:4001:81b::1') !== $k('2a00:1450:4002:81b::1'),
            'priv' => array_map($k, ['127.0.0.1', '192.168.1.5', '10.0.0.1', '172.16.5.5', '100.64.0.1', '100.127.255.255', '169.254.1.1', '::1', 'fe80::1', 'fd00::1', 'khong-phai-ip', '']),
            'cgnat_edge' => [wppocket_shield_ip_is_private('100.63.255.255'), wppocket_shield_ip_is_private('100.128.0.1')],
            'noip' => [$k('45.10.1.7') === hash_hmac('sha256', 'x', 'y')]]);''')
        check('ip_key: IPv4 cung /24 giong nhau, khac /24 khac nhau', d.get('same4') and d.get('diff4'), d)
        check('ip_key: IPv6 cung /48 giong nhau, khac /48 khac nhau', d.get('same6') and d.get('diff6'), d)
        check('ip_key: loopback/LAN/CGNAT/link-local/ULA/khong hop le -> "" (khong ap dung chan)', d.get('priv') == [''] * 12, d.get('priv'))
        check('CGNAT 100.64/10 dung bien (100.63.x va 100.128.x la IP cong khai)', d.get('cgnat_edge') == [False, False], d.get('cgnat_edge'))
        d = e.js(r'''$_SERVER['REMOTE_ADDR'] = 'rac<script>'; echo json_encode([wppocket_shield_ip(), (function(){ unset($_SERVER['REMOTE_ADDR']); return wppocket_shield_ip(); })()]);''')
        check('wppocket_shield_ip: REMOTE_ADDR rac/thieu -> ""', d == ['', ''], d)
        d1 = e.js(r'''echo json_encode(wppocket_shield_ip_key('45.10.1.7'));''')
        d2 = e.js(r'''echo json_encode(wppocket_shield_ip_key('45.10.1.7'));''', extra_env={'NO_SALT': '1'})
        check('ip_key phu thuoc muoi AUTH_SALT (khong do nguoc ra IP bang bang tra co dinh)', d1 != d2 and len(d1) == 12, (d1, d2))

        # ===== 6) Do mat khau phan tan =====
        T = 1_900_000_000
        store = os.path.join(e.run, 'shield-login.json')
        d = e.js(r'''$f = wppocket_shield_store_path(); $T = %d; $res = [];
          // 19 lan sai tu 19 mang khac nhau -> chua khoa
          for ($i = 1; $i <= 19; $i++) { $r = wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key("45.10.$i.7"), $T + $i); }
          $res['at19'] = $r;
          $r = wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key('45.10.20.7'), $T + 20); $res['at20'] = $r;
          $r = wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key('45.10.21.7'), $T + 21); $res['at21'] = $r;
          echo json_encode($res);''' % T)
        check('19 lan sai tu 19 mang: chua khoa', d['at19']['locked'] is False and d['at19']['new_lock'] is False, d['at19'])
        check('lan sai thu 20: tai khoan vao phong thu (new_lock) ~900 giay', d['at20']['locked'] and d['at20']['new_lock'] and d['at20']['until'] == T + 20 + 900, d['at20'])
        check('lan sai thu 21: van khoa nhung khong bao "moi" nua, gia han', d['at21']['locked'] and not d['at21']['new_lock'] and d['at21']['until'] == T + 21 + 900, d['at21'])
        d = e.js(r'''$f = wppocket_shield_store_path(); $T = %d; $n = $T + 100;
          $known = wppocket_shield_ip_key('91.1.2.3'); $stranger = wppocket_shield_ip_key('45.99.1.1');
          echo json_encode(['stranger' => wppocket_shield_blocked($f, 'id:1', $stranger, $n), 'known_before' => wppocket_shield_blocked($f, 'id:1', $known, $n),
            'other_user' => wppocket_shield_blocked($f, 'id:2', $stranger, $n), 'private_ip' => wppocket_shield_blocked($f, 'id:1', '', $n),
            'after_expiry' => wppocket_shield_blocked($f, 'id:1', $stranger, $T + 21 + 901)]);''' % T)
        check('tai khoan dang phong thu: mang la bi chan ("user")', d['stranger'] == 'user', d)
        check('tai khoan dang phong thu: tai khoan KHAC khong bi anh huong, IP rieng (khong ro) khong ap dung', d['other_user'] == '' and d['private_ip'] == '', d)
        check('het phong thu sau 900 giay ke tu lan sai cuoi', d['after_expiry'] == '', d)
        # mang quen khong bao gio bi chan
        d = e.js(r'''$f = wppocket_shield_store_path(); $T = %d; $n = $T + 100;
          $known = wppocket_shield_ip_key('91.1.2.3');
          $first = wppocket_shield_record_success($f, 'id:1', $known, $n - 50);
          $again = wppocket_shield_record_success($f, 'id:1', $known, $n - 40);
          $second = wppocket_shield_record_success($f, 'id:1', wppocket_shield_ip_key('62.3.4.5'), $n - 30);
          echo json_encode(['first_new' => $first, 'again_new' => $again, 'second_new' => $second,
            'known_blocked' => wppocket_shield_blocked($f, 'id:1', $known, $n), 'known2_blocked' => wppocket_shield_blocked($f, 'id:1', wppocket_shield_ip_key('62.3.4.5'), $n),
            'stranger' => wppocket_shield_blocked($f, 'id:1', wppocket_shield_ip_key('45.99.1.1'), $n),
            'known_expired' => wppocket_shield_blocked($f, 'id:1', $known, $n + 61 * 86400)]);''' % T)
        check('mang da dang nhap thanh cong: KHONG bi chan du tai khoan dang phong thu', d['known_blocked'] == '' and d['known2_blocked'] == '', d)
        check('lan dang nhap dau tien cua tai khoan khong bi coi la "mang moi"; lan lap lai khong; mang thu 2 la moi', d['first_new'] is False and d['again_new'] is False and d['second_new'] is True, d)
        check('van chan nguoi la khi tai khoan phong thu', d['stranger'] == 'user', d)
        # mang quen het han (60 ngay) khong dang nhap: khong con duoc mien
        d2 = e.js(r'''$f = wppocket_shield_store_path(); $T = %d;
          $e1 = wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key('1.2.3.4'), $T + 70 * 86400);
          for ($i = 1; $i <= 20; $i++) { wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key("45.20.$i.7"), $T + 70 * 86400 + $i); }
          echo json_encode(wppocket_shield_blocked($f, 'id:1', wppocket_shield_ip_key('91.1.2.3'), $T + 70 * 86400 + 30));''' % T)
        check('mang quen het han sau 60 ngay khong dang nhap: bi chan lai khi phong thu', d2 == 'user', d2)

        # Do tu 1 mang: 8 lan
        os.remove(store)
        d = e.js(r'''$f = wppocket_shield_store_path(); $T = %d; $ip = wppocket_shield_ip_key('45.50.1.1'); $o = [];
          for ($i = 1; $i <= 7; $i++) { $r = wppocket_shield_record_failure($f, 'id:2', $ip, $T + $i); } $o['at7'] = $r;
          $r = wppocket_shield_record_failure($f, 'id:2', $ip, $T + 8); $o['at8'] = $r;
          $o['same_net'] = wppocket_shield_blocked($f, 'id:2', $ip, $T + 10);
          $o['other_net'] = wppocket_shield_blocked($f, 'id:2', wppocket_shield_ip_key('45.50.2.1'), $T + 10);
          $o['other_user_same_net'] = wppocket_shield_blocked($f, 'id:1', $ip, $T + 10);
          $o['later'] = wppocket_shield_blocked($f, 'id:2', $ip, $T + 8 + 901);
          echo json_encode($o);''' % T)
        check('8 lan sai tu 1 mang vao 1 tai khoan: mang do bi chan ("ip"), chua phong thu ca tai khoan', d['at7']['ip_blocked'] is False and d['at8']['ip_blocked'] is True and d['at8']['locked'] is False and d['same_net'] == 'ip', d)
        check('chan theo mang: mang khac/tai khoan khac khong bi anh huong; het sau cua so', d['other_net'] == '' and d['other_user_same_net'] == '' and d['later'] == '', d)
        # IP rieng -> khong ghi gi
        os.remove(store)
        d = e.js(r'''$f = wppocket_shield_store_path(); $r = wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key('127.0.0.1'), 5); echo json_encode([$r, file_exists($f)]);''')
        check('IP loopback/LAN (thieu realip): khong ghi trang thai, khong chan', d[0]['locked'] is False and d[1] is False, d)

        # ===== 7) Luong that qua hook =====
        os.remove(store) if os.path.exists(store) else None
        script = r'''
          $u = $USERS[1];
          $login = function ($ip, $name = 'admin', $ok = false) use ($u) {
            $_SERVER['REMOTE_ADDR'] = $ip; unset($GLOBALS['wppocket_shield_locked']);
            $user = apply('wp_authenticate_user', [$u, 'pw']);
            if ($user instanceof WP_User) { $user = apply('authenticate', [$ok ? $u : new WP_Error('incorrect_password', 'x'), $name, 'pw']); }
            if ($user instanceof WP_Error) { fire('wp_login_failed', [$name]); return $user->code; }
            fire('wp_login', [$name, $u]); return 'OK';
          };
          $o = [];
          $o['first_login'] = $login('91.1.2.3', 'admin', true);              // chu site dang nhap tu mang quen
          for ($i = 1; $i <= 25; $i++) { $c = $login("45.10.$i.7", $i % 2 ? 'admin' : 'ADMIN'); }   // do mat khau phan tan, ten viet hoa/thuong lan lon
          $o['attacker_last'] = $c;
          $o['attacker_with_right_pw'] = $login('45.77.7.7', 'admin', true);   // du dung mat khau van bi chan khi phong thu
          $o['owner_known'] = $login('91.1.2.99', 'admin', true);              // cung /24 voi mang quen
          $o['owner_by_email'] = (function () use ($u) { $_SERVER['REMOTE_ADDR'] = '91.1.2.5'; return apply('authenticate', [$u, 'boss@example.com', 'pw']) instanceof WP_User ? 'OK' : 'BLOCKED'; })();
          $o['attacker_by_email'] = (function () use ($u) { $_SERVER['REMOTE_ADDR'] = '45.88.8.8'; $r = apply('authenticate', [$u, 'boss@example.com', 'pw']); return $r instanceof WP_Error ? $r->code : 'OK'; })();
          $o['cookie_auth_unaffected'] = (function () use ($u) { $_SERVER['REMOTE_ADDR'] = '45.88.8.8'; return apply('authenticate', [$u, '', '']) instanceof WP_User ? 'OK' : 'BLOCKED'; })();
          $o['locked_msg'] = apply('login_errors', ['x']);
          echo json_encode($o);'''
        d = e.js(script)
        check('luong that: chu site tu mang quen dang nhap OK', d.get('first_login') == 'OK', d)
        check('luong that: do mat khau tu 25 mang (ten hoa/thuong lan lon) -> phong thu, chan ngay ca khi dung mat khau', d.get('attacker_last') == 'wppocket_locked' and d.get('attacker_with_right_pw') == 'wppocket_locked', d)
        check('luong that: chu site van vao duoc (cung /24 voi mang quen), ke ca dang nhap bang email', d.get('owner_known') == 'OK' and d.get('owner_by_email') == 'OK', d)
        check('luong that: ke tan cong doi sang dang nhap bang email van bi chan (khoa theo tai khoan, khong theo chuoi go)', d.get('attacker_by_email') == 'wppocket_locked', d)
        check('luong that: dang nhap bang cookie (khong ten/mat khau) khong bi anh huong', d.get('cookie_auth_unaffected') == 'OK', d)
        check('luong that: thong bao hien ra la "Too many..." khi bi khoa', str(d.get('locked_msg', '')).startswith('Too many'), d)
        ev = e.events()
        check('su kien: ghi 1 dong "TAM KHOA DANG NHAP" (khong lap lai moi lan sai)', ev.count('TAM KHOA DANG NHAP') == 1, ev)
        check('su kien: khong ghi "dang nhap quan tri tu mang moi" cho lan dang nhap dau tien', 'MANG MOI' not in ev, ev)
        d = e.js(r'''$u = $USERS[1]; $_SERVER['REMOTE_ADDR'] = '62.200.1.1'; fire('wp_login', ['admin', $u]);   // admin dang nhap tu mang chua tung thay (da co mang quen khac)
          $u2 = $USERS[2]; $_SERVER['REMOTE_ADDR'] = '62.201.1.1'; fire('wp_login', ['editor1', $u2]); fire('wp_login', ['editor1', $u2]);
          echo 'x';''')
        ev = e.events()
        check('su kien: admin dang nhap tu mang MOI (da co mang quen) -> ghi "DANG NHAP QUAN TRI TU MANG MOI"', 'DANG NHAP QUAN TRI TU MANG MOI: admin (id 1)' in ev, ev)
        check('su kien: nguoi dung thuong dang nhap tu mang moi -> khong ghi', 'editor1' not in ev, ev)

        # ===== 8) Su kien nhay cam =====
        (os.remove(os.path.join(e.run, "security-events.log")) if os.path.exists(os.path.join(e.run, "security-events.log")) else None)
        d = e.js(r'''$_SERVER['REMOTE_ADDR'] = '45.1.2.3';
          fire('user_register', [1]); fire('user_register', [2]);
          fire('set_user_role', [2, 'administrator', ['editor']]); fire('set_user_role', [2, 'editor', ['subscriber']]); fire('add_user_role', [2, 'administrator']);
          fire('update_option_admin_email', ['boss@example.com', 'attacker@evil.io']);
          fire('activated_plugin', ['seo-booster/seo-booster.php']);
          $GLOBALS['USERS'][3] = new WP_User(3, "evil\nFAKE 2026-01-01 ip=1.1.1.1 IP bi tu dong chan: 8.8.8.8", ['administrator']); fire('user_register', [3]);
          echo 'x';''')
        ev = e.events()
        lines = ev.strip().split('\n')
        check('su kien: dung dinh dang "YYYY-MM-DD HH:MM:SS ip=<ip> ..."', all(re.match(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d ip=\S+ \S', l) for l in lines), lines[:3])
        check('su kien: tai khoan admin moi (chi role administrator) duoc ghi, editor thi khong', 'TAI KHOAN QUAN TRI MOI: admin (id 1)' in ev and 'TAI KHOAN QUAN TRI MOI: editor1' not in ev, ev)
        check('su kien: cap quyen administrator (set + add) duoc ghi, doi sang editor thi khong', ev.count('QUYEN QUAN TRI DUOC CAP CHO: editor1 (id 2)') == 2, ev)
        check('su kien: doi email quan tri chi ghi dang che (b***@example.com), khong lo email day du', 'EMAIL QUAN TRI DA DOI: b***@example.com -> a***@evil.io' in ev and 'boss@example.com' not in ev and 'attacker@evil.io' not in ev, ev)
        check('su kien: plugin kich hoat duoc ghi', 'PLUGIN VUA DUOC KICH HOAT: seo-booster/seo-booster.php' in ev, ev)
        check('su kien: ghi IP khach vao dong', 'ip=45.1.2.3 ' in ev, ev)
        check('su kien: ten tai khoan chua xuong dong KHONG tao dong gia (moi su kien dung 1 dong)', len(lines) == 6 and not any(l.startswith('FAKE') for l in lines), lines)

        # ===== 9) Ben vung file trang thai =====
        os.remove(store) if os.path.exists(store) else None
        out, err, rc = e.php(r'''$f = wppocket_shield_store_path(); wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key('45.1.1.1'), 100); echo decoct(fileperms($f) & 0777);''')
        check('file trang thai quyen 0600', out == '600', (out, err))
        raw = open(store).read()
        check('file trang thai khong chua IP that (chi muoi bam)', '45.1.1.1' not in raw and '45.1.1' not in raw, raw[:200])
        for junk in ['', '{rac', '[1,2,3]', '{"v":2,"u":5}', 'null']:
            open(store, 'w').write(junk)
            d = e.js(r'''$f = wppocket_shield_store_path(); $r = wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key('45.1.1.1'), 100); echo json_encode([$r['locked'], wppocket_shield_blocked($f, 'id:1', wppocket_shield_ip_key('45.9.9.9'), 101)]);''')
            check('file trang thai hong (%r): tu phuc hoi, khong loi' % junk[:12], d == [False, ''], d)
        os.remove(store)
        d = e.js(r'''$f = wppocket_shield_store_path(); for ($i = 0; $i < 450; $i++) { wppocket_shield_record_failure($f, 'n:user' . $i, wppocket_shield_ip_key('45.1.1.1'), 1000 + $i); }
          $d = json_decode(file_get_contents($f), true); echo json_encode([count($d['u']), isset($d['u']['n:user449']), isset($d['u']['n:user0']), filesize($f) < 200000]);''')
        check('ten tai khoan ngau nhien khong lam phinh file: toi da 300, giu nhung cai gan day nhat', d == [300, True, False, True], d)
        os.remove(store)
        # nhieu tien trinh ghi dong thoi: khong mat cap nhat
        procs = []
        snippet_tpl = r'''$f = wppocket_shield_store_path(); for ($i = 0; $i < 10; $i++) { wppocket_shield_record_failure($f, 'id:1', wppocket_shield_ip_key('45.%d.1.1'), 5000); }'''
        pf = []
        for k in range(8):
            e.n += 1
            fn = os.path.join(e.tmp, 'par%d.php' % k)
            open(fn, 'w').write(PRELUDE + "\n$_SERVER['REMOTE_ADDR']='1.1.1.1';\nrequire " + json.dumps(e.loader) + ";\n" + snippet_tpl % (60 + k))
            env = dict(os.environ)
            env['APP_HOME'] = e.home
            procs.append(subprocess.Popen(['php', fn], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE))
        for p in procs:
            p.communicate()
        d = json.load(open(store))
        total_f = len(d['u']['id:1']['f'])
        check('8 tien trinh x 10 lan sai dong thoi: KHONG mat cap nhat (80 lan, tru gioi han 200)', total_f == 80, total_f)

        # ===== 9b) Cong REST (shield-rest-gate-on): TUY CHON =====
        d = e.js(r"""echo json_encode(['on' => has_cb('f', 'rest_pre_dispatch')]);""")
        check('cong REST: mac dinh TAT -> khong dang ky rest_pre_dispatch', d == {'on': False}, d)
        e.flag('shield-rest-gate-on')
        gate = r"""
class Req { public $r; function __construct($r) { $this->r = $r; } function get_route() { return $this->r; } }
$out = [];
foreach (['/wp/v2/posts', '/', '/wp/v2/users', '/wp/v2/types/post', '/oembed/1.0/embed', '/contact-form-7/v1/contact-forms/5/feedback', '/wc/store/v1/cart', '/wc/v3/orders', '/oembed/1.0X/embed', '/wp/v2/posts/../users'] as $rt) {
    $v = apply('rest_pre_dispatch', [null, new stdClass, new Req($rt)]);
    $out[$rt] = $v instanceof WP_Error ? $v->code : 'pass';
}
echo json_encode(['hooked' => has_cb('f', 'rest_pre_dispatch', 5), 'r' => $out]);
"""
        d = e.js(gate)
        blocked = ['/wp/v2/posts', '/', '/wp/v2/users', '/wp/v2/types/post', '/wc/v3/orders', '/oembed/1.0X/embed', '/wp/v2/posts/../users']
        passed = ['/oembed/1.0/embed', '/contact-form-7/v1/contact-forms/5/feedback', '/wc/store/v1/cart']
        check('cong REST bat: dang ky rest_pre_dispatch o uu tien 5 (truoc cac xu ly khac)', d.get('hooked') is True, d)
        check('cong REST bat, KHACH: /wp/v2/*, goc "/", users, wc/v3 bi chan voi ma rest_guest_blocked', all(d['r'].get(r) == 'rest_guest_blocked' for r in blocked), d.get('r'))
        check('cong REST bat, KHACH: oEmbed, Contact Form 7, WooCommerce Store API (danh sach co san) di qua', all(d['r'].get(r) == 'pass' for r in passed), d.get('r'))
        d = e.js(r"""$GLOBALS['LOGGED'] = true; class Req { function get_route() { return '/wp/v2/posts'; } }
$v = apply('rest_pre_dispatch', [null, new stdClass, new Req]); echo json_encode(['v' => $v instanceof WP_Error ? $v->code : 'pass']);""")
        check('cong REST bat, NGUOI DA DANG NHAP: di qua (trinh soan thao khoi khong hong)', d == {'v': 'pass'}, d)
        d = e.js(r"""class Req { function get_route() { return '/wp/v2/posts'; } }
$pre = new stdClass; $v = apply('rest_pre_dispatch', [$pre, new stdClass, new Req]); echo json_encode(['same' => $v === $pre]);""")
        check('cong REST: gia tri co san tu bo loc khac (khac null) duoc giu nguyen, khong ghi de', d == {'same': True}, d)
        d = e.js(r"""$v = apply('rest_pre_dispatch', [null, new stdClass, new stdClass]); echo json_encode(['v' => $v]);""")
        check('cong REST: doi tuong request la (khong co get_route): bo qua, khong loi', d == {'v': None}, d)
        open(os.path.join(e.run, 'shield-rest-allow.txt'), 'w').write("# chu site them\n/wp/v2/types\n/UPPER/Case   # ghi chu cuoi dong\nnoslash\n/../etc/passwd\n/a b\n/ok-1_2.x\n\n   /wp/v2/pages  \n")
        d = e.js(r"""echo json_encode(wppocket_shield_rest_user_allow());""")
        check('shield-rest-allow.txt: doc dung dong hop le (chu thuong hoa), bo dong thieu "/", co ".." hoac ky tu la', d == ['/wp/v2/types', '/upper/case', '/ok-1_2.x', '/wp/v2/pages'], d)
        d = e.js(gate.replace("['/wp/v2/posts', '/', ", "['/wp/v2/types', '/wp/v2/types/post', '/wp/v2/typesX', '/wp/v2/type', '/upper/case/x', '/wp/v2/pages/3', '/wp/v2/posts', '/', "))
        check('cho phep theo file: khop THEO RANH GIOI doan (types, types/post, pages/3 vao; typesX, type, posts van chan)',
              d['r'].get('/wp/v2/types') == d['r'].get('/wp/v2/types/post') == d['r'].get('/upper/case/x') == d['r'].get('/wp/v2/pages/3') == 'pass'
              and d['r'].get('/wp/v2/typesX') == d['r'].get('/wp/v2/type') == d['r'].get('/wp/v2/posts') == 'rest_guest_blocked', d.get('r'))
        big = '\n'.join('/r%d' % i for i in range(300))
        open(os.path.join(e.run, 'shield-rest-allow.txt'), 'w').write(big)
        d = e.js(r"""echo json_encode(count(wppocket_shield_rest_user_allow()));""")
        check('shield-rest-allow.txt: toi da 100 dong (chong file khong lo lam cham moi request REST)', d == 100, d)
        open(os.path.join(e.run, 'shield-rest-allow.txt'), 'w').write('x' * 200000)
        d = e.js(r"""echo json_encode(wppocket_shield_rest_user_allow());""")
        check('shield-rest-allow.txt: file rac/qua lon: chi doc 16KB dau, khong loi', d == [], d)
        os.remove(os.path.join(e.run, 'shield-rest-allow.txt'))
        d = e.js(r"""echo json_encode([wppocket_shield_rest_allowed('/wp/v2/posts', ['/']), wppocket_shield_rest_allowed('/wp/v2/posts', ['']), wppocket_shield_rest_allowed('', ['/wp/v2/posts']), wppocket_shield_rest_allowed('//wp/v2/posts', ['/wp/v2/posts']), wppocket_shield_rest_allowed('/WP/V2/POSTS/', ['/wp/v2/posts'])]);""")
        check('rest_allowed: tien to "/" hoac rong KHONG cho phep tat ca; route rong/"//" bi tu choi; khong phan biet hoa thuong', d == [False, False, False, False, True], d)
        e.flag('shield-off')
        d = e.js(r"""echo json_encode(['on' => has_cb('f', 'rest_pre_dispatch')]);""")
        check('cong REST + shield-off: Shield tat het nen cong cung tat (loi thoat khan cap)', d == {'on': False}, d)
        e.flag('shield-off', False)
        e.flag('shield-rest-gate-on', False)

        # ===== 10) Loader chiu loi =====
        shutil.copy(e.logic, e.logic + '.bak')
        open(e.logic, 'w').write("<?php\nif (!defined('ABSPATH')) exit;\nthis is not php {{{\n")
        out, err, rc = e.php('echo "SURVIVED";')
        check('shield.php loi CU PHAP (ParseError): loader nuot, website van chay', out.endswith('SURVIVED') and rc == 0, (out[-200:], err[:200], rc))
        open(e.logic, 'w').write("<?php\nif (!defined('ABSPATH')) exit;\nthrow new RuntimeException('boom');\n")
        out, err, rc = e.php('echo "SURVIVED";')
        check('shield.php nem exception: loader nuot, website van chay', out.endswith('SURVIVED') and rc == 0, (out[-200:], err[:200], rc))
        shutil.copy(e.logic + '.bak', e.logic)
        r = subprocess.run(['php', '-r', 'require $argv[1]; echo "ok";', e.loader], capture_output=True, text=True)
        check('loader goi truc tiep (khong co ABSPATH): thoat im lang, khong chay logic', 'ok' not in r.stdout and r.returncode == 0 and 'Warning' not in r.stdout, (r.stdout, r.stderr))
        out, err, rc = e.php('require_once ' + json.dumps(e.logic) + '; echo "twice-ok";')
        check('nap shield.php 2 lan khong loi (khong dinh nghia lai ham/hang)', 'twice-ok' in out and 'Fatal' not in out and 'Warning' not in out, (out[-200:], err[:200]))
    finally:
        e.clean()

    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
