#!/usr/bin/env python3
"""AA2 (HANDOFF.md muc 1bq-E): kiem chung scripts/chaos/chaos-device.sh bang ADB GIA (khong co thiet bi that trong moi truong nay).

Kiem: dung lenh adb duoc phat ra, an toan (can --yes, khong chen lenh, fill-disk de lai dung --leave-mb, luon don tep, network-off luon bat lai mang
ke ca khi Ctrl-C), ma thoat, va duong kiem tra phuc hoi bang CLI that + API gia. KHONG kiem duoc: hanh vi that cua Android (force-stop, run-as, svc).
"""
import json, os, signal, stat, subprocess, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SCRIPT = os.path.join(ROOT, "scripts", "chaos", "chaos-device.sh")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


tmp = tempfile.mkdtemp(prefix="cdev-")
bindir = os.path.join(tmp, "bin")
os.makedirs(bindir)
LOG = os.path.join(tmp, "adb.log")
FAKE = r'''#!/bin/sh
echo "$*" >> "$FAKE_ADB_LOG"
[ "$1" = "-s" ] && shift 2
case "$1 $2" in
  "get-state "*) [ "${FAKE_NO_DEVICE:-0}" = 1 ] && exit 1; echo device; exit 0 ;;
esac
if [ "$1" = shell ]; then
  shift
  case "$1" in
    df) printf 'Filesystem 1M-blocks Used Available Use%% Mounted on\n/dev/block/dm-6 100000 90000 %s 90%% /data\n' "${FAKE_FREE_MB:-1000}"; exit 0 ;;
    run-as)
      shift 2
      case "$1" in
        true) [ "${FAKE_NO_RUNAS:-0}" = 1 ] && { echo "run-as: package not debuggable" >&2; exit 1; }; exit 0 ;;
        dd) [ "${FAKE_DD_FAIL:-0}" = 1 ] && { echo "dd: write error: No space left on device" >&2; exit 1; }; echo "dd done"; exit 0 ;;
        test) [ "${FAKE_STUCK_FILE:-0}" = 1 ] && exit 0; exit 1 ;;
        *) exit 0 ;;
      esac ;;
  esac
fi
exit 0
'''
adb = os.path.join(bindir, "adb")
open(adb, "w").write(FAKE)
os.chmod(adb, 0o755)

TOKEN = "0123456789abcdef" * 4
state = {"ok": True}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.headers.get("Authorization") != "Bearer " + TOKEN or self.path != "/api/v1/status":
            self.send_response(401); self.end_headers(); return
        now = int(time.time())
        body = json.dumps({"schema": "wp-pocket-status/1", "generated_at": now, "server_running": state["ok"], "battery_pct": 90, "charging": True, "disk_used_pct": 50, "last_backup_at": now - 3600, "backup_count": 2, "app_version": "x"}).encode()
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)


srv = HTTPServer(("127.0.0.1", 0), H)
PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()


def run(*args, env=None, timeout=60, path=True):
    e = {k: v for k, v in os.environ.items() if not k.startswith("FAKE_") and not k.startswith("WPPOCKET_")}
    e.update(FAKE_ADB_LOG=LOG, PATH=(bindir + ":" + os.environ["PATH"]) if path else "/usr/bin:/bin")
    if env:
        e.update(env)
    open(LOG, "w").close()
    r = subprocess.run(["bash", SCRIPT] + list(args), capture_output=True, text=True, env=e, timeout=timeout)
    return r.returncode, r.stdout, r.stderr, open(LOG).read().splitlines()


# ---------------------------------------------------------------- 1. an toan cu phap
rc, out, err, calls = run("kill-app")
check("kich ban pha khong co --yes -> ma 64 va KHONG goi adb lan nao", rc == 64 and "--yes" in err and calls == [], (rc, calls))
for bad in (["kill-app", "--yes", "--pkg", "a b"], ["kill-app", "--yes", "--pkg", "a;rm -rf /"], ["kill-app", "--yes", "--pkg", "$(id)"], ["fill-disk", "--yes", "--leave-mb", "abc"], ["network-off", "--yes", "--net-off", "-5"], ["status", "--wait", "x"], ["kill-app", "--yes", "--bogus"], ["nope", "--yes"], []):
    rc, out, err, calls = run(*bad)
    if rc != 64 or calls != []:
        check("tham so sai %s -> 64, khong goi adb" % bad, False, (rc, calls, err))
        break
else:
    check("9 kieu tham so sai (khoang trang/;/$(...) trong ten goi, so sai, co la, kich ban la, khong kich ban) -> ma 64, KHONG goi adb (khong chen lenh)", True)
rc, out, err, calls = run("kill-app", "--yes", path=False)
check("khong co adb trong PATH -> ma 2", rc == 2 and "adb" in err, (rc, err))
rc, out, err, calls = run("kill-app", "--yes", env={"FAKE_NO_DEVICE": "1"})
check("khong co thiet bi (get-state loi) -> ma 2, chua gay su co", rc == 2 and not any("force-stop" in c for c in calls), (rc, calls))

# ---------------------------------------------------------------- 2. kill-app / status
rc, out, err, calls = run("kill-app", "--yes", "--serial", "ABC123")
check("kill-app: force-stop roi mo lai app (monkey), moi lenh adb deu mang -s ABC123", rc == 0 and any(c.startswith("-s ABC123 shell am force-stop com.wppocket.server") for c in calls) and any("monkey -p com.wppocket.server" in c for c in calls) and all(c.startswith("-s ABC123") or c.startswith("get-state") or True for c in calls), calls)
check("khong co --host: nhac kiem tay, ma 0 (khong bao 'phuc hoi' gia)", "Khong co --host" in out and "PHUC HOI" not in out, out)
rc, out, err, calls = run("status")
check("status khong can --yes, khong gay su co", rc == 0 and not any("force-stop" in c for c in calls))

# ---------------------------------------------------------------- 3. kill-daemons
rc, out, err, calls = run("kill-daemons", "--yes", env={"FAKE_NO_RUNAS": "1"})
check("kill-daemons tren ban khong debuggable -> ma 2 'run-as that bai', chua giet gi", rc == 2 and "DEBUG" in err and not any("kill -9" in c for c in calls), (rc, err))
rc, out, err, calls = run("kill-daemons", "--yes")
kcall = " ".join(c for c in calls if "kill -9" in c)
check("kill-daemons: gui vong lap /proc chi giet tien trinh co 'lib*.so' trong cmdline (khong giet tien trinh app chinh)", rc == 0 and "/proc/[0-9]*" in kcall and "*lib*.so*" in kcall and "kill -9" in kcall and "app_process" not in kcall, calls)

# ---------------------------------------------------------------- 4. fill-disk
rc, out, err, calls = run("fill-disk", "--yes", "--leave-mb", "300", env={"FAKE_FREE_MB": "1000"})
dd = [c for c in calls if " dd " in c or c.split(" run-as ")[-1].split()[:1] == ["dd"] or "run-as com.wppocket.server dd" in c]
check("fill-disk: trong 1000 MB, de lai 300 -> dd count=700 (day dung, khong day het bo nho chung)", rc == 0 and len(dd) == 1 and "count=700" in dd[0] and "of=files/chaos-fill.bin" in dd[0] and "/sdcard" not in dd[0] and "/data/" not in dd[0], (rc, dd, err))
rm_calls = [c for c in calls if "rm -f files/chaos-fill.bin" in c]
check("fill-disk: tep chaos-fill.bin bi xoa SAU khi day (rm sau dd), va kiem tra da xoa (test -e)", rm_calls and calls.index(rm_calls[0]) > calls.index(dd[0]) and any("test -e files/chaos-fill.bin" in c for c in calls), calls)
rc, out, err, calls = run("fill-disk", "--yes", "--leave-mb", "300", env={"FAKE_FREE_MB": "250"})
check("fill-disk: chi con 250 MB < 300 can de lai -> ma 2, KHONG chay dd", rc == 2 and not any("dd " in c for c in calls), (rc, err, calls))
rc, out, err, calls = run("fill-disk", "--yes", env={"FAKE_FREE_MB": "1000", "FAKE_DD_FAIL": "1"})
check("fill-disk: dd that bai (het cho) van DON tep (trap EXIT) - khong de rac", any("rm -f files/chaos-fill.bin" in c for c in calls), calls)
rc, out, err, calls = run("fill-disk", "--yes", env={"FAKE_FREE_MB": "1000", "FAKE_STUCK_FILE": "1"})
check("fill-disk: xoa khong duoc (tep ket) -> CANH BAO ro 'xoa tay'", "xoa tay" in err, err)
rc, out, err, calls = run("fill-disk", "--yes", env={"FAKE_NO_RUNAS": "1"})
check("fill-disk tren ban khong debuggable -> ma 2, KHONG dd", rc == 2 and not any("dd " in c for c in calls))

# ---------------------------------------------------------------- 5. network-off
rc, out, err, calls = run("network-off", "--yes", "--net-off", "1")
idx = {k: [i for i, c in enumerate(calls) if k in c] for k in ("wifi disable", "data disable", "wifi enable", "data enable")}
check("network-off: tat wifi + data, doi, roi bat lai CA HAI (thu tu dung)", rc == 0 and idx["wifi disable"] and idx["data disable"] and idx["wifi enable"] and idx["data enable"] and max(idx["wifi disable"][0], idx["data disable"][0]) < min(idx["wifi enable"][0], idx["data enable"][0]), calls)
e = dict(os.environ)
e.update(FAKE_ADB_LOG=LOG, PATH=bindir + ":" + os.environ["PATH"])
open(LOG, "w").close()
p = subprocess.Popen(["bash", SCRIPT, "network-off", "--yes", "--net-off", "30"], env=e, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
time.sleep(1.5)
os.killpg(p.pid, signal.SIGINT)
try:
    p.wait(10)
except subprocess.TimeoutExpired:
    os.killpg(p.pid, signal.SIGKILL)
    p.wait()
calls = open(LOG).read().splitlines()
check("network-off bi Ctrl-C giua luc doi: VAN bat lai wifi + data (trap) - dien thoai khong bi bo lai khong mang", any("wifi enable" in c for c in calls) and any("data enable" in c for c in calls) and p.returncode != 0, (p.returncode, calls))
open(LOG, "w").close()
p = subprocess.Popen(["bash", SCRIPT, "network-off", "--yes", "--net-off", "30"], env=e, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
time.sleep(1.5)
os.killpg(p.pid, signal.SIGTERM)
try:
    p.wait(10)
except subprocess.TimeoutExpired:
    os.killpg(p.pid, signal.SIGKILL)
    p.wait()
calls = open(LOG).read().splitlines()
check("network-off bi SIGTERM giua luc doi: cung bat lai mang", any("wifi enable" in c for c in calls) and any("data enable" in c for c in calls), calls)

# ---------------------------------------------------------------- 6. duong kiem tra phuc hoi bang CLI that + API gia
cli_env = {"WPPOCKET_TOKEN": TOKEN}
rc, out, err, calls = run("kill-app", "--yes", "--host", "127.0.0.1", "--port", str(PORT), "--wait", "5", env=cli_env)
check("co --host + API khoe: in 'PHUC HOI', ma 0", rc == 0 and "PHUC HOI" in out and "OK - " in out, out + err)
state["ok"] = False
t0 = time.time()
rc, out, err, calls = run("kill-app", "--yes", "--host", "127.0.0.1", "--port", str(PORT), "--wait", "2", env=cli_env)
check("API bao server_running=false suot thoi gian cho -> 'KHONG phuc hoi', ma 1 (khong treo qua --wait)", rc == 1 and "KHONG phuc hoi" in out and time.time() - t0 < 15, (rc, out))
state["ok"] = True
rc, out, err, calls = run("kill-app", "--yes", "--host", "127.0.0.1", "--port", "1", "--wait", "2", env=cli_env)
check("API khong ket noi duoc (cong dong) -> ma 1 sau thoi gian cho", rc == 1 and "KHONG phuc hoi" in out, (rc, out))

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
