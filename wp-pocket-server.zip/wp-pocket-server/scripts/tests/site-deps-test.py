#!/usr/bin/env python3
"""Kiem thu scripts/lib/site_deps.sh (HANDOFF.md muc 1ba) voi npm / pip / composer THAT va goi THAT tu registry.

Kiem tra ca TINH NANG (cai duoc, Node require duoc, Python import duoc) lan AN TOAN (script cua goi KHONG chay; sdist-only
bi tu choi; goi native duoc canh bao/xoa; thu muc da co san thi bo qua; tat bang install_deps=false; cai loi -> that bai ro rang).
Phan can mang (registry npm/PyPI) bi bo qua neu khong truy cap duoc; phan composer can composer.phar (tai tu GitHub release,
hoac COMPOSER_PHAR=...; thieu thi bo qua phan do).
"""
import json, os, shutil, subprocess, sys, tempfile, textwrap

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('PASS:', name)
    else: failed += 1; print('FAIL:', name, ('  -> ' + str(detail)[:300]) if detail != '' else '')

tmp = tempfile.mkdtemp(prefix='site-deps-')
# Hermetic: cache npm/pip nam trong thu muc tam cua test (khong phu thuoc/khong lam ban HOME, chay duoc voi user bat ky)
os.environ['npm_config_cache'] = os.path.join(tmp, 'npm-cache'); os.environ['PIP_CACHE_DIR'] = os.path.join(tmp, 'pip-cache')
def wr(p, t):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(t)
def deps(runtime, d, env=None, path_prefix=None):
    e = dict(os.environ, **(env or {}))
    if path_prefix: e['PATH'] = path_prefix + ':' + e['PATH']
    r = subprocess.run(['bash', '-c', 'source scripts/lib/site_deps.sh; install_site_deps "$1" "$2"', 'x', runtime, d], cwd=ROOT, env=e,
                       capture_output=True, text=True, timeout=300)
    return r.returncode, r.stdout, r.stderr

def net_ok():
    try: return subprocess.run(['npm', 'view', 'ms', 'version'], capture_output=True, text=True, timeout=60).returncode == 0 and \
        subprocess.run([sys.executable, '-m', 'pip', 'download', '--no-deps', '-q', '-d', os.path.join(tmp, 'pipdl'), 'six==1.16.0'], capture_output=True, timeout=90).returncode == 0
    except Exception: return False

try:
    # ---------------------------------------------------------------- Node
    if shutil.which('npm') and shutil.which('node') and net_ok():
        marker = os.path.join(tmp, 'INSTALL_SCRIPT_RAN')
        d = os.path.join(tmp, 'node1')
        wr(d + '/package.json', json.dumps({'name': 't', 'version': '1.0.0', 'dependencies': {'ms': '2.1.3', 'evil': 'file:./evil'}, 'devDependencies': {'is-number': '7.0.0'}}))
        wr(d + '/evil/package.json', json.dumps({'name': 'evil', 'version': '1.0.0', 'scripts': {'postinstall': 'node -e "require(\'fs\').writeFileSync(%s,\'1\')"' % json.dumps(marker)}}))
        wr(d + '/evil/index.js', 'module.exports = 1')
        rc, out, err = deps('node', d)
        check('Node: npm install lac BUILD thanh cong (goi that ms@2.1.3 tu registry)', rc == 0 and os.path.isfile(d + '/node_modules/ms/package.json'), err[-200:])
        check('Node: devDependencies KHONG duoc cai (--omit=dev)', not os.path.exists(d + '/node_modules/is-number'))
        check('Node: script postinstall cua goi KHONG chay (--ignore-scripts) - khong co marker', not os.path.exists(marker))
        r = subprocess.run(['node', '-e', "console.log(require('ms')('2 days'))"], cwd=d, capture_output=True, text=True)
        check('Node: require("ms") chay duoc tu node_modules vua cai', r.stdout.strip() == '172800000', r.stderr[-120:])

        d = os.path.join(tmp, 'node2')
        wr(d + '/package.json', json.dumps({'name': 't2', 'version': '1.0.0', 'dependencies': {'ms': '2.1.3'}}))
        subprocess.run(['npm', 'install', '--package-lock-only', '--no-audit', '--no-fund'], cwd=d, capture_output=True)
        rc, out, err = deps('node', d)
        check('Node: co package-lock.json -> dung "npm ci" (tai lap theo lock)', rc == 0 and 'ci' in out.split('npm:')[1].split()[0] if 'npm:' in out else False, out[:200])
        check('Node: npm ci cai du', os.path.isfile(d + '/node_modules/ms/index.js'))

        d = os.path.join(tmp, 'node3')
        wr(d + '/package.json', json.dumps({'name': 't3', 'version': '1.0.0', 'dependencies': {'nativepkg': 'file:./nativepkg'}}))
        wr(d + '/nativepkg/package.json', json.dumps({'name': 'nativepkg', 'version': '1.0.0'})); wr(d + '/nativepkg/binding.gyp', '{}')
        rc, out, err = deps('node', d)
        check('Node: goi can MA NATIVE (binding.gyp) -> CANH BAO ten goi (khong lam fail build)', rc == 0 and 'nativepkg' in err and 'NATIVE' in err, err[-200:])

        d = os.path.join(tmp, 'node4')
        wr(d + '/package.json', json.dumps({'name': 't4', 'version': '1.0.0', 'dependencies': {'ms': '99.99.99'}}))
        rc, out, err = deps('node', d)
        check('Node: cai LOI (phien ban khong ton tai) -> THAT BAI ro rang (rc!=0, thong bao LOI)', rc != 0 and 'LOI' in err, (rc, err[-150:]))

        d = os.path.join(tmp, 'node5'); wr(d + '/package.json', json.dumps({'name': 't5', 'version': '1.0.0', 'dependencies': {'ms': '2.1.3'}})); wr(d + '/node_modules/keep.txt', 'x')
        rc, out, err = deps('node', d)
        check('Node: da co node_modules san -> bo qua, khong dung vao', rc == 0 and os.listdir(d + '/node_modules') == ['keep.txt'] and 'bo qua' in out)

        d = os.path.join(tmp, 'node6'); wr(d + '/package.json', json.dumps({'name': 't6', 'version': '1.0.0', 'dependencies': {'ms': '2.1.3'}}))
        cfg = os.path.join(tmp, 'off.json'); wr(cfg, json.dumps({'install_deps': False, 'runtime': 'node'}))
        rc, out, err = deps('node', d, env={'SITE_CONFIG': cfg})
        check('install_deps=false trong site.config.json -> khong cai gi', rc == 0 and not os.path.exists(d + '/node_modules') and 'install_deps=false' in out)

        d = os.path.join(tmp, 'node7'); wr(d + '/index.js', 'x')
        rc, out, err = deps('node', d)
        check('Node: khong co package.json -> khong lam gi, khong loi', rc == 0 and out.strip() == '' and err.strip() == '')

        # ------------------------------------------------------------ Python
        d = os.path.join(tmp, 'py1')
        wr(d + '/requirements.txt', 'six==1.16.0\nMarkupSafe==2.1.5\n'); wr(d + '/app.py', 'print(1)')
        rc, out, err = deps('python', d)
        sos = [os.path.join(r, f) for r, _, fs in os.walk(d + '/.pylibs') for f in fs if '.so' in f or f.endswith('.pyd')]
        check('Python: pip cai requirements.txt vao .pylibs (six + MarkupSafe that tu PyPI)', rc == 0 and os.path.isfile(d + '/.pylibs/six.py') and os.path.isdir(d + '/.pylibs/markupsafe'), err[-250:])
        check('Python: module bien dich cua may CI (.so) da bi XOA + canh bao ten goi', sos == [] and 'markupsafe' in err.lower() and 'XOA' in err, (sos[:2], err[-200:]))
        r = subprocess.run([sys.executable, '-c', "import six, markupsafe; print(markupsafe.escape('<a>'))"], env=dict(os.environ, PYTHONPATH=d + '/.pylibs', PYTHONDONTWRITEBYTECODE='1'), capture_output=True, text=True)
        check('Python: sau khi xoa .so, MarkupSafe van import duoc nho duong lui Python thuan (khong ImportError)', r.stdout.strip() == '&lt;a&gt;', r.stderr[-150:])
        check('Python: khong de lai __pycache__ (tai lap + nhe)', not any('__pycache__' in r for r, _, _ in os.walk(d + '/.pylibs')))

        d = os.path.join(tmp, 'py2'); wr(d + '/requirements.txt', 'docopt==0.6.2\n')
        rc, out, err = deps('python', d)
        check('Python: goi CHI co ma nguon sdist (docopt) bi TU CHOI (--only-binary: khong chay setup.py cua goi)', rc != 0 and 'LOI' in err and not os.path.exists(d + '/.pylibs/docopt.py'), (rc, err[-200:]))
        d = os.path.join(tmp, 'py3'); wr(d + '/requirements.txt', 'six==1.16.0\n'); wr(d + '/.pylibs/keep.txt', 'x')
        rc, out, err = deps('python', d)
        check('Python: da co .pylibs san -> bo qua', rc == 0 and os.listdir(d + '/.pylibs') == ['keep.txt'])
    else:
        print('(bo qua phan Node/Python: thieu npm/node hoac khong truy cap duoc registry npm/PyPI)')

    # ---------------------------------------------------------------- PHP / composer
    phar = os.environ.get('COMPOSER_PHAR') or os.path.join(tmp, 'composer.phar')
    if not os.path.isfile(phar):
        subprocess.run(['curl', '-fsSL', '--max-time', '120', '-o', phar, 'https://github.com/composer/composer/releases/latest/download/composer.phar'], capture_output=True)
    if os.path.isfile(phar) and os.path.getsize(phar) > 100000 and shutil.which('php'):
        wrapdir = os.path.join(tmp, 'bin'); os.makedirs(wrapdir)
        wr(wrapdir + '/composer', '#!/bin/sh\nexec php "%s" "$@"\n' % phar); os.chmod(wrapdir + '/composer', 0o755)
        marker = os.path.join(tmp, 'COMPOSER_SCRIPT_RAN')
        d = os.path.join(tmp, 'php1')
        wr(d + '/pkg/composer.json', json.dumps({'name': 'local/pkg', 'version': '1.0.0', 'autoload': {'psr-4': {'Local\\Pkg\\': 'src/'}}}))
        wr(d + '/pkg/src/Hello.php', '<?php namespace Local\\Pkg; class Hello { public static function hi() { return "hi"; } }')
        wr(d + '/composer.json', json.dumps({'name': 'app/test', 'require': {'local/pkg': '*', 'ext-fake-ext-xyz': '*'}, 'repositories': [{'packagist.org': False}, {'type': 'path', 'url': 'pkg', 'options': {'symlink': False}}],
                                              'minimum-stability': 'dev', 'scripts': {'post-install-cmd': 'touch %s' % marker, 'post-autoload-dump': 'touch %s' % marker}}))
        rc, out, err = deps('php', d, path_prefix=wrapdir)
        check('PHP: composer install lac BUILD thanh cong (goi path, khong can mang)', rc == 0 and os.path.isfile(d + '/vendor/autoload.php'), (out + err)[-300:])
        r = subprocess.run(['php', '-r', "require '%s/vendor/autoload.php'; echo Local\\Pkg\\Hello::hi();" % d], capture_output=True, text=True)
        check('PHP: autoload chay duoc, class cua goi nap duoc', r.stdout == 'hi', r.stderr[-150:])
        check('PHP: script trong composer.json KHONG chay (--no-scripts)', not os.path.exists(marker))
        check('PHP: ext-* yeu cau duoc LIET KE de doi chieu voi PHP Termux', 'ext-fake-ext-xyz' in err, err[-200:])

        d = os.path.join(tmp, 'php2'); wr(d + '/composer.json', '{ khong phai json'); 
        rc, out, err = deps('php', d, path_prefix=wrapdir)
        check('PHP: composer.json hong -> THAT BAI ro rang', rc != 0 and 'LOI' in err, (rc, err[-150:]))
        d = os.path.join(tmp, 'php3'); wr(d + '/composer.json', json.dumps({'name': 'wp/core', 'require': {}})); wr(d + '/wp-includes/version.php', '<?php $wp_version="6.8.1";')
        rc, out, err = deps('php', d, path_prefix=wrapdir)
        check('PHP: cay WordPress (co wp-includes/version.php) -> bo qua composer', rc == 0 and not os.path.exists(d + '/vendor') and 'WordPress' in out)
        d = os.path.join(tmp, 'php4'); wr(d + '/composer.json', json.dumps({'name': 'a/b', 'require': {}})); wr(d + '/vendor/keep.txt', 'x')
        rc, out, err = deps('php', d, path_prefix=wrapdir)
        check('PHP: da co vendor/ san -> bo qua', rc == 0 and os.listdir(d + '/vendor') == ['keep.txt'])
    else:
        print('(bo qua phan composer: khong co composer.phar - dat COMPOSER_PHAR=... hoac cho phep tai tu GitHub)')

    # python.sh sinh runtime.json: trich DUNG doan lenh that (khong chep lai) va chay voi / khong co .pylibs.
    # [Sua o 1bq: doan nay tung la heredoc "JSON"; tu 1bi python.sh dung generic_write_runtime_json nen test cu khong con tim thay doan va FAIL tu truoc -
    #  da co san ngay trong zip goc. Nay trich tu "# Co .pylibs" den het dong goi generic_write_runtime_json va nap thu vien generic_runtime.sh.]
    import re
    src = open(os.path.join(ROOT, 'scripts', 'runtimes', 'python.sh'), encoding='utf-8').read()
    m = re.search(r'(# Co \.pylibs.*?\ngeneric_write_runtime_json[^\n]*\n)', src, re.S)
    check('python.sh co doan sinh runtime.json voi PYTHONPATH de trich', bool(m))
    if m:
        for has in (True, False):
            st = os.path.join(tmp, 'st-%s' % has); out = os.path.join(tmp, 'out-%s' % has); os.makedirs(out)
            if has: os.makedirs(os.path.join(st, '.pylibs'))
            else: os.makedirs(st)
            script = 'cd "%s"; source scripts/lib/generic_runtime.sh; STAGING="%s"; OUT_DIR="%s"; PORT=8080; MODE=direct; APP_ARGS="__DOCROOT__/app.py"\n%s' % (ROOT, st, out, m.group(1))
            r = subprocess.run(['bash', '-c', script], capture_output=True, text=True)
            try: j = json.load(open(os.path.join(out, 'runtime.json')))
            except Exception as e: j = {'err': str(e), 'stderr': r.stderr[-150:]}
            if has: check('python.sh + .pylibs: runtime.json hop le, env.PYTHONPATH = ${DOCROOT}/.pylibs (RuntimeConfig se thay luc chay)', j.get('env', {}).get('PYTHONPATH') == '${DOCROOT}/.pylibs' and j['env'].get('PYTHONUNBUFFERED') == '1', j)
            else: check('python.sh khong co .pylibs: runtime.json van hop le, KHONG co PYTHONPATH (hanh vi cu giu nguyen)', 'PYTHONPATH' not in j.get('env', {'x': 1}) and j.get('env', {}).get('PYTHONUNBUFFERED') == '1', j)

    # runtime khac / khong biet
    d = os.path.join(tmp, 'other'); wr(d + '/index.html', 'x')
    rc, out, err = deps('static', d)
    check('runtime static: khong lam gi', rc == 0 and out.strip() == '' and err.strip() == '')
finally:
    shutil.rmtree(tmp, ignore_errors=True)

print('\nTONG KET: pass=%d fail=%d' % (passed, failed))
sys.exit(1 if failed else 0)
