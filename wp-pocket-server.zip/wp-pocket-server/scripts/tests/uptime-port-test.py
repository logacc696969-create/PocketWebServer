#!/usr/bin/env python3
"""Ban PORT Python 1-1 cua logic uptime trong MonitorLogic.kt (H4) + chay CUNG bo vector voi MonitorLogicTest.kt.
Khi khong co kotlinc (xem HANDOFF 1be-A) day la cach duy nhat kiem thuat toan ngay; JVM test that chay o CI (run-monitorlogic-test.sh).
Ngoai ra DOI CHIEU van ban: cac hang so / ten ham / chuoi dinh dang trong Kotlin va PHP phai khop ban port nay."""
import math, os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
PASS = FAIL = 0
def ok(c, n):
    global PASS, FAIL
    if c: PASS += 1; print('  OK  ', n)
    else: FAIL += 1; print('  FAIL', n)

KEEP, MAXS = 30 * 24 * 3600, 4000
def parse(text):
    out = []
    for line in text.split('\n'):
        parts = line.strip().split(',')
        if len(parts) != 2: continue
        try: ts = int(parts[0].strip())
        except ValueError: continue
        f = parts[1].strip()
        if f not in ('0', '1'): continue
        out.append((ts, f == '1'))
    return out
def fmt(samples): return ''.join('%d,%d\n' % (t, 1 if u else 0) for t, u in samples)
def append(existing, now, up, keep=KEEP, mx=MAXS):
    allv = [s for s in existing if s[0] <= now and now - s[0] <= keep] + [(now, up)]
    return allv[-mx:] if len(allv) > mx else allv
def stats(samples, now, win):
    n = u = 0
    for t, up in samples:
        if t > now or now - t > win: continue
        n += 1; u += 1 if up else 0
    return n, u
def jround1(p):            # Math.round(p*10.0)/10.0 -> Double.toString
    v = math.floor(p * 10.0 + 0.5) / 10.0
    return repr(v)
def line(label, st):
    n, u = st
    if n == 0: return '%s: chua co du lieu' % label
    return '%s: %s%% (%d/%d lan kiem tra)' % (label, jround1(u * 100.0 / n), u, n)

ok(stats([], 1, 86400)[0] == 0, 'chua co mau -> 0 mau')
ok(line('24 gio', (0, 0)) == '24 gio: chua co du lieu', 'dong chu khi chua co du lieu')
ok(line('24 gio', (96, 95)) == '24 gio: 99.0% (95/96 lan kiem tra)', '95/96 -> 99.0%')
ok(line('7 ngay', (3, 2)).startswith('7 ngay: 66.7%'), '2/3 -> 66.7%')
ok(line('30 ngay', (5, 5)) == '30 ngay: 100.0% (5/5 lan kiem tra)', '100.0% (Double.toString co ".0")')
csv = '1799990000,1\nrac\n1799990900,0\n,1\n1799991800,2\n1799991800,1\n  1799992700 , 1  \n'
p = parse(csv)
ok(len(p) == 4 and p[1][1] is False and p[3][0] == 1799992700, 'parse bo dong hong, giu dong co khoang trang')
ok(parse(fmt(p)) == p, 'format -> parse khu hoi')
ok(stats(p, 1799993000, 3600) == (4, 3), 'cua so 1 gio: 4 mau, 3 len')
ok(stats(p, 1799993000, 1000)[0] == 1, 'cua so hep chi con mau gan nhat')
ok(stats(p, 1799991000, 99999)[0] == 2, 'mau tuong lai bi bo khoi thong ke')
a = append(p, 1799993600, False)
ok(len(a) == 5 and a[-1] == (1799993600, False), 'append them o cuoi')
ag = append(p, 1799990000 + 40 * 86400, True)
ok(len(ag) == 1 and ag[0][1], 'mau cu hon 30 ngay bi cat')
sk = append(p, 1799991000, True)
ok(len(sk) == 3 and all(t <= 1799991000 for t, _ in sk), 'dong ho lui: mau tuong lai bi bo')
many = [(1799000000 + i, True) for i in range(1, 51)]
cp = append(many, 1799000100, False, mx=10)
ok(len(cp) == 10 and cp[-1][1] is False and cp[0][0] == 1799000042, 'gioi han so mau, giu mau MOI NHAT')

# ---- doi chieu van ban voi Kotlin that
kt = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/MonitorLogic.kt'), encoding='utf8').read()
ok('const val UPTIME_KEEP_SEC: Long = 30L * 24 * 3600' in kt, 'Kotlin: UPTIME_KEEP_SEC = 30 ngay')
ok('const val UPTIME_MAX_SAMPLES: Int = 4000' in kt, 'Kotlin: toi da 4000 mau')
ok('"$label: chua co du lieu"' in kt and 'lan kiem tra)"' in kt, 'Kotlin: chuoi dinh dang khop ban port')
mon = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/Monitoring.kt'), encoding='utf8').read()
ok('File(File(context.filesDir, "lamp-run"), "uptime.csv")' in mon, 'Monitoring ghi dung lamp-run/uptime.csv')
hc = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/HealthCheckWorker.kt'), encoding='utf8').read()
ok(hc.count('Monitoring.recordUptimeSample(') == 2, 'HealthCheckWorker ghi mau o ca 2 nhanh (service chet = xuong; HTTP = ket qua that)')
ok('Monitoring.recordUptimeSample(applicationContext, false)' in hc and 'Monitoring.recordUptimeSample(applicationContext, responding)' in hc, 'gia tri up dung o tung nhanh')
php = open(os.path.join(ROOT, 'scripts/runtimes/templates/admin-metrics.php'), encoding='utf8').read()
ok("lamp-run/uptime.csv" in php or "'/uptime.csv'" in php, 'metrics.php doc cung file uptime.csv')
print('TONG KET: pass=%d fail=%d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
