#!/usr/bin/env python3
"""Bien dich TOAN BO ma Kotlin cua app (48 tep) voi android.jar + stub androidx + R/ViewBinding tu sinh (HANDOFF.md muc 1br-H).
Ly do: CI that (Gradle) tung hong vi `Context.MODE_PRIVATE` thieu `import android.content.Context` o ServerForegroundService.kt - tep dung androidx
nen cac test Kotlin truoc day (chi bien dich lop thuan) khong bien dich no. Test nay bat dung loai loi do, kem DOI CHUNG AM (bo import -> phai bao loi).

Can: kotlinc (bien moi KOTLINC, mac dinh `kotlinc` trong PATH), android.jar (bien moi ANDROID_JAR; vd platforms/android-34/android.jar), tuy chon KOTLIN_STDLIB
(duong dan kotlin-stdlib.jar neu kotlinc cua ban khong tu them). Thieu kotlinc hoac android.jar thi BO QUA (exit 0).
"""
import glob, os, re, shutil, subprocess, sys, tempfile
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
SRC = os.path.join(ROOT, 'app', 'src', 'main', 'java')
RES = os.path.join(ROOT, 'app', 'src', 'main', 'res')
STUBS = os.path.join(HERE, 'kotlin-stubs')
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:600]) if d else ''))


def camel(s):
    p = s.split('_')
    return p[0] + ''.join(x[:1].upper() + x[1:] for x in p[1:])


def pascal(s):
    return ''.join(x[:1].upper() + x[1:] for x in s.split('_'))


def view_type(tag):
    if '.' not in tag:
        return 'android.view.' + tag if tag in ('View', 'ViewGroup', 'ViewStub', 'SurfaceView', 'TextureView') else 'android.widget.' + tag
    last = tag.split('.')[-1]
    for k, b in (('Switch', 'android.widget.Switch'), ('Button', 'android.widget.Button'), ('EditText', 'android.widget.EditText'), ('TextView', 'android.widget.TextView'),
                 ('Layout', 'android.view.ViewGroup'), ('Toolbar', 'android.view.ViewGroup'), ('CardView', 'android.widget.FrameLayout')):
        if k in last:
            return b
    return 'android.view.View'


def generate(outdir):
    """R.kt + *Binding.kt (giong cac lop AGP sinh) tu res/."""
    names = {k: set() for k in ('string', 'color', 'dimen', 'style', 'array', 'plurals', 'integer', 'bool', 'drawable', 'layout', 'xml', 'mipmap', 'id', 'anim', 'menu', 'raw', 'attr')}
    kinds = {'string': 'string', 'color': 'color', 'dimen': 'dimen', 'style': 'style', 'string-array': 'array', 'integer-array': 'array', 'array': 'array',
             'plurals': 'plurals', 'integer': 'integer', 'bool': 'bool', 'attr': 'attr'}
    for f in glob.glob(RES + '/values*/*.xml'):
        for e in ET.parse(f).getroot():
            n = e.get('name')
            t = e.get('type') if e.tag == 'item' and e.get('type') else kinds.get(e.tag)
            if n and t in names:
                names[t].add(n.replace('.', '_'))
    for d in glob.glob(RES + '/*/'):
        t = os.path.basename(d.rstrip('/')).split('-')[0]
        if t in names and t != 'values':
            for f in os.listdir(d):
                names[t].add(f.split('.')[0])
    ns = '{http://schemas.android.com/apk/res/android}'
    for f in glob.glob(RES + '/layout*/*.xml'):
        base = os.path.basename(f)[:-4]
        props, seen = [], set()
        for e in ET.parse(f).getroot().iter():
            i = e.get(ns + 'id')
            if i and i.startswith('@+id/'):
                n = i[5:]
                names['id'].add(n)
                if n not in seen:
                    seen.add(n)
                    props.append('    val %s: %s = TODO()' % (camel(n), view_type(e.tag)))
        cls = pascal(base) + 'Binding'
        open(os.path.join(outdir, cls + '.kt'), 'w').write(
            'package com.wppocket.server.databinding\nclass %s {\n    val root: android.view.View = TODO()\n%s\n    companion object {\n'
            '        @JvmStatic fun inflate(li: android.view.LayoutInflater): %s = TODO()\n'
            '        @JvmStatic fun inflate(li: android.view.LayoutInflater, p: android.view.ViewGroup?, a: Boolean): %s = TODO()\n    }\n}\n' % (cls, '\n'.join(props), cls, cls))
    out = ['package com.wppocket.server', 'object R {']
    for t, ns_ in names.items():
        out.append('  object %s {' % t)
        out += ['    const val %s: Int = 0' % n for n in sorted(ns_)]
        out.append('  }')
    out.append('}')
    open(os.path.join(outdir, 'R.kt'), 'w').write('\n'.join(out) + '\n')


def compile_tree(kotlinc, android_jar, stdlib, src_dir, tmp, tag):
    gen = os.path.join(tmp, 'gen-' + tag)
    out = os.path.join(tmp, 'out-' + tag)
    os.makedirs(gen)
    os.makedirs(out)
    generate(gen)
    cp = os.pathsep.join([p for p in (android_jar, stdlib) if p])
    kts = [os.path.join(dp, f) for dp, _, fs in os.walk(src_dir) for f in fs if f.endswith('.kt')]
    javas = [os.path.join(dp, f) for dp, _, fs in os.walk(os.path.join(STUBS, 'java')) for f in fs if f.endswith('.java')]
    cmd = [kotlinc, '-nowarn', '-cp', cp, '-d', out] + kts + glob.glob(gen + '/*.kt') + [os.path.join(STUBS, 'WorkKt.kt')] + javas
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    errs = [l for l in (r.stdout + r.stderr).splitlines() if re.search(r'\berror:', l)]
    nclass = sum(len([f for f in fs if f.endswith('.class')]) for _, _, fs in os.walk(out))
    return r.returncode, errs, nclass, len(kts)


def main():
    kotlinc = os.environ.get('KOTLINC') or shutil.which('kotlinc')
    android_jar = os.environ.get('ANDROID_JAR')
    if not kotlinc or not android_jar or not os.path.isfile(android_jar):
        print('(bo qua: can kotlinc va ANDROID_JAR=<...>/android.jar; xem dau tep)')
        return 0
    stdlib = os.environ.get('KOTLIN_STDLIB')
    tmp = tempfile.mkdtemp(prefix='ktapp-')
    try:
        rc, errs, ncls, nkt = compile_tree(kotlinc, android_jar, stdlib, SRC, tmp, 'real')
        check('bien dich %d tep Kotlin cua app khong loi (%d lop)' % (nkt, ncls), rc == 0 and not errs and ncls > 100, (rc, errs[:5], ncls))
        # doi chung am: ban sao khong co "import android.content.Context" o ServerForegroundService.kt (dung loi CI that da gap) -> PHAI bao loi
        neg = os.path.join(tmp, 'neg-src')
        shutil.copytree(SRC, neg)
        f = os.path.join(neg, 'com', 'wppocket', 'server', 'ServerForegroundService.kt')
        s = open(f, encoding='utf-8').read()
        has = re.search(r'^import android\.content\.Context\s*$', s, re.M) is not None
        check('ServerForegroundService.kt co "import android.content.Context" (dung Context.MODE_PRIVATE)', has and 'Context.MODE_PRIVATE' in s)
        open(f, 'w', encoding='utf-8').write(re.sub(r'^import android\.content\.Context\s*$\n', '', s, flags=re.M))
        rc2, errs2, _, _ = compile_tree(kotlinc, android_jar, stdlib, neg, tmp, 'neg')
        check('DOI CHUNG AM: bo import Context -> trinh bien dich BAO loi "unresolved reference Context"', rc2 != 0 and any('Context' in e and 'ServerForegroundService.kt' in e for e in errs2), errs2[:3])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
