#!/usr/bin/env python3
"""Kiem thu TICH HOP _admin/health.php (HANDOFF.md muc 1bk; PDF 2 C9/I8/Q12/R15/R17/O1) bang PHP THAT (php -S) + MARIADB THAT.
Phan A (chi can php): khung trang, memory_limit, 3 tang gioi han upload, uptime tu uptime.csv, co bao tri/tunnel, WordPress chua/da cai,
wp-config that cua du an (khong bi bao WP_DEBUG nham), cac duong "khong ket noi duoc DB" khong sinh Warning/Fatal, MariaDB dang ngu.
Phan B (can mariadbd...): doc option `cron` that, bai hen gio qua gio, autoload lon, escape XSS tieu de bai, khong ghi gi vao DB.
Thieu php -> bo qua (exit 0); thieu MariaDB -> chi bo qua phan B. Dung bien HEALTH_PAGE de thay trang (doi chung am)."""
import json, getpass, importlib.util, os, re, shutil, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check
PAGE = os.environ.get('HEALTH_PAGE') or os.path.join(ROOT, 'scripts', 'runtimes', 'templates', 'admin-health.php')
DB_OS_USER = 'root' if os.geteuid() == 0 else getpass.getuser()
LAN = '192.168.1.5'


def wr(p, t):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w').write(t)


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p


def make_tree(tmp):
    app, run, www0, adm0 = sec.build_tree(tmp)
    www = os.path.join(app, 'www')          # health.php doc APP_HOME/www lam docroot (nhu that)
    shutil.move(www0, www)
    shutil.copy(PAGE, os.path.join(www, '_admin', 'health.php'))
    return app, run, www


def start_php(www, tmp, app, extra=()):
    s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
    cmd = ['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
           '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=1', '-d', 'error_reporting=E_ALL']
    for e in extra:
        cmd += ['-d', e]
    p = subprocess.Popen(cmd, env=dict(os.environ, APP_HOME=app, EXT_DIR=os.path.join(tmp, 'ext')), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
        except OSError:
            time.sleep(0.1)
    return p, port


_CLIENTS = {}


def page(port):
    """GET health.php bang 1 phien da dang nhap/cong (dang nhap 1 lan, tai dung - khong tao hang chuc phien)."""
    c = _CLIENTS.get(port)
    if c is None:
        c = sec.Client(port, LAN)
        if not c.login():
            return None, ''
        _CLIENTS[port] = c
    sc, body, _ = c.req('GET', '/_admin/health.php')
    return sc, body


def row(body, label):
    """(trang thai, noi dung) cua 1 hang kiem tra; None neu khong co."""
    m = re.search(r'<div class="k">%s</div>\s*<div class="v"><span class="tag (\w+)">[^<]*</span>([^<]*)</div>' % re.escape(label), body)
    return (m.group(1), m.group(2)) if m else None


def clean(body, name):
    check(name + ': khong co Fatal/Warning/Notice/Deprecated', not sec.FATAL_RE.search(body) and not sec.WARN_RE.search(body),
          (sec.FATAL_RE.search(body) or sec.WARN_RE.search(body)).group(0) if (sec.FATAL_RE.search(body) or sec.WARN_RE.search(body)) else '')


def ser_cron(events):
    """Chuoi serialize() cua option `cron` cua WordPress: {ts: {hook: {chu_ky: {schedule:false,args:[]}}}, version:2}."""
    out = ''
    for i, (ts, hook) in enumerate(sorted(events)):
        sig = ('%032x' % (i + 1))
        out += 'i:%d;a:1:{s:%d:"%s";a:1:{s:32:"%s";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}' % (ts, len(hook), hook, sig)
    return 'a:%d:{%ss:7:"version";i:2;}' % (len(events) + 1, out)


def real_wp_config():
    """wp-config.php that: lay nguyen khoi heredoc trong scripts/lib/site_source.sh (de bat loi regex voi file that, khong voi file tu bia)."""
    src = open(os.path.join(ROOT, 'scripts', 'lib', 'site_source.sh'), encoding='utf8').read()
    m = re.search(r'wp-config\.php\.template" <<PHP\n(.*?)\nPHP\n', src, re.S)
    txt = m.group(1).replace('\\$', '$').replace('${salts}', "define('AUTH_KEY', 'x');").replace('__MYSQL_SOCK__', '/tmp/x.sock')
    return txt


def main():
    if not shutil.which('php'):
        print('(bo qua: khong co php)'); return 0
    tmp = tempfile.mkdtemp(prefix='health-')
    procs = []
    try:
        os.chmod(tmp, 0o755)
        app, run, www = make_tree(tmp)
        now = int(time.time())

        # ============ PHAN A: khong can DB ============
        print('== A1. khung trang + gioi han PHP (memory 32M, upload 64M, post 100M) ==')
        wr(os.path.join(run, 'nginx.conf'), 'http {\n  client_max_body_size 8m;\n}\n')
        p1, port1 = start_php(www, tmp, app, ['memory_limit=32M', 'upload_max_filesize=64M', 'post_max_size=100M'])
        procs.append(p1)
        sc, body = page(port1)
        check('GET health.php sau dang nhap: 200 + dung tieu de', sc == 200 and 'Suc khoe site' in body, sc)
        clean(body, 'A1')
        r = row(body, 'memory_limit'); check('memory_limit 32M bi CANH BAO (duoi 64M)', r and r[0] == 'warn' and '32M' in r[1], r)
        r = row(body, 'Gioi han upload'); check('nginx 8m < PHP upload 64M => canh bao co ghi "413" (loi that nguoi dung se gap)', r and r[0] == 'warn' and '413' in r[1] and '8 MB' in r[1], r)
        wr(os.path.join(run, 'nginx.conf'), 'client_max_body_size 128m;\n')
        r = row(page(port1)[1], 'Gioi han upload'); check('nginx 128m >= upload 64M, post 100M >= upload => OK ("3 tang khop")', r and r[0] == 'ok', r)
        wr(os.path.join(run, 'nginx.conf'), '# khong co dong gioi han\n')
        r = row(page(port1)[1], 'Gioi han upload'); check('khong doc duoc gioi han nginx -> khong bao nham (chi so sanh PHP)', r and r[0] == 'ok' and 'nginx client_max_body_size' not in r[1], r)
        r = row(body, 'Dung luong'); check('co hang Dung luong (disk that cua may chay test)', r is not None and r[0] in ('ok', 'warn', 'bad'), r)
        r = row(body, 'Extension PHP'); check('co hang Extension PHP', r is not None, None)

        print('== A2. post_max_size < upload_max_filesize => canh bao ==')
        p2, port2 = start_php(www, tmp, app, ['upload_max_filesize=64M', 'post_max_size=8M'])
        procs.append(p2)
        r = row(page(port2)[1], 'Gioi han upload'); check('post_max 8M < upload 64M => canh bao', r and r[0] == 'warn' and 'post_max_size nho hon' in r[1], r)
        p2.terminate()

        print('== A2b. diem suc khoe gop + muc bao mat (HANDOFF.md muc 1br) ==')
        b0 = page(port1)[1]
        m = re.search(r'id="health-score">(\d+)</b>/100', b0)
        n_bad = len(re.findall(r'<div class="v"><span class="tag bad">', b0)); n_warn = len(re.findall(r'<div class="v"><span class="tag warn">', b0))
        check('co diem suc khoe gop va khop cong thuc 100 - 20*bad - 6*warn (san 0)', bool(m) and int(m.group(1)) == max(0, 100 - 20 * n_bad - 6 * n_warn), (m.group(1) if m else None, n_bad, n_warn))
        r = row(b0, 'Quet ma doc'); check('chua co ket qua quet: hang "Quet ma doc" canh bao (khong bao nham sach)', r and r[0] == 'warn' and 'chua co ket qua quet' in r[1], r)
        wr(os.path.join(run, 'security-scan.json'), json.dumps({'v': 1, 'at': now - 120, 'files': 321, 'counts': {'critical': 1, 'high': 2, 'medium': 0, 'info': 0}, 'findings': []}))
        wr(os.path.join(run, 'realip-missing'), '')
        b1 = page(port1)[1]
        r = row(b1, 'Quet ma doc'); check('quet thay nghiem trong/cao: hang DO co so lieu', r and r[0] == 'bad' and '1 nghiem trong' in r[1] and '2 cao' in r[1] and '321 file' in r[1], r)
        r = row(b1, 'IP khach that'); check('thieu realip: hang DO', r and r[0] == 'bad', r)
        m1 = re.search(r'id="health-score">(\d+)</b>', b1)
        check('them hang DO (quet nghiem trong + thieu realip), bo hang canh bao cu: diem tinh lai dung cong thuc', bool(m1) and int(m1.group(1)) == max(0, 100 - 20 * len(re.findall(r'<div class="v"><span class="tag bad">', b1)) - 6 * len(re.findall(r'<div class="v"><span class="tag warn">', b1))) and int(m1.group(1)) < int(m.group(1)), (m.group(1) if m else None, m1.group(1) if m1 else None))
        clean(b1, 'A2b')
        wr(os.path.join(run, 'security-scan.json'), json.dumps({'v': 1, 'at': now - 60, 'files': 400, 'counts': {'critical': 0, 'high': 0, 'medium': 0, 'info': 1}, 'findings': []}))
        os.remove(os.path.join(run, 'realip-missing'))
        r = row(page(port1)[1], 'Quet ma doc'); check('quet sach: hang XANH', r and r[0] == 'ok', r)
        wr(os.path.join(run, 'security-scan.json'), json.dumps({'v': 1, 'at': now - 90000, 'files': 400, 'counts': {'critical': 0, 'high': 0, 'medium': 0, 'info': 0}, 'findings': []}))
        r = row(page(port1)[1], 'Quet ma doc'); check('ket qua quet da cu (> 6 gio): canh bao', r and r[0] == 'warn', r)
        wr(os.path.join(run, 'security-scan.json'), '{rac')
        b2 = page(port1)[1]
        r = row(b2, 'Quet ma doc'); check('security-scan.json hong: khong Fatal, hang canh bao', r and r[0] == 'warn' and not sec.FATAL_RE.search(b2), r)
        os.remove(os.path.join(run, 'security-scan.json'))

        print('== A3. uptime tu uptime.csv ==')
        wr(os.path.join(run, 'uptime.csv'), '\n'.join([
            '%d,1' % (now - 100), '%d,1' % (now - 1000), '%d,1' % (now - 5000), '%d,1' % (now - 9000), '%d,0' % (now - 20000),
            '%d,1' % (now - 200000),       # ngoai 24h: khong tinh
            '%d,0' % (now + 5000),         # tuong lai (dong ho chinh lui): khong tinh
            'rac', ',1', '123,7', '%d,1,extra' % now, ''
        ]))
        r = row(page(port1)[1], 'Uptime 24 gio')
        check('4/5 mau len = 80.0% (bo qua mau cu >24h, mau tuong lai, dong rac), trang thai LOI (<90%)', r and r[0] == 'bad' and '80.0% (4/5 lan kiem tra)' in r[1], r)
        os.remove(os.path.join(run, 'uptime.csv'))
        r = row(page(port1)[1], 'Uptime 24 gio'); check('khong co uptime.csv -> "chua co du lieu" (khong bao 100%)', r and r[0] == 'info' and 'chua co du lieu' in r[1], r)

        print('== A4. co bao tri / tunnel ==')
        wr(os.path.join(run, 'maintenance-mode'), '')
        wr(os.path.join(run, 'tunnel-named'), '')
        b = page(port1)[1]
        r = row(b, 'Che do bao tri'); check('co maintenance-mode -> CHU Y "DANG BAT"', r and r[0] == 'warn' and 'DANG BAT' in r[1], r)
        r = row(b, 'Tunnel'); check('co tunnel-named -> Named Tunnel', r and 'Named Tunnel' in r[1], r)
        os.remove(os.path.join(run, 'maintenance-mode')); os.remove(os.path.join(run, 'tunnel-named'))
        b = page(port1)[1]
        r = row(b, 'Che do bao tri'); check('bo co -> OK "tat"', r and r[0] == 'ok', r)
        r = row(b, 'Tunnel'); check('khong co tunnel-named -> Quick Tunnel/chua bat', r and 'Quick Tunnel' in r[1], r)

        print('== A5. WordPress chua cai / da cai, wp-config that ==')
        b = page(port1)[1]
        r = row(b, 'WordPress'); check('chua co wp-includes/version.php -> "chua cai", khong cham DB', r and 'chua cai' in r[1] and row(b, 'Database / WP-Cron') is None, r)
        wr(os.path.join(www, 'wp-includes', 'version.php'), "<?php\n$wp_version = '6.8.1';\n$wp_db_version = 12345;\n")
        wr(os.path.join(www, 'wp-config.php'), real_wp_config())
        b = page(port1)[1]
        clean(b, 'A5 (wp-config that cua du an)')
        r = row(b, 'WordPress'); check('doc dung phien ban tu version.php: 6.8.1', r and '6.8.1' in r[1], r)
        check('wp-config.php THAT cua du an (WP_DEBUG false) KHONG bi bao WP_DEBUG nham', row(b, 'WP_DEBUG') is None, row(b, 'WP_DEBUG'))
        r = row(b, 'Database / WP-Cron'); check('khong co mysql.sock -> thong bao "Khong ket noi duoc MariaDB" (khong loi)', r and 'Khong ket noi duoc MariaDB' in r[1], r)
        wr(os.path.join(run, 'mariadb-asleep'), '')
        r = row(page(port1)[1], 'Database / WP-Cron'); check('MariaDB dang NGU (Auto-Sleep) -> noi ro, khong co ket noi danh thuc DB', r and 'NGU' in r[1], r)
        os.remove(os.path.join(run, 'mariadb-asleep'))
        wr(os.path.join(www, 'wp-config.php'), real_wp_config().replace("define('WP_DEBUG', false)", "define('WP_DEBUG', true)"))
        r = row(page(port1)[1], 'WP_DEBUG'); check('WP_DEBUG=true trong wp-config -> CHU Y', r and r[0] == 'warn', r)
        wr(os.path.join(www, 'wp-config.php'), "<?php\ndefine('DB_ENGINE', 'sqlite');\n$table_prefix = 'wp_';\n")
        b = page(port1)[1]; clean(b, 'A5 (che do SQLite, khong co DB_NAME)')
        r = row(b, 'Database / WP-Cron'); check('wp-config kieu SQLite (khong DB_NAME) -> "Khong doc duoc thong tin DB", khong loi', r and 'Khong doc duoc thong tin DB' in r[1], r)

        print('== A6. chi doc: khong ghi/sua file nao trong docroot ==')
        before = sec.snapshot([www])
        page(port1)
        check('GET health.php khong tao/sua file nao trong docroot', sec.snapshot([www]) == before)
        c = sec.Client(port1, '8.8.8.8')
        sc, b2, _ = c.req('GET', '/_admin/health.php')
        check('IP ngoai LAN -> 403, khong lo noi dung', sc == 403 and 'Suc khoe site' not in b2, sc)
        c = sec.Client(port1, LAN)
        sc, b2, _ = c.req('GET', '/_admin/health.php')
        check('chua dang nhap -> form dang nhap, khong lo thong tin he thong', sc == 200 and 'admin_password' in b2 and 'memory_limit' not in b2, sc)

        # ============ PHAN B: MariaDB that ============
        mariadbd = which('mariadbd', 'mysqld'); install = which('mariadb-install-db', 'mysql_install_db'); cli = which('mariadb', 'mysql')
        if not all((mariadbd, install, cli)):
            print('(bo qua phan B: thieu MariaDB that)')
        else:
            print('== B. MariaDB that: option cron, bai hen gio, autoload ==')
            data = os.path.join(tmp, 'data'); sock = os.path.join(run, 'mysql.sock')
            r = subprocess.run([install, '--user=' + DB_OS_USER, '--datadir=' + data, '--auth-root-authentication-method=normal'], capture_output=True, text=True)
            if r.returncode != 0:
                print('(bo qua phan B: khong khoi tao duoc datadir: %s)' % r.stderr[-120:])
            else:
                db = subprocess.Popen([mariadbd] + ([] if os.geteuid() != 0 else ['--user=root']) + ['--datadir=' + data, '--socket=' + sock, '--skip-networking',
                                       '--pid-file=' + os.path.join(tmp, 'm.pid'), '--innodb-buffer-pool-size=32M', '--log-error=' + os.path.join(tmp, 'err.log')],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                procs.append(db)
                for _ in range(60):
                    if os.path.exists(sock) and subprocess.run([cli, '--socket=' + sock, '-uroot', '-e', 'select 1'], capture_output=True).returncode == 0:
                        break
                    time.sleep(0.5)
                else:
                    print('(bo qua phan B: mariadbd khong len)'); db = None
                if db is not None:
                    def sql(q, dbname=None):
                        cmd = [cli, '--socket=' + sock, '--default-character-set=utf8mb4', '-uroot', '-N', '-B', '-e', q]
                        if dbname: cmd.append(dbname)
                        rr = subprocess.run(cmd, capture_output=True, text=True)
                        if rr.returncode != 0:
                            print('   [sql loi] %s -> %s' % (q[:70], rr.stderr.strip()[:120]))
                        return rr.stdout.strip()
                    sql("CREATE DATABASE wordpress CHARACTER SET utf8mb4")
                    sql("CREATE USER 'wordpress'@'localhost' IDENTIFIED BY 'wordpress'")
                    sql("GRANT ALL ON `wordpress`.* TO 'wordpress'@'localhost'")
                    sql("CREATE TABLE wp_options (option_id INT AUTO_INCREMENT PRIMARY KEY, option_name VARCHAR(191), option_value LONGTEXT, autoload VARCHAR(20) DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", 'wordpress')
                    sql("CREATE TABLE wp_posts (ID INT AUTO_INCREMENT PRIMARY KEY, post_title TEXT, post_status VARCHAR(20), post_date_gmt DATETIME) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", 'wordpress')
                    late = ser_cron([(now - 1800, 'publish_future_post'), (now + 7200, 'wp_version_check'), (now + 86400, 'wp_update_plugins')])
                    sql("INSERT INTO wp_options (option_name, option_value, autoload) VALUES ('cron', '%s', 'on')" % late, 'wordpress')
                    sql("INSERT INTO wp_options (option_name, option_value, autoload) VALUES ('big', REPEAT('x', 1300000), 'yes')", 'wordpress')
                    sql("INSERT INTO wp_options (option_name, option_value, autoload) VALUES ('khong_autoload', REPEAT('y', 3000000), 'no'), ('nho', 'abc', 'yes')", 'wordpress')
                    fmt = lambda t: time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(t))
                    sql("INSERT INTO wp_posts (post_title, post_status, post_date_gmt) VALUES ('Bai bi tre', 'future', '%s'), ('<script>alert(1)</script> Bai tuong lai', 'future', '%s'), ('Ban nhap', 'draft', '0000-00-00 00:00:00')" % (fmt(now - 1800), fmt(now + 172800)), 'wordpress')
                    wr(os.path.join(www, 'wp-config.php'), real_wp_config())
                    wr(os.path.join(run, 'nginx.conf'), 'client_max_body_size 128m;\n')
                    snap_db = sql("SELECT (SELECT COUNT(*) FROM wp_options), (SELECT COUNT(*) FROM wp_posts), (SELECT SUM(LENGTH(option_value)) FROM wp_options)", 'wordpress')

                    sc, b = page(port1)
                    clean(b, 'B1 (DB that)')
                    r = row(b, 'Kich thuoc database'); check('doc duoc kich thuoc database that (MB)', r and re.search(r'\d+(\.\d+)? (MB|KB|GB)', r[1]), r)
                    r = row(b, 'Autoload options'); check('autoload 1.3MB (chi tinh autoload yes/on, KHONG tinh option 3MB autoload=no) -> CHU Y', r and r[0] == 'warn' and '1.2 MB' in r[1], r)
                    r = row(b, 'WP-Cron'); check('bai hen gio qua gio 30 phut -> LOI, huong dan cron event run --due-now', r and r[0] == 'bad' and '1 bai hen gio DA QUA gio' in r[1] and 'due-now' in r[1], r)
                    check('bang WP-Cron liet ke 3 tac vu, tac vu qua han to mau "late"', 'publish_future_post' in b and 'wp_version_check' in b and 'wp_update_plugins' in b and re.search(r'publish_future_post</td><td class="late">tre 30 phut', b) is not None, re.findall(r'<tr><td>[^<]*</td><td[^>]*>[^<]*</td></tr>', b)[:4])
                    check('wp_version_check sap toi KHONG bi to mau late', re.search(r'wp_version_check</td><td class="">sau 2 gio', b) is not None)
                    check('bang bai hen gio co 2 bai (khong co ban nhap), bai tre to mau late', 'Bai bi tre' in b and 'Bai tuong lai' in b and 'Ban nhap' not in b and re.search(r'Bai bi tre</td>\s*<td class="late">', b) is not None)
                    check('tieu de bai chua <script> duoc ESCAPE (XSS)', '<script>alert(1)' not in b and '&lt;script&gt;alert(1)' in b)
                    check('trang khong ghi gi vao DB (so dong + tong do dai khong doi)', sql("SELECT (SELECT COUNT(*) FROM wp_options), (SELECT COUNT(*) FROM wp_posts), (SELECT SUM(LENGTH(option_value)) FROM wp_options)", 'wordpress') == snap_db)

                    sql("DELETE FROM wp_posts WHERE post_title = 'Bai bi tre'", 'wordpress')
                    r = row(page(port1)[1], 'WP-Cron'); check('con tac vu qua han nhung KHONG con bai hen gio tre -> CHU Y (khong phai LOI)', r and r[0] == 'warn' and '1 tac vu qua han' in r[1], r)
                    sql("UPDATE wp_options SET option_value = '%s' WHERE option_name = 'cron'" % ser_cron([(now + 600, 'wp_version_check')]), 'wordpress')
                    r = row(page(port1)[1], 'WP-Cron'); check('khong co gi qua han -> OK', r and r[0] == 'ok' and '1 tac vu dang cho' in r[1], r)
                    sql("UPDATE wp_options SET option_value = 'khong-phai-serialize{' WHERE option_name = 'cron'", 'wordpress')
                    b = page(port1)[1]; clean(b, 'B2 (option cron hong)')
                    check('option cron hong -> khong co hang WP-Cron, khong loi', row(b, 'WP-Cron') is None and 'WP-Cron: tac vu sap toi' not in b)
                    sql("DELETE FROM wp_options WHERE option_name = 'cron'", 'wordpress')
                    b = page(port1)[1]; clean(b, 'B2 (khong co option cron)')
                    check('khong co option cron -> khong co hang WP-Cron, khong loi', row(b, 'WP-Cron') is None)
                    sql("TRUNCATE wp_posts", 'wordpress'); sql("DELETE FROM wp_options WHERE option_name = 'big'", 'wordpress')
                    r = row(page(port1)[1], 'Autoload options'); check('autoload nho -> OK', r and r[0] == 'ok', r)
                    wr(os.path.join(www, 'wp-config.php'), real_wp_config().replace("'DB_PASSWORD', 'wordpress'", "'DB_PASSWORD', 'sai-mat-khau'"))
                    b = page(port1)[1]; clean(b, 'B3 (sai mat khau DB: mysqli that bao loi)')
                    r = row(b, 'Database / WP-Cron'); check('sai mat khau DB -> thong bao "Khong ket noi duoc MariaDB", khong Fatal/Warning', r and 'Khong ket noi duoc MariaDB' in r[1], r)
                    wr(os.path.join(www, 'wp-config.php'), real_wp_config().replace("$table_prefix = 'wp_'", "$table_prefix = 'khong_ton_tai_'"))
                    b = page(port1)[1]; clean(b, 'B3 (prefix bang sai)')
                    check('prefix bang khong ton tai -> khong Fatal/Warning; van co hang Kich thuoc database', row(b, 'Kich thuoc database') is not None)
    finally:
        for p in procs:
            try:
                p.terminate(); p.wait(timeout=10)
            except Exception:
                try: p.kill()
                except Exception: pass
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL))
    return 0 if sec.FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
