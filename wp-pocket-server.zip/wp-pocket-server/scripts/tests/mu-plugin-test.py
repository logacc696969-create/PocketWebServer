#!/usr/bin/env python3
"""Kiem thu mu-plugin wppocket-maintenance.php (HANDOFF.md muc 1az, B6).

Trich NGUYEN VAN mu-plugin tu scripts/lib/site_source.sh (khong chep ban sao), chay bang PHP THAT
voi stub toi thieu cua WordPress (add_action/add_filter/WP-Cron/$wpdb). Kiem tra:
  - co "defer-heavy-jobs" moi  -> handler bao tri DB KHONG chay OPTIMIZE, hen thu lai +1h;
                                   4 filter auto_update_* tra false (du dau vao la true);
  - khong co / co cu (>2h) / khong co APP_HOME -> chay binh thuong, filter di qua nguyen gia tri;
  - bien gioi 119 phut / 121 phut.
Doi chung am: MU_SOURCE_SH=<site_source.sh cu> -> ban chua co B6 phai DO.
"""
import json, os, re, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.environ.get("MU_SOURCE_SH", os.path.join(HERE, "..", "lib", "site_source.sh"))

passed = failed = 0
def check(name, cond, extra=""):
    global passed, failed
    if cond:
        passed += 1; print("PASS:", name)
    else:
        failed += 1; print("FAIL:", name, extra)

def extract_plugin(path):
    text = open(path, encoding="utf-8").read()
    m = re.search(r"wppocket-maintenance\.php\" <<'PHP'\n(.*?)\nPHP\n", text, re.S)
    if not m:
        raise SystemExit("Khong trich duoc mu-plugin tu " + path)
    return m.group(1) + "\n"

HARNESS = r"""<?php
// Stub WordPress toi thieu
define('ABSPATH', '/tmp/'); define('HOUR_IN_SECONDS', 3600); define('DAY_IN_SECONDS', 86400);
$H = ['actions' => [], 'filters' => []]; $SINGLE = []; $SCHEDULED = [];
function add_action($t, $f, $p = 10, $n = 1) { global $H; $H['actions'][$t][] = $f; }
function add_filter($t, $f, $p = 10, $n = 1) { global $H; $H['filters'][$t][] = $f; }
function apply_filters($t, $v) { global $H; foreach (($H['filters'][$t] ?? []) as $f) { $v = $f($v); } return $v; }
function do_action($t) { global $H; foreach (($H['actions'][$t] ?? []) as $f) { $f(); } }
function wp_next_scheduled($h) { global $SCHEDULED; return $SCHEDULED[$h] ?? false; }
function wp_schedule_event($t, $r, $h) { global $SCHEDULED; $SCHEDULED[$h] = $t; return true; }
function wp_schedule_single_event($t, $h) { global $SINGLE; $SINGLE[] = [$t, $h]; return true; }
function esc_sql($s) { return $s; }
function wp_delete_post_revision($id) { global $WDB; $WDB->deleted[] = $id; }
class FakeWpdb {
    public $posts = 'wp_posts'; public $prefix = 'wp_'; public $queries = []; public $deleted = [];
    function prepare($q, ...$a) { return $q; }
    function esc_like($s) { return $s; }
    function get_col($q) { if (stripos($q, 'SHOW TABLES') !== false) return ['wp_posts', 'wp_options', 'wp_users']; return [11, 12]; }
    function query($q) { $this->queries[] = $q; return 1; }
}
$WDB = new FakeWpdb; $wpdb = $WDB;
$home = $argv[2] ?? '';
if ($home !== '') putenv('APP_HOME=' . $home); else putenv('APP_HOME');
require $argv[1];
$before = time();
do_action('wppocket_db_maintenance');
$optimize = 0; foreach ($WDB->queries as $q) { if (stripos($q, 'OPTIMIZE TABLE') === 0) $optimize++; }
$f = [];
foreach (['auto_update_core', 'auto_update_plugin', 'auto_update_theme', 'auto_update_translation'] as $t) {
    $f[$t] = ['true_in' => apply_filters($t, true), 'false_in' => apply_filters($t, false)];
}
echo json_encode([
    'optimize' => $optimize, 'revisions_deleted' => count($WDB->deleted),
    'single' => array_map(function ($e) use ($before) { return ['delta' => $e[0] - $before, 'hook' => $e[1]]; }, $SINGLE),
    'deferred' => function_exists('wppocket_heavy_jobs_deferred') ? wppocket_heavy_jobs_deferred() : null,
    'filters' => $f,
]);
"""

def run(plugin_path, home, flag_age_s):
    """flag_age_s: None = khong co file co; so giay = tuoi cua co (mtime = now - tuoi)."""
    if home is not None:
        os.makedirs(os.path.join(home, "lamp-run"), exist_ok=True)
        flag = os.path.join(home, "lamp-run", "defer-heavy-jobs")
        if os.path.exists(flag): os.remove(flag)
        if flag_age_s is not None:
            open(flag, "w").write("1")
            t = time.time() - flag_age_s
            os.utime(flag, (t, t))
    out = subprocess.run(["php", HARNESS_PATH, plugin_path, home or ""], capture_output=True, text=True, timeout=60)
    if out.returncode != 0:
        raise SystemExit("PHP loi: " + out.stdout + out.stderr)
    return json.loads(out.stdout)

tmp = tempfile.mkdtemp(prefix="mu-test-")
HARNESS_PATH = os.path.join(tmp, "harness.php")
open(HARNESS_PATH, "w").write(HARNESS)
PLUGIN = os.path.join(tmp, "wppocket-maintenance.php")
open(PLUGIN, "w", encoding="utf-8").write(extract_plugin(SRC))
home = os.path.join(tmp, "app-home")

lint = subprocess.run(["php", "-l", PLUGIN], capture_output=True, text=True)
check("php -l mu-plugin trich ra tu site_source.sh", lint.returncode == 0, lint.stdout + lint.stderr)

HAS_B6 = "wppocket_heavy_jobs_deferred" in open(PLUGIN, encoding="utf-8").read()
ALL = ["auto_update_core", "auto_update_plugin", "auto_update_theme", "auto_update_translation"]

if not HAS_B6:
    # Ban cu (doi chung am): co moi nhung plugin khong biet toi no -> van chay OPTIMIZE
    r = run(PLUGIN, home, 60)
    check("DOI CHUNG AM (ban chua co B6): co 'moi' nhung van chay OPTIMIZE (khong hoan)", r["optimize"] == 3, str(r))
    print("\nTONG KET (doi chung am): pass=%d fail=%d" % (passed, failed))
    sys.exit(1 if failed else 0)

r = run(PLUGIN, home, 60)  # co moi (1 phut)
check("co moi: bao tri DB KHONG chay OPTIMIZE", r["optimize"] == 0, str(r))
check("co moi: KHONG xoa revision", r["revisions_deleted"] == 0, str(r))
check("co moi: hen thu lai bang 1 su kien don +1h", len(r["single"]) == 1 and r["single"][0]["hook"] == "wppocket_db_maintenance" and 3590 <= r["single"][0]["delta"] <= 3610, str(r["single"]))
check("co moi: 4 filter auto_update_* tra false ke ca dau vao true", all(r["filters"][t]["true_in"] is False for t in ALL), str(r["filters"]))
check("co moi: deferred()==true", r["deferred"] is True)

r = run(PLUGIN, home, None)  # co home, khong co file co
check("khong co file co: OPTIMIZE chay du 3 bang", r["optimize"] == 3, str(r))
check("khong co file co: khong hen su kien don", r["single"] == [], str(r["single"]))
check("khong co file co: filter DI QUA nguyen gia tri (true->true, false->false)", all(r["filters"][t]["true_in"] is True and r["filters"][t]["false_in"] is False for t in ALL), str(r["filters"]))
check("khong co file co: xoa revision cu chay", r["revisions_deleted"] == 2, str(r))

r = run(PLUGIN, home, 3 * 3600)  # co cu 3 gio
check("co CU 3 gio (app khong con cap nhat): coi nhu het hieu luc -> chay binh thuong (fail-open)", r["optimize"] == 3 and r["deferred"] is False and r["single"] == [], str(r))
r = run(PLUGIN, home, 119 * 60)
check("bien: co 119 phut -> VAN hoan", r["deferred"] is True and r["optimize"] == 0, str(r))
r = run(PLUGIN, home, 121 * 60)
check("bien: co 121 phut -> het hieu luc", r["deferred"] is False and r["optimize"] == 3, str(r))

r = run(PLUGIN, "", None)  # khong co APP_HOME
check("khong co APP_HOME (khong chay trong app): khong hoan gi", r["deferred"] is False and r["optimize"] == 3, str(r))

print("\nTONG KET: pass=%d fail=%d" % (passed, failed))
sys.exit(1 if failed else 0)
