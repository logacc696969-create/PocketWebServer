#!/usr/bin/env python3
"""Kiem thu GIOI HAN TOC DO + CHAN BOT cua nginx.conf.template bang nginx THAT + php-fpm THAT (HANDOFF.md muc 1bl; PDF 2 C10/R19/R20).
Trong tam: (1) MAC DINH TAT - khong anh huong ai; (2) khi bat, dung IP KHACH THAT (CF-Connecting-IP) nen khach khac nhau co bo dem rieng
(loi nghiem trong nhat neu sai: moi khach sau Cloudflare cung IP 127.0.0.1 => chan CA SITE); (3) /wp-admin/ va file tinh KHONG bi gioi han;
(4) chan bot dung danh sach, KHONG chan Googlebot/Bingbot/UA rong/trinh duyet thuong; (5) tat co => het hieu luc.
Can: nginx + php-fpm. Thieu thi bo qua (exit 0). Doi chung am: NGINX_TPL=<template cu khong co khoi bao ve> -> PHAI do."""
import http.client, os, re, shutil, socket, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.environ.get('NGINX_TPL') or os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates', 'nginx.conf.template'))
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:220]) if d else ''))
def which(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p
def wr(root, rel, txt):
    p = os.path.join(root, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(txt)

CHROME = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36'

def main():
    nginx = which('nginx'); fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    if not nginx or not fpm:
        print('(bo qua: thieu nginx hoac php-fpm)'); return 0
    tmp = tempfile.mkdtemp(prefix='protect-ngx-'); doc = os.path.join(tmp, 'www'); run = os.path.join(tmp, 'run')
    os.chmod(tmp, 0o755); os.makedirs(run); os.makedirs(os.path.join(tmp, 'stg'))
    wr(doc, 'index.php', '<?php echo "HOME;";\n'); wr(doc, 'wp-admin/index.php', '<?php echo "ADMIN;";\n')
    wr(doc, 'wp-login.php', '<?php echo "LOGIN;";\n'); wr(doc, 'style.css', 'body{color:red}\n')
    rate, bots = os.path.join(run, 'rate-limit-on'), os.path.join(run, 'block-bots-on')
    s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
    s = socket.socket(); s.bind(('127.0.0.1', 0)); sport = s.getsockname()[1]; s.close()
    sock = os.path.join(run, 'fpm.sock')
    conf = open(TPL, encoding='utf-8').read()
    for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)),
                 ('__FPM_SOCK__', sock), ('__CF_REALIP_DIRECTIVES__', '')):
        conf = conf.replace(k, v)
    conf = conf.replace('__STAGING_DOCROOT__', os.path.join(tmp, 'stg'))
    open(os.path.join(tmp, 'nginx.conf'), 'w').write(conf)
    open(os.path.join(run, 'ban-list.conf'), 'a').close()   # geo include (HANDOFF.md muc 1br) can file ton tai luc nginx khoi dong
    for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
        os.makedirs(m, exist_ok=True)
    open(os.path.join(tmp, 'fpm.conf'), 'w').write('[global]\npid=%s/fpm.pid\nerror_log=%s/fpm.log\ndaemonize=no\n[www]\nuser=root\ngroup=root\nlisten=%s\nlisten.mode=0666\npm=static\npm.max_children=4\n' % (tmp, tmp, sock))
    open(os.path.join(tmp, 'php.ini'), 'w').write('cgi.fix_pathinfo=0\n')

    def req(path, headers=None, ua=CHROME):
        h = dict(headers or {})
        c = http.client.HTTPConnection('127.0.0.1', port, timeout=20)
        c.putrequest('GET', path, skip_host=False, skip_accept_encoding=True)
        if ua is not None: c.putheader('User-Agent', ua)
        for k, v in h.items(): c.putheader(k, v)
        c.endheaders()
        r = c.getresponse(); r.read(); st = r.status; c.close()
        return st
    def burst(path, n, headers=None, ua=CHROME):
        return [req(path, headers, ua) for _ in range(n)]
    def wait_until(fn, timeout=8.0):
        t0 = time.time()
        while time.time() - t0 < timeout:
            if fn(): return True
            time.sleep(0.25)
        return False

    procs = []
    try:
        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(sock): break
            time.sleep(0.1)
        check('nginx + php-fpm that hoat dong voi template moi (nginx -t ngam: neu cu phap sai thi nginx khong len)', req('/') == 200)

        print('== A. MAC DINH TAT: khong anh huong ai ==')
        check('A1. 80 request lien tiep tu 1 IP deu 200 (khong gioi han)', set(burst('/', 80)) == {200}, sorted(set(burst('/', 1))))
        check('A2. UA cong cu quet (sqlmap) va bot SEO (AhrefsBot) van 200 khi chua bat', req('/', ua='sqlmap/1.7.2#stable') == 200 and req('/', ua='Mozilla/5.0 (compatible; AhrefsBot/7.0)') == 200)

        print('== B. BAT gioi han toc do ==')
        open(rate, 'w').close()
        res = burst('/', 90)
        n_ok, n_429 = res.count(200), res.count(429)
        check('B1. 90 request dong thoi tu 1 IP: dot dau (~30) qua, phan sau bi 429', n_ok >= 20 and n_429 >= 25 and set(res) <= {200, 429}, (n_ok, n_429, sorted(set(res))))
        check('B2. IP khach KHAC (CF-Connecting-IP) co bo dem RIENG: van 200 du IP 127.0.0.1 da het luot', req('/', {'CF-Connecting-IP': '203.0.113.7'}) == 200)
        res2 = burst('/', 80, {'CF-Connecting-IP': '203.0.113.7'})
        check('B3. khach do cung bi gioi han khi tu nhieu (dung IP that tu header, khong phai IP ket noi)', res2.count(429) >= 20, (res2.count(200), res2.count(429)))
        check('B4. khach thu 3 (198.51.100.9) khong bi anh huong boi 2 khach tren', req('/', {'CF-Connecting-IP': '198.51.100.9'}) == 200)
        check('B5. /wp-admin/ KHONG bi gioi han (60 request deu 200) du IP da het luot', set(burst('/wp-admin/index.php', 60)) == {200})
        check('B6. file tinh (style.css) KHONG bi gioi han (60 request deu 200)', set(burst('/style.css', 60)) == {200})
        wl = burst('/wp-login.php', 6)
        check('B7. wp-login.php giu bo gioi han RIENG va ma tra ve CU (503, KHONG bi doi thanh 429 boi khoi moi)', wl[-1] == 503 and 429 not in wl, wl)
        check('B8. sau ~4 giay nap lai luot: / lai 200', wait_until(lambda: req('/') == 200, 12))
        os.remove(rate)
        check('B9. TAT co: het gioi han (nginx doc co moi request, toi da ~2 giay)', wait_until(lambda: set(burst('/', 60)) == {200}, 10))

        print('== C. BAT chan bot ==')
        open(bots, 'w').close()
        check('C1. bat co: sqlmap bi 403', wait_until(lambda: req('/', ua='sqlmap/1.7.2#stable') == 403, 6))
        bad = ['Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)', 'Mozilla/5.0 (compatible; SemrushBot/7~bl; +http://www.semrush.com/bot.html)',
               'Mozilla/5.0 (compatible; MJ12bot/v1.4.8; http://mj12bot.com/)', 'Mozilla/5.0 (compatible; PetalBot;+https://webmaster.petalsearch.com/site/petalbot)',
               'Nmap Scripting Engine; https://nmap.org/book/nse.html', 'Nikto/2.1.6', 'WPScan v3.8.22 (https://wpscan.com/)', 'masscan/1.3 (https://github.com/robertdavidgraham/masscan)',
               'Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 (compatible; Bytespider; spider-feedback@bytedance.com)', 'zgrab/0.x', 'DirBuster-1.0-RC1']
        check('C2. %d UA xau (quet lo hong + bot ngon bang thong) deu 403' % len(bad), all(req('/', ua=u) == 403 for u in bad), [u[:30] for u in bad if req('/', ua=u) != 403])
        check('C3. chan theo UA ap dung ca file tinh (server-level): sqlmap xin style.css cung 403', req('/style.css', ua='sqlmap/1.7') == 403)
        good = [CHROME, 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)',
                'curl/8.5.0', 'UptimeRobot/2.0', 'Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0', 'python-requests/2.31.0']
        check('C4. trinh duyet thuong, Googlebot, Bingbot, curl, UptimeRobot, python-requests KHONG bi chan', all(req('/', ua=u) == 200 for u in good), [u[:30] for u in good if req('/', ua=u) != 200])
        check('C5. khong co User-Agent: khong bi chan', req('/', ua=None) == 200)
        os.remove(bots)
        check('C6. tat co chan bot: sqlmap lai 200', wait_until(lambda: req('/', ua='sqlmap/1.7') == 200, 10))

        print('== D. bat ca hai cung luc ==')
        open(rate, 'w').close(); open(bots, 'w').close()
        check('D1. bat ca hai: khach thuong van vao duoc (200), bot xau 403', wait_until(lambda: req('/', ua='sqlmap/1.7') == 403, 6) and wait_until(lambda: req('/', {'CF-Connecting-IP': '192.0.2.77'}) == 200, 6))
        os.remove(rate); os.remove(bots)
        check('D2. tat ca hai: moi thu tro lai binh thuong', wait_until(lambda: req('/', ua='sqlmap/1.7') == 200 and set(burst('/', 40)) == {200}, 12))
    finally:
        for p in procs:
            try: p.terminate(); p.wait(timeout=10)
            except Exception:
                try: p.kill()
                except Exception: pass
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
