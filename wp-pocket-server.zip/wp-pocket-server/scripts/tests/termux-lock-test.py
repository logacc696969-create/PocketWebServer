#!/usr/bin/env python3
"""Kiem thu bo phat hien lech phien ban goi Termux (scripts/lib/termux_lock.py + termux_record_pkg) - HANDOFF.md muc 1ay."""
import importlib.util, os, subprocess, sys, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.normpath(os.path.join(HERE, '..', 'lib'))
spec = importlib.util.spec_from_file_location('tl', os.path.join(LIB, 'termux_lock.py')); tl = importlib.util.module_from_spec(spec); spec.loader.exec_module(tl)
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:200]) if d else ''))

A = 'aarch64'
lock = {(A, 'php'): ('8.5.1', 'aaa'), (A, 'php-fpm'): ('8.5.1', 'bbb'), (A, 'mariadb'): ('11.8.5', 'ccc'),
        (A, 'libcurl'): ('8.16.0', 'ddd'), (A, 'nginx'): ('1:1.28.0-1', 'eee')}
def m(**kw):  # {goi: (ver, sha)} -> manifest
    base = {(A, k): v for k, v in lock.items() if False}
    base = dict(lock); base.update({(A, k): v for k, v in kw.items()}); return base

code, out = tl.check(dict(lock), lock)
check('giong het tep khoa -> ma 0, khong thong bao', code == 0 and out == [], out)
code, out = tl.check(m(php=('8.5.2', 'x'), **{'php-fpm': ('8.5.2', 'x')}), lock)
check('PHP doi PATCH (8.5.1 -> 8.5.2) -> chi canh bao, ma 0', code == 0 and any('CANH BAO' in l and 'php' in l for l in out), (code, out))
code, out = tl.check(m(php=('8.6.0', 'x')), lock)
check('PHP doi MINOR (8.5 -> 8.6) -> LOI, ma 1', code == 1 and any(l.startswith('LOI') and 'php' in l for l in out), (code, out))
code, out = tl.check(m(mariadb=('12.0.1', 'x')), lock)
check('MariaDB doi MAJOR (11 -> 12) -> LOI, ma 1', code == 1)
code, out = tl.check(m(nginx=('1:1.30.0-1', 'x')), lock)
check('nginx doi minor, co epoch "1:" -> van phan tich dung (1.28 -> 1.30) -> LOI', code == 1, out)
code, out = tl.check(m(nginx=('1:1.28.3-1', 'x')), lock)
check('nginx cung major.minor khac patch/revision (epoch 1:) -> khong loi', code == 0, out)
code, out = tl.check(m(libcurl=('8.17.0', 'x')), lock)
check('thu vien KHONG quan trong doi minor -> chi canh bao (khong lam hong build vi Termux cap nhat lib)', code == 0 and any('CANH BAO' in l and 'libcurl' in l for l in out), (code, out))
code, out = tl.check(m(php=('rac-khong-phan-tich-duoc', 'x')), lock)
check('phien ban goi quan trong khong phan tich duoc -> coi la LOI (khong im lang bo qua)', code == 1, out)
code, out = tl.check(m(php=('8.5.1', 'KHAC')), lock)
check('cung phien ban nhung SHA-256 khac -> canh bao (Termux dung lai ban), khong loi', code == 0 and any('SHA-256 khac' in l for l in out), out)
mm = m(); mm[(A, 'goi-moi')] = ('1.0', 'z')
code, out = tl.check(mm, lock)
check('goi MOI chua co trong tep khoa -> ghi chu, ma 0', code == 0 and any('MOI' in l for l in out))
mm = dict(lock); del mm[(A, 'libcurl')]
code, out = tl.check(mm, lock)
check('goi co trong tep khoa nhung khong con tai -> ghi chu', code == 0 and any('khong con duoc tai' in l for l in out))
code, out = tl.check(m(php=('8.6.0', 'x')), lock, allow=True)
check('ALLOW_TERMUX_DRIFT=1 -> cho phep loi lech (ma 0) nhung VAN ghi ro da bo qua', code == 0 and any('bo qua' in l for l in out) and any(l.startswith('LOI') for l in out), out)
code, out = tl.check(dict(lock), None)
check('chua co tep khoa -> ma 0 + huong dan tao (khong chan lan build dau tien)', code == 0 and any('chua co tep khoa' in l for l in out))
# arch tach rieng
mm = dict(lock); mm[('arm', 'php')] = ('8.6.0', 'x'); lk = dict(lock); lk[('arm', 'php')] = ('8.5.1', 'y')
code, _ = tl.check(mm, lk)
check('khoa theo (arch, goi): lech o arch "arm" van bi bat', code == 1)
check('major_minor: "8.5.1"->(8,5); "1:1.28.0-1"->(1,28); rac->None', tl.major_minor('8.5.1') == (8, 5) and tl.major_minor('1:1.28.0-1') == (1, 28) and tl.major_minor('abc') is None)

# CLI: update roi check qua tep that
tmp = tempfile.mkdtemp(prefix='tl-')
try:
    man = os.path.join(tmp, 'm.tsv'); lk = os.path.join(tmp, 'lock')
    open(man, 'w').write('php\t8.5.1\taaa\taarch64\nphp\t8.5.1\taaa2\taarch64\nmariadb\t11.8.5\tccc\taarch64\n')
    r = subprocess.run([sys.executable, os.path.join(LIB, 'termux_lock.py'), 'update', man, lk], capture_output=True, text=True)
    check('CLI update: ghi tep khoa (ban ghi trung: ban sau thang)', r.returncode == 0 and 'php' in open(lk).read() and 'aaa2' in open(lk).read() and 'aaa\t' not in open(lk).read().replace('aaa2', ''), r.stdout + r.stderr)
    r = subprocess.run([sys.executable, os.path.join(LIB, 'termux_lock.py'), 'check', man, lk], capture_output=True, text=True)
    check('CLI check ngay sau update -> OK (ma 0)', r.returncode == 0 and 'OK' in r.stdout, r.stdout)
    open(man, 'w').write('php\t8.6.0\taaa\taarch64\nmariadb\t11.8.5\tccc\taarch64\n')
    r = subprocess.run([sys.executable, os.path.join(LIB, 'termux_lock.py'), 'check', man, lk], capture_output=True, text=True)
    check('CLI check khi PHP len 8.6 -> ma 1', r.returncode == 1 and 'LOI' in r.stdout, r.stdout)
    r = subprocess.run([sys.executable, os.path.join(LIB, 'termux_lock.py'), 'check', man, lk], capture_output=True, text=True, env=dict(os.environ, ALLOW_TERMUX_DRIFT='1'))
    check('CLI check voi ALLOW_TERMUX_DRIFT=1 -> ma 0', r.returncode == 0, r.stdout)
    r = subprocess.run([sys.executable, os.path.join(LIB, 'termux_lock.py'), 'check', os.path.join(tmp, 'khong-co.tsv'), lk], capture_output=True, text=True)
    check('manifest khong ton tai -> ma 2 (buoc tai goi chua chay), khong im lang coi la OK', r.returncode == 2, r.stdout)

    # phia bash: termux_record_pkg voi chi muc Termux GIA
    idx = os.path.join(tmp, 'Packages')
    open(idx, 'w').write('Package: php\nVersion: 8.5.1\nSHA256: abc123\nFilename: pool/main/p/php/php_8.5.1_aarch64.deb\n\n'
                         'Package: mariadb\nVersion: 11.8.5-1\nSHA256: def456\nFilename: pool/main/m/mariadb/mariadb_11.8.5-1_aarch64.deb\n')
    bm = os.path.join(tmp, 'bm.tsv'); open(bm, 'w').close()
    r = subprocess.run(['bash', '-c', 'source "%s/termux_fetch.sh"; TERMUX_PACKAGES_INDEX="%s"; TERMUX_MANIFEST="%s"; TERMUX_ARCH=aarch64; termux_record_pkg php; termux_record_pkg mariadb' % (LIB, idx, bm)],
                       capture_output=True, text=True)
    rows = [l.split('\t') for l in open(bm).read().splitlines()]
    check('termux_record_pkg (bash) ghi dung "goi, phien ban, sha256, arch" tu chi muc',
          r.returncode == 0 and rows == [['php', '8.5.1', 'abc123', 'aarch64'], ['mariadb', '11.8.5-1', 'def456', 'aarch64']], (rows, r.stderr[-150:]))
    open(bm, 'w').close()
    r = subprocess.run(['bash', '-c', 'source "%s/termux_fetch.sh"; TERMUX_PACKAGES_INDEX="%s"; unset TERMUX_MANIFEST; termux_record_pkg php' % (LIB, idx)], capture_output=True, text=True)
    check('khong dat TERMUX_MANIFEST -> khong lam gi, khong loi (tuong thich ngach cu)', r.returncode == 0 and open(bm).read() == '')
    # vong tron: manifest do bash ghi -> python so sanh
    open(bm, 'w').write('php\t8.5.1\tabc123\taarch64\nmariadb\t11.8.5-1\tdef456\taarch64\n')
    r = subprocess.run([sys.executable, os.path.join(LIB, 'termux_lock.py'), 'update', bm, lk], capture_output=True, text=True)
    r2 = subprocess.run([sys.executable, os.path.join(LIB, 'termux_lock.py'), 'check', bm, lk], capture_output=True, text=True)
    check('vong tron dinh dang: manifest bash -> update -> check cho OK', r.returncode == 0 and r2.returncode == 0, r2.stdout)
finally:
    shutil.rmtree(tmp, ignore_errors=True)
print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); sys.exit(0 if FAIL == 0 else 1)
