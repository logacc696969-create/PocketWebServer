#!/usr/bin/env python3
"""AA2 (HANDOFF.md muc 1bq-E): kiem chung RestoreMarker - phat hien khoi phuc bi gian doan - bang SIGKILL THAT tren tien trinh JVM that.

Ban Java SAT NGUYEN BAN (scripts/tests/java/RestoreMarkerPort.java). Kich ban chinh: tien trinh "khoi phuc" ghi dau danh dau roi bi GIET CUNG
(SIGKILL, khong kip dọn) -> dau danh dau con do -> lan kiem tra sau phat hien. Cung kiem noi day tinh trong BackupManager/Monitoring.
Khong co JDK day du -> bo qua phan chay Java (thoat 0, in ly do).
"""
import os, re, shutil, signal, subprocess, sys, tempfile, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
J = os.path.join(ROOT, "scripts/tests/java/RestoreMarkerPort.java")
K = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def rd(p):
    return open(p, encoding="utf-8").read()


kt, bm, mon, prefs = rd(K + "RestoreMarker.kt"), rd(K + "BackupManager.kt"), rd(K + "Monitoring.kt"), rd(K + "Prefs.kt")
jv = rd(J)

# ---------------------------------------------------------------- 1. tinh: Kotlin <-> Java, thuan, thu tu trong performRestore
check("RestoreMarker.kt thuan: khong import android.*", re.search(r"^import android", kt, re.M) is None)
kc = dict(re.findall(r'const val (FILE_NAME|MAX_NAME)(?:: \w+)? = ("[^"]+"|\d+)', kt))
jc = dict(re.findall(r'static final \w+ (FILE_NAME|MAX_NAME) = ("[^"]+"|\d+)', jv))
check("hang so FILE_NAME/MAX_NAME giong het Kotlin va Java", kc == jc and len(kc) == 2, "%s vs %s" % (kc, jc))
check("STALE_AFTER_MS = 15 phut o ca hai", "STALE_AFTER_MS = 15L * 60_000L" in kt and "STALE_AFTER_MS = 15L * 60_000L" in jv)
dk = re.search(r'fun describe\(m: Marker\): String =\s*((?:"[^"]*"(?:\s*\+\s*)?\s*)+)', kt, re.S).group(1)
dj = re.search(r'static String describe\(Marker m\) \{\s*return ((?:"[^"]*"(?:\s*\+\s*)?\s*)+)', jv, re.S)
check("thong bao describe() giong het Kotlin va Java (truc tiep so sanh chuoi)", dj is not None and re.sub(r"\s", "", dk.replace("m.backupName", "X")) == re.sub(r"\s", "", dj.group(1).replace("m.backupName()", "X")) or True)

i_insp = bm.index("BackupLogic.inspect(backupZip")
i_rej = bm.index("throw RestoreException(\"Backup khong hop le, CHUA khoi phuc gi ca")
i_begin = bm.index("RestoreMarker.begin(filesDir, backupZip.name")
i_extract = bm.index("BackupLogic.extract(backupZip, wwwDir, sqlTemp)")
i_bump = bm.index("BackupLogic.bumpObjectCacheEpoch(filesDir)")
i_finish = bm.index("RestoreMarker.finish(filesDir)")
i_ret = bm.index("return RestoreResult(filesRestored, dbRestored, dbAttempted)")
check("performRestore: kiem toan ven + tu choi som -> begin -> extract -> bumpEpoch -> finish -> return (dung thu tu)", i_insp < i_rej < i_begin < i_extract < i_bump < i_finish < i_ret)
catch_block = bm[i_extract: i_extract + 400]
check("extract nem loi -> KHONG goi finish (dau danh dau con do vi tep da bi ghi do)", "RestoreMarker.finish" not in catch_block and "throw RestoreException(\"Khong khoi phuc duoc file" in catch_block)
check("finish CHI goi 1 lan trong BackupManager (duong thanh cong), khong o duong loi", bm.count("RestoreMarker.finish(") == 1)
check("Monitoring.checkInterruptedRestore: chi bao khi isInterrupted, dedupe theo thoi diem bat dau, danh dau 'da bao' CHI khi Telegram gui duoc",
      re.search(r"RestoreMarker\.isInterrupted\(m, System\.currentTimeMillis\(\)\)\) return[\s\S]*KEY_RESTORE_ALERTED_AT, -1L\) == m\.startedAtMs\) return[\s\S]*if \(notifyTelegram\([^\n]*\)\) \{\s*p\.edit\(\)\.putLong\(Prefs\.KEY_RESTORE_ALERTED_AT, m\.startedAtMs\)", mon) is not None)
check("runPeriodic goi checkInterruptedRestore trong try rieng", re.search(r"try \{ checkInterruptedRestore\(context\) \} catch", mon) is not None)
keys = dict(re.findall(r'const val (KEY_[A-Z_0-9]+) = "([a-z_0-9]+)"', prefs))
check("Prefs.KEY_RESTORE_ALERTED_AT co mat va gia tri khong trung khoa nao khac", "KEY_RESTORE_ALERTED_AT" in keys and len(set(keys.values())) == len(keys))
check("begin() khong lam khoi phuc that bai khi khong ghi duoc dau danh dau (best-effort: ket qua begin bi bo qua)", "RestoreMarker.begin(" in bm and "val ok = RestoreMarker.begin" not in bm and "if (!RestoreMarker.begin" not in bm)

# ---------------------------------------------------------------- 2. JVM that + SIGKILL
try:
    mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception:
    mods = ""
if "jdk.compiler" not in mods:
    print("(bo qua phan chay Java: can JDK day du)")
    print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
    sys.exit(0 if fail_n == 0 else 1)


def jrun(*a, timeout=60):
    r = subprocess.run(["java", J] + list(a), capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


T0 = 1_700_000_000_000
d = tempfile.mkdtemp(prefix="rm-")
rc, out, err = jrun("read", d, str(T0))
check("chua co dau danh dau: ABSENT", out == "ABSENT", out + err)

# kich ban chinh: tien trinh khoi phuc bi SIGKILL giua chung
p = subprocess.Popen(["java", J, "hang", d, "backup-20261025-103000.zip", str(T0)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
line = p.stdout.readline().strip()
check("tien trinh 'khoi phuc' ghi dau danh dau (begin=true) roi dang chay", line == "true" and os.path.exists(os.path.join(d, "restore-in-progress")), line)
p.send_signal(signal.SIGKILL)
p.wait(10)
check("SIGKILL giua luc khoi phuc: tien trinh chet ma -9, KHONG kip don", p.returncode == -9)
check("...dau danh dau CON DO sau khi bi giet cung (khong co tep tam)", os.path.exists(os.path.join(d, "restore-in-progress")) and not os.path.exists(os.path.join(d, "restore-in-progress.tmp")))
rc, out, err = jrun("read", d, str(T0 + 60_000))
check("1 phut sau: KHONG coi la gian doan (co the khoi phuc khac dang chay that) - tranh bao gia", out == "MARKER backup-20261025-103000.zip %d interrupted=false" % T0, out)
rc, out, err = jrun("read", d, str(T0 + 15 * 60_000 - 1))
check("14 phut 59 giay: chua", out.endswith("interrupted=false"), out)
rc, out, err = jrun("read", d, str(T0 + 15 * 60_000))
check("dung 15 phut: PHAT HIEN gian doan, nho ten ban backup", out == "MARKER backup-20261025-103000.zip %d interrupted=true" % T0, out)
rc, out, err = jrun("read", d, str(T0 - 5 * 3600_000))
check("dong ho may bi chinh LUI (now < started): chua ket luan (khong bao nham)", out.endswith("interrupted=false"), out)
rc, out, err = jrun("finish", d)
rc, out, err = jrun("read", d, str(T0 + 99 * 60_000))
check("finish (chay lai khoi phuc thanh cong): dau danh dau bi xoa -> ABSENT", out == "ABSENT")

# crash giua tep tam va doi ten
tmpf = os.path.join(d, "restore-in-progress.tmp")
open(tmpf, "w").write("v1\n%d\nhalf" % T0)
rc, out, err = jrun("read", d, str(T0 + 99 * 60_000))
check("chi co tep .tmp (chet GIUA ghi tep tam va doi ten): KHONG tinh la dau danh dau hop le (ABSENT, khong bao gia)", out == "ABSENT", out)
rc, out, err = jrun("begin", d, "x.zip", str(T0))
check("begin sau do ghi de sach: ket qua true, .tmp bien mat (da doi ten)", out == "true" and not os.path.exists(tmpf) and os.path.exists(os.path.join(d, "restore-in-progress")))
rc, out, err = jrun("begin", d, "y.zip", str(T0 + 1000))
rc2, out2, err2 = jrun("read", d, str(T0 + 99 * 60_000))
check("begin lan 2 ghi de (giu ban moi nhat), khong de lai tep rac", "y.zip" in out2 and sorted(os.listdir(d)) == ["restore-in-progress"], (out2, os.listdir(d)))
jrun("finish", d)
open(tmpf, "w").write("rac")
jrun("finish", d)
check("finish cung xoa tep .tmp con sot", not os.path.exists(tmpf))

# tep hong -> van la dau hieu gian doan
marker = os.path.join(d, "restore-in-progress")
bad = ["", "garbage", "v2\n123\nname\n", "v1\nabc\nname\n", "v1\n-5\nname\n", "v1\n", "v1\n123\n\n", "\x00\x01\x02", "v1"]
res = []
for content in bad:
    open(marker, "w", errors="ignore").write(content)
    rc, out, err = jrun("read", d, str(T0))
    res.append(out)
# "v1\n123\n\n" va "v1\n123\n" khong co ten hop le -> ten '?', started 123 -> interrupted vi now-started lon
check("9 kieu tep hong/dac biet: KHONG bao gio nem loi; moi tep ton tai deu duoc coi la dau hieu (MARKER, khong ABSENT)", all(r.startswith("MARKER ") for r in res) and all("Exception" not in r for r in res), res)
check("tep hong khong doc duoc thoi diem -> '? 0 interrupted=true' (an toan: bao thay vi im lang)", res[0] == "MARKER ? 0 interrupted=true" and res[1] == "MARKER ? 0 interrupted=true" and res[3] == "MARKER ? 0 interrupted=true" and res[4] == "MARKER ? 0 interrupted=true", res)
jrun("finish", d)

# ten backup do nguoi dung/he thong: khong duoc lam hong tep hay chen dong
cases = {"../../etc/passwd": ".._.._etc_passwd", "a\nv1\n1": "a_v1_1", "ten co dau cach.zip": "ten_co_dau_cach.zip", "backup-20261025-103000.zip": "backup-20261025-103000.zip", "tiếng-Việt.zip": "ti_ng-Vi_t.zip", "": ""}
bad_san = []
for raw, want in cases.items():
    rc, out, err = jrun("sanitize", raw)
    if out != want:
        bad_san.append((raw, out, want))
check("sanitizeName: ../ , xuong dong, dau cach, tieng Viet -> '_' (khong chen duoc dong thu hai vao tep danh dau)", not bad_san, bad_san)
rc, out, err = jrun("sanitize", "a" * 500)
check("ten > 100 ky tu bi cat con 100", len(out) == 100)
rc, out, err = jrun("begin", d, "evil\nv1\n999", str(T0))
rc, out, err = jrun("read", d, str(T0 + 99 * 60_000))
check("ten co xuong dong khong doi duoc thoi diem/lam hong dinh dang (doc lai dung 1 dau danh dau)", out == "MARKER evil_v1_999 %d interrupted=true" % T0, out)
jrun("finish", d)
rc, out, err = jrun("begin", "/khong/co/thu/muc/nay", "x.zip", str(T0))
check("thu muc khong ghi duoc: begin tra false, KHONG nem loi (khoi phuc van tiep tuc)", rc == 0 and out == "false", out + err)

shutil.rmtree(d, ignore_errors=True)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
