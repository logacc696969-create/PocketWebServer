#!/usr/bin/env python3
"""Kiem thu /healthz (HANDOFF.md muc 1bg) bang nginx THAT + php-fpm THAT, dung DUNG php-fpm.conf.template va nginx.conf.template cua du an
(chi doi: duong dan placeholder, va listen.mode 0660 -> 0666 de worker nginx cua runner ket noi duoc vao socket cua root).
Y nghia: ping.path cua php-fpm tra "pong" KHONG chay script, KHONG cham CSDL -> giam sat ngoai goi dinh ky khong lam WordPress/MariaDB hoat dong,
nhung PHAI phat hien dung "php-fpm chet" (502) va "dang bao tri" (503).
Doi chung am: NGINX_TPL=<template cu khong co /healthz> python3 healthz-test.py -> PHAI do.
Can: nginx + php-fpm. Thieu thi bo qua (exit 0)."""
import http.client, os, re, shutil, socket, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TPLDIR = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
NGX = os.environ.get('NGINX_TPL') or os.path.join(TPLDIR, 'nginx.conf.template')
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:200]) if d else ''))
def which(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p
def main():
    nginx = which('nginx'); fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    if not nginx or not fpm: print('(bo qua: thieu nginx hoac php-fpm)'); return 0
    tmp = tempfile.mkdtemp(prefix='healthz-'); os.chmod(tmp, 0o755)
    doc, run, files, stg = (os.path.join(tmp, d) for d in ('www', 'run', 'files', 'stg'))
    for d in (doc, run, files, stg): os.makedirs(d)
    s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
    s = socket.socket(); s.bind(('127.0.0.1', 0)); sport = s.getsockname()[1]; s.close()
    sock = os.path.join(run, 'fpm.sock')
    conf = open(NGX, encoding='utf-8').read()
    for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)),
                 ('__FPM_SOCK__', sock), ('__CF_REALIP_DIRECTIVES__', ''), ('__STAGING_DOCROOT__', stg)):
        conf = conf.replace(k, v)
    open(os.path.join(tmp, 'nginx.conf'), 'w').write(conf)
    open(os.path.join(run, 'ban-list.conf'), 'a').close()   # geo include (HANDOFF.md muc 1br) can file ton tai luc nginx khoi dong
    for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)): os.makedirs(m, exist_ok=True)
    fc = open(os.path.join(TPLDIR, 'php-fpm.conf.template'), encoding='utf-8').read()
    for k, v in (('__RUNDIR__', run), ('__FPM_SOCK__', sock), ('__FILESDIR__', files), ('__EXT_DIR__', tmp), ('__STAGING_PORT__', str(sport)),
                 ('__MYSQL_SOCK__', os.path.join(run, 'mysql.sock')), ('__DB_NAME__', 'x'), ('__DB_USER__', 'x'), ('__DB_PASS__', 'x')):
        fc = fc.replace(k, v)
    fc = fc.replace('listen.mode = 0660', 'listen.mode = 0666')
    open(os.path.join(tmp, 'fpm.conf'), 'w').write(fc)
    open(os.path.join(tmp, 'php.ini'), 'w').write('cgi.fix_pathinfo=0\n')
    def req(method, path):
        c = http.client.HTTPConnection('127.0.0.1', port, timeout=20)
        c.request(method, path); r = c.getresponse(); b = r.read().decode('utf-8', 'replace'); h = {k.lower(): v for k, v in r.getheaders()}; c.close()
        return r.status, h, b
    procs = []
    try:
        pf = subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        procs.append(pf)
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(sock): break
            time.sleep(0.1)
        print('== A. php-fpm song ==')
        r = req('GET', '/healthz')
        check('GET /healthz -> 200 "pong"', r[0] == 200 and r[2].strip() == 'pong', (r[0], r[2][:60]))
        check('Content-Type text/plain', r[1].get('content-type', '').startswith('text/plain'), r[1].get('content-type'))
        check('Cache-Control: no-cache (giam sat khong nhan ban cu)', 'no-cache' in r[1].get('cache-control', ''), r[1].get('cache-control'))
        check('van co header bao mat cua server{} (khong dung add_header rieng nen duoc ke thua)', r[1].get('x-frame-options') == 'SAMEORIGIN', r[1].get('x-frame-options'))
        check('KHONG di qua page cache (khong co X-WPP-Cache)', 'x-wpp-cache' not in r[1], r[1].get('x-wpp-cache'))
        h = req('HEAD', '/healthz'); check('HEAD /healthz -> 200', h[0] == 200, h[0])
        q = req('GET', '/healthz?x=1&y=2'); check('query string bi bo qua -> van "pong"', q[0] == 200 and q[2].strip() == 'pong', (q[0], q[2][:40]))
        open(os.path.join(run, 'mariadb-asleep'), 'w').write('1')
        a = req('GET', '/healthz')
        check('MariaDB dang ngu (Auto-Sleep): /healthz van "pong", KHONG bi rewrite sang trang danh thuc', a[0] == 200 and a[2].strip() == 'pong', (a[0], a[2][:60]))
        check('/healthz KHONG chay script PHP nao (docroot khong co file .php van tra pong)', not any(f.endswith('.php') for f in os.listdir(doc)))
        print('== B. php-fpm chet -> phai bao loi (day la gia tri cua endpoint) ==')
        pf.terminate()
        try: pf.wait(timeout=10)
        except Exception: pf.kill()
        time.sleep(0.5)
        d = req('GET', '/healthz')
        check('php-fpm chet -> 502/504 (giam sat phat hien duoc)', d[0] in (502, 504), (d[0], d[2][:60]))
        print('== C. Dang bao tri -> 503 ==')
        open(os.path.join(run, 'maintenance-mode'), 'w').write('1')
        m = req('GET', '/healthz')
        check('bao tri bat -> /healthz tra 503 (nhu moi trang khac)', m[0] == 503, m[0])
    finally:
        for pr in procs: pr.terminate()
        for pr in procs:
            try: pr.wait(timeout=5)
            except Exception: pr.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
