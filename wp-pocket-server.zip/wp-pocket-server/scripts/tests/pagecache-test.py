#!/usr/bin/env python3
"""Kiem thu PAGE CACHE (fastcgi_cache) cua nginx.conf.template bang nginx THAT + php-fpm THAT (HANDOFF.md muc 1bf).

VIET TRUOC khi viet cau hinh cache (theo yeu cau: "test doi chung viet truoc"). Trong tam KHONG phai "cache co chay khong" ma la
"cache co BAO GIO phuc vu nham noi dung khong": trang cua nguoi dang nhap, bien the khac nhau theo scheme/host/thiet bi, phan hoi co
Set-Cookie, v.v. Moi tinh huong nguy hiem deu co phep thu rieng, va co phep thu "KHONG LUU" (loi nghiem trong nhat: noi dung rieng tu bi
luu vao cache roi phuc vu cho nguoi la, du chinh request luc do da tranh duoc cache).

Doi chung am: NGINX_TPL=<duong dan template cu khong co cache> python3 pagecache-test.py  -> PHAI do.
Can: nginx + php-fpm. Thieu thi bo qua (exit 0).
"""
import http.client, os, re, shutil, socket, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.environ.get('NGINX_TPL') or os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates', 'nginx.conf.template'))
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:200]) if d else ''))
def which(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p
def wr(root, rel, txt):
    p = os.path.join(root, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(txt)

INDEX = r'''<?php
// Gia lap WordPress: moi lan PHP THUC SU chay thi tang counter.txt (bang chung "khong chay PHP" khi HIT).
$cf = __DIR__ . '/counter.txt';
$n = (int)@file_get_contents($cf) + 1; file_put_contents($cf, (string)$n);
$u = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($u === '/setcookie') { setcookie('visit', 'x', time() + 60, '/'); }
if ($u === '/private')   { header('Cache-Control: private, max-age=0'); }
$who = isset($_COOKIE['wordpress_logged_in_abc']) ? $_COOKIE['wordpress_logged_in_abc'] : 'anon';
$mob = (isset($_SERVER['HTTP_USER_AGENT']) && stripos($_SERVER['HTTP_USER_AGENT'], 'mobile') !== false) ? 1 : 0;
echo 'RUN=' . $n . ';USER=' . $who . ';M=' . $_SERVER['REQUEST_METHOD'] . ';U=' . $u . ';HTTPS=' . (isset($_SERVER['HTTPS']) ? $_SERVER['HTTPS'] : '')
   . ';HOST=' . $_SERVER['HTTP_HOST'] . ';MOB=' . $mob . ';';
'''
DIRECT = r'''<?php
$cf = __DIR__ . '/counter.txt';
$n = (int)@file_get_contents($cf) + 1; file_put_contents($cf, (string)$n);
echo 'RUN=' . $n . ';DIRECT;';
'''

def main():
    nginx = which('nginx'); fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    if not nginx or not fpm:
        print('(bo qua: thieu nginx hoac php-fpm)'); return 0
    tmp = tempfile.mkdtemp(prefix='pagecache-'); doc = os.path.join(tmp, 'www'); run = os.path.join(tmp, 'run')
    os.chmod(tmp, 0o755); os.makedirs(run); os.makedirs(os.path.join(tmp, 'stg'))
    wr(doc, 'index.php', INDEX); wr(doc, 'direct.php', DIRECT)
    wr(doc, 'wp-login.php', '<?php echo "LOGIN;" . mt_rand();\n')
    wr(doc, 'style.css', 'body{color:red}\n')
    counter = os.path.join(doc, 'counter.txt'); wr(doc, 'counter.txt', '0')
    flag = os.path.join(run, 'page-cache-on'); cache_dir = os.path.join(run, 'page-cache')
    s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
    s = socket.socket(); s.bind(('127.0.0.1', 0)); sport = s.getsockname()[1]; s.close()
    sock = os.path.join(run, 'fpm.sock')
    conf = open(TPL, encoding='utf-8').read()
    for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)),
                 ('__FPM_SOCK__', sock), ('__CF_REALIP_DIRECTIVES__', '')):
        conf = conf.replace(k, v)
    conf = conf.replace('__STAGING_DOCROOT__', os.path.join(tmp, 'stg'))
    open(os.path.join(tmp, 'nginx.conf'), 'w').write(conf)
    open(os.path.join(run, 'ban-list.conf'), 'a').close()   # geo include (HANDOFF.md muc 1br) can file ton tai luc nginx khoi dong
    for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
        os.makedirs(m, exist_ok=True)
    open(os.path.join(tmp, 'fpm.conf'), 'w').write('[global]\npid=%s/fpm.pid\nerror_log=%s/fpm.log\ndaemonize=no\n[www]\nuser=root\ngroup=root\nlisten=%s\nlisten.mode=0666\npm=static\npm.max_children=2\n' % (tmp, tmp, sock))
    open(os.path.join(tmp, 'php.ini'), 'w').write('cgi.fix_pathinfo=0\n')

    def req(method, path, headers=None, body=None):
        h = dict(headers or {})
        c = http.client.HTTPConnection('127.0.0.1', port, timeout=20)
        c.putrequest(method, path, skip_host=('Host' in h))
        for k, v in h.items(): c.putheader(k, v)
        if body is not None: c.putheader('Content-Length', str(len(body))); c.putheader('Content-Type', 'application/x-www-form-urlencoded')
        c.endheaders(body.encode() if body is not None else None)
        r = c.getresponse(); b = r.read().decode('utf-8', 'replace'); hd = {k.lower(): v for k, v in r.getheaders()}; c.close()
        return r.status, hd, b
    def cs(r): return r[1].get('x-wpp-cache')
    def run_n(r):
        m = re.search(r'RUN=(\d+);', r[2]); return int(m.group(1)) if m else None
    def php_count(): return int(open(counter).read().strip() or '0')

    procs = []
    try:
        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(sock): break
            time.sleep(0.1)
        r = req('GET', '/'); check('nginx+php-fpm that hoat dong', r[0] == 200 and 'RUN=' in r[2], (r[0], r[2][:80]))

        print('== A. MAC DINH TAT (khong co file page-cache-on): hanh vi nhu cu, moi request chay PHP ==')
        a1, a2 = req('GET', '/'), req('GET', '/')
        check('TAT: hai lan GET / deu chay PHP (RUN khac nhau)', run_n(a1) is not None and run_n(a1) != run_n(a2), (run_n(a1), run_n(a2)))
        check('TAT: header X-WPP-Cache = BYPASS (cache khong duoc dung)', cs(a1) == 'BYPASS' and cs(a2) == 'BYPASS', (cs(a1), cs(a2)))

        print('== B. BAT (tao file page-cache-on, khong can reload nginx) ==')
        open(flag, 'w').write('1')
        b1 = req('GET', '/'); n_after_b1 = php_count()
        b2 = req('GET', '/'); n_after_b2 = php_count()
        check('BAT: lan 1 MISS (chay PHP, luu cache)', cs(b1) == 'MISS', cs(b1))
        check('BAT: lan 2 HIT, cung noi dung', cs(b2) == 'HIT' and b2[2] == b1[2], (cs(b2), b2[2][:60], b1[2][:60]))
        check('BAT: lan HIT KHONG chay PHP (counter that khong tang)', n_after_b2 == n_after_b1, (n_after_b1, n_after_b2))
        check('BAT: HIT van co header bao mat cua server{} (X-Frame-Options)', b2[1].get('x-frame-options') == 'SAMEORIGIN', b2[1].get('x-frame-options'))
        c1, c2 = req('GET', '/page-a'), req('GET', '/page-a')
        check('BAT: URL khac -> muc cache rieng (MISS roi HIT)', cs(c1) == 'MISS' and cs(c2) == 'HIT' and 'U=/page-a;' in c2[2], (cs(c1), cs(c2)))
        css = req('GET', '/style.css')
        check('File tinh KHONG di qua cache trang (khong co X-WPP-Cache)', css[0] == 200 and cs(css) is None, (css[0], cs(css)))

        print('== C. DOI CHUNG: nhung tinh huong KHONG DUOC cache / KHONG DUOC phuc vu nham ==')
        # C1. nguoi dang nhap khi khoa '/' DA CO trong cache
        li = req('GET', '/', {'Cookie': 'wordpress_logged_in_abc=alice'})
        check('DANG NHAP (khoa da nong): BYPASS va thay noi dung cua CHINH MINH (USER=alice)', cs(li) == 'BYPASS' and 'USER=alice;' in li[2], (cs(li), li[2][:80]))
        an = req('GET', '/')
        check('Sau do nguoi la (anon) van HIT va KHONG thay "alice"', cs(an) == 'HIT' and 'alice' not in an[2] and 'USER=anon;' in an[2], (cs(an), an[2][:80]))
        # C2. nguoi dang nhap vao khoa CHUA co: noi dung rieng tu KHONG DUOC luu
        li2 = req('GET', '/cold', {'Cookie': 'wordpress_logged_in_abc=alice'})
        an2 = req('GET', '/cold')
        check('DANG NHAP (khoa lanh): BYPASS', cs(li2) == 'BYPASS' and 'USER=alice;' in li2[2], (cs(li2), li2[2][:80]))
        check('KHONG LUU: anon vao ngay sau do la MISS (chay PHP that) va USER=anon, KHONG phai trang cua alice', cs(an2) == 'MISS' and 'USER=anon;' in an2[2] and 'alice' not in an2[2], (cs(an2), an2[2][:80]))
        # C3. cac cookie nhay cam khac -> bypass
        for ck in ('PHPSESSID=abc123', 'woocommerce_items_in_cart=1', 'wp-postpass_x=1', 'comment_author_x=Bob', 'wordpress_sec_x=1', 'lang=vi'):
            rr = req('GET', '/', {'Cookie': ck})
            check('cookie %s -> BYPASS' % ck.split('=')[0], cs(rr) == 'BYPASS', cs(rr))
        ga = req('GET', '/', {'Cookie': '_ga=GA1.2.3.4'})
        check('cookie phan tich (_ga) KHONG pha cache (van HIT trang cong khai)', cs(ga) == 'HIT', cs(ga))
        # C4. query string, phuong thuc, Authorization
        q1, q2 = req('GET', '/?x=1'), req('GET', '/?x=1')
        check('co query string -> BYPASS va chay PHP moi lan', cs(q1) == 'BYPASS' and cs(q2) == 'BYPASS' and run_n(q1) != run_n(q2), (cs(q1), cs(q2)))
        po = req('POST', '/', None, 'a=1'); po2 = req('POST', '/', None, 'a=1')
        check('POST -> BYPASS va chay PHP moi lan', cs(po) == 'BYPASS' and run_n(po) != run_n(po2) and 'M=POST;' in po[2], (cs(po), cs(po2)))
        au = req('GET', '/', {'Authorization': 'Basic Zm9vOmJhcg=='})
        check('co header Authorization -> BYPASS', cs(au) == 'BYPASS', cs(au))
        # C5. duong dan quan tri / dong
        for pth in ('/wp-admin/', '/wp-admin/post.php', '/wp-json/wp/v2/posts', '/wp-cron.php', '/wp-comments-post.php'):
            w1, w2 = req('GET', pth), req('GET', pth)
            check('%s khong bao gio HIT' % pth, cs(w1) != 'HIT' and cs(w2) != 'HIT', (cs(w1), cs(w2)))
        d1, d2 = req('GET', '/direct.php'), req('GET', '/direct.php')
        check('URL tro thang file .php (/direct.php) -> chay PHP moi lan, khong HIT', run_n(d1) != run_n(d2) and cs(d2) != 'HIT', (cs(d1), cs(d2)))
        l1, l2 = req('GET', '/wp-login.php'), req('GET', '/wp-login.php')
        check('/wp-login.php khong bao gio qua cache (khong co X-WPP-Cache, noi dung khac nhau)', cs(l1) is None and cs(l2) is None and l1[2] != l2[2], (cs(l1), l1[2], l2[2]))
        # C6. phan hoi phia backend tu cam cache
        s1, s2 = req('GET', '/setcookie'), req('GET', '/setcookie')
        check('phan hoi co Set-Cookie KHONG duoc cache (chay PHP lan 2, khong HIT)', run_n(s1) != run_n(s2) and cs(s2) != 'HIT', (cs(s1), cs(s2)))
        p1, p2 = req('GET', '/private'), req('GET', '/private')
        check('phan hoi Cache-Control: private KHONG duoc cache', run_n(p1) != run_n(p2) and cs(p2) != 'HIT', (cs(p1), cs(p2)))
        # C7. bien the: scheme, host, thiet bi - khong phuc vu cheo
        h_http = req('GET', '/')
        h_https1 = req('GET', '/', {'X-Forwarded-Proto': 'https'}); h_https2 = req('GET', '/', {'X-Forwarded-Proto': 'https'})
        check('bien the HTTPS: lan dau MISS (KHONG nhan ban HTTP), noi dung HTTPS=on', cs(h_https1) == 'MISS' and 'HTTPS=on;' in h_https1[2], (cs(h_https1), h_https1[2][:90]))
        check('bien the HTTPS: lan sau HIT dung ban HTTPS; ban HTTP van la ban HTTP', cs(h_https2) == 'HIT' and 'HTTPS=on;' in h_https2[2] and 'HTTPS=;' in h_http[2], (cs(h_https2), h_http[2][:90]))
        ho = req('GET', '/', {'Host': 'khac.example'})
        check('bien the HOST: host khac MISS va noi dung theo host do, khong nhan ban cua host cu', cs(ho) == 'MISS' and 'HOST=khac.example;' in ho[2], (cs(ho), ho[2][:100]))
        mo = req('GET', '/', {'User-Agent': 'Mozilla/5.0 (Linux; Android 14) Mobile Safari'})
        de = req('GET', '/', {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64)'})
        check('bien the THIET BI: mobile MISS va MOB=1 (khong nhan ban desktop da cache)', cs(mo) == 'MISS' and 'MOB=1;' in mo[2], (cs(mo), mo[2][:100]))
        check('bien the THIET BI: desktop van HIT dung ban MOB=0', cs(de) == 'HIT' and 'MOB=0;' in de[2], (cs(de), de[2][:100]))

        print('== D. Tat/xoa khi dang chay ==')
        # nginx dung open_file_cache (open_file_cache_valid 2s trong template): file co/da xoa co the con duoc nho toi ~2 giay (bat thi
        # tuc thi vi open_file_cache_errors off; TAT/XOA thi cho qua 2 giay). Day la hanh vi da ghi o phan bandwidth-limited cua template.
        os.remove(flag); time.sleep(2.6)
        t1 = req('GET', '/'); t2 = req('GET', '/')
        check('TAT lai: sau toi da ~2 giay khong con phuc vu ban cu (BYPASS, chay PHP moi lan)', cs(t1) == 'BYPASS' and cs(t2) == 'BYPASS' and run_n(t1) != run_n(t2), (cs(t1), cs(t2)))
        open(flag, 'w').write('1')
        for root, _d, files in os.walk(cache_dir):
            for f in files: os.remove(os.path.join(root, f))
        time.sleep(2.6)
        pg1, pg2 = req('GET', '/'), req('GET', '/')
        check('XOA CACHE (xoa file trong thu muc cache): request sau MISS roi HIT lai', cs(pg1) == 'MISS' and cs(pg2) == 'HIT', (cs(pg1), cs(pg2)))
    finally:
        for pr in procs: pr.terminate()
        for pr in procs:
            try: pr.wait(timeout=5)
            except Exception: pr.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
