#!/usr/bin/env python3
"""Ban PORT 1-1 cua DataLifecycle.kt + doi chieu van ban voi ma that (PDF 2 AB1/AB3; HANDOFF.md muc 1bo).
Cung cac khang dinh voi scripts/tests/DataLifecycleTest.kt (chay Kotlin that o CI). Khong can kotlinc/php/mang."""
import os, re, shutil, sys, tempfile
from decimal import Decimal, ROUND_HALF_UP

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "app/src/main/java/com/wppocket/server")
pass_n = fail_n = 0
def check(name, cond):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name)

SITE, DB, RUN = "www", "mysql-data", "lamp-run"

def dir_size(d):                      # BackupLogic.dirSize: bo qua symlink
    if not os.path.exists(d): return 0
    t = 0
    for n in os.listdir(d):
        p = os.path.join(d, n)
        if os.path.islink(p): continue
        t += dir_size(p) if os.path.isdir(p) else os.path.getsize(p)
    return t

def collect(files, backups):
    site, db, run = (dir_size(os.path.join(files, x)) for x in (SITE, DB, RUN))
    b = dir_size(backups) if backups else 0
    other = max(dir_size(files) - site - db - run, 0)
    return site, db, run, b, other

def fmt(b):                           # Kotlin: String.format(Locale.US, "%.1f") = HALF_UP
    if b <= 0: return "0 B"
    if b < 1024: return "%d B" % b
    units = ["KB", "MB", "GB", "TB"]; v = b / 1024.0; i = 0
    while v >= 1024.0 and i < len(units) - 1: v /= 1024.0; i += 1
    return "%s %s" % (Decimal(repr(v)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP), units[i])

def wipe_ok(typed, word):
    w = word.strip()
    return typed is not None and w != "" and typed.strip().lower() == w.lower()

check("formatBytes: 0/am/duoi 1KB", fmt(0) == "0 B" and fmt(-5) == "0 B" and fmt(512) == "512 B" and fmt(1023) == "1023 B")
check("formatBytes: KB/MB/GB mot chu so thap phan", fmt(1024) == "1.0 KB" and fmt(1536) == "1.5 KB" and fmt(5 * 1024**2) == "5.0 MB" and fmt(3 * 1024**3 + 214748365) == "3.2 GB")
check("formatBytes: TB la don vi tran, dau cham thap phan", fmt(2048 * 1024**3) == "2.0 TB" and "," not in fmt(1536))
check("wipeConfirmed: dung tu (khong phan biet hoa thuong, bo khoang trang)", wipe_ok("XOA", "XOA") and wipe_ok("  xoa ", "XOA") and wipe_ok("Delete", "DELETE"))
check("wipeConfirmed: sai/rong/None/tu rong -> khong", not wipe_ok("XO", "XOA") and not wipe_ok("", "XOA") and not wipe_ok(None, "XOA") and not wipe_ok("", "") and not wipe_ok("x", "  "))

tmp = tempfile.mkdtemp()
try:
    files = os.path.join(tmp, "files")
    for d in ("www/wp-content", "mysql-data", "lamp-run"): os.makedirs(os.path.join(files, d))
    def w(rel, n):
        with open(os.path.join(files, rel), "wb") as f: f.write(b"\0" * n)
    w("www/wp-content/a.bin", 1000); w("mysql-data/ibdata1", 4000); w("lamp-run/x.log", 300); w("admin-password.txt", 16); w("other.dat", 84)
    out = os.path.join(tmp, "outside"); os.makedirs(out); open(os.path.join(out, "huge.bin"), "wb").write(b"\0" * 50000)
    os.symlink(out, os.path.join(files, "www", "link"))
    bk = os.path.join(tmp, "backups"); os.makedirs(bk); open(os.path.join(bk, "b.zip"), "wb").write(b"\0" * 777)
    s, d, r, b, o = collect(files, bk)
    check("collect: tung nhom dung, symlink KHONG tinh", (s, d, r, b) == (1000, 4000, 300, 777))
    check("collect: 'khac' = phan con lai cua filesDir", o == 100)
    check("collect: khong ton tai / khong co thu muc backup -> toan 0", collect(os.path.join(tmp, "none"), None) == (0, 0, 0, 0, 0))
finally:
    shutil.rmtree(tmp, ignore_errors=True)

# ---- doi chieu van ban voi ma that ----
kt = open(os.path.join(SRC, "DataLifecycle.kt"), encoding="utf-8").read()
def const(n): m = re.search(r'const val %s = "([^"]+)"' % n, kt); return m.group(1) if m else None
check("hang so Kotlin == ban port (www, mysql-data, lamp-run)", (const("SITE_DIR"), const("DB_DIR"), const("RUN_DIR")) == (SITE, DB, RUN))
sh = lambda p: open(os.path.join(ROOT, p), encoding="utf-8").read()
check("docroot 'www' khop runtime.json cua php + node/python/static", '"docroot": "www"' in sh("scripts/runtimes/php.sh") and '"docroot": "www"' in sh("scripts/lib/generic_runtime.sh"))
check("start-lamp.sh that su dung $DATA/mysql-data va $RUNDIR=lamp-run duoi filesDir", '"$DATA/mysql-data' in sh("scripts/runtimes/templates/start-lamp.sh") and "lamp-run" in sh("scripts/runtimes/templates/start-lamp.sh"))
check("thu muc backup 'backups' khop BackupManager (getExternalFilesDir(null)/backups)", 'File(context.getExternalFilesDir(null), "backups")' in sh("app/src/main/java/com/wppocket/server/BackupManager.kt"))
check("Kotlin dung BackupLogic.dirSize (bo qua symlink) cho moi nhom", kt.count("BackupLogic.dirSize(") >= 5)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
