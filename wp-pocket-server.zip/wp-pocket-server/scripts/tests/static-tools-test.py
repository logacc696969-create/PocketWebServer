#!/usr/bin/env python3
"""Kiem thu 2 cong cu tinh (scripts/tools/lex-check.py, android-ref-check.py) - dung DOI CHUNG AM: chen loi co y vao ban sao cua du an
va yeu cau cong cu phai bao dung loi do (cong cu "khong bao gi bao loi" thi vo dung). Khong can php/kotlinc/mang."""
import os, re, shutil, subprocess, sys, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
PASS = FAIL = 0


def ok(cond, name):
    global PASS, FAIL
    if cond: PASS += 1; print('  OK  ', name)
    else: FAIL += 1; print('  FAIL', name)


def run(tool, *args):
    r = subprocess.run([sys.executable, os.path.join(ROOT, 'scripts/tools', tool), *args], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def copy_project():
    d = tempfile.mkdtemp(prefix='stat-')
    shutil.copytree(os.path.join(ROOT, 'app'), os.path.join(d, 'app'))
    return d


def edit(path, old, new, count=1):
    s = open(path, encoding='utf8').read()
    assert old in s, (path, old)
    open(path, 'w', encoding='utf8').write(s.replace(old, new, count))


print('== ban goc phai SACH ==')
rc, out = run('android-ref-check.py', ROOT); ok(rc == 0, 'android-ref-check sach tren du an that: ' + out.strip().splitlines()[-1])
rc, out = run('lex-check.py', os.path.join(ROOT, 'app'), os.path.join(ROOT, 'scripts')); ok(rc == 0, 'lex-check sach tren du an that: ' + out.strip().splitlines()[-1])

print('== lex-check: Kotlin ==')
t = tempfile.mkdtemp(prefix='lex-')
def kt(name, body):
    p = os.path.join(t, name); open(p, 'w', encoding='utf8').write(body); return p
good = kt('good.kt', 'package x\n/** doc ${a} "q" */\nfun f(a: Int): String { val s = "a${a + 1}b\\"c"; val r = """raw "x" ${a}"""; val c = \'(\'; return s + r + c } // (\n')
bad1 = kt('bad1.kt', 'package x\n/**\n * duong dan lib-dynload/*.so la loi (comment long nhau)\n */\nfun f() {}\n')
bad2 = kt('bad2.kt', 'package x\nfun f() {\n  val a = listOf(1, 2\n}\n')
bad3 = kt('bad3.kt', 'package x\nfun f() { val s = "chua dong\n}\n')
bad4 = kt('bad4.kt', 'package x\nfun f() { } }\n')
ok(run('lex-check.py', good)[0] == 0, 'Kotlin hop le (mau chuoi, chuoi tho, ky tu, chu thich) khong bi bao')
r = run('lex-check.py', bad1); ok(r[0] == 1 and 'chu thich' in r[1], 'bat chu thich KDoc long nhau (/* trong /** */) - loi that cua 1bj')
r = run('lex-check.py', bad2); ok(r[0] == 1, 'bat thieu dau dong ngoac')
r = run('lex-check.py', bad3); ok(r[0] == 1, 'bat chuoi khong dong')
r = run('lex-check.py', bad4); ok(r[0] == 1, 'bat thua dau }')

print('== lex-check: PHP ==')
def php(name, body):
    p = os.path.join(t, name); open(p, 'w', encoding='utf8').write(body); return p
pg = php('good.php', "<?php\n$a = ['x' => \"y {$b}\"]; // ) comment\n# ) hash\n/* ) */\n$h = <<<EOT\n ) { unbalanced in heredoc\nEOT;\nif ($a) { echo 'it\\'s'; }\n?>\n<p>html ( khong tinh</p>\n<?php foreach ($a as $b) { ?> x <?php } ?>\n")
ok(run('lex-check.py', pg)[0] == 0, 'PHP hop le (heredoc, chu thich, HTML xen ke, ngoac trong chuoi) khong bi bao')
r = run('lex-check.py', php('bad1.php', "<?php\nfunction f() {\n  if (1) {\n  echo 'x';\n}\n")); ok(r[0] == 1, 'PHP: bat thieu } ')
r = run('lex-check.py', php('bad2.php', "<?php\n$a = 'chua dong;\n")); ok(r[0] == 1, 'PHP: bat chuoi khong dong')
r = run('lex-check.py', php('bad3.php', "<?php\n$a = foo(1, [2, 3);\n")); ok(r[0] == 1, 'PHP: bat ngoac lech loai')

print('== android-ref-check: chen loi vao ban sao ==')
KT = 'app/src/main/java/com/wppocket/server/'
for name, fn in (
    ('R.id khong ton tai', lambda d: edit(d + '/' + KT + 'LogViewerActivity.kt', 'loadLog(0)\n    }', 'loadLog(0); findViewById<android.view.View>(R.id.khongTonTai)\n    }')),
    ('binding.xxx khong co trong layout', lambda d: edit(d + '/' + KT + 'LogViewerActivity.kt', 'binding.btnShareLog.setOnClickListener', 'binding.nutKhongCo.setOnClickListener')),
    ('R.string khong ton tai', lambda d: edit(d + '/' + KT + 'LogViewerActivity.kt', 'R.string.toast_log_copied', 'R.string.khong_co_chuoi_nay')),
    ('getString thieu tham so', lambda d: edit(d + '/' + KT + 'LogViewerActivity.kt', 'getString(R.string.log_filter_none, q)', 'getString(R.string.log_filter_none)')),
    ('Object.ham khong ton tai', lambda d: edit(d + '/' + KT + 'BackupWorker.kt', 'WebhookUploader.isConfigured(webhookUrl)', 'WebhookUploader.khongCoHam(webhookUrl)')),
    ('Prefs.KEY chua khai bao', lambda d: edit(d + '/' + KT + 'TelegramCommandWorker.kt', 'Prefs.KEY_TELEGRAM_LAST_BACKUP_CMD, now', 'Prefs.KEY_KHONG_CO, now')),
    ('shortcut: targetPackage sai', lambda d: edit(d + '/app/src/main/res/xml/shortcuts.xml', 'android:targetPackage="com.wppocket.server"', 'android:targetPackage="com.khac.app"', 1)),
    ('shortcut: action khong khop hang so ShortcutActivity', lambda d: edit(d + '/app/src/main/res/xml/shortcuts.xml', 'com.wppocket.server.shortcut.STOP', 'com.wppocket.server.shortcut.STOPP')),
    ('ShortcutActivity bi dat exported=true (app khac tat duoc server)', lambda d: edit(d + '/app/src/main/AndroidManifest.xml', '''            android:name=".ShortcutActivity"
            android:exported="false"''', '''            android:name=".ShortcutActivity"
            android:exported="true"''')),
    ('shortcut: targetClass khong ton tai', lambda d: edit(d + '/app/src/main/res/xml/shortcuts.xml', 'com.wppocket.server.LogViewerActivity', 'com.wppocket.server.KhongCoActivity')),
    ('@dimen khong ton tai trong layout', lambda d: edit(d + '/app/src/main/res/layout/activity_main.xml', '@dimen/screen_padding_h', '@dimen/khong_co_dimen', 2)),
):
    d = copy_project()
    try:
        fn(d)
        rc, out = run('android-ref-check.py', d)
        ok(rc == 1, 'bat loi: ' + name)
    finally:
        shutil.rmtree(d, ignore_errors=True)
shutil.rmtree(t, ignore_errors=True)

print('== template nginx: placeholder GIA TRI PHUC TAP khong duoc nhac trong dong chu thich ==')
# start-lamp.sh thay moi chuoi __XXX__ bang sed "s|..|..|g" tren TOAN file ke ca chu thich. Voi __RUNDIR__/__PORT__... (duong dan/so,
# 1 dong) viec nhac trong chu thich vo hai; rieng __CF_REALIP_DIRECTIVES__ nhan gia tri tuy theo module realip nen KHONG duoc xuat hien o
# dong chu thich (1bl suyt mac loi nay). Them ten vao COMPLEX neu start-lamp.sh co them placeholder kieu nay.
COMPLEX = ('__CF_REALIP_DIRECTIVES__',)
for tpl in ('nginx.conf.template', 'nginx-front.conf.template'):
    path = os.path.join(ROOT, 'scripts', 'runtimes', 'templates', tpl)
    if not os.path.exists(path):
        continue
    lines = open(path, encoding='utf8').read().split('\n')
    bad = [(i + 1, l.strip()[:70]) for i, l in enumerate(lines) if l.lstrip().startswith('#') and any(c in l for c in COMPLEX)]
    ok(not bad, tpl + ': placeholder phuc tap khong nam trong chu thich ' + str(bad))
    if tpl == 'nginx.conf.template':
        ok(sum(l.count('__CF_REALIP_DIRECTIVES__') for l in lines) == 1, tpl + ': __CF_REALIP_DIRECTIVES__ xuat hien dung 1 lan (cho that)')
print('== hop dong ten file co/luat giua PHP - nginx - Kotlin (1bl) ==')
def rd(rel): return open(os.path.join(ROOT, rel), encoding='utf8').read()
ngx, prot, auth = rd('scripts/runtimes/templates/nginx.conf.template'), rd('scripts/runtimes/templates/admin-protect.php'), rd('scripts/runtimes/templates/admin-auth.php')
main_kt = rd('app/src/main/java/com/wppocket/server/MainActivity.kt')
for flag in ('rate-limit-on', 'block-bots-on'):
    ok(('__RUNDIR__/' + flag) in ngx and flag in prot, 'co %s: nginx (-f __RUNDIR__/...) va protect.php cung dung ten nay' % flag)
ok('admin-ip-rules.json' in auth and 'admin-ip-rules.json' in prot and 'lamp-run/admin-ip-rules.json' in main_kt,
   'file luat IP: auth.php (doc), protect.php (ghi), MainActivity (nut xoa khan cap) cung ten admin-ip-rules.json')
ok("$rundir . '/uptime.csv'" in rd('scripts/runtimes/templates/admin-metrics.php') and 'uptime.csv' in rd('app/src/main/java/com/wppocket/server/Monitoring.kt'),
   'uptime.csv: Monitoring.kt (ghi) va admin-metrics.php (doc) cung ten')
print('TONG KET: pass=%d fail=%d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
