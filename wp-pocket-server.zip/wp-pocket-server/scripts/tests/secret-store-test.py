#!/usr/bin/env python3
"""AC1 (PDF 2; HANDOFF.md muc 1bp-I): bi mat trong SharedPreferences duoc ma hoa; test nay (1) chay AES-GCM THAT tren JDK, (2) CANH GAC
tinh: khong cho phep doc/ghi truc tiep cac khoa bi mat ngoai SecretStore, va moi khoa 'nhin giong bi mat' moi them vao Prefs deu phai
duoc dang ky trong SecretStore.SECRET_KEYS (neu khong test do). Khong can kotlinc/Android."""
import os, re, subprocess, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
K = "app/src/main/java/com/wppocket/server/"
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
rd = lambda p: open(os.path.join(ROOT, p), encoding="utf-8").read()

# ---- (1) JDK that ----
try: mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception: mods = ""
if "jdk.compiler" in mods:
    r = subprocess.run(["java", os.path.join(ROOT, "scripts/tests/java/SecretCodecPort.java")], capture_output=True, text=True, timeout=300)
    check("SecretCodecPort tren JDK that (AES-256-GCM that): 12/12", r.returncode == 0 and "pass=12" in r.stdout and "fail=0" in r.stdout, r.stdout[-300:] + r.stderr[-200:])
else:
    print("(bo qua phan JDK: thieu jdk.compiler)")

# ---- (2) canh gac tinh ----
prefs = rd(K + "Prefs.kt"); store = rd(K + "SecretStore.kt"); codec = rd(K + "SecretCodec.kt")
all_keys = dict(re.findall(r'const val (KEY_[A-Z0-9_]+) = "([^"]+)"', prefs))
secretish = {k for k in all_keys if re.search(r"TOKEN|PASSPHRASE|PASSWORD|SECRET|WEBHOOK_URL|HEARTBEAT_URL|API_KEY", k)}
reg = set(re.findall(r"Prefs\.(KEY_[A-Z0-9_]+)", re.search(r"SECRET_KEYS: Set<String> = setOf\((.*?)\)\n", store, re.S).group(1)))
check("moi khoa Prefs 'nhin giong bi mat' deu duoc dang ky trong SecretStore.SECRET_KEYS (thieu: %s)" % sorted(secretish - reg), secretish <= reg)
check("SECRET_KEYS chi gom khoa co that trong Prefs (khong go sai ten): %s" % sorted(reg - set(all_keys)), reg <= set(all_keys))
check("7 khoa bi mat da biet co mat: token tunnel, cum mat khau backup, token Telegram, webhook backup/canh bao, heartbeat, token API trang thai (T1)",
      reg == {"KEY_TUNNEL_TOKEN", "KEY_BACKUP_ENCRYPT_PASSPHRASE", "KEY_TELEGRAM_BOT_TOKEN", "KEY_BACKUP_WEBHOOK_URL", "KEY_ALERT_WEBHOOK_URL", "KEY_HEARTBEAT_URL", "KEY_API_TOKEN"}, str(reg))
alt = "|".join(sorted(reg))
raw_rx = re.compile(r"(getString|putString)\(\s*Prefs\.(%s)\b" % alt)
def violations(text_by_file):
    out = []
    for f, t in text_by_file.items():
        if f in ("Prefs.kt", "SecretStore.kt"): continue
        for i, l in enumerate(t.split("\n"), 1):
            if raw_rx.search(l) and not re.search(r"SecretStore\.(get|encode)\(", l): out.append("%s:%d" % (f, i))
    return out
files = {os.path.basename(p): rd(p) for p in [K + n for n in os.listdir(os.path.join(ROOT, K)) if n.endswith(".kt")]}
v = violations(files)
check("KHONG con cho nao doc/ghi truc tiep 6 khoa bi mat ngoai SecretStore (vi pham: %s)" % v, v == [])
mut = dict(files); mut["BackupWorker.kt"] = files["BackupWorker.kt"].replace("SecretStore.get(prefs, Prefs.KEY_TELEGRAM_BOT_TOKEN, null)", "prefs.getString(Prefs.KEY_TELEGRAM_BOT_TOKEN, null)", 1)
check("DOI CHUNG AM: dua lai 1 lan doc truc tiep thi canh gac BAT DUOC", violations(mut) != [])
n_get = sum(len(re.findall(r"SecretStore\.get\(", t)) for f, t in files.items() if f != "SecretStore.kt")
n_enc = sum(len(re.findall(r"SecretStore\.encode\(", t)) for f, t in files.items() if f != "SecretStore.kt")
check("so cho doc qua SecretStore.get >= 23 va ghi qua encode >= 6 (khong giam; T1 them cho moi) (%d / %d)" % (n_get, n_enc), n_get >= 23 and n_enc >= 6)
check("SecretCodec chi dung java*/javax* (khong Android) -> test JVM duoc", all(re.match(r"(java|javax)\.", i) for i in re.findall(r"^import ([\w.]+)", codec, re.M)))
check("FAIL-OPEN: Keystore loi -> encode tra gia tri goc, khong nem loi (khong chan nguoi dung)", "val k = key() ?: return plain" in store and "catch (e: Exception)" in store and "keyUnavailable = true" in store)
check("khoa mat/du lieu hong khi giai ma -> tra mac dinh (nhu chua cau hinh), khong nem loi", "return decode(stored) ?: default" in store and "val k = key() ?: return null" in store)
check("di tru tu dong: gia tri cu dang ro duoc ma hoa ghi lai o lan doc dau, van tra gia tri dang ro cho nguoi goi", "prefs.edit().putString(key, sealed).apply()" in store and "return stored" in store)
check("khoa AES-256-GCM, khong padding, trong AndroidKeyStore, KHONG yeu cau mo khoa man hinh (worker nen chay khi khoa may)",
      "setKeySize(256)" in store and "BLOCK_MODE_GCM" in store and "ENCRYPTION_PADDING_NONE" in store and 'PROVIDER = "AndroidKeyStore"' in store and "setUnlockedDeviceRequired" not in store)
ma = rd(K + "MainActivity.kt")
check("MainActivity: o nhap van hien gia tri da giai ma (SecretStore.get) va ghi lai bang encode", 'binding.etTunnelToken.setText(SecretStore.get(prefs, Prefs.KEY_TUNNEL_TOKEN, "") ?: "")' in ma and "putString(Prefs.KEY_TUNNEL_TOKEN, SecretStore.encode(token))" in ma)
check("allowBackup van false (bi mat da ma hoa khong bi dua len may chu sao luu)", 'android:allowBackup="false"' in rd("app/src/main/AndroidManifest.xml"))
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
