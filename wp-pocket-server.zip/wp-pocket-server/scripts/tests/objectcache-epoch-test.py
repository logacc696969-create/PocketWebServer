#!/usr/bin/env python3
"""Kiem thu co che VO HIEU HOA CACHE APCu khi du lieu doi tu ngoai pool php-fpm (HANDOFF.md muc 1bd) - APCu THAT.

Boi canh: object-cache.php (APCu, het han = 0) giu du lieu WordPress qua cac request; neu 1 tien trinh KHAC (WP-CLI,
Adminer, khoi phuc backup, promote staging) doi DB thi php-fpm van tra du lieu CU. Co che: ben ghi tu ngoai ghi 1 chuoi
moi vao lamp-run/object-cache-epoch; object-cache.php so chuoi do moi request va xoa APCu khi khac.

Mo phong "request moi" TRONG 1 tien trinh PHP (APCu cua CLI song trong tien trinh): huy $wp_object_cache roi wp_cache_init()
lai - dung la dieu php-fpm lam moi request (APCu giu nguyen, doi tuong WP_Object_Cache dung lai tu dau).
Moi kich ban co DOI CHUNG de test khong "dung" vi 1 ly do khac (vd APCu khong bat).

Can php-apcu (CI cai; sandbox: apt install php-apcu). Khong co -> bo qua, thoat 0 va IN RO (khong gia vo da kiem).
Chay: python3 scripts/tests/objectcache-epoch-test.py
"""
import os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.join(HERE, '..', 'runtimes', 'templates')
PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond: PASS += 1; print('PASS: ' + name)
    else: FAIL += 1; print('FAIL: ' + name + ((' -> ' + str(detail)[:300]) if detail else ''))


def php(code, env=None, apcu=True):
    args = ['php', '-d', 'display_errors=1', '-d', 'error_reporting=E_ALL']
    if apcu: args += ['-d', 'apc.enabled=1', '-d', 'apc.enable_cli=1']
    e = dict(os.environ); e.pop('APP_HOME', None); e.update(env or {})
    p = subprocess.run(args + ['-r', code], capture_output=True, text=True, env=e)
    return p.returncode, p.stdout, p.stderr


def apcu_available():
    rc, out, err = php('echo function_exists("apcu_enabled") && apcu_enabled() ? "YES" : "NO";')
    return out.strip() == 'YES'


# Dung HAM THAT trong admin-auth.php (khong chep lai): tach theo ten ham.
def extract_bump_function():
    src = open(os.path.join(TPL, 'admin-auth.php'), encoding='utf-8').read()
    m = re.search(r'function wp_pocket_bump_object_cache_epoch\(\): void\n\{.*?\n\}\n', src, re.S)
    assert m, 'khong tim thay wp_pocket_bump_object_cache_epoch() trong admin-auth.php'
    return m.group(0)


PRELUDE = r'''
define("ABSPATH", "/tmp/oc-test-abspath/");
require %r;
function newreq() { unset($GLOBALS["wp_object_cache"]); wp_cache_init(); }   // 1 "request moi": APCu con, doi tuong cache dung lai
function v($k) { $f = false; $r = wp_cache_get($k, "grp", true, $f); return $f ? $r : "<MISS>"; }
apcu_clear_cache();
''' % os.path.join(TPL, 'object-cache.php')


def main():
    if not apcu_available():
        print('(BO QUA: php khong co APCu kha dung - cai php-apcu. Test nay KHONG duoc tinh la da kiem.)')
        return 0
    tmp = tempfile.mkdtemp(prefix='oc-epoch-')
    home = os.path.join(tmp, 'app'); os.makedirs(os.path.join(home, 'lamp-run'))
    epoch = os.path.join(home, 'lamp-run', 'object-cache-epoch')
    env = {'APP_HOME': home}
    try:
        print('== 1. co che epoch (APCu that, nhieu "request" trong 1 tien trinh) ==')
        code = PRELUDE + r'''
$out = [];
newreq(); wp_cache_set("k", "goc", "grp");
newreq(); $out[] = "A:" . v("k");                                  // chua co file epoch: giu nguyen (DOI CHUNG: APCu thuc su luu qua request)
file_put_contents(%(ep)r, "epoch-1");                              // ben ngoai bao hieu lan 1
newreq(); $out[] = "B:" . v("k");                                  // phai bi xoa
wp_cache_set("k", "moi", "grp");
newreq(); $out[] = "C:" . v("k");                                  // cung epoch: KHONG xoa lai moi request
newreq(); $out[] = "D:" . v("k");
file_put_contents(%(ep)r, "epoch-1");                              // ghi lai CUNG chuoi: khong phai thay doi
newreq(); $out[] = "E:" . v("k");
file_put_contents(%(ep)r, "epoch-2");
newreq(); $out[] = "F:" . v("k");                                  // doi that: xoa lai
echo implode("|", $out);
''' % {'ep': epoch}
        rc, out, err = php(code, env)
        r = dict(x.split(':', 1) for x in out.strip().split('|')) if out.strip() else {}
        check('DOI CHUNG: chua co file epoch -> cache BEN qua cac request (APCu that su dang chay)', r.get('A') == 'goc', (rc, out, err))
        check('ben ngoai ghi epoch -> request ke tiep THAY MISS (cache bi xoa)', r.get('B') == '<MISS>', r)
        check('sau khi xoa, gia tri ghi MOI van ben qua request (khong xoa lai moi request)', r.get('C') == 'moi' and r.get('D') == 'moi', r)
        check('ghi lai CUNG chuoi epoch khong gay xoa', r.get('E') == 'moi', r)
        check('epoch DOI -> xoa lai', r.get('F') == '<MISS>', r)
        check('khong co canh bao/loi PHP', err.strip() == '' and 'Warning' not in out and 'Notice' not in out, err)

        print('\n== 2. truong hop bien ==')
        os.remove(epoch)
        rc, out, err = php(PRELUDE + r'''newreq(); wp_cache_set("k","x","grp"); newreq(); echo v("k");''', env)
        check('file epoch KHONG ton tai -> khong xoa, khong loi', out.strip() == 'x' and err.strip() == '', (out, err))
        rc, out, err = php(PRELUDE + r'''newreq(); wp_cache_set("k","x","grp"); file_put_contents(%r, "e"); newreq(); echo v("k");''' % epoch, {})
        check('KHONG co APP_HOME -> bo qua co che (giu hanh vi cu), khong loi', out.strip() == 'x' and err.strip() == '', (out, err))
        rc, out, err = php(PRELUDE + r'''newreq(); wp_cache_set("k","x","grp"); newreq(); echo v("k");''', {'APP_HOME': os.path.join(tmp, 'khong-ton-tai')})
        check('APP_HOME tro toi thu muc KHONG ton tai -> khong loi, cache van chay', out.strip() == 'x' and err.strip() == '', (out, err))
        open(epoch, 'w').write('')
        rc, out, err = php(PRELUDE + r'''newreq(); wp_cache_set("k","x","grp"); newreq(); echo v("k");''', env)
        check('file epoch RONG -> khong loi (xu ly nhu 1 gia tri)', err.strip() == '', err)
        os.remove(epoch)
        # APCu tat: drop-in van chay (khong dung APCu), khong goi ham apcu_*
        rc, out, err = php(r'''define("ABSPATH","/tmp/x/"); require %r; file_put_contents(%r,"e"); wp_cache_init(); wp_cache_set("k","x","grp"); echo wp_cache_get("k","grp");''' % (os.path.join(TPL, 'object-cache.php'), epoch), env, apcu=False)
        check('APCu TAT: drop-in van chay, khong goi apcu_* (khong "undefined function")', out.strip() == 'x' and err.strip() == '', (out, err))
        os.remove(epoch)

        print('\n== 3. wp_pocket_bump_object_cache_epoch() (ham THAT trich tu admin-auth.php) ==')
        fn = extract_bump_function()
        runner = '<?php\n' + fn + '\nwp_pocket_bump_object_cache_epoch();\n'
        rf = os.path.join(tmp, 'bump.php'); open(rf, 'w').write(runner)
        p = subprocess.run(['php', rf], capture_output=True, text=True, env=dict(os.environ, APP_HOME=home))
        check('bump tao file epoch (APP_HOME co lamp-run)', os.path.isfile(epoch) and open(epoch).read().strip() != '', p.stderr)
        first = open(epoch).read()
        subprocess.run(['php', rf], capture_output=True, text=True, env=dict(os.environ, APP_HOME=home))
        check('lan bump sau cho chuoi KHAC (khong bi trung du goi lien tiep)', open(epoch).read() != first)
        check('khong de lai tep tam', not [f for f in os.listdir(os.path.join(home, 'lamp-run')) if '.tmp' in f], os.listdir(os.path.join(home, 'lamp-run')))
        e2 = dict(os.environ); e2.pop('APP_HOME', None)
        p = subprocess.run(['php', rf], capture_output=True, text=True, env=e2)
        check('KHONG co APP_HOME -> im lang bo qua (khong loi/canh bao)', p.returncode == 0 and p.stdout == '' and p.stderr == '', (p.stdout, p.stderr))
        os.makedirs(os.path.join(tmp, 'app2'))
        p = subprocess.run(['php', rf], capture_output=True, text=True, env=dict(os.environ, APP_HOME=os.path.join(tmp, 'app2')))
        check('co APP_HOME nhung CHUA co lamp-run -> khong tao, khong loi', p.returncode == 0 and not os.path.exists(os.path.join(tmp, 'app2', 'lamp-run')) and p.stderr == '', (p.stdout, p.stderr))

        print('\n== 4. TICH HOP: bump that (ham trong admin-auth.php) -> drop-in that xoa cache that ==')
        code = PRELUDE + (r'''
%s
$out = [];
newreq(); wp_cache_set("siteurl", "http://cu", "grp");
newreq(); $out[] = "before:" . v("siteurl");
wp_pocket_bump_object_cache_epoch();                      // ben ghi tu ngoai (vd trang wpcli) bao hieu
newreq(); $out[] = "after:" . v("siteurl");
echo implode("|", $out);
''' % fn)
        rc, out, err = php(code, env)
        r = dict(x.split(':', 1) for x in out.strip().split('|')) if out.strip() else {}
        check('tich hop: truoc bump cache con, sau bump (ham THAT) cache bi xoa', r.get('before') == 'http://cu' and r.get('after') == '<MISS>', (out, err))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
