#!/usr/bin/env python3
"""T1 - API trang thai CHI DOC cho LAN (PDF 2; HANDOFF.md muc 1bp-L). Kiem: (1) logic tren JDK that + JSON bang json.loads; (2) ham shell THAT
cua start-lamp.sh chay bang bash that tren nginx.conf render tu template that; (3) MO HINH quy tac allow/deny doc truc tiep tu khoi da chen
(khong phai nginx that - xem 'CHUA kiem' trong HANDOFF); (4) noi day Kotlin/giao dien. Khong can nginx/php/kotlinc."""
import ipaddress, json, os, re, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.abspath(os.path.join(HERE, ".."))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
import lamp_render as lr
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
rd = lambda p: open(os.path.join(ROOT, p), encoding="utf-8").read()
SL = rd("scripts/runtimes/templates/start-lamp.sh"); NG_T = rd("scripts/runtimes/templates/nginx.conf.template")

# ---- (1) JDK that ----
try: mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception: mods = ""
if "jdk.compiler" in mods:
    r = subprocess.run(["java", "-Dstdout.encoding=UTF-8", os.path.join(ROOT, "scripts/tests/java/ApiLogicPort.java")], capture_output=True, text=True, timeout=300, encoding="utf-8")
    check("ApiLogicPort tren JDK that (SecureRandom that): 5/5", r.returncode == 0 and "pass=5" in r.stdout and "fail=0" in r.stdout, r.stdout[-300:] + r.stderr[-200:])
    js = [json.loads(l[5:]) for l in r.stdout.splitlines() if l.startswith("JSON:")]
    check("JSON do Java sinh ra la JSON HOP LE (json.loads) - 3 mau, ke ca chuoi co nhay kep/gach cheo/xuong dong/ky tu dieu khien/tieng Viet", len(js) == 3)
    if len(js) == 3:
        a, b, c = js
        check("mau 1: du lieu day du dung kieu (so, bool, chuoi)", a == {"schema": "wp-pocket-status/1", "generated_at": 1700000000, "server_running": True, "battery_pct": 83, "charging": True, "disk_used_pct": 41, "last_backup_at": 1699990000, "backup_count": 5, "app_version": "1.2.3"})
        check("mau 2: gia tri khong biet -> null (khong bia so); chuoi phuc tap duoc thoat dung va doc lai nguyen ven", b["battery_pct"] is None and b["disk_used_pct"] is None and b["last_backup_at"] is None and b["backup_count"] == 0 and b["app_version"] == 'ver "x" \\ \n\t\x02 tiếng Việt')
        check("mau 3: pin 101 va backup am -> null (ngoai khoang hop le), dia 100 giu nguyen", c["battery_pct"] is None and c["disk_used_pct"] == 100 and c["last_backup_at"] is None)
        check("JSON KHONG chua truong nhay cam (khong token/mat khau/duong dan/IP)", all(k in {"schema", "generated_at", "server_running", "battery_pct", "charging", "disk_used_pct", "last_backup_at", "backup_count", "app_version"} for k in a))
else:
    print("(bo qua phan JDK)")

# ---- (2) ham shell that ----
m = re.search(r"(# === API trang thai chi doc cho LAN.*?# === HET API trang thai ===)", SL, re.S)
check("start-lamp.sh co khoi ham API trang thai (co moc dau/cuoi)", m is not None)
FUNCS = m.group(1)
values = {v: "8080" if "PORT" in v else ("" if "REALIP" in v or "LINE" in v or "PREPEND" in v else "/x") for _p, v in lr.sed_pairs("nginx.conf.template", SL)}
ng0 = lr.render(NG_T, "nginx.conf.template", values, SL)
def run(token, rundir_name="lamp-run"):
    with tempfile.TemporaryDirectory() as d:
        rd_ = os.path.join(d, rundir_name); os.makedirs(rd_)
        open(os.path.join(rd_, "nginx.conf"), "w").write(ng0); open(os.path.join(d, "funcs.sh"), "w").write(FUNCS)
        env = {k: v for k, v in os.environ.items() if k != "WPP_API_TOKEN"}
        if token is not None: env["WPP_API_TOKEN"] = token
        r = subprocess.run(["bash", "-c", 'RUNDIR="%s"; . "%s/funcs.sh"; api_status_nginx; api_status_nginx' % (rd_, d)], capture_output=True, text=True, env=env, cwd=d)
        return r, open(os.path.join(rd_, "nginx.conf")).read(), sorted(os.listdir(rd_)), sorted(os.listdir(d)), rd_
TOK = "0123456789abcdef" * 4
for tok in (None, "", "abc", "a" * 31, "a" * 65, "A" * 40, "g" * 40, "a" * 39 + '"', "a" * 39 + ";", "a" * 39 + "$", "a" * 39 + " ", "a" * 39 + "\n", "a" * 39 + "'", "$(touch PWN)", "`touch PWN`", "a" * 40 + "; touch PWN"):
    r, ng, rfiles, dfiles, _ = run(tok)
    check("token khong hop le %r -> nginx.conf giu nguyen TUNG BYTE, khong tep la, khong tiem lenh" % (tok if tok is None or len(tok) < 12 else tok[:8] + "..",), r.returncode == 0 and ng == ng0 and rfiles == ["nginx.conf"] and "PWN" not in dfiles + rfiles)
for tok in (TOK, "a" * 32, "0" * 40):
    r, ng, rfiles, _, rundir = run(tok)
    check("token hop le (%d ky tu): chen DUNG 1 khoi (goi 2 lan van chi 1 - khong 'duplicate location'), khong de lai tep tam" % len(tok), r.returncode == 0 and ng.count("location = /api/v1/status {") == 1 and rfiles == ["nginx.conf"], r.stderr)
r, ng, _, _, rundir = run(TOK)
blk = re.search(r"        location = /api/v1/status \{.*?\n        \}\n", ng, re.S).group(0)
check("khoi nam TRONG server chinh, ngay tai diem danh dau, TRUOC /_fpm-status", ng.index("WPP-API-INSERT-POINT") < ng.index("location = /api/v1/status") < ng.index("location = /_fpm-status"))
check("khoi co dung 3 dong allow (192.168/16, 10/8, 172.16/12) + deny all", re.findall(r"allow ([\d./]+);", blk) == ["192.168.0.0/16", "10.0.0.0/8", "172.16.0.0/12"] and "deny all;" in blk)
check("AN TOAN: KHONG co 'allow 127.0.0.1', 'allow all', '::1' (tunnel noi tu 127.0.0.1 - se mo cho Internet)", not re.search(r"allow\s+(127\.|all|::1|0\.0\.0\.0)", blk))
check("kiem token bang 'if ($http_authorization != \"Bearer <token>\") { return 401; }' - chi 'return' trong if", ('if ($http_authorization != "Bearer %s") { return 401; }' % TOK) in blk and blk.count("if (") == 1)
check("alias tro dung tep trang thai trong RUNDIR; khong cache; nosniff; nhac lai X-Request-ID (nginx khong ke thua add_header)", ("alias %s/api-status.json;" % rundir) in blk and 'Cache-Control "no-store"' in blk and "nosniff" in blk and "add_header X-Request-ID $request_id always;" in blk)
check("khoi KHONG ghi log truy cap (token nam trong header, khong lo ra access log)", "access_log off;" in blk)
check("tong dau { } cua nginx.conf van can bang sau khi chen", ng.count("{") == ng.count("}"))
with tempfile.NamedTemporaryFile("w", suffix=".conf", delete=False) as f: f.write(ng); tmpc = f.name
lint = subprocess.run([sys.executable, os.path.join(ROOT, "scripts/tools/nginx-lint.py"), tmpc], capture_output=True, text=True); os.unlink(tmpc)
check("nginx-lint sach tren nginx.conf SAU KHI chen khoi API", lint.returncode == 0, lint.stdout + lint.stderr)
check("nginx.conf gom CA token chi o dung 1 cho (khong nhan ban ra noi khac)", ng.count(TOK) == 1)

# ---- (3) mo hinh quy tac allow/deny doc tu khoi da chen ----
rules = re.findall(r"^\s*(allow|deny) ([\d./]+|all);", blk, re.M)
def decide(ip, auth):
    for kind, net in rules:   # nginx: quy tac dau tien khop thang; 'deny all' cuoi
        if net == "all" or ipaddress.ip_address(ip) in ipaddress.ip_network(net):
            if kind == "deny": return 403
            break
    return 200 if auth == "Bearer " + TOK else 401
cases = [("192.168.1.50", "Bearer " + TOK, 200), ("10.0.0.7", "Bearer " + TOK, 200), ("172.16.0.1", "Bearer " + TOK, 200), ("172.31.255.254", "Bearer " + TOK, 200),
         ("127.0.0.1", "Bearer " + TOK, 403), ("8.8.8.8", "Bearer " + TOK, 403), ("172.15.255.255", "Bearer " + TOK, 403), ("172.32.0.1", "Bearer " + TOK, 403),
         ("192.169.0.1", "Bearer " + TOK, 403), ("11.0.0.1", "Bearer " + TOK, 403), ("100.64.0.1", "Bearer " + TOK, 403),
         ("192.168.1.50", None, 401), ("192.168.1.50", "Bearer wrong", 401), ("192.168.1.50", "bearer " + TOK, 401), ("192.168.1.50", TOK, 401), ("192.168.1.50", "Bearer " + TOK + " ", 401)]
bad = [(ip, a, want, decide(ip, a)) for ip, a, want in cases if decide(ip, a) != want]
check("MO HINH: LAN + token dung -> 200; 127.0.0.1 (tunnel), IP cong cong, bien 172.15/172.32, CGNAT 100.64 -> 403; sai/thieu/khac kieu token -> 401: %s" % bad, bad == [])
check("DOI CHUNG AM: neu them 'allow 127.0.0.1' thi mo hinh bat duoc lo hong (Internet qua tunnel vao duoc)", (lambda: (rules.insert(0, ("allow", "127.0.0.1/32")), decide("127.0.0.1", "Bearer " + TOK))[1])() == 200)

# ---- (4) noi day ----
al = rd("app/src/main/java/com/wppocket/server/ApiLogic.kt"); svc = rd("app/src/main/java/com/wppocket/server/ServerForegroundService.kt"); mon = rd("app/src/main/java/com/wppocket/server/Monitoring.kt")
st = rd("app/src/main/java/com/wppocket/server/StatusApi.kt"); ma = rd("app/src/main/java/com/wppocket/server/MainActivity.kt")
check("Kotlin <-> shell: do dai token toi thieu/toi da giong nhau (32/64)", "MIN_TOKEN_LEN = 32" in al and "MAX_TOKEN_LEN = 64" in al and '-ge 32' in FUNCS and '-le 64' in FUNCS and "[!0-9a-f]" in FUNCS)
check("service chi truyen WPP_API_TOKEN khi nguoi dung BAT API va token hop le", 'if (sleepPrefs.getBoolean(Prefs.KEY_API_ENABLED, false))' in svc and 'env["WPP_API_TOKEN"] = apiToken' in svc and "ApiLogic.isValidToken(apiToken)" in svc)
check("token doc qua SecretStore (khong lo dang ro trong SharedPreferences)", "SecretStore.get(sleepPrefs, Prefs.KEY_API_TOKEN, null)" in svc and "SecretStore.encode(newApiToken())" in ma)
check("StatusApi.write duoc goi: chu ky suc khoe (runPeriodic) + luc server len; tat API thi XOA tep", "try { StatusApi.write(context) }" in mon and "StatusApi.write(applicationContext)" in svc and "f.delete()" in st and "KEY_API_ENABLED" in st)
check("StatusApi ghi nguyen tu (tep tam + doi ten) vao lamp-run/api-status.json - dung duong dan nginx alias", 'lamp-run/api-status.json' in st and "tmp.renameTo(f)" in st and "alias ${RUNDIR}/api-status.json;" in FUNCS)
check("start-lamp.sh: api_status_nginx goi dung 1 lan, SAU dong render nginx.conf va SAU php_tuning_nginx; token KHONG bi echo/log", SL.count("\napi_status_nginx   #") == 1 and SL.index("\nphp_tuning_nginx   #") < SL.index("\napi_status_nginx   #") and not re.search(r"echo[^\n]*WPP_API_TOKEN|log[^\n]*WPP_API_TOKEN", SL))
check("template: diem danh dau WPP-API-INSERT-POINT xuat hien DUNG 1 lan va chi la chu thich", NG_T.count("WPP-API-INSERT-POINT") == 1 and re.search(r"^\s*#[^\n]*WPP-API-INSERT-POINT", NG_T, re.M) is not None)
check("giao dien: hop kiem + nut + luu pref; mac dinh TAT", "cbApi.setOnCheckedChangeListener" in ma and "btnApiInfo.setOnClickListener { showApiInfo() }" in ma and "putBoolean(Prefs.KEY_API_ENABLED, enabled)" in ma and 'getBoolean(Prefs.KEY_API_ENABLED, false)' in ma)
check("KEY_API_TOKEN da dang ky trong SecretStore.SECRET_KEYS", "Prefs.KEY_API_TOKEN" in re.search(r"SECRET_KEYS: Set<String> = setOf\((.*?)\)\n", rd("app/src/main/java/com/wppocket/server/SecretStore.kt"), re.S).group(1))
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
