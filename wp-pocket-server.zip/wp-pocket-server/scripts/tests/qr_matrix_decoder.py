#!/usr/bin/env python3
"""Bo giai ma QR muc MA TRAN, viet RIENG BIET voi QrCode.kt/QrCodePort.java (HANDOFF.md muc 1bq).

Muc dich: bang chung doc lap rang ma tran do bo ma hoa sinh ra la mot ma QR hop le theo dac ta - KHONG phu thuoc viec anh co duoc
bo dò tim cua OpenCV phat hien hay khong (OpenCV dò tim hay lo voi ma day/lon, du giai ma dung khi biet san 4 goc - xem
qr-code-test.py). Bo giai ma nay: dung ban do vung chuc nang riêng, doc ma tu theo duong zigzag, bo mat na, tach xen ke thanh cac
khoi, roi kiem tra MOI khoi co syndrome Reed-Solomon bang 0 tren GF(256) (da thuc 0x11D) va giai ma che do byte.

Khong thu loi (khong sua sai): chi xac nhan "tat ca khoi hop le". Viec sua loi thuc su duoc kiem bang OpenCV (qr-code-test.py muc 5).
Cac bang so khoi/ECC la tham so DAU VAO (lay tu QrCode.kt) - bang do duoc doi chieu voi giai ma that cua OpenCV o 160 to hop.
"""
import numpy as np

EXP = [0] * 512
LOG = [0] * 256
_x = 1
for _i in range(255):
    EXP[_i] = _x
    LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    EXP[_i] = EXP[_i - 255]


def gmul(a, b):
    return 0 if a == 0 or b == 0 else EXP[LOG[a] + LOG[b]]


def n_raw(ver):
    r = (16 * ver + 128) * ver + 64
    if ver >= 2:
        na = ver // 7 + 2
        r -= (25 * na - 10) * na - 55
        if ver >= 7:
            r -= 36
    return r


def align_positions(ver):
    if ver == 1:
        return []
    num = ver // 7 + 2
    step = 26 if ver == 32 else ((ver * 4 + 4 + num * 2 - 3) // (num * 2 - 2)) * 2
    return [6] + [ver * 4 + 10 - step * (num - 1 - i) for i in range(1, num)]


_cache = {}


def _order(ver):
    """Danh sach (hang, cot) cua cac module DU LIEU theo thu tu zigzag cua dac ta."""
    if ver in _cache:
        return _cache[ver]
    n = ver * 4 + 17
    f = np.zeros((n, n), bool)
    f[0:9, 0:9] = True
    f[0:9, n - 8:n] = True
    f[n - 8:n, 0:9] = True
    f[6, :] = True
    f[:, 6] = True
    pos = align_positions(ver)
    for i, r in enumerate(pos):
        for j, c in enumerate(pos):
            if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                continue
            f[r - 2:r + 3, c - 2:c + 3] = True
    if ver >= 7:
        f[0:6, n - 11:n - 8] = True
        f[n - 11:n - 8, 0:6] = True
    rows, cols = [], []
    c = n - 1
    up = True
    while c > 0:
        if c == 6:
            c -= 1
        rr = range(n - 1, -1, -1) if up else range(n)
        for r in rr:
            for cc in (c, c - 1):
                if not f[r][cc]:
                    rows.append(r)
                    cols.append(cc)
        up = not up
        c -= 2
    out = (np.array(rows), np.array(cols))
    _cache[ver] = out
    return out


def _mask_bits(mask, r, c):
    if mask == 0: return (r + c) % 2 == 0
    if mask == 1: return r % 2 == 0
    if mask == 2: return c % 3 == 0
    if mask == 3: return (r + c) % 3 == 0
    if mask == 4: return (r // 2 + c // 3) % 2 == 0
    if mask == 5: return (r * c) % 2 + (r * c) % 3 == 0
    if mask == 6: return ((r * c) % 2 + (r * c) % 3) % 2 == 0
    return ((r + c) % 2 + (r * c) % 3) % 2 == 0


def read_codewords(m, ver, mask):
    r, c = _order(ver)
    bits = m[r, c].astype(np.uint8) ^ _mask_bits(mask, r, c).astype(np.uint8)
    nb = len(bits) - len(bits) % 8
    return [int(v) for v in np.packbits(bits[:nb])]


def deinterleave(cw, nb, nec):
    raw = len(cw)
    short = raw // nb
    nshort = nb - raw % nb
    dlens = [short - nec + (0 if j < nshort else 1) for j in range(nb)]
    data = [[] for _ in range(nb)]
    ecc = [[] for _ in range(nb)]
    idx = 0
    for i in range(max(dlens)):
        for j in range(nb):
            if i < dlens[j]:
                data[j].append(cw[idx]); idx += 1
    for i in range(nec):
        for j in range(nb):
            ecc[j].append(cw[idx]); idx += 1
    return data, ecc


def syndromes_zero(block, nec):
    for i in range(nec):
        s = 0
        for coef in block:
            s = gmul(s, EXP[i]) ^ coef
        if s:
            return False
    return True


def parse_bytes(stream, ver):
    bits = "".join(format(b, "08b") for b in stream)
    if bits[:4] != "0100":
        return None
    cc = 8 if ver <= 9 else 16
    n = int(bits[4:4 + cc], 2)
    body = bits[4 + cc:4 + cc + 8 * n]
    if len(body) < 8 * n:
        return None
    return bytes(int(body[i:i + 8], 2) for i in range(0, 8 * n, 8))


def try_decode(m, ver, e, mask, ecc_tbl, blk_tbl):
    """Tra ve bytes neu MOI khoi cua (muc e, mat na) co syndrome 0, nguoc lai None."""
    raw = n_raw(ver) // 8
    cw = read_codewords(m, ver, mask)
    if len(cw) < raw:
        return None
    cw = cw[:raw]
    nec = ecc_tbl[e][ver]
    data, ecc = deinterleave(cw, blk_tbl[e][ver], nec)
    if not all(syndromes_zero(d + c, nec) for d, c in zip(data, ecc)):
        return None
    return parse_bytes([b for d in data for b in d], ver) or b""


def valid_combos(m, ver, ecc_tbl, blk_tbl, levels=range(4)):
    """Moi (muc_ECC_index, mat_na, bytes) ma moi khoi deu hop le - mot ma QR dung chi co DUNG 1 to hop."""
    found = []
    for e in levels:
        for mask in range(8):
            got = try_decode(m, ver, e, mask, ecc_tbl, blk_tbl)
            if got is not None:
                found.append((e, mask, got))
    return found
