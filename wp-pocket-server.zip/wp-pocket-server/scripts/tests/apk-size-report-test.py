#!/usr/bin/env python3
"""Kiem thu scripts/tools/apk_size_report.py bang APK GIA LAP (zip) co so lieu biet truoc: nhom, stored/deflated, lap trong APK, lap giua cac APK, doc zip artifact."""
import json, os, random, subprocess, sys, tempfile, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL = os.path.join(HERE, '..', 'tools', 'apk_size_report.py')
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:300]) if d else ''))


def blob(seed, n):
    r = random.Random(seed)
    return bytes(r.getrandbits(8) for _ in range(n))


def make_apk(path, entries):
    with zipfile.ZipFile(path, 'w') as z:
        for name, data, method in entries:
            z.writestr(zipfile.ZipInfo(name), data, compress_type=method)


def run(*args):
    r = subprocess.run([sys.executable, TOOL] + list(args), capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr


def main():
    tmp = tempfile.mkdtemp(prefix='apkrep-')
    S, D = zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED
    a64 = blob(1, 200000)      # "libbig.so" arm64 (khong nen duoc vi ngau nhien)
    a32 = blob(2, 120000)
    www = blob(3, 80000)
    zeros = b'\0' * 300000     # nen duoc rat manh
    common = [('assets/www.zip', www, D), ('classes.dex', blob(4, 5000), D), ('AndroidManifest.xml', b'<m/>', D)]
    arm64 = [('lib/arm64-v8a/libbig.so', a64, S), ('lib/arm64-v8a/libzero.so', zeros, S)] + common
    v7 = [('lib/armeabi-v7a/libbig.so', a32, S)] + common
    uni = [('lib/arm64-v8a/libbig.so', a64, S), ('lib/arm64-v8a/libzero.so', zeros, S), ('lib/armeabi-v7a/libbig.so', a32, S)] + common
    p1, p2, p3 = (os.path.join(tmp, n) for n in ('app-arm64-v8a-debug.apk', 'app-armeabi-v7a-debug.apk', 'app-universal-debug.apk'))
    make_apk(p1, arm64)
    make_apk(p2, v7)
    make_apk(p3, uni)
    rc, out, err = run('--json', p1, p2, p3)
    j = json.loads(out)
    byname = {r['apk']: r for r in j['apks']}
    check('doc duoc 3 APK', rc == 0 and set(byname) == {os.path.basename(p) for p in (p1, p2, p3)}, (rc, err[:200]))
    u = byname['app-universal-debug.apk']['categories']
    check('nhom theo ABI: lib/arm64-v8a va lib/armeabi-v7a tach rieng, co assets + dex', 'lib/arm64-v8a' in u and 'lib/armeabi-v7a' in u and 'assets' in u and 'dex' in u, list(u))
    check('so lieu chinh xac: lib/arm64-v8a goc = 200000 + 300000 byte, 2 muc, deu "stored"', u['lib/arm64-v8a']['raw'] == 500000 and u['lib/arm64-v8a']['n'] == 2 and u['lib/arm64-v8a']['stored'] == 2, u['lib/arm64-v8a'])
    check('assets/www.zip duoc nhan la deflated', u['assets']['deflated'] == 1 and u['assets']['stored'] == 0, u['assets'])
    # lap giua cac APK: universal lap lai arm64 (libbig + libzero + www.zip + dex) va v7a (libbig v7 + www.zip + dex)
    exp_dup = None
    sizes = {}
    for p in (p1, p2, p3):
        with zipfile.ZipFile(p) as z:
            for i in z.infolist():
                sizes[(os.path.basename(p), i.filename)] = (i.compress_size, i.file_size)
    # chi tinh muc >= 4096 byte; tinh tay theo cong thuc cua tool: moi (ten, crc, size) xuat hien o nhieu APK -> cong compress_size cua cac ban thu 2 tro di
    expect = 0
    for fn in ('lib/arm64-v8a/libbig.so', 'lib/arm64-v8a/libzero.so', 'assets/www.zip', 'classes.dex'):
        have = [sizes[(os.path.basename(p), fn)][0] for p in (p1, p2, p3) if (os.path.basename(p), fn) in sizes]
        expect += sum(have[1:])
    expect += sizes[(os.path.basename(p3), 'lib/armeabi-v7a/libbig.so')][0]   # v7a + universal
    check('LAP GIUA CAC APK tinh dung (universal lap lai 2 APK con): %d byte' % expect, j['cross_apk_duplicate'] == expect, (j['cross_apk_duplicate'], expect))
    check('phan lap giua APK chu yeu nam o nhom lib/ (dung ly do artifact nang gap doi)', j['cross_by_category'].get('lib/arm64-v8a', 0) > j['cross_by_category'].get('assets', 0), j['cross_by_category'])
    check('tong TONG = tong kich thuoc 3 tep', j['total'] == sum(os.path.getsize(p) for p in (p1, p2, p3)))
    # cung TEN nhung KHAC noi dung o 2 APK khong phai lap (nhieu build khac nhau co the trung ten tep)
    p4 = os.path.join(tmp, 'other.apk')
    make_apk(p4, [('lib/arm64-v8a/libbig.so', blob(77, 200000), S)])
    j2 = json.loads(run('--json', p1, p4)[1])
    check('cung ten khac noi dung (CRC khac) o 2 APK KHONG tinh la lap', j2['cross_apk_duplicate'] == 0, j2['cross_apk_duplicate'])
    # cung noi dung nhung KHAC ten khong phai "lap giua APK" (do la lap trong APK - xet o duoi)
    # lap trong 1 APK: cung noi dung duoi 2 ten
    dup = os.path.join(tmp, 'dup.apk')
    make_apk(dup, [('lib/arm64-v8a/libicu.so', blob(9, 50000), S), ('lib/arm64-v8a/libicu.so.75', blob(9, 50000), S), ('lib/arm64-v8a/libother.so', blob(10, 50000), S)])
    rc, out, _ = run('--json', dup)
    d = json.loads(out)['apks'][0]
    check('LAP TRONG APK: 2 ten cung noi dung duoc bat, tiet kiem = 1 ban (50000)', len(d['dups']) == 1 and set(d['dups'][0]['names']) == {'lib/arm64-v8a/libicu.so', 'lib/arm64-v8a/libicu.so.75'} and d['dup_wasted'] == 50000, d['dups'])
    # muc nho (< 4 KB) khong tinh la lap
    small = os.path.join(tmp, 'small.apk')
    make_apk(small, [('res/a.xml', b'x' * 100, D), ('res/b.xml', b'x' * 100, D)])
    d = json.loads(run('--json', small)[1])['apks'][0]
    check('muc < 4 KB cung noi dung khong bi tinh la lap (nhieu)', d['dups'] == [], d['dups'])
    # --estimate: .so stored nen duoc
    rc, out, _ = run('--json', '--estimate', p1)
    e = json.loads(out)['apks'][0]['estimate']
    check('--estimate: thay 2 tep .so dang luu khong nen; libzero (toan so 0) co the giam manh (> 250000 byte)', e['so_stored_count'] == 2 and e['saving_if_deflated_top40'] > 250000, e)
    # doc zip artifact chua nhieu .apk
    art = os.path.join(tmp, 'artifact.zip')
    with zipfile.ZipFile(art, 'w') as z:
        for p in (p1, p2, p3):
            z.write(p, os.path.basename(p))
    rc, out, _ = run('--json', art)
    check('doc ca zip artifact chua 3 .apk (nhu tai tu GitHub Actions)', rc == 0 and len(json.loads(out)['apks']) == 3 and json.loads(out)['cross_apk_duplicate'] == expect)
    rc, out, _ = run(p1, p2, p3)
    check('bao cao chu co dong "LAP GIUA CAC APK" va ten tung APK', rc == 0 and 'LAP GIUA CAC APK' in out and 'app-universal-debug.apk' in out and 'lib/arm64-v8a' in out, out[:200])
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
