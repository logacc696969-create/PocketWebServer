#!/usr/bin/env python3
"""S8 (HANDOFF.md muc 1bp-K): baseline-prof.txt hop le va khop ma nguon; phu thuoc profileinstaller; co doi chung am."""
import os, subprocess, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "tools"))
import baseline_prof_check as bp
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
rd = lambda p: open(os.path.join(ROOT, p), encoding="utf-8").read()
txt = rd("app/src/main/baseline-prof.txt"); lines = txt.rstrip("\n").split("\n")
check("baseline-prof.txt dung vi tri chuan AGP (app/src/main/baseline-prof.txt) va khong rong", len(lines) >= 5)
errs = bp.check(lines)
check("moi quy tac hop cu phap va KHOP ma nguon (lop co that, ham co that voi dung kieu JVM): %s" % errs, errs == [])
check("co quy tac ham startup (HSP) cho MainActivity.onCreate va ServerForegroundService.onCreate/onStartCommand",
      "HSPLcom/wppocket/server/MainActivity;->onCreate(Landroid/os/Bundle;)V" in lines and "HSPLcom/wppocket/server/ServerForegroundService;->onStartCommand(Landroid/content/Intent;II)I" in lines)
check("DOI CHUNG AM: kieu JVM sai (onCreate(I)V) bi bat", bp.check(["HSPLcom/wppocket/server/MainActivity;->onCreate(I)V"]) != [])
check("DOI CHUNG AM: lop khong ton tai bi bat", bp.check(["Lcom/wppocket/server/KhongCoLopNay;"]) != [])
check("DOI CHUNG AM: ham khong ton tai (MainActivity.onResume khong duoc override) bi bat", bp.check(["HSPLcom/wppocket/server/MainActivity;->onResume()V"]) != [])
check("DOI CHUNG AM: chu thich '#', dong trong, ky tu thay the, sai cu phap deu bi tu choi", all(bp.check([x]) != [] for x in ["# ghi chu", "", "Lcom/wppocket/**;", "HSPLcom/wppocket/server/MainActivity", "xyz"]))
check("DOI CHUNG AM: lop ViewBinding khong co layout tuong ung bi bat", bp.check(["Lcom/wppocket/server/databinding/KhongCoBinding;"]) != [])
check("moi lop trong profile thuoc goi com.wppocket.server (khong lo quy tac cua ben thu ba)", all(l.lstrip("HSP").startswith("Lcom/wppocket/server/") for l in lines))
g = rd("app/build.gradle.kts")
check("build.gradle.kts khai bao androidx.profileinstaller voi phien ban CU THE (khong dong/khong '+')", 'implementation("androidx.profileinstaller:profileinstaller:1.3.1")' in g and "profileinstaller:+" not in g)
check("THIRD_PARTY_NOTICES.md nhac profileinstaller (chuoi cung ung minh bach)", "profileinstaller" in rd("THIRD_PARTY_NOTICES.md"))
r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts/tools/baseline_prof_check.py")], capture_output=True, text=True)
check("CLI baseline_prof_check.py thoat 0 tren tep that", r.returncode == 0, r.stderr)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
