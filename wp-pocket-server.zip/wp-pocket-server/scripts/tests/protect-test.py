#!/usr/bin/env python3
"""Kiem thu _admin/protect.php + luat IP trong admin-auth.php bang PHP THAT (HANDOFF.md muc 1bl; PDF 2 G7/C10/R19/R20).
Trong tam: luat IP KHONG BAO GIO tu khoa nguoi dung luc luu (allow thieu IP cua minh / deny co IP cua minh => tu choi, khong ghi file),
file luat hong/rong khong khoa ai (fail-open co chu dich), go file luat (viec nut Kotlin "Xoa luat IP _admin" lam) khoi phuc truy cap NGAY,
luat ap dung cho MOI trang _admin (ke ca form dang nhap), CIDR/IPv6 khop dung, CSRF sai khong doi gi, moi thao tac vao audit.
Thieu php -> bo qua (exit 0)."""
import importlib.util, json, os, re, shutil, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
AUTH = os.path.join(ROOT, 'scripts', 'runtimes', 'templates', 'admin-auth.php')
PAGE = os.environ.get('PROTECT_PAGE') or os.path.join(ROOT, 'scripts', 'runtimes', 'templates', 'admin-protect.php')
ME, OTHER, FAR = '192.168.1.30', '192.168.1.31', '192.168.2.5'


def extract_fn(src, name):
    i = src.index('function ' + name)
    j = src.index('{', i)
    depth = 0
    for k in range(j, len(src)):
        if src[k] == '{': depth += 1
        elif src[k] == '}':
            depth -= 1
            if depth == 0:
                return src[i:k + 1]
    raise ValueError(name)


def php_unit():
    """Chay ham wp_pocket_ip_matches TRICH NGUYEN VAN tu auth.php (khong chep lai) bang php CLI."""
    fn = extract_fn(open(AUTH, encoding='utf8').read(), 'wp_pocket_ip_matches')
    cases = [
        ('192.168.1.5', ['192.168.1.5'], True), ('192.168.1.5', ['192.168.1.6'], False),
        ('192.168.1.5', ['192.168.1.0/24'], True), ('192.168.2.5', ['192.168.1.0/24'], False),
        ('10.1.2.3', ['10.0.0.0/8'], True), ('11.1.2.3', ['10.0.0.0/8'], False),
        ('192.168.1.5', ['192.168.1.5/32'], True), ('192.168.1.6', ['192.168.1.5/32'], False),
        ('8.8.8.8', ['0.0.0.0/0'], True),                                  # /0 khop tat ca
        ('192.168.1.5', ['192.168.1.0/33'], False), ('192.168.1.5', ['192.168.1.0/-1'], False), ('192.168.1.5', ['192.168.1.0/ab'], False),
        ('192.168.1.5', ['rac', '', '999.1.1.1', '192.168.1.0/'], False),   # muc hong bi bo qua, khong nem loi
        ('192.168.1.5', ['rac', '192.168.1.5'], True),                      # muc hong khong chan muc dung ke sau
        ('192.168.1.5', [], False), ('khong-phai-ip', ['192.168.1.5'], False), ('', ['192.168.1.5'], False),
        ('fd00::1', ['fd00:0:0:0:0:0:0:1'], True),                           # IPv6: khac dang viet, cung dia chi
        ('fd00::1', ['fd00::2'], False), ('fd00::1', ['192.168.1.5'], False), ('192.168.1.5', ['fd00::1'], False),
        ('192.168.1.5', [' 192.168.1.5 '], True),                            # trim khoang trang
    ]
    harness = '<?php\n' + fn + '\n$ok=0;$bad=[];\n$cases = json_decode(file_get_contents($argv[1]), true);\n' \
        'foreach ($cases as $i => $c) { if (wp_pocket_ip_matches($c[0], $c[1]) === $c[2]) $ok++; else $bad[] = $i; }\n' \
        'echo json_encode(["ok"=>$ok,"bad"=>$bad]);\n'
    d = tempfile.mkdtemp(prefix='ipm-')
    try:
        open(d + '/h.php', 'w').write(harness)
        json.dump(cases + [('192.168.1.5', [123, None, ['x']], False)], open(d + '/c.json', 'w'))   # muc khong phai chuoi: bo qua
        r = subprocess.run(['php', '-d', 'display_errors=1', d + '/h.php', d + '/c.json'], capture_output=True, text=True)
        try:
            res = json.loads(r.stdout)
        except Exception:
            res = {'ok': -1, 'bad': ['loi: ' + (r.stdout + r.stderr)[:200]]}
        check('wp_pocket_ip_matches (trich nguyen van tu auth.php): %d truong hop IPv4/CIDR/IPv6/muc hong' % (len(cases) + 1),
              res['ok'] == len(cases) + 1 and not res['bad'], res)
    finally:
        shutil.rmtree(d, ignore_errors=True)


def main():
    if not shutil.which('php'):
        print('(bo qua: khong co php)'); return 0
    tmp = tempfile.mkdtemp(prefix='protect-'); srv = None
    try:
        os.chmod(tmp, 0o755)
        print('== 0. ham khop IP (php CLI) ==')
        php_unit()
        app, run, www, adm = sec.build_tree(tmp)
        shutil.copy(PAGE, os.path.join(adm, 'protect.php'))
        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
                                '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=1', '-d', 'error_reporting=E_ALL'],
                               env=dict(os.environ, APP_HOME=app, EXT_DIR=os.path.join(tmp, 'ext')), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        rate, bots, rules = [os.path.join(run, n) for n in ('rate-limit-on', 'block-bots-on', 'admin-ip-rules.json')]
        audit = os.path.join(run, 'admin-audit.log')
        def log(): return open(audit, encoding='utf-8').read() if os.path.exists(audit) else ''
        def clean(b, n): check(n + ': khong Fatal/Warning/Notice/Deprecated', not sec.FATAL_RE.search(b) and not sec.WARN_RE.search(b))

        me = sec.Client(port, ME); check('dang nhap (IP %s)' % ME, me.login())
        sc, b, _ = me.req('GET', '/_admin/protect.php')
        check('GET protect.php: 200 + 3 khoi, mac dinh deu TAT', sc == 200 and 'Bao ve site' in b and b.count('>TAT<') == 3, sc); clean(b, 'GET')
        check('khong dang nhap -> form dang nhap, khong lo trang', 'Gioi han toc do' not in sec.Client(port, OTHER).req('GET', '/_admin/protect.php')[1])
        check('IP ngoai LAN -> 403', sec.Client(port, '8.8.8.8').req('GET', '/_admin/protect.php')[0] == 403)

        print('== 1. co gioi han toc do / chan bot ==')
        def post(c, data, page='protect'):
            t = c.token(page); d = dict(data); d['csrf_token'] = t
            return c.req('POST', '/_admin/%s.php' % page, d)
        sc, b, _ = post(me, {'action': 'rate_on'})
        check('rate_on: tao lamp-run/rate-limit-on, trang bao DA BAT', os.path.exists(rate) and 'DANG BAT' in b); clean(b, 'rate_on')
        post(me, {'action': 'bots_on'}); check('bots_on: tao block-bots-on', os.path.exists(bots))
        post(me, {'action': 'rate_off'}); post(me, {'action': 'bots_off'})
        check('rate_off + bots_off: xoa ca hai co', not os.path.exists(rate) and not os.path.exists(bots))
        post(me, {'action': 'rate_off'}); check('tat khi co da khong ton tai: khong loi', True)
        before = (os.path.exists(rate), os.path.exists(bots))
        me.req('POST', '/_admin/protect.php', {'action': 'rate_on', 'csrf_token': 'x' * 64})
        me.req('POST', '/_admin/protect.php', {'action': 'rate_on'})
        check('CSRF sai/thieu: KHONG doi gi', (os.path.exists(rate), os.path.exists(bots)) == before)
        sc, b, _ = post(me, {'action': 'khong-co-action'}); check('action la: bao loi, khong doi gi, khong Fatal', 'khong hop le' in b and not os.path.exists(rate)); clean(b, 'action la')
        sc, b, _ = me.req('POST', '/_admin/protect.php', {'action[]': 'x', 'csrf_token': me.token('protect')}); clean(b, 'action dang mang')
        check('audit ghi thao tac protect', re.search(r'ip=%s thao tac protect\.php action=rate_on' % re.escape(ME), log()) is not None and 'action=bots_off' in log())

        print('== 2. luat IP: tu choi truoc khi tu khoa minh ==')
        sc, b, _ = post(me, {'action': 'ip_save', 'mode': 'allow', 'entries': '192.168.1.99'})
        check('allow KHONG chua IP cua minh -> TU CHOI (khong ghi file), thong bao nhac "KHOA CHINH BAN"', not os.path.exists(rules) and 'KHOA CHINH BAN' in b)
        sc, b, _ = post(me, {'action': 'ip_save', 'mode': 'allow', 'entries': ''})
        check('allow danh sach rong -> TU CHOI (se khoa tat ca)', not os.path.exists(rules))
        sc, b, _ = post(me, {'action': 'ip_save', 'mode': 'deny', 'entries': '%s\n10.0.0.1' % ME})
        check('deny CO IP cua minh -> TU CHOI', not os.path.exists(rules) and 'khoa chinh ban' in b)
        for bad in ('abc', '1.2.3.4/33', '1.2.3/24', '999.1.1.1', '1.2.3.4/-1', '::1/64'):
            post(me, {'action': 'ip_save', 'mode': 'deny', 'entries': '10.0.0.1\n' + bad})
            if os.path.exists(rules): check('muc khong hop le "%s" phai bi tu choi' % bad, False); os.remove(rules)
        check('muc sai (abc, /33, thieu octet, IP>255, /-1, CIDR IPv6) deu tu choi, khong ghi gi', not os.path.exists(rules))
        post(me, {'action': 'ip_save', 'mode': 'deny', 'entries': '\n'.join('10.0.%d.1' % i for i in range(51))})
        check('> 50 muc -> tu choi', not os.path.exists(rules))
        post(me, {'action': 'ip_save', 'mode': 'weird', 'entries': '10.0.0.1'}); check('che do la -> tu choi', not os.path.exists(rules))
        sc, b, _ = post(me, {'action': 'ip_save', 'mode': 'deny', 'entries[]': '10.0.0.1'}); check('entries dang mang (entries[]=...) -> khong Fatal/Warning, khong ghi', not os.path.exists(rules)); clean(b, 'entries dang mang')
        post(me, {'action': 'ip_save', 'mode': 'deny', 'entries': '# chi co ghi chu'}); check('deny khong co muc nao -> tu choi (khong ghi file vo nghia)', not os.path.exists(rules))

        print('== 3. luat IP hop le: allow ==')
        sc, b, _ = post(me, {'action': 'ip_save', 'mode': 'allow', 'entries': '# ghi chu\n%s  # may cua toi\n192.168.1.99' % ME}); clean(b, 'ip_save allow')
        d = json.load(open(rules)) if os.path.exists(rules) else {}
        check('luu: file JSON mode=allow, entries da chuan hoa + bo ghi chu', d == {'mode': 'allow', 'entries': [ME, '192.168.1.99']}, d)
        check('khong de lai file .tmp (ghi nguyen tu)', not os.path.exists(rules + '.tmp'))
        sc, b, _ = me.req('GET', '/_admin/protect.php')
        check('IP trong allowlist van vao duoc', sc == 200 and 'CHI CHO PHEP' in b)
        oth = sec.Client(port, OTHER)
        sc, b, _ = oth.req('GET', '/_admin/index.php')
        check('IP KHAC (cung LAN, khong trong allowlist) -> 403 ngay ca o form dang nhap, khong lo gi', sc == 403 and 'chan boi luat IP' in b and 'admin_password' not in b, sc)
        check('luat ap dung cho MOI trang (maintenance, health, db.php... deu 403)', all(oth.req('GET', '/_admin/%s.php' % n)[0] == 403 for n in ('maintenance', 'sessions', 'protect')))
        check('IP bi chan khong dang nhap duoc (POST mat khau dung -> 403)', oth.req('POST', '/_admin/index.php', {'admin_password': sec.PASSWORD})[0] == 403)
        check('audit ghi su kien chan', 'chan theo luat IP (allow)' in log() and 'ip=%s' % OTHER in log())
        check('IP ngoai LAN van bi chan boi kiem tra LAN (khong bi luat IP lam hong)', sec.Client(port, '8.8.8.8').req('GET', '/_admin/index.php')[0] == 403)

        print('== 4. khoi phuc: go file luat (viec nut Kotlin "Xoa luat IP _admin" lam) ==')
        os.remove(rules)
        sc, b, _ = oth.req('GET', '/_admin/index.php')
        check('xoa file luat -> IP truoc do bi chan vao lai duoc NGAY (khong cache)', sc == 200 and 'admin_password' in b, sc)

        check('dang nhap IP %s (de kiem phien song sot o muc 7)' % OTHER, oth.login())
        print('== 5. CIDR va deny ==')
        post(me, {'action': 'ip_save', 'mode': 'allow', 'entries': '192.168.1.0/24'})
        check('allow 192.168.1.0/24: .30 va .31 vao duoc, 192.168.2.5 (LAN khac) bi chan',
              me.req('GET', '/_admin/protect.php')[0] == 200 and oth.req('GET', '/_admin/index.php')[0] == 200 and sec.Client(port, FAR).req('GET', '/_admin/index.php')[0] == 403)
        post(me, {'action': 'ip_save', 'mode': 'deny', 'entries': '%s\n10.9.9.9' % OTHER})
        check('deny: chi IP trong danh sach bi chan (.31 bi, .30 va 192.168.2.5 vao duoc)',
              oth.req('GET', '/_admin/index.php')[0] == 403 and me.req('GET', '/_admin/protect.php')[0] == 200 and sec.Client(port, FAR).req('GET', '/_admin/index.php')[0] == 200)
        post(me, {'action': 'ip_save', 'mode': 'off', 'entries': ''})
        check('mode off: xoa file luat, moi IP trong LAN vao lai duoc', not os.path.exists(rules) and oth.req('GET', '/_admin/index.php')[0] == 200)

        print('== 6. file luat hong/bat thuong KHONG khoa ai (fail-open) ==')
        for name, content in (('JSON rac', '{khong phai json'), ('mode la', '{"mode":"block","entries":["192.168.1.30"]}'), ('entries sai kieu', '{"mode":"allow","entries":"192.168.1.30"}'),
                              ('allow rong (khong the la y dinh)', '{"mode":"allow","entries":[]}'), ('file rong', '')):
            open(rules, 'w').write(content)
            check('%s -> coi nhu TAT, IP bat ky trong LAN vao duoc' % name, oth.req('GET', '/_admin/index.php')[0] == 200 and sec.Client(port, FAR).req('GET', '/_admin/index.php')[0] == 200)
        os.remove(rules)

        print('== 7. phien dang dung khong "song sot" qua luat moi ==')
        post(me, {'action': 'ip_save', 'mode': 'allow', 'entries': ME})
        sc, b, _ = oth.req('GET', '/_admin/protect.php')
        check('phien cua IP bi chan (dang nhap truoc do) cung bi chan ngay, khong can dang nhap lai', sc == 403)
        os.remove(rules)
    finally:
        if srv:
            srv.terminate()
            try: srv.wait(timeout=10)
            except Exception: srv.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL))
    return 0 if sec.FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
