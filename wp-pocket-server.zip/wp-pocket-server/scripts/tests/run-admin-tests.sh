#!/bin/sh
# Chay bo test bao mat _admin/ bang PHP that, roi (neu co kotlinc) doi chieu file
# audit do PHP ghi voi bo phan tich Kotlin (hop dong PHP<->Kotlin). Xem HANDOFF.md muc 1av.
# Can: php, python3. Tuy chon: kotlinc + kotlin (de chay hop dong).
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
export ADMIN_TEST_OUT="$OUT"
python3 "$HERE/admin-security-test.py" || { rm -rf "$OUT"; exit 1; }
if command -v kotlinc >/dev/null 2>&1 && command -v kotlin >/dev/null 2>&1; then
  echo; echo "== Hop dong PHP -> Kotlin (audit log) =="
  F=$(python3 -c "import json,sys;d=json.load(open('$OUT/contract.json'));print(d['failures'],d['lockouts'])")
  kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/MonitorLogic.kt" "$HERE/../../app/src/main/java/com/wppocket/server/AlertThresholds.kt" "$HERE/AuditContractTest.kt" -d "$OUT/k" \
    && kotlin -cp "$OUT/k" AuditContractTestKt "$OUT/admin-audit.log" $F
  rc=$?
else
  echo; echo "(bo qua hop dong PHP->Kotlin: khong co kotlinc/kotlin)"; rc=0
fi
rm -rf "$OUT"; exit $rc
