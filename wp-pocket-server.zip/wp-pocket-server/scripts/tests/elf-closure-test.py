#!/usr/bin/env python3
"""Kiem thu parser ELF (elf_needed.py) va check-runtime-closure.py bang ELF THAT cua may + ELF tu dung (khong can Termux/Android). HANDOFF.md muc 1bi."""
import os, shutil, struct, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.normpath(os.path.join(HERE, '..', 'tools'))
sys.path.insert(0, TOOLS)
import elf_needed, importlib.util
spec = importlib.util.spec_from_file_location('closure', os.path.join(TOOLS, 'check-runtime-closure.py')); closure = importlib.util.module_from_spec(spec); spec.loader.exec_module(closure)
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:200]) if d else ''))

def make_elf(path, needed, soname=None, bits=64, endian='<'):
    """ELF dong toi thieu: header + 1 PT_LOAD phu het file + 1 PT_DYNAMIC + dynstr + dynamic (DT_NEEDED..., DT_SONAME, DT_STRTAB)."""
    strs = b'\0'; idx = {}
    for n in list(needed) + ([soname] if soname else []):
        idx[n] = len(strs); strs += n.encode() + b'\0'
    ents = [(1, idx[n]) for n in needed] + ([(14, idx[soname])] if soname else [])
    eh, ph, dsz = (64, 56, 16) if bits == 64 else (52, 32, 8)
    dyn_off = eh + 2 * ph; nd = len(ents) + 2           # + DT_STRTAB + DT_NULL
    str_off = dyn_off + nd * dsz; total = str_off + len(strs)
    e = endian; w = 'Q' if bits == 64 else 'I'
    if bits == 64:
        hdr = b'\x7fELF' + bytes([2, 1 if e == '<' else 2, 1, 0]) + b'\0' * 8 + struct.pack(e + 'HHIQQQIHHHHHH', 3, 183, 1, 0, eh, 0, 0, eh, ph, 2, 0, 0, 0)
        phs = struct.pack(e + 'IIQQQQQQ', 1, 5, 0, 0, 0, total, total, 0x1000) + struct.pack(e + 'IIQQQQQQ', 2, 6, dyn_off, dyn_off, dyn_off, nd * dsz, nd * dsz, 8)
        dyn = b''.join(struct.pack(e + 'qQ', t, v) for t, v in ents) + struct.pack(e + 'qQ', 5, str_off) + struct.pack(e + 'qQ', 0, 0)
    else:
        hdr = b'\x7fELF' + bytes([1, 1 if e == '<' else 2, 1, 0]) + b'\0' * 8 + struct.pack(e + 'HHIIIIIHHHHHH', 3, 40, 1, 0, eh, 0, 0, eh, ph, 2, 0, 0, 0)
        phs = struct.pack(e + 'IIIIIIII', 1, 0, 0, 0, total, total, 5, 0x1000) + struct.pack(e + 'IIIIIIII', 2, dyn_off, dyn_off, dyn_off, nd * dsz, nd * dsz, 6, 4)
        dyn = b''.join(struct.pack(e + 'iI', t, v) for t, v in ents) + struct.pack(e + 'iI', 5, str_off) + struct.pack(e + 'iI', 0, 0)
    open(path, 'wb').write(hdr + phs + dyn + strs)

def main():
    print('== A. Parser tren ELF THAT cua may ==')
    real = next((p for p in ('/bin/ls', '/usr/bin/ls', '/bin/sh') if os.path.exists(p)), None)
    if real:
        r = elf_needed.parse(real)
        check('ELF that (%s): doc duoc NEEDED, co libc' % real, any(n.startswith('libc.') for n in r['needed']), r)
        rd = shutil.which('readelf')
        if rd:
            out = subprocess.run([rd, '-d', real], capture_output=True, text=True).stdout
            ref = [l.split('[')[1].rstrip(']') for l in out.split('\n') if '(NEEDED)' in l]
            check('khop voi readelf -d', ref == r['needed'], (ref, r['needed']))
    print('== B. Parser tren ELF tu dung (64/32 bit, little/big endian) ==')
    tmp = tempfile.mkdtemp(prefix='elf-')
    try:
        for bits in (64, 32):
            for e in ('<', '>'):
                p = os.path.join(tmp, 'x.so'); make_elf(p, ['libz.so.1', 'libc.so', 'libssl.so.3'], soname='libx.so.7', bits=bits, endian=e)
                r = elf_needed.parse(p)
                check('ELF%d %s endian: NEEDED va SONAME dung' % (bits, 'little' if e == '<' else 'big'), r['needed'] == ['libz.so.1', 'libc.so', 'libssl.so.3'] and r['soname'] == 'libx.so.7' and r['bits'] == bits, r)
        open(os.path.join(tmp, 'text.so'), 'w').write('#!/system/bin/sh\necho hi\n')
        try: elf_needed.parse(os.path.join(tmp, 'text.so')); ok = False
        except ValueError: ok = True
        check('file khong phai ELF (script) -> ValueError', ok)

        print('== C. check-runtime-closure ==')
        out = os.path.join(tmp, 'out'); os.makedirs(out)
        make_elf(os.path.join(out, 'libnginx.so'), ['libc.so', 'libm.so', 'libpcre2-8.so.0', 'libssl.so.3', 'libz.so.1'])
        make_elf(os.path.join(out, 'libpcre2-8_so_0.so'), ['libc.so'])
        make_elf(os.path.join(out, 'libssl_so_3.so'), ['libc.so', 'libcrypto.so.3'])
        make_elf(os.path.join(out, 'libcrypto_so_3.so'), ['libc.so'])
        make_elf(os.path.join(out, 'libz_so_1.so'), ['libc.so'])
        open(os.path.join(out, 'soname-map.txt'), 'w').write('libpcre2-8.so.0 libpcre2-8_so_0.so\nlibssl.so.3 libssl_so_3.so\nlibcrypto.so.3 libcrypto_so_3.so\nlibz.so.1 libz_so_1.so\n')
        n, probs = closure.check(out)
        check('DU: moi NEEDED thoa qua he thong / file cung ten / soname-map (5 file ELF, 0 thieu)', n == 5 and not probs, (n, probs))
        os.remove(os.path.join(out, 'libcrypto_so_3.so'))
        n, probs = closure.check(out)
        check('DOI CHUNG: xoa libcrypto_so_3.so -> bao THIEU libcrypto.so.3 (soname-map tro toi file khong co)', any(p[0] == 'libssl_so_3.so' and p[1] == 'libcrypto.so.3' for p in probs), probs)
        make_elf(os.path.join(out, 'libcrypto_so_3.so'), ['libc.so'])
        open(os.path.join(out, 'soname-map.txt'), 'w').write('libpcre2-8.so.0 libpcre2-8_so_0.so\nlibssl.so.3 libssl_so_3.so\nlibcrypto.so.3 libcrypto_so_3.so\n')
        n, probs = closure.check(out)
        check('DOI CHUNG: thieu dong soname-map cua libz.so.1 -> bao THIEU (loi that "library libz.so.1 not found")', [(p[0], p[1]) for p in probs] == [('libnginx.so', 'libz.so.1')], probs)
        n, probs = closure.check(out, extra_allow=['libz.so.1'])
        check('--allow cho phep bo qua 1 ten cu the', not probs, probs)
        make_elf(os.path.join(out, 'libextra.so'), ['libc++_shared.so'])
        n, probs = closure.check(out, extra_allow=['libz.so.1'])
        check('libc++_shared.so KHONG nam trong danh sach he thong -> phai tu dong goi (bi bao thieu neu quen)', [(p[0], p[1]) for p in probs] == [('libextra.so', 'libc++_shared.so')], probs)
        r = subprocess.run([sys.executable, os.path.join(TOOLS, 'check-runtime-closure.py'), out], capture_output=True, text=True)
        check('CLI: thoat 1 khi thieu, in dong THIEU', r.returncode == 1 and 'THIEU: libnginx.so can libz.so.1' in r.stdout, (r.returncode, r.stdout))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
