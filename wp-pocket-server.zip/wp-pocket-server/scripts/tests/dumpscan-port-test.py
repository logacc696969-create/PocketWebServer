#!/usr/bin/env python3
"""Ban PORT Python 1-1 cua BackupLogic.DumpScanner (H1, HANDOFF 1bl) + chay cung bo vector voi BackupLogicTest.kt - kiem thuat toan
quet dump THEO LUONG khi khong co kotlinc (JVM test that chay o CI). Them: moi cach cat 2 khoi, cat 3 khoi, khoi 1-17 byte."""
import os, re, sys, itertools
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
PASS = FAIL = 0
def ok(c, n):
    global PASS, FAIL
    if c: PASS += 1; print('  OK  ', n)
    else: FAIL += 1; print('  FAIL', n)

CARRY = 300
CREATE = re.compile(r'CREATE TABLE (?:IF NOT EXISTS )?`([^`\r\n]{1,64})`')
INSERT = re.compile(r'INSERT INTO `[^`\r\n]{0,60}options`')
class Scanner:
    def __init__(self): self.tables = set(); self.opt = False; self.carry = ''
    def feed(self, b):
        if not b: return
        text = self.carry + b.decode('latin-1')
        for m in CREATE.finditer(text): self.tables.add(m.group(1))
        if not self.opt and INSERT.search(text): self.opt = True
        self.carry = text[-CARRY:] if len(text) > CARRY else text
    def wp(self):
        return any(t.endswith('options') for t in self.tables) and any(t.endswith('posts') for t in self.tables) and self.opt

DUMP_WP = ("-- MariaDB dump 10.19\nCREATE TABLE `wp_options` (id int);\nCREATE TABLE `wp_posts` (id int);\n"
           "INSERT INTO `wp_options` VALUES (1,'siteurl','x','yes');\n-- Dump completed on 2026-10-11  3:00:00\n").encode()
DUMP_OK = ("-- MariaDB dump 10.19\nCREATE TABLE `wp_options` (id int);\n"
           "INSERT INTO `wp_options` VALUES (1,'siteurl','https://abc-def.trycloudflare.com','yes');\n-- Dump completed on 2026-10-11  3:00:00\n").encode()

def run(chunks):
    s = Scanner()
    for c in chunks: s.feed(c)
    return s
ok(run([DUMP_WP]).wp(), 'dump WP day du -> nhan dien WordPress')
ok(not run([DUMP_OK]).wp(), 'dump chi co options (thieu posts) -> KHONG phai WordPress')
ok(not run([DUMP_WP.replace(b'INSERT INTO', b'-- skip')]).wp(), 'co bang nhung khong co du lieu options -> khong')
ok(run([DUMP_WP.replace(b'wp_', b'abc_')]).wp(), 'tien to tuy y abc_ van nhan')
ok(not Scanner().wp(), 'chua nap gi -> khong')
ok(all(run([DUMP_WP[:c], DUMP_WP[c:]]).wp() and run([DUMP_WP[:c], DUMP_WP[c:]]).tables == {'wp_options', 'wp_posts'} for c in range(1, len(DUMP_WP))), 'cat 2 khoi o MOI vi tri (%d cach)' % (len(DUMP_WP) - 1))
n3 = 0; bad3 = 0
for a in range(1, len(DUMP_WP), 3):
    for b in range(a + 1, len(DUMP_WP), 3):
        n3 += 1
        if not run([DUMP_WP[:a], DUMP_WP[a:b], DUMP_WP[b:]]).wp(): bad3 += 1
ok(bad3 == 0, 'cat 3 khoi (%d to hop) deu dung' % n3)
ok(all(run([DUMP_WP[i:i + k] for i in range(0, len(DUMP_WP), k)]).wp() for k in range(1, 18)), 'khoi nho 1..17 byte deu dung')
big = b'x' * 70000 + DUMP_WP + b'y' * 70000
ok(run([big[i:i + 65536] for i in range(0, len(big), 65536)]).wp(), 'dump lon, khoi 64KB nhu thuc te, mau nam giua nhieu khoi')
ok(run([b'\xff\xfe\x00' * 10 + DUMP_WP]).wp(), 'byte rac (UTF-8 hong) khong lam hong viec quet (ISO-8859-1)')
# ten bang dai >64 ky tu khong khop (tranh quet vo han / khop sai)
ok('x' * 65 not in ''.join(run([b'CREATE TABLE `' + b'x' * 65 + b'` (a int);']).tables), 'ten bang > 64 ky tu bi bo qua')
# doi chieu van ban voi Kotlin that
kt = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/BackupLogic.kt'), encoding='utf8').read()
ok('const val CARRY = 300' in kt, 'Kotlin CARRY = 300')
ok('CREATE TABLE (?:IF NOT EXISTS )?`([^`\\\\r\\\\n]{1,64})`' in kt and 'INSERT INTO `[^`\\\\r\\\\n]{0,60}options`' in kt, 'Kotlin dung cung 2 regex voi ban port')
ok('Charsets.ISO_8859_1' in kt and 'scanner?.feed(buf, n)' in kt, 'Kotlin doc ISO-8859-1 va nap dung khoi vao scanner trong inspect')
print('TONG KET: pass=%d fail=%d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
