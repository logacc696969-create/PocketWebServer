#!/usr/bin/env python3
"""Kiem thu ung dung PHP KHONG phai WordPress tren stack THAT (HANDOFF.md muc 1bb): nginx + php-fpm + MariaDB, render tu template
THAT theo danh sach sed trich tu start-lamp.sh, doan SQL khoi tao CSDL THAT cua start-lamp.sh, ho so site do scripts/lib/site_profile.sh
ghi, _admin/ do prepare_admin_tools THAT trien khai.

Ung dung mau co cau truc kieu Laravel/Symfony/Slim: bo dieu khien truoc public/index.php, con .env / composer.json / vendor / storage nam
NGOAI web root. Kiem tra: web root la public/; file bi mat KHONG truy cap duoc; URL "dep" roi ve front controller; bien moi truong
DB_* dung duoc voi ket noi MariaDB that (khong can sua file cau hinh cua ung dung); tai khoan CSDL chi co quyen tren DB cua no;
_admin/ nam trong web root va khong co trang WordPress.

GENERIC_NO_DOCROOT=1: mo phong hanh vi CU (web root = goc du an) de DOI CHUNG AM - cac kiem tra co lap file bi mat phai DO.
Can: nginx, php-fpm, MariaDB, jq (nhu fullstack-realwp-test.py). Thieu -> bo qua (exit 0). Khong can WordPress.
"""
import gzip, importlib.util, json, os, re, shutil, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
sys.path.insert(0, HERE)
import lamp_render as lr

def load(name, fname):
    spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, fname)); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
rw = load('rw', 'staging-realwp-test.py')
fs = load('fs', 'fullstack-realwp-test.py')
req = fs.req

PASS = FAIL = 0
def check(name, cond, detail=''):
    global PASS, FAIL
    if cond: PASS += 1; print('PASS:', name)
    else: FAIL += 1; print('FAIL:', name, ('  -> ' + str(detail)[:240]) if detail != '' else '')

APP = r"""<?php
// Bo dieu khien truoc kieu Laravel/Symfony/Slim: moi duong dan khong phai file roi ve day (nginx try_files).
header('Content-Type: application/json; charset=utf-8');
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$keys = ['DB_CONNECTION', 'DB_HOST', 'DB_SOCKET', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'];
if ($path === '/db') {
    // Chi dung bien moi truong - nhu Laravel config/database.php
    $m = new mysqli(getenv('DB_HOST'), getenv('DB_USERNAME'), getenv('DB_PASSWORD'), getenv('DB_DATABASE'), null, getenv('DB_SOCKET'));
    $m->set_charset('utf8mb4');
    $m->query('CREATE TABLE IF NOT EXISTS notes (id INT AUTO_INCREMENT PRIMARY KEY, v VARCHAR(200)) CHARACTER SET utf8mb4');
    $st = $m->prepare('INSERT INTO notes (v) VALUES (?)'); $v = 'Tiếng Việt có dấu 😀'; $st->bind_param('s', $v); $st->execute();
    $r = $m->query('SELECT v, DATABASE() AS d FROM notes ORDER BY id DESC LIMIT 1')->fetch_assoc();
    echo json_encode(['db' => $r['d'], 'v' => $r['v']], JSON_UNESCAPED_UNICODE); exit;
}
$env = []; foreach ($keys as $k) { $env[$k] = getenv($k); }
echo json_encode(['docroot' => $_SERVER['DOCUMENT_ROOT'], 'uri' => $_SERVER['REQUEST_URI'], 'script' => $_SERVER['SCRIPT_NAME'], 'env' => $env], JSON_UNESCAPED_UNICODE);
"""

def main():
    nginx = rw.which('nginx'); fpm = rw.which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    mariadbd = rw.which('mariadbd', 'mysqld'); install = rw.which('mariadb-install-db', 'mysql_install_db'); cli = rw.which('mariadb', 'mysql')
    if not all((nginx, fpm, mariadbd, install, cli, rw.which('php'), rw.which('bash'), rw.which('jq'))):
        print('(bo qua: thieu nginx/php-fpm/MariaDB/jq)'); return 0
    no_docroot = os.environ.get('GENERIC_NO_DOCROOT') == '1'
    tmp = tempfile.mkdtemp(prefix='generic-php-'); os.chmod(tmp, 0o755)
    procs = []; db = None
    try:
        app = os.path.join(tmp, 'app'); www = os.path.join(app, 'www'); run = os.path.join(app, 'lamp-run'); pub = os.path.join(www, 'public')
        os.makedirs(os.path.join(run, 'php-sessions'))
        for rel, content in (('composer.json', '{"name":"x/y","note":"SECRET-COMPOSER"}'), ('.env', 'APP_KEY=SECRET-ENV-KEY\n'), ('storage/secret.txt', 'SECRET-STORAGE'),
                             ('vendor/autoload.php', '<?php // SECRET-VENDOR'), ('public/index.php', APP), ('public/.env', 'SECRET-PUBLIC-ENV\n'),
                             ('public/assets/app.css', 'body { color: #123456; }\n' * 40), ('artisan', '#!/usr/bin/env php\n<?php // SECRET-ARTISAN')):
            rw.wr(os.path.join(www, rel), content)

        # ---- ho so site: DUNG ham that cua du an (docroot/profile/db_name tu site.config.json)
        cfg = os.path.join(tmp, 'site.config.json'); rw.wr(cfg, json.dumps({'runtime': 'php', 'docroot': 'public', 'profile': 'auto', 'db_name': '', 'site_source': {'type': 'git'}}))
        env = dict(os.environ, SITE_CONFIG=cfg)
        sh = lambda code: subprocess.run(['bash', '-c', 'source scripts/lib/site_profile.sh; ' + code, 'x', www], cwd=ROOT, env=env, capture_output=True, text=True)
        sub = sh('site_docroot_subdir').stdout.strip(); prof = sh('site_resolve_profile "$1"').stdout.strip(); dbn = sh('site_resolve_db_name "$(site_resolve_profile "$1")"').stdout.strip()
        check('site_profile.sh nhan ra ung dung Laravel-like: docroot=public, profile=generic, CSDL=app', (sub, prof, dbn) == ('public', 'generic', 'app'), (sub, prof, dbn))
        sh('site_write_profile_env "$1" generic public app')
        senv = subprocess.run(['sh', '-c', '. "%s/_supervisor/site-profile.env"; echo "$SITE_PROFILE|$WEB_SUBDIR|$DB_NAME"' % www], capture_output=True, text=True).stdout.strip()
        check('start-lamp.sh se doc dung ho so: generic|public|app', senv == 'generic|public|app', senv)
        # ---- _admin/ THAT trong web root
        r = subprocess.run(['bash', '-c', 'source scripts/lib/admin_tools.sh; prepare_admin_tools "$1" public generic', 'x', www], cwd=ROOT, capture_output=True, text=True, timeout=240)
        check('prepare_admin_tools that: _admin/ nam trong public/, khong co trang WordPress', r.returncode == 0 and os.path.isdir(pub + '/_admin') and not any(os.path.exists(pub + '/_admin/' + f) for f in ('wpcli.php', 'staging.php', 'install-wp.php', 'core-rollback.php', 'safe-mode.php')), r.stderr[-150:])

        # ---- MariaDB that + SQL khoi tao THAT cua start-lamp.sh
        sock = os.path.join(run, 'mysql.sock'); data = os.path.join(tmp, 'data')
        r = subprocess.run([install, '--user=' + rw.DB_OS_USER, '--datadir=' + data, '--auth-root-authentication-method=normal'], capture_output=True, text=True)
        if r.returncode != 0: print('(bo qua: khong khoi tao duoc MariaDB: %s)' % r.stderr[-120:]); return 0
        db = subprocess.Popen([mariadbd] + ([] if os.geteuid() != 0 else ['--user=root']) + ['--datadir=' + data, '--socket=' + sock, '--skip-networking', '--pid-file=' + os.path.join(tmp, 'm.pid'),
                               '--innodb-buffer-pool-size=64M', '--log-error=' + os.path.join(tmp, 'err.log')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            if os.path.exists(sock) and subprocess.run([cli, '--socket=' + sock, '-uroot', '-e', 'select 1'], capture_output=True).returncode == 0: break
            time.sleep(0.5)
        else: print('(bo qua: mariadbd khong len)'); return 0
        DBN = 'app'
        sql_text = subprocess.run(['sh', '-c', 'DB_NAME="%s"; DB_USER="%s"; DB_PASS="%s"\ncat <<SQL\n%s\nSQL\n' % (DBN, DBN, DBN, lr.sql_init_block())], capture_output=True, text=True).stdout
        r = subprocess.run([cli, '--socket=' + sock, '-uroot'], input=sql_text, capture_output=True, text=True)
        check('SQL khoi tao THAT cua start-lamp.sh (DB_NAME=app) chay thanh cong tren MariaDB that', r.returncode == 0, r.stderr[-200:])
        rootsql = lambda q: subprocess.run([cli, '--socket=' + sock, '-uroot', '-N', '-B', '-e', q], capture_output=True, text=True).stdout.strip()
        check("chi co database 'app' (khong tao nham 'wordpress' cho ung dung khac)", rootsql("SHOW DATABASES LIKE 'app'") == 'app' and rootsql("SHOW DATABASES LIKE 'wordpress%'") == '')

        # ---- render + chay nginx/php-fpm
        port = rw.free_port(); sport = rw.free_port(); fsock = os.path.join(run, 'php-fpm.sock')
        has_realip = 'http_realip_module' in (lambda r: r.stdout + r.stderr)(subprocess.run([nginx, '-V'], capture_output=True, text=True))
        realip = 'set_real_ip_from 127.0.0.1; real_ip_header CF-Connecting-IP; real_ip_recursive off;' if has_realip else '# (khong co realip)'
        webroot = www if no_docroot else pub   # DOI CHUNG AM: web root = goc du an (hanh vi truoc 1bb)
        vals = dict(DOCROOT=www, WEBROOT=webroot, PORT=port, STAGING_PORT=sport, FPM_SOCK=fsock, RUNDIR=run, CF_REALIP_LINE=realip, DATA=app, BIN=tmp,
                    MYSQL_SOCK=sock, DB_NAME=DBN, DB_USER=DBN, DB_PASS=DBN)
        ngx = lr.render(open(os.path.join(lr.TPLDIR, 'nginx.conf.template'), encoding='utf-8').read(), 'nginx.conf.template', vals)
        if os.geteuid() == 0: ngx = 'user root;\n' + ngx
        rw.wr(os.path.join(tmp, 'nginx.conf'), ngx)
        for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', ngx)): os.makedirs(m, exist_ok=True)
        fpmc = lr.render(open(os.path.join(lr.TPLDIR, 'php-fpm.conf.template'), encoding='utf-8').read(), 'php-fpm.conf.template', vals).replace('listen.mode = 0660', 'listen.mode = 0666')
        if os.geteuid() == 0: fpmc = fpmc.replace('[www]\n', '[www]\nuser = root\ngroup = root\n', 1)
        rw.wr(os.path.join(tmp, 'php-fpm.conf'), fpmc)
        ini = open(os.path.join(lr.TPLDIR, 'php.ini.template'), encoding='utf-8').read()
        for k in ('__OPCACHE_ENABLE_LINE__', '__OPCACHE_LOCK_LINE__', '__OPCACHE_MEM_LINE__', '__OPCACHE_FILE_LINE__', '__APCU_EXTENSION_LINE__', '__APCU_ENABLED_LINE__', '__APCU_SHM_SIZE_LINE__', '__APCU_ENABLE_CLI_LINE__', '__AUTO_SLEEP_PREPEND__'): ini = ini.replace(k, '')
        ini = re.sub(r'^extension_dir\s*=.*$', '', ini.replace('__RUNDIR__', run), flags=re.M)
        rw.wr(os.path.join(tmp, 'php.ini'), ini)
        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'php-fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(fsock): break
            time.sleep(0.1)

        print('== A. Web root = public/ ==')
        r0 = req(port, 'GET', '/')
        j = json.loads(r0.text) if r0.status == 200 and r0.text.startswith('{') else {}
        check('GET / -> front controller public/index.php chay (200 JSON)', r0.status == 200 and 'docroot' in j, (r0.status, r0.text[:120]))
        check('DOCUMENT_ROOT cua PHP la thu muc public/ (khong phai goc du an)', j.get('docroot', '').endswith('/www/public'), j.get('docroot'))
        r1 = req(port, 'GET', '/pretty/url/path?x=1&y=2')
        j1 = json.loads(r1.text) if r1.text.startswith('{') else {}
        check('URL dep /pretty/url/path roi ve front controller (try_files), giu nguyen query', r1.status == 200 and j1.get('uri') == '/pretty/url/path?x=1&y=2' and j1.get('script') == '/index.php', (r1.status, j1))
        rc = req(port, 'GET', '/assets/app.css', {'Accept-Encoding': 'gzip'})
        css = gzip.decompress(rc.body).decode() if rc.h.get('content-encoding') == 'gzip' else rc.text
        check('file tinh public/assets/app.css: 200, text/css, gzip, Cache-Control immutable, header bao mat (cac ky thuat PDF ap dung cho moi app PHP)',
              rc.status == 200 and rc.h.get('content-type', '').startswith('text/css') and rc.h.get('content-encoding') == 'gzip' and 'color: #123456' in css and 'immutable' in rc.h.get('cache-control', '')
              and rc.h.get('x-content-type-options') == 'nosniff', (rc.status, rc.h))

        print('== B. File bi mat NGOAI web root khong truy cap duoc ==')
        leaks = {}
        for p in ('/composer.json', '/.env', '/storage/secret.txt', '/vendor/autoload.php', '/artisan', '/_supervisor/site-profile.env', '/public/.env', '/.env.bak'):
            rr = req(port, 'GET', p)
            leaks[p] = (rr.status, 'SECRET' in rr.text)
        bad = {p: v for p, v in leaks.items() if v[1]}
        check('composer.json / .env / storage / vendor / artisan / _supervisor / public/.env: KHONG lo noi dung bi mat', not bad, bad)
        # Duong dan ngoai web root khong phai file tinh: nginx roi ve front controller (framework tu tra 404 cua no) - 200 voi JSON cua ung dung, KHONG phai file that
        def uri_of(p):
            try: return json.loads(req(port, 'GET', p).text).get('uri')
            except Exception: return None
        routed = [p for p in ('/composer.json', '/storage/secret.txt', '/artisan') if uri_of(p) == p]
        check('duong dan ngoai web root KHONG phai .php duoc ung dung xu ly (front controller), khong phai phuc vu file that', len(routed) == 3, routed)
        rv = req(port, 'GET', '/vendor/autoload.php')
        check('/vendor/autoload.php (.php ngoai web root): 404, khong thuc thi/lo ma', rv.status == 404 and 'SECRET' not in rv.text, rv.status)
        trav = [req(port, 'GET', p) for p in ('/../.env', '/%2e%2e/.env', '/assets/../../.env', '/..%2f.env')]
        check('thu thoat web root bang ../ va %2e%2e: khong lo .env', not any('SECRET' in t.text for t in trav), [(t.status) for t in trav])
        check('public/.env (nam TRONG web root) bi chan boi quy tac file an cua nginx -> 403', req(port, 'GET', '/.env').status in (403, 404) and 'SECRET' not in req(port, 'GET', '/.env').text)

        print('== C. Bien moi truong DB_* dung duoc voi MariaDB that ==')
        e = j.get('env', {})
        check('PHP thay du 6 bien DB_*: mysql / localhost / socket / app / app / app', (e.get('DB_CONNECTION'), e.get('DB_HOST'), e.get('DB_SOCKET'), e.get('DB_DATABASE'), e.get('DB_USERNAME'), e.get('DB_PASSWORD')) == ('mysql', 'localhost', sock, 'app', 'app', 'app'), e)
        rd = req(port, 'GET', '/db')
        jd = json.loads(rd.text) if rd.text.startswith('{') else {}
        check('ket noi + ghi + doc MariaDB CHI bang bien moi truong (nhu Laravel); DATABASE()=app; tieng Viet + emoji nguyen ven', rd.status == 200 and jd == {'db': 'app', 'v': 'Tiếng Việt có dấu 😀'}, (rd.status, rd.text[:160]))

        print('== D. Tai khoan CSDL chi co quyen tren DB cua no ==')
        asql = lambda q: subprocess.run([cli, '--socket=' + sock, '-uapp', '-papp', '-N', '-B', '-e', q], capture_output=True, text=True)
        ok1 = asql('CREATE DATABASE app_staging'); ok2 = asql('DROP DATABASE app_staging')
        check("user 'app' tao/xoa duoc DB ten app_* (staging) - dung theo SQL khoi tao", ok1.returncode == 0 and ok2.returncode == 0, ok1.stderr[-120:])
        d1 = asql('CREATE DATABASE other'); d2 = asql('SELECT user FROM mysql.user LIMIT 1'); d3 = asql('CREATE DATABASE wordpress')
        check("user 'app' KHONG tao duoc DB khac, KHONG doc duoc mysql.user, KHONG tao duoc 'wordpress'", d1.returncode != 0 and d2.returncode != 0 and d3.returncode != 0, (d1.returncode, d2.returncode, d3.returncode))
        check("user 'app' thay dung DB cua minh (SHOW DATABASES khong liet ke DB khac)", set(asql('SHOW DATABASES').stdout.split()) <= {'app', 'information_schema'}, asql('SHOW DATABASES').stdout)

        print('== E. _admin/ nam trong web root, khong co trang WordPress ==')
        rw.wr(os.path.join(app, 'admin-password.txt'), 'generic-test-password-1234\n')  # app Android sinh file nay luc chay lan dau
        # _admin/ chi cho IP mang LAN: tu loopback luon 403 (ke ca file khong ton tai). Gia IP LAN bang CF-Connecting-IP (realip tin 127.0.0.1 -
        # Cloudflare luon GHI DE header nay nen khach tunnel khong tu dat duoc).
        if has_realip:
            LAN = {'CF-Connecting-IP': '192.168.1.50'}
            check('tu loopback KHONG co IP LAN: /_admin/ bi chan 403 (nhu thiet ke)', req(port, 'GET', '/_admin/').status == 403)
            ra = req(port, 'GET', '/_admin/', LAN)
            check('tu IP LAN: /_admin/ phuc vu tu public/_admin (khong 403/404/500)', ra.status in (200, 302, 401), (ra.status, ra.text[:80]))
            wp404 = [req(port, 'GET', '/_admin/' + f, LAN).status for f in ('wpcli.php', 'staging.php', 'install-wp.php', 'core-rollback.php', 'safe-mode.php')]
            check('tu IP LAN: /_admin/{wpcli,staging,install-wp,core-rollback,safe-mode}.php -> 404 (khong trien khai cho app khong phai WordPress)', all(s == 404 for s in wp404), wp404)
            check('tu IP LAN: /_admin/logs.php (trang dung chung) co mat (khong 404)', req(port, 'GET', '/_admin/logs.php', LAN).status != 404)
            ri = req(port, 'GET', '/_admin/', LAN)
            check('menu /_admin/ cua app generic: khong hien "Cai WordPress", WP-CLI, Staging (HTML that qua nginx+php-fpm)', not any(w in ri.text for w in ('install-wp.php', 'wpcli.php', 'staging.php', 'WP-CLI')), ri.status)
        else:
            print('(bo qua kiem tra HTTP cua _admin/: nginx khong co realip de gia IP LAN; da kiem tra file tren dia o tren)')

        print('== F. Cac ky thuat van hanh ap dung cho moi app PHP ==')
        rw.wr(os.path.join(run, 'maintenance-mode'), '1'); time.sleep(2.6)
        rm = req(port, 'GET', '/'); check('maintenance-mode: 503 + trang bao tri', rm.status == 503 and 'bao tri' in rm.text.lower(), (rm.status, rm.text[:60]))
        os.remove(os.path.join(run, 'maintenance-mode')); time.sleep(2.6)
        check('tat maintenance-mode: app tro lai 200', req(port, 'GET', '/').status == 200)
        mh, mb = fs.multipart('f', 3 * 1024 * 1024)
        pr = req(port, 'POST', '/pretty/upload', mh, mb)
        check('upload 3MB toi front controller qua (nginx 32m / PHP 32M khop)', pr.status == 200)
        check('khong co X-Powered-By (lo phien ban PHP)', 'x-powered-by' not in r0.h)
    finally:
        for p in procs + ([db] if db else []):
            try: p.terminate(); p.wait(timeout=15)
            except Exception:
                try: p.kill()
                except Exception: pass
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
