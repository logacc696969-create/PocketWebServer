#!/usr/bin/env python3
"""Ban PORT Python 1-1 cua logic nhiet do pin trong MonitorLogic.kt (AJ2/AJ3, HANDOFF 1bm) + dung CUNG vector voi MonitorLogicTest.kt.
Khi khong co kotlinc day la cach kiem thuat toan ngay; JVM test that chay o CI. Doi chieu hang so/chuoi voi Kotlin va Monitoring/BackupWorker."""
import os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
PASS = FAIL = 0
def ok(c, n):
    global PASS, FAIL
    if c: PASS += 1; print('  OK  ', n)
    else: FAIL += 1; print('  FAIL', n)
UNK = -2**31
WARM, HOT, MAXD = 400, 450, 3
known = lambda t: -300 <= t <= 1500
warm = lambda t: known(t) and t >= WARM
hot = lambda t: known(t) and t >= HOT
def fmt(t):
    if not known(t): return '?'
    a = -t if t < 0 else t
    return ('-' if t < 0 else '') + str(a // 10) + '.' + str(a % 10)
COOL = {'DEVICE_HOT': 30 * 60000, 'DEVICE_WARM': 120 * 60000}
def issues(pct, charging, temp):      # chi phan lien quan: BATTERY_CRITICAL (<=5 && !charging) roi DEVICE_*
    out = []
    if 0 <= pct <= 5 and not charging: out.append('BATTERY_CRITICAL')
    if hot(temp): out.append('DEVICE_HOT')
    elif warm(temp): out.append('DEVICE_WARM')
    return out
defer_heavy = lambda opt, chg, h=False: (opt and not chg) or h
defer_backup = lambda h, n, mx=MAXD: h and n < mx
alert = lambda issue, last, now: last <= 0 or now - last >= COOL[issue]

ok(all(known(x) for x in (365, 0, -300, 1500)) and not any(known(x) for x in (1501, UNK, 99999)), 'khoang hop le -30.0..150.0, rac/khong ro bi loai')
ok(not warm(399) and warm(400) and not hot(449) and hot(450) and warm(450), 'nguong 40.0 va 45.0 (bien 399/400 va 449/450)')
ok(not warm(UNK) and not hot(UNK), 'khong doc duoc -> khong bao nong')
ok((fmt(365), fmt(400), fmt(5), fmt(-35), fmt(UNK)) == ('36.5', '40.0', '0.5', '-3.5', '?'), 'formatTempC')
ok(issues(80, True, UNK) == [], 'snapshot cu (khong nhiet do) khong sinh van de')
ok(issues(80, True, 410) == ['DEVICE_WARM'] and issues(80, True, 450) == ['DEVICE_HOT'] and issues(80, True, 399) == [], '41 -> WARM; 45 -> chi HOT; 39.9 -> khong')
ok(issues(3, False, 470) == ['BATTERY_CRITICAL', 'DEVICE_HOT'], 'pin gan can + nong: dung thu tu khai bao')
ok(not alert('DEVICE_HOT', 1000, 1000 + 29 * 60000) and alert('DEVICE_HOT', 1000, 1000 + 30 * 60000) and not alert('DEVICE_WARM', 1000, 1000 + 119 * 60000) and alert('DEVICE_WARM', 1000, 1000 + 120 * 60000), 'cooldown HOT 30 phut, WARM 2 gio')
ok(defer_heavy(False, True, True) and defer_heavy(True, False) and not defer_heavy(True, True) and not defer_heavy(False, False) and defer_heavy(True, False, False), 'wantDeferHeavyJobs')
ok(defer_backup(True, 0) and defer_backup(True, 2) and not defer_backup(True, 3) and not defer_backup(False, 0) and defer_backup(True, 5, 9), 'shouldDeferBackupForHeat: toi da 3 lan lien tiep')
# mo phong chuoi nhieu chu ky: may nong LIEN TUC -> hoan 3 lan roi CHAY (khong bao gio "khong backup"), roi lai hoan
cnt, seq = 0, []
for _ in range(9):
    if defer_backup(True, cnt): cnt += 1; seq.append('hoan')
    else: cnt = 0; seq.append('chay')
ok(seq == ['hoan'] * 3 + ['chay'] + ['hoan'] * 3 + ['chay'] + ['hoan'], 'may nong lien tuc: cu 3 chu ky hoan thi 1 chu ky CHAY (khong bao gio mat backup)')
kt = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/MonitorLogic.kt'), encoding='utf8').read()
ok('const val TEMP_WARM_TENTHS: Int = 400' in kt and 'const val TEMP_HOT_TENTHS: Int = 450' in kt and 'const val HEAT_MAX_BACKUP_DEFERRALS: Int = 3' in kt, 'Kotlin: hang so 400/450/3 khop ban port')
ok('tenths in -300..1500' in kt and 'DEVICE_WARM(2L * 3600 * 1000)' in kt and 'DEVICE_HOT(30L * 60 * 1000)' in kt, 'Kotlin: khoang hop le va cooldown khop')
mo = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/Monitoring.kt'), encoding='utf8').read()
ok('EnvIssue.DEVICE_WARM ->' in mo and 'EnvIssue.DEVICE_HOT ->' in mo, 'Monitoring.envMessage co du nhanh cho 2 van de moi (when la bieu thuc, thieu nhanh = loi bien dich)')
ok('MonitorLogic.wantDeferHeavyJobs(enabled, charging, hot)' in mo, 'syncHeavyJobsFlag truyen co "hot"')
bw = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/BackupWorker.kt'), encoding='utf8').read()
ok('shouldDeferBackupForHeat(' in bw and 'KEY_HEAT_DEFER_COUNT, 0)' in bw, 'BackupWorker hoan co gioi han + reset dem')
enum_names = re.findall(r'^\s+([A-Z_]+)\(\d', kt[kt.index('enum class EnvIssue'):kt.index('const val RESTRICT_BACKGROUND_ENABLED')], re.M)
branches = re.findall(r'MonitorLogic\.EnvIssue\.([A-Z_]+) ->', mo)
ok(sorted(enum_names) == sorted(branches), 'moi gia tri EnvIssue (%d) deu co nhanh trong envMessage (%d)' % (len(enum_names), len(branches)))
print('TONG KET: pass=%d fail=%d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
