#!/usr/bin/env python3
"""Doi chieu TAI LIEU voi CODE (HANDOFF.md muc 1bo-G). Khong can kotlinc/php/mang.

Van de: tai lieu van hanh (FAILURE_MODES, DISASTER_RECOVERY, DATA_AND_SECRETS, RELEASE_AND_COMPATIBILITY) neu cac con so
(5 ban backup, 15 phut, 85%, 50 MB, ...) ma code da doi thi tro thanh SAI ma khong ai hay. Moi con so trong tai lieu duoc gan
dau `<!-- code-fact: TEN=GIATRI -->` va test nay doc gia tri THAT tu code de so; them vao do cac con so nam trong cau chu
duoc kiem bang mau cau; tep duoc nhac toi bang `...md` phai ton tai; moi tai lieu phai co trong muc luc README.
"""
import glob, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
K = "app/src/main/java/com/wppocket/server/"
T = "scripts/runtimes/templates/"
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
def rd(p): return open(os.path.join(ROOT, p), encoding="utf-8").read()

def rx(path, pat, flags=0, conv=lambda x: x):
    m = re.search(pat, rd(path), flags)
    return conv(m.group(1)) if m else None

def backup_contains():
    t = rd(K + "BackupManager.kt")
    names = set(re.findall(r'ZipEntry\("([^"]+)"\)', t))
    if 'zipDir(wwwDir, "www", zos)' in t: names.add("www")
    return ",".join(sorted(names))

FACTS = {
    "KEEP_BACKUPS": lambda: rx(K + "BackupManager.kt", r"KEEP_BACKUPS = (\d+)"),
    "BACKUP_DEFAULT_HOURS": lambda: rx(K + "Prefs.kt", r"DEFAULT_BACKUP_INTERVAL_HOURS = (\d+)L"),
    "HEALTH_PERIOD_MIN": lambda: rx(K + "HealthCheckWorker.kt", r"PeriodicWorkRequestBuilder<HealthCheckWorker>\((\d+), TimeUnit\.MINUTES"),
    "HEALTH_FAIL_THRESHOLD": lambda: rx(K + "HealthCheckWorker.kt", r"FAIL_THRESHOLD = (\d+)"),
    "DISK_ALERT_PCT": lambda: rx(K + "AlertThresholds.kt", r"DISK_DEFAULT = (\d+)"),
    "DISK_ALERT_COOLDOWN_H": lambda: rx(K + "Monitoring.kt", r"DISK_ALERT_COOLDOWN_MS = (\d+)L \* 60 \* 60 \* 1000"),
    "AUDIT_ALERT_COOLDOWN_MIN": lambda: rx(K + "Monitoring.kt", r"AUDIT_ALERT_COOLDOWN_MS = (\d+)L \* 60 \* 1000"),
    "HEAT_HOT_TENTHS": lambda: rx(K + "MonitorLogic.kt", r"TEMP_HOT_TENTHS: Int = (\d+)"),
    "HEAT_MAX_DEFERRALS": lambda: rx(K + "MonitorLogic.kt", r"HEAT_MAX_BACKUP_DEFERRALS: Int = (\d+)"),
    "SESSION_IDLE_SEC": lambda: rx(T + "admin-auth.php", r"WP_POCKET_SESSION_IDLE_SECONDS = (\d+);"),
    "MAX_FAILED_ATTEMPTS": lambda: rx(T + "admin-auth.php", r"WP_POCKET_MAX_FAILED_ATTEMPTS = (\d+);"),
    "LOCKOUT_SEC": lambda: rx(T + "admin-auth.php", r"WP_POCKET_LOCKOUT_SECONDS = (\d+);"),
    "MARIADB_STOP_TIMEOUT": lambda: rx(T + "start-lamp.sh", r"MARIADB_STOP_TIMEOUT:-(\d+)"),
    "TELEGRAM_MAX_MB": lambda: rx(K + "UploadLogic.kt", r"TELEGRAM_MAX_BYTES: Long = (\d+)L \* 1024L \* 1024L"),
    "PHP_TIMEZONE": lambda: rx(T + "php.ini.template", r"^date\.timezone = (.+?)\s*$", re.M),
    "ALLOW_BACKUP": lambda: rx("app/src/main/AndroidManifest.xml", r'android:allowBackup="(\w+)"'),
    "VERSION_CODE": lambda: rx("app/build.gradle.kts", r"versionCode = (\d+)"),
    "MIN_SDK": lambda: rx("app/build.gradle.kts", r"minSdk = (\d+)"),
    "TARGET_SDK": lambda: rx("app/build.gradle.kts", r"targetSdk = (\d+)"),
    "DEFAULT_VERSION_NAME": lambda: rx("app/build.gradle.kts", r'versionName = \(project\.findProperty\("appVersionName"\) as String\?\) \?: "([^"]+)"'),
    "BACKUP_CONTAINS": backup_contains,
    "PHP_FATAL_COOLDOWN_MIN": lambda: rx(K + "Monitoring.kt", r"PHP_FATAL_ALERT_COOLDOWN_MS = (\d+)L \* 60 \* 1000"),
}
CODE = {k: f() for k, f in FACTS.items()}
check("moi hang so doc duoc tu code (khong None)", all(v is not None for v in CODE.values()), str([k for k, v in CODE.items() if v is None]))

DOCS = ["docs/FAILURE_MODES.md", "docs/DISASTER_RECOVERY.md", "docs/DATA_AND_SECRETS.md", "docs/RELEASE_AND_COMPATIBILITY.md", "docs/COMPETITIVE_ANALYSIS.md"]
ROOT_MD = ["CHANGELOG.md", "BREAKING_CHANGES.md", "CONTRIBUTING.md", "CODE_OF_CONDUCT.md", "TERMS.md"]
check("moi tai lieu ton tai", all(os.path.isfile(os.path.join(ROOT, p)) for p in DOCS + ROOT_MD))

def verify_markers(text):
    bad = []
    for name, val in re.findall(r"<!-- code-fact: ([A-Z_]+)=(.*?) -->", text):
        if name not in CODE: bad.append("%s: khong co trong bang doi chieu" % name)
        elif CODE[name] != val: bad.append("%s: tai lieu=%r code=%r" % (name, val, CODE[name]))
    return bad
total_markers = 0
for d in DOCS + ROOT_MD:
    t = rd(d); n = len(re.findall(r"<!-- code-fact:", t)); total_markers += n
    check("%s: moi dau code-fact khop code (%d dau)" % (d, n), verify_markers(t) == [], str(verify_markers(t)))
check("cac tai lieu van hanh co dau code-fact (khong bo trong)", all("<!-- code-fact:" in rd(d) for d in DOCS[:4]))
check("DOI CHUNG AM: sua 1 con so trong tai lieu thi test BAT DUOC", verify_markers(rd("docs/DISASTER_RECOVERY.md").replace("KEEP_BACKUPS=5", "KEEP_BACKUPS=7")) != [])

# ---- con so trong CAU CHU (khong chi trong chu thich) ----
def expect(doc, template):
    s = template.format(**CODE)
    check("%s: cau chu chua dung '%s'" % (doc, s), s in rd(doc))
expect("docs/FAILURE_MODES.md", "(≥ {DISK_ALERT_PCT}%)")
expect("docs/FAILURE_MODES.md", "chạy mỗi {HEALTH_PERIOD_MIN} phút")
expect("docs/FAILURE_MODES.md", "liên tiếp {HEALTH_FAIL_THRESHOLD} lần")
expect("docs/FAILURE_MODES.md", "tối đa 1 lần/{DISK_ALERT_COOLDOWN_H} giờ")
expect("docs/FAILURE_MODES.md", "tối đa {HEAT_MAX_DEFERRALS} lần liên tiếp")
expect("docs/FAILURE_MODES.md", "Sai {MAX_FAILED_ATTEMPTS} lần")
expect("docs/FAILURE_MODES.md", "{LOCKOUT_SEC} giây")
expect("docs/FAILURE_MODES.md", "tối đa 1 lần/{AUDIT_ALERT_COOLDOWN_MIN} phút")
expect("docs/FAILURE_MODES.md", "{SESSION_IDLE_SEC} giây")
expect("docs/FAILURE_MODES.md", "MariaDB tối đa {MARIADB_STOP_TIMEOUT} giây")
expect("docs/FAILURE_MODES.md", "{TELEGRAM_MAX_MB} MB")
check("FAILURE_MODES: nguong nong %s decimau = %s.%s C" % (CODE["HEAT_HOT_TENTHS"], int(CODE["HEAT_HOT_TENTHS"]) // 10, int(CODE["HEAT_HOT_TENTHS"]) % 10), "(≥ %d,%d °C)" % (int(CODE["HEAT_HOT_TENTHS"]) // 10, int(CODE["HEAT_HOT_TENTHS"]) % 10) in rd("docs/FAILURE_MODES.md"))
expect("docs/FAILURE_MODES.md", "tối đa 1 lần/{PHP_FATAL_COOLDOWN_MIN} phút")
expect("docs/DISASTER_RECOVERY.md", "mặc định {BACKUP_DEFAULT_HOURS} giờ")
expect("docs/DISASTER_RECOVERY.md", "giữ {KEEP_BACKUPS} bản gần nhất")
expect("docs/DISASTER_RECOVERY.md", "tệp > {TELEGRAM_MAX_MB} MB")
expect("docs/DISASTER_RECOVERY.md", 'allowBackup="{ALLOW_BACKUP}"')
expect("docs/DATA_AND_SECRETS.md", "Giữ {KEEP_BACKUPS} bản gần nhất")
expect("docs/RELEASE_AND_COMPATIBILITY.md", "luôn là {VERSION_CODE}")
expect("docs/RELEASE_AND_COMPATIBILITY.md", "`minSdk` {MIN_SDK}")
expect("docs/RELEASE_AND_COMPATIBILITY.md", "`targetSdk` {TARGET_SDK}")
expect("docs/RELEASE_AND_COMPATIBILITY.md", "mặc định `{DEFAULT_VERSION_NAME}`")
expect("docs/DATA_AND_SECRETS.md", "{PHP_TIMEZONE}") if False else None
check("backup chua dung 'database.sql' va 'www' (tai lieu DISASTER_RECOVERY noi vay)", CODE["BACKUP_CONTAINS"] == "database.sql,www")

# ---- tep duoc nhac toi + muc luc README + HANDOFF ----
refs_ok = True; missing = []
for d in DOCS + ROOT_MD:
    for ref in re.findall(r"`((?:docs/)?[A-Za-z_]+\.md)`", rd(d)):
        if not (os.path.isfile(os.path.join(ROOT, ref)) or os.path.isfile(os.path.join(ROOT, "docs", ref))):
            refs_ok = False; missing.append((d, ref))
check("moi tep .md duoc nhac toi bang `...` deu ton tai", refs_ok, str(missing))
readme = rd("README.md")
check("README co muc luc tai lieu va tro toi moi tai lieu", all(p in readme for p in DOCS + ROOT_MD), str([p for p in DOCS + ROOT_MD if p not in readme]))
h = rd("HANDOFF.md")
check("HANDOFF.md co muc 1bo va nhac moi tai lieu moi (lich su khong bi bo sot)", "## 1bo." in h and all(os.path.basename(p) in h for p in DOCS + ROOT_MD), str([p for p in DOCS + ROOT_MD if os.path.basename(p) not in h]))
check("HANDOFF: dinh chinh o muc 1q va 1bc-E ton tai", h.count("ĐÍNH CHÍNH (vòng 1bo, đọc code)") == 1 and "ĐÍNH CHÍNH 1bo: quyết định này đã ĐẢO" in h)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
