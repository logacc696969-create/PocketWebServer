#!/usr/bin/env python3
"""Kiem thu nginx PHIA TRUOC cho node/python/static (HANDOFF.md muc 1bi) bang nginx THAT chay QUA CHINH start-generic.sh (binary libnginx.so la ban boc goi nginx
he thong; app that la 1 may chu Python nho). Che do PROXY: header Host/X-Forwarded-*/CF-Connecting-IP, header bao mat + CSP + HSTS co dieu kien, gzip,
WEBSOCKET (101 + chuyen byte 2 chieu), /healthz, chan _supervisor va dotfile, app chet -> 502 + giam sat thoat 1. Che do STATIC: phuc vu file, ETag/304,
Cache-Control tai san tinh (van ke thua header bao mat), gzip, chan _supervisor/dotfile, 404, /healthz.
Can: nginx + python3 + sh. Thieu nginx thi bo qua (exit 0)."""
import gzip, http.client, os, shutil, socket, subprocess, sys, tempfile, textwrap, threading, time
HERE = os.path.dirname(os.path.abspath(__file__)); TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:240]) if d else ''))

BACKEND = r'''
import http.server, socketserver, os, sys
class H(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *a): pass
    def _send(self, body, ctype='text/plain', code=200):
        b = body.encode(); self.send_response(code); self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(b))); self.end_headers()
        if self.command != 'HEAD': self.wfile.write(b)
    do_HEAD = lambda self: self.do_GET()
    def do_GET(self):
        if self.path == '/ws' and self.headers.get('Upgrade', '').lower() == 'websocket':
            self.send_response(101); self.send_header('Upgrade', 'websocket'); self.send_header('Connection', 'Upgrade'); self.end_headers()
            self.wfile.flush(); self.close_connection = True
            while True:
                d = self.connection.recv(4096)
                if not d: break
                self.connection.sendall(d)
            return
        if self.path == '/big': return self._send('a' * 20000)
        if self.path == '/missing': return self._send('nope', code=404)
        h = self.headers
        self._send('host=%s;xff=%s;real=%s;proto=%s;upg=[%s];conn=[%s];' % (h.get('Host'), h.get('X-Forwarded-For'), h.get('X-Real-IP'), h.get('X-Forwarded-Proto'), h.get('Upgrade'), h.get('Connection')))
class T(socketserver.ThreadingMixIn, http.server.HTTPServer): daemon_threads = True; allow_reuse_address = True
T(('127.0.0.1', int(os.environ['PORT'])), H).serve_forever()
'''

def free_port():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p
def wait_port(port, t=8):
    for _ in range(int(t * 20)):
        try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); return True
        except OSError: time.sleep(0.05)
    return False

def main():
    nginx = shutil.which('nginx')
    if not nginx: print('(bo qua: thieu nginx)'); return 0
    tmp = tempfile.mkdtemp(prefix='front-'); os.chmod(tmp, 0o755)
    procs = []
    try:
        def layout(name):
            d = os.path.join(tmp, name); www = os.path.join(d, 'www'); sup = os.path.join(www, '_supervisor'); binp = os.path.join(d, 'bin'); home = os.path.join(d, 'home')
            for x in (sup, binp, home): os.makedirs(x)
            for f in ('start-generic.sh', 'nginx-front.conf.template', 'front-locations-proxy.conf.template', 'front-locations-static.conf.template'): shutil.copy(os.path.join(TPL, f), sup)
            open(os.path.join(binp, 'libnginx.so'), 'w').write('#!/bin/sh\nexec %s "$@"\n' % nginx); os.chmod(os.path.join(binp, 'libnginx.so'), 0o755)
            open(os.path.join(d, 'backend.py'), 'w').write(BACKEND)
            open(os.path.join(binp, 'libruntimesrv.so'), 'w').write('#!/bin/sh\nexec %s %s\n' % (sys.executable, os.path.join(d, 'backend.py'))); os.chmod(os.path.join(binp, 'libruntimesrv.so'), 0o755)
            os.chmod(d, 0o755)
            for x in (www, sup, binp, home): os.chmod(x, 0o755)
            return d, www, sup, binp, home
        def launch(d, www, sup, binp, home, port, **env):
            e = dict(os.environ, LD_LIBRARY_PATH=binp, HOME=home, PORT=str(port)); e.update(env)
            p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=e, cwd=www, stdout=subprocess.PIPE, stderr=subprocess.STDOUT); procs.append(p); return p
        def req(port, method, path, headers=None):
            c = http.client.HTTPConnection('127.0.0.1', port, timeout=15)
            try:
                c.request(method, path, headers=headers or {}); r = c.getresponse(); b = r.read(); return r.status, {k.lower(): v for k, v in r.getheaders()}, b
            finally: c.close()

        print('== A. PROXY: nginx -> app Python ==')
        d, www, sup, binp, home = layout('proxy'); port = free_port()
        p = launch(d, www, sup, binp, home, port, GEN_MODE='proxy', GEN_APP_BIN='libruntimesrv.so', GEN_APP_ARGS='')
        up = wait_port(port); check('nginx nghe cong cong va app tra loi qua nginx', up and req(port, 'GET', '/')[0] == 200, p.poll())
        if not up: print(p.stdout.read().decode()[-500:] if p.poll() is not None else ''); return 1
        s, h, b = req(port, 'GET', '/', {'Host': 'front.example'}); b = b.decode()
        check('Host duoc chuyen nguyen ven toi app (host=front.example)', 'host=front.example;' in b, b)
        check('khong co CF-Connecting-IP: X-Forwarded-For = dia chi ket noi (127.0.0.1)', 'xff=127.0.0.1;' in b and 'real=127.0.0.1;' in b, b)
        check('khong co X-Forwarded-Proto: app thay http', 'proto=http;' in b, b)
        s, h, b2 = req(port, 'GET', '/', {'CF-Connecting-IP': '203.0.113.9', 'X-Forwarded-Proto': 'https'}); b2 = b2.decode()
        check('qua Cloudflare: IP khach that 203.0.113.9 -> X-Forwarded-For/X-Real-IP, proto=https', 'xff=203.0.113.9;' in b2 and 'real=203.0.113.9;' in b2 and 'proto=https;' in b2, b2)
        check('header bao mat tren phan hoi da proxy (X-Frame-Options, nosniff, Referrer-Policy)', h.get('x-frame-options') == 'SAMEORIGIN' and h.get('x-content-type-options') == 'nosniff' and h.get('referrer-policy') == 'strict-origin-when-cross-origin', h)
        check("CSP tap con an toan: frame-ancestors 'self'; base-uri 'self'", h.get('content-security-policy') == "frame-ancestors 'self'; base-uri 'self'", h.get('content-security-policy'))
        check('HSTS co dieu kien: qua https (X-Forwarded-Proto) CO, max-age=2592000', h.get('strict-transport-security') == 'max-age=2592000', h.get('strict-transport-security'))
        s, h0, _ = req(port, 'GET', '/'); check('HSTS: truy cap LAN http KHONG co header', 'strict-transport-security' not in h0, h0.get('strict-transport-security'))
        s, hg, bg = req(port, 'GET', '/big', {'Accept-Encoding': 'gzip'})
        check('gzip: Content-Encoding gzip va giai nen dung 20000 ky tu', hg.get('content-encoding') == 'gzip' and gzip.decompress(bg) == b'a' * 20000 and len(bg) < 2000, (hg.get('content-encoding'), len(bg)))
        s, hn, bn = req(port, 'GET', '/big'); check('khong xin gzip -> khong nen', 'content-encoding' not in hn and len(bn) == 20000, hn.get('content-encoding'))
        s, _, _ = req(port, 'GET', '/healthz'); check('/healthz -> 200 khi app song', s == 200, s)
        s, _, _ = req(port, 'HEAD', '/healthz'); check('/healthz HEAD -> 200', s == 200, s)
        s, hm, bm = req(port, 'GET', '/missing'); check('404 cua app duoc chuyen nguyen (khong bi nuot)', s == 404 and bm == b'nope', (s, bm))
        s, _, _ = req(port, 'GET', '/_supervisor/start-generic.sh'); check('/_supervisor/ bi chan (403), khong lo script', s == 403, s)
        s, _, _ = req(port, 'GET', '/.env'); check('dotfile (/.env) bi chan (403)', s == 403, s)
        # WebSocket (PDF H3)
        so = socket.create_connection(('127.0.0.1', port), timeout=8)
        so.sendall(b'GET /ws HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\n\r\n')
        buf = b''
        while b'\r\n\r\n' not in buf: 
            c = so.recv(4096)
            if not c: break
            buf += c
        check('WebSocket: nginx chuyen tiep nang cap -> 101 Switching Protocols', buf.startswith(b'HTTP/1.1 101'), buf[:80])
        so.sendall(b'ping-123'); so.settimeout(5)
        try: echo = so.recv(100)
        except Exception as e: echo = repr(e).encode()
        check('WebSocket: byte di 2 chieu qua nginx (echo ping-123)', echo == b'ping-123', echo); so.close()
        # app chet
        app_pid = int(open(os.path.join(home, 'generic-run', 'front-app.pid')).read())
        os.kill(app_pid, 9); time.sleep(0.5)
        s, _, _ = req(port, 'GET', '/healthz'); check('app chet -> /healthz 502/504 (giam sat phat hien duoc) HOAC giam sat da dung nginx', s in (502, 504), s) if p.poll() is None else check('giam sat da dung ca bo ngay khi app chet', True)
        try: rc = p.wait(timeout=8)
        except Exception: p.kill(); rc = 'timeout'
        check('app chet -> giam sat thoat 1 (Kotlin se khoi dong lai ca bo)', rc == 1, rc)
        check('...va nginx cung da dung (cong dong lai)', not wait_port(port, 1), None)

        print('== B. STATIC: nginx phuc vu thang ==')
        d, www, sup, binp, home = layout('static'); port = free_port()
        open(os.path.join(www, 'index.html'), 'w').write('STATIC-OK'); open(os.path.join(www, 'style.css'), 'w').write('body{color:red}\n' * 40); open(os.path.join(www, '.secret'), 'w').write('TOPSECRET')
        open(os.path.join(www, 'app.js'), 'w').write('console.log(1);\n' * 200); os.makedirs(os.path.join(www, 'sub')); open(os.path.join(www, 'sub', 'index.html'), 'w').write('SUB-OK')
        for f in ('index.html', 'style.css', '.secret', 'app.js'): os.chmod(os.path.join(www, f), 0o644)
        os.chmod(os.path.join(www, 'sub'), 0o755); os.chmod(os.path.join(www, 'sub', 'index.html'), 0o644)
        p = launch(d, www, sup, binp, home, port, GEN_MODE='static', GEN_APP_BIN='', GEN_APP_ARGS='')
        up = wait_port(port); check('static: nginx nghe cong cong', up)
        if up:
            s, h, b = req(port, 'GET', '/'); check('GET / -> index.html', s == 200 and b == b'STATIC-OK', (s, b))
            check('co ETag va Last-Modified', 'etag' in h and 'last-modified' in h, h)
            s, h2, _ = req(port, 'GET', '/', {'If-None-Match': h['etag']}); check('If-None-Match -> 304 (khong gui lai noi dung)', s == 304, s)
            check('header bao mat + CSP tap con tren trang tinh', h.get('x-frame-options') == 'SAMEORIGIN' and h.get('content-security-policy') == "frame-ancestors 'self'; base-uri 'self'", h)
            s, hc, _ = req(port, 'GET', '/style.css'); check('tai san tinh: Cache-Control max-age=604800 (7 ngay)', 'max-age=604800' in hc.get('cache-control', ''), hc.get('cache-control'))
            check('tai san tinh VAN ke thua header bao mat (chi dung expires, khong add_header)', hc.get('x-frame-options') == 'SAMEORIGIN' and hc.get('x-content-type-options') == 'nosniff', hc)
            s, hj, bj = req(port, 'GET', '/app.js', {'Accept-Encoding': 'gzip'}); check('gzip cho JS lon', hj.get('content-encoding') == 'gzip' and gzip.decompress(bj).startswith(b'console.log(1);'), hj.get('content-encoding'))
            s, _, b = req(port, 'GET', '/sub/'); check('thu muc con co index.html', s == 200 and b == b'SUB-OK', (s, b))
            s, _, b = req(port, 'GET', '/_supervisor/start-generic.sh'); check('static: /_supervisor/ bi chan (403) - script/soname-map/mau nginx KHONG duoc phuc vu', s == 403 and b'start-generic' not in b, s)
            s, _, b = req(port, 'GET', '/.secret'); check('dotfile (/.secret) bi chan 403, khong lo noi dung', s == 403 and b'TOPSECRET' not in b, s)
            s, _, _ = req(port, 'GET', '/khong-co'); check('khong co -> 404', s == 404, s)
            s, _, b = req(port, 'GET', '/healthz'); check('/healthz -> 200 ok', s == 200 and b.strip() == b'ok', (s, b))
            s, _, _ = req(port, 'POST', '/'); check('POST toi file tinh khong gay loi may chu (405/404/403, khong 5xx)', s < 500, s)
        p.terminate()
        try: p.wait(timeout=8)
        except Exception: p.kill()
    finally:
        for pr in procs:
            try: pr.terminate()
            except Exception: pass
        time.sleep(0.5); subprocess.run(['pkill', '-f', tmp], capture_output=True)
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
