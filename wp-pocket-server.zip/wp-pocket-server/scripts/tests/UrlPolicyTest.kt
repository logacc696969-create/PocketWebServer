import com.wppocket.server.UrlPolicy
import java.io.File

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }
fun ok(u: String?) = UrlPolicy.isAllowedOutbound(u)

fun main(args: Array<String>) {
    // ---- cho phep: https ----
    for (u in listOf("https://example.com/hook", "https://hooks.example.com:8443/a/b?key=abc#x", "HTTPS://Example.COM/x", "https://user:pw@example.com/x", "https://192.168.1.5/hook",
        "https://[2001:db8::1]/x", "https://script.google.com/macros/s/AKfy/exec", "  https://example.com/x  ")) {
        check("cho phep https: '$u'", ok(u))
    }
    // ---- cho phep: http CHI toi loopback ----
    for (u in listOf("http://127.0.0.1/x", "http://127.0.0.1:8080/api?k=1", "http://localhost/x", "http://LOCALHOST:3000/", "http://[::1]/x", "http://[::1]:9000/path")) {
        check("cho phep http loopback: '$u'", ok(u))
    }
    // ---- tu choi: http toi moi noi khac (noi dung nhay cam bi lo tren mang) ----
    for (u in listOf("http://example.com/hook", "http://192.168.1.5:8123/api/webhook/x", "http://10.0.0.2/x", "http://hooks.example.com:80/", "http://127.0.0.2/x",
        "http://127.0.0.1.evil.com/x", "http://localhost.evil.com/x", "http://evil-localhost/x", "http://0.0.0.0/x", "http://0x7f.0.0.1/x", "http://2130706433/x", "http://[::ffff:127.0.0.1]/x")) {
        check("TU CHOI http: '$u'", !ok(u))
    }
    // ---- tu choi: qua mat bo kiem tra loopback bang userinfo/dau gach/fragment (hai bo phan tich doc khac nhau) ----
    for (u in listOf("http://127.0.0.1@evil.com/x", "http://localhost@evil.com/x", "http://127.0.0.1:80@evil.com/", "http://evil.com\\@127.0.0.1/", "http://evil.com#@127.0.0.1/",
        "http://evil.com?@127.0.0.1/", "http://127.0.0.1%2f@evil.com/", "http://user@127.0.0.1@evil.com/", "http://[::1]@evil.com/", "http://127.0.0.1\\.evil.com/")) {
        check("TU CHOI (lach loopback): '$u'", !ok(u))
    }
    // ---- tu choi: dinh dang sai / scheme khac / ky tu la ----
    for (u in listOf<String?>(null, "", "   ", "example.com/x", "//example.com/x", "https://", "https:///x", "https:example.com", "ftp://example.com/x", "file:///etc/passwd", "javascript:alert(1)",
        "data:text/plain,hi", "content://x/y", "ws://example.com/", "wss://example.com/", "mailto:a@b.c", "https://exa mple.com/", "https://example.com/\nHost: evil", "https://example.com/a\tb",
        "https://example.com/\u0000", "https://exa\u200bmple.com/")) {
        check("TU CHOI (sai dinh dang/scheme khac): ${if (u == null) "null" else "'" + u.replace("\n", "\\n").replace("\t", "\\t").replace("\u0000", "\\0") + "'"}", !ok(u))
    }
    check("TU CHOI URL qua dai (> 2048 ky tu)", !ok("https://example.com/" + "a".repeat(2100)) && ok("https://example.com/" + "a".repeat(100)))
    check("hang LOOPBACK_HOSTS dung 3 host (khop network_security_config.xml)", UrlPolicy.LOOPBACK_HOSTS == setOf("127.0.0.1", "localhost", "[::1]"))

    // ---- khop network_security_config.xml (tham so 1: duong dan file) ----
    if (args.isNotEmpty()) {
        val xml = File(args[0]).readText().replace(Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL), "")   // bo chu thich: chi kiem phan cau hinh
        check("NSC: base-config cleartextTrafficPermitted=\"false\"", Regex("<base-config[^>]*cleartextTrafficPermitted=\"false\"").containsMatchIn(xml))
        val allowed = Regex("<domain[^>]*>([^<]+)</domain>").findAll(xml).map { it.groupValues[1].trim() }.toSet()
        // XML khong ghi [::1] dang ngoac vuong ma ghi ::1
        val want = UrlPolicy.LOOPBACK_HOSTS.map { it.removePrefix("[").removeSuffix("]") }.toSet()
        check("NSC: cac <domain> duoc phep cleartext KHOP DUNG UrlPolicy.LOOPBACK_HOSTS (khong them/bot): $allowed", allowed == want)
        check("NSC: khong co certificates src=\"user\" (khong tin CA nguoi dung them vao - chong MITM bang CA tu cai)", !Regex("src=\"user\"").containsMatchIn(xml))
        check("NSC: khong co cleartextTrafficPermitted=\"true\" o base-config / debug-overrides", !Regex("<base-config[^>]*cleartextTrafficPermitted=\"true\"").containsMatchIn(xml) && !xml.contains("debug-overrides"))
    }
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
