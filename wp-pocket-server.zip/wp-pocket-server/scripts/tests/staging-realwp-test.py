#!/usr/bin/env python3
"""Kiem thu DAU-CUOI _admin/staging.php voi WORDPRESS THAT + MARIADB THAT + CHINH fetch_site_source (HANDOFF.md muc 1az).

staging-realdb-test.py dung bang gia + wp-config.php GIA tu viet khop dung chuoi ma trang staging tim - nen khong
bat duoc loi khi wp-config THAT khac chuoi do. Test nay:
  * chay CHINH ham fetch_site_source (scripts/lib/site_source.sh, type=wordpress) voi 1 shim `curl` tra WordPress
    that (6.8.1) da tai san -> thu duoc cay website y het CI tao (wp-config.php.template that, mu-plugin that);
  * sinh wp-config.php bang dung lenh sed cua start-lamp.sh; cai WordPress that qua wp-admin/install.php;
  * chay vong doi clone -> sua staging bang WordPress -> promote; kiem tra staging CO CO LAP voi LIVE;
  * 2 kich ban LOI THAT: wp-config bi sua tay thanh `define( 'DB_NAME', 'wordpress' );` (staging phai TU CHOI,
    khong duoc tro nham vao DB LIVE) va wp-config staging bi sua tay truoc promote (phai DUNG truoc khi dong LIVE);
  * mu-plugin that + WP-Cron that + MariaDB that: co "defer-heavy-jobs" (B6) hoan OPTIMIZE va auto-update.
Can: mariadbd/mariadb-install-db/mariadb/mariadb-dump, php (mysqli), bash, jq, unzip va file WordPress zip
(WP_SRC_ZIP hoac /tmp/wp-test-cache/wp-src.zip; neu thieu se thu tai tu GitHub). Thieu -> bo qua (exit 0).
STAGING_PAGE=<admin-staging.php khac> de doi chung am.
"""
import importlib.util, json, os, re, shutil, socket, subprocess, sys, tempfile, time, urllib.request, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
# Chay duoc CA voi user thuong (runner CI khong phai root): mariadb-install-db --user=<chinh minh>; mariadbd khong dung --user.
import getpass
DB_OS_USER = 'root' if os.geteuid() == 0 else getpass.getuser()
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check
WP_TAG = '6.8.1'


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p


def wr(p, t):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w').write(t)


def free_port():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p


def get_wp_zip():
    p = os.environ.get('WP_SRC_ZIP') or '/tmp/wp-test-cache/wp-src.zip'
    if os.path.isfile(p): return p
    os.makedirs(os.path.dirname(p), exist_ok=True)
    try:
        urllib.request.urlretrieve('https://codeload.github.com/WordPress/WordPress/zip/refs/tags/' + WP_TAG, p)
        return p
    except Exception as e:
        print('(khong tai duoc WordPress %s: %s)' % (WP_TAG, e)); return None


def bump_object_cache_epoch(app_home):
    """Chay CHINH ham wp_pocket_bump_object_cache_epoch() cua admin-auth.php (trich theo ten, khong chep lai) voi APP_HOME cho
    truoc. Dung de mo phong BEN GHI TU NGOAI pool php-fpm (WP-CLI, Adminer, khoi phuc backup) ma san pham that su bao hieu
    cache APCu (HANDOFF.md muc 1bd). Test nao tu doi du lieu bang con duong khong qua WordPress phai goi ham nay y nhu san pham."""
    src = open(os.path.join(ROOT, 'scripts', 'runtimes', 'templates', 'admin-auth.php'), encoding='utf-8').read()
    m = re.search(r'function wp_pocket_bump_object_cache_epoch\(\): void\n\{.*?\n\}\n', src, re.S)
    f = tempfile.mktemp(suffix='-bump.php')
    open(f, 'w').write('<?php\n' + m.group(0) + '\nwp_pocket_bump_object_cache_epoch();\n')
    try: subprocess.run(['php', f], env=dict(os.environ, APP_HOME=app_home), check=True)
    finally: os.remove(f)


def get_wpcli_phar():
    """wp-cli.phar that (cache /tmp/wp-test-cache), kiem SHA-256 do kho wp-cli/builds cong bo canh tep. None neu khong tai duoc."""
    p = os.environ.get('WPCLI_PHAR') or '/tmp/wp-test-cache/wp-cli.phar'
    if os.path.isfile(p): return p
    base = 'https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar'
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        data = urllib.request.urlopen(base, timeout=60).read()
        want = urllib.request.urlopen(base + '.sha256', timeout=60).read().decode().split()[0]
        import hashlib
        if hashlib.sha256(data).hexdigest() != want: print('(wp-cli.phar sai SHA-256 - bo qua)'); return None
        open(p, 'wb').write(data); return p
    except Exception as e:
        print('(khong tai duoc wp-cli.phar: %s)' % e); return None


def apcu_active():
    # APCu mac dinh TAT voi SAPI "cli" nhung BAT voi "cli-server" (php -S, dung lam may chu trong test) va php-fpm => chi can extension duoc nap.
    r = subprocess.run(['php', '-r', 'echo extension_loaded("apcu") ? "1" : "0";'], capture_output=True, text=True)
    return r.stdout.strip() == '1'


def repack_as_latest_zip(src, dst):
    """Zip cua mirror GitHub co thu muc goc WordPress-x.y.z/; wordpress.org/latest.zip co goc 'wordpress/'."""
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(dst, 'w', zipfile.ZIP_STORED) as zo:
        for info in zi.infolist():
            name = info.filename.split('/', 1)
            if len(name) < 2 or not name[1]: continue
            zo.writestr('wordpress/' + name[1], zi.read(info.filename))


def main():
    mariadbd = which('mariadbd', 'mysqld'); install = which('mariadb-install-db', 'mysql_install_db')
    cli = which('mariadb', 'mysql'); dump = which('mariadb-dump', 'mysqldump')
    if not all((mariadbd, install, cli, dump, which('php'), which('bash'), which('jq'), which('unzip'))):
        print('(bo qua: thieu cong cu - can MariaDB that, php, bash, jq, unzip)'); return 0
    if subprocess.run(['php', '-r', 'exit(extension_loaded("mysqli")?0:1);']).returncode != 0:
        print('(bo qua: PHP khong co mysqli)'); return 0
    wpzip = get_wp_zip()
    if not wpzip: print('(bo qua: khong co WordPress zip)'); return 0

    tmp = tempfile.mkdtemp(prefix='stgwp-'); os.chmod(tmp, 0o755)
    db = srv = srv2 = None
    try:
        # ---------- 1. Chay CHINH fetch_site_source voi WordPress that ----------
        latest = os.path.join(tmp, 'latest.zip'); repack_as_latest_zip(wpzip, latest)
        shim = os.path.join(tmp, 'shim'); os.makedirs(shim)
        salts = os.path.join(tmp, 'salts.txt')
        keys = ['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT']
        wr(salts, ''.join("define('%s',%s'%s');\n" % (k, ' ' * (17 - len(k)), os.urandom(24).hex()) for k in keys))
        wr(os.path.join(shim, 'curl'), '#!/bin/sh\nout=""; url=""\nwhile [ $# -gt 0 ]; do case "$1" in -o) out="$2"; shift 2;; -*) shift;; *) url="$1"; shift;; esac; done\n'
           'case "$url" in\n  https://wordpress.org/latest.zip) cp "$WP_ZIP" "$out";;\n  https://api.wordpress.org/secret-key/1.1/salt/) cat "$SALT_FILE";;\n  *) exit 22;;\nesac\n')
        os.chmod(os.path.join(shim, 'curl'), 0o755)
        for p in ('/tmp/wp-extract', '/tmp/wordpress.zip'):  # fetch_site_source ghi cung duong dan nay
            try:
                shutil.rmtree(p, ignore_errors=True) if os.path.isdir(p) else (os.path.exists(p) and os.remove(p))
            except OSError:
                pass
        fetched = os.path.join(tmp, 'fetched')
        env = dict(os.environ, PATH=shim + ':' + os.environ['PATH'], WP_ZIP=latest, SALT_FILE=salts, SITE_CONFIG=os.path.join(ROOT, 'site.config.json'))
        r = subprocess.run(['bash', '-c', 'set -euo pipefail; source scripts/lib/site_source.sh; fetch_site_source "$1"', 'x', fetched],
                           cwd=ROOT, env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=300)
        check('fetch_site_source THAT (type=wordpress, WordPress %s that) chay xong' % WP_TAG, r.returncode == 0, r.stderr[-300:])
        check('cay website co loi WP that + wp-config.php.template + mu-plugin bao tri that',
              all(os.path.isfile(os.path.join(fetched, f)) for f in ('wp-includes/version.php', 'wp-admin/install.php', 'wp-config.php.template', 'wp-content/mu-plugins/wppocket-maintenance.php')))

        # ---------- 2. Khung app + MariaDB that ----------
        app, run, www0, adm0 = sec.build_tree(tmp)
        www = os.path.join(app, 'www')
        shutil.move(os.path.join(www0, '_admin'), os.path.join(fetched, '_admin')); shutil.rmtree(www0); shutil.move(fetched, www)
        shutil.copy(os.environ.get('STAGING_PAGE') or os.path.join(ROOT, 'scripts', 'runtimes', 'templates', 'admin-staging.php'), os.path.join(www, '_admin', 'staging.php'))
        sock = os.path.join(run, 'mysql.sock'); data = os.path.join(tmp, 'data')
        r = subprocess.run([install, '--user=' + DB_OS_USER, '--datadir=' + data, '--auth-root-authentication-method=normal'], capture_output=True, text=True)
        if r.returncode != 0: print('(bo qua: khong khoi tao duoc MariaDB: %s)' % r.stderr[-120:]); return 0
        db = subprocess.Popen([mariadbd] + ([] if os.geteuid() != 0 else ['--user=root']) + ['--datadir=' + data, '--socket=' + sock, '--skip-networking', '--pid-file=' + os.path.join(tmp, 'm.pid'),
                               '--innodb-buffer-pool-size=64M', '--log-error=' + os.path.join(tmp, 'err.log')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            if os.path.exists(sock) and subprocess.run([cli, '--socket=' + sock, '-uroot', '-e', 'select 1'], capture_output=True).returncode == 0: break
            time.sleep(0.5)
        else:
            print('(bo qua: mariadbd khong len)'); return 0

        def sql(q, dbname=None):
            cmd = [cli, '--socket=' + sock, '--default-character-set=utf8mb4', '-uroot', '-N', '-B', '-e', q]
            if dbname: cmd.append(dbname)
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0 and 'Unknown database' not in r.stderr: print('   [sql loi] %s -> %s' % (q[:60], r.stderr.strip()[:120]))
            return r.stdout.strip()
        sql("CREATE DATABASE wordpress CHARACTER SET utf8mb4")
        sql("CREATE USER 'wordpress'@'localhost' IDENTIFIED BY 'wordpress'")
        sql("GRANT ALL ON `wordpress%`.* TO 'wordpress'@'localhost'")
        live = lambda q: sql(q, 'wordpress')
        stg = lambda q: sql(q, 'wordpress_staging')

        # wp-config.php that: dung CHINH lenh sed cua start-lamp.sh (dong 508-513)
        tpl = os.path.join(www, 'wp-config.php.template')
        cfg_live = open(tpl).read().replace('__MYSQL_SOCK__', sock)
        wr(os.path.join(www, 'wp-config.php'), cfg_live); os.chmod(os.path.join(www, 'wp-config.php'), 0o600); os.remove(tpl)
        check("wp-config.php THAT cua du an co DUNG 2 chuoi ma staging tim (neu lech: staging tro nham vao DB LIVE)",
              "define('DB_NAME', 'wordpress');" in cfg_live and "require_once ABSPATH . 'wp-settings.php';" in cfg_live)

        ext = os.path.join(tmp, 'ext-db'); os.makedirs(ext)
        os.symlink(cli, os.path.join(ext, 'libmysqlcli.so')); os.symlink(dump, os.path.join(ext, 'libmysqldump.so'))
        # Chi cho TEST: tat WP-Cron (khong lam bang DB doi giua 2 lan do) + chan HTTP ra ngoai (khong co mang)
        wr(os.path.join(tmp, 'spoof.php'), "<?php if (isset($_SERVER['HTTP_X_TEST_IP'])) { $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_X_TEST_IP']; }\n"
           "if (!defined('DISABLE_WP_CRON')) define('DISABLE_WP_CRON', true);\nif (!defined('WP_HTTP_BLOCK_EXTERNAL')) define('WP_HTTP_BLOCK_EXTERNAL', true);\n")
        penv = dict(os.environ, APP_HOME=app, EXT_DIR=ext, STAGING_PORT='18999')

        def serve(root, port):
            p = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', root, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
                                  '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=0'],
                                 env=penv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            for _ in range(100):
                try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
                except OSError: time.sleep(0.1)
            return p
        port = free_port(); srv = serve(www, port)
        live_url = 'http://127.0.0.1:%d' % port

        def bump_epoch():
            bump_object_cache_epoch(app)

        def wp(root, host, code, extra_env=None, bump=True):
            # `wp()` DONG VAI WP-CLI (tien trinh CLI rieng). Trong san pham WP-CLI chi chay qua _admin/wpcli.php, trang do
            # bump epoch luc ket thuc (HANDOFF.md muc 1bd) - nen helper nay bump y nhu vay. bump=False de DOI CHUNG.
            """Chay ma PHP TRONG WordPress that (wp-load.php) cua cay `root`, tra stdout."""
            f = os.path.join(tmp, 'wpcli.php')
            wr(f, "<?php $_SERVER['HTTP_HOST']=%s; $_SERVER['REQUEST_URI']='/'; $_SERVER['REQUEST_METHOD']='GET';\n"
                  "define('DISABLE_WP_CRON', true); define('WP_USE_THEMES', false); define('WP_HTTP_BLOCK_EXTERNAL', true); define('SAVEQUERIES', true);\n"
                  "require %s;\n%s\n" % (json.dumps(host), json.dumps(os.path.join(root, 'wp-load.php')), code))
            r = subprocess.run(['php', '-d', 'display_errors=0', '-d', 'memory_limit=512M', f], env=dict(penv, **(extra_env or {})), capture_output=True, text=True, timeout=120)
            if bump: bump_epoch()
            return r.stdout.strip() if r.returncode == 0 else 'PHP-LOI: ' + (r.stdout + r.stderr)[-300:]

        # ---------- 3. Cai WordPress THAT qua wp-admin/install.php ----------
        wpc = sec.Client(port, '10.3.3.3')
        wpc.req('GET', '/wp-admin/install.php?step=1')
        sc, body, _ = wpc.req('POST', '/wp-admin/install.php?step=2', {'weblog_title': 'Trang That Tieng Viet', 'user_name': 'admin', 'admin_password': 'Pa55-w0rd-Test-9876!',
                                                                     'admin_password2': 'Pa55-w0rd-Test-9876!', 'pw_weak': '1', 'admin_email': 'a@example.com', 'blog_public': '0', 'Submit': 'Install WordPress', 'language': ''})
        n_tables = live("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='wordpress'")
        check('cai WordPress that qua HTTP: DB co du 12 bang cua WP 6.8 (dang co %s)' % n_tables, n_tables == '12', body[-250:])
        check('siteurl trong DB = URL that cua may chu (%s)' % live_url, live("SELECT option_value FROM wp_options WHERE option_name='siteurl'") == live_url)
        out = wp(www, '127.0.0.1:%d' % port, "$id = wp_insert_post(['post_title'=>'Bài viết thật số một','post_content'=>'Nội dung 😀','post_status'=>'publish']); echo $id;")
        check('tao bai viet bang wp_insert_post cua WordPress that', out.isdigit(), out)
        sc, body, _ = sec.Client(port, '10.3.3.4').req('GET', '/')
        check('trang chu LIVE tra 200 va hien ten site + bai viet that', sc == 200 and 'Trang That Tieng Viet' in body and 'Bài viết thật số một' in body, (sc, body[:200]))

        c = sec.Client(port, '10.2.2.2'); c.login()
        staging = os.path.join(app, 'www-staging'); safety = os.path.join(app, 'staging-safety-backups')

        def act(action):
            tok = c.token('staging')
            return c.req('POST', '/_admin/staging.php', {'action': action, 'csrf_token': tok})[1]
        def checksum_all(dbname):
            tabs = sql("SHOW TABLES", dbname).split()
            return sorted(x.split('\t')[1] for x in sql("CHECKSUM TABLE " + ','.join(tabs), dbname).splitlines()) if tabs else []
        cfg_path = os.path.join(www, 'wp-config.php')

        print('== 4. clone: staging co CO LAP voi LIVE (WordPress that) ==')
        before_cfg = open(cfg_path).read()
        body = act('clone')
        check('clone: bao "Da tao xong ban staging"', 'Da tao xong ban staging' in body and os.path.isdir(staging), body[-300:])
        check('clone: moi bang cua DB staging co CHECKSUM trung LIVE (12 bang WP that)', checksum_all('wordpress_staging') == checksum_all('wordpress') and len(checksum_all('wordpress')) == 12)
        scfg = open(os.path.join(staging, 'wp-config.php')).read() if os.path.isfile(os.path.join(staging, 'wp-config.php')) else ''
        check("clone: wp-config staging tro DB_NAME=wordpress_staging va DB LIVE cua wp-config LIVE khong doi", "define('DB_NAME', 'wordpress_staging');" in scfg and open(cfg_path).read() == before_cfg)
        check('clone: muoi (AUTH_KEY...) cua staging GIONG LIVE (khong lam dang nhap that bi vo hieu)', re.search(r"define\('AUTH_KEY'.*", scfg) and re.search(r"define\('AUTH_KEY'.*", scfg).group(0) == re.search(r"define\('AUTH_KEY'.*", before_cfg).group(0))
        check('clone: WP_HOME/WP_SITEURL dong chen DUNG 1 lan, truoc wp-settings.php', scfg.count('__WP_POCKET_STAGING_DYNAMIC_URL__') == 1 and scfg.index("define('WP_HOME'") < scfg.index("require_once ABSPATH . 'wp-settings.php';"))
        port2 = free_port(); srv2 = serve(staging, port2)
        host2 = '127.0.0.1:%d' % port2
        check('staging chay duoc bang WordPress that: home_url() = host dang truy cap (dong theo host), DB siteurl van la URL LIVE',
              wp(staging, host2, 'echo home_url();') == 'http://' + host2 and stg("SELECT option_value FROM wp_options WHERE option_name='siteurl'") == live_url)
        sc, body, _ = sec.Client(port2, '10.3.3.5').req('GET', '/')
        check('trang chu STAGING tra 200, hien bai viet nhan ban + KHONG tro ve URL LIVE', sc == 200 and 'Bài viết thật số một' in body and live_url not in body and host2 in body, (sc, live_url in body, host2 in body))

        print('== 5. sua staging bang WordPress that -> LIVE KHONG bi anh huong ==')
        live_blog0 = live("SELECT option_value FROM wp_options WHERE option_name='blogname'"); live_posts0 = live("SELECT COUNT(*) FROM wp_posts WHERE post_type='post'")
        wp(staging, host2, "update_option('blogname','Ten Staging Moi'); wp_insert_post(['post_title'=>'Bài chỉ có ở staging','post_status'=>'publish']);")
        check('sua o staging: DB staging doi that', stg("SELECT option_value FROM wp_options WHERE option_name='blogname'") == 'Ten Staging Moi')
        check('CO LAP: DB LIVE KHONG doi (ten site + so bai viet)', live("SELECT option_value FROM wp_options WHERE option_name='blogname'") == live_blog0 and live("SELECT COUNT(*) FROM wp_posts WHERE post_type='post'") == live_posts0)
        wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEW')

        print('== 6. promote -> LIVE (WordPress that) ==')
        body = act('promote')
        check('promote: bao "Da promote xong"', 'Da promote xong' in body, body[-300:])
        check('promote: DB LIVE nhan ten moi + bai viet moi', live("SELECT option_value FROM wp_options WHERE option_name='blogname'") == 'Ten Staging Moi' and live("SELECT COUNT(*) FROM wp_posts WHERE post_type='post'") == str(int(live_posts0) + 1))
        lcfg = open(cfg_path).read()
        check("promote: wp-config LIVE ve DB_NAME=wordpress, het dong WP_HOME dong, muoi KHONG doi", "define('DB_NAME', 'wordpress');" in lcfg and 'WP_POCKET_STAGING' not in lcfg and 'WP_HOME' not in lcfg
              and re.search(r"define\('AUTH_KEY'.*", lcfg).group(0) == re.search(r"define\('AUTH_KEY'.*", before_cfg).group(0))
        check('promote: file LIVE = staging, don staging (thu muc + DB)', open(os.path.join(www, 'MARKER.txt')).read() == 'STAGING-NEW' and not os.path.exists(staging) and stg('SELECT 1') == '')
        check('promote: siteurl trong DB LIVE van la URL LIVE (khong nhiem URL staging)', live("SELECT option_value FROM wp_options WHERE option_name='siteurl'") == live_url)
        sc, body, _ = sec.Client(port, '10.3.3.6').req('GET', '/')
        check('sau promote: trang chu LIVE 200, hien ten moi + bai moi (WordPress that chay tren DB LIVE)', sc == 200 and 'Ten Staging Moi' in body and 'Bài chỉ có ở staging' in body, (sc, body[:160]))
        w2 = sec.Client(port, '10.3.3.7'); w2.req('GET', '/wp-login.php')
        w2.jar['wordpress_test_cookie'] = 'WP%20Cookie%20check'
        sc, _, loc = w2.req('POST', '/wp-login.php', {'log': 'admin', 'pwd': 'Pa55-w0rd-Test-9876!', 'wp-submit': 'Log In', 'redirect_to': live_url + '/wp-admin/', 'testcookie': '1'})
        check('sau promote: dang nhap wp-login.php that van duoc (mat khau bam + muoi con nguyen) -> 302 toi wp-admin', sc == 302 and loc and 'wp-admin' in loc, (sc, loc))
        dumps = [f for f in os.listdir(safety) if f.startswith('pre-promote-db-')]
        check('promote: co ban an toan DB truoc khi ghi de', len(dumps) == 1)
        if dumps:
            sql("CREATE DATABASE wordpress_restorecheck CHARACTER SET utf8mb4")
            rr = subprocess.run([cli, '--socket=' + sock, '-uroot', 'wordpress_restorecheck'], stdin=open(os.path.join(safety, dumps[0])), capture_output=True, text=True)
            check('ban an toan KHOI PHUC DUOC that: ra ten site GOC', rr.returncode == 0 and sql("SELECT option_value FROM wp_options WHERE option_name='blogname'", 'wordpress_restorecheck') == live_blog0, rr.stderr[-200:])

        print('== 6b. Dump cua GOI DI CHUYEN (dung dung co cua BackupManager.buildPortableExportLocked) tren DB WordPress that ==')
        pdump = os.path.join(tmp, 'portable.sql')
        rr = subprocess.run([dump, '--socket=' + sock, '-uroot', '--single-transaction', '--quick', '--lock-tables=false', '--default-character-set=utf8mb4', 'wordpress'],
                            stdout=open(pdump, 'wb'), stderr=subprocess.PIPE)
        text = open(pdump, encoding='utf-8', errors='replace').read()
        tail = open(pdump, 'rb').read()[-2048:].decode('utf-8', 'replace')
        check('dump portable: KHONG co CREATE DATABASE / USE (nap duoc vao DB ten bat ky tren hosting khac)', rr.returncode == 0 and not re.search(r'^CREATE DATABASE', text, re.M | re.I) and not re.search(r'^USE `', text, re.M), rr.stderr[-200:])
        check('dump portable: dong "-- Dump completed" nam trong 2048 byte cuoi (BackupLogic.dumpLooksComplete dua vao day)', '-- Dump completed' in tail)
        m = re.search(r"'siteurl','((?:[^'\\]|\\.|'')*)'", text)
        check("dump portable: tim thay option siteurl bang dung dang regex cua BackupLogic.findOptionInDump va = URL that", bool(m) and m.group(1) == live_url, m.group(1) if m else None)
        check('dump portable: tien to bang that la wp_ (README goi se huong dan dat $table_prefix)', 'CREATE TABLE `wp_options`' in text and re.search(r"\$table_prefix\s*=\s*'wp_'", open(cfg_path).read()) is not None)
        if os.environ.get('KEEP_DUMP'): shutil.copy(pdump, os.environ['KEEP_DUMP'])  # de kiem cheo BackupLogic (Kotlin) tren dump that

        print('== 7. LOI THAT: wp-config bi sua tay thanh dinh dang KHAC (khoang trang) ==')
        good_cfg = open(cfg_path).read()
        wr(cfg_path, good_cfg.replace("define('DB_NAME', 'wordpress');", "define( 'DB_NAME', 'wordpress' );"))
        spaced = open(cfg_path).read()
        live_sum = checksum_all('wordpress')
        body = act('clone')
        check('wp-config LIVE sai dinh dang -> staging TU CHOI (khong tao ban tro nham vao DB LIVE)', not os.path.exists(staging) and 'Da tao xong ban staging' not in body, body[-300:])
        check('  ... khong co DB wordpress_staging mo coi, wp-config LIVE va DB LIVE khong doi', stg('SELECT 1') == '' and open(cfg_path).read() == spaced and checksum_all('wordpress') == live_sum)
        wr(cfg_path, good_cfg)

        print('== 8. LOI THAT: wp-config STAGING bi sua tay truoc promote ==')
        act('clone')
        scfg_path = os.path.join(staging, 'wp-config.php')
        wr(scfg_path, open(scfg_path).read().replace("define('DB_NAME', 'wordpress_staging');", "define( 'DB_NAME', 'wordpress_staging' );"))
        live_sum = checksum_all('wordpress'); marker_before = open(os.path.join(www, 'MARKER.txt')).read(); wr(os.path.join(staging, 'MARKER.txt'), 'SHOULD-NOT-PROMOTE')
        body = act('promote')
        check('wp-config staging sai dinh dang -> promote DUNG, khong noi "Da promote xong"', 'Da promote xong' not in body, body[-300:])
        check('  ... DB LIVE + file LIVE khong bi dong, staging van con de sua', checksum_all('wordpress') == live_sum and open(os.path.join(www, 'MARKER.txt')).read() == marker_before and os.path.isdir(staging) and not os.path.exists(www + '.promote-new'))
        check("  ... wp-config LIVE van tro DB wordpress (khong bi doi sang DB staging)", "define('DB_NAME', 'wordpress');" in open(cfg_path).read())
        act('discard')  # don dep de phan 9 khong bi anh huong

        print('== 9. B6 dau-cuoi: mu-plugin THAT + WP-Cron THAT + MariaDB THAT ==')
        flag = os.path.join(run, 'defer-heavy-jobs'); hook = 'wppocket_db_maintenance'; host = '127.0.0.1:%d' % port
        cron_dump = ("$o=[]; foreach ((array)_get_cron_array() as $ts=>$hs) if (isset($hs['%s'])) foreach ($hs['%s'] as $e) $o[]=['delta'=>$ts-time(),'schedule'=>$e['schedule']]; echo json_encode($o);" % (hook, hook))
        probe = ("global $wpdb; $wpdb->queries = []; do_action('%s'); $o = 0; foreach ($wpdb->queries as $q) { if (stripos($q[0], 'OPTIMIZE TABLE') === 0) $o++; }\n"
                 "echo json_encode(['optimize'=>$o, 'core'=>apply_filters('auto_update_core', true), 'plugin'=>apply_filters('auto_update_plugin', true)]);" % hook)
        reset = "wp_clear_scheduled_hook('%s');" % hook
        if os.path.exists(flag): os.remove(flag)
        wp(www, host, reset)
        r1 = json.loads(wp(www, host, probe))
        check('khong co co: bao tri DB chay OPTIMIZE TABLE that tren MariaDB that, auto-update di qua', r1['optimize'] >= 10 and r1['core'] is True and r1['plugin'] is True, r1)
        wr(flag, '1')
        r2 = json.loads(wp(www, host, probe))
        check('co "defer-heavy-jobs" moi: KHONG OPTIMIZE; auto_update_core/plugin tra false', r2['optimize'] == 0 and r2['core'] is False and r2['plugin'] is False, r2)
        ev = json.loads(wp(www, host, cron_dump))
        check('  ... WP-Cron that luu 1 su kien don (schedule=false) hen thu lai ~1 gio sau', any(e['schedule'] is False and 3400 <= e['delta'] <= 3700 for e in ev), ev)

        # URL cron LAY TU CHINH start-lamp.sh (khong tu viet lai): neu script goi sai kieu thi test do theo dung cai do.
        sl = open(os.path.join(ROOT, 'scripts', 'runtimes', 'templates', 'start-lamp.sh'), encoding='utf-8').read()
        # Lenh goi that nam trong file_get_contents("http://127.0.0.1:<PORT>/wp-cron.php...") (KHONG phai dong kiem tra -f wp-cron.php)
        mcr = re.search(r'127\.0\.0\.1:[^/]*?(/wp-cron\.php[A-Za-z0-9_=&.?]*)', sl)
        check('start-lamp.sh co lenh goi wp-cron.php qua http://127.0.0.1:PORT (de trich URL that)', bool(mcr))
        cron_url = mcr.group(1) if mcr else '/wp-cron.php'
        print('   URL cron cua start-lamp.sh = %s' % cron_url)
        # Duong WP-Cron THAT (qua HTTP wp-cron.php, y nhu vong lap trong start-lamp.sh): su kien dinh ky den han khi co dang bat
        wp(www, host, reset + "wp_schedule_event(time()-30, 'wppocket_weekly', '%s');" % hook)
        sc, _, _ = sec.Client(port, '10.3.3.9').req('GET', cron_url)
        ev = json.loads(wp(www, host, cron_dump))
        singles = [e for e in ev if e['schedule'] is False]; recurring = [e for e in ev if e['schedule'] == 'wppocket_weekly']
        check('WP-Cron THAT qua URL cua start-lamp.sh khi co dang bat: dung 1 su kien don +1h VA su kien dinh ky da dat lai ~7 ngay (khong chong chat)',
              sc == 200 and len(singles) == 1 and 3400 <= singles[0]['delta'] <= 3700 and len(recurring) == 1 and 6 * 86400 <= recurring[0]['delta'] <= 8 * 86400, (sc, ev))
        os.remove(flag)
        wp(www, host, reset + "wp_schedule_event(time()-30, 'wppocket_weekly', '%s');" % hook)
        sec.Client(port, '10.3.3.9').req('GET', cron_url)
        ev = json.loads(wp(www, host, cron_dump))
        rec = [e for e in ev if e['schedule'] == 'wppocket_weekly']
        check('WP-Cron THAT qua URL cua start-lamp.sh khi KHONG co co: su kien den han DUOC CHAY va dat lai ~7 ngay (khong sinh su kien don)',
              [e for e in ev if e['schedule'] is False] == [] and len(rec) == 1 and 6 * 86400 <= rec[0]['delta'] <= 8 * 86400, ev)

        wr(flag, '1'); t = time.time() - 3 * 3600; os.utime(flag, (t, t))
        r3 = json.loads(wp(www, host, probe))
        check('co CU 3 gio (app khong con cap nhat): fail-open, OPTIMIZE chay lai, filter di qua', r3['optimize'] >= 10 and r3['core'] is True, r3)

        # ---------- H. 1bd: cache APCu + WP-CLI THAT qua _admin/wpcli.php ----------
        print('== H. cache APCu khong de site hien du lieu CU sau khi WP-CLI/Adminer/khoi phuc doi du lieu (HANDOFF.md muc 1bd) ==')
        phar = get_wpcli_phar()
        if not phar or not apcu_active():
            print('(BO QUA muc H: %s - muc nay KHONG duoc tinh la da kiem)' % ('khong co wp-cli.phar' if not phar else 'php khong co APCu - cai php-apcu'))
        else:
            os.symlink(shutil.which('php'), os.path.join(ext, 'libphpcli.so')); shutil.copy(phar, os.path.join(ext, 'wp-cli.phar'))
            home = lambda: sec.Client(port, '10.3.3.4').req('GET', '/')[1]
            home()    # lam nong cache (APCu cua may chu da giu danh sach bai viet hien tai)
            # DOI CHUNG: chay WP-CLI THAT khong qua trang quan tri (nhu tien trinh ngoai khac) -> trang chu van hien du lieu CU.
            rc = subprocess.run(['php', phar, 'post', 'create', '--post_title=BaiTrucTiepQuaCLI', '--post_status=publish', '--path=' + www, '--porcelain'], env=penv, capture_output=True, text=True)
            check('DOI CHUNG: WP-CLI that tao bai viet (khong qua trang quan tri)', rc.returncode == 0 and rc.stdout.strip().isdigit(), (rc.stdout + rc.stderr)[-200:])
            check('DOI CHUNG: ... nhung trang chu (APCu cua may chu) CHUA thay bai do - day chinh la LOI 1bd co that trong moi truong nay', 'BaiTrucTiepQuaCLI' not in home())
            # DUONG SAN PHAM: lenh qua trang wpcli.php (bump epoch luc ket thuc) -> trang chu phai moi hoan toan
            wc = sec.Client(port, '10.3.3.10'); check('dang nhap _admin/ de dung wpcli.php', wc.login())
            tok = wc.token('wpcli')
            out = wc.req('POST', '/_admin/wpcli.php', {'cmd': 'post create --post_title=BaiQuaTrangWpcli --post_status=publish', 'csrf_token': tok})[1]
            check('wpcli.php chay WP-CLI that va tao bai (Success)', 'Success' in out, re.sub(r'<[^>]+>', ' ', out)[-300:])
            body = home()
            check('SAU lenh qua wpcli.php: trang chu hien bai moi do lenh do tao', 'BaiQuaTrangWpcli' in body)
            check('  ... VA ca bai tao truc tiep truoc do (cache bi xoa het chu khong chi 1 muc)', 'BaiTrucTiepQuaCLI' in body)
            tok = wc.token('wpcli')
            wc.req('POST', '/_admin/wpcli.php', {'cmd': 'option update blogname TenMoiQuaWpcli', 'csrf_token': tok})
            check('wp option update blogname qua wpcli.php: tieu de site doi NGAY tren trang chu', 'TenMoiQuaWpcli' in home())
            # Cau noi dung tinh nang: file epoch do CHINH trang tao ra
            check('file lamp-run/object-cache-epoch da duoc tao boi trang (khong phai test)', os.path.isfile(os.path.join(app, 'lamp-run', 'object-cache-epoch')))
    finally:
        for pr in (srv, srv2, db):
            if pr:
                pr.terminate()
                try: pr.wait(timeout=15)
                except Exception: pr.kill()
        shutil.rmtree(tmp, ignore_errors=True)
        for p in ('/tmp/wp-extract',): shutil.rmtree(p, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL))
    return 0 if sec.FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
