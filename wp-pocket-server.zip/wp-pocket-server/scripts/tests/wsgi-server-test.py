#!/usr/bin/env python3
"""H2 (PDF 1; HANDOFF.md muc 1bq-C): kiem chung may chu WSGI tu viet (scripts/runtimes/wpp_wsgi.py) bang HTTP THAT tren Python that.

Khong gia lap: mo may chu that tren cong ngau nhien (127.0.0.1), gui yeu cau bang http.client / socket tho, doi chieu phan hoi;
chay lenh that (subprocess) de kiem SIGTERM, loi nap ung dung, cong bi chiem. Phan nginx phia truoc KHONG co o day (khong co nginx).
"""
import contextlib, hashlib, http.client, importlib.util, io, json, os, signal, socket, subprocess, sys, tempfile, textwrap, threading, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRV = os.path.join(ROOT, "scripts", "runtimes", "wpp_wsgi.py")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, extra)


spec = importlib.util.spec_from_file_location("wpp_wsgi", SRV)
W = importlib.util.module_from_spec(spec)
sys.modules["wpp_wsgi"] = W
spec.loader.exec_module(W)

APP_SRC = textwrap.dedent('''
    import hashlib, json, threading, time
    CALLS = {"n": 0}
    CLOSED = {"n": 0}

    class Closing(object):
        def __init__(self, parts): self.parts = parts
        def __iter__(self): return iter(self.parts)
        def close(self): CLOSED["n"] += 1

    def app(environ, start_response):
        CALLS["n"] += 1
        path = environ["PATH_INFO"]
        if path == "/hello":
            body = b"xin chao"
            start_response("200 OK", [("Content-Type", "text/plain"), ("Content-Length", str(len(body)))])
            return [body]
        if path.startswith("/env"):
            keys = ["REQUEST_METHOD", "PATH_INFO", "QUERY_STRING", "SCRIPT_NAME", "SERVER_PROTOCOL", "CONTENT_TYPE", "CONTENT_LENGTH", "HTTP_HOST", "REMOTE_ADDR", "wsgi.url_scheme", "wsgi.multithread"]
            d = {k: environ.get(k) for k in keys}
            body = json.dumps(d).encode()
            start_response("200 OK", [("Content-Type", "application/json"), ("Content-Length", str(len(body)))])
            return [body]
        if path == "/echo-sha":
            n = int(environ.get("CONTENT_LENGTH") or 0)
            data = environ["wsgi.input"].read(n)
            body = json.dumps({"len": len(data), "sha": hashlib.sha256(data).hexdigest()}).encode()
            start_response("200 OK", [("Content-Type", "application/json")])
            return [body]
        if path == "/read-all":
            data = environ["wsgi.input"].read()
            lines = environ["wsgi.input"].readline()
            start_response("200 OK", [("Content-Type", "text/plain")])
            return [str(len(data)).encode() + b"|" + str(len(lines)).encode()]
        if path == "/stream":
            start_response("200 OK", [("Content-Type", "text/plain")])
            return Closing([b"a" * 1000, b"b" * 1000, b"c" * 1000])
        if path == "/boom":
            raise RuntimeError("loi gia lap truoc khi gui header")
        if path == "/boom-mid":
            start_response("200 OK", [("Content-Type", "text/plain")])
            def gen():
                yield b"mot phan"
                raise RuntimeError("loi giua chung")
            return gen()
        if path == "/slow":
            time.sleep(float(environ.get("QUERY_STRING") or "0.3"))
            start_response("200 OK", [("Content-Type", "text/plain")])
            return [b"cham"]
        if path == "/big":
            body = b"z" * 3000000
            start_response("200 OK", [("Content-Type", "application/octet-stream"), ("Content-Length", str(len(body)))])
            return [body]
        if path == "/head" and environ["REQUEST_METHOD"] == "HEAD":
            start_response("200 OK", [("Content-Type", "text/plain"), ("Content-Length", "5")])
            return []
        start_response("404 Not Found", [("Content-Type", "text/plain")])
        return [b"khong co"]

    def create_app():
        return app

    class Holder(object):
        app = staticmethod(app)

    holder = Holder()
    not_callable = 42
''')

tmp = tempfile.mkdtemp()
with open(os.path.join(tmp, "wsgi_testapp.py"), "w") as f:
    f.write(APP_SRC)
sys.path.insert(0, tmp)
os.chdir(tmp)
import wsgi_testapp as T


def start(**kw):
    server = W.make_server(W.load_app("wsgi_testapp:app"), host="127.0.0.1", port=0, **kw)
    port = server.server_address[1]
    th = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True)
    th.start()
    return server, port, th


def stop(server, th):
    server.shutdown()
    server.server_close()
    th.join(5)


def req(port, method, path, body=None, headers=None, timeout=10):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=timeout)
    c.request(method, path, body=body, headers=headers or {})
    r = c.getresponse()
    data = r.read()
    out = (r.status, dict((k.lower(), v) for k, v in r.getheaders()), data)
    c.close()
    return out


def raw(port, payload, read_all=True, timeout=5):
    s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
    s.sendall(payload)
    chunks = []
    try:
        while True:
            d = s.recv(65536)
            if not d:
                break
            chunks.append(d)
            if not read_all:
                break
    except socket.timeout:
        pass
    s.close()
    return b"".join(chunks)


srv, port, th = start(threads=16, timeout=5, max_body_mb=2, trust_proxy=False)

# ---------------------------------------------------------------- 1. co ban
st, hd, body = req(port, "GET", "/hello")
check("GET /hello: 200, dung noi dung, Content-Length, Date, Server", st == 200 and body == b"xin chao" and hd.get("content-length") == "8" and "date" in hd and "server" in hd)
check("phan hoi co 'Connection: close' (may chu dong ket noi sau moi yeu cau, noi ro)", hd.get("connection") == "close")
st, hd, body = req(port, "GET", "/khong-co")
check("404 cua ung dung duoc chuyen nguyen ven", st == 404 and body == b"khong co\n".replace(b"\n", b"") or body == b"khong co")
st, hd, body = req(port, "HEAD", "/head")
check("HEAD: ung dung quyet dinh (Content-Length 5, khong co body)", st == 200 and hd.get("content-length") == "5" and body == b"")

# ---------------------------------------------------------------- 2. environ theo PEP 3333
st, hd, body = req(port, "POST", "/env%20x/a%2Fb?x=1&y=%C3%A1", body=b"abc", headers={"Content-Type": "text/plain", "Host": "example.test"})
e = json.loads(body)
check("environ: METHOD/PATH_INFO giai ma phan tram/QUERY_STRING giu nguyen/SCRIPT_NAME rong/SERVER_PROTOCOL/CONTENT_*/HTTP_HOST",
      e["REQUEST_METHOD"] == "POST" and e["PATH_INFO"] == "/env x/a/b" and e["QUERY_STRING"] == "x=1&y=%C3%A1" and e["SCRIPT_NAME"] == "" and e["SERVER_PROTOCOL"].startswith("HTTP/1.") and e["CONTENT_TYPE"] == "text/plain" and e["CONTENT_LENGTH"] == "3" and e["HTTP_HOST"] == "example.test", str(e))
check("environ: wsgi.url_scheme=http, wsgi.multithread=True, REMOTE_ADDR=127.0.0.1", e["wsgi.url_scheme"] == "http" and e["wsgi.multithread"] is True and e["REMOTE_ADDR"] == "127.0.0.1")

# ---------------------------------------------------------------- 3. body
payload = os.urandom(1000000)
st, hd, body = req(port, "POST", "/echo-sha", body=payload)
r = json.loads(body)
check("POST 1 MB: ung dung doc dung tung byte (sha256 khop)", st == 200 and r["len"] == len(payload) and r["sha"] == hashlib.sha256(payload).hexdigest())
t0 = time.time()
st, hd, body = req(port, "POST", "/read-all", body=b"x" * 5000, timeout=5)
check("wsgi.input.read() KHONG tham so tra dung 5000 byte roi het (khong treo cho khach dong ket noi)", st == 200 and body == b"5000|0" and time.time() - t0 < 2, body)
t0 = time.time()
st, hd, body = req(port, "GET", "/read-all", timeout=5)
check("GET khong body: read() tra ngay b'' (khong treo)", st == 200 and body == b"0|0" and time.time() - t0 < 2)

# ---------------------------------------------------------------- 4. streaming + close()
c0 = T.CLOSED["n"]
st, hd, body = req(port, "GET", "/stream")
time.sleep(0.1)
check("phan hoi dang iterator nhieu manh: du 3000 byte dung thu tu; server goi close() cua iterator (PEP 3333)", st == 200 and body == b"a" * 1000 + b"b" * 1000 + b"c" * 1000 and T.CLOSED["n"] == c0 + 1)
st, hd, body = req(port, "GET", "/big", timeout=15)
check("phan hoi lon 3 MB nguyen ven", st == 200 and len(body) == 3000000 and body == b"z" * 3000000)

# ---------------------------------------------------------------- 5. loi cua ung dung
err = io.StringIO()
with contextlib.redirect_stderr(err):
    st, hd, body = req(port, "GET", "/boom")
check("ung dung nem loi truoc khi gui header -> 500 (khong sap may chu)", st == 500)
check("traceback ghi ra stderr (de nguoi dung thay trong nhat ky app)", "loi gia lap truoc khi gui header" in err.getvalue() and "Traceback" in err.getvalue(), err.getvalue()[:200])
err = io.StringIO()
with contextlib.redirect_stderr(err):
    try:
        st, hd, body = req(port, "GET", "/boom-mid")
    except Exception:
        st = None
check("loi GIUA luong phan hoi: may chu khong sap, tiep tuc phuc vu", req(port, "GET", "/hello")[0] == 200)

# ---------------------------------------------------------------- 6. gioi han body / chunked / header sai
n0 = T.CALLS["n"]
st, hd, body = req(port, "POST", "/echo-sha", body=b"y" * (3 * 1024 * 1024))
check("body 3 MB > gioi han 2 MB -> 413, ung dung KHONG bi goi", st == 413 and T.CALLS["n"] == n0)
r = raw(port, b"POST /echo-sha HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nhello\r\n0\r\n\r\n")
check("body chunked -> 411 Length Required, ung dung KHONG bi goi", r.startswith((b"HTTP/1.1 411", b"HTTP/1.0 411")) and T.CALLS["n"] == n0)
r = raw(port, b"POST /echo-sha HTTP/1.1\r\nHost: x\r\nContent-Length: abc\r\n\r\n")
check("Content-Length khong phai so -> 400", r.startswith((b"HTTP/1.1 400", b"HTTP/1.0 400")) and T.CALLS["n"] == n0)
r = raw(port, b"POST /echo-sha HTTP/1.1\r\nHost: x\r\nContent-Length: -5\r\n\r\n")
check("Content-Length am -> 400", r.startswith((b"HTTP/1.1 400", b"HTTP/1.0 400")) and T.CALLS["n"] == n0)
r = raw(port, b"GARBAGE\r\n\r\n")
check("dong yeu cau rac -> 400 (http.server tra trang loi, khong co dong trang thai vi khong co phien ban HTTP), may chu song", (b" 400 " in r.split(b"\r\n")[0] or b"Error code: 400" in r) and req(port, "GET", "/hello")[0] == 200, r[:80])
r = raw(port, b"GET /" + b"a" * 70000 + b" HTTP/1.1\r\nHost: x\r\n\r\n")
check("URL 70 KB -> 414 (khong cap phat vo han), may chu song", b" 414 " in r.split(b"\r\n")[0] and req(port, "GET", "/hello")[0] == 200)
r = raw(port, b"GET /hello HTTP/1.1\r\nHost: x\r\n" + b"X-Pad: " + b"b" * 70000 + b"\r\n\r\n")
check("header 70 KB -> bi tu choi (4xx), may chu song", (b" 431 " in r.split(b"\r\n")[0] or b" 400 " in r.split(b"\r\n")[0]) and req(port, "GET", "/hello")[0] == 200, r[:60])

# ---------------------------------------------------------------- 7. khach hu / ngat ket noi
err = io.StringIO()
with contextlib.redirect_stderr(err):
    for _ in range(5):
        s = socket.create_connection(("127.0.0.1", port))
        s.sendall(b"GET /big HTTP/1.1\r\nHost: x\r\n\r\n")
        s.recv(100)
        s.close()  # ngat giua chung khi dang nhan 3 MB
    time.sleep(0.5)
check("5 khach ngat ket noi giua luc nhan phan hoi lon: may chu song va KHONG xa traceback vo ich ra stderr", req(port, "GET", "/hello")[0] == 200 and "Traceback" not in err.getvalue(), err.getvalue()[:300])
stop(srv, th)

# ---------------------------------------------------------------- 8. da luong that + gioi han luong (503)
srv, port, th = start(threads=16, timeout=5)
t0 = time.time()
res = []
ths = [threading.Thread(target=lambda: res.append(req(port, "GET", "/slow?0.5")[0])) for _ in range(12)]
[t.start() for t in ths]
[t.join() for t in ths]
el = time.time() - t0
check("12 yeu cau cham 0,5 giay song song xong trong %.1fs (< 3s: THAT SU da luong; tuan tu se la ~6s)" % el, res.count(200) == 12 and el < 3.0, str((res, el)))
stop(srv, th)

srv, port, th = start(threads=2, timeout=5)
res = []
ths = [threading.Thread(target=lambda: res.append(req(port, "GET", "/slow?1.0")[0])) for _ in range(6)]
t0 = time.time()
[t.start() for t in ths]
[t.join() for t in ths]
check("gioi han 2 luong + 6 yeu cau cung luc: it nhat 2 duoc phuc vu (200), phan con lai nhan 503 NGAY (khong xep hang vo han)", res.count(200) >= 2 and res.count(503) >= 1 and res.count(200) + res.count(503) == 6 and srv.rejected >= 1, str(res))
time.sleep(0.2)
check("sau qua tai may chu hoi phuc: yeu cau tiep theo 200 (khe luong da duoc tra lai)", req(port, "GET", "/hello")[0] == 200)
st, hd, body = (lambda c: (c.request("GET", "/hello") or c.getresponse()))(http.client.HTTPConnection("127.0.0.1", port, timeout=5)), None, None
stop(srv, th)

# ---------------------------------------------------------------- 9. khach cham (slowloris)
srv, port, th = start(threads=2, timeout=1)
socks = [socket.create_connection(("127.0.0.1", port)) for _ in range(2)]  # 2 ket noi im lang chiem het 2 luong
time.sleep(0.2)
r_busy = req(port, "GET", "/hello")[0]
time.sleep(1.8)  # qua han 1 giay
r_free = req(port, "GET", "/hello")[0]
check("2 ket noi im lang chiem het luong: yeu cau luc do 503; sau khi qua han doc 1 giay may chu TU DONG giai phong -> 200", r_busy == 503 and r_free == 200, str((r_busy, r_free)))
[s.close() for s in socks]
stop(srv, th)

# ---------------------------------------------------------------- 10. tin header proxy
srv, port, th = start(trust_proxy=True)
st, hd, body = req(port, "GET", "/env", headers={"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})
e = json.loads(body)
check("--trust-proxy + ket noi tu loopback: REMOTE_ADDR=IP that tu X-Forwarded-For, scheme=https tu X-Forwarded-Proto", e["REMOTE_ADDR"] == "203.0.113.9" and e["wsgi.url_scheme"] == "https", str(e))
e = json.loads(req(port, "GET", "/env", headers={"X-Forwarded-For": "2001:db8::1, 10.0.0.1"})[2])
check("X-Forwarded-For nhieu gia tri: lay gia tri DAU; IPv6 duoc chuan hoa", e["REMOTE_ADDR"] == "2001:db8::1", str(e))
for bad in ("evil", "999.1.1.1", "", "'; DROP TABLE", "1.2.3.4:80"):
    e = json.loads(req(port, "GET", "/env", headers={"X-Forwarded-For": bad})[2])
    check("X-Forwarded-For khong hop le %r bi bo qua (giu 127.0.0.1)" % bad, e["REMOTE_ADDR"] == "127.0.0.1", str(e))
e = json.loads(req(port, "GET", "/env", headers={"X-Forwarded-Proto": "javascript"})[2])
check("X-Forwarded-Proto la ('javascript') bi bo qua", e["wsgi.url_scheme"] == "http")
stop(srv, th)
srv, port, th = start(trust_proxy=False)
e = json.loads(req(port, "GET", "/env", headers={"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})[2])
check("MAC DINH (khong --trust-proxy): bo qua X-Forwarded-* (chong gia IP khi bind 0.0.0.0)", e["REMOTE_ADDR"] == "127.0.0.1" and e["wsgi.url_scheme"] == "http")
stop(srv, th)
# ket noi KHONG tu loopback khong bao gio duoc tin, du bat --trust-proxy (kiem truc tiep lop bao ve)
seen = {}
def probe(environ, start_response):
    seen.update(addr=environ["REMOTE_ADDR"], scheme=environ["wsgi.url_scheme"])
    start_response("200 OK", [])
    return []
g = W.guard(probe, 1024, True)
g({"REMOTE_ADDR": "198.51.100.7", "HTTP_X_FORWARDED_FOR": "203.0.113.9", "HTTP_X_FORWARDED_PROTO": "https", "wsgi.url_scheme": "http", "wsgi.input": io.BytesIO(b""), "CONTENT_LENGTH": "0"}, lambda *a: None)
check("--trust-proxy nhung ket noi den tu IP KHONG phai loopback (198.51.100.7): KHONG tin header (chi tin proxy cuc bo)", seen == {"addr": "198.51.100.7", "scheme": "http"}, str(seen))

# ---------------------------------------------------------------- 11. nap ung dung
def exits(target):
    try:
        W.load_app(target)
        return None
    except SystemExit as e:
        return str(e)
check("load_app: 'module:app', 'module:create_app()', 'module:holder.app' (thuoc tinh long nhau) deu nap duoc", callable(W.load_app("wsgi_testapp:app")) and callable(W.load_app("wsgi_testapp:create_app()")) and callable(W.load_app("wsgi_testapp:holder.app")))
check("load_app: thieu ':' / module khong co / thuoc tinh khong co / khong phai ham -> SystemExit voi thong bao ro", all(exits(t) for t in ("wsgi_testapp", "khong_co_module:app", "wsgi_testapp:khong_co", "wsgi_testapp:not_callable", ":app", "wsgi_testapp:")))
check("load_app tu them thu muc hien tai vao sys.path (docroot chua ma ung dung)", os.getcwd() in sys.path)

# ---------------------------------------------------------------- 12. lenh that: SIGTERM, loi nap, cong bi chiem
def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p

p = free_port()
proc = subprocess.Popen([sys.executable, SRV, "wsgi_testapp:app", "--port", str(p), "--bind", "127.0.0.1", "--threads", "4", "--access-log"], cwd=tmp, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
line = proc.stdout.readline()
check("lenh that: in dong 'listening' voi cong/ung dung/so luong/thoi han", "listening 127.0.0.1:%d" % p in line and "app=wsgi_testapp:app" in line and "threads=4" in line, line)
ok = req(p, "GET", "/hello")[0] == 200
t0 = time.time()
proc.send_signal(signal.SIGTERM)
try:
    rc = proc.wait(5)
except subprocess.TimeoutExpired:
    proc.kill()
    rc = None
out = proc.stdout.read()
check("SIGTERM -> thoat SACH ma 0 trong %.1fs (dung sach, khong treo)" % (time.time() - t0), ok and rc == 0 and time.time() - t0 < 4)
check("--access-log ghi 1 dong cho moi yeu cau (IP, thoi gian, 'GET /hello HTTP/1.1' 200)", '"GET /hello HTTP/1.1" 200' in out, out)
proc = subprocess.run([sys.executable, SRV, "wsgi_testapp:khong_co", "--port", str(free_port())], cwd=tmp, capture_output=True, text=True, timeout=20)
check("lenh that: ung dung khong nap duoc -> thoat ma khac 0 voi thong bao ro tren stderr", proc.returncode not in (0, None) and "khong co 'khong_co'" in proc.stderr, proc.stderr)
holder = socket.socket()
holder.bind(("127.0.0.1", 0))
holder.listen(1)
busy = holder.getsockname()[1]
proc = subprocess.run([sys.executable, SRV, "wsgi_testapp:app", "--port", str(busy), "--bind", "127.0.0.1"], cwd=tmp, capture_output=True, text=True, timeout=20)
holder.close()
check("lenh that: cong dang bi chiem -> thoat ma khac 0, bao 'khong mo duoc cong'", proc.returncode not in (0, None) and "khong mo duoc cong" in proc.stderr, proc.stderr)
proc = subprocess.run([sys.executable, SRV, "wsgi_testapp:app", "--threads", "0"], cwd=tmp, capture_output=True, text=True, timeout=20)
check("tham so ngoai khoang (--threads 0) bi tu choi truoc khi nap ung dung", proc.returncode not in (0, None) and "--threads" in proc.stderr)

# ---------------------------------------------------------------- 13. khong dung thu vien ngoai (chi stdlib) - chong ai them dependency
src = open(SRV, encoding="utf-8").read()
import re
imports = set(re.findall(r"^(?:import|from)\s+([a-z_]+)", src, re.M))
stdlib = set(sys.stdlib_module_names) if hasattr(sys, "stdlib_module_names") else None
check("chi import thu vien chuan: %s" % sorted(imports), stdlib is None or imports <= stdlib, str(imports - (stdlib or set())))

# ---------------------------------------------------------------- 14. khung thuc te neu co san
try:
    import flask  # noqa
    have_flask = True
except Exception:
    have_flask = False
if have_flask:
    with open(os.path.join(tmp, "flask_app.py"), "w") as f:
        f.write("from flask import Flask, request, jsonify\napp = Flask(__name__)\n@app.route('/hi/<name>')\ndef hi(name):\n    return jsonify(hi=name, ip=request.remote_addr)\n@app.route('/post', methods=['POST'])\ndef post():\n    return jsonify(n=len(request.get_data()))\n")
    s2 = W.make_server(W.load_app("flask_app:app"), port=0)
    p2 = s2.server_address[1]
    t2 = threading.Thread(target=s2.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True)
    t2.start()
    a = json.loads(req(p2, "GET", "/hi/an")[2])
    b = json.loads(req(p2, "POST", "/post", body=b"z" * 70000)[2])
    check("Flask THAT chay tren may chu: route co tham so + POST 70 KB", a["hi"] == "an" and b["n"] == 70000)
    s2.shutdown(); s2.server_close()
else:
    print("(bo qua kiem Flask that: Flask chua cai trong moi truong nay)")

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
