#!/usr/bin/env python3
"""Kiem thu AUDIT THAO TAC nhay cam cua _admin/ bang PHP that (HANDOFF.md muc 1bk; PDF 2 muc G4 "ai bat 2FA/chay WP-CLI/bat bao tri...").
Diem ghi chung: wp_pocket_csrf_verify() (admin-auth.php) + nhom lenh WP-CLI (admin-wpcli.php).
Khang dinh: co dong "thao tac <trang> action=<..>" khi CSRF HOP LE; KHONG ghi khi CSRF sai; chi ghi ten trang + action da loc (khong
ghi mat khau/lenh/doi so); khong lam sai bo dem canh bao dang nhap sai cua MonitorLogic (dong khong bat dau bang 'dang nhap sai')."""
import importlib.util, os, re, shutil, subprocess, sys, tempfile, time, socket

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check


def main():
    if not shutil.which('php'):
        print('(bo qua: khong co php)'); return 0
    tmp = tempfile.mkdtemp(prefix='audit-')
    srv = None
    try:
        os.chmod(tmp, 0o755)
        app, run, www, adm = sec.build_tree(tmp)
        port = sec.free_port()
        ext = os.path.join(tmp, 'ext')
        srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
                                '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=1'],
                               env=dict(os.environ, APP_HOME=app, EXT_DIR=ext), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        audit = os.path.join(run, 'admin-audit.log')
        def log(): return open(audit, encoding='utf-8').read() if os.path.exists(audit) else ''
        def acts(): return [l for l in log().splitlines() if ' thao tac ' in l or ' wp-cli ' in l]

        c = sec.Client(port, '192.168.1.7')
        check('dang nhap', c.login())
        check('dang nhap + GET trang KHONG sinh dong "thao tac" (chi POST hop le moi ghi)', acts() == [] and (c.req('GET', '/_admin/maintenance.php') and acts() == []))

        t = c.token('maintenance')
        check('lay duoc CSRF token', t is not None)
        sc, body, _ = c.req('POST', '/_admin/maintenance.php', {'csrf_token': 'sai' * 8, 'action': 'enable'})
        check('POST token SAI: khong thuc hien (khong tao co bao tri) VA khong co dong audit thao tac',
              not os.path.exists(os.path.join(run, 'maintenance-mode')) and acts() == [], acts())

        c.req('POST', '/_admin/maintenance.php', {'csrf_token': t, 'action': 'enable', 'ghi_chu': 'MATKHAU-BI-MAT-123'})
        a = acts()
        check('POST hop le: audit ghi "ip=... thao tac maintenance.php action=enable"', len(a) == 1 and re.search(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d ip=192\.168\.1\.7 thao tac maintenance\.php action=enable$', a[0]) is not None, a)
        check('thao tac that su duoc thuc hien (co bao tri bat)', os.path.exists(os.path.join(run, 'maintenance-mode')))
        check('truong khac cua form (co the chua bi mat) KHONG bi ghi vao audit', 'MATKHAU-BI-MAT-123' not in log() and sec.PASSWORD not in log())

        t = c.token('maintenance')
        c.req('POST', '/_admin/maintenance.php', {'csrf_token': t, 'action': 'en<able;$(rm -rf)' + 'x' * 40})
        last = acts()[-1]
        m = re.search(r'action=(\S*)$', last)
        check('action co ky tu la bi LOC ve [a-z0-9_-] va cat toi da 24 ky tu (khong chen duoc dong/ky tu dieu khien vao log)',
              m is not None and re.fullmatch(r'[a-z0-9_-]{1,24}', m.group(1)) is not None and '<' not in last and ';' not in last and '$' not in last, last)
        check('khong co dong audit nao bi tach doi (moi thao tac = dung 1 dong)', all(re.match(r'\d{4}-', l) for l in log().splitlines()))

        t = c.token('maintenance')
        n0 = len(acts())
        c.req('POST', '/_admin/maintenance.php', {'csrf_token': t, 'action': 'disable'})
        check('tat bao tri cung duoc ghi (action=disable)', len(acts()) == n0 + 1 and acts()[-1].endswith('thao tac maintenance.php action=disable'), acts()[-2:])

        # WP-CLI: ghi 2 tu dau, KHONG ghi doi so
        tw = c.token('wpcli')
        n1 = len(acts())
        sc, body, _ = c.req('POST', '/_admin/wpcli.php', {'csrf_token': tw, 'cmd': 'wp plugin install bi-mat-slug --activate --password=XYZ-BI-MAT'})
        lines = acts()[n1:]
        check('WP-CLI: audit ghi "thao tac wpcli.php" + "wp-cli plugin install" (2 tu dau, bo tien to "wp ")',
              any(l.endswith('thao tac wpcli.php') for l in lines) and any(l.endswith(' wp-cli plugin install') for l in lines), lines)
        check('WP-CLI: doi so (slug/--password) KHONG vao audit', 'bi-mat-slug' not in log() and 'XYZ-BI-MAT' not in log())
        calls = os.path.join(ext, 'calls.log')
        check('WP-CLI that su duoc goi (kiem chung khong chan nham vi audit)', os.path.exists(calls) and 'plugin install' in open(calls).read())
        tw = c.token('wpcli')
        n2 = len(acts())
        c.req('POST', '/_admin/wpcli.php', {'csrf_token': tw, 'cmd': 'plugin list; rm -rf /'})
        check('lenh bi chan (ky tu dieu khien shell): thao tac van duoc ghi (de thay nguoi thu), lenh KHONG chay',
              len(acts()) > n2 and 'rm -rf' not in open(calls).read())

        # Adminer / Tiny File Manager (1bl): ban gia chi co guard -> kiem hanh vi cua guard, khong can ban that
        for nm in ('db', 'files'):
            open(os.path.join(adm, nm + '.php'), 'w').write("<?php\nrequire __DIR__ . '/auth.php';\necho 'TOOL-OK';\n")
        tool_lines = lambda: [l for l in log().splitlines() if ' truy cap ' in l]
        d0 = sec.Client(port, '192.168.1.8')
        sc, b0, _ = d0.req('GET', '/_admin/db.php')
        check('chua dang nhap vao db.php: khong lo noi dung va khong ghi dong truy cap', 'TOOL-OK' not in b0 and tool_lines() == [], tool_lines())
        check('dang nhap (client khac)', d0.login())
        d0.req('GET', '/_admin/db.php'); d0.req('POST', '/_admin/db.php', {'x': '1'}); d0.req('GET', '/_admin/db.php')
        tl = tool_lines()
        check('mo db.php 3 lan trong 10 phut: chi 1 dong "truy cap db.php (Adminer)" (khong ghi tung request)', len(tl) == 1 and 'ip=192.168.1.8 truy cap db.php (Adminer)' in tl[0], tl)
        sc, b1, _ = d0.req('GET', '/_admin/files.php')
        tl = tool_lines()
        check('files.php co moc rieng: them 1 dong "truy cap files.php (File Manager)", noi dung van hien (guard khong chan nham)', 'TOOL-OK' in b1 and len(tl) == 2 and 'files.php (File Manager)' in tl[1], tl)
        d1 = sec.Client(port, '192.168.1.9'); d1.login(); d1.req('GET', '/_admin/db.php')
        check('phien KHAC cung mo db.php: duoc ghi rieng (moc theo phien)', len(tool_lines()) == 3 and 'ip=192.168.1.9 truy cap db.php' in tool_lines()[-1], tool_lines())

        # Hop dong voi Kotlin: cac dong moi khong bi dem la "dang nhap sai"
        counted = [l for l in log().splitlines() if re.search(r'ip=\S+\s+(dang nhap sai|sai ma 2FA)', l) or 'BI KHOA TAM' in l]
        check('cac dong thao tac KHONG khop mau dem "dang nhap sai"/"sai ma 2FA"/"BI KHOA TAM" cua MonitorLogic.scanAudit', counted == [], counted)
    finally:
        if srv:
            srv.terminate()
            try: srv.wait(timeout=10)
            except Exception: srv.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL))
    return 0 if sec.FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
