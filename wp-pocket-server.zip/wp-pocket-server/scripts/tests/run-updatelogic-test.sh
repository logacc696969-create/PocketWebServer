#!/bin/sh
# Chay kiem thu JVM cho UpdateLogic.kt (can kotlinc + java). Khong can Android SDK. HANDOFF.md muc 1bg.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/UpdateLogic.kt" "$HERE/UpdateLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" UpdateLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
