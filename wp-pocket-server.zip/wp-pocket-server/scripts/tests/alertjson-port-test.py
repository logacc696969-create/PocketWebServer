#!/usr/bin/env python3
"""Ban PORT Python 1-1 cua MonitorLogic.jsonEscape/buildAlertJson (T2, HANDOFF 1bl) tren DON VI UTF-16 (nhu Kotlin) + kiem bang json.loads that.
Khi khong co kotlinc: day la cach kiem thuat toan ngay (JVM test that chay o CI). Doi chieu van ban voi Kotlin va dung dung cac vector cua MonitorLogicTest.kt."""
import json, os, random, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
PASS = FAIL = 0
def ok(c, n, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('  OK  ', n)
    else: FAIL += 1; print('  FAIL', n, d)

EVENTS = {'site_down', 'backup_ok', 'backup_failed'}
MAXC = 1000
def units(s): b = s.encode('utf-16-le', 'surrogatepass'); return [int.from_bytes(b[i:i+2], 'little') for i in range(0, len(b), 2)]
def from_units(u): return b''.join(x.to_bytes(2, 'little') for x in u).decode('utf-16-le', 'surrogatepass')
def esc(u):
    """Tren DON VI UTF-16 (nhu Kotlin); ghep lai thanh str o CUOI de cap thay the thanh ky tu dung (khong phai 2 ky tu mo coi cua Python)."""
    out = []
    for c in u:
        if c == 0x22: out.extend(map(ord, '\\"'))
        elif c == 0x5C: out.extend(map(ord, '\\\\'))
        elif c == 0x0A: out.extend(map(ord, '\\n'))
        elif c == 0x0D: out.extend(map(ord, '\\r'))
        elif c == 0x09: out.extend(map(ord, '\\t'))
        elif c < 0x20: out.extend(map(ord, '\\u%04x' % c))
        else: out.append(c)
    return from_units(out)
def build(event, text, ts):
    ev = event if event in EVENTS else 'unknown'
    u = units(text)
    if len(u) > MAXC: u = u[:MAXC]
    if u and 0xD800 <= u[-1] <= 0xDBFF: u = u[:-1]
    return '{"app":"wp-pocket-server","event":"%s","ts":%d,"text":"%s"}' % (ev, ts, esc(u))

ok(esc(units('a"b\\c\nd\te')) == 'a\\"b\\\\c\\nd\\te', 'vector Kotlin: nhay kep/gach cheo/xuong dong/tab')
ok(esc(units('x\x01y')) == 'x\\u0001y', 'vector Kotlin: 0x01 -> \\u0001')
vi = 'Kh\u00f4ng ph\u1ea3n h\u1ed3i \U0001F600'
ok(esc(units(vi)) == vi, 'vector Kotlin: tieng Viet + emoji giu nguyen')
ok(build('site_down', 'hi', 1760000000) == '{"app":"wp-pocket-server","event":"site_down","ts":1760000000,"text":"hi"}', 'vector Kotlin: khung co dinh')
ok('"event":"unknown"' in build('<script>', 'x', 1), 'vector Kotlin: su kien la -> unknown')
ok(build('backup_failed', '"}, "event":"hack', 1) == '{"app":"wp-pocket-server","event":"backup_failed","ts":1,"text":"\\"}, \\"event\\":\\"hack"}', 'vector Kotlin: chen nhay kep khong pha cau truc (so sanh chinh xac)')
ok(len(build('backup_ok', 'a' * 2000, 1)) == len(build('backup_ok', 'a' * 1000, 1)), 'vector Kotlin: text dai bi cat 1000')
cut = 'a' * 999 + '\U0001F600'
r = build('backup_ok', cut, 1)
ok('\ud83d' not in r and json.loads(r)['text'] == 'a' * 999, 'vector Kotlin: cat giua cap thay the -> bo nua cap, JSON van hop le')
# --- kiem bang json.loads that, ngau nhien (seed co dinh)
random.seed(1306)
pool = ['"', '\\', '\n', '\r', '\t', '\x00', '\x01', '\x1f', ' ', '/', '{', '}', '[', ']', ':', ',', '\u2028', '\u2029', '\u00f4', '\u1ea3', '\U0001F600', '\U0001F4A5', 'a', 'Z', '0', "'", '<', '>', '&']
bad = 0
for _ in range(4000):
    t = ''.join(random.choice(pool) for _ in range(random.randint(0, 60)))
    ev = random.choice(list(EVENTS) + ['x'])
    try:
        d = json.loads(build(ev, t, 1760000000))
        exp = t if len(units(t)) <= MAXC else None
        if d['app'] != 'wp-pocket-server' or d['event'] != (ev if ev in EVENTS else 'unknown') or d['ts'] != 1760000000 or d['text'] != exp: bad += 1
    except Exception:
        bad += 1
ok(bad == 0, '4000 chuoi ngau nhien (nhay, gach cheo, dieu khien, U+2028, emoji...): json.loads that doc lai DUNG NGUYEN van', bad)
bad = 0
for _ in range(500):
    n = random.randint(995, 1004)
    t = ''.join(random.choice(['a', '\U0001F600', 'b']) for _ in range(n))
    try:
        d = json.loads(build('backup_ok', t, 1))
        t2 = d['text']
        u = units(t2)
        if len(u) > MAXC or (u and 0xD800 <= u[-1] <= 0xDBFF) or not t.startswith(t2): bad += 1
    except Exception:
        bad += 1
ok(bad == 0, '500 chuoi dai quanh gioi han 1000 voi emoji: luon JSON hop le, khong ky tu mo coi, la TIEN TO cua ban goc', bad)
kt = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/MonitorLogic.kt'), encoding='utf8').read()
ok('setOf("site_down", "backup_ok", "backup_failed", "backup_verify_failed")' in kt and 'const val ALERT_TEXT_MAX: Int = 1000' in kt, 'Kotlin: danh sach su kien + gioi han 1000 khop ban port')
ok('"{\\"app\\":\\"wp-pocket-server\\",\\"event\\":\\"$ev\\",\\"ts\\":$tsSec,\\"text\\":\\"${jsonEscape(t)}\\"}"' in kt, 'Kotlin: khung JSON khop ban port')
hc = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/HealthCheckWorker.kt'), encoding='utf8').read()
bw = open(os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/BackupWorker.kt'), encoding='utf8').read()
ok('AlertWebhook.notify(\n                applicationContext, "site_down"' in hc, 'HealthCheckWorker gui site_down')
ok('"backup_ok"' in bw and '"backup_failed"' in bw, 'BackupWorker gui backup_ok + backup_failed')
for ev in ('site_down', 'backup_ok', 'backup_failed', 'backup_verify_failed'):
    ok(ev in kt, 'su kien %s nam trong ALERT_EVENTS (neu quen them, no se bi doi thanh "unknown")' % ev)
print('TONG KET: pass=%d fail=%d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
