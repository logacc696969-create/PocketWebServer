import com.wppocket.server.FatalLogLogic
import java.io.File
import java.nio.file.Files

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun main() {
    val ts = "[22-Oct-2026 10:15:03 Asia/Ho_Chi_Minh] "
    val log = listOf(
        ts + "PHP Warning:  Undefined variable \$x in /a.php on line 5",
        ts + "PHP Fatal error:  Allowed memory size of 134217728 bytes exhausted (tried to allocate 262144 bytes) in /w/class-wp.php on line 100",
        "[22-Oct-2026 10:16:44 Asia/Ho_Chi_Minh] PHP Fatal error:  Allowed memory size of 134217728 bytes exhausted (tried to allocate 20480 bytes) in /w/class-wp.php on line 101",
        ts + "PHP Fatal error:  Maximum execution time of 60 seconds exceeded in /w/p/x.php on line 9",
        ts + "PHP Parse error:  syntax error, unexpected token in /w/t/functions.php on line 33",
        ts + "PHP Fatal error:  Uncaught Error: Call to undefined function foo() in /w/p.php:12",
        "Stack trace:", "#0 {main}", ts + "PHP Notice:  x in /n.php on line 3")
    val g = FatalLogLogic.scan(log)
    check("phan loai 4 loai", g.size == 4 && g[0].kind == "memory" && g[1].kind == "timeout" && g[2].kind == "parse" && g[3].kind == "uncaught")
    check("2 loi memory gom 1 nhom dem 2; Warning/Notice/Stack trace khong tinh", g[0].count == 2 && g.sumOf { it.count } == 5)
    check("mau bo tien to thoi gian", !g[0].sample.startsWith("["))
    check("alertText: null khi khong co loi; co tong + nhan phan loai khi co", FatalLogLogic.alertText(emptyList()) == null && FatalLogLogic.alertText(g)!!.contains("5 loi PHP") && FatalLogLogic.alertText(g)!!.contains("memory_limit"))
    check("cooledDown", FatalLogLogic.cooledDown(3_600_000L, 0L, 3_600_000L) && !FatalLogLogic.cooledDown(3_599_999L, 0L, 3_600_000L))
    val tmp = Files.createTempDirectory("fatal-kt").toFile(); val f = File(tmp, "php-error.log")
    try {
        check("file chua co -> rong, offset 0", FatalLogLogic.readNew(f, 0L).first.isEmpty() && FatalLogLogic.readNew(f, 0L).second == 0L)
        f.appendText(ts + "PHP Fatal error:  Uncaught Error: A in /x.php:1\n")
        val r1 = FatalLogLogic.readNew(f, 0L)
        check("doc lan dau thay 1 fatal; khong doc lai khi khong co gi moi", FatalLogLogic.scan(r1.first).size == 1 && r1.second == f.length() && FatalLogLogic.scan(FatalLogLogic.readNew(f, r1.second).first).isEmpty())
        f.appendText(ts + "PHP Fatal error:  Maximum execution time of 30 seconds exceeded in /y.php on line 2\n")
        val r2 = FatalLogLogic.readNew(f, r1.second)
        check("chi doc phan moi", FatalLogLogic.scan(r2.first).size == 1 && FatalLogLogic.scan(r2.first)[0].kind == "timeout")
        f.writeText(ts + "PHP Parse error:  syntax error in /z.php on line 3\n")
        val r3 = FatalLogLogic.readNew(f, r2.second)
        check("file bi cat -> doc lai tu dau", FatalLogLogic.scan(r3.first).size == 1 && FatalLogLogic.scan(r3.first)[0].kind == "parse")
    } finally { tmp.deleteRecursively() }
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
