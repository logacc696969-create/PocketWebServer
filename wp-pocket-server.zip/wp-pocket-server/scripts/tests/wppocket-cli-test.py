#!/usr/bin/env python3
"""T4 (PDF 2; HANDOFF.md muc 1bq-D): kiem chung cong cu dong lenh scripts/tools/wppocket_cli.py.

May chu API GIA chay THAT tren 127.0.0.1 (mo phong dung hop dong cua nginx/start-lamp.sh: GET /api/v1/status, Bearer token, 401 khi sai token,
JSON lược do wp-pocket-status/1). CLI duoc chay bang subprocess that (ma thoat, stdout, stderr that). Phan nginx that da duoc kiem o api-status-test.py.
"""
import importlib.util, json, os, re, stat, subprocess, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
CLI = os.path.join(ROOT, "scripts", "tools", "wppocket_cli.py")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, extra)


spec = importlib.util.spec_from_file_location("wppocket_cli", CLI)
C = importlib.util.module_from_spec(spec)
sys.modules["wppocket_cli"] = C
spec.loader.exec_module(C)

TOKEN = "0123456789abcdef" * 4
STATE = {"mode": "ok", "body": None, "hits": 0, "last_auth": None, "last_path": None, "redirect_hits": 0}


def base_status(**kw):
    now = int(time.time())  # tinh LAI moi lan goi: "12 giay truoc" khong troi theo thoi gian chay test
    d = {"schema": "wp-pocket-status/1", "generated_at": now - 12, "server_running": True, "battery_pct": 83, "charging": True,
         "disk_used_pct": 72, "last_backup_at": now - 5 * 3600, "backup_count": 3, "app_version": "1.2.3"}
    d.update(kw)
    return d


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        STATE["hits"] += 1
        STATE["last_auth"] = self.headers.get("Authorization")
        STATE["last_path"] = self.path
        mode = STATE["mode"]
        if self.path == "/leak":
            STATE["redirect_hits"] += 1
            self.send_response(200); self.end_headers(); self.wfile.write(b"x"); return
        if self.path != "/api/v1/status":
            self.send_response(404); self.end_headers(); return
        if mode == "403":
            self.send_response(403); self.end_headers(); return
        if mode == "404":
            self.send_response(404); self.end_headers(); return
        if mode == "500":
            self.send_response(500); self.end_headers(); return
        if mode == "redirect":
            self.send_response(302); self.send_header("Location", "http://127.0.0.1:%d/leak" % self.server.server_address[1]); self.end_headers(); return
        if self.headers.get("Authorization") != "Bearer " + TOKEN:
            self.send_response(401); self.end_headers(); return
        if mode == "slow":
            time.sleep(3)
        if mode == "huge":
            body = b"{" + b" " * (200 * 1024) + b"}"
        elif mode == "notjson":
            body = b"<html>hello</html>"
        else:
            body = json.dumps(STATE["body"] if STATE["body"] is not None else base_status()).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except OSError:
            pass


srv = HTTPServer(("127.0.0.1", 0), H)
PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

home = tempfile.mkdtemp()
ENV = {k: v for k, v in os.environ.items() if not k.startswith("WPPOCKET_") and k not in ("http_proxy", "HTTP_PROXY")}
ENV.update(HOME=home, XDG_CONFIG_HOME=os.path.join(home, "cfg"), WPPOCKET_HOST="127.0.0.1", WPPOCKET_PORT=str(PORT), WPPOCKET_TOKEN=TOKEN)


def run(*args, env=None, timeout=30, mode=None, body=None):
    STATE["mode"] = mode or "ok"
    STATE["body"] = body
    e = dict(ENV)
    if env:
        e.update(env)
    for k in [k for k, v in e.items() if v is None]:
        del e[k]
    r = subprocess.run([sys.executable, CLI] + list(args), capture_output=True, text=True, env=e, timeout=timeout)
    return r.returncode, r.stdout, r.stderr


# ---------------------------------------------------------------- 1. status co ban (vi/en)
rc, out, err = run("status")
check("status: ma thoat 0, hien may chu/pin/bo nho/backup/du lieu (tieng Viet mac dinh)", rc == 0 and "ĐANG CHẠY" in out and "83% (đang sạc)" in out and "đã dùng 72%" in out and "5 giờ trước (3 bản)" in out and re.search(r"1[2-4] giây trước", out) and "(v1.2.3)" in out, out + err)
check("dong tieu de co host:port", ("127.0.0.1:%d" % PORT) in out.splitlines()[0])
rc, out, err = run("--lang", "en", "status")
check("--lang en: tieng Anh", rc == 0 and "RUNNING" in out and "83% (charging)" in out and "72% used" in out and "5 h ago (3 copies)" in out, out)
rc, out, err = run("status", env={"WPPOCKET_LANG": "en"})
check("WPPOCKET_LANG=en dung duoc", "RUNNING" in out)
check("gui DUNG yeu cau: GET /api/v1/status + Authorization: Bearer <token>", STATE["last_path"] == "/api/v1/status" and STATE["last_auth"] == "Bearer " + TOKEN)
rc, out, err = run("status", "--json")
d = json.loads(out)
check("--json: JSON hop le, giu nguyen DUNG 9 truong (khong them/bot), ma thoat 0", rc == 0 and set(d) == set(base_status()) and d["schema"] == "wp-pocket-status/1" and d["battery_pct"] == 83 and d["backup_count"] == 3)
rc, out, err = run("status", mode="ok", body=base_status(server_running=False))
check("server_running=false: ma thoat 2 (CRITICAL) du khong co --check, hien KHONG CHAY", rc == 2 and "KHÔNG CHẠY" in out)

# ---------------------------------------------------------------- 2. gia tri null / sai kieu -> 'khong ro', khong sap
rc, out, err = run("status", body=base_status(battery_pct=None, disk_used_pct=None, last_backup_at=None, backup_count=0, charging=False))
check("pin/bo nho = null -> 'không rõ'; chua tung backup -> 'chưa có' (khong bia so)", rc == 0 and out.count("không rõ") == 2 and "chưa có" in out, out)
rc, out, err = run("status", body=base_status(battery_pct=999, disk_used_pct=-5, last_backup_at="abc", backup_count="x", generated_at="y", server_running="true"))
check("truong sai kieu/ngoai khoang (pin 999, dia -5, chuoi) -> 'khong ro', khong sap; server_running='true' (chuoi) KHONG tinh la dang chay", rc == 2 and "Traceback" not in err and out.count("không rõ") >= 3 and "KHÔNG CHẠY" in out, out + err)
rc, out, err = run("status", body=base_status(extra_field={"a": 1}, battery_pct=True))
check("truong thua duoc bo qua (tuong thich xuoi); bool khong bi coi la so (battery_pct=true -> khong ro)", rc == 0 and "Traceback" not in err and "không rõ" in out)

# ---------------------------------------------------------------- 3. --check (Nagios)
rc, out, err = run("status", "--check")
check("--check khong nguong: OK, ma thoat 0, DUNG 1 dong", rc == 0 and out.startswith("OK - ") and len(out.strip().splitlines()) == 1, out)
rc, out, err = run("status", "--check", "--max-disk", "70")
check("--max-disk 70 voi dia 72 -> WARNING ma 1", rc == 1 and out.startswith("WARNING - ") and "72%" in out and "70%" in out, out)
rc, out, err = run("status", "--check", "--max-disk", "72")
check("--max-disk 72 voi dia 72 -> WARNING (>=)", rc == 1)
rc, out, err = run("status", "--check", "--max-disk", "73")
check("--max-disk 73 voi dia 72 -> OK", rc == 0)
rc, out, err = run("status", "--check", "--min-battery", "90", body=base_status(charging=True))
check("--min-battery 90, pin 83 NHUNG DANG SAC -> OK (khong bao pin thap khi dang sac)", rc == 0, out)
rc, out, err = run("status", "--check", "--min-battery", "90", body=base_status(charging=False))
check("--min-battery 90, pin 83 khong sac -> WARNING", rc == 1 and "83%" in out, out)
rc, out, err = run("status", "--check", "--max-backup-age", "4h")
check("--max-backup-age 4h, backup cu 5h -> WARNING", rc == 1 and "5 giờ" in out and "4 giờ" in out, out)
rc, out, err = run("status", "--check", "--max-backup-age", "1d")
check("--max-backup-age 1d, backup cu 5h -> OK", rc == 0)
rc, out, err = run("status", "--check", "--max-backup-age", "1d", body=base_status(last_backup_at=None))
check("--max-backup-age khi chua co backup -> WARNING 'chua co backup'", rc == 1 and "chưa có backup" in out, out)
rc, out, err = run("status", "--check", "--max-staleness", "10s")
check("--max-staleness 10s, du lieu cu 12s -> CRITICAL ma 2 (app/dien thoai co the treo)", rc == 2 and out.startswith("CRITICAL - ") and "treo" in out, out)
rc, out, err = run("status", "--check", "--max-staleness", "10m")
check("--max-staleness 10m, du lieu cu 12s -> OK", rc == 0)
rc, out, err = run("status", "--check", "--max-disk", "10", body=base_status(server_running=False))
check("CRITICAL + WARNING cung luc: CRITICAL thang, thong bao gom ca hai ly do", rc == 2 and "KHÔNG chạy" in out and "bộ nhớ đầy" in out, out)
rc, out, err = run("status", "--check", "--max-disk", "10", body=base_status(disk_used_pct=None))
check("nguong --max-disk nhung bo nho = null (khong biet) -> KHONG bao gia (OK)", rc == 0)
rc, out, err = run("--lang", "en", "status", "--check", "--max-disk", "50")
check("--check tieng Anh: 'WARNING - storage 72% full (threshold 50%)'", out.strip() == "WARNING - storage 72% full (threshold 50%)", out)

# ---------------------------------------------------------------- 4. loi mang/API -> UNKNOWN 3, thong bao ro, khong lo token
mis = []
for mode, needle in (("403", "HTTP 403"), ("404", "HTTP 404"), ("500", "HTTP 500"), ("redirect", "chuyển hướng"), ("huge", "quá lớn"), ("notjson", "không phải JSON")):
    rc, out, err = run("status", mode=mode)
    if not (rc == 3 and needle in err and TOKEN not in err + out):
        mis.append((mode, rc, err[:120]))
check("403/404/500/chuyen huong/phan hoi qua lon/khong phai JSON -> ma 3, thong bao ro, KHONG lo token", not mis, str(mis))
run("status", mode="redirect")
check("chuyen huong KHONG duoc theo (may dich khong nhan token / khong bi goi)", STATE["redirect_hits"] == 0)
rc, out, err = run("status", env={"WPPOCKET_TOKEN": "f" * 64})
check("sai token (dung dinh dang) -> 401 -> ma 3 voi huong dan lay token", rc == 3 and "HTTP 401" in err and "f" * 64 not in err + out, err)
rc, out, err = run("status", mode="ok", body={"schema": "khac/9", "x": 1})
check("sai lược do -> ma 3, noi ro nhan duoc gi", rc == 3 and "wp-pocket-status/1" in err and "khac/9" in err, err)
rc, out, err = run("status", mode="ok", body=[1, 2])
check("JSON la mang (khong phai object) -> ma 3, khong sap", rc == 3 and "Traceback" not in err)
t0 = time.time()
rc, out, err = run("status", "--timeout", "1", mode="slow")
check("may chu cham: het thoi gian (1s) -> ma 3 'hết thời gian chờ' trong < 3s", rc == 3 and "hết thời gian" in err and time.time() - t0 < 3, err)
rc, out, err = run("status", env={"WPPOCKET_PORT": "1"})
check("cong dong (connection refused) -> ma 3, thong bao ro", rc == 3 and "bị từ chối" in err, err)

# ---------------------------------------------------------------- 5. an toan dia chi / token / cau hinh
for bad_host in ("example.com", "8.8.8.8", "trycloudflare.com", "my.site.vn", "1.2.3.4"):
    rc, out, err = run("status", env={"WPPOCKET_HOST": bad_host})
    check("host cong cong %r bi TU CHOI truoc khi gui token (ma 64)" % bad_host, rc == 64 and "Từ chối gửi token" in err, err)
hits0 = STATE["hits"]
run("status", env={"WPPOCKET_HOST": "example.com"})
check("tu choi host cong cong KHONG mo ket noi nao (khong goi mang)", STATE["hits"] == hits0)
for ok_host in ("127.0.0.1", "192.168.1.23", "10.0.0.5", "172.16.5.4", "169.254.1.1", "localhost", "pocket.local", "phone.lan", "phone", "router.home.arpa", "[fd00::1]", "::1", "fe80::1%eth0", "::ffff:192.168.1.5", "172.31.255.255"):
    check("is_private_host(%r) = True" % ok_host, C.is_private_host(ok_host))
for pub in ("8.8.8.8", "1.1.1.1", "203.0.113.9", "198.51.100.7", "100.64.0.1", "0.0.0.0", "172.32.0.1", "192.169.0.1", "::ffff:8.8.8.8", "example.com", "x.trycloudflare.com", "", "2001:4860:4860::8888"):
    check("is_private_host(%r) = False" % pub, not C.is_private_host(pub))
rc, out, err = run("status", env={"WPPOCKET_HOST": "example.com"}, )
rc2, out2, err2 = run("status", "--allow-public", env={"WPPOCKET_HOST": "127.0.0.1"})
check("--allow-public vo hai voi host noi bo", rc2 == 0)
for bad_tok in ("abc", "A" * 40, "g" * 40, "a" * 31, "a" * 65, "a" * 39 + "'", "a" * 39 + "\n", "$(id)"):
    rc, out, err = run("status", env={"WPPOCKET_TOKEN": bad_tok})
    if rc != 64 or "Token phải là 32-64" not in err:
        check("token sai dinh dang %r -> ma 64" % bad_tok, False, err)
        break
else:
    check("8 token sai dinh dang (ngan/dai/HOA/ky tu la/dau nhay/xuong dong/$(...)) bi tu choi truoc khi gui, ma 64", True)
rc, out, err = run("status", env={"WPPOCKET_TOKEN": None})
check("khong co token -> ma 64 + huong dan", rc == 64 and "Chưa có token" in err)
rc, out, err = run("status", env={"WPPOCKET_HOST": None})
check("khong co host -> ma 64 + huong dan", rc == 64 and "Chưa có địa chỉ" in err)
rc, out, err = run("status", env={"WPPOCKET_PORT": "70000"})
check("cong ngoai khoang -> ma 64", rc == 64)
rc, out, err = run("status", env={"WPPOCKET_HOST": "a b"})
check("host co khoang trang/ky tu la -> ma 64", rc == 64)
for bad_args in (["status", "--max-disk", "101"], ["status", "--min-battery", "-1"], ["status", "--max-backup-age", "5x"], ["status", "--max-staleness", "0"], ["nope"], ["status", "--port", "abc"]):
    rc, out, err = run(*bad_args)
    if rc != 64:
        check("tham so sai %s -> ma 64" % bad_args, False, "%d %s" % (rc, err))
        break
else:
    check("6 kieu tham so sai (nguong >100, am, thoi luong sai, bang 0, lenh la, cong chu) -> ma 64 (khong trung ma CRITICAL=2)", True)
rc, out, err = run()
check("khong lenh -> in tro giup, ma 64", rc == 64 and "status" in out)

# ---------------------------------------------------------------- 6. config
env_nocfg = {"WPPOCKET_HOST": None, "WPPOCKET_PORT": None, "WPPOCKET_TOKEN": None}
rc, out, err = run("config", "set", "--host", "127.0.0.1", "--port", str(PORT), "--token", TOKEN, env=env_nocfg)
cfgp = os.path.join(home, "cfg", "wppocket", "config.json")
check("config set: ghi tep, in duong dan, ma 0", rc == 0 and os.path.exists(cfgp) and cfgp in out, out + err)
mode = stat.S_IMODE(os.stat(cfgp).st_mode)
check("tep cau hinh quyen 0600; thu muc cha 0700", mode == 0o600 and stat.S_IMODE(os.stat(os.path.dirname(cfgp)).st_mode) == 0o700, oct(mode))
rc, out, err = run("status", env=env_nocfg)
check("dung cau hinh tu tep khi khong co bien/co: status chay dung", rc == 0 and "ĐANG CHẠY" in out, out + err)
rc, out, err = run("config", "show", env=env_nocfg)
check("config show che token (xxxx...xxxx), KHONG in token day du", rc == 0 and "0123...cdef" in out and TOKEN not in out, out)
rc, out, err = run("config", "show", "--reveal", env=env_nocfg)
check("config show --reveal in token day du", TOKEN in out)
rc, out, err = run("config", "path", env=env_nocfg)
check("config path in duong dan", out.strip() == cfgp)
os.chmod(cfgp, 0o644)
rc, out, err = run("status", env=env_nocfg)
check("tep cau hinh quyen 0644 -> CANH BAO tren stderr (van chay), khong lo token", rc == 0 and "chmod 600" in err and TOKEN not in err, err)
rc, out, err = run("status", "--host", "127.0.0.1", "--port", str(PORT), env={"WPPOCKET_HOST": "10.255.255.1", "WPPOCKET_PORT": "1"})
check("uu tien: tham so dong lenh > bien moi truong > tep", rc == 0)
rc, out, err = run("status", env={"WPPOCKET_HOST": "127.0.0.1", "WPPOCKET_TOKEN": TOKEN, "WPPOCKET_PORT": str(PORT)})
check("uu tien: bien moi truong > tep (tep van tro dung nhung env duoc dung)", rc == 0)
rc, out, err = run("config", "set", "--host", "example.com", env=env_nocfg)
check("config set host cong cong bi tu choi (khong ghi)", rc == 64 and "Từ chối" in err and json.load(open(cfgp)).get("host") == "127.0.0.1")
rc, out, err = run("config", "set", "--token", "xyz", env=env_nocfg)
check("config set token sai dinh dang bi tu choi (tep khong doi)", rc == 64 and json.load(open(cfgp)).get("token") == TOKEN)
rc, out, err = run("config", "set", env=env_nocfg)
check("config set khong co gia tri -> ma 64", rc == 64)
open(cfgp, "w").write("{ khong phai json")
rc, out, err = run("status", env=env_nocfg)
check("tep cau hinh hong (khong phai JSON) -> coi nhu chua co, bao thieu host (ma 64), khong sap", rc == 64 and "Traceback" not in err)

# ---------------------------------------------------------------- 7. watch
rc, out, err = run("watch", "--interval", "0.2", "--count", "3", "--max-disk", "90")
lines = [l for l in out.strip().splitlines()]
check("watch --count 3: in dung 3 dong co gio, moi dong 'OK - ...'", rc == 0 and len(lines) == 3 and all(re.match(r"\d\d:\d\d:\d\d  OK - ", l) for l in lines), out)
rc, out, err = run("watch", "--interval", "0.1", "--count", "2", env={"WPPOCKET_PORT": "1"})
check("watch khi mat ket noi: van chay het so lan, moi dong 'UNKNOWN - ...', ma thoat cuoi 3", rc == 3 and out.count("UNKNOWN - ") == 2, out)

# ---------------------------------------------------------------- 8. ham thuan + khong lo token + chi stdlib
check("parse_duration gia tri chinh xac", C.parse_duration("30s") == 30 and C.parse_duration("10m") == 600 and C.parse_duration("48h") == 172800 and C.parse_duration("2d") == 172800 and C.parse_duration("30") == 30)
check("parse_duration tu choi 0, 5x, rong, -1, 1.5h", all(C.parse_duration(x) is None for x in ("0", "5x", "", "-1", "1.5h", "0m")))
check("mask_token: 64 ky tu -> 'xxxx...xxxx'; ngan -> ****", C.mask_token(TOKEN) == "0123...cdef" and C.mask_token("abc") == "****" and C.mask_token("") == "")
check("human_duration: 5 giay / 3 phut / 2 gio / 4 ngay, am -> 0 giay", [C.human_duration(x, "vi") for x in (5, 180, 7300, 400000, -9)] == ["5 giây", "3 phút", "2 giờ", "4 ngày", "0 giây"])
src = open(CLI, encoding="utf-8").read()
imports = set(re.findall(r"^(?:import|from)\s+([a-z_]+)", src, re.M))
std = set(sys.stdlib_module_names) if hasattr(sys, "stdlib_module_names") else None
check("chi import thu vien chuan: %s" % sorted(imports), std is None or imports <= std)
check("dung ProxyHandler({}) (khong gui token qua proxy cua moi truong) va chan chuyen huong", "ProxyHandler({})" in src and "redirect_request" in src and "return None" in src)
check("khong co eval/exec/os.system/subprocess/shell trong CLI", not re.search(r"\b(eval|exec|os\.system|subprocess|shell=True)\b", src))

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
