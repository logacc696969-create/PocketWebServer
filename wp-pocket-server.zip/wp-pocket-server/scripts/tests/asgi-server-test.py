#!/usr/bin/env python3
"""H2 phan ASGI (PDF 1; HANDOFF.md muc 1bq-K): kiem chung cau noi ASGI->WSGI (AsgiBridge trong scripts/runtimes/wpp_wsgi.py) bang HTTP THAT.

Ung dung ASGI 3.0 viet TAY theo dac ta (khong co Starlette/FastAPI trong moi truong nay - neu co thi chay them mot ung dung Starlette that).
Mo may chu that tren cong ngau nhien, gui yeu cau bang http.client/socket, chay lenh that bang subprocess (lifespan, SIGTERM, loi khoi dong).
"""
import contextlib, hashlib, http.client, importlib.util, io, json, os, signal, socket, subprocess, sys, tempfile, textwrap, threading, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRV = os.path.join(ROOT, "scripts", "runtimes", "wpp_wsgi.py")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


spec = importlib.util.spec_from_file_location("wpp_wsgi", SRV)
W = importlib.util.module_from_spec(spec)
sys.modules["wpp_wsgi"] = W
spec.loader.exec_module(W)

APP_SRC = textwrap.dedent('''
    import asyncio, hashlib, json, os
    EVENTS = os.environ.get("ASGI_EVENTS")
    MODE = os.environ.get("ASGI_LIFESPAN", "ok")
    CALLS = {"n": 0}

    def log(x):
        if EVENTS:
            with open(EVENTS, "a") as f:
                f.write(x + "\\n")

    async def respond(send, status, body, headers=None):
        h = [(b"content-type", b"text/plain; charset=utf-8")] + (headers or [])
        await send({"type": "http.response.start", "status": status, "headers": h})
        await send({"type": "http.response.body", "body": body})

    async def app(scope, receive, send):
        if scope["type"] == "lifespan":
            if MODE == "unsupported":
                raise RuntimeError("lifespan khong ho tro")
            while True:
                msg = await receive()
                if msg["type"] == "lifespan.startup":
                    if MODE == "fail":
                        await send({"type": "lifespan.startup.failed", "message": "db down"})
                        return
                    scope["state"]["db"] = "connected"
                    log("startup")
                    await send({"type": "lifespan.startup.complete"})
                elif msg["type"] == "lifespan.shutdown":
                    log("shutdown")
                    await send({"type": "lifespan.shutdown.complete"})
                    return
        assert scope["type"] == "http"
        CALLS["n"] += 1
        path = scope["path"]
        body = b""
        while True:
            m = await receive()
            body += m.get("body", b"")
            if not m.get("more_body"):
                break
        if path == "/hello":
            return await respond(send, 200, "xin chao".encode())
        if path == "/scope":
            d = {k: scope[k] for k in ("method", "path", "scheme", "http_version", "root_path", "client", "server", "state")}
            d["raw_path"] = scope["raw_path"].decode()
            d["query_string"] = scope["query_string"].decode()
            d["asgi"] = scope["asgi"]
            d["headers"] = {k.decode(): v.decode() for k, v in scope["headers"]}
            d["body_len"] = len(body)
            return await respond(send, 200, json.dumps(d).encode(), [(b"content-type", b"application/json")])
        if path.startswith("/unicode/"):
            return await respond(send, 200, path.encode())
        if path == "/echo-sha":
            return await respond(send, 200, json.dumps({"len": len(body), "sha": hashlib.sha256(body).hexdigest()}).encode())
        if path == "/stream":
            await send({"type": "http.response.start", "status": 200, "headers": [(b"content-type", b"text/plain")]})
            for ch in (b"a", b"b", b"c"):
                await send({"type": "http.response.body", "body": ch * 1000, "more_body": True})
                await asyncio.sleep(0.01)
            await send({"type": "http.response.body", "body": b"", "more_body": False})
            return
        if path == "/boom":
            raise RuntimeError("loi gia lap TRUOC khi gui")
        if path == "/boom-after-start":
            await send({"type": "http.response.start", "status": 200, "headers": []})
            raise RuntimeError("loi gia lap SAU khi gui start")
        if path == "/nostart":
            return
        if path == "/slow":
            await asyncio.sleep(float(scope["query_string"].decode() or "3"))
            return await respond(send, 200, b"cham")
        if path == "/concurrent":
            await asyncio.sleep(0.4)
            return await respond(send, 200, b"ok")
        if path == "/cookies":
            return await respond(send, 200, b"c", [(b"set-cookie", b"a=1; Path=/"), (b"set-cookie", b"b=2; Path=/")])
        if path == "/hop":
            return await respond(send, 200, b"h", [(b"transfer-encoding", b"chunked"), (b"connection", b"keep-alive"), (b"x-keep", b"yes")])
        if path == "/head-body":
            return await respond(send, 200, b"khong duoc gui", [(b"content-length", b"14")])
        if path == "/state":
            return await respond(send, 200, scope["state"].get("db", "none").encode())
        if path == "/disconnect-wait":
            try:
                m = await asyncio.wait_for(receive(), 0.3)
                r = m["type"]
            except asyncio.TimeoutError:
                r = "blocked"
            return await respond(send, 200, r.encode())
        return await respond(send, 404, b"khong co")
''')

tmp = tempfile.mkdtemp()
with open(os.path.join(tmp, "asgi_testapp.py"), "w") as f:
    f.write(APP_SRC)
with open(os.path.join(tmp, "sync_app.py"), "w") as f:
    f.write("def app(environ, start_response):\n    start_response('200 OK', [])\n    return [b'x']\n")
sys.path.insert(0, tmp)
os.chdir(tmp)
import asgi_testapp as T


def req(port, method, path, body=None, headers=None, timeout=10):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=timeout)
    c.request(method, path, body=body, headers=headers or {})
    r = c.getresponse()
    data = r.read()
    out = (r.status, r.getheaders(), data)
    c.close()
    return out


def hd(headers):
    return dict((k.lower(), v) for k, v in headers)


def serve(**kw):
    bridge = W.AsgiBridge(T.app, timeout=kw.pop("timeout", 2))
    err = bridge.start()
    server = W.make_server(bridge, host="127.0.0.1", port=0, max_body_mb=2, **kw)
    th = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True)
    th.start()
    return bridge, server, server.server_address[1], th, err


bridge, server, port, th, err = serve()
check("lifespan.startup: app tra complete -> start() = None, lifespan_active = True", err is None and bridge.lifespan_active is True, err)
st, h, body = req(port, "GET", "/state")
check("state tu lifespan (scope['state']['db']) tro toi yeu cau HTTP: 'connected'", st == 200 and body == b"connected")
st, h, body = req(port, "GET", "/hello")
check("GET /hello: 200, dung noi dung, co Content-Length (tinh tu body da gom), Content-Type cua app", st == 200 and body == "xin chao".encode() and hd(h).get("content-length") == "8" and hd(h).get("content-type", "").startswith("text/plain"))

# ---------------------------------------------------------------- scope theo dac ta ASGI 3.0
st, h, body = req(port, "POST", "/scope?x=1&y=%C3%A1", body=b"abc", headers={"Host": "example.test", "X-Custom": "gia tri", "Content-Type": "text/plain"})
d = json.loads(body)
check("scope: type http, asgi 3.0/2.3, method, path, query_string GIU NGUYEN (chua giai ma), root_path rong", d["method"] == "POST" and d["path"] == "/scope" and d["query_string"] == "x=1&y=%C3%A1" and d["asgi"] == {"version": "3.0", "spec_version": "2.3"} and d["root_path"] == "")
check("scope: headers la TEN CHU THUONG + gia tri (host, x-custom, content-type, content-length)", d["headers"].get("host") == "example.test" and d["headers"].get("x-custom") == "gia tri" and d["headers"].get("content-type") == "text/plain" and d["headers"].get("content-length") == "3", d["headers"])
check("scope: client = (127.0.0.1, 0), server = (host, cong dung), scheme http, http_version 1.x, body 3 byte da giao qua receive()", d["client"][0] == "127.0.0.1" and d["server"][1] == port and d["scheme"] == "http" and d["http_version"] in ("1.0", "1.1") and d["body_len"] == 3, d)
check("scope: state la BAN SAO NONG cua state lifespan (co db)", d["state"] == {"db": "connected"})
st, h, body = req(port, "GET", "/unicode/ti%E1%BA%BFng-Vi%E1%BB%87t")
check("duong dan UTF-8 duoc giai ma dung ('/unicode/tiếng-Việt')", body.decode("utf-8") == "/unicode/tiếng-Việt", body)
d = json.loads(req(port, "GET", "/scope?q=1")[2])
check("raw_path la duong dan da ma hoa phan tram (bytes ascii)", d["raw_path"] == "/scope")
st, h, body = req(port, "GET", "/unicode/ti%E1%BA%BFng")
check("raw_path khong lam hong: yeu cau voi %XX van den ung dung", st == 200)

# ---------------------------------------------------------------- body / streaming / loi
payload = os.urandom(1000000)
r = json.loads(req(port, "POST", "/echo-sha", body=payload)[2])
check("POST 1 MB: ung dung ASGI nhan DUNG tung byte qua receive() (sha256 khop)", r["len"] == len(payload) and r["sha"] == hashlib.sha256(payload).hexdigest())
n0 = T.CALLS["n"]
st, h, body = req(port, "POST", "/echo-sha", body=b"y" * (3 * 1024 * 1024))
check("body 3 MB > gioi han 2 MB -> 413 TRUOC khi goi ung dung ASGI (lop guard dung chung voi WSGI)", st == 413 and T.CALLS["n"] == n0)
st, h, body = req(port, "GET", "/stream")
check("phan hoi nhieu manh (more_body=True x3 + manh rong cuoi): GOM DU 3000 byte dung thu tu, Content-Length = 3000", st == 200 and body == b"a" * 1000 + b"b" * 1000 + b"c" * 1000 and hd(h).get("content-length") == "3000")
errbuf = io.StringIO()
with contextlib.redirect_stderr(errbuf):
    s1 = req(port, "GET", "/boom")[0]
    s2 = req(port, "GET", "/boom-after-start")[0]
    s3 = req(port, "GET", "/nostart")[0]
check("app nem loi (truoc/sau http.response.start) hoac ket thuc ma khong gui start -> 500 (vi da GOM nen khong gui nua chung), may chu van song", (s1, s2, s3) == (500, 500, 500) and req(port, "GET", "/hello")[0] == 200, (s1, s2, s3))
check("traceback ghi ra stderr (xem trong nhat ky app)", "loi gia lap TRUOC khi gui" in errbuf.getvalue() and "Traceback" in errbuf.getvalue())
st, h, body = req(port, "GET", "/cookies")
cookies = [v for k, v in h if k.lower() == "set-cookie"]
check("hai Set-Cookie cua ung dung DEU toi client (header lap lai khong bi gop/mat)", sorted(cookies) == ["a=1; Path=/", "b=2; Path=/"], cookies)
st, h, body = req(port, "GET", "/hop")
check("header hop-by-hop (transfer-encoding, connection) cua ung dung bi LOC (wsgiref cam), header thuong x-keep van con", st == 200 and "x-keep" in hd(h) and hd(h).get("transfer-encoding") is None and body == b"h", h)
# Doc BYTE THO tu socket: http.client tu bo qua body cua HEAD nen khong phat hien duoc may chu lo gui body (doi chung am da lo ra dieu nay).
s_ = socket.create_connection(("127.0.0.1", port), timeout=5)
s_.sendall(b"HEAD /head-body HTTP/1.1\r\nHost: x\r\n\r\n")
raw_resp = b""
while True:
    chunk = s_.recv(65536)
    if not chunk:
        break
    raw_resp += chunk
s_.close()
head_part, _, tail_part = raw_resp.partition(b"\r\n\r\n")
check("HEAD: ung dung lo gui body -> may chu KHONG gui byte body nao (doc byte tho), giu Content-Length cua ung dung (14)", head_part.startswith(b"HTTP/1.") and b" 200 " in head_part.split(b"\r\n")[0] and b"content-length: 14" in head_part.lower() and tail_part == b"", raw_resp[-60:])
st, h, body = req(port, "GET", "/disconnect-wait")
check("receive() lan 2 CHAN (khong tra http.disconnect ngay): Starlette/StreamingResponse khong bi huy som", body == b"blocked", body)

# ---------------------------------------------------------------- dong thoi that (async)
t0 = time.time()
res = []
ths = [threading.Thread(target=lambda: res.append(req(port, "GET", "/concurrent")[0])) for _ in range(12)]
[t.start() for t in ths]
[t.join() for t in ths]
el = time.time() - t0
check("12 yeu cau cham 0,4 giay xong trong %.1fs (< 1.8s): chay DONG THOI tren vong lap asyncio (tuan tu se la ~4.8s)" % el, res.count(200) == 12 and el < 1.8, (res, el))

# ---------------------------------------------------------------- timeout
t0 = time.time()
errbuf = io.StringIO()
with contextlib.redirect_stderr(errbuf):
    st, h, body = req(port, "GET", "/slow?5", timeout=8)
check("ung dung khong ket thuc trong --asgi-timeout (2s) -> 504 sau ~2s (khong treo luong mai)", st == 504 and 1.5 < time.time() - t0 < 4.5, (st, time.time() - t0))
time.sleep(0.2)
check("sau timeout may chu hoi phuc: yeu cau tiep theo 200", req(port, "GET", "/hello")[0] == 200)
server.shutdown(); server.server_close()
bridge.stop()

# ---------------------------------------------------------------- proxy tin / khong tin
bridge2, server2, port2, th2, _ = serve(trust_proxy=True)
d = json.loads(req(port2, "GET", "/scope", headers={"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})[2])
check("--trust-proxy + ASGI: scope.client = IP that tu X-Forwarded-For, scope.scheme = https (lop guard dung chung voi WSGI)", d["client"][0] == "203.0.113.9" and d["scheme"] == "https", d)
server2.shutdown(); server2.server_close(); bridge2.stop()
bridge3, server3, port3, th3, _ = serve(trust_proxy=False)
d = json.loads(req(port3, "GET", "/scope", headers={"X-Forwarded-For": "203.0.113.9", "X-Forwarded-Proto": "https"})[2])
check("mac dinh (khong --trust-proxy): bo qua X-Forwarded-* trong scope", d["client"][0] == "127.0.0.1" and d["scheme"] == "http")
server3.shutdown(); server3.server_close(); bridge3.stop()

# ---------------------------------------------------------------- lenh that
def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def run_cli(args, env_extra=None, wait_listen=True):
    e = dict(os.environ)
    e.update(env_extra or {})
    p = subprocess.Popen([sys.executable, SRV] + args, cwd=tmp, env=e, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    line = p.stdout.readline() if wait_listen else ""
    return p, line


ev = os.path.join(tmp, "events.log")
open(ev, "w").close()
p1 = free_port()
proc, line = run_cli(["asgi_testapp:app", "--asgi", "--port", str(p1)], {"ASGI_EVENTS": ev})
st = req(p1, "GET", "/state")[2]
ev_before = open(ev).read()
t0 = time.time()
proc.send_signal(signal.SIGTERM)
try:
    rc = proc.wait(8)
except subprocess.TimeoutExpired:
    proc.kill(); rc = None
ev_after = open(ev).read()
check("lenh that --asgi: in 'listening', lifespan.startup chay TRUOC khi nhan khach (events='startup'), phuc vu dung", "listening 127.0.0.1:%d" % p1 in line and ev_before.strip() == "startup" and st == b"connected", (line, ev_before, st))
check("SIGTERM -> lifespan.shutdown chay (events them 'shutdown') roi thoat ma 0 trong %.1fs" % (time.time() - t0), rc == 0 and ev_after.split() == ["startup", "shutdown"], (rc, ev_after))
p2 = free_port()
r = subprocess.run([sys.executable, SRV, "asgi_testapp:app", "--asgi", "--port", str(p2)], cwd=tmp, env=dict(os.environ, ASGI_LIFESPAN="fail"), capture_output=True, text=True, timeout=30)
check("lifespan.startup.failed ('db down') -> KHONG mo cong, thoat ma khac 0 voi thong bao ro (nhu uvicorn)", r.returncode not in (0, None) and "lifespan startup that bai: db down" in r.stderr, r.stderr)
try:
    socket.create_connection(("127.0.0.1", p2), timeout=1).close()
    opened = True
except OSError:
    opened = False
check("...va cong thuc su KHONG mo", not opened)
p3 = free_port()
proc, line = run_cli(["asgi_testapp:app", "--asgi", "--port", str(p3)], {"ASGI_LIFESPAN": "unsupported"})
ok = req(p3, "GET", "/hello")[0] == 200
proc.send_signal(signal.SIGTERM)
rc = proc.wait(8)
check("app KHONG ho tro lifespan (nem loi voi scope lifespan): may chu van chay binh thuong (dung dac ta), thoat sach ma 0", "listening" in line and ok and rc == 0, (line, ok, rc))
r = subprocess.run([sys.executable, SRV, "sync_app:app", "--asgi", "--port", str(free_port())], cwd=tmp, capture_output=True, text=True, timeout=30)
check("--asgi voi ung dung WSGI dong bo (khong async) bi tu choi ro rang, khong chay sai", r.returncode not in (0, None) and "khong giong ung dung ASGI" in r.stderr, r.stderr)
r = subprocess.run([sys.executable, SRV, "asgi_testapp:app", "--asgi", "--asgi-timeout", "0"], cwd=tmp, capture_output=True, text=True, timeout=30)
check("--asgi-timeout 0 bi tu choi", r.returncode not in (0, None) and "--asgi-timeout" in r.stderr)

# ---------------------------------------------------------------- chi stdlib + Starlette that neu co
import re
src = open(SRV, encoding="utf-8").read()
imports = set(re.findall(r"^(?:import|from)\s+([a-z_]+)", src, re.M))
stdlib = set(sys.stdlib_module_names) if hasattr(sys, "stdlib_module_names") else None
check("van chi import thu vien chuan (them asyncio/concurrent.futures/http/inspect/urllib): %s" % sorted(imports), stdlib is None or imports <= stdlib, str(imports - (stdlib or set())))
try:
    import starlette  # noqa
    have = True
except Exception:
    have = False
if have:
    with open(os.path.join(tmp, "star_app.py"), "w") as f:
        f.write("from starlette.applications import Starlette\nfrom starlette.responses import JSONResponse\nfrom starlette.routing import Route\nasync def hi(request):\n    return JSONResponse({'hi': request.path_params['n'], 'ip': request.client.host})\napp = Starlette(routes=[Route('/hi/{n}', hi)])\n")
    b = W.AsgiBridge(W.load_app("star_app:app")); b.start()
    s = W.make_server(b, port=0); pp = s.server_address[1]
    threading.Thread(target=s.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True).start()
    check("Starlette THAT chay qua cau noi: route co tham so", json.loads(req(pp, "GET", "/hi/an")[2])["hi"] == "an")
    s.shutdown(); s.server_close(); b.stop()
else:
    print("(bo qua kiem Starlette that: chua cai trong moi truong nay)")

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
