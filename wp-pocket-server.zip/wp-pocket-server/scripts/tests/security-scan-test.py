#!/usr/bin/env python3
"""Kiem thu security-scan.php (quet ma doc / file la / thay doi diem bam tru - HANDOFF.md muc 1br) bang PHP CLI THAT tren cay WordPress gia lap.
Khong can nginx/MariaDB/mang. Xem docs/SECURITY.md.

Trong tam (nhung dieu NGUY HIEM neu sai):
  1) KHONG bao nham tren site sach: file loi dung checksum, thu vien hop phap dung base64 -> khong bao CAO; cap nhat WordPress khong gay bao dong;
  2) bat duoc ke tan cong that: php trong uploads, anh polyglot, loi bi sua, file la o goc, mu-plugin/drop-in moi, plugin moi, web-shell;
  3) cach ly chi di chuyen file DANG nam trong ket qua quet (khong dung de di chuyen wp-config.php / file tuy y / ".."), khoi phuc khong ghi de;
  4) quet khong treo/khong do (qua nhieu file, het gio -> truncated va KHONG lap moc do dang).
"""
import hashlib, json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
SCAN = os.path.join(TPL, 'security-scan.php')
PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:300]) if detail else ''))


PHP_FLAGS = ['-d', 'display_errors=1', '-d', 'error_reporting=E_ALL', '-d', 'date.timezone=UTC']
DRIVER = r'''<?php
define("WPP_SCAN_AS_LIB", 1);
require $argv[1];
$cmd = $argv[2];
if ($cmd === "run") { echo json_encode(wpp_scan_run($argv[3], $argv[4], (int) $argv[5], isset($argv[6]) ? json_decode($argv[6], true) : [])); }
elseif ($cmd === "score") { echo json_encode(wpp_scan_score_content(file_get_contents($argv[3]))); }
elseif ($cmd === "quar") { echo json_encode(wpp_scan_quarantine($argv[3], $argv[4], $argv[5], (int) $argv[6])); }
elseif ($cmd === "restore") { echo json_encode(wpp_scan_restore($argv[3], $argv[4], $argv[5])); }
elseif ($cmd === "ignore") { echo json_encode(wpp_scan_ignore($argv[3], $argv[4], $argv[5])); }
elseif ($cmd === "accept") { echo json_encode(wpp_scan_accept($argv[3])); }
elseif ($cmd === "info") { echo json_encode(wpp_scan_wp_info($argv[3])); }
'''

WP_VERSION = '6.9.5'
T0 = 1_900_000_000

CLEAN_PHP = "<?php\n// plugin hop phap\nfunction hello_world() { return 'hi'; }\n"
# thu vien hop phap hay dung eval/base64 nhung KHONG goi tu request: khong duoc len muc CAO
LEGIT_LIB = "<?php\nclass Enc { function d($s) { return base64_decode($s); } function t() { return eval('return 1;'); } }\n"
SHELL_EVAL = "<?php @eval(base64_decode($_POST['x']));\n"
SHELL_DYN = "<?php $_REQUEST['c']($_REQUEST['d']);\n"
SHELL_NAMED = "<?php /* c99shell by someone */ echo 'x';\n"
SHELL_OBF = "<?php $a = chr(101).chr(118).chr(97).chr(108).chr(40).chr(36).chr(95).chr(80).chr(79); echo $a;\n"
SHELL_SYS = "<?php if (isset($_GET['k'])) { system($_GET['k']); }\n"
SHELL_PUT = "<?php file_put_contents('x.php', $_POST['code']);\n"
POLYGLOT = b"GIF89a;\n<?php system($_GET['x']); ?>\n"


class Env:
    def __init__(self):
        self.tmp = tempfile.mkdtemp(prefix='secscan-')
        self.root = os.path.join(self.tmp, 'www')
        self.run = os.path.join(self.tmp, 'lamp-run')
        os.makedirs(self.run)
        self.driver = os.path.join(self.tmp, 'driver.php')
        open(self.driver, 'w').write(DRIVER)
        self.core = {}
        self.build_wp()

    def w(self, rel, content, mode='w'):
        p = os.path.join(self.root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, mode + ('b' if isinstance(content, bytes) else '')) as f:
            f.write(content)
        return p

    def build_wp(self):
        self.w('wp-load.php', "<?php // load\n")
        self.w('wp-includes/version.php', "<?php\n$wp_version = '%s';\n$wp_db_version = 60000;\n" % WP_VERSION)
        for n in ['index.php', 'wp-login.php', 'wp-settings.php', 'wp-cron.php', 'xmlrpc.php', 'wp-blog-header.php', 'wp-load.php']:
            self.w(n, "<?php\n// core %s\nrequire __DIR__ . '/wp-load.php';\n" % n) if n != 'wp-load.php' else None
        self.w('wp-config.php', "<?php\ndefine('DB_NAME', 'wp');\n")
        for i in range(60):
            self.w('wp-includes/core-%d.php' % i, "<?php\nfunction core_fn_%d() { return %d; }\n" % (i, i))
        for i in range(50):
            self.w('wp-admin/adm-%d.php' % i, "<?php\nfunction adm_fn_%d() { return %d; }\n" % (i, i))
        self.w('wp-content/index.php', "<?php // Silence is golden.\n")
        self.w('wp-content/plugins/good/good.php', CLEAN_PHP)
        self.w('wp-content/plugins/good/lib/enc.php', LEGIT_LIB)
        self.w('wp-content/themes/twentytwenty/functions.php', CLEAN_PHP)
        self.w('wp-content/uploads/2026/01/photo.jpg', b"\xff\xd8\xff\xe0JFIF binary" + b"\x00" * 50)
        self.w('wp-content/uploads/2026/01/note.txt', "plain text\n")
        self.refresh_core()

    def refresh_core(self):
        """Ghi lai checksum 'chinh thuc' = MD5 hien tai cua cac file loi (gia lap wordpress.org)."""
        self.core = {}
        for base in ('wp-includes', 'wp-admin'):
            for dp, _dn, fn in os.walk(os.path.join(self.root, base)):
                for f in fn:
                    if f.endswith('.php'):
                        full = os.path.join(dp, f)
                        self.core[os.path.relpath(full, self.root)] = hashlib.md5(open(full, 'rb').read()).hexdigest()
        for n in ['index.php', 'wp-login.php', 'wp-settings.php', 'wp-cron.php', 'xmlrpc.php', 'wp-blog-header.php', 'wp-load.php']:
            full = os.path.join(self.root, n)
            if os.path.exists(full):
                self.core[n] = hashlib.md5(open(full, 'rb').read()).hexdigest()
        self.write_core()

    def write_core(self, version=WP_VERSION):
        json.dump({'version': version, 'locale': 'en_US', 'fetched': T0, 'checksums': self.core}, open(os.path.join(self.run, 'wp-core-checksums.json'), 'w'))

    def php(self, *args):
        r = subprocess.run(['php'] + PHP_FLAGS + [self.driver, SCAN] + [str(a) for a in args], capture_output=True, text=True)
        return r.stdout, r.stderr, r.returncode

    def scan(self, now=T0, managed=None):
        out, err, rc = self.php('run', self.root, self.run, now, *([json.dumps(managed)] if managed is not None else []))
        try:
            return json.loads(out)
        except ValueError:
            return {'_raw': out, '_err': err, '_rc': rc, 'findings': [], 'counts': {}}

    def kinds(self, res):
        return sorted(f['kind'] + ':' + f['file'] for f in res.get('findings', []))

    def find(self, res, kind, file=None):
        return [f for f in res.get('findings', []) if f['kind'] == kind and (file is None or f['file'] == file)]

    def clean(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def score(e, text):
    p = os.path.join(e.tmp, 'sample.php')
    open(p, 'w').write(text)
    out, err, rc = e.php('score', p)
    try:
        return json.loads(out)
    except ValueError:
        return [None, [err]]


def main():
    r = subprocess.run(['php', '-l', SCAN], capture_output=True, text=True)
    check('php -l security-scan.php', r.returncode == 0, r.stdout + r.stderr)

    # ===== 1) Cham diem noi dung (khong can cay WordPress) =====
    e = Env()
    try:
        s, h = score(e, CLEAN_PHP)
        check('cham diem: file sach = 0', s == 0 and h == [], (s, h))
        s, h = score(e, LEGIT_LIB)
        check('cham diem: thu vien eval+base64 hop phap < nguong CAO (8) va < nguong TB (5)... eval-don 2 + base64 1', s < 5.0, (s, h))
        s, h = score(e, SHELL_EVAL)
        check('cham diem: eval(base64_decode($_POST)) -> CAO', s >= 8.0, (s, h))
        s, h = score(e, SHELL_DYN)
        check('cham diem: $_REQUEST[c]($_REQUEST[d]) -> CAO', s >= 8.0, (s, h))
        s, h = score(e, SHELL_NAMED)
        check('cham diem: ten web-shell noi tieng -> CAO', s >= 8.0, (s, h))
        s, h = score(e, SHELL_OBF)
        check('cham diem: noi chuoi chr() lien tuc -> TB tro len', s >= 5.0, (s, h))
        s, h = score(e, SHELL_SYS)
        check('cham diem: system($_GET[..]) -> CAO', s >= 8.0, (s, h))
        s, h = score(e, SHELL_PUT)
        check('cham diem: file_put_contents(..php.., $_POST) -> CAO', s >= 8.0, (s, h))
        s, h = score(e, "<?php\n$x = '" + 'A' * 5000 + "';\n")
        check('cham diem: blob base64 dai ~5000 ky tu cho diem nhung KHONG tu no thanh CAO', 0 < s < 8.0, (s, h))
        s, h = score(e, "<?php\n$x = '" + 'A' * 2300 + "';\n")
        check('cham diem: chuoi 2300 ky tu chua toi nguong blob', s == 0, (s, h))
        # --- bat web shell THAT chi lo ra khi dung WordPress that (HANDOFF.md muc 1br-H, wp-real-test.py) ---
        for name, code, want in [
            ('$f = $_POST[k]; $f($_POST[v]) (goi ham qua BIEN gan tu request)', '<?php $f = $_POST["k"]; $f($_POST["v"]); ?>', True),
            ("$a=@$_GET['x']; ... $a($_GET['y'])", "<?php $a=@$_GET['x']; echo 1; $a($_GET['y']);", True),
            ('array_map($_GET[f], ..) (callback tu request)', '<?php array_map($_GET["f"], $arr);', True),
            ('usort($arr, $_POST[f]) (callback o doi so 2)', '<?php usort($arr, $_POST["f"]);', True),
            ('call_user_func($_REQUEST[f], ..)', '<?php call_user_func($_REQUEST["f"], 1);', True),
            ('chuoi thoat hex IN DUOC "\\x65\\x76\\x61\\x6c..." (giau ten ham)', '<?php $f = "\\x65\\x76\\x61\\x6c\\x28\\x24\\x5f\\x50";', True),
            ('chuoi thoat bat phan IN DUOC "\\145\\166..."', '<?php $f = "\\145\\166\\141\\154\\050\\044\\137\\120";', True),
            ('DOI CHUNG: $this->$method() / Foo::$method() la hop phap', '<?php $method = $_GET["m"]; $this->$method(); Foo::$method();', False),
            ('DOI CHUNG: $name = $_POST[name]; esc_html($name)', '<?php $name = $_POST["name"]; echo esc_html($name);', False),
            ('DOI CHUNG: array_map("trim", $_POST[items]) / call_user_func_array($cb, $_POST[args]) (request la DU LIEU)', '<?php $x = array_map("trim", $_POST["items"]); call_user_func_array($cb, $_POST["args"]);', False),
            ('DOI CHUNG: preg_replace_callback($p, $cb, $_POST[s]) (request la chuoi nguon)', '<?php preg_replace_callback($p, $cb, $_POST["s"]);', False),
            ('DOI CHUNG: bang hex NHI PHAN \\x00\\x01.. (thu vien SimplePie/getID3/sodium) khong du de bao', '<?php $t = "\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07\\x08\\x09\\x0a\\x0b\\xff\\xfe";', False),
            ('DOI CHUNG: chu thich "must match $var (the key)" (wp-cron.php that)', "<?php\n$d = $_GET['doing_wp_cron'];\n/* must match $d (the \"key\") */\n", False),
        ]:
            s, h = score(e, code)
            check('cham diem: ' + name, (s >= 5.0) == want, (s, h))
        import time as _t
        t0 = _t.time()
        s, h = score(e, "<?php\n" + ('$a = $_POST["x"];\n' * 100_000))
        check('cham diem: 100k dong "$a = $_POST[x];" (khong goi) chay < 8s va KHONG bao dong', _t.time() - t0 < 8.0 and s < 5.0, (_t.time() - t0, s, h))
        # chong DoS regex: file 2MB toan 1 ky tu khong lam treo
        import time
        t = time.time()
        s, h = score(e, "<?php\n" + ('a' * 2_000_000) + "\n")
        check('cham diem: file 2MB 1 ky tu chay < 5s (khong backtrack bung no)', time.time() - t < 5.0, time.time() - t)
        t = time.time()
        s, h = score(e, "<?php\n" + ('eval(' * 200_000))
        check('cham diem: 200k "eval(" chay < 5s', time.time() - t < 5.0, time.time() - t)
    finally:
        e.clean()

    # ===== 2) Site sach: khong bao nham =====
    e = Env()
    try:
        res = e.scan()
        check('site sach: lan quet dau tao moc (baseline_created) va KHONG co phat hien CAO/NGHIEM TRONG', res.get('baseline_created') is True and res['counts']['critical'] == 0 and res['counts']['high'] == 0, (res.get('counts'), e.kinds(res)))
        check('site sach: nhan dien WordPress + checksum xac minh', res.get('profile') == 'wordpress' and res['core']['verified'] is True and res['core']['version'] == WP_VERSION, res.get('core'))
        check('site sach: ghi security-scan.json + security-baseline.json', os.path.isfile(os.path.join(e.run, 'security-scan.json')) and os.path.isfile(os.path.join(e.run, 'security-baseline.json')))
        res2 = e.scan(T0 + 100)
        check('site sach: lan quet 2 khong co gi (0 phat hien) va khong tao lai moc', res2['findings'] == [] and res2['baseline_created'] is False, (e.kinds(res2), res2.get('baseline_created')))
        ev = os.path.join(e.run, 'security-events.log')
        check('site sach: khong ghi su kien canh bao', not os.path.exists(ev) or open(ev).read() == '')
        # thu vien hop phap khong bi bao CAO
        check('site sach: plugin co thu vien base64/eval hop phap khong bi ghi "nghi-web-shell"', not e.find(res2, 'nghi-web-shell'))
    finally:
        e.clean()

    # ===== 3) Ke tan cong =====
    e = Env()
    try:
        e.scan()                               # lap moc sach
        # 3a) PHP trong uploads
        e.w('wp-content/uploads/2026/01/cache.php', "<?php echo 1;\n")
        e.w('wp-content/uploads/shell.phtml', "<?php echo 2;\n")
        # 3b) anh polyglot
        e.w('wp-content/uploads/2026/01/avatar.png', POLYGLOT)
        e.w('wp-content/uploads/2026/01/ok.png', b"\x89PNG\r\n\x1a\n" + b"\x00" * 100)
        e.w('wp-content/uploads/.htaccess', "AddType application/x-httpd-php .jpg\n")
        # 3c) loi bi sua + file la trong wp-includes
        e.w('wp-includes/core-3.php', "<?php\nfunction core_fn_3() { return 3; }\n@eval(base64_decode($_POST['z']));\n")
        e.w('wp-includes/rogue.php', CLEAN_PHP)
        # 3d) file la o goc site + diem bam tru: mu-plugin, drop-in, wp-config doi
        e.w('about.php', CLEAN_PHP)
        e.w('wp-content/mu-plugins/aaa.php', CLEAN_PHP)
        e.w('wp-content/db.php', CLEAN_PHP)
        e.w('wp-config.php', "<?php\ndefine('DB_NAME', 'wp');\ninclude 'x.php';\n")
        # 3e) plugin gia + web-shell trong plugin
        e.w('wp-content/plugins/seo-booster/seo-booster.php', CLEAN_PHP)
        e.w('wp-content/plugins/good/shell.php', SHELL_EVAL)
        e.w('wp-content/themes/evil/functions.php', CLEAN_PHP)
        res = e.scan(T0 + 200)
        k = e.kinds(res)
        check('quet: php trong uploads (.php) -> CRITICAL', any(f['sev'] == 'critical' and f['file'] == 'wp-content/uploads/2026/01/cache.php' for f in e.find(res, 'php-trong-uploads')), k)
        check('quet: .phtml trong uploads -> CRITICAL', any(f['file'] == 'wp-content/uploads/shell.phtml' for f in e.find(res, 'php-trong-uploads')), k)
        check('quet: anh polyglot GIF89a+<?php -> HIGH anh-chua-ma-php', any(f['file'].endswith('avatar.png') for f in e.find(res, 'anh-chua-ma-php')), k)
        check('quet: anh PNG that khong bi bao', not any(f['file'].endswith('ok.png') for f in res['findings']), k)
        check('quet: .htaccess co AddType trong uploads -> HIGH', bool(e.find(res, 'htaccess-trong-uploads')), k)
        check('quet: file loi bi chen ma -> core-bi-sua HIGH', any(f['file'] == 'wp-includes/core-3.php' for f in e.find(res, 'core-bi-sua')), k)
        check('quet: file la trong wp-includes -> core-file-la HIGH', any(f['file'] == 'wp-includes/rogue.php' for f in e.find(res, 'core-file-la')), k)
        check('quet: file PHP la o goc -> php-la-o-goc-site', any(f['file'] == 'about.php' for f in e.find(res, 'php-la-o-goc-site')), k)
        check('quet: file o goc site moi so voi moc -> diem-bam-tru-moi HIGH', any(f['file'] == 'about.php' for f in e.find(res, 'diem-bam-tru-moi')), k)
        check('quet: mu-plugin moi -> diem-bam-tru-moi', any(f['file'] == 'wp-content/mu-plugins/aaa.php' for f in e.find(res, 'diem-bam-tru-moi')), k)
        check('quet: drop-in wp-content/db.php moi -> diem-bam-tru-moi', any(f['file'] == 'wp-content/db.php' for f in e.find(res, 'diem-bam-tru-moi')), k)
        check('quet: wp-config.php bi sua -> diem-bam-tru-doi', any(f['file'] == 'wp-config.php' for f in e.find(res, 'diem-bam-tru-doi')), k)
        check('quet: plugin moi (seo-booster) -> plugin-moi', any(f['file'].endswith('seo-booster') for f in e.find(res, 'plugin-moi')), k)
        check('quet: theme moi (evil) -> theme-moi', any(f['file'].endswith('themes/evil') for f in e.find(res, 'theme-moi')), k)
        check('quet: web-shell trong plugin cu -> nghi-web-shell HIGH', any(f['file'] == 'wp-content/plugins/good/shell.php' for f in e.find(res, 'nghi-web-shell')), k)
        check('quet: co >= 1 critical va thu tu sap xep: nghiem trong truoc', res['counts']['critical'] >= 2 and res['findings'][0]['sev'] == 'critical', res['counts'])
        ev = open(os.path.join(e.run, 'security-events.log')).read()
        check('su kien: ghi dong "ip=- PHAT HIEN MA DOC/THAY DOI LA" cho phat hien CAO/NGHIEM TRONG', 'ip=- PHAT HIEN MA DOC/THAY DOI LA (critical)' in ev and 'php-trong-uploads' in ev, ev[:300])
        n_ev = ev.count('\n')
        check('su kien: gioi han <= 11 dong/lan (10 + 1 dong "muc nua")', n_ev <= 11, n_ev)
        res_b = e.scan(T0 + 300)
        ev2 = open(os.path.join(e.run, 'security-events.log')).read()
        check('su kien: quet lai khong ghi trung su kien da bao', ev2 == ev, (len(ev), len(ev2)))
        check('quet lai: phat hien van con (khong tu mat)', res_b['counts']['critical'] == res['counts']['critical'])
    finally:
        e.clean()

    # ===== 4) Cap nhat WordPress hop phap khong gay bao dong =====
    e = Env()
    try:
        e.scan()
        e.w('wp-login.php', "<?php\n// core wp-login NEW VERSION\nrequire __DIR__ . '/wp-load.php';\n")
        e.w('wp-includes/core-7.php', "<?php\nfunction core_fn_7() { return 70; }\n")
        e.refresh_core()                       # wordpress.org cong bo checksum cua phien ban moi
        res = e.scan(T0 + 50)
        check('cap nhat WP hop phap (checksum khop): khong co phat hien nao', res['findings'] == [], e.kinds(res))
        # nhung neu checksum KHONG co: file goc doi -> diem-bam-tru-doi (that su dang ngo)
        e.w('wp-login.php', "<?php\n// sua tay\n")
        os.remove(os.path.join(e.run, 'wp-core-checksums.json'))
        res = e.scan(T0 + 60)
        check('thieu checksum loi: file goc doi noi dung duoc bao diem-bam-tru-doi (khong bo qua)', any(f['file'] == 'wp-login.php' for f in e.find(res, 'diem-bam-tru-doi')), e.kinds(res))
        check('thieu checksum loi: bao core.verified=false', res['core']['verified'] is False, res['core'])
        # WordPress doi phien ban nhung chua tai duoc checksum: file goc doi chi la canh bao trung binh (khong bao dong gia)
        e2 = Env()
        e2.scan()
        e2.w('wp-includes/version.php', "<?php\n$wp_version = '6.9.6';\n")
        e2.w('wp-login.php', "<?php\n// ban moi 6.9.6\n")
        e2.write_core(version='6.9.5')               # cache cu: sai phien ban -> khong dung
        res = e2.scan(T0 + 5)
        f = e2.find(res, 'loi-doi-chua-xac-minh', 'wp-login.php')
        check('doi phien ban chua co checksum: file goc doi -> TRUNG BINH "loi-doi-chua-xac-minh" (khong phai CAO)', bool(f) and f[0]['sev'] == 'medium' and not e2.find(res, 'diem-bam-tru-doi', 'wp-login.php'), e2.kinds(res))
        e2.clean()
        # checksum cua phien ban khac -> khong dung
        e.write_core(version='6.0.0')
        res = e.scan(T0 + 70)
        check('checksum cache sai phien ban -> khong dung (verified=false)', res['core']['verified'] is False, res['core'])
    finally:
        e.clean()

    # ===== 4b) File do chinh ung dung dong bo (mu-plugin Shield) =====
    e = Env()
    try:
        v1 = "<?php // shield v1\n"
        e.w('wp-content/mu-plugins/wppocket-shield.php', v1)
        sha = lambda t: hashlib.sha1(t.encode()).hexdigest()
        rel = 'wp-content/mu-plugins/wppocket-shield.php'
        e.scan(managed={rel: sha(v1)})
        v2 = "<?php // shield v2 (ung dung cap nhat)\n"
        e.w(rel, v2)
        res = e.scan(T0 + 5, managed={rel: sha(v2)})
        check('file ung dung dong bo, sha1 khop ban goc moi: cap nhat khong bi bao "doi"', res['findings'] == [], e.kinds(res))
        e.w(rel, "<?php // sua tay, khac ban goc\n")
        res = e.scan(T0 + 6, managed={rel: sha(v2)})
        check('sha1 KHONG khop ban goc (bi sua tay): bao diem-bam-tru-doi', bool(e.find(res, 'diem-bam-tru-doi', rel)), e.kinds(res))
        e.w(rel, v2 + "@eval(base64_decode($_POST['z']));\n")
        res = e.scan(T0 + 7, managed={rel: sha(v2)})
        check('file managed bi chen ma doc: khop-sha1 that bai -> van bi bat (diem-bam-tru-doi + noi dung)', bool(e.find(res, 'diem-bam-tru-doi', rel)) and bool(e.find(res, 'nghi-web-shell', rel)), e.kinds(res))
    finally:
        e.clean()

    # ===== 5) File loi bi xoa =====
    e = Env()
    try:
        e.scan()
        os.remove(os.path.join(e.root, 'wp-includes/core-9.php'))
        os.remove(os.path.join(e.root, 'wp-admin/adm-9.php'))
        res = e.scan(T0 + 10)
        f = e.find(res, 'core-thieu-file')
        check('file loi bi xoa -> core-thieu-file (gom so luong)', len(f) == 1 and f[0]['detail'].startswith('2 file'), e.kinds(res))
    finally:
        e.clean()

    # ===== 6) Diem bam tru bi xoa + ignore + accept =====
    e = Env()
    try:
        e.w('wp-content/mu-plugins/mine.php', CLEAN_PHP)
        e.scan()
        os.remove(os.path.join(e.root, 'wp-content/mu-plugins/mine.php'))
        res = e.scan(T0 + 10)
        check('mu-plugin bi xoa so voi moc -> diem-bam-tru-mat (info)', any(f['sev'] == 'info' for f in e.find(res, 'diem-bam-tru-mat', 'wp-content/mu-plugins/mine.php')), e.kinds(res))
        e.w('wp-content/mu-plugins/mine.php', CLEAN_PHP + "// them 1 dong\n")
        e.w('about.php', CLEAN_PHP)
        res = e.scan(T0 + 20)
        h = e.find(res, 'diem-bam-tru-moi', 'about.php')
        check('truoc khi ignore: about.php bi bao', bool(h), e.kinds(res))
        out, err, rc = e.php('ignore', e.run, 'about.php', h[0]['sha1'])
        check('ignore: ghi duoc', out.strip() == 'true', (out, err))
        res = e.scan(T0 + 30)
        check('ignore: ca "diem-bam-tru-moi" lan "php-la-o-goc-site" cua dung file+sha1 bien mat', not [f for f in res['findings'] if f['file'] == 'about.php' and f['sha1'] == h[0]['sha1']], e.kinds(res))
        # file doi noi dung sau khi ignore -> bao lai (sha1 khac)
        e.w('about.php', CLEAN_PHP + "// da doi\n")
        res = e.scan(T0 + 40)
        check('ignore chi theo sha1: file doi noi dung -> bao lai', bool(e.find(res, 'diem-bam-tru-moi', 'about.php')) , e.kinds(res))
        out, err, rc = e.php('accept', e.run)
        check('accept: xoa moc', out.strip() == 'true' and not os.path.exists(os.path.join(e.run, 'security-baseline.json')), (out, err))
        res = e.scan(T0 + 50)
        check('accept: lan quet sau lap moc moi, het bao diem-bam-tru', res['baseline_created'] is True and not e.find(res, 'diem-bam-tru-moi') and not e.find(res, 'diem-bam-tru-doi'), e.kinds(res))
    finally:
        e.clean()

    # ===== 7) Cach ly / khoi phuc =====
    e = Env()
    try:
        e.scan()
        shell = e.w('wp-content/plugins/good/shell.php', SHELL_EVAL)
        e.w('wp-content/uploads/2026/01/cache.php', "<?php echo 1;\n")
        res = e.scan(T0 + 10)
        keep = open(os.path.join(e.root, 'wp-config.php')).read()
        # 7a) tu choi duong dan nguy hiem
        for bad in ['../wp-config.php', 'wp-config.php', '/etc/passwd', 'wp-content/../wp-config.php', '', 'wp-content/plugins/good/good.php']:
            out, err, rc = e.php('quar', e.root, e.run, bad, T0 + 20)
            try:
                d = json.loads(out)
            except ValueError:
                d = {'ok': None, '_raw': out + err}
            check('cach ly tu choi: %r' % bad[:50], d.get('ok') is False, d)
        check('cach ly tu choi: wp-config.php van nguyen ven', open(os.path.join(e.root, 'wp-config.php')).read() == keep)
        r = subprocess.run(['php'] + PHP_FLAGS + ['-r', 'define("WPP_SCAN_AS_LIB",1); require $argv[1]; echo json_encode(wpp_scan_quarantine($argv[2], $argv[3], "wp-content/plugins/good/shell.php\\0x", 1));', SCAN, e.root, e.run], capture_output=True, text=True)
        check('cach ly tu choi: ten co byte NUL', json.loads(r.stdout)['ok'] is False and os.path.exists(shell), r.stdout + r.stderr)
        # 7b) link tuong trung
        victim = os.path.join(e.tmp, 'outside.php')
        open(victim, 'w').write("<?php // ngoai\n")
        os.symlink(victim, os.path.join(e.root, 'wp-content/plugins/good/link.php'))
        res2 = e.scan(T0 + 15)
        out, err, rc = e.php('quar', e.root, e.run, 'wp-content/plugins/good/link.php', T0 + 20)
        check('cach ly tu choi: symlink (khong nam trong ket qua/khong theo lien ket)', json.loads(out)['ok'] is False and os.path.exists(victim), out)
        # 7c) cach ly dung file
        out, err, rc = e.php('quar', e.root, e.run, 'wp-content/plugins/good/shell.php', T0 + 20)
        d = json.loads(out)
        check('cach ly: file trong ket qua quet duoc cach ly', d['ok'] is True and d['id'] != '' and not os.path.exists(shell), d)
        qdir = os.path.join(e.run, 'quarantine')
        qfiles = [f for f in os.listdir(qdir) if f.endswith('.quar')]
        check('cach ly: file .quar trong lamp-run/quarantine, quyen 0600, ghi index.json', len(qfiles) == 1 and oct(os.stat(os.path.join(qdir, qfiles[0])).st_mode & 0o777) == '0o600' and os.path.isfile(os.path.join(qdir, 'index.json')), (qfiles, os.listdir(qdir)))
        out, err, rc = e.php('quar', e.root, e.run, 'wp-content/uploads/2026/01/cache.php', T0 + 21)
        check('cach ly 2 file khac nhau -> khong de len nhau', json.loads(out)['ok'] is True and len([f for f in os.listdir(qdir) if f.endswith('.quar')]) == 2, out)
        # 7d) khoi phuc
        for bad_id in ['../index', '', 'x', '20240101-000000-zzzzzzzz']:
            out, err, rc = e.php('restore', e.root, e.run, bad_id)
            check('khoi phuc tu choi id sai: %r' % bad_id, json.loads(out)['ok'] is False, out)
        out, err, rc = e.php('restore', e.root, e.run, d['id'])
        check('khoi phuc: file ve dung cho cu', json.loads(out)['ok'] is True and open(shell).read() == SHELL_EVAL, out)
        out, err, rc = e.php('restore', e.root, e.run, d['id'])
        check('khoi phuc lan 2: muc cach ly da het', json.loads(out)['ok'] is False, out)
        # khong ghi de
        out, err, rc = e.php('quar', e.root, e.run, 'wp-content/plugins/good/shell.php', T0 + 30)
        d2 = json.loads(out)
        open(shell, 'w').write("<?php // file moi cung ten\n")
        out, err, rc = e.php('restore', e.root, e.run, d2['id'])
        check('khoi phuc khong ghi de file dang co', json.loads(out)['ok'] is False and 'khong ghi de' in json.loads(out)['msg'] and open(shell).read() == "<?php // file moi cung ten\n", out)
        # index gia mao tro ra ngoai
        idxp = os.path.join(qdir, 'index.json')
        idx = json.load(open(idxp))
        idx[d2['id']]['orig'] = '../escape.php'
        json.dump(idx, open(idxp, 'w'))
        out, err, rc = e.php('restore', e.root, e.run, d2['id'])
        check('khoi phuc tu choi duong dan goc ".." (index bi sua)', json.loads(out)['ok'] is False and not os.path.exists(os.path.join(e.tmp, 'escape.php')), out)
    finally:
        e.clean()

    # ===== 8) Gioi han: truncated =====
    e = Env()
    try:
        for i in range(30):
            e.w('wp-content/plugins/many/f%d.php' % i, CLEAN_PHP)
        src = open(SCAN).read().replace('const WPP_SCAN_MAX_FILES = 25000;', 'const WPP_SCAN_MAX_FILES = 40;')
        alt = os.path.join(e.tmp, 'scan-small.php')
        open(alt, 'w').write(src)
        out = subprocess.run(['php'] + PHP_FLAGS + [e.driver, alt, 'run', e.root, e.run, str(T0)], capture_output=True, text=True).stdout
        res = json.loads(out)
        check('qua nhieu file: truncated=true, dung dung han', res['truncated'] is True and res['files'] <= 41, (res.get('truncated'), res.get('files')))
        check('truncated: KHONG lap moc (tranh bao nham ve sau)', res['baseline_created'] is False and not os.path.exists(os.path.join(e.run, 'security-baseline.json')), res.get('baseline_created'))
        check('truncated: khong bao "core-thieu-file" (chua duyet het)', not e.find(res, 'core-thieu-file'), e.kinds(res))
    finally:
        e.clean()

    # ===== 9) Khong phai WordPress / chua cai =====
    e = Env()
    try:
        shutil.rmtree(e.root)
        os.makedirs(e.root)
        res = e.scan()
        check('docroot rong: khong loi, khong lap moc', res.get('profile') == 'generic' and res['baseline_created'] is False and res['findings'] == [], res)
        # cai WordPress sau do: khong bi bao "moi" hang loat vi moc rong
        e.build_wp()
        res = e.scan(T0 + 10)
        check('cai WordPress sau lan quet rong: lan quet tiep chi lap moc (khong "diem-bam-tru-moi" hang loat)', res['baseline_created'] is True and not e.find(res, 'diem-bam-tru-moi'), e.kinds(res))
        # site PHP chung: file goc doi thoai mai nhung php trong uploads van bi bat
        e2 = Env()
        shutil.rmtree(e2.root)
        os.makedirs(os.path.join(e2.root, 'uploads'))
        open(os.path.join(e2.root, 'index.php'), 'w').write(CLEAN_PHP)
        res = e2.scan()
        open(os.path.join(e2.root, 'index.php'), 'w').write(CLEAN_PHP + '// doi\n')
        open(os.path.join(e2.root, 'extra.php'), 'w').write(SHELL_EVAL)
        res = e2.scan(T0 + 5)
        check('site PHP chung: file goc doi khong bao "diem-bam-tru", nhung web-shell van bi bat theo noi dung', not e2.find(res, 'diem-bam-tru-doi') and bool(e2.find(res, 'nghi-web-shell', 'extra.php')), e2.kinds(res))
        e2.clean()
    finally:
        e.clean()

    # ===== 10) Thu muc bo qua / lien ket / plugin bao mat =====
    e = Env()
    try:
        e.scan()
        e.w('wp-content/cache/x/evil.php', SHELL_EVAL)
        e.w('wp-content/plugins/good/node_modules/pkg/evil.php', SHELL_EVAL)
        e.w('_admin/tool.php', SHELL_EVAL)
        e.w('wp-content/plugins/wordfence/lib/sig.php', SHELL_EVAL)       # plugin bao mat chua chu ky ma doc: bo qua noi dung
        os.symlink(e.root, os.path.join(e.root, 'wp-content/plugins/loop'))
        res = e.scan(T0 + 10)
        bad = [f for f in res['findings'] if any(s in f['file'] for s in ('wp-content/cache', 'node_modules', '_admin/', 'wordfence/lib/sig.php'))]
        check('bo qua cache/node_modules/_admin/plugin bao mat/lien ket vong (khong loi, khong bao)', not bad and res.get('_raw') is None and 'files' in res, bad or res)
    finally:
        e.clean()

    # ===== 11) CLI =====
    e = Env()
    try:
        r = subprocess.run(['php'] + PHP_FLAGS + [SCAN, e.root, e.run], capture_output=True, text=True)
        check('CLI scan: thoat 0, in tom tat "quet N file"', r.returncode == 0 and 'quet ' in r.stdout and 'nghiem trong' in r.stdout, (r.returncode, r.stdout, r.stderr[:200]))
        r = subprocess.run(['php'] + PHP_FLAGS + [SCAN, e.root, e.run, 'accept'], capture_output=True, text=True)
        check('CLI accept: thoat 0', r.returncode == 0 and 'moc' in r.stdout, (r.stdout, r.stderr))
        r = subprocess.run(['php'] + PHP_FLAGS + [SCAN], capture_output=True, text=True)
        check('CLI thieu doi so -> thoat 2 + huong dan', r.returncode == 2 and 'dung:' in r.stderr, (r.returncode, r.stderr))
        r = subprocess.run(['php'] + PHP_FLAGS + ['-r', 'require $argv[1]; echo "ok";', SCAN], capture_output=True, text=True)
        check('nap nhu thu vien KHONG chay main', r.stdout == 'ok' and r.returncode == 0, (r.stdout, r.stderr[:100]))
        # scan-fetch khong co mang: khong loi, van quet
        os.remove(os.path.join(e.run, 'wp-core-checksums.json'))
        r = subprocess.run(['php'] + PHP_FLAGS + ['-d', 'default_socket_timeout=2', SCAN, e.root, e.run, 'scan-fetch'], capture_output=True, text=True, timeout=60)
        check('CLI scan-fetch: mang loi van quet duoc, thoat 0', r.returncode == 0 and 'quet ' in r.stdout, (r.returncode, r.stdout, r.stderr[:200]))
        # khoa: lan quet thu 2 dong thoi bi bo qua
        out, err, rc = e.php('info', e.root)
        check('wp_info: doc dung phien ban', json.loads(out)['version'] == WP_VERSION, out)
    finally:
        e.clean()

    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
