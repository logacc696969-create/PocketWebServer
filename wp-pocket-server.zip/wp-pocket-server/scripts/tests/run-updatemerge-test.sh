#!/bin/sh
# Chay kiem thu JVM cho UpdateMergeLogic.kt (can kotlinc + java). Khong can Android SDK. HANDOFF.md muc 1bo.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/UpdateMergeLogic.kt" "$HERE/UpdateMergeLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" UpdateMergeLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
