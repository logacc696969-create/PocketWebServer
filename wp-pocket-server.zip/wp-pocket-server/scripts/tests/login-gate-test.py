#!/usr/bin/env python3
"""Kiem thu "URL dang nhap bi mat" (lamp-run/login-gate.conf, HANDOFF.md muc 1br-H) bang nginx THAT + php-fpm THAT (+ WordPress THAT 7.1.4, tuy chon).

Dung DUNG nginx.conf.template va php-fpm.conf.template cua du an (chi doi duong dan, user=root, listen.mode). Tep login-gate.conf KHONG viet tay trong test: no do CHINH
cac ham trong admin-security.php (wp_pocket_sec_gate_write/render/read) tao ra - trich nguyen van tu nguon roi chay bang php CLI - de test cung bat duoc loi o phia ghi tep.
Tao tep xong, test gui HUP cho nginx giong supervisor khi thay co ban-reload.

PHAN A (trang gia lap: wp-login.php, wp-admin/*.php, admin-ajax.php...): mac dinh KHONG chan; bat -> chua go cua thi /wp-login.php va PHP trong /wp-admin/ 404 (ca khi viet
  kieu %77p-admin, //wp-admin//, POST), admin-ajax.php/admin-post.php/tep tinh/trang chu VAN mo; cookie sai/thieu/gan dung 404; "go cua" = 302 ve /wp-login.php (Location
  tuong doi, khong gay vong lap http/https) + Set-Cookie HttpOnly SameSite (+Secure khi qua Cloudflare); co cookie thi vao duoc; 404 tra TRUOC limit_req (khong 503); doi URL -> cookie/URL
  cu mat hieu luc; co login-gate-off; tat han; ham ghi tep tu choi gia tri co ky tu nginx.
PHAN B (WordPress THAT, can WP_REAL_SRC + WP_SQLITE_SRC): luong dang nhap day du sau khi go cua; admin-ajax cho khach van chay; phien dang nhap WP KHONG thay cho cookie go cua.
Doi chung am: NGINX_TPL=<template khong co khoi login-gate> -> PHAI do. Thieu cong cu -> bo qua (exit 0).
"""
import http.client, importlib.util, os, re, shutil, signal, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
TPLDIR = os.path.join(ROOT, 'scripts', 'runtimes', 'templates')
NGX_TPL = os.environ.get('NGINX_TPL') or os.path.join(TPLDIR, 'nginx.conf.template')
ADMIN_SEC = os.path.join(TPLDIR, 'admin-security.php')
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:260]) if d else ''))


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wr(path, txt):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w').write(txt)


def gate_php_block():
    """Trich nguyen van 3 ham gate tu admin-security.php (tu 'function wp_pocket_sec_gate_render' den truoc khoi 'ban-list/allowlist')."""
    src = open(ADMIN_SEC, encoding='utf-8').read()
    a = src.index('function wp_pocket_sec_gate_render')
    b = src.index('/** "ban-list/allowlist"')
    return src[a:b]


def gate_cli(php, run, op, *args):
    """Chay ham gate THAT bang php CLI; tra stdout."""
    code = '<?php\n' + gate_php_block() + '\n$a = $argv; $op = $a[1]; $run = $a[2];\n' \
        'if ($op === "write") { echo json_encode(wp_pocket_sec_gate_write($run, $a[3], $a[4])); }\n' \
        'elseif ($op === "read") { echo json_encode(wp_pocket_sec_gate_read($run)); }\n' \
        'elseif ($op === "render") { echo json_encode(wp_pocket_sec_gate_render($a[3], $a[4])); }\n'
    f = tempfile.NamedTemporaryFile('w', suffix='.php', delete=False)
    f.write(code)
    f.close()
    try:
        return subprocess.run([php, '-d', 'display_errors=1', f.name, op, run] + list(args), capture_output=True, text=True, timeout=30).stdout.strip()
    finally:
        os.unlink(f.name)


def launch(nginx, fpm, tpl_ngx, tpl_fpm, tmp, run, doc, port, files, fast_login=True):
    """Khoi dong php-fpm + nginx tu template that. Tra (danh sach tien trinh, nginx_proc).
    fast_login: nang limit_req dang nhap (5 lan/phut) len rat cao CHI trong test, de cac kiem tra "co cookie thi vao duoc" khong bi 503 cua bo gioi han (khong lien quan cong).
    Kiem tra tuong tac voi limit_req THAT dung fast_login=False o A0."""
    sport = free_port()
    sock, hsock = os.path.join(run, 'php-fpm.sock'), os.path.join(run, 'php-hard.sock')
    conf = tpl_ngx
    if fast_login and 'rate=5r/m' in conf:
        conf = conf.replace('rate=5r/m', 'rate=100000r/m')
    for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)), ('__FPM_SOCK__', sock),
                 ('__CF_REALIP_DIRECTIVES__', ''), ('__STAGING_DOCROOT__', os.path.join(tmp, 'stg'))):
        conf = conf.replace(k, v)
    os.makedirs(os.path.join(tmp, 'stg'), exist_ok=True)
    wr(os.path.join(tmp, 'nginx.conf'), 'user root;\n' + conf if os.geteuid() == 0 else conf)
    open(os.path.join(run, 'ban-list.conf'), 'a').close()
    for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
        os.makedirs(m, exist_ok=True)
    fc = tpl_fpm
    for k, v in (('__RUNDIR__', run), ('__FPM_SOCK__', sock), ('__FILESDIR__', files), ('__EXT_DIR__', tmp), ('__STAGING_PORT__', str(sport)),
                 ('__MYSQL_SOCK__', os.path.join(run, 'mysql.sock')), ('__DB_NAME__', 'x'), ('__DB_USER__', 'x'), ('__DB_PASS__', 'x')):
        fc = fc.replace(k, v)
    fc = fc.replace('listen.mode = 0660', 'listen.mode = 0666')
    fc = re.sub(r'(?m)^\[(www|hard)\]$', lambda m: '[%s]\nuser = root\ngroup = root' % m.group(1), fc)
    fc = fc.replace('php_admin_flag[log_errors] = on', 'php_admin_flag[log_errors] = on\nphp_admin_flag[display_errors] = off')
    wr(os.path.join(tmp, 'fpm.conf'), fc)
    wr(os.path.join(tmp, 'php.ini'), 'cgi.fix_pathinfo=0\nmemory_limit=512M\n')
    procs = [subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)]
    ngx = subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    procs.append(ngx)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.2).close()
            break
        except OSError:
            time.sleep(0.1)
    for _ in range(100):
        if os.path.exists(sock) and os.path.exists(hsock):
            break
        time.sleep(0.1)
    return procs, ngx


def stop(procs):
    for p in procs:
        try:
            p.terminate()
            p.wait(timeout=5)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass


def req(port, method, path, body=None, headers=None, cookie=None):
    h = {'User-Agent': 'Mozilla/5.0 TestBrowser'}
    h.update(headers or {})
    if cookie:
        h['Cookie'] = cookie
    c = http.client.HTTPConnection('127.0.0.1', port, timeout=60)
    try:
        c.request(method, path, body=body, headers=h)
        r = c.getresponse()
        data = r.read().decode('utf-8', 'replace')
        return r.status, data, r.msg
    except Exception as ex:
        return 'ERR', repr(ex), None
    finally:
        c.close()


def settle(pred, timeout=8.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            if pred():
                return time.time() - t0
        except Exception:
            pass
        time.sleep(0.25)
    return None


def apply_reload(run, ngx):
    """Giong start-lamp.sh: co ban-reload -> xoa co + HUP nginx."""
    f = os.path.join(run, 'ban-reload')
    if os.path.exists(f):
        os.remove(f)
        ngx.send_signal(signal.SIGHUP)
        return True
    return False


STUB_LOGIN = '<?php echo "LOGIN-PAGE user_login";\n'
STUB_OK = '<?php echo "OK:" . $_SERVER["SCRIPT_NAME"];\n'


def part_a0(nginx, fpm, php, tpl_ngx, tpl_fpm):
    """limit_req dang nhap THAT (5 lan/phut, burst 3): request bi cong 404 khong bi tinh vao gioi han; request co cookie van bi tinh (gioi han con nguyen tac dung)."""
    print('== A0. Tuong tac voi limit_req dang nhap that (5r/m) ==')
    tmp = tempfile.mkdtemp(prefix='logingate0-')
    os.chmod(tmp, 0o755)
    procs = []
    try:
        doc, run, files = (os.path.join(tmp, d) for d in ('www', 'run', 'files'))
        for d in (doc, run, files):
            os.makedirs(d)
        port = free_port()
        wr(os.path.join(doc, 'wp-login.php'), STUB_LOGIN)
        wr(os.path.join(doc, 'index.php'), STUB_OK)
        slug, token = 'a1b2c3d4e5f60718293a4b5c', '0123456789abcdef0123456789abcdef'
        check('write truoc khi nginx khoi dong (code that)', gate_cli(php, run, 'write', slug, token) == 'true')
        os.remove(os.path.join(run, 'ban-reload'))
        procs, ngx = launch(nginx, fpm, tpl_ngx, tpl_fpm, tmp, run, doc, port, files, fast_login=False)
        codes = [req(port, 'GET', '/wp-login.php')[0] for _ in range(20)]
        check('nginx khoi dong voi tep cau hinh san: 20 request /wp-login.php khong cookie => TAT CA 404, khong 503 (404 tra TRUOC limit_req, khong cham PHP)', codes.count(404) == 20, sorted(set(map(str, codes))))
        codes = [req(port, 'GET', '/wp-login.php', cookie='wppgate=' + token)[0] for _ in range(10)]
        check('cung IP do, sau khi go cua: limit_req dang nhap van tac dung (co 200 dau, roi 503 khi vuot burst)', codes[0] == 200 and 503 in codes, codes)
    finally:
        stop(procs)
        shutil.rmtree(tmp, ignore_errors=True)


def part_a(nginx, fpm, php, tpl_ngx, tpl_fpm):
    print('== A. Trang gia lap + nginx that ==')
    tmp = tempfile.mkdtemp(prefix='logingate-')
    os.chmod(tmp, 0o755)
    procs = []
    try:
        doc, run, files = (os.path.join(tmp, d) for d in ('www', 'run', 'files'))
        for d in (doc, run, files):
            os.makedirs(d)
        port = free_port()
        wr(os.path.join(doc, 'index.php'), STUB_OK)
        wr(os.path.join(doc, 'wp-login.php'), STUB_LOGIN)
        for n in ('index.php', 'plugins.php', 'load-styles.php', 'admin-ajax.php', 'admin-post.php', 'admin-ajax.php.bak.php'):
            wr(os.path.join(doc, 'wp-admin', n), STUB_OK)
        wr(os.path.join(doc, 'wp-admin', 'css', 'x.css'), 'body{}\n')
        wr(os.path.join(doc, 'style.css'), 'body{}\n')
        procs, ngx = launch(nginx, fpm, tpl_ngx, tpl_fpm, tmp, run, doc, port, files)
        slug, token = 'a1b2c3d4e5f60718293a4b5c', '0123456789abcdef0123456789abcdef'

        def code(path, method='GET', cookie=None, headers=None, body=None):
            return req(port, method, path, body=body, headers=headers, cookie=cookie)[0]

        print('-- A1. Mac dinh (chua bat): khong doi hanh vi --')
        check('chua co login-gate.conf: /wp-login.php 200', code('/wp-login.php') == 200)
        check('... /wp-admin/plugins.php 200', code('/wp-admin/plugins.php') == 200)
        check('... /wp-admin/ (thu muc -> index.php) 200', code('/wp-admin/') == 200)
        check('... URL ngau nhien khong tao cookie (khong co location go cua)', 'wppgate' not in str(req(port, 'GET', '/' + slug)[2]))

        print('-- A2. Ham ghi tep (code that cua admin-security.php) --')
        check('render tu choi duong dan co ky tu la (chen cu phap nginx): ra null', gate_cli(php, run, 'render', 'a1b2c3d4e5f60718293a4b5"', token) == 'null')
        check('render tu choi duong dan sai do dai / chu hoa', gate_cli(php, run, 'render', 'A1B2C3D4E5F60718293A4B5C', token) == 'null' and gate_cli(php, run, 'render', 'abcd', token) == 'null')
        check('render tu choi token chua dau nhay/dau cham phay (dong kep chen cau hinh)', gate_cli(php, run, 'render', slug, '0123456789abcdef0123456789abc";}') == 'null')
        check('render tu choi gia tri co xuong dong ("\\n") o cuoi (khong dung $ long leo)', gate_cli(php, run, 'render', slug + '\n', token) == 'null')
        check('write voi gia tri sai: tra false va KHONG tao tep', gate_cli(php, run, 'write', 'zz', token) == 'false' and not os.path.exists(os.path.join(run, 'login-gate.conf')) and not os.path.exists(os.path.join(run, 'ban-reload')))
        check('write gia tri dung: tra true', gate_cli(php, run, 'write', slug, token) == 'true')
        gf = os.path.join(run, 'login-gate.conf')
        check('tep login-gate.conf co quyen 0600 (chi chu so huu doc - chua token)', os.path.exists(gf) and (os.stat(gf).st_mode & 0o777) == 0o600, oct(os.stat(gf).st_mode & 0o777) if os.path.exists(gf) else None)
        check('khong con tep .tmp sot lai (tmp + rename)', not os.path.exists(gf + '.tmp'))
        check('tao co ban-reload (de supervisor HUP nginx)', os.path.exists(os.path.join(run, 'ban-reload')))
        got = gate_cli(php, run, 'read')
        check('read: JSON [slug, token] khop gia tri da ghi', got == '["%s","%s"]' % (slug, token), got)
        txt = open(gf).read()
        check('tep co dung 1 khoi "location = /<slug>" va khong chua gia tri nao khac ngoai slug/token', txt.count('location = /') == 1 and ('location = /' + slug + ' {') in txt and txt.count(token) == 2, txt[:200])

        print('-- A3. Bat: chua go cua --')
        apply_reload(run, ngx)
        ok = settle(lambda: code('/wp-login.php') == 404, 8)
        check('sau HUP: /wp-login.php khong cookie => 404', ok is not None, code('/wp-login.php'))
        for path, want in (('/wp-login.php?action=lostpassword', 404), ('/wp-login.php?action=logout', 404), ('/wp-login.php?redirect_to=/wp-admin/', 404),
                           ('/wp-admin/', 404), ('/wp-admin/index.php', 404), ('/wp-admin/plugins.php', 404), ('/wp-admin/load-styles.php?c=1', 404),
                           ('/%77p-admin/plugins.php', 404), ('/wp-admin/%70lugins.php', 404), ('//wp-admin//plugins.php', 404), ('/wp-admin/../wp-admin/plugins.php', 404),
                           ('/wp-%6cogin.php', 404), ('/wp-admin/admin-ajax.php', 200), ('/wp-admin/admin-post.php', 200), ('/wp-admin/admin-ajax.php?action=x', 200),
                           ('/wp-admin/css/x.css', 200), ('/style.css', 200), ('/', 200), ('/index.php', 200)):
            got = code(path)
            check('chua go cua: GET %s => %s' % (path, want), got == want, got)
        check('chua go cua: POST /wp-login.php (do mat khau) => 404, khong cham PHP', code('/wp-login.php', 'POST', body='log=admin&pwd=x', headers={'Content-Type': 'application/x-www-form-urlencoded'}) == 404)
        check('chua go cua: POST /wp-admin/plugins.php => 404', code('/wp-admin/plugins.php', 'POST', body='a=b', headers={'Content-Type': 'application/x-www-form-urlencoded'}) == 404)
        check('chua go cua: HEAD /wp-login.php => 404', code('/wp-login.php', 'HEAD') == 404)
        for label, ck in (('cookie sai gia tri', 'wppgate=' + '0' * 32), ('cookie dung nua dau', 'wppgate=' + token[:16]), ('cookie dung + ky tu thua', 'wppgate=' + token + 'a'),
                          ('cookie rong', 'wppgate='), ('ten cookie khac', 'other=' + token), ('cookie viet hoa', 'wppgate=' + token.upper()), ('cookie WP dang nhap gia', 'wordpress_logged_in_x=admin%7C1%7Cx')):
            check('%s => /wp-login.php 404' % label, code('/wp-login.php', cookie=ck) == 404)

        print('-- A4. Go cua --')
        sc, body, hd = req(port, 'GET', '/' + slug)
        sck = hd.get_all('Set-Cookie') or []
        check('GET /<slug> => 302', sc == 302, sc)
        check('Location TUONG DOI "/wp-login.php" (khong "http://host/..." - tranh ha cap https->http sau Cloudflare)', hd.get('Location') == '/wp-login.php', hd.get('Location'))
        check('Set-Cookie wppgate=<token>; Path=/; HttpOnly; SameSite=Lax; Max-Age', len(sck) == 1 and sck[0].startswith('wppgate=' + token + '; Path=/;') and 'HttpOnly' in sck[0] and 'SameSite=Lax' in sck[0] and 'Max-Age=2592000' in sck[0], sck)
        check('Truy cap http (LAN): KHONG co Secure (khong thi cookie khong gui duoc)', len(sck) == 1 and 'Secure' not in sck[0], sck)
        sc, body, hd2 = req(port, 'GET', '/' + slug, headers={'X-Forwarded-Proto': 'https'})
        sck2 = hd2.get_all('Set-Cookie') or []
        check('Qua Cloudflare (X-Forwarded-Proto: https): cookie co Secure', len(sck2) == 1 and sck2[0].rstrip().endswith('Secure'), sck2)
        check('Phan hoi go cua: Cache-Control no-store (Cloudflare/trinh duyet khong luu)', 'no-store' in (hd.get('Cache-Control') or ''), hd.get('Cache-Control'))
        check('Phan hoi go cua: giu header bao mat (nosniff, SAMEORIGIN) du location co add_header rieng', hd.get('X-Content-Type-Options') == 'nosniff' and hd.get('X-Frame-Options') == 'SAMEORIGIN', (hd.get('X-Content-Type-Options'), hd.get('X-Frame-Options')))
        check('go cua bang HEAD/POST cung chi tra 302 (khong loi)', code('/' + slug, 'HEAD') == 302)
        ck = 'wppgate=' + token
        sc, body, _ = req(port, 'GET', '/wp-login.php', cookie=ck)
        check('co cookie: /wp-login.php 200 + trang dang nhap', sc == 200 and 'LOGIN-PAGE' in body, (sc, body[:60]))
        for path in ('/wp-admin/', '/wp-admin/plugins.php', '/wp-admin/load-styles.php?c=1', '/%77p-admin/plugins.php', '//wp-admin//plugins.php', '/wp-login.php?action=lostpassword'):
            check('co cookie: GET %s 200' % path, code(path, cookie=ck) == 200)
        check('co cookie (nhieu cookie khac di kem): van duoc', code('/wp-login.php', cookie='a=1; wppgate=%s; wordpress_logged_in_z=1' % token) == 200)
        check('co cookie: POST /wp-login.php toi PHP (200)', code('/wp-login.php', 'POST', cookie=ck, body='log=a&pwd=b', headers={'Content-Type': 'application/x-www-form-urlencoded'}) == 200)

        print('-- A5. Co khan cap login-gate-off --')
        flag = os.path.join(run, 'login-gate-off')
        open(flag, 'w').write('')
        dt = settle(lambda: code('/wp-login.php') == 200, 6)
        check('tao co login-gate-off: /wp-login.php mo lai khong can cookie (tuc thi)', dt is not None, dt)
        check('... /wp-admin/plugins.php cung mo', code('/wp-admin/plugins.php') == 200)
        os.remove(flag)
        dt = settle(lambda: code('/wp-login.php') == 404, 6)
        check('xoa co: cong chan lai trong <= ~2s (open_file_cache_valid 2s), cau hinh khong bi mat', dt is not None, dt)

        print('-- A6. Doi URL (tao moi) --')
        slug2, token2 = '00112233445566778899aabb', 'fedcba9876543210fedcba9876543210'
        check('write lan 2 (doi URL): true', gate_cli(php, run, 'write', slug2, token2) == 'true')
        apply_reload(run, ngx)
        dt = settle(lambda: code('/wp-login.php', cookie=ck) == 404, 8)
        check('sau HUP: cookie CU het hieu luc (404)', dt is not None, code('/wp-login.php', cookie=ck))
        sc, _, hd = req(port, 'GET', '/' + slug)
        check('URL cu khong con dat cookie', 'wppgate' not in str(hd.get_all('Set-Cookie')), hd.get_all('Set-Cookie'))
        check('URL cu chay toi trang chu thuong (khong phai cua)', sc == 200)
        sc, _, hd = req(port, 'GET', '/' + slug2)
        check('URL moi: 302 + cookie moi', sc == 302 and 'wppgate=' + token2 in str(hd.get_all('Set-Cookie')), (sc, hd.get_all('Set-Cookie')))
        check('cookie moi vao duoc /wp-login.php', code('/wp-login.php', cookie='wppgate=' + token2) == 200)

        print('-- A7. Tat han (xoa tep + HUP) --')
        os.remove(gf)
        open(os.path.join(run, 'ban-reload'), 'w').write('')
        apply_reload(run, ngx)
        dt = settle(lambda: code('/wp-login.php') == 200, 8)
        check('xoa login-gate.conf + HUP: /wp-login.php mo lai nhu cu', dt is not None, code('/wp-login.php'))
        check('... /wp-admin/plugins.php mo lai', code('/wp-admin/plugins.php') == 200)
        sc, _, hd = req(port, 'GET', '/' + slug2)
        check('... URL bi mat cu khong con dat cookie', 'wppgate' not in str(hd.get_all('Set-Cookie')))
        check('read sau khi xoa tep: null', gate_cli(php, run, 'read') == 'null')

        logtxt = ''
        for n in ('nginx-error.log', 'error.log'):
            p = os.path.join(run, n)
            if os.path.exists(p):
                logtxt += open(p, errors='replace').read()
        check('nginx khong ghi [emerg]/[alert]/"unknown variable" trong ca qua trinh HUP bat/tat/doi', not re.search(r'\[(?:emerg|alert|crit)\]|unknown "', logtxt), logtxt[-300:])
    finally:
        stop(procs)
        shutil.rmtree(tmp, ignore_errors=True)


def part_b(nginx, fpm, php, tpl_ngx, tpl_fpm, wp_src, sq_src):
    spec = importlib.util.spec_from_file_location('wpreal', os.path.join(HERE, 'wp-real-test.py'))
    wr_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(wr_mod)
    print('== B. WordPress THAT 7.1.4 (SQLite) + nginx that ==')
    site = wr_mod.Site(wp_src, sq_src)
    procs = []
    try:
        ok, msg = site.install()
        check('cai WordPress that (SQLite)', ok, msg)
        if not ok:
            return
        run = site.run
        os.makedirs(os.path.join(run, 'php-sessions'), exist_ok=True)
        site.cli("global $wp_rewrite; $wp_rewrite->set_permalink_structure('/%postname%/'); $wp_rewrite->flush_rules(false); echo 'OK';")
        procs, ngx = launch(nginx, fpm, tpl_ngx, tpl_fpm, site.tmp, run, site.site, site.port, site.home)
        port = site.port
        slug, token = 'c0ffee00c0ffee00c0ffee00', 'abcdefabcdefabcdefabcdefabcdef12'
        sc, body, _ = req(port, 'GET', '/wp-login.php')
        check('WP that, chua bat cong: /wp-login.php 200 co form dang nhap', sc == 200 and 'user_login' in body, sc)
        check('write cong (code that)', gate_cli(php, run, 'write', slug, token) == 'true')
        apply_reload(run, ngx)
        check('WP that: sau HUP /wp-login.php khong cookie => 404', settle(lambda: req(port, 'GET', '/wp-login.php')[0] == 404, 8) is not None)
        sc, body, _ = req(port, 'GET', '/wp-admin/')
        check('WP that: /wp-admin/ khong cookie => 404 (khong lo chuyen huong ve wp-login)', sc == 404, sc)
        sc, body, _ = req(port, 'GET', '/')
        check('WP that: trang chu cho khach VAN 200', sc == 200 and ('Test Site' in body or 'wp-content' in body), sc)
        sc, body, _ = req(port, 'GET', '/wp-json/')
        check('WP that: REST /wp-json/ VAN 200', sc == 200 and '"namespaces"' in body, sc)
        sc, body, _ = req(port, 'GET', '/wp-admin/admin-ajax.php?action=nopriv_khong_co')
        check('WP that: admin-ajax.php cho khach VAN toi WordPress (khong 404 cua gate)', sc in (200, 400) and body.strip() in ('0', '-1', ''), (sc, body[:40]))
        sc, body, _ = req(port, 'GET', '/wp-cron.php?doing_wp_cron')
        check('WP that: wp-cron.php VAN 200', sc == 200, sc)
        sc, body, _ = req(port, 'GET', '/feed/')
        check('WP that: /feed/ VAN 200', sc == 200 and '<rss' in body, sc)

        sc, _, hd = req(port, 'GET', '/' + slug)
        check('WP that: go cua => 302 /wp-login.php + cookie', sc == 302 and hd.get('Location') == '/wp-login.php' and ('wppgate=' + token) in str(hd.get_all('Set-Cookie')), (sc, hd.get('Location')))
        ck = 'wppgate=' + token
        sc, body, hd = req(port, 'GET', '/wp-login.php', cookie=ck)
        check('WP that: co cookie go cua => form dang nhap that (user_login) 200', sc == 200 and 'user_login' in body, sc)
        wtc = 'wordpress_test_cookie=WP%20Cookie%20check'
        data = 'log=owner&pwd=Pa55word-Test%21&wp-submit=Log+In&redirect_to=' + 'http%3A%2F%2F127.0.0.1%3A' + str(port) + '%2Fwp-admin%2F&testcookie=1'
        sc, body, hd = req(port, 'POST', '/wp-login.php', body=data, headers={'Content-Type': 'application/x-www-form-urlencoded'}, cookie=ck + '; ' + wtc)
        sck = hd.get_all('Set-Cookie') or []
        logged = [c.split(';', 1)[0] for c in sck if c.startswith('wordpress_logged_in')]
        check('WP that: DANG NHAP THANH CONG sau khi go cua (302 + cookie wordpress_logged_in)', sc == 302 and logged, (sc, [c.split('=')[0] for c in sck]))
        wpck = '; '.join(c.split(';', 1)[0] for c in sck)
        sc, body, hd = req(port, 'GET', '/wp-admin/', cookie=wpck + '; ' + ck)
        if sc == 302 and (hd.get('Location') or '').startswith('http://127.0.0.1:%d/' % port):
            sc, body, hd = req(port, 'GET', hd['Location'][len('http://127.0.0.1:%d' % port):], cookie=wpck + '; ' + ck)
        check('WP that: da dang nhap + co cookie go cua: /wp-admin/ 200 Dashboard', sc == 200 and 'Dashboard' in body, (sc, body[:60]))
        sc, body, hd = req(port, 'GET', '/wp-admin/plugins.php', cookie=wpck + '; ' + ck)
        check('WP that: /wp-admin/plugins.php 200', sc == 200 and 'Plugins' in body, sc)
        sc, body, hd = req(port, 'GET', '/wp-admin/', cookie=wpck)
        check('WP that: phien WordPress hop le NHUNG thieu cookie go cua => 404 (phien bi danh cap rieng le khong du de vao wp-admin)', sc == 404, sc)
        sc, body, hd = req(port, 'GET', '/wp-login.php?action=lostpassword', cookie=ck)
        check('WP that: co cookie: trang "quen mat khau" 200', sc == 200 and 'user_login' in body, sc)
        sc, body, hd = req(port, 'GET', '/wp-login.php?action=lostpassword')
        check('WP that: khong cookie: trang "quen mat khau" 404 (da ghi trong tai lieu: mo URL bi mat truoc)', sc == 404, sc)

        # khong cookie, tan cong do mat khau nhieu lan: khong ton PHP, khong tinh limit
        codes = [req(port, 'POST', '/wp-login.php', body='log=owner&pwd=guess%d' % i, headers={'Content-Type': 'application/x-www-form-urlencoded'})[0] for i in range(15)]
        check('WP that: 15 lan do mat khau khong cookie: toan 404 (khong chay PHP/WordPress, khong 503 limit_req)', codes.count(404) == 15, set(codes))
        logs = ''
        for n in ('php-error.log', 'php-fpm.log'):
            p = os.path.join(run, n)
            if os.path.exists(p):
                logs += open(p, errors='replace').read()
        check('log PHP khong co Fatal error', not re.search(r'PHP Fatal error', logs), logs[-200:])
        # tat han
        os.remove(os.path.join(run, 'login-gate.conf'))
        open(os.path.join(run, 'ban-reload'), 'w').write('')
        apply_reload(run, ngx)
        check('WP that: tat han -> /wp-login.php 200 lai', settle(lambda: req(port, 'GET', '/wp-login.php')[0] == 200, 8) is not None)
    finally:
        stop(procs)
        try:
            site.stop()
        except Exception:
            pass
        shutil.rmtree(site.tmp, ignore_errors=True)


def main():
    nginx = which('nginx')
    fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    php = which('php')
    if not (nginx and fpm and php):
        print('(bo qua: thieu nginx / php-fpm / php CLI)')
        return 0
    tpl_ngx = open(NGX_TPL, encoding='utf-8').read()
    tpl_fpm = open(os.path.join(TPLDIR, 'php-fpm.conf.template'), encoding='utf-8').read()
    part_a0(nginx, fpm, php, tpl_ngx, tpl_fpm)
    part_a(nginx, fpm, php, tpl_ngx, tpl_fpm)
    wp_src, sq_src = os.environ.get('WP_REAL_SRC'), os.environ.get('WP_SQLITE_SRC')
    if wp_src and sq_src and os.path.isdir(wp_src) and os.path.isdir(sq_src):
        part_b(nginx, fpm, php, tpl_ngx, tpl_fpm, wp_src, sq_src)
    else:
        print('(PHAN B bo qua: can WP_REAL_SRC + WP_SQLITE_SRC)')
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
