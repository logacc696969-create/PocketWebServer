#!/usr/bin/env python3
"""Doi chieu tai nguyen Android (HANDOFF.md muc 1az) - khong can Android SDK.

  1. strings.xml (vi) va values-en/strings.xml co CUNG tap ten chuoi;
  2. dinh dang (%1$s, %2$d...) o hai ngon ngu KHOP nhau cho tung chuoi;
  3. moi @string/x trong layout va moi R.string.x trong Kotlin deu ton tai;
  4. khong co chuoi nao co >=2 placeholder khong danh so (AAPT2 bao loi);
  4b. dau nhay don (') trong strings.xml phai duoc escape (\\') hoac nam trong ngoac kep -
     neu khong aapt2 bao loi va APK khong build duoc;
  5. moi android:id trong layout la duy nhat; XML hop le.
"""
import os, re, sys, xml.etree.ElementTree as ET

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "app", "src", "main")
passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: passed += 1; print("PASS:", name)
    else: failed += 1; print("FAIL:", name, detail)

def strings(path):
    root = ET.parse(path).getroot()
    out = {}
    for el in root.findall("string"):
        out[el.get("name")] = "".join(el.itertext())
    return out

def raw_strings(path):
    """Chuoi tho (chua qua XML parser) de kiem dau nhay don chua escape."""
    text = open(path, encoding="utf-8").read()
    return re.findall(r'<string name="([^"]+)"[^>]*>(.*?)</string>', text, re.S)

vi_path = os.path.join(ROOT, "res", "values", "strings.xml")
en_path = os.path.join(ROOT, "res", "values-en", "strings.xml")
vi, en = strings(vi_path), strings(en_path)
check("strings.xml (vi) va (en) hop le", len(vi) > 0 and len(en) > 0)
only_vi = sorted(set(vi) - set(en)); only_en = sorted(set(en) - set(vi))
check("moi chuoi vi co ban en (%d chuoi)" % len(vi), not only_vi, "thieu o EN: %s" % only_vi[:10])
check("moi chuoi en co ban vi", not only_en, "thieu o VI: %s" % only_en[:10])

fmt = re.compile(r"%(?:\d+\$)?[sdfx]|%%")
bad = [n for n in vi if n in en and sorted(fmt.findall(vi[n])) != sorted(fmt.findall(en[n]))]
check("placeholder (%1$s/%1$d...) khop giua vi va en", not bad, "lech: %s" % bad[:10])

def multi_nonpositional(d):
    """AAPT2 tu choi chuoi co >=2 placeholder khong danh so (vd '%s ... %s'): phai dung %1$s %2$s."""
    return [n for n, v in d.items() if len(re.findall(r"%(?!\d+\$)[sdf]", v)) >= 2]
check("vi: khong co chuoi >=2 placeholder khong danh so", not multi_nonpositional(vi), str(multi_nonpositional(vi)))
check("en: khong co chuoi >=2 placeholder khong danh so", not multi_nonpositional(en), str(multi_nonpositional(en)))

def unescaped_apostrophes(path):
    bad = []
    for name, body in raw_strings(path):
        b = body.strip()
        if b.startswith('"') and b.endswith('"'):
            continue  # trong ngoac kep thi dau nhay don hop le
        if re.search(r"(?<!\\)'", b):
            bad.append(name)
    return bad
check("vi: khong co dau nhay don chua escape", not unescaped_apostrophes(vi_path), str(unescaped_apostrophes(vi_path)[:10]))
check("en: khong co dau nhay don chua escape", not unescaped_apostrophes(en_path), str(unescaped_apostrophes(en_path)[:10]))

# layout
ids = {}; layout_str_refs = set(); dup = []
for fn in sorted(os.listdir(os.path.join(ROOT, "res", "layout"))):
    p = os.path.join(ROOT, "res", "layout", fn)
    try:
        ET.parse(p)
    except ET.ParseError as e:
        check("layout %s la XML hop le" % fn, False, str(e)); continue
    text = open(p, encoding="utf-8").read()
    seen = set()
    for m in re.finditer(r'android:id="@\+id/(\w+)"', text):
        if m.group(1) in seen: dup.append((fn, m.group(1)))
        seen.add(m.group(1))
    layout_str_refs |= set(re.findall(r"@string/(\w+)", text))
check("moi layout la XML hop le", True)
check("android:id trong tung layout la duy nhat", not dup, str(dup))
missing_layout = sorted(layout_str_refs - set(vi))
check("moi @string/x trong layout ton tai (%d tham chieu)" % len(layout_str_refs), not missing_layout, str(missing_layout[:10]))

# Kotlin
kt_refs = set()
kdir = os.path.join(ROOT, "java", "com", "wppocket", "server")
for fn in os.listdir(kdir):
    if fn.endswith(".kt"):
        kt_refs |= set(re.findall(r"(?<!android\.)R\.string\.(\w+)", open(os.path.join(kdir, fn), encoding="utf-8").read()))
missing_kt = sorted(kt_refs - set(vi))
check("moi R.string.x trong Kotlin ton tai (%d tham chieu)" % len(kt_refs), not missing_kt, str(missing_kt[:10]))

# chuoi mo coi cua vong 21 (cac khoa moi phai duoc dung)
new_keys = ["btn_import_backup", "btn_export_backup", "toast_import_reading", "toast_import_invalid", "toast_no_file_picker",
            "toast_file_too_small", "export_pick_title", "export_option_portable", "export_portable_warning", "toast_export_preparing",
            "toast_export_done", "toast_export_failed", "toast_export_expired", "switch_heavy_only_charging", "hint_heavy_only_charging"]
used = kt_refs | layout_str_refs
check("cac chuoi moi cua vong 21 deu duoc dung (khong mo coi)", all(k in used for k in new_keys), str([k for k in new_keys if k not in used]))

print("\nTONG KET: pass=%d fail=%d" % (passed, failed))
sys.exit(1 if failed else 0)
