#!/bin/sh
# Chay kiem thu JVM cho DbCheckLogic.kt (can kotlinc + java). HANDOFF.md muc 1bp.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/DbCheckLogic.kt" "$HERE/DbCheckLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" DbCheckLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
