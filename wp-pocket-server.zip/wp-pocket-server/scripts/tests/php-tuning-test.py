#!/usr/bin/env python3
"""Ho so hieu nang PHP (PDF 2 R15-R18; HANDOFF.md muc 1bp): chay cac ham shell THAT cua start-lamp.sh bang bash that tren
php.ini/nginx.conf render tu template THAT (lamp_render). Khong can php/nginx/mariadb."""
import os, re, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
import lamp_render as lr

pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
rd = lambda p: open(os.path.join(ROOT, p), encoding="utf-8").read()
SL = rd("scripts/runtimes/templates/start-lamp.sh")
NG_T = rd("scripts/runtimes/templates/nginx.conf.template"); INI_T = rd("scripts/runtimes/templates/php.ini.template")

def values_for(tpl_name):
    return {v: "8080" if "PORT" in v else ("" if "REALIP" in v or "LINE" in v or "PREPEND" in v else "/x") for _p, v in lr.sed_pairs(tpl_name, SL)}
# php.ini duoc render trong HAM render_php_ini (sed thut dong) nen lamp_render.sed_pairs khong thay - tu thay placeholder: dong "*_LINE"/PREPEND -> rong, con lai -> /x
ini0 = re.sub(r"__[A-Z0-9_]+__", lambda m: "" if ("LINE" in m.group(0) or "PREPEND" in m.group(0)) else "/x", INI_T)
ng0 = lr.render(NG_T, "nginx.conf.template", values_for("nginx.conf.template"), SL)

m = re.search(r"(# === Ho so hieu nang PHP \(PDF 2 R15-R18.*?# === HET ho so hieu nang PHP ===)", SL, re.S)
check("start-lamp.sh co khoi ham ho so hieu nang PHP (co moc dau/cuoi)", m is not None)
FUNCS = m.group(1)

def effective(ini):
    d = {}
    for l in ini.splitlines():
        t = l.strip()
        if not t or t.startswith(";"): continue
        mm = re.match(r"([a-z_.]+)\s*=\s*(.+)$", t)
        if mm: d[mm.group(1)] = mm.group(2).strip().strip('"')
    return d
def to_mb(v):
    m = re.match(r"(\d+)([KkMmGg]?)", v); return int(m.group(1)) * {"K": 1 / 1024, "M": 1, "G": 1024}[(m.group(2) or "M").upper()]
PHP_LOC = re.compile(r"location ~ \\\.php\$ \{((?:(?!\n        \}).)*)", re.S)
def php_read_timeout(ng):
    # NHIEU location co fastcgi_read_timeout (healthz = 5s): chi lay cai trong location PHP chinh
    blk = PHP_LOC.search(ng); m = re.search(r"fastcgi_read_timeout\s+(\d+)s;", blk.group(1)) if blk else None
    return int(m.group(1)) if m else None
def layers_ok(ini, ng):
    e = effective(ini); cb = re.search(r"client_max_body_size\s+(\d+)([kKmMgG])\s*;", ng); rt = php_read_timeout(ng)
    return bool(cb and rt and to_mb(cb.group(1) + cb.group(2)) >= to_mb(e["post_max_size"]) >= to_mb(e["upload_max_filesize"]) and rt >= int(e["max_execution_time"]))

def run(profile):
    with tempfile.TemporaryDirectory() as d:
        open(os.path.join(d, "php.ini"), "w").write(ini0); open(os.path.join(d, "nginx.conf"), "w").write(ng0)
        open(os.path.join(d, "funcs.sh"), "w").write(FUNCS)
        env = {k: v for k, v in os.environ.items() if k != "WPP_PHP_PROFILE"}
        if profile is not None: env["WPP_PHP_PROFILE"] = profile
        r = subprocess.run(["bash", "-c", 'RUNDIR="%s"; . "%s/funcs.sh"; php_tuning_ini; php_tuning_nginx' % (d, d)], capture_output=True, text=True, env=env, cwd=d)
        return r, open(os.path.join(d, "php.ini")).read(), open(os.path.join(d, "nginx.conf")).read(), os.listdir(d)

# ---- DAC TA MAC DINH khop template that ----
e0 = effective(ini0)
check("ho so 0 (mac dinh) khop DUNG gia tri hien co cua template: 128M / 60 / 32M / 32M va nginx 32m",
      (e0["memory_limit"], e0["max_execution_time"], e0["post_max_size"], e0["upload_max_filesize"]) == ("128M", "60", "32M", "32M") and "client_max_body_size 32m;" in ng0)
check("tien de: 'client_max_body_size 32m;' va 'fastcgi_read_timeout 60s;' xuat hien DUNG 1 lan trong nginx.conf.template (sed moi co cai de thay)", NG_T.count("client_max_body_size 32m;") == 1 and NG_T.count("fastcgi_read_timeout 60s;") == 1)
check("fastcgi_read_timeout 60s nam trong location PHP chinh (~ \\.php$), khong phai noi khac", re.search(r"location ~ \\\.php\$ \{(?:(?!\n        \}).)*fastcgi_read_timeout 60s;", NG_T, re.S) is not None)
check("tang mac dinh da khop nhau (nginx >= post >= upload; 60s >= 60)", layers_ok(ini0, ng0))

# ---- KHONG DOI GI khi ho so la/khong dat ----
for prof in (None, "0", "", "abc", "9", "-1", "3", "01", "1 ", "1; touch PWN", "$(touch PWN)", "`touch PWN`"):
    r, ini, ng, files = run(prof)
    check("WPP_PHP_PROFILE=%r -> KHONG doi byte nao (php.ini + nginx.conf), khong loi, khong tao tep la" % (prof,), r.returncode == 0 and ini == ini0 and ng == ng0 and "PWN" not in files and not os.path.exists("PWN"), r.stderr)

# ---- ho so 1 va 2 ----
kt = rd("app/src/main/java/com/wppocket/server/PhpTuning.kt")
kprof = {int(i): (int(a), int(b), int(c)) for i, a, b, c in re.findall(r"Profile\((\d), (\d+), (\d+), (\d+)\)", kt)}
sprof = {int(i): (int(a), int(b), int(c)) for i, a, b, c in re.findall(r"(\d)\) PT_MEMORY=(\d+)M; PT_EXEC=(\d+); PT_UPLOAD=(\d+) ;;", SL)}
check("DOI CHIEU Kotlin <-> shell: bang ho so 1,2 giong het (memoryMb, execSeconds, uploadMb)", kprof.get(1) == sprof.get(1) and kprof.get(2) == sprof.get(2) and kprof.get(0) == (128, 60, 32), "%s | %s" % (kprof, sprof))
for prof in ("1", "2"):
    r, ini, ng, _ = run(prof); e = effective(ini); mem, ex, up = sprof[int(prof)]
    check("ho so %s: php.ini hieu luc = memory %dM, exec %d, post/upload %dM (dong CUOI thang)" % (prof, mem, ex, up), r.returncode == 0 and (e["memory_limit"], e["max_execution_time"], e["post_max_size"], e["upload_max_filesize"]) == ("%dM" % mem, str(ex), "%dM" % up, "%dM" % up), str(e))
    check("ho so %s: nginx client_max_body_size = %dm va fastcgi_read_timeout = %ds (exec + 10)" % (prof, up, ex + 10), ("client_max_body_size %dm;" % up) in ng and ("fastcgi_read_timeout %ds;" % (ex + 10)) in ng)
    check("ho so %s: ba tang upload KHOP va timeout nginx >= max_execution_time" % prof, layers_ok(ini, ng))
    check("ho so %s: phan con lai cua php.ini va nginx.conf giu nguyen (chi them khoi cuoi / doi dung 2 dong)" % prof, ini.startswith(ini0) and re.sub(r"client_max_body_size \d+m;|fastcgi_read_timeout \d+s;", "", ng) == re.sub(r"client_max_body_size \d+m;|fastcgi_read_timeout \d+s;", "", ng0))
r, ini, ng, _ = run("1"); r2, ini2, ng2, _ = run("2")
check("DOI CHUNG AM: neu chi nang php.ini ma QUEN nginx thi bo kiem tra tang bat duoc (nginx 32m < post 64M)", not layers_ok(ini, ng0))
check("DOI CHUNG AM: nang max_execution_time ma QUEN fastcgi_read_timeout thi bo kiem tra bat duoc (60s < 120)", not layers_ok(ini, ng.replace("fastcgi_read_timeout 130s;", "fastcgi_read_timeout 60s;")))

# ---- noi day trong start-lamp.sh va tu Kotlin ----
check("start-lamp.sh: render_php_ini goi php_tuning_ini BEN TRONG ham (lan render lai OPcache cung giu ho so)", re.search(r"render_php_ini\(\) \{.*?php_tuning_ini.*?\n\}\nopcache_vars", SL, re.S) is not None)
check("start-lamp.sh: php_tuning_nginx goi NGAY SAU lenh render nginx.conf", re.search(r'"\$SUP/nginx\.conf\.template" > "\$RUNDIR/nginx\.conf"\nphp_tuning_nginx', SL) is not None)
check("start-lamp.sh: ca nginx.conf.tune dung mv (khong dung 'sed -i' - khong chac co tren moi toybox)", "sed -i" not in FUNCS and "mv " in FUNCS)
svc = rd("app/src/main/java/com/wppocket/server/ServerForegroundService.kt")
check("ServerForegroundService truyen WPP_PHP_PROFILE (da clamp 0..2) cho start-lamp.sh", 'env["WPP_PHP_PROFILE"] = PhpTuning.clamp(sleepPrefs.getInt(Prefs.KEY_PHP_PROFILE, 0)).toString()' in svc)
ma = rd("app/src/main/java/com/wppocket/server/MainActivity.kt")
check("MainActivity: nut + hop thoai chon ho so luu Prefs.KEY_PHP_PROFILE", "btnPhpProfile.setOnClickListener { showPhpProfileDialog() }" in ma and "putInt(Prefs.KEY_PHP_PROFILE, PhpTuning.clamp(which))" in ma)
vi, en = rd("app/src/main/res/values/strings.xml"), rd("app/src/main/res/values-en/strings.xml")
check("chuoi giao dien ho so co du VI + EN va so lieu trong chuoi khop bang ho so", all(k in vi and k in en for k in ("php_profile_title", "php_profile_0", "php_profile_1", "php_profile_2", "php_profile_saved", "btn_php_profile"))
      and "256 MB" in vi and "120 giây" in vi and "64 MB" in vi and "192 MB" in vi and "300 giây" in vi and "128 MB" in vi and "256 MB" in en and "120 s" in en and "300 s" in en)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
