import com.wppocket.server.MonitorLogic
import java.io.File

/**
 * HOP DONG giua PHP (security-guard.php + security-scan.php + mu-plugin Shield cung ghi lamp-run/security-events.log) va Kotlin
 * (Monitoring.checkSecurityEvents -> MonitorLogic.scanSecurityEvents doc lai): file su kien do PHP THAT ghi ra phai duoc bo phan tich dem DUNG.
 * 2 phia chi lien ket bang chuoi van ban - doi 1 phia ma khong doi phia kia se am tham lam hong canh bao Telegram. Xem HANDOFF.md muc 1br.
 * Tham so: <file su kien> <urgent mong doi> <notices mong doi> <autoBans mong doi>
 */
fun main(args: Array<String>) {
    val f = File(args[0])
    val (lines, off) = MonitorLogic.readNewLines(f, 0)
    val s = MonitorLogic.scanSecurityEvents(lines)
    println("dong=${lines.size} urgent=${s.urgent} notices=${s.notices} bans=${s.autoBans} mau=${s.samples.size}")
    val checks = listOf(
        "urgent khop (${s.urgent}==${args[1]})" to (s.urgent == args[1].toInt()),
        "notices khop (${s.notices}==${args[2]})" to (s.notices == args[2].toInt()),
        "autoBans khop (${s.autoBans}==${args[3]})" to (s.autoBans == args[3].toInt()),
        "shouldAlertSecurity = true" to MonitorLogic.shouldAlertSecurity(s),
        "doc het file (offset == kich thuoc)" to (off == f.length()),
        "moi dong su kien deu duoc phan loai (khong dong nao PHP ghi ma Kotlin khong nhan ra)" to (s.urgent + s.notices + s.autoBans == lines.size),
        "mau dai dien <= 3 va dong dau la nghiem trong" to (s.samples.size in 1..3 && s.samples[0].let { m -> listOf("PHAT HIEN", "TAI KHOAN QUAN TRI", "QUYEN QUAN TRI", "EMAIL QUAN TRI", "2FA ", "LO HONG").any { m.startsWith(it) } })
    )
    var ok = true
    for ((name, pass) in checks) {
        println((if (pass) "PASS: " else "FAIL: ") + name)
        if (!pass) ok = false
    }
    if (!ok) System.exit(1)
}
