#!/usr/bin/env python3
"""Kiem thu scripts/tools/make_sbom.py (L5, HANDOFF 1bk): dinh dang CycloneDX hop le, dung nguon, tinh on dinh, khang dau vao hong."""
import json, os, subprocess, sys, tempfile, shutil
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
TOOL = os.path.join(ROOT, 'scripts/tools/make_sbom.py')
PASS = FAIL = 0
def ok(c, n):
    global PASS, FAIL
    if c: PASS += 1; print('  OK  ', n)
    else: FAIL += 1; print('  FAIL', n)
def run(*args):
    return subprocess.run([sys.executable, TOOL, *args], capture_output=True, text=True)

d = tempfile.mkdtemp(prefix='sbom-')
try:
    H = 'a' * 64
    open(d + '/t1.tsv', 'w').write('nginx\t1.27.1\t%s\taarch64\nlibc++\t27c\t%s\taarch64\nnginx\t1.27.1\t%s\taarch64\n# comment\nbad line\nx\ty\tnothex\n' % (H, 'b' * 64, H))
    open(d + '/t2.tsv', 'w').write('nginx\t1.27.1\t%s\tarm\n' % ('c' * 64))
    open(d + '/v.tsv', 'w').write('cloudflared-linux-arm64\tOK\tsha256\t%s\tghrelease\nwordpress.zip\tUNVERIFIED\tsha1\t%s\t\nplugin.zip\tRECORDED\tsha256\tXYZ\tx\nincomplete\n' % ('d' * 64, 'e' * 40))
    out = d + '/s.json'
    r = run('--version', '1.2.3', '--termux', d + '/t1.tsv', d + '/t2.tsv', '--verify', d + '/v.tsv', '--out', out)
    ok(r.returncode == 0, 'chay thanh cong: ' + r.stdout.strip()[:90])
    b = json.load(open(out))
    ok(b['bomFormat'] == 'CycloneDX' and b['specVersion'] == '1.5' and b['version'] == 1, 'khung CycloneDX 1.5')
    ok(b['serialNumber'].startswith('urn:uuid:') and len(b['serialNumber']) == 45, 'serialNumber la urn:uuid hop le')
    ok(b['metadata']['component']['name'] == 'WP Pocket Server' and b['metadata']['component']['version'] == '1.2.3', 'thanh phan goc = app + phien ban')
    ok('timestamp' not in b['metadata'], 'khong co timestamp khi khong truyen (dau ra on dinh)')
    comps = b['components']
    refs = [c['bom-ref'] for c in comps]
    ok(len(refs) == len(set(refs)), 'bom-ref duy nhat')
    nginx = [c for c in comps if c['name'] == 'nginx']
    ok(len(nginx) == 2 and {c['purl'] for c in nginx} == {'pkg:deb/termux/nginx@1.27.1?arch=aarch64', 'pkg:deb/termux/nginx@1.27.1?arch=arm'}, 'goi Termux: khu trung (cung pkg/ver/arch) nhung giu 2 kien truc')
    lc = [c for c in comps if c['name'] == 'libc%2B%2B' or c['name'] == 'libc++']
    ok(len(lc) == 1 and lc[0]['purl'] == 'pkg:deb/termux/libc%2B%2B@27c?arch=aarch64', 'ten co ky tu dac biet duoc ma hoa purl dung (libc++)')
    ok(all(not [h for h in c.get('hashes', []) if len(h['content']) != 64] for c in nginx), 'hash goi Termux 64 hex')
    x = [c for c in comps if c['name'] == 'x']
    ok(len(x) == 1 and 'hashes' not in x[0], 'hash khong hop le bi BO (khong ghi hash gia) nhung goi van duoc liet ke')
    cf = [c for c in comps if c['name'] == 'cloudflared-linux-arm64'][0]
    ok(cf['type'] == 'file' and cf['hashes'] == [{'alg': 'SHA-256', 'content': 'd' * 64}] and {'name': 'wppocket:verify-status', 'value': 'OK'} in cf['properties'], 'tep xac minh: type=file + hash that + trang thai')
    wp = [c for c in comps if c['name'] == 'wordpress.zip'][0]
    ok(wp['hashes'][0]['alg'] == 'SHA-1' and {'name': 'wppocket:verify-status', 'value': 'UNVERIFIED'} in wp['properties'], 'SHA-1 giu dung thuat toan, trang thai UNVERIFIED hien ra trong SBOM')
    pl = [c for c in comps if c['name'] == 'plugin.zip'][0]
    ok('hashes' not in pl, 'hash sai dinh dang (XYZ) khong duoc ghi')
    ok(not [c for c in comps if c['name'] == 'incomplete'], 'dong report thieu cot bi bo')
    ad = [c for c in comps if c['name'] == 'adminer'][0]
    pins = open(os.path.join(ROOT, 'scripts/lib/pins.env')).read()
    sha = [l.split('=')[1] for l in pins.splitlines() if l.startswith('ADMINER_SHA256=')][0].strip()
    ver = [l.split('=')[1] for l in pins.splitlines() if l.startswith('ADMINER_VERSION=')][0].strip()
    ok(ad['hashes'][0]['content'] == sha and ad['version'] == ver, 'Adminer: phien ban + SHA-256 lay dung tu pins.env')
    ok('licenses' in ad and 'GPL' in json.dumps(ad['licenses']), 'giay phep Adminer duoc khai (da doc tan nguon)')
    gr = [c for c in comps if c.get('purl', '').startswith('pkg:maven/')]
    src = open(os.path.join(ROOT, 'app/build.gradle.kts')).read()
    import re
    n_dep = len(re.findall(r'(?m)^\s*implementation\("[^"]+:[^"]+:[^"]+"\)', src))
    ok(len(gr) == n_dep and n_dep >= 5, 'moi phu thuoc Gradle implementation(...) deu co trong SBOM (%d)' % n_dep)
    # on dinh
    out2 = d + '/s2.json'
    run('--version', '1.2.3', '--termux', d + '/t1.tsv', d + '/t2.tsv', '--verify', d + '/v.tsv', '--out', out2)
    ok(open(out, 'rb').read() == open(out2, 'rb').read(), 'cung dau vao => cung tung byte (on dinh)')
    out3 = d + '/s3.json'
    run('--version', '1.2.4', '--termux', d + '/t1.tsv', '--out', out3)
    ok(json.load(open(out3))['serialNumber'] != b['serialNumber'], 'doi dau vao => serialNumber doi')
    r = run('--timestamp', '2026-10-19T00:00:00Z', '--out', d + '/s4.json')
    ok(json.load(open(d + '/s4.json'))['metadata']['timestamp'] == '2026-10-19T00:00:00Z', '--timestamp duoc ghi khi truyen')
    r = run('--termux', d + '/khong-ton-tai.tsv', '--verify', d + '/khong-ton-tai2.tsv', '--out', d + '/s5.json')
    ok(r.returncode == 0 and json.load(open(d + '/s5.json'))['components'], 'nguon thieu -> bo qua, KHONG dung giua chung')
    ok(run().returncode != 0, 'thieu --out -> loi')
finally:
    shutil.rmtree(d, ignore_errors=True)
print('TONG KET: pass=%d fail=%d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
