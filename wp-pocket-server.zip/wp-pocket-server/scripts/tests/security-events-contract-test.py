#!/usr/bin/env python3
"""Hop dong PHP -> Kotlin cho lamp-run/security-events.log (HANDOFF.md muc 1br): 3 thanh phan PHP THAT (security-guard.php, security-scan.php, mu-plugin
Shield) cung ghi file nay; bo phan tich Kotlin (MonitorLogic.scanSecurityEvents) phai nhan ra DUNG moi dong. Phan PHP luon chay; phan Kotlin chay khi co
kotlinc + kotlin (nhu hop dong audit trong run-admin-tests.sh), neu khong thi bo qua (exit 0)."""
import importlib.util, json, os, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
SRC = os.path.normpath(os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java', 'com', 'wppocket', 'server'))
_spec = importlib.util.spec_from_file_location('shieldtest', os.path.join(HERE, 'shield-test.py'))
ST = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ST)
PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:300]) if detail else ''))


def main():
    e = ST.Env()
    try:
        run = e.run
        now = int(time.time())
        # 1) guard: 1 IP cong khai bi chan
        with open(os.path.join(run, 'nginx-security.log'), 'w') as f:
            for p in ('/.env', '/.git/config', '/wp-config.php.bak', '/backup.sql', '/.aws/credentials', '/phpinfo.php'):
                f.write('%d.123 203.0.113.50 404 GET "%s" "curl/8"\n' % (now - 5, p))
        r = subprocess.run(['php', '-d', 'date.timezone=UTC', os.path.join(TPL, 'security-guard.php'), run], capture_output=True, text=True)
        check('guard: chan 1 IP', r.returncode == 0 and 'chan moi: 203.0.113.50' in r.stdout, (r.stdout, r.stderr))
        # 2) scan: cay WordPress nho co 2 phat hien >= CAO (php trong uploads + web-shell trong plugin)
        www = os.path.join(e.tmp, 'www')
        os.makedirs(os.path.join(www, 'wp-includes'))
        os.makedirs(os.path.join(www, 'wp-content', 'uploads'))
        os.makedirs(os.path.join(www, 'wp-content', 'plugins', 'p'))
        open(os.path.join(www, 'wp-load.php'), 'w').write('<?php\n')
        open(os.path.join(www, 'wp-includes', 'version.php'), 'w').write("<?php\n$wp_version = '6.9.5';\n")
        sc = os.path.join(TPL, 'security-scan.php')
        subprocess.run(['php', sc, www, run], capture_output=True, text=True)               # lap moc sach
        open(os.path.join(www, 'wp-content', 'uploads', 'x.php'), 'w').write('<?php echo 1;\n')
        open(os.path.join(www, 'wp-content', 'plugins', 'p', 's.php'), 'w').write("<?php @eval(base64_decode($_POST['x']));\n")
        r = subprocess.run(['php', sc, www, run], capture_output=True, text=True)
        check('scan: bao phat hien', r.returncode == 0 and 'nghiem trong' in r.stdout, (r.stdout, r.stderr))
        scan_res = json.load(open(os.path.join(run, 'security-scan.json')))
        scan_events = sum(1 for f in scan_res['findings'] if f['sev'] in ('critical', 'high'))
        check('scan: co 2 phat hien >= cao', scan_events == 2, scan_res['counts'])
        # 3) Shield: 3 nghiem trong + 3 luu y
        d = e.js(r'''$_SERVER['REMOTE_ADDR'] = '45.1.2.3';
          fire('user_register', [1]);
          fire('set_user_role', [2, 'administrator', ['editor']]);
          fire('update_option_admin_email', ['boss@example.com', 'attacker@evil.io']);
          fire('activated_plugin', ['seo-booster/seo-booster.php']);
          $f = wppocket_shield_store_path();
          wppocket_shield_record_success($f, 'id:1', wppocket_shield_ip_key('91.1.2.3'), time() - 100);
          $_SERVER['REMOTE_ADDR'] = '62.200.1.1'; fire('wp_login', ['admin', $USERS[1]]);
          for ($i = 1; $i <= 20; $i++) { $_SERVER['REMOTE_ADDR'] = "45.10.$i.7"; fire('wp_login_failed', ['admin']); }
          echo 'x';''')
        events = open(os.path.join(run, 'security-events.log')).read()
        n_lines = events.count('\n')
        exp_urgent, exp_notice, exp_ban = scan_events + 3, 3, 1
        check('tong so dong su kien = %d (guard 1 + scan %d + Shield 6)' % (1 + scan_events + 6, scan_events), n_lines == 1 + scan_events + 6, (n_lines, events))
        check('moi dong theo dinh dang "YYYY-MM-DD HH:MM:SS ip=<ip> ..."', all(__import__('re').match(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d ip=\S+ \S', l) for l in events.strip().split('\n')))
        if shutil.which('kotlinc') and shutil.which('kotlin'):
            out = tempfile.mkdtemp(prefix='seccontract-')
            try:
                r = subprocess.run(['kotlinc', '-nowarn', os.path.join(SRC, 'MonitorLogic.kt'), os.path.join(SRC, 'AlertThresholds.kt'), os.path.join(HERE, 'SecurityEventsContractTest.kt'), '-d', out],
                                   capture_output=True, text=True)
                check('Kotlin bien dich', r.returncode == 0, r.stderr[-300:])
                if r.returncode == 0:
                    r = subprocess.run(['kotlin', '-cp', out, 'SecurityEventsContractTestKt', os.path.join(run, 'security-events.log'), str(exp_urgent), str(exp_notice), str(exp_ban)], capture_output=True, text=True)
                    print(r.stdout.strip())
                    check('Kotlin: file su kien do PHP that ghi duoc phan tich dung', r.returncode == 0 and 'FAIL' not in r.stdout, r.stdout[-400:] + r.stderr[-200:])
            finally:
                shutil.rmtree(out, ignore_errors=True)
        else:
            print('(bo qua phan Kotlin: khong co kotlinc/kotlin)')
    finally:
        e.clean()
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
