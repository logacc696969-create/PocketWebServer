#!/usr/bin/env python3
"""Ban PORT 1-1 cua UploadLogic.kt + doi chieu van ban voi ma that (HANDOFF.md muc 1bo-F).
Than multipart duoc ghep that va PHAN TICH bang bo parser MIME chuan cua Python (khong tu tin vao chinh ban port).
Cung khang dinh voi UploadLogicTest.kt (Kotlin that chay o CI). Khong can kotlinc/php/mang."""
import email, email.policy, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(ROOT, "app/src/main/java/com/wppocket/server")
pass_n = fail_n = 0
def check(name, cond):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name)

TG_MAX = 50 * 1024 * 1024
def clean(s): return s.replace('"', "'").replace("\r", " ").replace("\n", " ")
def build(boundary, fields, file_field, file_name, ctype):
    h = ""
    for n, v in fields:
        h += "--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (boundary, clean(n), v)
    h += "--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: %s\r\n\r\n" % (boundary, clean(file_field), clean(file_name), ctype)
    return h.encode("utf-8"), ("\r\n--%s--\r\n" % boundary).encode("utf-8")
def too_large(n): return n > TG_MAX
def mb(b): return (b + 1048575) // 1048576
def failure_note(tc, tok, wc, wok, n):
    p = []
    if tc and not tok:
        p.append("Telegram khong nhan tep %d MB (gioi han %d MB)" % (mb(n), mb(TG_MAX)) if too_large(n) else "gui qua Telegram that bai")
    if wc and not wok: p.append("gui qua webhook that bai")
    return None if not p else "backup da tao xong va van nam trong may nhung CHUA co ban sao ngoai may: " + "; ".join(p)

# ---- ghep + phan tich bang parser chuan ----
payload = bytes(range(256)) * 40 + b"\r\n--BND--\r\nlooks-like-boundary-but-isnt"
h, f = build("----WPPocketBoundary1729", [("chat_id", "-100123"), ("caption", "Sao luu: tiếng Việt có dấu")], "document", "backup-2026-10-22.zip", "application/zip")
body = h + payload + f
msg = email.message_from_bytes(b"Content-Type: multipart/form-data; boundary=----WPPocketBoundary1729\r\n\r\n" + body, policy=email.policy.HTTP)
parts = {p.get_param("name", header="content-disposition"): p for p in msg.iter_parts()}
check("parser MIME chuan doc duoc 3 phan: chat_id, caption, document", set(parts) == {"chat_id", "caption", "document"})
raw = lambda p: bytes(p.get_payload(decode=True)).decode("utf-8")   # phan truong khong khai bao charset -> doc nhi phan roi giai ma UTF-8 (Telegram cung doc nhu vay)
check("chat_id + caption (tieng Viet co dau) nguyen ven", raw(parts["chat_id"]).strip() == "-100123" and raw(parts["caption"]).strip() == "Sao luu: tiếng Việt có dấu")
doc = parts["document"]
check("tep: ten tep + loai noi dung dung", doc.get_filename() == "backup-2026-10-22.zip" and doc.get_content_type() == "application/zip")
check("tep: noi dung nhi phan nguyen ven tung byte (ke ca chuoi giong boundary ben trong)", bytes(doc.get_payload(decode=True)) == payload)
check("tong do dai khai bao (header+tep+footer) == so byte thuc su gui (Content-Length dung)", len(h) + len(payload) + len(f) == len(body))
check("do dai tinh theo BYTE, khong theo ky tu (tieng Viet 2-3 byte/ky tu)", len(h) > len(h.decode("utf-8")))
check("tep rat lon (> 2 GB) khong tran: tong = header + n + footer", len(h) + 3_000_000_000 + len(f) == len(h) + len(f) + 3 * 10**9)
h2, _ = build("B", [], "file", 'a"b\r\nX-Evil: 1.zip', "application/zip")
check("ten tep co nhay kep/CRLF khong chen duoc header moi", b"\r\nX-Evil" not in h2 and b'filename="a\'b  X-Evil: 1.zip"' in h2)
check("webhook (khong truong phu, field 'file'): chi 1 phan", len(list(email.message_from_bytes(b"Content-Type: multipart/form-data; boundary=B\r\n\r\n" + build("B", [], "file", "x.zip", "application/zip")[0] + b"hello" + build("B", [], "file", "x.zip", "application/zip")[1], policy=email.policy.HTTP).iter_parts())) == 1)

check("ranh gioi 50 MB: dung 50 MB duoc gui, 50 MB + 1 byte thi khong", not too_large(TG_MAX) and too_large(TG_MAX + 1))
check("failureNote: khong cau hinh / thanh cong -> None", failure_note(False, True, False, True, 10) is None and failure_note(True, True, True, True, 10) is None)
n = failure_note(True, False, False, True, 120 * 1024 * 1024)
check("failureNote: tep 120 MB -> neu ro kich thuoc + gioi han 50 MB", n and "120 MB" in n and "50 MB" in n and "CHUA co ban sao ngoai may" in n)
check("failureNote: loi mang (tep nho) -> khong noi gioi han; ca hai that bai -> liet ke ca hai; webhook rieng", "Telegram that bai" in failure_note(True, False, False, True, 1024) and "50 MB" not in failure_note(True, False, False, True, 1024)
      and "Telegram" in failure_note(True, False, True, False, 1024) and "webhook" in failure_note(True, False, True, False, 1024) and "Telegram" not in failure_note(True, True, True, False, 1024))

# ---- doi chieu van ban voi ma Kotlin THAT ----
rd = lambda n: open(os.path.join(SRC, n), encoding="utf-8").read()
ul, tn, wu, bw, sfs, tcw = (rd(x) for x in ("UploadLogic.kt", "TelegramNotifier.kt", "WebhookUploader.kt", "BackupWorker.kt", "ServerForegroundService.kt", "TelegramCommandWorker.kt"))
check("hang so: TELEGRAM_MAX_BYTES Kotlin == 50 MB cua ban port", re.search(r"TELEGRAM_MAX_BYTES: Long = 50L \* 1024L \* 1024L", ul) is not None)
def streaming_ok(t): return "setFixedLengthStreamingMode(body.totalLength(file.length()))" in t and "UploadLogic.buildMultipart(" in t and "out.write(body.header)" in t and "out.write(body.footer)" in t
check("TelegramNotifier.sendDocument: streaming do dai co dinh + dung bo dung multipart chung", streaming_ok(tn))
check("WebhookUploader.uploadFile: streaming do dai co dinh + dung bo dung multipart chung", streaming_ok(wu))
check("DOI CHUNG AM: bo dong streaming thi kiem tra BAT DUOC (ma cu se ra DO)", not streaming_ok(tn.replace("setFixedLengthStreamingMode(body.totalLength(file.length()))", "")))
check("Telegram: tu choi tep > 50 MB truoc khi gui (tiet kiem data 4G)", "if (UploadLogic.telegramTooLarge(file.length()))" in tn)
bad_lines = [l.strip() for t in (bw, sfs, tcw) for l in t.split("\n") if "TelegramNotifier.sendDocument(" in l and not re.search(r"\b(val|var)\s+\w+\s*=|\?\s*TelegramNotifier|else true", l.split("TelegramNotifier.sendDocument(")[0] + "x")]
check("moi noi goi sendDocument deu GAN ket qua (khong con vut bo): %s" % bad_lines, bad_lines == [])
check("moi noi goi uploadFile deu gan ket qua", all(re.search(r"(val|var)\s+\w+\s*=", l) for t in (bw, sfs) for l in t.split("\n") if "WebhookUploader.uploadFile(" in l))
check("3 noi gui backup deu dung UploadLogic.failureNote", all("UploadLogic.failureNote(" in t for t in (bw, sfs, tcw)))
check("BackupWorker: chi bao backup_ok khi KHONG co that bai; that bai -> backup_failed", re.search(r"if \(failNote == null\) \{\s*AlertWebhook\.notify\(applicationContext, \"backup_ok\"", bw) is not None and "\"backup_failed\", \"WP Pocket Server - $failNote\"" in bw)
check("dung lai su kien backup_failed co san trong ALERT_EVENTS (khong them ten moi lam hong danh sach trang)", 'setOf("site_down", "backup_ok", "backup_failed", "backup_verify_failed")' in rd("MonitorLogic.kt"))
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
