#!/bin/sh
# L6 (PDF 2; HANDOFF.md muc 1bp-J): do do phu (JaCoCo) cua cac test JVM Kotlin cho logic thuan.
# Khong sua 11 script run-*-test.sh: dat 2 "shim" len PATH - `kotlinc` that + sao chep class ra thu muc chung, `kotlin` that + JAVA_OPTS
# gan agent JaCoCo. Can: kotlinc, kotlin, java, python3 va (de bao cao) JACOCO_AGENT=<org.jacoco.agent-*-runtime.jar>, JACOCO_CLI=<org.jacoco.cli-*-nodeps.jar>.
# COVERAGE_SKIP_REPORT=1: chi chay cac test (dung de kiem thu chinh script nay bang kotlinc/kotlin gia).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/../.."
OUT="${COVERAGE_OUT:-$ROOT/coverage-out}"; CLS="$OUT/classes"; EXEC="$OUT/jacoco.exec"; SHIM="$OUT/shim"
REAL_KOTLINC="$(command -v kotlinc)"; REAL_KOTLIN="$(command -v kotlin)"
rm -rf "$OUT"; mkdir -p "$CLS" "$SHIM"
cat > "$SHIM/kotlinc" <<SH
#!/bin/sh
"$REAL_KOTLINC" "\$@" || exit \$?
prev=""; for a in "\$@"; do [ "\$prev" = "-d" ] && cp -r "\$a"/. "$CLS"/ 2>/dev/null; prev="\$a"; done
exit 0
SH
cat > "$SHIM/kotlin" <<SH
#!/bin/sh
JAVA_OPTS="\$JAVA_OPTS -javaagent:${JACOCO_AGENT:-/khong-co}=destfile=$EXEC,append=true,includes=com.wppocket.*" exec "$REAL_KOTLIN" "\$@"
SH
chmod +x "$SHIM/kotlinc" "$SHIM/kotlin"
fails=0
for t in "$HERE"/run-*-test.sh; do
  case "$(basename "$t")" in run-coverage.sh) continue;; esac
  PATH="$SHIM:$PATH" sh "$t" >"$OUT/$(basename "$t").log" 2>&1 && echo "OK   $(basename "$t")" || { echo "LOI  $(basename "$t")"; fails=$((fails+1)); }
done
[ "${COVERAGE_SKIP_REPORT:-0}" = "1" ] && { echo "(bo qua bao cao) test loi: $fails"; exit 0; }
[ -f "$EXEC" ] || { echo "khong co du lieu do phu ($EXEC)"; exit 1; }
java -jar "$JACOCO_CLI" report "$EXEC" --classfiles "$CLS/com" --sourcefiles "$ROOT/app/src/main/java" \
  --html "$OUT/html" --xml "$OUT/jacoco.xml" --csv "$OUT/jacoco.csv"
python3 - "$OUT/jacoco.csv" <<'PY'
import csv, sys
rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8")))
tm = tc = 0
print("%-34s %8s" % ("Lop", "Lenh %"))
for r in rows:
    m, c = int(r["INSTRUCTION_MISSED"]), int(r["INSTRUCTION_COVERED"]); tm += m; tc += c
    print("%-34s %7.1f%%" % (r["CLASS"][:34], 100.0 * c / (m + c) if m + c else 0))
print("%-34s %7.1f%%" % ("TONG", 100.0 * tc / (tm + tc) if tm + tc else 0))
PY
exit $fails
