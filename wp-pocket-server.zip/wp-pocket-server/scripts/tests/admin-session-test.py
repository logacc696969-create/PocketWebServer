#!/usr/bin/env python3
"""Kiem thu QUAN LY PHIEN _admin/ bang PHP THAT (php -S) - HANDOFF.md muc 1bc (PDF "chat luong tinh phi" G2).

Dung lai harness cua admin-security-test.py (cung cay thu muc, cung Client). Kiem:
  * so phien (lamp-run/admin-sessions.json) ghi dung; trang sessions.php hien thiet bi, danh dau "Thiet bi nay"
  * thu hoi 1 phien / tat ca phien khac / dang xuat (co DOI CHUNG: thieu CSRF thi KHONG co tac dung)
  * DOI MAT KHAU huy MOI phien cu (loi that o ban truoc 1bc: phien cu song vo thoi han)
  * phien cu (truoc khi co quan ly phien) bi buoc dang nhap lai; so mat/hong; fail-open khi khong ghi duoc so
  * 12 lan dang nhap SONG SONG khong hong so (flock); cat toi da 20; XSS qua User-Agent bi escape
DOI CHUNG AM: ORIG_AUTH=<admin-auth.php goc> -> kiem tra "doi mat khau huy phien cu" PHAI do (tai hien loi cu).
Chay: python3 scripts/tests/admin-session-test.py
"""
import importlib.util, json, os, re, shutil, subprocess, sys, tempfile, threading, time

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check
ORIG_AUTH = os.environ.get('ORIG_AUTH')

UA_CHROME_ANDROID = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36'
UA_FIREFOX_WIN = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0'
UA_SAFARI_IPHONE = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1'
UA_EDGE_WIN = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0'


class UAClient(sec.Client):
    def __init__(self, port, ip, ua):
        super().__init__(port, ip); self.ua = ua
    def req(self, method, path, data=None, ip=None, headers=None):
        h = {'User-Agent': self.ua}; h.update(headers or {})
        return super().req(method, path, data, ip, h)


def authed(c, path='/_admin/sessions.php'):
    """Phien con dang nhap? (trang that tra 200 va co noi dung cua chinh trang, khong phai form dang nhap)"""
    sc, body, _ = c.req('GET', path)
    return sc == 200 and 'name="admin_password"' not in body and 'Dang nhap quan tri' not in body


def registry(run):
    p = os.path.join(run, 'admin-sessions.json')
    try: return json.load(open(p))
    except Exception: return None


def audit(run):
    p = os.path.join(run, 'admin-audit.log')
    return open(p, encoding='utf-8').read() if os.path.exists(p) else ''


def csrf(c, page='sessions'):
    return c.token(page)


def main():
    tmp = tempfile.mkdtemp(prefix='sesstest-')
    app, run, www, adm = sec.build_tree(tmp)
    if ORIG_AUTH:
        shutil.copy(ORIG_AUTH, os.path.join(adm, 'auth.php'))
    port = sec.free_port()
    env = dict(os.environ, APP_HOME=app, EXT_DIR=os.path.join(tmp, 'ext'))
    logf = open(os.path.join(tmp, 'php.log'), 'w')
    srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
                            '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=1', '-d', 'error_reporting=E_ALL'],
                           env=env, stdout=logf, stderr=logf)
    try:
        for _ in range(100):
            try:
                import socket; socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        run_tests(port, app, run, www, adm, tmp)
    finally:
        srv.terminate()
        try: srv.wait(timeout=5)
        except Exception: srv.kill()
        logf.close()
        log = open(os.path.join(tmp, 'php.log')).read()
        if sec.FATAL_RE.search(log) and not ORIG_AUTH:
            sec.check('khong co Fatal/Uncaught trong log PHP', False, sec.FATAL_RE.search(log).group(0))
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL))
    return 1 if sec.FAIL else 0


def run_tests(port, app, run, www, adm, tmp):
    pwfile = os.path.join(app, 'admin-password.txt')
    regfile = os.path.join(run, 'admin-sessions.json')

    # ---------------- 1. dang nhap ghi so + trang hien thiet bi ----------------
    print('== 1. so phien + trang sessions.php ==')
    A = UAClient(port, '192.168.1.10', UA_CHROME_ANDROID)
    check('dang nhap thanh cong', A.login())
    if not ORIG_AUTH:
        reg = registry(run)
        check('so phien co DUNG 1 muc sau 1 lan dang nhap', reg is not None and len(reg) == 1, reg)
        row = next(iter(reg.values())) if reg else {}
        check('muc ghi IP, User-Agent, since, last', row.get('ip') == '192.168.1.10' and row.get('ua') == UA_CHROME_ANDROID and row.get('since') and row.get('last'), row)
        sc, body, _ = A.req('GET', '/_admin/sessions.php')
        check('sessions.php hien "Chrome tren Android" va danh dau "Thiet bi nay"', sc == 200 and 'Chrome tren Android' in body and 'Thiet bi nay' in body, sc)
        check('index.php co the dan toi sessions.php', 'href="sessions.php"' in A.req('GET', '/_admin/index.php')[1])
        B = UAClient(port, '192.168.1.11', UA_FIREFOX_WIN); check('client B dang nhap', B.login())
        C = UAClient(port, '10.0.0.5', UA_SAFARI_IPHONE); check('client C dang nhap', C.login())
        D = UAClient(port, '172.16.4.4', UA_EDGE_WIN); check('client D dang nhap', D.login())
        body = A.req('GET', '/_admin/sessions.php')[1]
        check('trang liet ke dung nhan: Firefox/Windows, Safari/iPhone, Edge/Windows (Edge khong bi nhan nham la Chrome)',
              all(x in body for x in ('Firefox tren Windows', 'Safari tren iPhone', 'Edge tren Windows')), re.findall(r'<b>([^<]+)', body))
        check('dung 4 muc, chi 1 muc "Thiet bi nay"', len(registry(run)) == 4 and body.count('Thiet bi nay') == 1)

        # ---------------- 2. thu hoi 1 phien (+ doi chung CSRF) ----------------
        print('\n== 2. thu hoi 1 phien ==')
        tagB = next(t for t, r in registry(run).items() if r['ip'] == '192.168.1.11')
        check('DOI CHUNG: B dang dang nhap truoc khi bi thu hoi', authed(B))
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke', 'tag': tagB})
        check('POST thu hoi THIEU token CSRF -> bi tu choi, B VAN dang nhap', 'CSRF' in body and authed(B) and tagB in registry(run))
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke', 'tag': tagB, 'csrf_token': 'a' * 64})
        check('POST thu hoi voi token SAI -> bi tu choi', 'CSRF' in body and authed(B))
        tok = csrf(A)
        sc, body, _ = A.req('GET', '/_admin/sessions.php?action=revoke&tag=' + tagB)
        check('GET ?action=revoke KHONG co tac dung (chi POST)', authed(B) and tagB in registry(run))
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke', 'tag': 'khong-hop-le', 'csrf_token': tok})
        check('ma phien sai dinh dang -> loi, khong doi so', 'khong hop le' in body and len(registry(run)) == 4)
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke', 'tag': '../../etc/pass', 'csrf_token': tok})
        check('ma phien kieu duong dan -> loi, khong doi so', len(registry(run)) == 4)
        myTag = next(t for t, r in registry(run).items() if r['ip'] == '192.168.1.10')
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke', 'tag': myTag, 'csrf_token': tok})
        check('khong cho tu thu hoi phien dang dung (huong dan bam Dang xuat)', 'Dang xuat' in body and myTag in registry(run) and authed(A))
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke', 'tag': tagB, 'csrf_token': tok})
        check('thu hoi dung (co token) -> bao thanh cong, muc B roi khoi so', 'Da thu hoi' in body and tagB not in registry(run))
        check('B bi DANG XUAT o request ke tiep (thay form dang nhap)', not authed(B))
        check('A (nguoi thu hoi) va C, D KHONG bi anh huong', authed(A) and authed(C) and authed(D))
        check('audit ghi "phien bi huy: phien da bi thu hoi" va "thu hoi phien"', 'phien bi huy: phien da bi thu hoi' in audit(run) and 'thu hoi phien ' in audit(run))
        check('sau khi bi huy, B dang nhap lai duoc binh thuong', B.login() and authed(B))

        # ---------------- 3. dang xuat cac thiet bi khac ----------------
        print('\n== 3. dang xuat cac thiet bi khac ==')
        tok = csrf(A)
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke_others'})
        check('revoke_others THIEU CSRF -> khong co tac dung', authed(B) and authed(C) and authed(D))
        sc, body, _ = A.req('POST', '/_admin/sessions.php', {'action': 'revoke_others', 'csrf_token': tok})
        check('revoke_others co token -> bao so luong (3)', 'Da dang xuat 3' in body, re.findall(r'class="msg[^"]*">([^<]+)', body))
        check('B, C, D deu bi dang xuat; A van dang nhap', not authed(B) and not authed(C) and not authed(D) and authed(A))
        check('so chi con muc cua A', list(registry(run).keys()) == [myTag] or len(registry(run)) == 1)

        # ---------------- 4. dang xuat ----------------
        print('\n== 4. dang xuat phien hien tai ==')
        E = UAClient(port, '192.168.1.20', UA_FIREFOX_WIN); E.login()
        tokE = csrf(E)
        sc, _, loc = E.req('GET', '/_admin/sessions.php?action=logout')
        check('GET ?action=logout KHONG dang xuat (chong dang xuat qua the <img>)', authed(E))
        sc, _, loc = E.req('POST', '/_admin/sessions.php', {'action': 'logout'})
        check('POST logout THIEU token -> khong dang xuat', authed(E))
        before = len(registry(run))
        sc, _, loc = E.req('POST', '/_admin/sessions.php', {'action': 'logout', 'csrf_token': tokE})
        check('logout co token -> 302 ve index.php', sc == 302 and loc and 'index.php' in loc, (sc, loc))
        check('sau logout: cookie cu khong con dung duoc (form dang nhap)', not authed(E))
        check('muc cua E roi khoi so', len(registry(run)) == before - 1)
        check('audit ghi "dang xuat"', re.search(r'ip=192\.168\.1\.20 dang xuat', audit(run)) is not None)

        # ---------------- 5. DOI MAT KHAU huy moi phien cu ----------------
        print('\n== 5. doi mat khau huy MOI phien cu ==')
    else:
        print('(ORIG_AUTH: bo qua cac muc 1-4, chi chay muc doi chung am cua muc 5)')
        B = UAClient(port, '192.168.1.11', UA_FIREFOX_WIN); B.login()
        C = UAClient(port, '10.0.0.5', UA_SAFARI_IPHONE); C.login()
        print('\n== 5. doi mat khau huy MOI phien cu ==')
    if not ORIG_AUTH:
        A.login(); B.login(); C.login()    # B, C da bi dang xuat o muc 3; A o muc 3 con dang nhap nhung dang nhap lai cho chac
    check('DOI CHUNG: truoc khi doi mat khau, A, B va C deu dang nhap', authed(B, '/_admin/maintenance.php') and authed(C, '/_admin/maintenance.php') and (ORIG_AUTH or authed(A, '/_admin/maintenance.php')))
    open(pwfile, 'w').write('Mat-khau-MOI-sau-khi-lo-9876\n')    # giong het MainActivity.showChangeAdminPasswordDialog (ghi de file)
    check('SAU KHI DOI MAT KHAU: phien cu cua B bi huy', not authed(B, '/_admin/maintenance.php'))
    check('SAU KHI DOI MAT KHAU: phien cu cua C bi huy', not authed(C, '/_admin/maintenance.php'))
    if not ORIG_AUTH:
        check('audit ghi ly do "mat khau quan tri da doi"', 'phien bi huy: mat khau quan tri da doi' in audit(run))
        check('A (phien cu) cung bi huy', not authed(A))
        sc, _, _ = B.req('POST', '/_admin/index.php', {'admin_password': sec.PASSWORD})
        check('mat khau CU khong con dang nhap duoc', not authed(B))
        sc, _, _ = B.req('POST', '/_admin/index.php', {'admin_password': 'Mat-khau-MOI-sau-khi-lo-9876'})
        check('mat khau MOI dang nhap duoc, vao duoc trang quan tri', sc == 302 and authed(B))
        check('phien moi co muc trong so', any(r['ip'] == '192.168.1.11' for r in registry(run).values()))
        open(pwfile, 'w').write(sec.PASSWORD + '\n')    # doi LAN 2 (tra ve mat khau goc cho cac muc sau)
        check('doi mat khau LAN 2 cung huy phien vua tao (khong chi lan dau)', not authed(B))

        # ---------------- 6. phien cu / so mat / so hong ----------------
        print('\n== 6. phien cu, so mat/hong, fail-open ==')
        sess_dir = os.path.join(tmp, 'sess')
        # phien "cu" nhu truoc 1bc: co wp_pocket_admin_authed + last_activity nhung KHONG co tag/dau van tay
        sid = 'oldstylesession0123456789abcd'
        open(os.path.join(sess_dir, 'sess_' + sid), 'w').write('wp_pocket_admin_authed|b:1;wp_pocket_last_activity|i:%d;' % int(time.time()))
        O = UAClient(port, '192.168.1.30', UA_FIREFOX_WIN); O.jar['PHPSESSID'] = sid
        check('phien kieu cu (truoc khi co quan ly phien) -> buoc dang nhap lai', not authed(O))
        check('  ... va ly do duoc ghi audit', 'phien cu (truoc khi co quan ly phien)' in audit(run))

        F = UAClient(port, '192.168.1.31', UA_FIREFOX_WIN); F.jar.clear()
        F.req('GET', '/_admin/index.php'); F.req('POST', '/_admin/index.php', {'admin_password': sec.PASSWORD})
        check('F dang nhap', authed(F))
        os.remove(regfile)
        check('XOA file so phien => moi phien bi coi la thu hoi (dung y nghia "dang xuat het")', not authed(F))

        # fail-open: so la 1 THU MUC => khong ghi duoc
        os.makedirs(regfile)
        G = UAClient(port, '192.168.1.32', UA_FIREFOX_WIN); G.req('GET', '/_admin/index.php')
        sc, _, _ = G.req('POST', '/_admin/index.php', {'admin_password': sec.PASSWORD})
        check('KHONG ghi duoc so (dia day gia lap): van DANG NHAP DUOC (fail-open, chu may khong bi khoa ngoai)', sc == 302 and authed(G), sc)
        body = G.req('GET', '/_admin/sessions.php')[1]
        check('  ... trang sessions.php canh bao phien khong thu hoi duoc tu xa', 'khong duoc ghi vao so' in body)
        shutil.rmtree(regfile)

        # ---------------- 7. cat toi da + dong thoi ----------------
        print('\n== 7. cat toi da 20 muc, 12 dang nhap song song ==')
        now = int(time.time())
        fake = {('%016x' % i): {'ip': '192.168.9.9', 'ua': 'x', 'since': now - 100 + i, 'last': now - 100 + i} for i in range(25)}
        fake['deadbeefdeadbeef'] = {'ip': '1.1.1.1', 'ua': 'het han', 'since': now - 99999, 'last': now - 99999}
        json.dump(fake, open(regfile, 'w'))
        H = UAClient(port, '192.168.1.40', UA_FIREFOX_WIN); H.login()
        reg = registry(run)
        check('26 muc gia + 1 dang nhap => cat con <= 20', reg is not None and len(reg) <= 20, len(reg or {}))
        check('muc het han (khong hoat dong > 30 phut) bi don', reg is not None and 'deadbeefdeadbeef' not in reg)
        check('muc moi cua H van con (khong bi cat nham)', reg is not None and any(r['ip'] == '192.168.1.40' for r in reg.values()))
        json.dump({}, open(regfile, 'w'))
        results = []
        def work(i):
            c = UAClient(port, '192.168.2.%d' % (i + 1), UA_FIREFOX_WIN)
            results.append(c.login())
        ts = [threading.Thread(target=work, args=(i,)) for i in range(12)]
        [t.start() for t in ts]; [t.join() for t in ts]
        reg = registry(run)
        check('12 lan dang nhap SONG SONG: ca 12 thanh cong', len(results) == 12 and all(results), results)
        check('so phien khong hong va co du 12 muc (flock hoat dong)', reg is not None and len(reg) == 12, None if reg is None else len(reg))

        # ---------------- 8. XSS qua User-Agent ----------------
        print('\n== 8. XSS qua User-Agent ==')
        X = UAClient(port, '192.168.3.3', '<script>alert(1)</script> Chrome/1 Android'); X.login()
        body = X.req('GET', '/_admin/sessions.php')[1]
        check('DOI CHUNG: dong cua X van duoc hien thi (nhan duoc rut gon tu UA)', 'Chrome tren Android' in body and '192.168.3.3' in body)
        check('User-Agent chua <script> KHONG bi chen vao HTML (chi hien nhan rut gon, khong in nguyen UA)', '<script>alert' not in body, None)

        # ---------------- 9. hop dong audit PHP -> Kotlin ----------------
        print('\n== 9. dong audit moi KHONG bi dem la "dang nhap sai"/"khoa" ==')
        lines = [l for l in audit(run).splitlines() if re.search(r'phien bi huy|dang xuat|thu hoi', l)]
        check('co dong audit moi de kiem (phien bi huy / dang xuat / thu hoi)', len(lines) >= 4, len(lines))
        check('khong dong nao bat dau bang "dang nhap sai"/"sai ma 2FA" hoac chua "BI KHOA TAM" (Kotlin MonitorLogic.scanAudit se khong bao dong gia)',
              not any(re.search(r'ip=\S+\s+(dang nhap sai|sai ma 2FA)', l) or 'BI KHOA TAM' in l for l in lines))
        open(os.path.join(tmp, 'new-audit-lines.txt'), 'w').write('\n'.join(lines) + '\n')
        if os.environ.get('SESSION_TEST_AUDIT_OUT'):
            shutil.copy(os.path.join(tmp, 'new-audit-lines.txt'), os.environ['SESSION_TEST_AUDIT_OUT'])

        # ---------------- 10. ly do cua luat "khong dau cach dau/cuoi" trong PasswordPolicy.kt ----------------
        print('\n== 10. mat khau co dau cach dau/cuoi: tu khoa minh (ly do PasswordPolicy chan) ==')
        for pwd, label in ((' Xk9#mQ2z ', 'dau cach 2 dau'), ('Xk9#mQ2z\n', 'xuong dong cuoi')):
            open(pwfile, 'w').write(pwd)      # giong MainActivity: pwFile.writeText(typed) - KHONG trim
            Z = UAClient(port, '192.168.5.5', UA_FIREFOX_WIN); Z.req('GET', '/_admin/index.php')
            sc, _, _ = Z.req('POST', '/_admin/index.php', {'admin_password': pwd})
            check('mat khau %s: nhap DUNG NGUYEN chuoi da luu van KHONG dang nhap duoc (admin-auth.php trim ban luu)' % label, not authed(Z))
            sc, _, _ = Z.req('POST', '/_admin/index.php', {'admin_password': pwd.strip()})
            check('  ... chi dang nhap duoc khi bo dau cach (nguoi dung khong the doan ra)', authed(Z))
        open(pwfile, 'w').write(sec.PASSWORD + '\n')


if __name__ == '__main__':
    sys.exit(main())
