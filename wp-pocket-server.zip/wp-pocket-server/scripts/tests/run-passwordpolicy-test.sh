#!/bin/sh
# Chay kiem thu JVM cho PasswordPolicy.kt (can kotlinc + java). Khong can Android SDK. HANDOFF.md muc 1bc.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/PasswordPolicy.kt" "$HERE/PasswordPolicyTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" PasswordPolicyTestKt
rc=$?; rm -rf "$OUT"; exit $rc
