import com.wppocket.server.DataLifecycle
import java.io.File
import java.nio.file.Files

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun main() {
    check("formatBytes: 0/am/duoi 1KB", DataLifecycle.formatBytes(0) == "0 B" && DataLifecycle.formatBytes(-5) == "0 B" && DataLifecycle.formatBytes(512) == "512 B" && DataLifecycle.formatBytes(1023) == "1023 B")
    check("formatBytes: KB/MB/GB, 1 chu so thap phan", DataLifecycle.formatBytes(1024) == "1.0 KB" && DataLifecycle.formatBytes(1536) == "1.5 KB" && DataLifecycle.formatBytes(5L * 1024 * 1024) == "5.0 MB" && DataLifecycle.formatBytes(3L * 1024 * 1024 * 1024 + 214748365L) == "3.2 GB")
    check("formatBytes: khong tran don vi (TB) va luon dung dau cham thap phan", DataLifecycle.formatBytes(2048L * 1024 * 1024 * 1024) == "2.0 TB" && !DataLifecycle.formatBytes(1536).contains(","))
    check("wipeConfirmed: dung tu (khong phan biet hoa thuong, bo khoang trang)", DataLifecycle.wipeConfirmed("XOA", "XOA") && DataLifecycle.wipeConfirmed("  xoa ", "XOA") && DataLifecycle.wipeConfirmed("Delete", "DELETE"))
    check("wipeConfirmed: sai/rong/null/tu rong -> khong xac nhan", !DataLifecycle.wipeConfirmed("XO", "XOA") && !DataLifecycle.wipeConfirmed("", "XOA") && !DataLifecycle.wipeConfirmed(null, "XOA") && !DataLifecycle.wipeConfirmed("", "") && !DataLifecycle.wipeConfirmed("x", "  "))

    val tmp = Files.createTempDirectory("datalife").toFile()
    try {
        val files = File(tmp, "files"); File(files, "www/wp-content").mkdirs(); File(files, "mysql-data").mkdirs(); File(files, "lamp-run").mkdirs()
        File(files, "www/wp-content/a.bin").writeBytes(ByteArray(1000)); File(files, "mysql-data/ibdata1").writeBytes(ByteArray(4000))
        File(files, "lamp-run/x.log").writeBytes(ByteArray(300)); File(files, "admin-password.txt").writeBytes(ByteArray(16)); File(files, "other.dat").writeBytes(ByteArray(84))
        val outside = File(tmp, "outside"); outside.mkdirs(); File(outside, "huge.bin").writeBytes(ByteArray(50000))
        Files.createSymbolicLink(File(files, "www/link").toPath(), outside.toPath())
        val backups = File(tmp, "backups"); backups.mkdirs(); File(backups, "b.zip").writeBytes(ByteArray(777))
        val r = DataLifecycle.collect(files, backups)
        check("collect: tung nhom dung (symlink KHONG tinh)", r.site == 1000L && r.db == 4000L && r.run == 300L && r.backups == 777L)
        check("collect: 'khac' = phan con lai cua filesDir", r.other == 100L)
        val backups2 = File(tmp, "sd-backups"); backups2.mkdirs(); File(backups2, "b2.zip").writeBytes(ByteArray(223))
        check("collectAll: cong don backup o NHIEU noi (bo nho chinh 777 + the nho 223 = 1000)", DataLifecycle.collectAll(files, listOf(backups, backups2)).backups == 1000L && DataLifecycle.collectAll(files, emptyList()).backups == 0L)
        val r2 = DataLifecycle.collect(File(tmp, "khong-co"), null)
        check("collect: thu muc khong ton tai / khong co thu muc backup -> toan 0, khong nem loi", r2.site == 0L && r2.db == 0L && r2.run == 0L && r2.backups == 0L && r2.other == 0L)
    } finally { tmp.deleteRecursively() }
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
