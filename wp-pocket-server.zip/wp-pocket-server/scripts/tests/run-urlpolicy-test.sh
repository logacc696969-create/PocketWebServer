#!/bin/sh
# Chay kiem thu JVM cho UrlPolicy.kt + doi chieu voi network_security_config.xml (can kotlinc + java). Khong can Android SDK. HANDOFF.md muc 1br-H.
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HERE/../../app/src/main"
OUT="$(mktemp -d)"
kotlinc -nowarn "$APP/java/com/wppocket/server/UrlPolicy.kt" "$HERE/UrlPolicyTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" UrlPolicyTestKt "$APP/res/xml/network_security_config.xml"
rc=$?; rm -rf "$OUT"; exit $rc
