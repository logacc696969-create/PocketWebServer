#!/usr/bin/env python3
"""Kiem thu gioi han so request PHP DONG THOI cua 1 IP (conn-limit-on, HANDOFF.md muc 1br-H) bang nginx THAT + php-fpm THAT.

Dung DUNG nginx.conf.template va php-fpm.conf.template cua du an (chi doi duong dan, user=root, listen.mode, va pm.max_children 3 -> 16 de du worker cho
10 request cham chay cung luc). Moi request giu worker PHP 2.5 giay (slow.php) de do so luong DONG THOI that.

Kiem: tat (mac dinh) -> 10 request cung luc deu 200; bat -> dung 5 chay duoc, 5 con lai 429, IP KHAC khong bi anh huong, tep tinh va /wp-admin/ khong bi dem, khoa
thay doi theo CF-Connecting-IP (IP khach that sau Cloudflare), giai phong slot khi request xong, tat lai co hieu luc.
Doi chung am: NGINX_TPL=<template khong co limit_conn> -> PHAI do. Can nginx + php-fpm; thieu thi bo qua (exit 0).
"""
import http.client, os, re, shutil, socket, subprocess, sys, tempfile, threading, time

HERE = os.path.dirname(os.path.abspath(__file__))
TPLDIR = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
NGX = os.environ.get('NGINX_TPL') or os.path.join(TPLDIR, 'nginx.conf.template')
PASS = FAIL = 0
LIMIT = 5


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:240]) if d else ''))


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wr(path, txt):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w').write(txt)


def main():
    nginx = which('nginx')
    fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    if not (nginx and fpm):
        print('(bo qua: thieu nginx hoac php-fpm)')
        return 0
    tmp = tempfile.mkdtemp(prefix='limitconn-')
    os.chmod(tmp, 0o755)
    procs = []
    try:
        doc, run, files, stg = (os.path.join(tmp, d) for d in ('www', 'run', 'files', 'stg'))
        for d in (doc, run, files, stg):
            os.makedirs(d)
        port, sport = free_port(), free_port()
        sock = os.path.join(run, 'php-fpm.sock')
        slow = '<?php usleep(2500000); echo "SLOW-OK";\n'
        wr(os.path.join(doc, 'slow.php'), slow)
        wr(os.path.join(doc, 'wp-admin', 'slow.php'), slow)
        wr(os.path.join(doc, 'quick.php'), '<?php echo "QUICK-OK";\n')
        wr(os.path.join(doc, 'style.css'), 'body{}\n')
        conf = open(NGX, encoding='utf-8').read()
        for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)), ('__FPM_SOCK__', sock),
                     ('__CF_REALIP_DIRECTIVES__', ''), ('__STAGING_DOCROOT__', stg)):
            conf = conf.replace(k, v)
        wr(os.path.join(tmp, 'nginx.conf'), 'user root;\n' + conf if os.geteuid() == 0 else conf)
        open(os.path.join(run, 'ban-list.conf'), 'a').close()
        for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
            os.makedirs(m, exist_ok=True)
        fc = open(os.path.join(TPLDIR, 'php-fpm.conf.template'), encoding='utf-8').read()
        for k, v in (('__RUNDIR__', run), ('__FPM_SOCK__', sock), ('__FILESDIR__', files), ('__EXT_DIR__', tmp), ('__STAGING_PORT__', str(sport)),
                     ('__MYSQL_SOCK__', os.path.join(run, 'mysql.sock')), ('__DB_NAME__', 'x'), ('__DB_USER__', 'x'), ('__DB_PASS__', 'x')):
            fc = fc.replace(k, v)
        fc = fc.replace('listen.mode = 0660', 'listen.mode = 0666').replace('pm.max_children = 3', 'pm.max_children = 16')
        fc = re.sub(r'(?m)^\[(www|hard)\]$', lambda m: '[%s]\nuser = root\ngroup = root' % m.group(1), fc)
        wr(os.path.join(tmp, 'fpm.conf'), fc)
        wr(os.path.join(tmp, 'php.ini'), 'cgi.fix_pathinfo=0\n')
        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try:
                socket.create_connection(('127.0.0.1', port), timeout=0.2).close()
                break
            except OSError:
                time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(sock):
                break
            time.sleep(0.1)
        flag = os.path.join(run, 'conn-limit-on')

        def get(path, ip=None, timeout=30):
            h = {'User-Agent': 'Mozilla/5.0 TestBrowser'}
            if ip:
                h['CF-Connecting-IP'] = ip
            c = http.client.HTTPConnection('127.0.0.1', port, timeout=timeout)
            try:
                c.request('GET', path, headers=h)
                r = c.getresponse()
                return r.status, r.read().decode('utf-8', 'replace')
            except Exception as ex:
                return 'ERR', repr(ex)
            finally:
                c.close()

        def burst(path, n, ip, stagger=0.05):
            """n request cung luc (so le chut de thu tu on dinh); tra danh sach status."""
            res = [None] * n

            def run_one(i):
                res[i] = get(path, ip)[0]
            ths = [threading.Thread(target=run_one, args=(i,)) for i in range(n)]
            for t in ths:
                t.start()
                time.sleep(stagger)
            for t in ths:
                t.join()
            return res

        print('== A. Tat (mac dinh): khong gioi han ==')
        check('server len, /quick.php 200', get('/quick.php')[0] == 200)
        r = burst('/slow.php', 10, '198.51.100.7')
        check('TAT: 10 request PHP cham cung luc tu 1 IP -> TAT CA 200 (hanh vi cu khong doi)', r.count(200) == 10, r)

        print('== B. Bat: toi da %d request PHP dong thoi / IP ==' % LIMIT)
        open(flag, 'w').write('1')
        r = burst('/slow.php', 10, '198.51.100.7')
        check('BAT: 10 request cung luc tu 1 IP -> dung %d chay duoc (200), %d bi 429' % (LIMIT, 10 - LIMIT), r.count(200) == LIMIT and r.count(429) == 10 - LIMIT, r)
        # IP khac khong bi anh huong KHI IP thu nhat dang bao hoa
        out = {}

        def saturate():
            out['a'] = burst('/slow.php', LIMIT, '198.51.100.7', 0.02)
        t = threading.Thread(target=saturate)
        t.start()
        time.sleep(0.8)
        sc_same, _ = get('/quick.php', '198.51.100.7')
        sc_other, b_other = get('/quick.php', '203.0.113.9')
        sc_static, _ = get('/style.css', '198.51.100.7')
        sc_admin = get('/wp-admin/slow.php', '198.51.100.7')[0]
        t.join()
        check('BAT, IP A dang giu %d request: IP A them 1 request PHP -> 429' % LIMIT, sc_same == 429, sc_same)
        check('... IP B (khac) cung luc VAN 200 (khong bi anh huong)', sc_other == 200 and 'QUICK-OK' in b_other, (sc_other, b_other))
        check('... tep tinh (style.css) cua IP A van 200 (khong tinh vao gioi han)', sc_static == 200, sc_static)
        check('... /wp-admin/*.php cua IP A van 200 (mien nhu limit_req: Gutenberg gui nhieu REST song song)', sc_admin == 200, sc_admin)
        check('%d request dang chay ban dau deu hoan thanh 200' % LIMIT, out.get('a') == [200] * LIMIT, out.get('a'))
        sc, b = get('/quick.php', '198.51.100.7')
        check('xong request -> slot duoc giai phong: IP A lai goi duoc', sc == 200 and 'QUICK-OK' in b, (sc, b))
        # khoa theo CF-Connecting-IP (IP khach that sau Cloudflare), khong phai IP ket noi 127.0.0.1
        res = {}

        def two_clients():
            res['x'] = burst('/slow.php', LIMIT, '198.51.100.20', 0.02)
        t = threading.Thread(target=two_clients)
        t.start()
        time.sleep(0.8)
        sc_y = get('/quick.php', '198.51.100.21')[0]
        sc_x = get('/quick.php', '198.51.100.20')[0]
        t.join()
        check('khoa theo CF-Connecting-IP: khach .20 dang bao hoa bi 429, khach .21 (cung ket noi 127.0.0.1 tu cloudflared) VAN 200', sc_x == 429 and sc_y == 200, (sc_x, sc_y))
        r = burst('/slow.php', 8, None)
        check('khong co CF-Connecting-IP (truy cap LAN truc tiep): dem theo IP ket noi, cung gioi han %d' % LIMIT, r.count(200) == LIMIT and r.count(429) == 8 - LIMIT, r)

        print('== C. Tat lai ==')
        os.remove(flag)
        deadline = time.time() + 5
        okoff = False
        while time.time() < deadline:
            if burst('/slow.php', 7, '198.51.100.7', 0.01).count(200) == 7:
                okoff = True
                break
            time.sleep(0.5)
        check('xoa co conn-limit-on: 7 request cung luc lai deu 200 (hieu luc sau toi da ~2 giay, khong HUP)', okoff)
        logtxt = ''
        for n in ('nginx-error.log', 'error.log'):
            p = os.path.join(run, n)
            if os.path.exists(p):
                logtxt += open(p, errors='replace').read()
        check('nginx khong ghi loi cau hinh/canh bao "could not build" khi chay', 'emerg' not in logtxt and 'could not build' not in logtxt, logtxt[-200:])
    finally:
        for p in procs:
            try:
                p.terminate()
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
