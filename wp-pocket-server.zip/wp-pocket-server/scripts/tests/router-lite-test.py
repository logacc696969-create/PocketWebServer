#!/usr/bin/env python3
"""Kiem thu BAO MAT router-lite.php (che do Lite) bang `php -S` THAT. Xem HANDOFF.md muc 1av.
Che do Lite khong co nginx: moi luat chan file nhay cam phai nam TRONG router.
Dung dung quy tac cua nginx.conf.template (dotfile tru .well-known, .bak/.old/.swp/
.orig/.save khong phan biet hoa thuong, *.template, /_supervisor/) lam chuan.
Chay: python3 scripts/tests/router-lite-test.py   (can php, python3)
"""
import http.client
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROUTER = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates', 'router-lite.php'))
PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:200]) if detail else ''))


def get(port, raw_path):
    """Gui dung chuoi duong dan tho (khong de thu vien chuan hoa/ma hoa giup)."""
    c = http.client.HTTPConnection('127.0.0.1', port, timeout=20)
    c.putrequest('GET', raw_path, skip_host=False, skip_accept_encoding=True)
    c.endheaders()
    r = c.getresponse()
    body = r.read().decode('utf-8', 'replace')
    c.close()
    return r.status, body


def write(root, rel, content):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w') as f:
        f.write(content)


def main():
    tmp = tempfile.mkdtemp(prefix='routertest-')
    doc = os.path.join(tmp, 'www')
    write(doc, 'index.php', '<?php echo "INDEX-OK " . $_SERVER["REQUEST_URI"];\n')
    write(doc, 'static.txt', 'STATIC-OK')
    write(doc, 'sub/index.php', '<?php echo "SUB-INDEX";\n')
    write(doc, '.well-known/acme/test.txt', 'WELLKNOWN-OK')
    secrets = {
        'wp-config.php.bak': 'SECRET-BAK', 'index.php.old': 'SECRET-OLD', 'a.swp': 'SECRET-SWP',
        'b.orig': 'SECRET-ORIG', 'c.save': 'SECRET-SAVE', 'UPPER.BAK': 'SECRET-UPPER',
        'Mixed.Old': 'SECRET-MIXED', 'x.template': 'SECRET-TPL', '.env': 'SECRET-ENV',
        '.htaccess': 'SECRET-HTA', '.git/config': 'SECRET-GIT', 'sub/.hidden': 'SECRET-HIDDEN',
        '_supervisor/secret.sh': 'SECRET-SUP', 'sub/deep.bak': 'SECRET-DEEP',
    }
    for rel, content in secrets.items():
        write(doc, rel, content)
    # thu muc sao luu cua plugin + PHP trong uploads (HANDOFF.md muc 1aw)
    for rel in ('wp-content/ai1wm-backups/site.wpress', 'wp-content/updraft/backup_db.gz',
                'wp-content/backups-dup-lite/x.zip', 'wp-content/uploads/backupbuddy_backups/x.zip',
                'wp-snapshots/x.zip', 'wp-content/backupwordpress-abc123-backups/x.zip',
                'wp-content/uploads/backwpup-9f8e7d-backups/x.zip'):
        write(doc, rel, 'SECRET-BACKUP')
    write(doc, 'wp-content/uploads/shell.php', '<?php echo "SECRET-SHELL-EXECUTED";\n')
    write(doc, 'wp-content/uploads/Sub/X.PHTML', '<?php echo "SECRET-PHTML-EXECUTED";\n')
    write(doc, 'wp-content/uploads/archive.zip', 'ZIP-OK')
    write(doc, 'wp-content/plugins/updraftplus/readme.txt', 'PLUGIN-README')
    write(doc, 'wp-content/plugins/hello/endpoint.php', '<?php echo "PLUGIN-EXEC";\n')
    shutil.copy(ROUTER, os.path.join(doc, '_supervisor', 'router-lite.php'))

    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    log = open(os.path.join(tmp, 'server.log'), 'w')
    srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', doc, os.path.join(doc, '_supervisor', 'router-lite.php')],
                           env=dict(os.environ, APP_HOME=os.path.join(tmp, 'app')), stdout=log, stderr=log)
    try:
        for _ in range(100):
            try:
                socket.create_connection(('127.0.0.1', port), timeout=0.2).close()
                break
            except OSError:
                time.sleep(0.1)

        print('== file hop le van phuc vu duoc ==')
        for path, marker in [('/', 'INDEX-OK'), ('/static.txt', 'STATIC-OK'), ('/sub/', 'SUB-INDEX'),
                             ('/2026/09/bai-viet/', 'INDEX-OK'), ('/.well-known/acme/test.txt', 'WELLKNOWN-OK')]:
            sc, body = get(port, path)
            check('GET %s -> co "%s"' % (path, marker), sc == 200 and marker in body, (sc, body[:60]))

        print('== file nhay cam KHONG duoc lo (truc tiep) ==')
        direct = ['/wp-config.php.bak', '/index.php.old', '/a.swp', '/b.orig', '/c.save', '/UPPER.BAK', '/Mixed.Old',
                  '/x.template', '/.env', '/.htaccess', '/.git/config', '/sub/.hidden', '/_supervisor/secret.sh', '/sub/deep.bak']
        for path in direct:
            sc, body = get(port, path)
            check('truc tiep %s khong lo' % path, 'SECRET' not in body, (sc, body[:60]))

        print('== ne bang ma hoa / chuan hoa duong dan ==')
        tricks = ['/%2eenv', '/%2Eenv', '/sub/../.env', '/./.env', '//.env', '/sub/../_supervisor/secret.sh',
                  '/sub/%2e%2e/_supervisor/secret.sh', '/%5fsupervisor/secret.sh', '/_supervisor%2fsecret.sh',
                  '/sub/../wp-config.php.bak', '/sub/./../index.php.old', '/a/../x.template', '/%2e%2e/%2e%2e/.env',
                  '/wp-config%2ephp.bak', '/..%2f.env', '/sub/..%2f_supervisor/secret.sh', '/.%65nv', '/%2egit/config',
                  '/sub//..//.env', '/.git%2fconfig', '/UPPER%2eBAK', '/sub/deep%2ebak']
        for path in tricks:
            sc, body = get(port, path)
            check('ne %s khong lo' % path, 'SECRET' not in body, (sc, body[:60]))

        print('== thu muc sao luu plugin + PHP trong uploads (1aw) ==')
        for path in ['/wp-content/ai1wm-backups/site.wpress', '/wp-content/updraft/backup_db.gz', '/wp-content/backups-dup-lite/x.zip',
                     '/wp-content/uploads/backupbuddy_backups/x.zip', '/wp-snapshots/x.zip',
                     '/wp-content/backupwordpress-abc123-backups/x.zip', '/wp-content/uploads/backwpup-9f8e7d-backups/x.zip',
                     '/wp-content/uploads/../updraft/backup_db.gz', '/wp-content/%75pdraft/backup_db.gz',
                     '/wp-content/uploads/shell.php', '/wp-content/uploads/Sub/X.PHTML', '/wp-content/uploads/sub/../shell.php']:
            sc, body = get(port, path)
            check('chan %s' % path, 'SECRET' not in body, (sc, body[:60]))
        for path, marker in [('/wp-content/uploads/archive.zip', 'ZIP-OK'), ('/wp-content/plugins/updraftplus/readme.txt', 'PLUGIN-README'),
                             ('/wp-content/plugins/hello/endpoint.php', 'PLUGIN-EXEC')]:
            sc, body = get(port, path)
            check('van phuc vu duoc %s (khong chan nham)' % path, sc == 200 and marker in body, (sc, body[:60]))

        print('== path traversal ra ngoai docroot ==')
        for path in ['/../../../../../../etc/passwd', '/%2e%2e/%2e%2e/%2e%2e/%2e%2e/etc/passwd', '/..%2f..%2f..%2f..%2fetc/passwd',
                     '/sub/../../../../../etc/passwd', '/etc/passwd%00.txt', '/..\\..\\..\\etc\\passwd']:
            sc, body = get(port, path)
            check('traversal %s khong lo /etc/passwd' % path[:50], 'root:x:0:0' not in body, (sc, body[:60]))
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        log.close()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
