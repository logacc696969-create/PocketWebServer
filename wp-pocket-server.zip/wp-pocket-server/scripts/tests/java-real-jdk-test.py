#!/usr/bin/env python3
"""Chay cac ban Java sat nguyen cua logic Kotlin tren JDK THAT (HANDOFF.md muc 1bp).

Ly do: may khong co kotlinc nhung CO JDK day du (jdk.compiler) -> `java File.java` bien dich + chay Java that. Cac logic cua
UpdateMergeLogic / UploadLogic chi goi API cua JDK (java.nio, ZipInputStream, HttpURLConnection) nen chay ban Java sat nguyen ban
cho bang chung chinh xac hon ban Python (symlink that, walkFileTree that, may chu HTTP that, gioi han heap that).
Bo qua (thoat 0) neu may khong co jdk.compiler/jdk.httpserver - CI (setup-java) co day du."""
import os, subprocess, sys, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
J = os.path.join(ROOT, "scripts", "tests", "java")
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)

try:
    mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception:
    mods = ""
if "jdk.compiler" not in mods or "jdk.httpserver" not in mods:
    print("(bo qua: can JDK day du co jdk.compiler + jdk.httpserver)"); sys.exit(0)

def run(args, heap=None, timeout=600):
    cmd = ["java"] + ([heap] if heap else []) + args
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr

rc, out = run([os.path.join(J, "UpdateMergePort.java")])
check("UpdateMergePort tren JDK that: 11/11 (gop de, symlink, Zip Slip, xung dot, doi chung am)", rc == 0 and "fail=0" in out and "pass=11" in out, out[-300:])
rc, out = run([os.path.join(J, "UploadStreamingPort.java"), "correct"])
check("Upload: streaming do dai co dinh gui DUNG tung byte, co Content-Length, khong chunked", rc == 0 and "PASS" in out, out[-300:])
rc, out = run([os.path.join(J, "FatalLogPort.java")])
check("FatalLogPort tren JDK that: 10/10 (phan loai loi PHP, gom nhom, doc theo offset, xoay vong, file lon)", rc == 0 and "pass=10" in out and "fail=0" in out, out[-300:])
kt = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/FatalLogLogic.kt"), encoding="utf-8").read()
check("doi chieu van ban: Kotlin va ban Java dung CUNG chuoi nhan dien/phan loai/gioi han doc (chong lech)",
      'Regex("PHP (Fatal error|Parse error):")' in kt and '"Allowed memory size of"' in kt and '"Maximum execution time of"' in kt and '"PHP Parse error:"' in kt and "MAX_READ_BYTES: Long = 256L * 1024L" in kt and "take(160)" in kt and "take(200)" in kt)
ms = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/Monitoring.kt"), encoding="utf-8").read()
check("Monitoring: checkPhpFatals duoc goi trong runPeriodic va chi tien offset khi da bao duoc/khong co loi",
      "try { checkPhpFatals(context) }" in ms and "putLong(Prefs.KEY_PHP_FATAL_OFFSET, res.second).putLong(Prefs.KEY_PHP_FATAL_ALERT_AT, now)" in ms)
fpm = open(os.path.join(ROOT, "scripts/runtimes/templates/php-fpm.conf.template"), encoding="utf-8").read()
check("nguon du lieu co that: php-fpm ghi loi PHP vao lamp-run/php-error.log (file ma Monitoring doc)", "php_admin_value[error_log] = __RUNDIR__/php-error.log" in fpm and "lamp-run/php-error.log" in ms)
rc, out = run([os.path.join(J, "DbCheckPort.java")])
check("DbCheckPort tren JDK that: 9/9 (CHECK TABLE: khoe, bang hong MyISAM, bo qua, CRLF, SQL, chia lo 100 bang)", rc == 0 and "pass=9" in out and "fail=0" in out, out[-300:])
dk = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/DbCheckLogic.kt"), encoding="utf-8").read()
dr = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/DbCheck.kt"), encoding="utf-8").read()
conds = [
    ("phan loai 'khong ho tro check'", "\"doesn't support check\"" in dk),
    ("gom theo dong status cuoi", 'if (x[0] == "status") lastStatus = x[1]' in dk),
    ("chia lo 100 bang", "CHUNK = 100" in dk),
    ("dung QUICK", '" QUICK;' in dk or " QUICK;\\n" in dk),
    ("chay libmysqlcli.so", "libmysqlcli.so" in dr),
    ("ten CSDL qua BackupManager.dbName", "BackupManager.dbName(context)" in dr),
    ("KHONG chay REPAIR (chi doc)", "REPAIR TABLE" not in dk and "REPAIR TABLE" not in dr),
]
check("doi chieu van ban DbCheck (7 dieu kien, thieu dieu nao in ra dieu do): %s" % [n for n, c in conds if not c], all(c for _, c in conds))
check("DbCheck dung cung khuon BackupManager: LD_LIBRARY_PATH compat-libs, API 26 (waitFor co thoi han), khong dung API Java 11 (nullOutputStream)",
      "compat-libs" in dr and "proc.waitFor(120, TimeUnit.SECONDS)" in dr and "nullOutputStream" not in dr)
rc, out = run([os.path.join(J, "BackupDirPort.java")])
check("BackupDirPort tren JDK that: 12/12 (chon noi ghi, gop danh sach 2 noi, giu 5 ban tren ca hai, .partial khong bi dong toi)", rc == 0 and "pass=12" in out and "fail=0" in out, out[-300:])
bd = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/BackupDirLogic.kt"), encoding="utf-8").read()
bm = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/BackupManager.kt"), encoding="utf-8").read()
ma2 = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/MainActivity.kt"), encoding="utf-8").read()
conds2 = [
    ("bo loc ten backup giong ban Java", 'name.startsWith("backup-") && (name.endsWith(".zip") || name.endsWith(".zip.enc"))' in bd),
    ("mac dinh KHONG bat tuy chon (getBoolean(..., false))", "getBoolean(Prefs.KEY_BACKUP_ON_SD, false)" in bm),
    ("giu KEEP_BACKUPS tinh tren moi noi qua BackupDirLogic.excess(listBackups", "BackupDirLogic.excess(listBackups(context), KEEP_BACKUPS)" in bm),
    ("listBackups gop moi noi", "BackupDirLogic.listAll(backupRoots(context))" in bm),
    ("khong con cho nao ghi cung thu muc backup cua bo nho chinh ngoai du phong cua backupRoots", bm.count('getExternalFilesDir(null), "backups"') == 1),
    ("wipe + thong ke dung backupRoots (xoa/tinh CA the nho)", "for (d in BackupManager.backupRoots(this)) UpdateMergeLogic.deleteNoFollow(d)" in ma2 and "DataLifecycle.collectAll(filesDir, BackupManager.backupRoots(this))" in ma2),
    ("tuy chon luu prefs khi doi checkbox", "putBoolean(Prefs.KEY_BACKUP_ON_SD, checked)" in ma2),
    ("chi tep backup sang the nho: KHONG co duong dan the nho cho mysql-data/www/lamp-run trong BackupDirLogic", "mysql-data" not in bd and "www" not in bd and "lamp-run" not in bd),
]
check("doi chieu van ban BackupDirLogic/BackupManager/MainActivity (thieu: %s)" % [n for n, c in conds2 if not c], all(c for _, c in conds2))
big = tempfile.mktemp(suffix=".zip")
try:
    with open(big, "wb") as f:
        blk = os.urandom(1024 * 1024)
        for _ in range(150): f.write(blk)
    rc, out = run([os.path.join(J, "UploadStreamingPort.java"), "stream", big], heap="-Xmx48m")
    check("Upload 150 MB voi heap 48 MB: THANH CONG nho streaming (khong dem tep trong RAM)", rc == 0 and "PASS" in out, out[-300:])
    rc, out = run([os.path.join(J, "UploadStreamingPort.java"), "buffer", big], heap="-Xmx48m")
    check("DOI CHUNG AM: khong dat streaming (ma cu) voi cung heap 48 MB -> OutOfMemoryError", rc == 0 and "OutOfMemoryError" in out, out[-300:])
finally:
    if os.path.exists(big): os.remove(big)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
