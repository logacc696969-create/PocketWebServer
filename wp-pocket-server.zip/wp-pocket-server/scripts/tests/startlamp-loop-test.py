#!/usr/bin/env python3
"""Kiem thu HANH VI cac doan trong vong lap cua start-lamp.sh (HANDOFF.md muc 1ba, PDF DeepSeek muc F1 + F4).

Hai ky thuat nay tung "co chu trong file" nhung KHONG co test nao. Test trich NGUYEN VAN doan lenh tu start-lamp.sh (khong chep lai)
va chay bang `sh` (dash, gan voi mksh cua Android):
  F1 xoay log: nguong 5MB (bien gioi), 9 file log, audit.log giu 2000 dong moi nhat, metrics.csv giu header + 2016 dong, chi chay moi
     1200 vong; va QUAN TRONG: cat log an toan KHI TIEN TRINH DANG GHI - chi dung neu tien trinh mo file bang O_APPEND (>>);
     test cho thay mo bang ">" (khong append) de lai file SPARSE day byte NUL, va kiem tra start-lamp.sh khong con dung ">" cho log bi cat.
  F4 cache warming: tien trinh nen goi GET / that len server, khong chan khoi dong, khong in gi ra.
"""
import os, re, socket, subprocess, sys, tempfile, threading, time, http.server

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
SRC = open(os.environ.get('START_LAMP') or os.path.join(ROOT, 'scripts', 'runtimes', 'templates', 'start-lamp.sh'), encoding='utf-8').read()  # START_LAMP=<ban khac> de doi chung am
passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('PASS:', name)
    else: failed += 1; print('FAIL:', name, ('  -> ' + str(detail)[:250]) if detail != '' else '')

LOGS = ['nginx-access.log', 'nginx-error.log', 'php-error.log', 'mysqld.log', 'php-slow.log', 'php-fpm.log', 'php-fpm-stdout.log', 'nginx-stdout.log', 'nginx-staging-error.log']
tmp = tempfile.mkdtemp(prefix='startlamp-')

# ---- trich khoi rotation: tu dong "if [ $((LOOP_COUNT % 1200)) ..." den ngay truoc khoi Auto-Sleep trong vong lap
m = re.search(r'(  if \[ \$\(\(LOOP_COUNT % 1200\)\) -eq 0 \]; then\n.*?\n  fi\n)\n  if \[ "\$AUTO_SLEEP_ENABLED" = "1" \]', SRC, re.S)
check('trich duoc khoi rotation log tu start-lamp.sh', bool(m))
ROT = m.group(1) if m else ''
listed = re.findall(r'"\$RUNDIR/([a-z\-]+\.log)"', ROT)
check('danh sach log bi cat gom du 9 file (nginx/php/mysql/staging, ke ca stdout)', sorted(set(listed) & set(LOGS)) == sorted(LOGS), sorted(set(LOGS) - set(listed)))

def rotate(rundir, loop=1200):
    script = 'RUNDIR="%s"; LOOP_COUNT=%d\nlog() { echo "LOG: $*"; }\n%s' % (rundir, loop, ROT)
    r = subprocess.run(['sh', '-c', script], capture_output=True, text=True, timeout=60)
    return r.stdout + r.stderr

def mk(rundir, name, size):
    with open(os.path.join(rundir, name), 'wb') as f: f.write(b'x' * size)

if ROT:
    rd = os.path.join(tmp, 'r1'); os.makedirs(rd)
    for lf in LOGS: mk(rd, lf, 5 * 1024 * 1024 + 1)
    out = rotate(rd)
    check('moi log 5MB+1 byte -> bi cat sach (9/9 file ve 0 byte)', all(os.path.getsize(os.path.join(rd, lf)) == 0 for lf in LOGS), {lf: os.path.getsize(os.path.join(rd, lf)) for lf in LOGS if os.path.getsize(os.path.join(rd, lf))})
    check('moi lan cat deu ghi 1 dong nhat ky "Da cat log ..."', out.count('Da cat log') == 9, out[:200])

    rd = os.path.join(tmp, 'r2'); os.makedirs(rd)
    mk(rd, 'nginx-access.log', 5 * 1024 * 1024); mk(rd, 'php-error.log', 1024 * 1024)
    rotate(rd)
    check('bien gioi: dung 5MB (5242880) KHONG bi cat; 1MB khong bi cat', os.path.getsize(rd + '/nginx-access.log') == 5 * 1024 * 1024 and os.path.getsize(rd + '/php-error.log') == 1024 * 1024)

    rd = os.path.join(tmp, 'r3'); os.makedirs(rd); mk(rd, 'nginx-access.log', 6 * 1024 * 1024)
    out = rotate(rd, loop=1199)
    check('LOOP_COUNT=1199 (khong chia het 1200): KHONG lam gi (khong cat)', os.path.getsize(rd + '/nginx-access.log') == 6 * 1024 * 1024 and out.strip() == '')
    rotate(rd, loop=2400)
    check('LOOP_COUNT=2400 (boi cua 1200): cat', os.path.getsize(rd + '/nginx-access.log') == 0)
    rotate(rd, loop=0)  # file trong
    check('file khong ton tai khong gay loi (cac log con lai vang mat)', True)

    # audit log: 6000 dong -> giu 2000 dong moi nhat; 5000 dong thi giu nguyen
    rd = os.path.join(tmp, 'r4'); os.makedirs(rd)
    open(rd + '/admin-audit.log', 'w').write(''.join('line%d\n' % i for i in range(1, 6001)))
    out = rotate(rd); L = open(rd + '/admin-audit.log').read().splitlines()
    check('admin-audit.log 6000 dong -> con 2000 dong MOI NHAT (bang chung bao mat khong bi xoa sach)', len(L) == 2000 and L[0] == 'line4001' and L[-1] == 'line6000', (len(L), L[:1], L[-1:]))
    open(rd + '/admin-audit.log', 'w').write(''.join('line%d\n' % i for i in range(1, 5001)))
    rotate(rd); check('admin-audit.log dung 5000 dong -> giu nguyen', len(open(rd + '/admin-audit.log').read().splitlines()) == 5000)

    # metrics.csv: giu header + 2016 dong
    rd = os.path.join(tmp, 'r5'); os.makedirs(rd)
    open(rd + '/metrics.csv', 'w').write('ts,cpu\n' + ''.join('%d,1\n' % i for i in range(1, 3001)))
    rotate(rd); L = open(rd + '/metrics.csv').read().splitlines()
    check('metrics.csv 3001 dong -> header + 2016 dong gan nhat (7 ngay)', len(L) == 2017 and L[0] == 'ts,cpu' and L[1] == '985,1' and L[-1] == '3000,1', (len(L), L[:2], L[-1:]))
    open(rd + '/metrics.csv', 'w').write('ts,cpu\n' + ''.join('%d,1\n' % i for i in range(1, 2017)))
    rotate(rd); check('metrics.csv 2017 dong (dung nguong) -> giu nguyen', len(open(rd + '/metrics.csv').read().splitlines()) == 2017)

    # ---- cat log KHI TIEN TRINH DANG GHI
    def live(mode):
        rd = os.path.join(tmp, 'live-' + mode); os.makedirs(rd); path = os.path.join(rd, 'nginx-stdout.log')
        f = open(path, 'ab' if mode == 'append' else 'wb')   # 'ab' = O_APPEND (>>)   'wb' = khong O_APPEND (>)
        stop = threading.Event(); fast = threading.Event(); fast.set()
        def writer():  # giai doan lap day: ghi nhanh; sau khi cat: ghi cham (nhu tien trinh that ghi vai dong)
            big = (b'y' * 99 + b'\n') * 1000; one = b'y' * 99 + b'\n'
            while not stop.is_set():
                f.write(big if fast.is_set() else one); f.flush(); time.sleep(0.0005 if fast.is_set() else 0.01)
        th = threading.Thread(target=writer); th.start()
        while os.path.getsize(path) < 5 * 1024 * 1024 + 4096: time.sleep(0.005)
        fast.clear(); time.sleep(0.05)
        rotate(rd)
        time.sleep(0.4); stop.set(); th.join(); f.close()
        data = open(path, 'rb').read()
        return len(data), data.count(b'\x00'), os.stat(path).st_blocks * 512
    size_a, nul_a, _ = live('append')
    check('tien trinh dang ghi voi O_APPEND (>>): sau khi cat file NHO (<1MB) va KHONG co byte NUL', size_a < 1024 * 1024 and nul_a == 0, (size_a, nul_a))
    size_n, nul_n, _ = live('truncate')
    check('DOI CHUNG AM: tien trinh mo bang ">" (khong append): sau khi cat file VAN ~5MB, day byte NUL (sparse) - dung cai bug da sua', size_n > 4 * 1024 * 1024 and nul_n > 1024 * 1024, (size_n, nul_n))

    # ---- start-lamp.sh phai dung ">>" cho MOI log bi cat do tien trinh con mo
    bad = []
    for lf in LOGS:
        for mm in re.finditer(r'(^|[^>\w])(>{1,2})\s*"\$RUNDIR/%s"' % re.escape(lf), SRC, re.M):
            line_start = SRC.rfind('\n', 0, mm.start()) + 1; line = SRC[line_start:SRC.find('\n', mm.start())]
            if mm.group(2) == '>' and not line.lstrip().startswith(':'):   # ": > file" (cat 1 lan) la hop le
                bad.append((lf, line.strip()[:80]))
    check('start-lamp.sh: KHONG con tien trinh nao duoc chuyen huong bang ">" (khong append) vao log nam trong danh sach bi cat', not bad, bad)

# ---- F4: cache warming
mw = re.search(r'(\(\n  sleep 1 # nginx/php-fpm vua fork.*?\n\) &\n)', SRC, re.S)
check('trich duoc khoi cache warming tu start-lamp.sh', bool(mw))
if mw:
    hits = []
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self): hits.append(self.path); self.send_response(200); self.end_headers(); self.wfile.write(b'ok')
        def log_message(self, *a): pass
    srv = http.server.HTTPServer(('127.0.0.1', 0), H); port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    bin_ = os.path.join(tmp, 'bin'); os.makedirs(bin_); os.symlink(subprocess.run(['which', 'php'], capture_output=True, text=True).stdout.strip(), os.path.join(bin_, 'libphpcli.so'))
    rd = os.path.join(tmp, 'warm'); os.makedirs(rd); open(rd + '/php.ini', 'w').write('allow_url_fopen=On\n')
    script = 'BIN="%s"; RUNDIR="%s"; PORT=%d\nSTART=$(date +%%s%%N)\n%s\nEND=$(date +%%s%%N)\necho "BLOCKED_MS=$(( (END-START)/1000000 ))"\nwait\n' % (bin_, rd, port, mw.group(1))
    t0 = time.time(); r = subprocess.run(['sh', '-c', script], capture_output=True, text=True, timeout=30); total = time.time() - t0
    blocked = int(re.search(r'BLOCKED_MS=(\d+)', r.stdout).group(1))
    check('cache warming: tien trinh nen goi GET / that len server (1 request)', hits == ['/'], hits)
    check('cache warming KHONG chan khoi dong: khoi lenh tra ve ngay (<300ms) du ben trong co sleep 1', blocked < 300 and total >= 1.0, (blocked, round(total, 2)))
    check('cache warming im lang (khong in gi ra stdout/stderr)', r.stdout.replace('BLOCKED_MS=%d' % blocked, '').strip() == '' and r.stderr.strip() == '', (r.stdout, r.stderr))
    srv.shutdown()

print('\nTONG KET: pass=%d fail=%d' % (passed, failed))
sys.exit(1 if failed else 0)
