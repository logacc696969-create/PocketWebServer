#!/usr/bin/env python3
"""Kiem thu BAO MAT + fuzz cac trang _admin/ bang PHP THAT (php -S), khong mock.
Xem HANDOFF.md muc 1av. Chay: python3 scripts/tests/admin-security-test.py
Can: php (CLI), python3. Khong can mang, MariaDB, nginx, Android.

Cach dung moi truong: dung dung cau truc nhu may that (copy cac admin-*.php
thanh _admin/*.php theo scripts/lib/admin_tools.sh, APP_HOME + lamp-run/).
Chi co 1 thu "gia" duy nhat: file prepend dat $_SERVER['REMOTE_ADDR'] theo
header X-Test-Ip (vi tren 127.0.0.1 thi auth.php luon tu choi: khong phai LAN).
Moi kiem tra "khong co tac dung phu" di kem DOI CHUNG DUONG (cung hanh dong
CO token thi PHAI co tac dung) - neu khong, ket qua "khong co gi xay ra" co the
chi do hanh dong von khong lam duoc gi trong sandbox.

Neu bien moi truong ADMIN_TEST_OUT duoc dat: ghi admin-audit.log (sau phan thu
khoa IP) + contract.json de run-admin-tests.sh doi chieu voi bo phan tich Kotlin.
"""
import glob
import http.client
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.normpath(os.path.join(HERE, '..'))
TPL = os.path.join(SCRIPTS, 'runtimes', 'templates')
PASSWORD = 'Tr0ub4dor-test-1234'

# (ten file trong _admin/, template nguon) - khop scripts/lib/admin_tools.sh
PAGES = [
    ('auth', 'admin-auth.php'), ('totp-lib', 'admin-totp-lib.php'), ('2fa', 'admin-2fa.php'),
    ('logs', 'admin-logs.php'), ('info', 'admin-info.php'), ('install-wp', 'admin-install-wp.php'),
    ('maintenance', 'admin-maintenance.php'), ('metrics', 'admin-metrics.php'),
    ('analytics', 'admin-analytics.php'), ('wpcli', 'admin-wpcli.php'),
    ('staging', 'admin-staging.php'), ('core-rollback', 'admin-core-rollback.php'),
    ('safe-mode', 'admin-safe-mode.php'), ('sessions', 'admin-sessions.php'), ('health', 'admin-health.php'),
    ('protect', 'admin-protect.php'), ('security', 'admin-security.php'),
    ('security-lib', 'security-guard.php'), ('security-scan-lib', 'security-scan.php'), ('security-vuln-lib', 'security-vuln.php'),
]
# totp-lib.php chi la thu vien ham (khong require auth.php), auth.php la chinh cong dang nhap
LIB_ONLY = {'totp-lib', 'security-lib', 'security-scan-lib', 'security-vuln-lib'}
FATAL_RE = re.compile(r'Fatal error|Uncaught|Parse error|Stack trace')
WARN_RE = re.compile(r'(Warning|Notice|Deprecated): ')

PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:300]) if detail else ''))


class Client:
    def __init__(self, port, ip):
        self.port, self.ip = port, ip
        self.jar = {}  # nhieu cookie: PHPSESSID (cong) + wpp_db / wpp_files (phien rieng cua Adminer/TFM, muc 1aw)

    @property
    def cookie(self):
        v = self.jar.get('PHPSESSID')
        return ('PHPSESSID=%s' % v) if v else None

    def req(self, method, path, data=None, ip=None, headers=None):
        h = {'X-Test-Ip': self.ip if ip is None else ip}
        if self.jar:
            h['Cookie'] = '; '.join('%s=%s' % kv for kv in self.jar.items())
        body = None
        if data is not None:
            body = urllib.parse.urlencode(data, doseq=True)
            h['Content-Type'] = 'application/x-www-form-urlencoded'
        h.update(headers or {})
        c = http.client.HTTPConnection('127.0.0.1', self.port, timeout=40)
        c.request(method, path, body=body, headers=h)
        r = c.getresponse()
        text = r.read().decode('utf-8', 'replace')
        for sc in (r.msg.get_all('Set-Cookie') or []):
            m = re.match(r'([^=;\s]+)=([^;]*)', sc)
            if m:
                if m.group(2) in ('', 'deleted'):
                    self.jar.pop(m.group(1), None)
                else:
                    self.jar[m.group(1)] = m.group(2)
        status, loc = r.status, r.getheader('Location')
        c.close()
        return status, text, loc

    def login(self):
        self.req('GET', '/_admin/index.php')
        sc, _, _ = self.req('POST', '/_admin/index.php', {'admin_password': PASSWORD})
        return sc == 302

    def token(self, page='maintenance'):
        _, body, _ = self.req('GET', '/_admin/%s.php' % page)
        m = re.search(r'name="csrf_token" value="([0-9a-f]{64})"', body)
        return m.group(1) if m else None


def snapshot(roots, exclude=('admin-audit.log', 'admin-login-attempts.json')):
    snap = {}
    for root in roots:
        for d, dirs, files in os.walk(root):
            for n in dirs:
                snap[os.path.join(d, n)] = 'dir'
            for n in files:
                if n in exclude:
                    continue
                p = os.path.join(d, n)
                st = os.stat(p)
                snap[p] = (st.st_size, st.st_mtime_ns)
    return snap


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def build_tree(tmp):
    app = os.path.join(tmp, 'app_home')
    run = os.path.join(app, 'lamp-run')
    www = os.path.join(tmp, 'www')
    adm = os.path.join(www, '_admin')
    for d in (run, adm, os.path.join(tmp, 'sess'), os.path.join(www, 'wp-content', 'plugins')):
        os.makedirs(d)
    with open(os.path.join(www, 'wp-content', 'plugins', 'hello.php'), 'w') as f:
        f.write('<?php // plugin gia\n')
    with open(os.path.join(www, 'wp-config.php'), 'w') as f:  # safe-mode chi chay voi site WordPress
        f.write('<?php // wp-config gia\n')
    ext = os.path.join(tmp, 'ext')  # EXT_DIR gia cho wpcli.php: libphpcli.so ghi lai moi lan duoc goi
    os.makedirs(ext)
    with open(os.path.join(ext, 'libphpcli.so'), 'w') as f:
        f.write('#!/bin/sh\necho "CALL: $*" >> "$(dirname "$0")/calls.log"\necho FAKE-WPCLI-OUTPUT\n')
    os.chmod(os.path.join(ext, 'libphpcli.so'), 0o755)
    open(os.path.join(ext, 'wp-cli.phar'), 'w').write('fake')
    with open(os.path.join(app, 'admin-password.txt'), 'w') as f:
        f.write(PASSWORD + '\n')
    for name, src in PAGES:
        shutil.copy(os.path.join(TPL, src), os.path.join(adm, name + '.php'))
    sh = open(os.path.join(SCRIPTS, 'lib', 'admin_tools.sh'), encoding='utf-8').read()
    m = re.search(r"index\.php\" <<'PHP'\n(.*?)\nPHP\n", sh, re.S)
    with open(os.path.join(adm, 'index.php'), 'w', encoding='utf-8') as f:
        f.write(m.group(1))
    with open(os.path.join(tmp, 'spoof.php'), 'w') as f:
        f.write("<?php if (isset($_SERVER['HTTP_X_TEST_IP'])) { $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_X_TEST_IP']; }\n")
    return app, run, www, adm


def post_fields(adm):
    """Tu cac trang that: action nao + truong POST nao (de fuzz co co so)."""
    per_page = {}
    for name, _ in PAGES:
        src = open(os.path.join(adm, name + '.php'), encoding='utf-8').read()
        if '$_POST' not in src and "=== 'POST'" not in src:
            continue
        actions = sorted(set(re.findall(r"\$action\s*===\s*'([a-z_]+)'", src)))
        fields = sorted(set(re.findall(r"\$_POST\['([A-Za-z0-9_]+)'\]", src)) - {'csrf_token', 'action', 'admin_password', 'totp_code'})
        per_page[name] = (actions or ['x'], fields)
    return per_page



HARDEN_KEYS = ('allow_url_include', 'enable_dl', 'zend.exception_ignore_args', 'session.use_strict_mode', 'session.use_only_cookies',
               'session.use_trans_sid', 'session.cookie_httponly', 'session.cookie_samesite')


def harden_flags():
    """Cac dong gia co bao mat THAT trong php.ini.template (HANDOFF.md muc 1br) -> danh sach '-d k=v': test chay voi dung cau hinh nay,
    khong phai mac dinh PHP (neu khong, 'session.use_strict_mode=1' co the lam vo dang nhap ma khong ai biet)."""
    flags = {}
    for line in open(os.path.join(TPL, 'php.ini.template'), encoding='utf-8'):
        m = re.match(r'^\s*([a-z_.]+)\s*=\s*(\S+)\s*$', line)
        if m and m.group(1) in HARDEN_KEYS:
            flags[m.group(1)] = m.group(2)
    return flags


def start_php_server(port, www, tmp, env, logf, workers=0):
    cmd = ['php', '-S', '127.0.0.1:%d' % port, '-t', www,
           '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
           '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'),
           '-d', 'display_errors=1', '-d', 'error_reporting=E_ALL']
    for k, v in harden_flags().items():
        cmd += ['-d', '%s=%s' % (k, v)]
    e = dict(env)
    if workers:
        e['PHP_CLI_SERVER_WORKERS'] = str(workers)   # php -S mac dinh xu ly TUAN TU: muon thu race that phai co nhieu worker
    srv = subprocess.Popen(cmd, env=e, stdout=logf, stderr=logf)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.2).close()
            break
        except OSError:
            time.sleep(0.1)
    return srv


def main():
    tmp = tempfile.mkdtemp(prefix='admintest-')
    app, run, www, adm = build_tree(tmp)
    port = free_port()
    env = dict(os.environ, APP_HOME=app, EXT_DIR=os.path.join(tmp, 'ext'))
    logf = open(os.path.join(tmp, 'php-server.log'), 'w')
    srv = start_php_server(port, www, tmp, env, logf)
    try:
        for _ in range(100):
            try:
                socket.create_connection(('127.0.0.1', port), timeout=0.2).close()
                break
            except OSError:
                time.sleep(0.1)
        run_tests(port, app, run, www, adm, tmp)
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        logf.close()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


def run_tests(port, app, run, www, adm, tmp):
    audit = os.path.join(run, 'admin-audit.log')
    lockout = os.path.join(run, 'admin-login-attempts.json')
    page_names = [n for n, _ in PAGES] + ['index']

    # ---------- 1. Gioi han IP LAN ----------
    print('== 1. gioi han IP LAN (moi trang) ==')
    bad_ips = ['8.8.8.8', '127.0.0.1', '172.32.0.1', '192.169.1.1', '::1', '999.1.1.1', '']
    good_ips = ['10.1.2.3', '172.16.0.1', '172.31.255.255', '192.168.0.1']
    leaks, wrongly_blocked = [], []
    for n in page_names:
        if n in LIB_ONLY:
            continue
        for ip in bad_ips:
            sc, body, _ = Client(port, ip).req('GET', '/_admin/%s.php' % n)
            if sc != 403 or 'admin_password' in body:
                leaks.append((n, ip, sc))
        for ip in good_ips:
            sc, body, _ = Client(port, ip).req('GET', '/_admin/%s.php' % n)
            if sc != 200 or 'admin_password' not in body:
                wrongly_blocked.append((n, ip, sc))
    check('IP ngoai LAN/khong hop le bi 403 o MOI trang', not leaks, leaks[:3])
    check('IP LAN hop le (10/8, 172.16/12, 192.168/16) thay form dang nhap o MOI trang', not wrongly_blocked, wrongly_blocked[:3])

    # ---------- 2. Chua dang nhap: khong lo noi dung, khong tac dung phu ----------
    print('== 2. chua dang nhap ==')
    anon = Client(port, '10.0.0.9')
    exposed = []
    for n in page_names:
        if n in LIB_ONLY:
            continue
        sc, body, _ = anon.req('GET', '/_admin/%s.php' % n)
        if 'admin_password' not in body or FATAL_RE.search(body):
            exposed.append((n, sc))
    check('GET chua dang nhap chi tra ve form dang nhap (moi trang)', not exposed, exposed[:3])
    sc, body, _ = anon.req('GET', '/_admin/totp-lib.php')
    check('totp-lib.php truy cap truc tiep: khong loi, khong lo thong tin', not FATAL_RE.search(body) and len(body.strip()) == 0, body[:100])

    pf = post_fields(adm)
    before = snapshot([app, www])
    for n, (actions, fields) in pf.items():
        for a in actions:
            data = {'action': a, 'csrf_token': 'x' * 64}
            data.update({f: '1' for f in fields})
            anon.req('POST', '/_admin/%s.php' % n, data)
    after = snapshot([app, www])
    check('POST hang loat chua dang nhap (moi action, ke ca csrf gia): khong doi file nao', before == after,
          sorted(set(before) ^ set(after))[:3])

    # ---------- 3. Chong do mat khau + hop dong audit voi Kotlin ----------
    print('== 3. khoa IP + audit log ==')
    a = Client(port, '10.1.1.1')
    wrong_ok = True
    for i in range(1, 6):
        sc, body, _ = a.req('POST', '/_admin/index.php', {'admin_password': 'sai%d' % i})
        if sc != 200 or 'Sai mat khau' not in body:
            wrong_ok = False
    check('5 lan sai mat khau deu bi tu choi (200 + thong bao sai)', wrong_ok)
    sc, body, _ = a.req('POST', '/_admin/index.php', {'admin_password': PASSWORD})
    check('lan thu 6 DUNG mat khau van bi chan 429 (dang bi khoa)', sc == 429, sc)
    sc, _, _ = a.req('GET', '/_admin/logs.php')
    check('IP bi khoa cung khong xem duoc trang khac (429)', sc == 429, sc)
    b = Client(port, '10.1.1.2')
    check('IP khac KHONG bi anh huong, dang nhap duoc', b.login())
    log_text = open(audit, encoding='utf-8').read() if os.path.exists(audit) else ''
    n_wrong = len(re.findall(r'ip=10\.1\.1\.1 dang nhap sai \(\d/5\)', log_text))
    n_lock = len(re.findall(r'ip=10\.1\.1\.1 BI KHOA TAM', log_text))
    check('audit ghi 4 dong "dang nhap sai" + 1 dong "BI KHOA TAM"', n_wrong == 4 and n_lock == 1, log_text)
    check('audit ghi dang nhap THANH CONG cua IP khac', re.search(r'ip=10\.1\.1\.2 dang nhap THANH CONG', log_text) is not None)
    out_dir = os.environ.get('ADMIN_TEST_OUT')
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
        shutil.copy(audit, os.path.join(out_dir, 'admin-audit.log'))
        json.dump({'failures': n_wrong, 'lockouts': n_lock}, open(os.path.join(out_dir, 'contract.json'), 'w'))
    data = json.load(open(lockout))
    data['10.1.1.1']['locked_until'] = int(time.time()) - 1
    json.dump(data, open(lockout, 'w'))
    check('het thoi gian khoa -> dang nhap lai duoc', a.login())

    # ---------- 3b. Host header (chong DNS rebinding, HANDOFF.md muc 1br) ----------
    print('== 3b. Host header (DNS rebinding) ==')
    hc = Client(port, '10.8.8.8')
    ok_hosts = ['10.1.2.3', '192.168.1.5:8080', '172.16.0.9:80', 'localhost', 'localhost:8080', 'phone', 'phone.local', 'my-phone.lan:8080',
                'pocket.home.arpa', '[::1]:8080', '[fe80::1]', '127.0.0.1:%d' % port, 'PHONE.Local']
    bad_hosts = ['evil.example.com', 'evil.com:80', '192.168.1.5.evil.com', 'phone.local.evil.com', 'evil.example.com.', 'attacker.io:8080',
                 '10.0.0.1:99999x', '[evil]', '[::1', 'a' * 300, 'ex ample.com', 'phone.example.org']
    wrong = []
    for h in ok_hosts:
        sc, body, _ = hc.req('GET', '/_admin/index.php', headers={'Host': h})
        if sc != 200 or 'admin_password' not in body:
            wrong.append((h, sc))
    check('Host hop le (IP, localhost, ten 1 nhan, .local/.lan/.home.arpa, [IPv6]) van thay form dang nhap', not wrong, wrong[:4])
    leak = []
    for h in bad_hosts:
        sc, body, _ = hc.req('GET', '/_admin/index.php', headers={'Host': h})
        if sc != 400 or 'admin_password' in body:
            leak.append((h[:30], sc))
    check('Host la / ten mien cong khai / gia dang IP (DNS rebinding) bi 400, KHONG hien form', not leak, leak[:4])
    sc_r, _, _ = hc.req('POST', '/_admin/index.php', {'admin_password': PASSWORD}, headers={'Host': 'evil.example.com'})
    check('DOI CHUNG: dung mat khau nhung Host la van bi 400 (khong dang nhap duoc qua ten mien gia)', sc_r == 400, sc_r)
    sc_r, _, _ = hc.req('POST', '/_admin/index.php', {'admin_password': PASSWORD}, headers={'Host': '10.1.2.3:8080'})
    check('DOI CHUNG DUONG: cung mat khau + Host hop le thi dang nhap duoc', sc_r == 302, sc_r)
    check('audit ghi "chan Host la" (khong ghi ky tu dieu khien)', 'chan Host la: evil.example.com' in open(audit, encoding='utf-8').read())
    extra = os.path.join(run, 'admin-allowed-hosts.txt')
    open(extra, 'w').write('# ten rieng cua toi\nphone.example.org\n')
    sc, body, _ = Client(port, '10.8.8.9').req('GET', '/_admin/index.php', headers={'Host': 'phone.example.org'})
    check('ten chu may TU KHAI BAO trong admin-allowed-hosts.txt duoc chap nhan', sc == 200 and 'admin_password' in body, sc)
    sc, _, _ = Client(port, '10.8.8.9').req('GET', '/_admin/index.php', headers={'Host': 'evil.example.com'})
    check('... nhung ten khac van bi chan', sc == 400, sc)
    os.remove(extra)

    # ---------- 3c. Do mat khau SONG SONG khong duoc vuot qua 5 lan (race that, nhieu worker) ----------
    print('== 3c. do mat khau song song (race) ==')
    import threading
    race_port = free_port()
    race_env = dict(os.environ, APP_HOME=app, EXT_DIR=os.path.join(tmp, 'ext'))
    race_log = open(os.path.join(tmp, 'php-race.log'), 'w')
    race_srv = start_php_server(race_port, www, tmp, race_env, race_log, workers=12)
    try:
        results = []
        lock = threading.Lock()
        guesses = ['sai-%d' % i for i in range(59)] + [PASSWORD]      # mat khau DUNG nam cuoi 60 lan thu: tran vet = thang

        def worker(pw):
            cl = Client(race_port, '10.7.7.7')
            try:
                sc, body, _ = cl.req('POST', '/_admin/index.php', {'admin_password': pw})
            except Exception as ex:   # noqa: BLE001 - mat ket noi cung la ket qua (khong phai dang nhap duoc)
                sc, body = -1, str(ex)
            with lock:
                results.append((pw, sc, body))

        ts = [threading.Thread(target=worker, args=(g,)) for g in guesses]
        for t in ts: t.start()
        for t in ts: t.join()
        answered = [r for r in results if r[1] == 200 and 'Sai mat khau' in r[2]]
        succeeded = [r for r in results if r[1] == 302]
        locked_resp = [r for r in results if r[1] == 429]
        log_text = open(audit, encoding='utf-8').read()
        n_locks = len(re.findall(r'ip=10\.7\.7\.7 BI KHOA TAM', log_text))
        n_wrongs = len(re.findall(r'ip=10\.7\.7\.7 dang nhap sai', log_text))
        check('60 request SONG SONG cung 1 IP: toi da 5 lan duoc SO mat khau (khong phai 60)',
              len(answered) + len(succeeded) <= 5 and len(answered) + len(succeeded) + len(locked_resp) == 60,
              (len(answered), len(succeeded), len(locked_resp), len(results)))
        check('... phan con lai bi 429 (khoa)', len(locked_resp) >= 55, len(locked_resp))
        check('audit: dung 1 dong BI KHOA TAM va khong qua 4 dong "dang nhap sai" cho dot nay (khong ghi trung)', n_locks <= 1 and n_wrongs <= 4, (n_locks, n_wrongs))
        data_race = json.load(open(lockout))
        check('bo dem khoa KHONG bi mat/ghi de (file hop le JSON, IP nay co muc)', '10.7.7.7' in data_race, list(data_race)[:5])
        check('DOI CHUNG: IP khac (dang nhap dung 1 request) van vao duoc trong luc IP kia bi khoa', Client(race_port, '10.7.7.8').login())
    finally:
        race_srv.terminate()
        try:
            race_srv.wait(timeout=5)
        except Exception:
            race_srv.kill()
        race_log.close()

    # ---------- 3d. Tep php.ini.template co dung cac dong gia co ma test dang nap ----------
    flags = harden_flags()
    check('php.ini.template co du %d dong gia co (session strict/httponly/samesite, allow_url_include, enable_dl...)' % len(HARDEN_KEYS),
          set(flags) == set(HARDEN_KEYS) and flags.get('allow_url_include') == '0' and flags.get('session.use_strict_mode') == '1', flags)

    # ---------- 4. Dang nhap: session fixation, GET moi trang ----------
    print('== 4. da dang nhap ==')
    c = Client(port, '10.2.2.2')
    c.req('GET', '/_admin/index.php')
    pre_cookie = c.cookie
    check('dang nhap dung mat khau', c.req('POST', '/_admin/index.php', {'admin_password': PASSWORD})[0] == 302)
    check('session id DOI sau khi dang nhap (chong session fixation)', c.cookie and c.cookie != pre_cookie, (pre_cookie, c.cookie))
    fatals, warns = [], []
    for n in page_names:
        if n in LIB_ONLY:
            continue
        sc, body, _ = c.req('GET', '/_admin/%s.php' % n)
        if FATAL_RE.search(body) or sc >= 500:
            m_ = FATAL_RE.search(body)
            fatals.append((n, sc, m_.group(0) if m_ else ''))
        for w in WARN_RE.finditer(body):
            warns.append((n, body[w.start():w.start() + 90].replace('\n', ' ')))
    check('GET moi trang sau dang nhap: khong Fatal/Uncaught/5xx', not fatals, fatals[:3])
    if warns:
        print('INFO: %d canh bao PHP (Warning/Notice/Deprecated) do thieu moi truong trong sandbox, vd: %s' % (len(warns), warns[0]))

    # ---------- 5. CSRF (co doi chung duong) ----------
    print('== 5. CSRF ==')
    flag = os.path.join(run, 'maintenance-mode')
    tok = c.token('maintenance')
    check('trang co cap token CSRF 64 hex', tok is not None)
    d = Client(port, '10.3.3.3')
    d.login()
    tok_other = d.token('maintenance')
    base = snapshot([app, www])
    st1, _, _ = c.req('POST', '/_admin/maintenance.php', {'action': 'enable'})
    st2, _, _ = c.req('POST', '/_admin/maintenance.php', {'action': 'enable', 'csrf_token': 'a' * 64})
    st3, _, _ = c.req('POST', '/_admin/maintenance.php', {'action': 'enable', 'csrf_token': tok_other})
    check('maintenance: thieu token / token sai / token cua PHIEN KHAC -> khong bat bao tri',
          not os.path.exists(flag), (st1, st2, st3))
    c.req('POST', '/_admin/maintenance.php', {'action': 'enable', 'csrf_token': tok})
    check('DOI CHUNG DUONG: dung token thi bat bao tri duoc (chung to test co kha nang phat hien)', os.path.exists(flag))
    c.req('POST', '/_admin/maintenance.php', {'action': 'disable', 'csrf_token': tok})
    check('dung token de tat bao tri', not os.path.exists(flag))

    plugins = os.path.join(www, 'wp-content', 'plugins')
    tok_sm = c.token('safe-mode')
    c.req('POST', '/_admin/safe-mode.php', {'action': 'disable_all'})
    c.req('POST', '/_admin/safe-mode.php', {'action': 'disable_all', 'csrf_token': 'b' * 64})
    check('safe-mode: thieu/sai token -> plugin KHONG bi vo hieu hoa',
          os.path.isfile(os.path.join(plugins, 'hello.php')) and not glob.glob(plugins + '.disabled-*'))
    c.req('POST', '/_admin/safe-mode.php', {'action': 'disable_all', 'csrf_token': tok_sm})
    disabled = glob.glob(plugins + '.disabled-*')
    check('DOI CHUNG DUONG: dung token thi vo hieu hoa plugin duoc', len(disabled) == 1, disabled)
    if disabled:
        for evil in ({'restore_dir[]': 'x'}, {'restore_dir[a]': 'b'}):
            sc_, body_, _ = c.req('POST', '/_admin/safe-mode.php', dict({'action': 'restore', 'csrf_token': tok_sm}, **evil))
            check('safe-mode restore voi %s: khong Fatal' % list(evil)[0], not FATAL_RE.search(body_), body_[:150])
        c.req('POST', '/_admin/safe-mode.php', {'action': 'restore', 'restore_dir': '../../../etc', 'csrf_token': tok_sm})
        check('safe-mode restore: restore_dir kieu path traversal bi tu choi', len(glob.glob(plugins + '.disabled-*')) == 1)
        c.req('POST', '/_admin/safe-mode.php', {'action': 'restore', 'restore_dir': os.path.basename(disabled[0]), 'csrf_token': tok_sm})
        check('restore hop le khoi phuc duoc plugin', os.path.isfile(os.path.join(plugins, 'hello.php')))

    before = snapshot([app, www])
    for n, (actions, fields) in post_fields(adm).items():
        for a_ in actions:
            for bad in (None, 'c' * 64, ''):
                data = {'action': a_}
                if bad is not None:
                    data['csrf_token'] = bad
                data.update({f: '1' for f in fields})
                c.req('POST', '/_admin/%s.php' % n, data)
    after = snapshot([app, www])
    check('POST khong token/token sai/rong vao MOI trang & action da dang nhap: khong doi file nao',
          before == after, sorted(set(before) ^ set(after))[:3])

    # ---------- 6. Fuzz tham so GET ----------
    print('== 6. fuzz tham so GET ==')
    bad_get = []
    logs_cases = ['', '?log=../../../../etc/passwd', '?log=nginx-loi%00', '?log[]=a', '?log=' + 'A' * 5000,
                  '?lines=-5', '?lines=999999', '?lines=abc', '?lines[]=1', '?lines=1e9', '?lines=0x1A',
                  '?log=nginx-loi&lines=%00', '?log=start-lamp&lines=10', '?log=dang-nhap-quantri&lines=10']
    for q in logs_cases:
        sc, body, _ = c.req('GET', '/_admin/logs.php' + q)
        if sc != 200 or FATAL_RE.search(body):
            bad_get.append(('logs' + q[:40], sc))
    check('logs.php: moi tham so GET la (path traversal, mang, so am/rat lon, null byte) deu an toan', not bad_get, bad_get[:3])
    check('logs.php: khong lo noi dung /etc/passwd', 'root:x:0:0' not in c.req('GET', '/_admin/logs.php?log=../../../../etc/passwd')[1])
    bad_m = []
    for q in ['?range=24h', '?range=7d', '?range=zzz', '?range[]=x', '?range[a]=b', '?range=' + 'Z' * 3000, '?range=%00']:
        sc, body, _ = c.req('GET', '/_admin/metrics.php' + q)
        m_ = FATAL_RE.search(body)
        if sc != 200 or m_:
            bad_m.append((q[:30], sc, m_.group(0) if m_ else ''))
    check('metrics.php: ?range=... (ke ca mang range[]=) khong gay loi PHP', not bad_m, bad_m[:3])

    # ---------- 7. XSS luu tru qua log (URL do ke tan cong dieu khien) ----------
    print('== 7. XSS ==')
    evil_path = '/<script>alert(1)</script>'
    with open(os.path.join(run, 'nginx-access.log'), 'w', encoding='utf-8') as f:
        f.write('6.6.6.6 - - [06/Oct/2026:10:00:00 +0700] "GET %s HTTP/1.1" 404 12 "-" "<img src=x onerror=alert(2)>" rt=0.010\n' % evil_path)
        f.write('<svg onload=alert(3)> - - [06/Oct/2026:10:00:01 +0700] "GET /ok HTTP/1.1" 200 12 "-" "UA" rt=0.010\n')
    for page in ('logs.php?log=nginx-truycap', 'analytics.php'):
        _, body, _ = c.req('GET', '/_admin/' + page)
        raw_xss = ('<script>alert(1)</script>' in body or '<img src=x onerror' in body or '<svg onload' in body)
        check('%s: thoat HTML dung (khong con <script>/<img onerror>/<svg onload> thuan)' % page.split('?')[0],
              not raw_xss, body[:200])
    _, body, _ = c.req('GET', '/_admin/analytics.php')
    check('analytics.php: duong dan doc hai van hien ra duoi dang ma hoa (&lt;script&gt;)', '&lt;script&gt;' in body, body[-300:])

    # ---------- 7b. 2FA dau-cuoi voi ma TOTP tinh DOC LAP (RFC 6238) ----------
    print('== 7b. 2FA (TOTP) ==')
    import base64, hashlib, hmac, struct

    def totp(secret_b32, ts=None, step=30, digits=6):
        key = base64.b32decode(secret_b32.upper() + '=' * (-len(secret_b32) % 8))
        counter = int((time.time() if ts is None else ts) // step)
        h = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
        o = h[-1] & 0x0F
        return '%0*d' % (digits, (struct.unpack('>I', h[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** digits))

    rfc_ok = totp(base64.b32encode(b'12345678901234567890').decode(), ts=59, digits=8) == '94287082'
    check('(kiem tra bo tinh TOTP cua test) khop vector RFC 6238 (T=59 -> 94287082)', rfc_ok)
    flag2fa = os.path.join(app, 'admin-totp-enabled.flag')
    e = Client(port, '10.4.4.4')
    e.login()
    tk = e.token('2fa')
    check('trang 2fa.php hien duoc cho nguoi da dang nhap (khong Fatal)', tk is not None)
    e.req('POST', '/_admin/2fa.php', {'action': 'generate', 'csrf_token': tk})
    _, page, _ = e.req('GET', '/_admin/2fa.php')
    m = re.search(r'<code>([A-Z2-7]{16})</code>', page)  # trang hien secret de nhap tay (khong sinh QR)
    secret = m.group(1) if m else ''
    check('sinh secret base32 16 ky tu hien tren trang', len(secret) == 16, secret)
    e.req('POST', '/_admin/2fa.php', {'action': 'confirm', 'code': '000000', 'csrf_token': tk})
    check('ma xac nhan SAI -> 2FA CHUA bat (an toan chong tu khoa minh)', not os.path.exists(flag2fa))
    if secret:
        e.req('POST', '/_admin/2fa.php', {'action': 'confirm', 'code': totp(secret), 'csrf_token': tk})
    check('ma TOTP DUNG (tinh doc lap bang Python) -> bat 2FA', os.path.exists(flag2fa))

    f = Client(port, '10.5.5.5')
    f.req('GET', '/_admin/index.php')
    sc, _, _ = f.req('POST', '/_admin/index.php', {'admin_password': PASSWORD})
    sc_info, body_info, _ = f.req('GET', '/_admin/info.php')
    check('2FA bat: dung mat khau CHUA du - van bi chan, doi ma 6 so', 'totp_code' in body_info and 'phpinfo' not in body_info.lower() and 'PHP Version' not in body_info, body_info[:120])
    f.req('POST', '/_admin/index.php', {'totp_code': totp(secret, ts=time.time() - 60)})
    check('ma TOTP cu 2 buoc (60s) bi tu choi', 'totp_code' in f.req('GET', '/_admin/info.php')[1])
    f.req('POST', '/_admin/index.php', {'totp_code': totp(secret, ts=time.time() + 30)})
    check('ma TOTP lech +1 buoc (30s) van duoc chap nhan (cua so +-1)', 'totp_code' not in f.req('GET', '/_admin/info.php')[1])

    # Chan dung lai ma TOTP (RFC 6238 muc 5.2): ma vua duoc 'f' dung o tren (buoc +1) KHONG duoc dung lai bang nguoi khac
    h2 = Client(port, '10.5.5.6')
    h2.req('GET', '/_admin/index.php')
    h2.req('POST', '/_admin/index.php', {'admin_password': PASSWORD})
    h2.req('POST', '/_admin/index.php', {'totp_code': totp(secret, ts=time.time() + 30)})
    check('REPLAY: cung ma TOTP vua dung o phien khac bi TU CHOI (ke ca trong cua so hop le)', 'totp_code' in h2.req('GET', '/_admin/info.php')[1])
    h2.req('POST', '/_admin/index.php', {'totp_code': totp(secret)})
    check('REPLAY: ma cua buoc CU HON buoc da dung cung bi tu choi', 'totp_code' in h2.req('GET', '/_admin/info.php')[1])
    check('audit ghi su kien replay (bat dau bang "sai ma 2FA" de bo canh bao van dem dung)',
          re.search(r'ip=10\.5\.5\.6 sai ma 2FA \(\d/5\) - ma da duoc dung roi \(replay\)', open(audit, encoding='utf-8').read()) is not None)
    last_step = os.path.join(run, 'admin-totp-last-step.txt')
    check('co ghi buoc TOTP da dung (admin-totp-last-step.txt)', os.path.isfile(last_step) and open(last_step).read().strip().isdigit())
    os.remove(last_step)
    h2.req('POST', '/_admin/index.php', {'totp_code': totp(secret, ts=time.time() + 30)})
    check('DOI CHUNG DUONG: xoa dau vet buoc da dung thi CUNG ma do duoc chap nhan (chung to tu choi o tren la do chong replay, khong phai nguyen nhan khac)',
          'totp_code' not in h2.req('GET', '/_admin/info.php')[1])

    g = Client(port, '10.6.6.6')
    g.req('GET', '/_admin/index.php')
    g.req('POST', '/_admin/index.php', {'admin_password': PASSWORD})
    for _i in range(5):
        g.req('POST', '/_admin/index.php', {'totp_code': '%06d' % (_i + 111111)})
    sc, _, _ = g.req('POST', '/_admin/index.php', {'totp_code': totp(secret)})
    check('5 lan sai ma 2FA -> khoa IP: ma DUNG o lan thu 6 van bi 429', sc == 429, sc)
    check('audit ghi "sai ma 2FA" va "BI KHOA TAM (sai ma 2FA"',
          re.search(r'ip=10\.6\.6\.6 sai ma 2FA', open(audit, encoding='utf-8').read()) is not None
          and 'BI KHOA TAM (sai ma 2FA' in open(audit, encoding='utf-8').read())

    tk_off = e.token('2fa')
    e.req('POST', '/_admin/2fa.php', {'action': 'disable'})
    check('tat 2FA khong token bi tu choi (2FA van bat)', os.path.exists(flag2fa))
    e.req('POST', '/_admin/2fa.php', {'action': 'disable', 'csrf_token': tk_off})
    check('tat 2FA co token -> go flag', not os.path.exists(flag2fa))

    # ---------- 7c. wpcli.php: chen lenh voi TOKEN HOP LE ----------
    print('== 7c. wpcli: chen lenh shell (token hop le) ==')
    ext = os.path.join(tmp, 'ext')
    calls = os.path.join(ext, 'calls.log')
    pwn = os.path.join(tmp, 'PWNED')
    tkw = c.token('wpcli')
    check('wpcli.php co EXT_DIR gia: trang hien form (khong bao thieu)', tkw is not None)

    def run_cmd(cmd):
        if os.path.exists(calls):
            os.remove(calls)
        _, body, _ = c.req('POST', '/_admin/wpcli.php', {'cmd': cmd, 'csrf_token': tkw})
        return body, (open(calls).read() if os.path.exists(calls) else '')

    body, called = run_cmd('plugin list')
    check('DOI CHUNG DUONG: lenh hop le "plugin list" duoc chay (libphpcli nhan "CALL: ... plugin list")',
          'plugin list' in called and 'FAKE-WPCLI-OUTPUT' in body, called)
    body, called = run_cmd('search-replace "old.example" "new.example" --dry-run')
    check('lenh hop le co dau nhay kep + --dry-run KHONG bi chan nham', 'search-replace' in called, called)
    body, called = run_cmd('wp core version')
    check('tien to "wp " duoc bo di dung', 'CALL:' in called and ' wp core' not in called and 'core version' in called, called)

    inj = ['plugin list; touch %s1' % pwn, 'plugin list && touch %s2' % pwn, 'plugin list || touch %s3' % pwn,
           'plugin list | touch %s4' % pwn, 'plugin list `touch %s5`' % pwn, 'plugin list $(touch %s6)' % pwn,
           'plugin list > %s7' % pwn, 'plugin list < /etc/passwd', 'plugin list\ntouch %s8' % pwn,
           'plugin list\rtouch %s9' % pwn, 'plugin list & touch %s10' % pwn, 'plugin list;touch %s11' % pwn]
    leaked = []
    for cmd in inj:
        body, called = run_cmd(cmd)
        if called or 'FAKE-WPCLI-OUTPUT' in body:
            leaked.append(cmd[:40])
    pwned = glob.glob(pwn + '*')
    check('12 kieu chen lenh (; && || | backtick $( ) > < newline CR &) deu bi chan TRUOC khi goi shell', not leaked, leaked[:3])
    check('khong file danh dau nao duoc tao (khong co lenh shell nao chay)', not pwned, pwned)
    body, called = run_cmd('plugin list')  # sau khi tan cong van hoat dong binh thuong
    check('sau chuoi tan cong, lenh hop le van chay binh thuong', 'plugin list' in called)
    sc_arr, body_arr, _ = c.req('POST', '/_admin/wpcli.php', {'cmd[]': 'plugin list', 'csrf_token': tkw})
    check('cmd dang mang (cmd[]=...) khong gay Fatal', not FATAL_RE.search(body_arr), body_arr[:120])
    if os.path.exists(calls):
        os.remove(calls)
    c.req('POST', '/_admin/wpcli.php', {'cmd': 'plugin list'})
    c.req('POST', '/_admin/wpcli.php', {'cmd': 'plugin list', 'csrf_token': 'd' * 64})
    check('thieu token / token sai CSRF -> KHONG goi libphpcli (doi chung: co token thi co goi, xem tren)', not os.path.exists(calls))

    # ---------- 7d. install-wp.php: bao ve site DANG CO ----------
    print('== 7d. install-wp: khong the ghi de site dang co ==')
    tki = c.token('maintenance')  # token CSRF theo PHIEN (dung chung giua cac trang); trang install-wp khong hien form khi site da cai
    check('lay duoc token CSRF hop le cua phien (de gui voi confirm=yes)', tki is not None)
    before = snapshot([app, www])
    c.req('POST', '/_admin/install-wp.php', {'confirm': 'yes', 'csrf_token': tki})
    c.req('POST', '/_admin/install-wp.php', {'confirm': 'yes'})
    after = snapshot([app, www])
    check('site DA CAI (co wp-config.php): POST confirm=yes voi token hop le KHONG doi file nao (chot chan alreadyInstalled)',
          before == after, sorted(set(before) ^ set(after))[:3])
    cfg = os.path.join(www, 'wp-config.php')
    os.rename(cfg, cfg + '.hold')
    try:
        sc_, body_, _ = c.req('POST', '/_admin/install-wp.php', {'confirm': 'yes'})
        check('site TRONG: confirm=yes KHONG co token CSRF -> bi tu choi, khong tao gi',
              'CSRF' in body_ and not os.path.exists(cfg) and not os.path.exists(os.path.join(adm, '.install-tmp')), body_[-200:])
        sc_, body_, _ = c.req('POST', '/_admin/install-wp.php', {'confirm': 'yes', 'csrf_token': 'e' * 64})
        check('site TRONG: token sai -> bi tu choi, khong tao gi', 'CSRF' in body_ and not os.path.exists(cfg))
    finally:
        os.rename(cfg + '.hold', cfg)

    # ---------- 8. Het han phien (idle 30 phut) ----------
    print('== 8. timeout phien ==')
    sid = c.cookie.split('=', 1)[1]
    sess_file = os.path.join(tmp, 'sess', 'sess_' + sid)
    ok_before = 'admin_password' not in c.req('GET', '/_admin/info.php')[1]
    txt = open(sess_file, encoding='utf-8').read()
    new_txt, n = re.subn(r'wp_pocket_last_activity\|i:\d+;', 'wp_pocket_last_activity|i:1;', txt)
    open(sess_file, 'w', encoding='utf-8').write(new_txt)
    body_after = c.req('GET', '/_admin/info.php')[1]
    check('phien con han: vao duoc trang quan tri', ok_before)
    check('phien quen 30+ phut bi huy: phai dang nhap lai', n == 1 and 'admin_password' in body_after, (n, body_after[:80]))


if __name__ == '__main__':
    sys.exit(main())
