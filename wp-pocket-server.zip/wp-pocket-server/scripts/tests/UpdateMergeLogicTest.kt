import com.wppocket.server.UpdateMergeLogic
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

// Kiem thu JVM cua UpdateMergeLogic (HANDOFF.md muc 1bo). Cung cac khang dinh voi ban port
// scripts/tests/update-merge-port-test.py (da chay that); file nay chay Kotlin that o CI.
var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun zipOf(files: Map<String, String>, dirs: List<String> = emptyList()): ByteArray {
    val bos = ByteArrayOutputStream()
    ZipOutputStream(bos).use { z ->
        for (d in dirs) { z.putNextEntry(ZipEntry(if (d.endsWith("/")) d else "$d/")); z.closeEntry() }
        for ((n, c) in files) { z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() }
    }
    return bos.toByteArray()
}

fun write(base: File, rel: String, c: String) { val f = File(base, rel); f.parentFile.mkdirs(); f.writeText(c) }
fun read(base: File, rel: String): String? { val f = File(base, rel); return if (f.isFile) f.readText() else null }
fun merge(zip: ByteArray, dir: File) = UpdateMergeLogic.extractMerge(ByteArrayInputStream(zip), dir)

fun main() {
    val tmp = Files.createTempDirectory("updmerge-kt").toFile()
    try {
        // ---- safeRelPath ----
        check("safeRelPath: chuan hoa ./ va //", UpdateMergeLogic.safeRelPath("a/b.txt") == "a/b.txt" && UpdateMergeLogic.safeRelPath("./a//b/") == "a/b" && UpdateMergeLogic.safeRelPath("a/") == "a")
        check("safeRelPath: .. / tuyet doi / NUL -> null", UpdateMergeLogic.safeRelPath("../x") == null && UpdateMergeLogic.safeRelPath("a/../../x") == null && UpdateMergeLogic.safeRelPath("a/..") == null && UpdateMergeLogic.safeRelPath("/etc/passwd") == null && UpdateMergeLogic.safeRelPath("a\u0000b") == null)
        check("safeRelPath: thu muc goc -> rong", UpdateMergeLogic.safeRelPath("./") == "" && UpdateMergeLogic.safeRelPath(".") == "")

        val bundle = mapOf(
            "index.php" to "NEW-INDEX", "wp-config.php.template" to "TEMPLATE-v2",
            "_admin/new-page.php" to "ADMIN-NEW", "_supervisor/start-lamp.sh" to "START-v2",
            "mariadb-share/errmsg.sys" to "ERR-v2", "wp-includes/version.php" to "6.9", "wp-admin/index.php" to "WPADMIN-v2",
            "wp-content/plugins/bundled/b.php" to "BUNDLED-v2", "wp-content/database/index.php" to "SILENCE")
        val zipNew = zipOf(bundle, listOf("wp-content/cache"))

        // ---- cai moi ----
        val d1 = File(tmp, "fresh")
        UpdateMergeLogic.prepareForMerge(d1)
        val r1 = merge(zipNew, d1)
        check("cai moi: moi tep co mat dung noi dung", bundle.all { (k, v) -> read(d1, k) == v })
        check("cai moi: dem ghi = so tep, khong bo qua", r1.written == bundle.size && r1.skippedLinks == 0 && r1.skippedConflicts == 0)

        // ---- cap nhat giu du lieu nguoi dung ----
        val d2 = File(tmp, "upd")
        val user = mapOf(
            "wp-content/uploads/2026/10/anh.jpg" to "JPEGDATA", "wp-content/plugins/my-plugin/x.php" to "MYPLUGIN",
            "wp-content/themes/my-theme/style.css" to "MYTHEME", "wp-content/database/.ht.sqlite" to "SQLITE-ALL-POSTS",
            "wp-content/languages/vi.mo" to "VI", "extra/readme.txt" to "USER-ADDED")
        val stale = mapOf("_admin/old-page.php" to "S", "wp-includes/stale.php" to "S", "mariadb-share/old.sys" to "S", "_supervisor/old.sh" to "S")
        for ((k, v) in user) write(d2, k, v)
        for ((k, v) in stale) write(d2, k, v)
        write(d2, "index.php", "OLD-INDEX"); write(d2, "wp-config.php", "OLD-CONFIG")
        UpdateMergeLogic.prepareForMerge(d2); merge(zipNew, d2)
        check("cap nhat: uploads/plugin/theme tu cai/SQLite/languages/tep nguoi dung them GIU NGUYEN", user.all { (k, v) -> read(d2, k) == v })
        check("cap nhat: tep cung duong dan voi goi bi ghi de ban moi", read(d2, "index.php") == "NEW-INDEX" && read(d2, "wp-content/plugins/bundled/b.php") == "BUNDLED-v2")
        check("cap nhat: tep cu trong REPLACED_DIRS bi go", stale.keys.all { read(d2, it) == null } && read(d2, "_admin/new-page.php") == "ADMIN-NEW")
        check("cap nhat: wp-config.php bi xoa de sinh lai; mau moi co mat", read(d2, "wp-config.php") == null && read(d2, "wp-config.php.template") == "TEMPLATE-v2")

        // ---- idempotent ----
        UpdateMergeLogic.prepareForMerge(d2); merge(zipNew, d2)
        check("chay lai: du lieu nguoi dung van nguyen, ma moi van dung", user.all { (k, v) -> read(d2, k) == v } && read(d2, "index.php") == "NEW-INDEX")

        // ---- Zip Slip ----
        var threw = false
        val victim = File(tmp, "evil.txt")
        try { merge(zipOf(mapOf("../evil.txt" to "x")), File(tmp, "slip1")) } catch (_: IOException) { threw = true }
        check("Zip Slip: ../ bi tu choi (IOException), khong ghi ra ngoai", threw && !victim.exists())
        threw = false
        try { merge(zipOf(mapOf("a/../../evil.txt" to "x")), File(tmp, "slip2")) } catch (_: IOException) { threw = true }
        check("Zip Slip: a/../../ bi tu choi", threw && !victim.exists())

        // ---- symlink ----
        val d4 = File(tmp, "sym"); val outside = File(tmp, "outside-cache"); outside.mkdirs(); write(outside, "keep.txt", "KEEP")
        File(d4, "wp-content").mkdirs()
        Files.createSymbolicLink(File(d4, "wp-content/cache").toPath(), outside.toPath())
        UpdateMergeLogic.prepareForMerge(d4)
        val r4 = merge(zipOf(mapOf("wp-content/cache/junk.txt" to "J", "wp-content/cache/sub/deep.txt" to "D", "ok.txt" to "OK"), listOf("wp-content/cache")), d4)
        check("symlink cache -> ngoai: khong ghi xuyen link, link con, khong nem loi", !File(outside, "junk.txt").exists() && !File(outside, "sub").exists() && Files.isSymbolicLink(File(d4, "wp-content/cache").toPath()) && read(d4, "ok.txt") == "OK" && r4.skippedLinks >= 2)
        check("symlink: noi dung dich khong bi dong vao", read(outside, "keep.txt") == "KEEP")

        val d5 = File(tmp, "sym2"); val out2 = File(tmp, "outside-lib"); out2.mkdirs(); write(out2, "libz.so.1", "LIB")
        File(d5, "_supervisor/pyhome").mkdirs()
        Files.createSymbolicLink(File(d5, "_supervisor/pyhome/lib-dynload").toPath(), out2.toPath())
        Files.createSymbolicLink(File(d5, "wp-admin").toPath(), out2.toPath())
        UpdateMergeLogic.prepareForMerge(d5)
        check("xoa REPLACED_DIRS khong theo symlink: chi xoa link", read(out2, "libz.so.1") == "LIB" && !Files.exists(File(d5, "_supervisor").toPath(), java.nio.file.LinkOption.NOFOLLOW_LINKS) && !Files.exists(File(d5, "wp-admin").toPath(), java.nio.file.LinkOption.NOFOLLOW_LINKS))

        val d6 = File(tmp, "sym3"); val out3 = File(tmp, "outside-file"); write(out3, "secret.txt", "SECRET"); d6.mkdirs()
        Files.createSymbolicLink(File(d6, "index.php").toPath(), File(out3, "secret.txt").toPath())
        merge(zipOf(mapOf("index.php" to "BUNDLE-INDEX")), d6)
        check("tep goi trung ten symlink-toi-tep: thay bang tep that, dich khong bi ghi de", read(d6, "index.php") == "BUNDLE-INDEX" && !Files.isSymbolicLink(File(d6, "index.php").toPath()) && read(out3, "secret.txt") == "SECRET")

        // ---- xung dot loai ----
        val d7 = File(tmp, "conf"); write(d7, "foo/user-data.txt", "UDATA"); write(d7, "bar", "A-USER-FILE")
        val r7 = merge(zipOf(mapOf("foo" to "BUNDLE-FILE-NAMED-FOO", "bar/baz.txt" to "BAZ")), d7)
        check("xung dot: tep goi trung ten thu muc nguoi dung -> bo qua, giu du lieu", r7.skippedConflicts == 1 && read(d7, "foo/user-data.txt") == "UDATA")
        check("xung dot: thu muc goi trung ten tep nguoi dung -> nhuong cho thu muc", read(d7, "bar/baz.txt") == "BAZ")

        // ---- hang so ----
        check("REPLACED_DIRS khong chua thu muc du lieu nguoi dung", UpdateMergeLogic.REPLACED_DIRS.none { it.contains("wp-content") || it.contains("upload") || it.contains("database") || it.isEmpty() })
    } finally {
        tmp.deleteRecursively()
    }
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
