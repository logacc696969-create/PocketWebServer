import com.wppocket.server.DbCheckLogic

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun main() {
    val healthy = "wordpress.wp_options\tcheck\tstatus\tOK\nwordpress.wp_posts\tcheck\tstatus\tOK\nwordpress.wp_users\tcheck\tstatus\tOK\n"
    val a = DbCheckLogic.parseCheck(healthy)
    check("CSDL khoe: 3 bang OK", a.total == 3 && a.ok == 3 && a.problems.isEmpty() && a.parsedRows == 3)
    val b = DbCheckLogic.parseCheck(healthy + "wordpress.wp_old\tcheck\twarning\tTable is marked as crashed\nwordpress.wp_old\tcheck\terror\tFound 1 keys of 0\nwordpress.wp_old\tcheck\tstatus\tCorrupt\n")
    check("bang hong: 1 van de, 3 OK", b.total == 4 && b.ok == 3 && b.problems.size == 1 && b.problems[0].startsWith("wordpress.wp_old: ") && b.problems[0].contains("crashed"))
    val c = DbCheckLogic.parseCheck("db.v\tcheck\tnote\tThe storage engine for the table doesn't support check\n" + healthy)
    check("bang khong ho tro check: bo qua", c.skipped == 1 && c.problems.isEmpty() && c.ok == 3)
    check("up to date = OK", DbCheckLogic.parseCheck("db.t\tcheck\tstatus\tTable is already up to date\n").ok == 1)
    check("status khac OK -> van de", DbCheckLogic.parseCheck("db.t\tcheck\tstatus\tOperation failed\n").problems.size == 1)
    val e = DbCheckLogic.parseCheck("ERROR 2002 (HY000): Can't connect to local MySQL server\n")
    check("dong loi ket noi -> khong parse duoc dong nao", e.parsedRows == 0 && e.total == 0)
    check("CRLF van dung", DbCheckLogic.parseCheck(healthy.replace("\n", "\r\n")).ok == 3)
    check("SQL kiem tra: dau ` nhan doi, QUICK", DbCheckLogic.checkSql("wordpress", listOf("wp_posts", "we`ird")) == "CHECK TABLE `wordpress`.`wp_posts`, `wordpress`.`we``ird` QUICK;\n")
    check("250 bang -> 3 cau", DbCheckLogic.checkSql("d", (0 until 250).map { "t$it" }).trim().split("\n").size == 3)
    check("parseTableList bo dong ERROR va dong trong", DbCheckLogic.parseTableList("wp_posts\nwp_users\n\nERROR 1045 x\n") == listOf("wp_posts", "wp_users"))
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
