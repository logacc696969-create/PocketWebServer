#!/usr/bin/env bash
# Kiem thu collect_shared_libs (scripts/lib/collect_libs.sh) tren cay thu muc gia gom chuoi symlink kieu Termux. HANDOFF.md muc 1bi.
# Chay: bash scripts/tests/collect-libs-test.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
source "$HERE/../lib/collect_libs.sh"
pass=0; fail=0
ok() { if [ "$1" = 0 ]; then pass=$((pass+1)); echo "PASS: $2"; else fail=$((fail+1)); echo "FAIL: $2"; fi; }
W="$(mktemp -d)"; X="$W/extract/usr/lib"; O="$W/out"; M="$W/map.txt"; mkdir -p "$X" "$O"
# libz: file that + SONAME symlink; libicudata: chuoi 3 ten cung 1 file; libplain.so: file thuong; libfoo.so.2 tro toi libfoo.so.2.9 (khong co ".so" cuoi)
echo ZLIBDATA > "$X/libz.so.1.3.1"; ln -s libz.so.1.3.1 "$X/libz.so.1"; ln -s libz.so.1 "$X/libz.so"
head -c 5000 /dev/zero > "$X/libicudata.so.75.1"; ln -s libicudata.so.75.1 "$X/libicudata.so.75"; ln -s libicudata.so.75 "$X/libicudata.so"
echo PLAIN > "$X/libplain.so"
echo FOO > "$X/libfoo.so.2.9"; ln -s libfoo.so.2.9 "$X/libfoo.so.2"
mkdir -p "$W/extract/usr/bin"; echo notalib > "$W/extract/usr/bin/node"          # khong khop *.so* -> khong duoc copy
collect_shared_libs "$W/extract" "$O" "$M"; ok $? "collect_shared_libs chay xong"
for f in "$O"/*; do case "$f" in *.so) ;; *) ok 1 "file KHONG ket thuc .so trong out: $f";; esac; done
[ -z "$(ls "$O" | grep -v '\.so$')" ]; ok $? "MOI file trong out ket thuc dung .so (jniLibs chi nhan *.so)"
[ -z "$(ls "$O" | grep '^node')" ]; ok $? "khong copy file khong khop *.so*"
cnt_z=$(cd "$O"; ls | grep -c '^libz'); [ "$cnt_z" = 1 ]; ok $? "chuoi libz (3 ten, 1 file that) chi copy MOT lan (co $cnt_z)"
cnt_i=$(cd "$O"; ls | grep -c '^libicudata'); [ "$cnt_i" = 1 ]; ok $? "chuoi libicudata (3 ten) chi copy MOT lan (co $cnt_i) - tranh APK phinh 2-3 lan"
grep -q '^libz.so.1 ' "$M"; ok $? "soname-map co dong cho ten SONAME that libz.so.1"
grep -q '^libfoo.so.2 libfoo_so_2.so$' "$M"; ok $? "ten khong ket thuc .so duoc doi: libfoo.so.2 -> libfoo_so_2.so"
grep -q '^libicudata.so.75 ' "$M"; ok $? "ten trung noi dung van duoc ghi vao soname-map (de linker tim duoc moi ten)"
! grep -q '^libplain.so ' "$M"; ok $? "file da ket thuc .so khong can dong anh xa"
# moi muc anh xa phai tro toi 1 file THAT SU co trong out
bad=0; while read -r a b; do [ -f "$O/$b" ] || { bad=1; echo "  map tro vao file khong co: $a -> $b"; }; done < "$M"; [ $bad = 0 ]; ok $? "moi dong soname-map tro toi file ton tai trong out"
# noi dung dung (copy THEO symlink, khong phai copy chinh symlink)
[ "$(cat "$O/$(grep '^libz.so.1 ' "$M" | cut -d' ' -f2)")" = "ZLIBDATA" ]; ok $? "noi dung file duoc copy dung (theo symlink)"
# chay lai lan 2 (out da co san) khong nhan doi, khong loi
collect_shared_libs "$W/extract" "$O" "$M.2"; n1=$(ls "$O" | wc -l); [ "$n1" = "$(ls "$O" | wc -l)" ]; ok $? "chay lai khong nhan doi file"
# DOI CHIEU VOI BAN GOC: trich dung doan thuat toan trong php.sh (duong PHP da chay tren thiet bi that) chay tren CUNG cay thu muc,
# ket qua (danh sach file + soname-map, da sap xep) phai GIONG HET - bao dam ban sao khong lech.
PHP_SH="$HERE/../runtimes/php.sh"
awk '/^SONAME_MAP="\$\(mktemp\)"$/,/^done < <\(find "\$EXTRACT_DIR" .*-print0\)$/' "$PHP_SH" > "$W/phpsh-block.sh"
[ -s "$W/phpsh-block.sh" ]; ok $? "trich duoc doan thuat toan tu php.sh ($(wc -l < "$W/phpsh-block.sh") dong)"
O2="$W/out-php"; mkdir -p "$O2"
( EXTRACT_DIR="$W/extract"; OUT_DIR="$O2"; set -u; source "$W/phpsh-block.sh"; cp "$SONAME_MAP" "$W/map-php.txt" ) 2>/dev/null
collect_shared_libs "$W/extract" "$W/out-new" "$W/map-new.txt" 2>/dev/null; mkdir -p "$W/out-new"; collect_shared_libs "$W/extract" "$W/out-new" "$W/map-new.txt"
[ "$(cd "$O2" && ls | sort)" = "$(cd "$W/out-new" && ls | sort)" ]; ok $? "danh sach file GIONG HET ban trong php.sh"
[ "$(sort "$W/map-php.txt")" = "$(sort "$W/map-new.txt")" ]; ok $? "soname-map GIONG HET ban trong php.sh"
rm -rf "$W"
echo; echo "TONG KET: pass=$pass fail=$fail"; [ $fail = 0 ]
