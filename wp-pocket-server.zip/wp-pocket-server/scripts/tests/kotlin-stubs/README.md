# Stub androidx de bien dich KIEM TRA toan bo Kotlin cua app (khong can Gradle/Android SDK day du)

Chi dung cho `scripts/tests/kotlin-app-compile-test.py`; KHONG nam trong APK. Chi chua chu ky (signature) cua cac lop `androidx.*` ma app dung
(WorkManager, AppCompatActivity, AlertDialog, NotificationCompat, ContextCompat, ActivityResultContracts...) de trinh bien dich kiem duoc **cac loi
khong lien quan androidx** (thieu import, sai ten ham, sai kieu...) - loai loi da lam CI hong o ban cu (`ServerForegroundService.kt: Unresolved reference: Context`).
Khi code them mot ham androidx moi, test bao "unresolved reference" -> them chu ky vao day (khong can than trong: Gradle that moi la nguon su that cuoi cung).
Lop `R` va cac lop ViewBinding duoc test TU SINH tu thu muc `res/`.
