package androidx.work
import java.util.concurrent.TimeUnit
inline fun <reified W : ListenableWorker> PeriodicWorkRequestBuilder(repeatInterval: Long, repeatIntervalTimeUnit: TimeUnit): PeriodicWorkRequest.Builder = PeriodicWorkRequest.Builder()
inline fun <reified W : ListenableWorker> OneTimeWorkRequestBuilder(): OneTimeWorkRequest.Builder = OneTimeWorkRequest.Builder()
fun workDataOf(vararg pairs: Pair<String, Any?>): Data = Data()
