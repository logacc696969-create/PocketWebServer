package androidx.work;
import android.content.Context;
public abstract class WorkManager {
  public static WorkManager getInstance(Context c){return null;}
  public abstract Object enqueueUniquePeriodicWork(String n, ExistingPeriodicWorkPolicy p, PeriodicWorkRequest r);
  public abstract Object enqueueUniqueWork(String n, ExistingWorkPolicy p, OneTimeWorkRequest r);
  public abstract Object cancelUniqueWork(String n);
}
