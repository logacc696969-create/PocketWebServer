package androidx.work;
import java.util.concurrent.TimeUnit;
public final class PeriodicWorkRequest extends WorkRequest {
  public static final class Builder {
    public Builder setConstraints(Constraints c){return this;} public Builder setInitialDelay(long d, TimeUnit u){return this;}
    public Builder addTag(String t){return this;} public Builder setInputData(Data d){return this;} public PeriodicWorkRequest build(){return null;}
  }
}
