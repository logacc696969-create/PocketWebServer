package androidx.work;
public class Data { public boolean getBoolean(String k, boolean d){return d;} public String getString(String k){return null;} public long getLong(String k,long d){return d;} public int getInt(String k,int d){return d;} }
