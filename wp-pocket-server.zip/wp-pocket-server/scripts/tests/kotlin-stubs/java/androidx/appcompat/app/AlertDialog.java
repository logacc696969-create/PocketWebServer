package androidx.appcompat.app;
import android.content.Context; import android.content.DialogInterface; import android.view.View; import android.widget.Button;
public class AlertDialog extends android.app.Dialog {
  public AlertDialog(Context c) { super(c); }
  public static final int BUTTON_POSITIVE = -1, BUTTON_NEGATIVE = -2, BUTTON_NEUTRAL = -3;
  public Button getButton(int which) { return null; }
  public static class Builder {
    public Builder(Context c) {}
    public Builder setTitle(CharSequence t){return this;} public Builder setTitle(int t){return this;}
    public Builder setMessage(CharSequence t){return this;} public Builder setMessage(int t){return this;}
    public Builder setPositiveButton(CharSequence t, DialogInterface.OnClickListener l){return this;} public Builder setPositiveButton(int t, DialogInterface.OnClickListener l){return this;}
    public Builder setNegativeButton(CharSequence t, DialogInterface.OnClickListener l){return this;} public Builder setNegativeButton(int t, DialogInterface.OnClickListener l){return this;}
    public Builder setNeutralButton(CharSequence t, DialogInterface.OnClickListener l){return this;} public Builder setNeutralButton(int t, DialogInterface.OnClickListener l){return this;}
    public Builder setView(View v){return this;} public Builder setCancelable(boolean b){return this;}
    public Builder setItems(CharSequence[] items, DialogInterface.OnClickListener l){return this;}
    public Builder setSingleChoiceItems(CharSequence[] items, int checked, DialogInterface.OnClickListener l){return this;}
    public Builder setOnDismissListener(DialogInterface.OnDismissListener l){return this;} public Builder setOnCancelListener(DialogInterface.OnCancelListener l){return this;}
    public AlertDialog create(){return null;} public AlertDialog show(){return null;}
  }
}
