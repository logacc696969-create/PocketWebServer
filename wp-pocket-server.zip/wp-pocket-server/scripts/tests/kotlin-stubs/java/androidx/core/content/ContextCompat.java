package androidx.core.content;
import android.content.Context; import android.content.Intent;
public class ContextCompat {
  public static void startForegroundService(Context c, Intent i) {}
  public static int checkSelfPermission(Context c, String p) { return 0; }
  public static int getColor(Context c, int id) { return 0; }
  public static android.graphics.drawable.Drawable getDrawable(Context c, int id) { return null; }
}
