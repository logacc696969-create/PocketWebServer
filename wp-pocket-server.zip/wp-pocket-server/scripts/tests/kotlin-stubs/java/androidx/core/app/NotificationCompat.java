package androidx.core.app;
import android.app.Notification; import android.app.PendingIntent; import android.content.Context;
public class NotificationCompat {
  public static final int PRIORITY_LOW = -1, PRIORITY_MIN = -2, PRIORITY_DEFAULT = 0, PRIORITY_HIGH = 1;
  public static final int VISIBILITY_PUBLIC = 1, VISIBILITY_PRIVATE = 0, VISIBILITY_SECRET = -1;
  public static final String CATEGORY_SERVICE = "service", CATEGORY_STATUS = "status";
  public static class Builder {
    public Builder(Context c, String channelId) {}
    public Builder setContentTitle(CharSequence t){return this;} public Builder setContentText(CharSequence t){return this;}
    public Builder setSmallIcon(int i){return this;} public Builder setOngoing(boolean b){return this;}
    public Builder setContentIntent(PendingIntent p){return this;} public Builder addAction(int icon, CharSequence t, PendingIntent p){return this;}
    public Builder setPriority(int p){return this;} public Builder setCategory(String c){return this;} public Builder setOnlyAlertOnce(boolean b){return this;}
    public Builder setVisibility(int v){return this;} public Builder setShowWhen(boolean b){return this;} public Builder setSilent(boolean b){return this;}
    public Builder setWhen(long w){return this;} public Builder setAutoCancel(boolean b){return this;} public Builder setForegroundServiceBehavior(int b){return this;}
    public Builder setStyle(Object s){return this;} public Notification build(){return null;}
  }
}
