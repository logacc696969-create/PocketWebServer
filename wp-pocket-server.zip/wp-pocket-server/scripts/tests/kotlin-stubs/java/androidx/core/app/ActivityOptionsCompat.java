package androidx.core.app;
public class ActivityOptionsCompat {
  public static ActivityOptionsCompat makeCustomAnimation(android.content.Context c, int enter, int exit) { return null; }
  public android.os.Bundle toBundle() { return null; }
}
