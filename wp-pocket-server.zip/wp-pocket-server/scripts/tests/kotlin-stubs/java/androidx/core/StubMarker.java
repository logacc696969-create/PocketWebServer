package androidx.core;
class StubMarker {}
