package androidx.activity.result;
public abstract class ActivityResultLauncher<I> { public abstract void launch(I input); }
