package androidx.activity.result.contract;
import androidx.activity.result.ActivityResult;
public class ActivityResultContracts {
  public static final class RequestPermission extends ActivityResultContract<String, Boolean> { public RequestPermission() {} }
  public static final class StartActivityForResult extends ActivityResultContract<android.content.Intent, ActivityResult> { public StartActivityForResult() {} }
}
