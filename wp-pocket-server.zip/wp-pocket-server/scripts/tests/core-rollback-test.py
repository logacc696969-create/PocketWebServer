#!/usr/bin/env python3
"""Kiem thu CHEN LOI cho _admin/core-rollback.php - xem HANDOFF.md muc 1ax.
Trang thay wp-admin/wp-includes bang snapshot: neu 1 file khong ghi duoc thi KHONG duoc bao 'xong',
va neu khong luu duoc ban an toan thi KHONG duoc ghi de. Loi duoc tao XAC DINH (khong can mount/disk day):
 - dat 1 THU MUC vao cho can ghi 1 file  -> copy() that bai ke ca khi chay bang root;
 - dat 1 symlink TREO trong thu muc hien tai -> buoc luu ban an toan (copy tu day) that bai.
Chay: python3 scripts/tests/core-rollback-test.py   (STAGING_PAGE-kieu: ROLLBACK_PAGE=<file> de doi chung am)
"""
import importlib.util, os, shutil, socket, subprocess, sys, tempfile, time, glob
HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check

def wr(p, t):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(t)

def main():
    page = os.environ.get('ROLLBACK_PAGE') or os.path.join(HERE, '..', 'runtimes', 'templates', 'admin-core-rollback.php')
    tmp = tempfile.mkdtemp(prefix='cr-')
    try:
        os.chmod(tmp, 0o755)
        app, run, www0, adm0 = sec.build_tree(tmp)
        www = os.path.join(app, 'www'); shutil.move(www0, www)
        shutil.copy(page, os.path.join(www, '_admin', 'core-rollback.php'))
        snap = os.path.join(www, 'wp-content', 'wppocket-core-rollback')
        def fixture():
            for d in ('wp-admin', 'wp-includes'):
                shutil.rmtree(os.path.join(www, d), ignore_errors=True)
            shutil.rmtree(snap, ignore_errors=True)
            for g in glob.glob(os.path.join(app, 'core-rollback-safety-*')): shutil.rmtree(g, ignore_errors=True)
            wr(os.path.join(www, 'wp-admin', 'a.php'), 'NEW-A')
            wr(os.path.join(www, 'wp-includes', 'version.php'), 'NEW-V')
            wr(os.path.join(www, 'wp-settings.php'), 'NEW-ROOT')
            wr(os.path.join(snap, 'version-before-update.txt'), '6.8.1')
            wr(os.path.join(snap, 'wp-admin', 'a.php'), 'OLD-A')
            wr(os.path.join(snap, 'wp-includes', 'version.php'), 'OLD-V')
            wr(os.path.join(snap, 'root-wp-settings.php'), 'OLD-ROOT')
        rd = lambda *p: open(os.path.join(www, *p)).read() if os.path.isfile(os.path.join(www, *p)) else None
        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
                                '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=1'],
                               env=dict(os.environ, APP_HOME=app), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
                except OSError: time.sleep(0.1)
            c = sec.Client(port, '10.2.2.2'); c.login()
            def rollback():
                tok = c.token('core-rollback')
                return c.req('POST', '/_admin/core-rollback.php', {'action': 'rollback', 'csrf_token': tok})[1]

            print('== R0. rollback binh thuong (doi chung duong) ==')
            fixture(); body = rollback()
            check('rollback OK: wp-admin, wp-includes, file goc duoc thay bang snapshot',
                  rd('wp-admin', 'a.php') == 'OLD-A' and rd('wp-includes', 'version.php') == 'OLD-V' and rd('wp-settings.php') == 'OLD-ROOT', body[-200:])
            check('rollback OK: bao "Da khoi phuc xong" + co ban an toan cua trang thai truoc khi ghi de',
                  'Da khoi phuc xong' in body and any(rd_ for rd_ in glob.glob(os.path.join(app, 'core-rollback-safety-*', 'wp-admin', 'a.php'))))
            check('rollback OK: ban an toan giu dung noi dung CU (NEW-A)', any(open(f).read() == 'NEW-A' for f in glob.glob(os.path.join(app, 'core-rollback-safety-*', 'wp-admin', 'a.php'))))

            print('== R1. 1 file KHONG ghi duoc luc khoi phuc ==')
            fixture()
            os.remove(os.path.join(www, 'wp-includes', 'version.php')); os.makedirs(os.path.join(www, 'wp-includes', 'version.php'))
            body = rollback()
            check('co file khong ghi duoc -> KHONG bao "Da khoi phuc xong"', 'Da khoi phuc xong' not in body, body[body.find('class="'):][:200] if 'class="' in body else body[:200])
            check('co file khong ghi duoc -> bao CHUA HOAN TAT + so file loi', 'CHUA HOAN TAT' in body, body[-300:])
            check('cac file khac van duoc khoi phuc (khong bo ca lo)', rd('wp-admin', 'a.php') == 'OLD-A')

            print('== R2. KHONG luu duoc ban an toan -> khong duoc ghi de ==')
            fixture()
            os.symlink('/nonexistent/khong-co-file', os.path.join(www, 'wp-admin', 'dangling.php'))
            body = rollback()
            check('luu ban an toan loi -> core KHONG bi ghi de (van la ban hien tai)', rd('wp-admin', 'a.php') == 'NEW-A' and rd('wp-includes', 'version.php') == 'NEW-V', (rd('wp-admin', 'a.php'), rd('wp-includes', 'version.php')))
            check('luu ban an toan loi -> bao loi ro rang, khong noi "Da khoi phuc xong"', 'Da khoi phuc xong' not in body and 'DUNG' in body, body[-300:])
        finally:
            srv.terminate()
            try: srv.wait(timeout=5)
            except Exception: srv.kill()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL)); return 0 if sec.FAIL == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
