#!/usr/bin/env python3
"""Kiem thu mu-plugin xoa page cache khi noi dung doi (HANDOFF.md muc 1bg) bang PHP CLI THAT.
Trong tam: (1) loi trong purge.php (ke ca loi CU PHAP) KHONG duoc lam hong website - day la ly do tach file nap + try/catch Throwable;
(2) chi xoa FILE trong lamp-run/page-cache, khong cham gi ngoai thu muc do; (3) dung cac hook, binh luan chua duyet khong xoa.
Can: php (CLI). Thieu thi bo qua (exit 0)."""
import json, os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:240]) if d else ''))

HARNESS = r'''<?php
// Gia lap toi thieu cua WordPress: ABSPATH + add_action ghi lai hook.
define('ABSPATH', '/tmp/fake-wp/');
$GLOBALS['hooks'] = array();
function add_action($h, $cb, $p = 10, $n = 1) { $GLOBALS['hooks'][$h][] = $cb; }
require $argv[1];                       // file NAP (wppocket-pagecache.php)
$mode = isset($argv[2]) ? $argv[2] : 'list';
if ($mode === 'list') { echo json_encode(array_keys($GLOBALS['hooks'])); }
if ($mode === 'fire')    { foreach ($GLOBALS['hooks'][$argv[3]] as $cb) { $cb(1, isset($argv[4]) ? $argv[4] : null); } echo 'FIRED'; }
if ($mode === 'survive') { echo 'SURVIVED'; }
'''
def main():
    php = shutil.which('php')
    if not php: print('(bo qua: thieu php CLI)'); return 0
    tmp = tempfile.mkdtemp(prefix='pcpurge-')
    try:
        mu = os.path.join(tmp, 'mu-plugins'); os.makedirs(os.path.join(mu, 'wppocket-pagecache'))
        shutil.copy(os.path.join(TPL, 'wppocket-pagecache-loader.php'), os.path.join(mu, 'wppocket-pagecache.php'))
        shutil.copy(os.path.join(TPL, 'wppocket-pagecache-purge.php'), os.path.join(mu, 'wppocket-pagecache', 'purge.php'))
        open(os.path.join(tmp, 'harness.php'), 'w').write(HARNESS)
        loader = os.path.join(mu, 'wppocket-pagecache.php')
        home = os.path.join(tmp, 'home'); cache = os.path.join(home, 'lamp-run', 'page-cache')
        def run(mode='list', *extra, env_home=home, loader_path=loader):
            env = dict(os.environ); env.pop('APP_HOME', None)
            if env_home is not None: env['APP_HOME'] = env_home
            return subprocess.run([php, os.path.join(tmp, 'harness.php'), loader_path, mode, *extra], capture_output=True, text=True, env=env)
        def fill():
            for sub in ('ab/cd', 'ef/01'):
                os.makedirs(os.path.join(cache, sub), exist_ok=True)
                open(os.path.join(cache, sub, 'entry'), 'w').write('x')
            open(os.path.join(home, 'lamp-run', 'giu-lai.txt'), 'w').write('KHONG DUOC XOA')
            open(os.path.join(tmp, 'ngoai-thu-muc.txt'), 'w').write('KHONG DUOC XOA')
        def left(): return sorted(os.path.join(r, f) for r, _d, fs in os.walk(cache) for f in fs)

        print('== 1. Nap + hook ==')
        r = run('list'); hooks = json.loads(r.stdout) if r.returncode == 0 and r.stdout else []
        check('file nap chay khong loi', r.returncode == 0 and bool(hooks), (r.returncode, r.stdout, r.stderr))
        for h in ('save_post', 'deleted_post', 'comment_post', 'wp_set_comment_status', 'switch_theme', 'activated_plugin', 'wp_update_nav_menu', 'edited_term'):
            check('da gan hook %s' % h, h in hooks)
        check('KHONG gan hook chung "updated_option" (se xoa cache lien tuc vi WordPress ghi option o front-end)', 'updated_option' not in hooks and 'update_option' not in hooks)

        print('== 2. Xoa dung pham vi ==')
        fill(); r = run('fire', 'save_post')
        check('hook save_post xoa HET file trong page-cache', r.stdout == 'FIRED' and left() == [], (r.stdout, r.stderr, left()))
        check('GIU thu muc cache (nginx dang giu) va file khac cua lamp-run', os.path.isdir(cache) and open(os.path.join(home, 'lamp-run', 'giu-lai.txt')).read() == 'KHONG DUOC XOA')
        check('KHONG cham file ngoai thu muc cache', open(os.path.join(tmp, 'ngoai-thu-muc.txt')).read() == 'KHONG DUOC XOA')
        fill(); r = run('fire', 'comment_post', '0')
        check('binh luan CHO DUYET (approved=0) KHONG xoa cache', len(left()) == 2, left())
        r = run('fire', 'comment_post', 'spam')
        check('binh luan spam KHONG xoa cache', len(left()) == 2, left())
        r = run('fire', 'comment_post', '1')
        check('binh luan duoc duyet ngay (approved=1) xoa cache', left() == [], left())
        fill(); r = run('fire', 'wp_set_comment_status')
        check('doi trang thai binh luan xoa cache', left() == [], left())

        print('== 3. Truong hop bien ==')
        shutil.rmtree(cache)
        r = run('fire', 'save_post'); check('khong co thu muc cache (tinh nang cache tat) -> khong loi, khong tao gi', r.stdout == 'FIRED' and not os.path.exists(cache), (r.stdout, r.stderr))
        os.makedirs(cache); fill()
        r = run('fire', 'save_post', env_home=None); check('khong co APP_HOME -> khong lam gi, khong loi', r.stdout == 'FIRED' and len(left()) == 2, (r.stdout, r.stderr, left()))
        os.symlink(os.path.join(tmp, 'ngoai-thu-muc.txt'), os.path.join(cache, 'lien-ket'))
        r = run('fire', 'save_post')
        check('symlink khong bi theo (khong xoa file dich ngoai cache)', os.path.exists(os.path.join(tmp, 'ngoai-thu-muc.txt')))

        print('== 4. QUAN TRONG: purge.php hong KHONG duoc lam hong website ==')
        bad = os.path.join(tmp, 'mu2'); os.makedirs(os.path.join(bad, 'wppocket-pagecache'))
        shutil.copy(os.path.join(TPL, 'wppocket-pagecache-loader.php'), os.path.join(bad, 'wppocket-pagecache.php'))
        open(os.path.join(bad, 'wppocket-pagecache', 'purge.php'), 'w').write('<?php\nif (!defined("ABSPATH")) { exit; }\nfunction broken( {  // loi cu phap co y\n')
        r = run('survive', loader_path=os.path.join(bad, 'wppocket-pagecache.php'))
        check('purge.php co LOI CU PHAP: trang van chay tiep (ParseError bi try/catch nuot)', r.returncode == 0 and r.stdout == 'SURVIVED', (r.returncode, r.stdout, r.stderr[:200]))
        open(os.path.join(bad, 'wppocket-pagecache', 'purge.php'), 'w').write('<?php\nthrow new RuntimeException("loi luc chay");\n')
        r = run('survive', loader_path=os.path.join(bad, 'wppocket-pagecache.php'))
        check('purge.php nem exception: trang van chay tiep', r.returncode == 0 and r.stdout == 'SURVIVED', (r.returncode, r.stdout, r.stderr[:200]))
        r = subprocess.run([php, '-l', os.path.join(TPL, 'wppocket-pagecache-purge.php')], capture_output=True, text=True)
        check('php -l purge.php sach', r.returncode == 0, r.stdout + r.stderr)
        r = subprocess.run([php, '-l', os.path.join(TPL, 'wppocket-pagecache-loader.php')], capture_output=True, text=True)
        check('php -l file nap sach', r.returncode == 0, r.stdout + r.stderr)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
