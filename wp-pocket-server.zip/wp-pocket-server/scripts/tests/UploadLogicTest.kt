import com.wppocket.server.UploadLogic

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun main() {
    val m = UploadLogic.buildMultipart("BND", listOf(Pair("chat_id", "123"), Pair("caption", "Sao luu: tiếng Việt")), "document", "b.zip", "application/zip")
    val h = String(m.header, Charsets.UTF_8); val f = String(m.footer, Charsets.UTF_8)
    check("header: moi truong + phan dau cua tep, dung dinh dang multipart", h.startsWith("--BND\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n123\r\n--BND\r\n") && h.contains("name=\"caption\"\r\n\r\nSao luu: tiếng Việt\r\n") && h.endsWith("--BND\r\nContent-Disposition: form-data; name=\"document\"; filename=\"b.zip\"\r\nContent-Type: application/zip\r\n\r\n"))
    check("footer: dong ket thuc boundary", f == "\r\n--BND--\r\n")
    check("totalLength tinh theo BYTE (tieng Viet 3 byte/ky tu), khong theo ky tu", m.header.size > h.length && m.totalLength(1000L) == m.header.size.toLong() + 1000L + m.footer.size.toLong())
    check("totalLength: tep rat lon (hon 2 GB) khong tran so nguyen", m.totalLength(3_000_000_000L) == m.header.size.toLong() + 3_000_000_000L + m.footer.size.toLong())
    val evil = UploadLogic.buildMultipart("B", emptyList(), "file", "a\"b\r\nX-Evil: 1.zip", "application/zip")
    val eh = String(evil.header, Charsets.UTF_8)
    check("ten tep chua nhay kep/CRLF khong chen duoc header moi", !eh.contains("\r\nX-Evil") && eh.contains("filename=\"a'b  X-Evil: 1.zip\""))
    check("telegramTooLarge: ranh gioi 50 MB", !UploadLogic.telegramTooLarge(UploadLogic.TELEGRAM_MAX_BYTES) && UploadLogic.telegramTooLarge(UploadLogic.TELEGRAM_MAX_BYTES + 1) && UploadLogic.TELEGRAM_MAX_BYTES == 52428800L)
    check("failureNote: khong cau hinh noi nao -> null", UploadLogic.failureNote(false, true, false, true, 10) == null)
    check("failureNote: gui thanh cong -> null", UploadLogic.failureNote(true, true, true, true, 10) == null)
    val big = UploadLogic.failureNote(true, false, false, true, 120L * 1024 * 1024)
    check("failureNote: Telegram + tep > 50 MB -> neu ro kich thuoc va gioi han", big != null && big.contains("120 MB") && big.contains("50 MB") && big.contains("CHUA co ban sao ngoai may"))
    check("failureNote: Telegram loi mang (tep nho) -> noi that bai, khong noi gioi han", UploadLogic.failureNote(true, false, false, true, 1024)!!.contains("Telegram that bai"))
    val both = UploadLogic.failureNote(true, false, true, false, 1024)!!
    check("failureNote: ca hai that bai -> liet ke ca hai", both.contains("Telegram") && both.contains("webhook"))
    check("failureNote: webhook that bai nhung Telegram ok -> chi neu webhook", UploadLogic.failureNote(true, true, true, false, 1024)!!.let { it.contains("webhook") && !it.contains("Telegram") })
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
