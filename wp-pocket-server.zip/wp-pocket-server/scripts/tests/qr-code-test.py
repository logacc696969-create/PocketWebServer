#!/usr/bin/env python3
"""K4 / A3 (PDF 1 muc K4, PDF 2 muc A3; HANDOFF.md muc 1bq): kiem chung bo ma hoa QR tu viet bang BO GIAI MA QR THAT.

Ly do tung bi tu choi ("khong kiem chung duoc anh QR co quet duoc that khong") da het: moi truong co OpenCV (cv2.QRCodeDetector),
va JDK day du de chay ban Java SAT NGUYEN BAN cua app/.../QrCode.kt (scripts/tests/java/QrCodePort.java).

Quy trinh: Java sinh ma tran -> Python ve anh (module 8 px, vung yen 4 module) -> cv2 GIAI MA -> so chuoi voi dau vao.
Bo qua phan giai ma (thoat 0, in ly do) neu thieu cv2/numpy hoac JDK day du - CI cai san ca hai (xem build-apk.yml).
"""
import base64, os, random, re, subprocess, sys, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
J = os.path.join(ROOT, "scripts", "tests", "java", "QrCodePort.java")
KT = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/QrCode.kt")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, extra)


kt = open(KT, encoding="utf-8").read()
jv = open(J, encoding="utf-8").read()

# ---------------------------------------------------------------- 1. doi chieu van ban Kotlin <-> Java (chong lech 2 ban)
def int_arrays(src):
    out = []
    for m in re.finditer(r"(?:intArrayOf|\{)\s*\(?\s*(-?\d+(?:\s*,\s*-?\d+){30,})", src):
        out.append([int(x) for x in re.split(r"\s*,\s*", m.group(1).strip())])
    return out

ka, ja = int_arrays(kt), int_arrays(jv)
check("Kotlin va Java co CUNG 8 bang so (ECC moi khoi x4, so khoi x4), tung phan tu giong nhau", len(ka) == 8 and ka == ja,
      "kotlin=%d java=%d" % (len(ka), len(ja)))
check("moi bang co du 41 phan tu (phan tu 0 la dem)", all(len(a) == 41 for a in ka))
for tok in ["0x11D", "0x537", "0x5412", "0x1F25", "0xEC", "0x11", "result += 40", "result += 3", "k * 10", "0x4, 4"]:
    check("hang so/thuat toan '%s' co mat o CA Kotlin va Java" % tok, tok.replace(" ", "") in kt.replace(" ", "") and tok.replace(" ", "") in jv.replace(" ", ""))
check("QrCode.kt thuan: khong import android.* (kiem duoc tren JVM)", re.search(r"^import android", kt, re.M) is None)
check("QrCode.kt tra ve null (khong nem loi) khi du lieu qua dai", "?" in kt and "return null" in kt and "throw " not in kt)

# ---------------------------------------------------------------- 2. Java selftest (bang chuan)
try:
    mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception:
    mods = ""
have_jdk = "jdk.compiler" in mods
try:
    import numpy as np, cv2
    have_cv = True
except Exception:
    have_cv = False
if not have_jdk or not have_cv:
    print("(bo qua phan giai ma: can JDK day du %s, numpy+opencv %s)" % (have_jdk, have_cv))
    print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
    sys.exit(0 if fail_n == 0 else 1)

r = subprocess.run(["java", J, "selftest"], capture_output=True, text=True, timeout=300)
check("QrCodePort selftest tren JDK that: ma tu du lieu/dung luong/mau can chinh khop bang chuan", r.returncode == 0 and "fail=0" in r.stdout, r.stdout[-400:] + r.stderr[-200:])

caps = {}
for line in subprocess.run(["java", J, "caps"], capture_output=True, text=True, timeout=120).stdout.split("\n"):
    if line.strip():
        v, e, c = line.split()
        caps[(int(v), e)] = int(c)

tmp = tempfile.mkdtemp()


def dump(cases):
    """cases: [(ecc, bytes[, 'noboost'])] -> danh sach (ecc, version, mask, ma tran numpy) hoac None."""
    path = os.path.join(tmp, "in.tsv")
    with open(path, "w", encoding="utf-8") as f:
        for c in cases:
            f.write("%s\t%s%s\n" % (c[0], base64.b64encode(c[1]).decode(), "\t" + c[2] if len(c) > 2 else ""))
    out = subprocess.run(["java", J, "dump", path], capture_output=True, text=True, timeout=900).stdout.strip().split("\n")
    res = []
    for line in out:
        if line == "NULL":
            res.append(None)
            continue
        ecc, ver, mask, size, rows = line.split(" ")
        m = np.array([[int(ch) for ch in row] for row in rows.split("/")], dtype=np.uint8)
        res.append((ecc, int(ver), int(mask), m))
    return res


def render(m, scale=8, quiet=4):
    n = m.shape[0]
    img = np.full(((n + 2 * quiet) * scale, (n + 2 * quiet) * scale), 255, dtype=np.uint8)
    big = np.kron(m, np.ones((scale, scale), dtype=np.uint8))
    img[quiet * scale:(quiet + n) * scale, quiet * scale:(quiet + n) * scale] = np.where(big == 1, 0, 255)
    return img


det = cv2.QRCodeDetector()


def decode(img):
    val, pts, _ = det.detectAndDecode(img)
    return val


# ---------------------------------------------------------------- bo giai ma ma tran doc lap + bang so khoi (lay tu Kotlin)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import qr_matrix_decoder as md
ECC_TBL, BLK_TBL = ka[:4], ka[4:]
LEVELS = ["LOW", "MEDIUM", "QUARTILE", "HIGH"]


def pts_for(m, scale, quiet=4):
    n = m.shape[0]
    a, b = quiet * scale, (quiet + n) * scale
    return np.array([[[a, a], [b, a], [b, b], [a, b]]], dtype=np.float32)


def cv_known(m, scale=6):
    """Giai ma bang OpenCV KHI BIET SAN 4 GOC (bo qua buoc do tim - buoc nay hay lo voi ma day/lon du ma hop le)."""
    out = det.decode(render(m, scale), pts_for(m, scale))
    return out[0]


# ---------------------------------------------------------------- 3. chuoi thuc te (URL, LAN, tieng Viet, emoji)
samples = [
    "https://quiet-river-1234.trycloudflare.com",
    "https://blog.example.com/",
    "http://192.168.1.23:8080/",
    "http://10.0.0.5:8080/_admin/",
    "https://example.com/duong-dan/co-dau/bai-viet?id=42&ref=qr#phan-2",
    "Xin chào WP Pocket Server — thử tiếng Việt: ăâêôơư ĐĐ ✓",
    "😀 emoji + 日本語",
    "a",
    "WIFI:T:WPA;S:Nha Toi;P:matkhau123;;",
]
cases = []
for s_ in samples:
    for e in LEVELS:
        cases.append((e, s_.encode("utf-8"), "noboost"))
res = dump(cases)
bad_known, ok_pipe = [], 0
for (c, rr) in zip(cases, res):
    want = c[1].decode("utf-8")
    if cv_known(rr[3], 8) != want:
        bad_known.append((c[0], c[1][:30]))
    if decode(render(rr[3])) == want:
        ok_pipe += 1
check("%d chuoi thuc te x 4 muc sua loi: OpenCV (biet san 4 goc) doc LAI DUNG tung chuoi (URL, LAN, tieng Viet, emoji)" % len(samples), not bad_known, str(bad_known[:3]))
check("duong day day du (do tim + giai ma) cua OpenCV doc dung >= 75%% (%d/%d) - bo do tim cua OpenCV tu no co luc lo" % (ok_pipe, len(cases)), ok_pipe >= 0.75 * len(cases))
check("muc sua loi trong ket qua dung muc yeu cau khi tat boost", all(rr[0] == c[0] for c, rr in zip(cases, res)))
cb = [("LOW", s_.encode("utf-8")) for s_ in samples]
rb = dump(cb)
check("boost: yeu cau LOW cho chuoi ngan duoc nang len muc cao hon va VAN doc dung", all(cv_known(x[3], 8) == s_ for x, s_ in zip(rb, samples)) and any(x[0] != "LOW" for x in rb))

# ---------------------------------------------------------------- 4. 40 phien ban x 4 muc voi tai trong DAY
rnd = random.Random(20261025)
alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~:/?#[]@!$&'()*+,;="
TRIES = 6
full = []
for v in range(1, 41):
    for e in LEVELS:
        for t in range(TRIES):
            full.append((v, e, "".join(rnd.choice(alpha) for _ in range(caps[(v, e)]))))
res = dump([(e, s_.encode(), "noboost") for v, e, s_ in full])
wrong_ver, matrix_bad, masks = [], [], set()
for (v, e, s_), rr in zip(full, res):
    if rr is None or rr[1] != v or rr[0] != e:
        wrong_ver.append((v, e, rr and rr[1]))
        continue
    masks.add(rr[2])
    got = md.try_decode(rr[3], v, LEVELS.index(e), rr[2], ECC_TBL, BLK_TBL)
    if got != s_.encode():
        matrix_bad.append((v, e, rr[2]))
check("960 ma (40 phien ban x 4 muc x 6 tai trong day ngau nhien): dung phien ban/muc du kien", not wrong_ver, str(wrong_ver[:5]))
check("960 ma: bo giai ma ma tran DOC LAP xac nhan MOI khoi Reed-Solomon co syndrome = 0 va doc lai DUNG tung byte", not matrix_bad, str(matrix_bad[:8]))
check("du 8 mat na (0..7) xuat hien trong cac ma tren", masks == set(range(8)), str(sorted(masks)))

# bo giai ma that cua OpenCV: MOI to hop (phien ban, muc) phai co it nhat 1 tai trong doc dung (xac nhan bang so khoi/ECC khop bo giai ma that)
combo_ok = {}
tries_ok = tries_all = 0
for (v, e, s_), rr in zip(full, res):
    key = (v, e)
    if combo_ok.get(key):
        continue
    tries_all += 1
    if cv_known(rr[3], 6 if v > 25 else 8) == s_:
        combo_ok[key] = True
        tries_ok += 1
    else:
        combo_ok.setdefault(key, False)
missing = sorted(k for k, ok in combo_ok.items() if not ok)
check("OpenCV (bo giai ma QR that, doc lap) doc DUNG it nhat 1 tai trong o MOI mot trong 160 to hop phien ban x muc", not missing, "khong giai ma duoc: %s" % missing[:10])
check("ty le doc dung cua OpenCV >= 70%% so lan thu (%d/%d lan; hon 30%% = bo giai ma OpenCV tu no hay lo, khong phai ma sai)" % (tries_ok, tries_all), tries_ok >= 0.7 * tries_all)

# tinh doc lap cua ma hop le: thu ca 32 to hop (4 muc x 8 mat na). Luu y: da thuc sinh Reed-Solomon LONG NHAU (g10 chia het cho g7) nen ma ECC cao
# cung "hop le" voi muc thap hon - vi vay khang dinh: mat na la DUY NHAT, to hop that co mat, va KHONG co muc ECC CAO HON muc that hop le.
uniq_bad = []
seen = set()
for (v, e, s_), rr in zip(full, res):
    if v in (1, 7, 14, 25, 40) and (v, e) not in seen:
        seen.add((v, e))
        fc = md.valid_combos(rr[3], v, ECC_TBL, BLK_TBL)
        true_e = LEVELS.index(e)
        ok = (any(a_ == true_e and b_ == rr[2] and c_ == s_.encode() for a_, b_, c_ in fc)
              and all(b_ == rr[2] for a_, b_, c_ in fc)
              and max(a_ for a_, b_, c_ in fc) == true_e)
        if not ok:
            uniq_bad.append((v, e, [(a_, b_) for a_, b_, _ in fc]))
check("thu ca 32 to hop (4 muc x 8 mat na) tren 20 ma: mat na DUY NHAT, to hop that co mat, khong muc ECC cao hon hop le", not uniq_bad, str(uniq_bad[:3]))

# tai trong khong phai chu in duoc: byte bat ky (0x00..0xFF) o nhieu do dai
rnd3 = random.Random(3)
arb = []
for v_len in (0, 1, 2, 13, 14, 15, 40, 100, 254, 255, 256, 300, 1000):
    for e in LEVELS:
        arb.append((e, bytes(rnd3.randrange(256) for _ in range(v_len)), "noboost"))
ra = dump(arb)
arb_bad = [(c[0], len(c[1])) for c, x in zip(arb, ra) if x is None or md.try_decode(x[3], x[1], LEVELS.index(x[0]), x[2], ECC_TBL, BLK_TBL) != c[1]]
check("byte bat ky (ke ca 0x00, 0xFF) o 13 do dai x 4 muc (gom ranh gioi dem ky tu 255/256): doc lai DUNG tung byte", not arb_bad, str(arb_bad[:5]))

over = [(v, e) for v in (1, 5, 9, 10, 20, 39) for e in ("LOW", "HIGH")]
ro = dump([(e, ("x" * (caps[(v, e)] + 1)).encode(), "noboost") for v, e in over])
check("them 1 byte vuot dung luong -> len dung phien ban ke tiep (ca ranh gioi dem ky tu 8->16 bit o v9/v10)", all(r_ and r_[1] == v + 1 for (v, e), r_ in zip(over, ro)), str([(o, r_ and r_[1]) for o, r_ in zip(over, ro)]))
rbig = dump([("LOW", b"x" * 2954), ("LOW", b"x" * 2953)])
check("2954 byte -> null (giao dien rut ve 'chi sao chep'), 2953 byte vua v40", rbig[0] is None and rbig[1] is not None and rbig[1][1] == 40)
re_ = dump([("MEDIUM", b"")])
check("chuoi rong: sinh ma v1 hop le (khong nem loi)", re_[0] is not None and re_[0][1] == 1)

# ---------------------------------------------------------------- 5. sua loi THAT (Reed-Solomon) bang OpenCV khi biet 4 goc
rnd2 = random.Random(7)
url = "https://quiet-river-1234.trycloudflare.com/wp-admin/"
rr = dump([(e, url.encode(), "noboost") for e in LEVELS])
recovered = {}
FLIPS = {"LOW": 6, "MEDIUM": 8, "QUARTILE": 8, "HIGH": 8}
for x in rr:
    ecc, ver, mask, m = x
    n = m.shape[0]
    ok_cnt = 0
    for trial in range(10):
        mm = m.copy()
        done = 0
        while done < FLIPS[ecc]:
            y, x_ = rnd2.randrange(10, n - 10), rnd2.randrange(10, n - 10)
            if y == 6 or x_ == 6:
                continue
            mm[y, x_] ^= 1
            done += 1
        if cv_known(mm, 8) == url:
            ok_cnt += 1
    recovered[ecc] = ok_cnt
check("sua loi Reed-Solomon that: lat 6-8 module du lieu ngau nhien van doc DUNG (>= 9/10 lan moi muc)", all(v >= 9 for v in recovered.values()), str(recovered))
# doi chung am 1: bo giai ma ma tran phai TU CHOI ma bi lat 1 module (chung to no khong de dai)
x0 = rr[1]
mm = x0[3].copy()
mm[15, 15] ^= 1
check("doi chung am: bo giai ma ma tran TU CHOI ma bi lat 1 module (syndrome khac 0)", md.try_decode(mm, x0[1], 1, x0[2], ECC_TBL, BLK_TBL) is None)
# doi chung am 2: sai bang so khoi (gia lap loi go bang) -> bo giai ma ma tran phat hien
bad_blk = [row[:] for row in BLK_TBL]
v6 = [r for r in dump([("MEDIUM", ("x" * caps[(6, "MEDIUM")]).encode(), "noboost")])][0]
bad_blk[1][6] = 3
check("doi chung am: neu bang so khoi sai (v6-M 3 thay vi 4 khoi) thi ma hop le bi TU CHOI (kiem tra co nhay voi bang)", md.try_decode(v6[3], 6, 1, v6[2], ECC_TBL, bad_blk) is None and md.try_decode(v6[3], 6, 1, v6[2], ECC_TBL, BLK_TBL) is not None)
# doi chung am 3: pha nat 40% module -> OpenCV khong doc ra chuoi goc
mm = rr[1][3].copy()
nn = mm.shape[0]
for _ in range(int(nn * nn * 0.4)):
    mm[rnd2.randrange(nn), rnd2.randrange(nn)] ^= 1
check("doi chung am: ma bi pha 40% module KHONG giai ra chuoi goc (bo giai ma khong 'doan bua')", cv_known(mm, 8) != url)

# ---------------------------------------------------------------- 5b. hinh hoc cua QrDrawable (cell khong nguyen) -> van doc duoc
import math


def jround(x):  # Math.round cua Java (lam tron nua len)
    return int(math.floor(x + 0.5))


def draw_like_drawable(m, side, quiet=4):
    """Mo phong DUNG thuat toan QrDrawable.draw: nen trang, cac doan module toi lien nhau ve thanh 1 hinh chu nhat, bien lam tron cung cong thuc."""
    n = m.shape[0]
    total = n + 2 * quiet
    cell = side / total
    img = np.full((side, side), 255, dtype=np.uint8)
    for y in range(n):
        x = 0
        while x < n:
            if not m[y][x]:
                x += 1
                continue
            start = x
            while x < n and m[y][x]:
                x += 1
            left, right = jround((start + quiet) * cell), jround((x + quiet) * cell)
            top, bottom = jround((y + quiet) * cell), jround((y + quiet + 1) * cell)
            img[top:bottom, left:right] = 0
    return img


geo_bad = []
geo_pipe = 0
geo_total = 0
for e, sample in (("MEDIUM", "https://quiet-river-1234.trycloudflare.com"), ("MEDIUM", "http://192.168.1.23:8080/"), ("MEDIUM", "https://example.com/duong-dan/co-dau/bai-viet?id=42&ref=qr#phan-2")):
    q = dump([(e, sample.encode(), "noboost")])[0]
    n = q[3].shape[0]
    for side in (4 * (n + 8) + 1, 300, 337, 411, 512, 640, 719):
        total = n + 8
        img = draw_like_drawable(q[3], side)
        scale = side / total
        a, b = 4 * scale, (4 + n) * scale
        pts = np.array([[[a, a], [b, a], [b, b], [a, b]]], dtype=np.float32)
        geo_total += 1
        if det.decode(img, pts)[0] != sample:
            geo_bad.append((sample[:20], side))
        if det.detectAndDecode(img)[0] == sample:
            geo_pipe += 1
# Hop thoai that >= 280 dp (>= 560 px o 2x) tuc >= 10 px/module voi URL thuong gap; moc 4 px/module la can duoi khac nghiet (3 px: OpenCV bat dau lo do ranh gioi lam tron +-0,5 px, khong phai loi ma)
check("QrDrawable: hinh hoc ve (cell khong nguyen, bien lam tron) van doc DUNG o %d kich thuoc x 3 URL (7 kich thuoc tu 4 px/module den ~16 px/module)" % 7, not geo_bad, str(geo_bad[:5]))
check("QrDrawable: duong day day du (do tim + giai ma) doc dung >= 70%% (%d/%d)" % (geo_pipe, geo_total), geo_pipe >= 0.7 * geo_total)

# ---------------------------------------------------------------- 6. noi day giao dien (tinh)
ma = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/MainActivity.kt"), encoding="utf-8").read()
qd_path = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/QrDrawable.kt")
check("QrDrawable.kt ton tai (ve crisp bang Canvas, khong Bitmap/phu thuoc)", os.path.exists(qd_path))
if os.path.exists(qd_path):
    qd = open(qd_path, encoding="utf-8").read()
    check("QrDrawable ve nen TRANG + module DEN co dinh (khong theo giao dien toi - may quet can tuong phan)", "Color.WHITE" in qd and "Color.BLACK" in qd)
    check("QrDrawable chua vung yen (quiet zone) >= 4 module theo dac ta", re.search(r"quietModules:\s*Int\s*=\s*4", qd) is not None)
check("MainActivity: shareUrl hien hop thoai co QR (QrCode.encodeText + QrDrawable)", "QrCode.encodeText(" in ma and "QrDrawable(" in ma)
check("MainActivity: rut ve chia se/sao chep khi khong ma hoa duoc (null)", re.search(r"QrCode\.encodeText\([^)]*\)\s*\?:|qr\s*==\s*null|qr\s*!=\s*null", ma) is not None)
vi = open(os.path.join(ROOT, "app/src/main/res/values/strings.xml"), encoding="utf-8").read()
en = open(os.path.join(ROOT, "app/src/main/res/values-en/strings.xml"), encoding="utf-8").read()
for name in ("qr_dialog_title", "qr_content_desc", "qr_too_long", "btn_copy_link", "toast_link_copied"):
    check("chuoi '%s' co o CA vi va en" % name, ('name="%s"' % name) in vi and ('name="%s"' % name) in en)
check("QR co contentDescription cho TalkBack (J8)", "qr_content_desc" in ma and "contentDescription" in ma)

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
