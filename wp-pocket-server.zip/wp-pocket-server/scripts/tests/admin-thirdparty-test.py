#!/usr/bin/env python3
"""Kiem thu CONG BAO VE (inject_auth_guard) cua Adminer va Tiny File Manager THAT - xem HANDOFF.md muc 1aw.
Tai 2 cong cu tu GitHub (nhu build that), chay DUNG cac buoc build: scripts/lib/inject_require.php roi
sed 'use_auth = false' (TFM), cai vao _admin/ cua fixture roi tan cong bang php -S that.
Neu khong tai duoc (khong co mang) -> bo qua, exit 0. Chay: python3 scripts/tests/admin-thirdparty-test.py
"""
import importlib.util, os, re, shutil, subprocess, sys, tempfile, time, socket, urllib.request, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
INJECT = os.path.normpath(os.path.join(HERE, '..', 'lib', 'inject_require.php'))
check = sec.check

def fetch(urls, dest):
    for u in urls:
        try:
            data = urllib.request.urlopen(u, timeout=60).read()
            if len(data) > 100000:
                open(dest, 'wb').write(data); return u
        except Exception:
            pass
    return None

def follow(c, path, hops=4):
    """GET va theo Location (TFM tra 302 ve ?p= truoc khi hien trang; Client khong tu theo)."""
    sc, body, loc = c.req('GET', path)
    while sc in (301, 302, 303) and loc and hops > 0:
        sc, body, loc = c.req('GET', urllib.parse.urlparse(loc).path + (('?' + urllib.parse.urlparse(loc).query) if urllib.parse.urlparse(loc).query else ''))
        hops -= 1
    return sc, body

def main():
    tmp = tempfile.mkdtemp(prefix='tp-')
    try:
        dl = os.path.join(tmp, 'dl'); os.makedirs(dl)
        # 1bc: test DUNG BAN GHIM trong scripts/lib/pins.env (khong con "master"/phien ban doan) va kiem SHA256 nhu build that.
        pins = {}
        for l in open(os.path.join(HERE, '..', 'lib', 'pins.env'), encoding='utf-8'):
            m = re.match(r'^([A-Z0-9_]+)=("?)(.*)\2$', l.strip())
            if m: pins[m.group(1)] = re.sub(r'\$\{(\w+)\}', lambda x: pins.get(x.group(1), ''), m.group(3))
        u1 = fetch([pins['ADMINER_URL']], os.path.join(dl, 'db.php'))
        u2 = fetch([pins['TFM_URL']], os.path.join(dl, 'files.php'))
        import hashlib
        for nm, key in (('db.php', 'ADMINER_SHA256'), ('files.php', 'TFM_SHA256')):
            fp = os.path.join(dl, nm)
            if os.path.exists(fp):
                check('ban ghim %s dung SHA256 trong pins.env' % nm, hashlib.sha256(open(fp, 'rb').read()).hexdigest() == pins[key])
        if not (u1 and u2):
            print('(bo qua: khong tai duoc Adminer/Tiny File Manager - khong co mang toi GitHub)'); return 0
        print('Adminer: %s\nTFM:     %s' % (u1.rsplit('/', 1)[-1], u2.rsplit('/', 1)[-1]))
        base = os.path.join(tmp, 'site'); os.makedirs(base)
        app, run, www, adm = sec.build_tree(base)
        for f in ('db.php', 'files.php'):
            shutil.copy(os.path.join(dl, f), os.path.join(adm, f))
            r = subprocess.run(['php', INJECT, os.path.join(adm, f)], capture_output=True, text=True)
            check('inject_require.php gan cong bao ve vao %s (rc=0)' % f, r.returncode == 0, r.stdout + r.stderr)
        if os.environ.get('TP_NO_ISOLATION'):  # DOI CHUNG AM: mo phong cong CU (chi require auth.php, khong tach phien)
            for f in ('db.php', 'files.php'):
                fp = os.path.join(adm, f); x = open(fp, 'rb').read()  # Adminer dong goi KHONG phai UTF-8 hop le -> bytes
                open(fp, 'wb').write(x.replace(b' wp_pocket_isolate_tool_session(__FILE__);', b''))
            print('(DOI CHUNG AM: dang chay voi cong CU - khong tach phien)')
        t = open(os.path.join(adm, 'files.php'), encoding='utf-8').read()
        open(os.path.join(adm, 'files.php'), 'w', encoding='utf-8').write(t.replace('use_auth = true;', 'use_auth = false;'))  # y het sed trong admin_tools.sh
        check('ca 2 file van la PHP hop le sau khi gan cong', all(subprocess.run(['php', '-l', os.path.join(adm, f)], capture_output=True).returncode == 0 for f in ('db.php', 'files.php')))
        victim = os.path.join(www, 'victim.txt'); open(victim, 'w').write('VICTIM-DATA')

        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(base, 'sess'),
                                '-d', 'auto_prepend_file=' + os.path.join(base, 'spoof.php'), '-d', 'display_errors=1', '-d', 'error_reporting=E_ALL',
                                '-d', 'upload_max_filesize=2M'],
                               env=dict(os.environ, APP_HOME=app), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
                except OSError: time.sleep(0.1)
            UI = {'db': re.compile(r'Adminer|adminer', re.I), 'files': re.compile(r'Tiny File Manager|tinyfilemanager|H3K', re.I)}
            pages = {'db': '/_admin/db.php', 'files': '/_admin/files.php'}

            print('== 1. gioi han IP ==')
            for k, path in pages.items():
                bad = []
                for ip in ('8.8.8.8', '127.0.0.1', '172.32.0.1', '::1', ''):
                    sc, body, _ = sec.Client(port, ip).req('GET', path)
                    if sc != 403 or UI[k].search(body): bad.append((ip, sc))
                check('%s: IP ngoai LAN bi 403, khong lo giao dien' % k, not bad, bad)

            print('== 2. chua dang nhap: KHONG duoc thay giao dien cong cu (ke ca cac duong dan phu) ==')
            anon = sec.Client(port, '10.0.0.9')
            probes = {
                'db': ['', '?server=127.0.0.1&username=root', '?file=default.css', '?script=version', '?username=', '?sqlite=&db=x', '?server=http://169.254.169.254/'],
                'files': ['', '?p=', '?p=..%2f..%2f', '?dl=wp-config.php', '?img=x.png', '?view=victim.txt', '?edit=victim.txt', '?p=&del=victim.txt', '?upload', '?help=1', '?phpinfo=1'],
            }
            for k, qs in probes.items():
                leaks = []
                for q in qs:
                    sc, body, _ = anon.req('GET', pages[k] + q)
                    if 'admin_password' not in body or UI[k].search(body.replace('admin_password', '')) and 'Dang nhap quan tri' not in body:
                        leaks.append((q, sc))
                check('%s: %d duong dan phu chi tra ve form dang nhap cua ta' % (k, len(qs)), not leaks, leaks[:3])
            sc, body, _ = anon.req('POST', pages['files'], {'fm_usr': 'admin', 'fm_pwd': 'admin@123', 'p': '', 'del': 'victim.txt', 'token': 'x'})
            check('files: thu tai khoan mac dinh TFM admin/admin@123 + xoa file khi chua dang nhap -> van chi form cua ta', 'admin_password' in body and os.path.exists(victim))
            check('files: victim.txt van con nguyen (khong ai xoa duoc khi chua dang nhap)', os.path.exists(victim))

            print('== 3. da dang nhap ==')
            c = sec.Client(port, '10.2.2.2'); c.login()
            for k in ('db', 'files'):
                sc, body = follow(c, pages[k])
                fatal = sec.FATAL_RE.search(body)
                check('%s: DOI CHUNG DUONG - nguoi dung hop le thay giao dien cong cu that' % k, sc == 200 and UI[k].search(body) and not fatal, (sc, body[:100]))
            sc, body, _ = c.req('GET', '/_admin/files.php?p=')
            check('files: use_auth=false co hieu luc (khong hien man hinh dang nhap rieng cua TFM voi tai khoan mac dinh)',
                  'fm_usr' not in body and 'fm_pwd' not in body, body[:100])

            print('== 4. CSRF cua Tiny File Manager (xoa file) ==')
            c.req('GET', '/_admin/files.php?p=&del=victim.txt')
            check('GET ?del=... KHONG xoa file (CSRF bang the <img>)', os.path.exists(victim))
            c.req('POST', '/_admin/files.php?p=&del=victim.txt', {'token': 'sai' * 10})
            c.req('POST', '/_admin/files.php?p=&del=victim.txt')
            check('POST thieu/sai token KHONG xoa file', os.path.exists(victim))
            _, page = follow(c, '/_admin/files.php?p=')
            m = (re.search(r'name="token"\s+value="([^"]+)"', page) or re.search(r"csrf\s*[:=]\s*['\"]([^'\"]+)['\"]", page)
                 or re.search(r'token["\']?\s*[:=]\s*["\']([0-9a-f]{20,})["\']', page))
            if m:
                c.req('POST', '/_admin/files.php?p=&del=victim.txt', {'token': m.group(1)})
                check('DOI CHUNG DUONG: co token that thi xoa duoc (test co kha nang phat hien)', not os.path.exists(victim))
                if os.path.exists(victim):
                    print('INFO: token trich duoc %r nhung xoa that bai; cac chuoi "token" trong trang:' % m.group(1)[:30])
                    for mm in list(re.finditer(r'.{0,50}token.{0,70}', page))[:6]: print('   ', mm.group(0).replace('\n', ' ')[:130])
            else:
                print('INFO: khong trich duoc token CSRF tu trang TFM (phien ban moi doi cach nhung) - bo qua doi chung duong')

            print('== 5. Adminer va TFM KHONG giam len phien cua nhau (HANDOFF.md muc 1aw) ==')
            fatals = []
            for i in range(12):  # xac suat chuoi hex 64 ky tu bat dau bang chu cai = 37,5%/phien -> 12 phien: loi gan nhu chac chan neu con
                cc = sec.Client(port, '10.%d.1.1' % (40 + i)); cc.login()
                follow(cc, '/_admin/files.php?p=')
                sc, body = follow(cc, '/_admin/db.php')
                if sec.FATAL_RE.search(body) or 'Unsupported operand' in body: fatals.append(i)
            check('mo TFM roi Adminer trong 12 phien moi: Adminer KHONG Fatal (truoc khi tach phien: ~4/10 phien sap)', not fatals, fatals)
            ok_all = True
            for i in range(3):
                vp = os.path.join(www, 'victimB%d.txt' % i); open(vp, 'w').write('x')
                cc = sec.Client(port, '10.%d.2.2' % (60 + i)); cc.login()
                follow(cc, '/_admin/db.php')
                _, pg = follow(cc, '/_admin/files.php?p=')
                mt = re.search(r'name="token"\s+value="([^"]+)"', pg)
                cc.req('POST', '/_admin/files.php?p=&del=victimB%d.txt' % i, {'token': mt.group(1) if mt else ''})
                if os.path.exists(vp): ok_all = False
            check('mo Adminer roi TFM: hanh dong POST cua TFM (xoa file voi token that) HOAT DONG (truoc day: 500 ca 3/3 lan)', ok_all)
            cc = sec.Client(port, '10.80.3.3'); cc.login(); follow(cc, '/_admin/files.php?p=')
            check('co cookie phien rieng cua cong cu (wpp_files) tach khoi phien cong (PHPSESSID)', 'wpp_files' in cc.jar and 'PHPSESSID' in cc.jar and cc.jar['wpp_files'] != cc.jar['PHPSESSID'], list(cc.jar))
            # ---- 1bd: POST toi Adminer (SQL do nguoi dung chay) phai bao hieu cache APCu (object-cache-epoch) ----
            ep = os.path.join(run, 'object-cache-epoch')
            rd = lambda: open(ep).read() if os.path.exists(ep) else None
            dc = sec.Client(port, '10.90.4.4'); dc.login(); follow(dc, '/_admin/db.php')    # dang nhap + mo Adminer (GET)
            check('1bd: GET db.php (xem Adminer) KHONG bump epoch (khong xoa cache vo ich)', rd() is None, rd())
            sec.Client(port, '10.90.5.5').req('POST', '/_admin/db.php', {'auth[driver]': 'server', 'auth[server]': 'x', 'auth[username]': 'u', 'auth[password]': 'p'})
            check('1bd: POST CHUA dang nhap _admin/ KHONG bump epoch (khach la khong the kich hoat xoa cache)', rd() is None, rd())
            dc.req('POST', '/_admin/db.php', {'auth[driver]': 'server', 'auth[server]': 'x', 'auth[username]': 'u', 'auth[password]': 'p'})
            first = rd()
            check('1bd: POST DA dang nhap toi Adminer THAT 6.1.2 -> bump epoch (sua wp_options bang SQL se khong lam site hien cu)', first not in (None, ''), first)
            dc.req('POST', '/_admin/db.php', {'auth[driver]': 'server', 'auth[server]': 'x', 'auth[username]': 'u', 'auth[password]': 'p'})
            check('1bd: moi POST bump chuoi MOI (object-cache.php nhan ra de xoa lai)', rd() != first and rd() not in (None, ''))
            before = rd(); follow(dc, '/_admin/files.php?p='); dc.req('POST', '/_admin/files.php?p=', {'token': 'x'})
            check('1bd: POST toi Tiny File Manager (khong phai Adminer) KHONG bump epoch', rd() == before)
        finally:
            srv.terminate()
            try: srv.wait(timeout=5)
            except Exception: srv.kill()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL)); return 0 if sec.FAIL == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
