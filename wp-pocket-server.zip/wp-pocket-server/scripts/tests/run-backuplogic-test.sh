#!/bin/sh
# Chay kiem thu JVM cho BackupLogic.kt (can kotlinc + java). Khong can Android SDK. Xem HANDOFF.md muc 1az.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/BackupLogic.kt" "$HERE/BackupLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" BackupLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
