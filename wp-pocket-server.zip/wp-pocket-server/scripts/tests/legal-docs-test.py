#!/usr/bin/env python3
"""Y3, Y7, Y5 (PDF 2) + dinh huong 'phat hanh mien phi cho nguoi kiem thu truoc' (HANDOFF.md muc 1bq-F): kiem chung tai lieu phap ly/thu nghiem.

Khong the kiem "dung phap luat" bang may: bai nay kiem (1) moi dau moi tai lieu co ghi dung so van ban/ngay tra cuu va KHONG ket luan thay luat su,
(2) cac su that ve ung dung (thuat toan mat ma, quyen, thanh phan GPL) KHOP voi ma nguon, (3) cac tai lieu khong mau thuan nhau (TERMS - LICENSE_OPTIONS -
THIRD_PARTY_NOTICES - PRIVACY), (4) moi duong dan tham chieu ton tai, (5) mau bao cao beta hop le va bat buoc xac nhan da che thong tin.
"""
import glob, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def rd(p):
    return open(os.path.join(ROOT, p), encoding="utf-8").read()


legal, terms, lic, priv, beta, third = rd("docs/LEGAL_NOTES_VN.md"), rd("TERMS.md"), rd("docs/LICENSE_OPTIONS.md"), rd("PRIVACY.md"), rd("docs/BETA_PROGRAM.md"), rd("THIRD_PARTY_NOTICES.md")

# ---------------------------------------------------------------- 1. LEGAL_NOTES_VN: so van ban, ngay tra cuu, khong ket luan thay luat su
for tok in ("91/2025/QH15", "356/2025/NĐ-CP", "13/2023/NĐ-CP", "341/2026/NĐ-CP", "211/2025/NĐ-CP", "01/01/2026", "Luật An ninh mạng 2025", "27/10/2026"):
    check("LEGAL_NOTES nhac '%s'" % tok, tok in legal)
check("LEGAL_NOTES noi ro Nghi dinh 356 THAY THE Nghi dinh 13/2023 va PDF da cu", re.search(r"thay thế Nghị định 13/2023", legal) and "đã **cũ**" in legal)
check("LEGAL_NOTES ghi 'KHONG phai tu van phap ly' o dau tai lieu", "KHÔNG phải tư vấn pháp lý" in legal.split("\n")[2] or "KHÔNG phải tư vấn pháp lý" in legal[:400])
check("LEGAL_NOTES ghi nguon (hang luat/cong van ban) cho moi muc", legal.count("Nguồn:") >= 3)
check("LEGAL_NOTES NOI THANG cac nguon ve EAR mau thuan nhau (bis.gov va Jones Day), khong chon thay", "bis.gov" in legal and "Jones Day" in legal and "mâu thuẫn" in legal)
check("LEGAL_NOTES co 'Cau hoi mo' ve Phu luc I/II va canh bao KHONG tu suy ra 'khong can'", "Câu hỏi mở" in legal and "Phụ lục I/II" in legal and "không** nên tự suy ra" in legal)
bad_phr = [p for p in ("chắc chắn không cần", "không cần xin giấy phép", "được miễn trừ hoàn toàn", "hoàn toàn hợp pháp", "đảm bảo tuân thủ") if p in legal]
check("LEGAL_NOTES khong ket luan thay luat su (khong co cau kieu 'khong can giay phep'/'hoan toan hop phap')", not bad_phr, bad_phr)
check("LEGAL_NOTES co danh sach cau hoi cho luat su (>= 5 cau)", len(re.findall(r"^\d\. ", legal.split("## C.")[1], re.M)) >= 5)

# ---------------------------------------------------------------- 2. su that ve ung dung khop ma nguon
kt = {os.path.basename(p): open(p, encoding="utf-8", errors="replace").read() for p in glob.glob(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/*.kt"))}
ciphers = set()
for src in kt.values():
    ciphers |= set(re.findall(r'Cipher\.getInstance\("([^"]+)"\)', src))
check("mat ma duy nhat app tu goi la AES/GCM/NoPadding (LEGAL_NOTES B1 noi dung)", ciphers == {"AES/GCM/NoPadding"}, ciphers)
check("PBKDF2WithHmacSHA256 co trong BackupManager.kt, Android Keystore trong SecretStore.kt (khop LEGAL_NOTES B1)", "PBKDF2WithHmacSHA256" in kt["BackupManager.kt"] and "AndroidKeyStore" in kt["SecretStore.kt"] and "SecretCodec.kt" in legal and "SecretStore.kt" in legal)
check("khong co SDK phan tich/quang cao/bao cao su co tu xa trong build.gradle (khop PRIVACY + LEGAL_NOTES A2)", not re.search(r"firebase|crashlytics|sentry|admob|appsflyer|mixpanel|amplitude|analytics", rd("app/build.gradle.kts"), re.I))
manifest = rd("app/src/main/AndroidManifest.xml")
perms = set(re.findall(r'uses-permission android:name="android\.permission\.([A-Z_]+)"', manifest))
check("quyen khai bao trong Manifest KHONG co danh ba/vi tri/camera/micro/bo nho chung (PRIVACY muc 1)", not (perms & {"READ_CONTACTS", "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "CAMERA", "RECORD_AUDIO", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE", "MANAGE_EXTERNAL_STORAGE"}), perms)
check('allowBackup="false" (PRIVACY muc 1)', 'android:allowBackup="false"' in manifest)

# ---------------------------------------------------------------- 3. TERMS / LICENSE_OPTIONS / THIRD_PARTY nhat quan
t7 = terms.split("7. **Giai đoạn thử nghiệm miễn phí (beta).**")[1] if "7. **Giai đoạn thử nghiệm miễn phí (beta).**" in terms else ""
check("TERMS co dieu 7 beta", bool(t7))
for tok in ("miễn phí", "không độc quyền", "có thể thu hồi", "[TÊN CHỦ BẢN QUYỀN] © [NĂM]", "giấy phép riêng", "không bị hạn chế", "mất dữ liệu", "ngoài điện thoại", "tự nguyện", "không hứa", "CHỦ DỰ ÁN QUYẾT"):
    check("TERMS dieu 7 co '%s'" % tok, tok in t7)
check("TERMS dieu 7 ghi 'quyen chi ap dung cho phan ma do du an tu viet' va nhac MariaDB/Tiny File Manager/WordPress (GPL khong bi han che)", "chỉ áp dụng cho phần mã do dự án tự viết" in t7 and all(x in t7 for x in ("MariaDB", "Tiny File Manager", "WordPress")))
has_license = os.path.exists(os.path.join(ROOT, "LICENSE"))
check("khong co tep LICENSE <=> TERMS van ghi 'Chua duoc chon' (khong mau thuan)", has_license == ("Chưa được chọn" not in terms))
check("THIRD_PARTY_NOTICES goi MariaDB GPL v2, Tiny File Manager GPL v3, WordPress GPL: cung bo voi LICENSE_OPTIONS", all(x in third for x in ("MariaDB", "Tiny File Manager", "WordPress")) and all(x in lic for x in ("MariaDB (GPL v2)", "Tiny File Manager (GPL v3)", "WordPress (GPL v2 trở lên)")))
check("LICENSE_OPTIONS ghi dinh huong cua chu du an (mien phi thu nghiem truoc, tinh phi sau) va ngay 27/10/2026", "Định hướng chủ dự án đã nêu (27/10/2026)" in lic and "phát hành miễn phí" in lic and "người kiểm thử" in lic and "tính phí" in lic)
sect = lic.split("## Hiện trạng")[0]
check("LICENSE_OPTIONS phan tich du 4 lua chon theo dinh huong (bao luu quyen + dung thu / MIT-Apache / GPL-AGPL / source-available) va KHONG chon thay", all(x in sect for x in ("bảo lưu mọi quyền", "MIT / Apache-2.0", "GPL-3.0 / AGPL-3.0", "Source-available")) and "không chọn giấy phép thay bạn" in sect)
check("LICENSE_OPTIONS liet ke viec chu du an con phai quyet (ai tra phi, ban beta da tai, ten chu ban quyen, nguon GPL)", all(x in sect for x in ("ai", "bản beta đã tải", "tên chủ bản quyền", "mã nguồn các thành phần GPL")))
check("LICENSE_OPTIONS tro toi LEGAL_NOTES_VN va TERMS dieu 7", "docs/LEGAL_NOTES_VN.md" in sect and "TERMS.md" in sect)

# ---------------------------------------------------------------- 4. PRIVACY cap nhat
for tok in ("quy tắc tuỳ chỉnh", "khôi phục bị gián đoạn", "restore-in-progress", "wppocket", "Giai đoạn thử nghiệm", "BETA_PROGRAM.md", "LEGAL_NOTES_VN.md"):
    check("PRIVACY nhac '%s'" % tok, tok in priv)

# ---------------------------------------------------------------- 5. BETA_PROGRAM + mau bao cao
for tok in ("không có bảo đảm", "Đừng dùng cho website quan trọng", "ngoài điện thoại", "Bot Token Telegram", "admin-password.txt", "wp-config.php", "chưa mã hoá", "chưa quyết", "kênh báo cáo do chủ dự án chọn", "24 giờ"):
    check("BETA_PROGRAM co '%s'" % tok, tok.lower() in beta.lower())
tpl = rd(".github/ISSUE_TEMPLATE/beta-report.yml")
try:
    import yaml
    y = yaml.safe_load(tpl)
    ids = [b.get("id") for b in y["body"] if b.get("id")]
    chk = [b for b in y["body"] if b.get("id") == "redacted"][0]
    req = {b["id"] for b in y["body"] if b.get("validations", {}).get("required")}
    check("mau bao cao beta: YAML hop le, co du truong (phien ban, may, runtime, muc nghiem trong, mo ta, nhat ky)", {"version", "device", "runtime", "severity", "what", "logs"} <= set(ids) and y["labels"] == ["beta"])
    check("mau bao cao: BAT BUOC xac nhan da che token/IP/mat khau (checkbox required)", chk["attributes"]["options"][0].get("required") is True and {"version", "device", "runtime", "severity", "what"} <= req)
except ImportError:
    check("mau bao cao beta (khong co PyYAML: kiem van ban)", "required: true" in tpl and "che token" in tpl and 'labels: ["beta"]' in tpl)

# ---------------------------------------------------------------- 6. duong dan tham chieu ton tai
missing = []
for name in ("docs/LEGAL_NOTES_VN.md", "docs/BETA_PROGRAM.md", "docs/LICENSE_OPTIONS.md", "TERMS.md", "PRIVACY.md"):
    for m in re.finditer(r"`([A-Za-z0-9_./-]+\.(?:md|py|sh|yml|kt|json))`", rd(name)):
        p = m.group(1)
        if "/" in p or p.endswith(".md"):
            cand = [os.path.join(ROOT, p), os.path.join(ROOT, "docs", p)]
            if not any(os.path.exists(c) for c in cand) and p not in ("LICENSE", "admin-password.txt", "wp-config.php", "admin-audit.log", "admin-sessions.json", "site.config.json", "THIRD_PARTY_NOTICES.md", "README.md"):
                missing.append((name, p))
check("moi duong dan tham chieu trong 5 tai lieu deu ton tai trong repo", not missing, missing[:6])

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
