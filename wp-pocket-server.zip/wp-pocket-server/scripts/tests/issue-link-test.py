#!/usr/bin/env python3
"""K5 (PDF 1; HANDOFF.md muc 1br): kiem chung lien ket 'Bao loi' (IssueLink) - Java that (ban sat nguyen ban) phan tich bang urllib.parse + noi day tinh + khop mau Issue."""
import os, re, subprocess, sys, urllib.parse

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
K = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/")
J = os.path.join(ROOT, "scripts/tests/java/IssueLinkPort.java")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def rd(p):
    return open(p, encoding="utf-8").read()


kt, jv, la, ul = rd(K + "IssueLink.kt"), rd(J), rd(K + "LogViewerActivity.kt"), rd(K + "UpdateLogic.kt")
check("IssueLink.kt thuan: khong import android.*", re.search(r"^import android", kt, re.M) is None)
check("hang so TEMPLATE/LABEL/TITLE_PREFIX/MAX_VALUE giong het Kotlin va Java", all(x in kt and x in jv for x in ('TEMPLATE = "beta-report.yml"', 'LABEL = "beta"', 'TITLE_PREFIX = "[beta] "', "MAX_VALUE = 100")))
check("Java dung CHINH XAC regex repo cua UpdateLogic.kt (so sanh nguyen van mau)", (lambda k, j_: k is not None and j_ is not None and k.group(1).replace("\\\\", "\\") == j_.group(1).replace("\\\\", "\\"))(re.search(r'REPO\s*=\s*Regex\("((?:[^"\\\\]|\\\\.)*)"\)', ul), re.search(r'REPO = Pattern\.compile\("((?:[^"\\\\]|\\\\.)*)"\)', jv)))

try:
    mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception:
    mods = ""
if "jdk.compiler" in mods:
    def run(repo, version, device):
        r = subprocess.run(["java", J, repo, version, device], capture_output=True, text=True, timeout=60)
        return r.stdout.strip()

    u = run("owner/WPPocketServer", "1.2.3", "Xiaomi Redmi 9, Android 12")
    p = urllib.parse.urlparse(u)
    q = urllib.parse.parse_qs(p.query, keep_blank_values=True)
    check("URL dung: https://github.com/<repo>/issues/new, dung 5 tham so (template, labels, title, version, device)", p.scheme == "https" and p.netloc == "github.com" and p.path == "/owner/WPPocketServer/issues/new" and sorted(q) == ["device", "labels", "template", "title", "version"], u)
    check("gia tri khop mau Issue: template=beta-report.yml, labels=beta, title='[beta] ', version/device giu nguyen", q["template"] == ["beta-report.yml"] and q["labels"] == ["beta"] and q["title"] == ["[beta] "] and q["version"] == ["1.2.3"] and q["device"] == ["Xiaomi Redmi 9, Android 12"], q)
    # id cua truong trong mau Issue phai co 'version' va 'device' (GitHub dien san theo id)
    tpl = rd(os.path.join(ROOT, ".github/ISSUE_TEMPLATE/beta-report.yml"))
    try:
        import yaml
        y = yaml.safe_load(tpl)
        ids = {b.get("id") for b in y["body"] if b.get("id")}
        tname_ok = os.path.exists(os.path.join(ROOT, ".github/ISSUE_TEMPLATE/beta-report.yml")) and y["labels"] == ["beta"] and y["title"] == "[beta] "
        check("mau Issue co truong id 'version' va 'device' (de GitHub dien san), nhan 'beta' va tieu de '[beta] ' dung IssueLink", {"version", "device"} <= ids and tname_ok, ids)
    except ImportError:
        check("mau Issue co id version/device (khong co PyYAML: kiem van ban)", "id: version" in tpl and "id: device" in tpl)

    # an toan: moi dau vao la khong duoc phep them tham so / pha cau truc
    nasty = ["a&template=evil", "a#frag", "a%00b", "a\nb=c", "x" * 500, "tiếng Việt ăâêôơư 😀", "a=b&c=d", "?evil=1", "../../x", " " * 5 + "pad" + " " * 5, "a\tb\rc"]
    bad = []
    for v in nasty:
        out = run("o/r", v, v)
        pp = urllib.parse.urlparse(out)
        qq = urllib.parse.parse_qs(pp.query, keep_blank_values=True)
        if pp.netloc != "github.com" or pp.path != "/o/r/issues/new" or sorted(qq) != ["device", "labels", "template", "title", "version"] or pp.fragment or len(qq["version"][0]) > 100 or any(c in qq["version"][0] for c in "\n\r\t\x00"):
            bad.append((v[:20], out[:120]))
    check("11 gia tri doc hai (&, #, %00, xuong dong, 500 ky tu, tieng Viet, emoji, ?, ../, tab/CR): KHONG them tham so, khong pha duong dan, khong fragment, <= 100 ky tu, khong ky tu dieu khien", not bad, bad[:3])
    out = run("o/r", "a\tb\nc  d", "x")
    check("ky tu dieu khien/khoang trang lap duoc gop thanh 1 dau cach ('a b c d')", urllib.parse.parse_qs(urllib.parse.urlparse(out).query)["version"] == ["a b c d"], out)
    out = run("o/r", "tiếng Việt 😀", "x")
    check("UTF-8 ma hoa phan tram dung va giai ma lai nguyen ven", urllib.parse.parse_qs(urllib.parse.urlparse(out).query)["version"] == ["tiếng Việt 😀"])
    badrepos = ["", "a", "a/b/c", "../x", "a/..", "./a", "a b/c", "a/b c", "o/r?x=1", "o/r#f", "o/r@evil", "javascript:alert(1)/x", "o/", "/r", "http://evil.com/x", "o\\r", "-", "a"*101 + "/b", "a/" + "b"*101]
    leak = [r for r in badrepos if run(r, "1", "d") != "NULL"]
    check("%d kho khong hop le (rong, 1 doan, 3 doan, '..', khoang trang, ?, #, @, javascript:, URL day du, doan > 100 ky tu) -> NULL, khong bao gio dung URL" % len(badrepos), not leak, leak)
    check("xuong dong/khoang trang CUOI cua tep update-repo.txt duoc trim (nhu UpdateChecker.readRepo) -> van tao URL dung, KHONG chen xuong dong vao URL", "\n" not in run("o/r\n", "1", "d") and run("o/r\n", "1", "d").startswith("https://github.com/o/r/issues/new?"))
    check("kho hop le co dau cham/gach (a.b/c_d-e) -> URL; khoang trang hai dau duoc bo", run("a.b/c_d-e", "1", "d").startswith("https://github.com/a.b/c_d-e/issues/new?") and run(" o/r ", "1", "d").startswith("https://github.com/o/r/issues/new?"))
else:
    print("(bo qua chay Java: can JDK day du)")

# noi day tinh
check("LogViewerActivity: btnReportIssue -> reportIssue(); lay kho tu UpdateChecker.readRepo (cung nguon voi cap nhat, CI ghi), khong URL cung", "binding.btnReportIssue.setOnClickListener { reportIssue() }" in la and "IssueLink.url(UpdateChecker.readRepo(this)" in la and "github.com" not in la)
body = la[la.index("private fun reportIssue()"): la.index("private fun shareLog()")]
check("reportIssue: chi truyen phien ban + mau may (khong nhat ky/IP/token/duong dan) vao IssueLink", "IssueLink.url(UpdateChecker.readRepo(this), version, device)" in body and "tvLogContent" not in body and "admin" not in body.lower() and "token" not in body.lower())
check("reportIssue: kho null -> Toast bao ro roi return (khong mo gi); mo trinh duyet loi -> sao chep URL, khong nem loi", "if (url == null)" in body and "report_issue_no_repo" in body and "return" in body and "catch (_: Exception)" in body and "setPrimaryClip" in body)
check("nhac che token/IP/mat khau truoc khi mo form (Toast report_issue_redact_hint)", "report_issue_redact_hint" in body)
vi, en = rd(os.path.join(ROOT, "app/src/main/res/values/strings.xml")), rd(os.path.join(ROOT, "app/src/main/res/values-en/strings.xml"))
check("4 chuoi moi co o CA vi va en", all(('name="%s"' % n) in vi and ('name="%s"' % n) in en for n in ("btn_report_issue", "report_issue_no_repo", "report_issue_redact_hint", "report_issue_copied")))
lay = rd(os.path.join(ROOT, "app/src/main/res/layout/activity_log_viewer.xml"))
check("nut btnReportIssue trong layout (match_parent, khong minHeight nho: dat tro nang A2)", 'android:id="@+id/btnReportIssue"' in lay and "minHeight" not in lay[lay.index("btnReportIssue"): lay.index("btnReportIssue") + 400])
doc = rd(os.path.join(ROOT, "docs/BETA_PROGRAM.md"))
check("BETA_PROGRAM.md huong dan nut Bao loi: chi dien san phien ban + mau may, khong gui nhat ky", "Báo lỗi (mở form GitHub)" in doc and "chỉ điền sẵn" in doc)
check("tro nang: toan bo layout van sach a11y_audit", subprocess.run([sys.executable, os.path.join(ROOT, "scripts/tools/a11y_audit.py")], capture_output=True, text=True).returncode == 0)

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
