#!/usr/bin/env python3
"""Kiem thu start-generic.sh (giam sat runtime node/python/static, HANDOFF.md muc 1bi) bang binary GIA (shell) - chay duoc moi noi co sh:
 symlink SONAME dung ten that + thu tu LD_LIBRARY_PATH, thay token trong GEN_APP_ARGS, che do direct/proxy/static, theo doi 2 tien trinh
 (1 cai chet -> dung cai kia + thoat 1), SIGTERM dung sach ca bo, don tien trinh mo coi, GEN_MODE sai."""
import os, shutil, signal, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:240]) if d else ''))
def alive(pid):
    """Song that su: kill -0 thanh cong VA khong phai zombie (container khong co init de don xac -> tien trinh mo coi da chet van la 'Z')."""
    try: os.kill(pid, 0)
    except OSError: return False
    try:
        with open('/proc/%d/stat' % pid) as f: return f.read().rsplit(')', 1)[1].split()[0] != 'Z'
    except OSError: return False
def wait_for(f, t=6):
    for _ in range(int(t * 20)):
        if os.path.exists(f) and open(f).read().strip(): return True
        time.sleep(0.05)
    return False

def main():
    tmp = tempfile.mkdtemp(prefix='gen-'); 
    try:
        def setup(name, soname_map=None):
            d = os.path.join(tmp, name); www = os.path.join(d, 'www'); sup = os.path.join(www, '_supervisor'); binp = os.path.join(d, 'bin'); home = os.path.join(d, 'home')
            for x in (sup, binp, home): os.makedirs(x)
            shutil.copy(os.path.join(TPL, 'start-generic.sh'), sup)
            for t in ('nginx-front.conf.template', 'front-locations-proxy.conf.template', 'front-locations-static.conf.template'): shutil.copy(os.path.join(TPL, t), sup)
            if soname_map is not None: open(os.path.join(sup, 'soname-map.txt'), 'w').write(soname_map)
            return d, www, sup, binp, home
        def script(path, body): open(path, 'w').write('#!/bin/sh\n' + body); os.chmod(path, 0o755)
        def env(binp, home, **kw):
            e = {k: v for k, v in os.environ.items() if not k.startswith('GEN_')}; e.update(LD_LIBRARY_PATH=binp, HOME=home, PORT='9000'); e.update(kw); return e

        print('== A. direct: symlink SONAME + token + thu tu LD_LIBRARY_PATH ==')
        d, www, sup, binp, home = setup('a', 'libz.so.1 libz_so_1.so\nlibcrypto.so.3 libcrypto_so_3.so\n')
        open(os.path.join(binp, 'libz_so_1.so'), 'w').write('z'); open(os.path.join(binp, 'libcrypto_so_3.so'), 'w').write('c')
        script(os.path.join(binp, 'libapp.so'), 'echo "LDP=$LD_LIBRARY_PATH"; echo "ARGS=$*"; echo "PORTENV=$PORT"\n')
        r = subprocess.run(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='direct', GEN_APP_BIN='libapp.so', GEN_APP_ARGS='__DOCROOT__/server.js --port __PORT__ --inner __APP_PORT__'), capture_output=True, text=True, cwd=www)
        compat = os.path.join(home, 'generic-run', 'compat-libs')
        check('chay thanh cong (exec app)', r.returncode == 0, (r.returncode, r.stderr))
        check('symlink libz.so.1 -> libz_so_1.so dung ten SONAME that', os.path.islink(os.path.join(compat, 'libz.so.1')) and os.path.realpath(os.path.join(compat, 'libz.so.1')) == os.path.realpath(os.path.join(binp, 'libz_so_1.so')))
        check('symlink libcrypto.so.3 cung duoc tao', os.path.islink(os.path.join(compat, 'libcrypto.so.3')))
        check('LD_LIBRARY_PATH = compat-libs TRUOC, binp SAU', ('LDP=%s:%s' % (compat, binp)) in r.stdout, r.stdout)
        check('token __DOCROOT__/__PORT__/__APP_PORT__ duoc thay (PORT=9000, APP_PORT=9001)', 'ARGS=%s/server.js --port 9000 --inner 9001' % os.path.realpath(www) in r.stdout, r.stdout)
        check('direct: app giu NGUYEN bien PORT cong cong (9000)', 'PORTENV=9000' in r.stdout, r.stdout)

        print('== B. proxy: 2 tien trinh, app tren PORT+1, SIGTERM dung sach ==')
        d, www, sup, binp, home = setup('b')
        run = os.path.join(home, 'generic-run')
        script(os.path.join(binp, 'libapp.so'), 'echo $$ > "%s/app.pid"; echo "$PORT" > "%s/app.port"; exec sleep 60\n' % (d, d))
        script(os.path.join(binp, 'libnginx.so'), 'echo $$ > "%s/ngx.pid"; echo "$*" > "%s/ngx.args"; exec sleep 60\n' % (d, d))
        p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='proxy', GEN_APP_BIN='libapp.so', GEN_APP_ARGS='x'), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=www, text=True)
        ok = wait_for(os.path.join(d, 'app.pid')) and wait_for(os.path.join(d, 'ngx.pid')); time.sleep(0.3)
        check('proxy: ca app lan nginx duoc khoi dong', ok)
        app_pid = int(open(os.path.join(d, 'app.pid')).read()); ngx_pid = int(open(os.path.join(d, 'ngx.pid')).read())
        check('app nhan PORT = PORT cong cong + 1 (9001), KHONG phai 9000', open(os.path.join(d, 'app.port')).read().strip() == '9001')
        cfg = open(os.path.join(run, 'nginx-front.conf')).read(); loc = open(os.path.join(run, 'front-locations.conf')).read()
        check('nginx.conf render: nghe cong 9000, khong con placeholder', 'listen 9000;' in cfg and '__' not in cfg, [l for l in cfg.split('\n') if '__' in l][:2])
        check('locations render: proxy_pass toi 127.0.0.1:9001, co WebSocket Upgrade, khong con placeholder', 'proxy_pass http://127.0.0.1:9001;' in loc and 'Upgrade $http_upgrade' in loc and '__' not in loc)
        check('nginx chay voi -p RUNDIR/ -c nginx-front.conf -g "daemon off;"', 'nginx-front.conf' in open(os.path.join(d, 'ngx.args')).read() and 'daemon off;' in open(os.path.join(d, 'ngx.args')).read())
        p.send_signal(signal.SIGTERM)
        try: rc = p.wait(timeout=6)
        except Exception: p.kill(); rc = 'timeout'
        time.sleep(0.3)
        check('SIGTERM: giam sat thoat 0', rc == 0, rc)
        check('SIGTERM: CA app lan nginx deu bi dung (khong de lai tien trinh mo coi)', not alive(app_pid) and not alive(ngx_pid), (alive(app_pid), alive(ngx_pid)))

        print('== C. proxy: app chet -> dung nginx, thoat 1 (Kotlin khoi dong lai) ==')
        d, www, sup, binp, home = setup('c')
        script(os.path.join(binp, 'libapp.so'), 'echo $$ > "%s/app.pid"; exec sleep 60\n' % d)
        script(os.path.join(binp, 'libnginx.so'), 'echo $$ > "%s/ngx.pid"; exec sleep 60\n' % d)
        p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='proxy', GEN_APP_BIN='libapp.so', GEN_APP_ARGS=''), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=www)
        wait_for(os.path.join(d, 'app.pid')); wait_for(os.path.join(d, 'ngx.pid')); time.sleep(0.3)
        app_pid = int(open(os.path.join(d, 'app.pid')).read()); ngx_pid = int(open(os.path.join(d, 'ngx.pid')).read())
        os.kill(app_pid, signal.SIGKILL)
        try: rc = p.wait(timeout=8)
        except Exception: p.kill(); rc = 'timeout'
        time.sleep(0.3)
        check('app bi giet -> giam sat thoat 1', rc == 1, rc)
        check('...va nginx cung bi dung theo', not alive(ngx_pid), alive(ngx_pid))

        print('== D. static: khong chay app, root theo GEN_WEB_SUBDIR ==')
        d, www, sup, binp, home = setup('d')
        os.makedirs(os.path.join(www, 'dist'))
        script(os.path.join(binp, 'libnginx.so'), 'echo $$ > "%s/ngx.pid"; exec sleep 60\n' % d)
        p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='static', GEN_APP_BIN='', GEN_APP_ARGS='', GEN_WEB_SUBDIR='dist'), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=www)
        wait_for(os.path.join(d, 'ngx.pid')); time.sleep(0.3)
        loc = open(os.path.join(home, 'generic-run', 'front-locations.conf')).read()
        check('static: root = <www>/dist, chan /_supervisor/, khong co proxy_pass', ('root %s/dist;' % os.path.realpath(www)) in loc and 'location ^~ /_supervisor/' in loc and 'proxy_pass' not in loc, loc[:200])
        check('static: KHONG co file front-app.pid (khong chay app)', not os.path.exists(os.path.join(home, 'generic-run', 'front-app.pid')))
        p.send_signal(signal.SIGTERM)
        try: rc = p.wait(timeout=6)
        except Exception: p.kill(); rc = 'timeout'
        check('static: SIGTERM thoat 0', rc == 0, rc)

        print('== D2. Python: PYTHONHOME + symlink lib-dynload ==')
        d, www, sup, binp, home = setup('py', '')
        os.makedirs(os.path.join(sup, 'pyhome', 'lib', 'python3.12', 'lib-dynload'))
        open(os.path.join(sup, 'pyhome', 'lib', 'python3.12', 'os.py'), 'w').write('# stdlib')
        open(os.path.join(sup, 'dynload-map.txt'), 'w').write('_socket.cpython-312-aarch64-linux-android.so libpydyn__socket_cpython-312-aarch64-linux-android.so\nmath.cpython-312-aarch64-linux-android.so libpydyn_math_cpython-312-aarch64-linux-android.so\n')
        for n in ('libpydyn__socket_cpython-312-aarch64-linux-android.so', 'libpydyn_math_cpython-312-aarch64-linux-android.so'): open(os.path.join(binp, n), 'w').write('x')
        script(os.path.join(binp, 'libapp.so'), 'echo "PYHOME=$PYTHONHOME"\n')
        r = subprocess.run(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='direct', GEN_APP_BIN='libapp.so', GEN_APP_ARGS=''), capture_output=True, text=True, cwd=www)
        dyn = os.path.join(sup, 'pyhome', 'lib', 'python3.12', 'lib-dynload')
        check('PYTHONHOME tro vao www/_supervisor/pyhome', 'PYHOME=%s' % os.path.join(os.path.realpath(www), '_supervisor', 'pyhome') in r.stdout, r.stdout)
        check('lib-dynload/<ten goc> -> nativeLibDir/<ten moi> (2 module)', all(os.path.islink(os.path.join(dyn, n)) for n in ('_socket.cpython-312-aarch64-linux-android.so', 'math.cpython-312-aarch64-linux-android.so')) and os.path.realpath(os.path.join(dyn, 'math.cpython-312-aarch64-linux-android.so')) == os.path.realpath(os.path.join(binp, 'libpydyn_math_cpython-312-aarch64-linux-android.so')), os.listdir(dyn))
        d, www, sup, binp, home = setup('nopy', '')
        script(os.path.join(binp, 'libapp.so'), 'echo "PYHOME=[$PYTHONHOME]"\n')
        r = subprocess.run(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='direct', GEN_APP_BIN='libapp.so', GEN_APP_ARGS=''), capture_output=True, text=True, cwd=www)
        check('runtime KHONG phai python: PYTHONHOME khong bi dat', 'PYHOME=[]' in r.stdout, r.stdout)

        print('== D3. Giao thuc DUNG SACH voi Kotlin (stop-requested + WPP_SESSION) - Process.destroy() tren Android co the la SIGKILL ==')
        d, www, sup, binp, home = setup('gs')
        proto = os.path.join(home, 'lamp-run'); os.makedirs(proto)
        open(os.path.join(proto, 'graceful-stop-ready'), 'w').write('TOKEN-CU-CUA-PHIEN-TRUOC')      # marker cu: PHAI bi xoa luc khoi dong
        script(os.path.join(binp, 'libapp.so'), 'echo $$ > "%s/app.pid"; exec sleep 60\n' % d)
        script(os.path.join(binp, 'libnginx.so'), 'echo $$ > "%s/ngx.pid"; exec sleep 60\n' % d)
        p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='proxy', GEN_APP_BIN='libapp.so', GEN_APP_ARGS='', WPP_SESSION='tok-1'), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=www)
        ready = os.path.join(proto, 'graceful-stop-ready')
        ok = False
        for _ in range(120):
            if os.path.exists(ready) and open(ready).read() == 'tok-1': ok = True; break
            time.sleep(0.05)
        check('marker graceful-stop-ready = token phien MOI (cu da bi xoa) sau khi ca hai tien trinh khoi dong', ok, open(ready).read() if os.path.exists(ready) else None)
        app_pid = int(open(os.path.join(d, 'app.pid')).read()); ngx_pid = int(open(os.path.join(d, 'ngx.pid')).read())
        open(os.path.join(proto, 'stop-requested'), 'w').write('TOKEN-SAI')
        time.sleep(2.5)
        check('stop-requested voi token SAI (file cu cua phien khac) bi BO QUA - van chay', p.poll() is None and alive(app_pid) and alive(ngx_pid), p.poll())
        open(os.path.join(proto, 'stop-requested'), 'w').write('tok-1')
        try: rc = p.wait(timeout=12)
        except Exception: p.kill(); rc = 'timeout'
        time.sleep(0.3)
        check('token KHOP -> tu dung sach, thoat 0', rc == 0, rc)
        check('...nginx va app deu da dung (khong de mo coi khi Kotlin chi "dung sach" qua file)', not alive(app_pid) and not alive(ngx_pid), (alive(app_pid), alive(ngx_pid)))
        check('...va marker graceful-stop-ready bi xoa khi thoat', not os.path.exists(ready))

        d, www, sup, binp, home = setup('gs2')
        proto = os.path.join(home, 'lamp-run'); os.makedirs(proto); open(os.path.join(proto, 'graceful-stop-ready'), 'w').write('CU')
        script(os.path.join(binp, 'libapp.so'), 'echo DIRECT-RAN\n')
        r = subprocess.run(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='direct', GEN_APP_BIN='libapp.so', GEN_APP_ARGS='', WPP_SESSION='tok-2'), capture_output=True, text=True, cwd=www)
        check('direct (1 tien trinh, exec): marker cu bi xoa va KHONG ghi marker moi (Kotlin destroy ngay, khong cho vo ich)', 'DIRECT-RAN' in r.stdout and not os.path.exists(os.path.join(proto, 'graceful-stop-ready')), os.listdir(proto))

        d, www, sup, binp, home = setup('gs3')
        proto = os.path.join(home, 'lamp-run')
        script(os.path.join(binp, 'libnginx.so'), 'echo $$ > "%s/ngx.pid"; exec sleep 60\n' % d)
        p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='static', GEN_APP_BIN='', GEN_APP_ARGS=''), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=www)
        wait_for(os.path.join(d, 'ngx.pid')); time.sleep(0.8)
        check('khong co WPP_SESSION (chay tay, khong qua Kotlin) -> KHONG ghi marker', not os.path.exists(os.path.join(proto, 'graceful-stop-ready')))
        open(os.path.join(proto, 'stop-requested'), 'w').write('bat-ky')
        time.sleep(2.2)
        check('...va cung KHONG phan ung voi stop-requested (can token)', p.poll() is None, p.poll())
        p.send_signal(signal.SIGTERM)
        try: rc = p.wait(timeout=10)
        except Exception: p.kill(); rc = 'timeout'
        check('SIGTERM van dung sach (static)', rc == 0, rc)

        print('== D4. Cat log nginx phia truoc khi > 5MB ==')
        d, www, sup, binp, home = setup('lg')
        run = os.path.join(home, 'generic-run'); os.makedirs(run)
        with open(os.path.join(run, 'nginx-front-error.log'), 'wb') as f: f.write(b'x' * (5 * 1024 * 1024 + 10))
        with open(os.path.join(run, 'nginx-front-stdout.log'), 'wb') as f: f.write(b'ngan\n')
        script(os.path.join(binp, 'libnginx.so'), 'echo $$ > "%s/ngx.pid"; exec sleep 60\n' % d)
        p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='static', GEN_APP_BIN='', GEN_APP_ARGS=''), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=www)
        wait_for(os.path.join(d, 'ngx.pid')); time.sleep(0.3)
        check('log > 5MB bi cat con 0 byte; log nho giu nguyen', os.path.getsize(os.path.join(run, 'nginx-front-error.log')) == 0 and open(os.path.join(run, 'nginx-front-stdout.log')).read() == 'ngan\n')
        p.send_signal(signal.SIGTERM)
        try: p.wait(timeout=10)
        except Exception: p.kill()

        print('== E. Truong hop bien ==')
        d, www, sup, binp, home = setup('e')
        r = subprocess.run(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='lung-tung'), capture_output=True, text=True, cwd=www)
        check('GEN_MODE khong hop le -> thoat 2 + log ro', r.returncode == 2 and 'khong hop le' in r.stdout, (r.returncode, r.stdout))
        d, www, sup, binp, home = setup('f')
        script(os.path.join(binp, 'libapp.so'), 'echo OK-NO-MAP\n')
        r = subprocess.run(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='direct', GEN_APP_BIN='libapp.so', GEN_APP_ARGS=''), capture_output=True, text=True, cwd=www)
        check('khong co soname-map.txt -> van chay (compat-libs rong)', r.returncode == 0 and 'OK-NO-MAP' in r.stdout, (r.returncode, r.stdout, r.stderr))
        d, www, sup, binp, home = setup('g')
        run = os.path.join(home, 'generic-run'); os.makedirs(run)
        # tien trinh mo coi: dung 1 script ten "libruntimesrv.so" de /proc/PID/cmdline chua chuoi can khop
        script(os.path.join(binp, 'libruntimesrv.so'), 'while :; do sleep 1; done\n')   # KHONG exec: cmdline phai giu ten script
        orphan = subprocess.Popen([os.path.join(binp, 'libruntimesrv.so')]); time.sleep(0.3)
        open(os.path.join(run, 'front-app.pid'), 'w').write(str(orphan.pid))
        unrelated = subprocess.Popen(['sleep', '60'])
        open(os.path.join(run, 'nginx-front.pid'), 'w').write(str(unrelated.pid))   # pid cua tien trinh KHONG lien quan: tuyet doi khong duoc giet
        script(os.path.join(binp, 'libapp.so'), 'echo $$ > "%s/app.pid"; exec sleep 60\n' % d)
        script(os.path.join(binp, 'libnginx.so'), 'echo $$ > "%s/ngx.pid"; exec sleep 60\n' % d)
        p = subprocess.Popen(['sh', os.path.join(sup, 'start-generic.sh')], env=env(binp, home, GEN_MODE='proxy', GEN_APP_BIN='libruntimesrv.so', GEN_APP_ARGS=''), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=www)
        time.sleep(2.5)
        orphan.poll()
        check('tien trinh mo coi (cmdline chua libruntimesrv.so) bi don khi khoi dong', orphan.returncode is not None, orphan.returncode)
        check('pid trong file thuoc tien trinh KHONG lien quan (sleep) TUYET DOI khong bi giet (chong tai su dung pid)', alive(unrelated.pid))
        p.send_signal(signal.SIGTERM)
        try: p.wait(timeout=6)
        except Exception: p.kill()
        unrelated.kill(); unrelated.wait()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
