#!/usr/bin/env python3
"""Kiem tra chuoi tai nguyen duoc DINH DANG luc chay (HANDOFF.md muc 1br-H).
Loi that da gap: `api_info` co "% bo nho" / "used %," giua cac %1$s/%2$s -> aapt canh bao "Multiple substitutions specified in non-positional format", va
Luc chay `getString(R.string.api_info, url, token)` NEM FormatFlagsConversionMismatchException (vi) / UnknownFormatConversionException (en) -> bam nut "Dia chi va token API" la app dong.
Chi xet chuoi duoc truyen THAM SO DINH DANG trong Kotlin (`getString(R.string.x, a, b)`): chuoi dung `setMessage(R.string.x)` hay `android:text` KHONG qua String.format
nen dau `%` don la dung (vd "pin duoi 15%") - gan "%%" cho chuoi do se hien 2 dau %.
Kiem: (1) moi "%" trong chuoi co tham so phai la mot dac ta hop le (hoac "%%"); (2) neu co tu 2 dac ta tro len thi PHAI danh so vi tri (%1$s); (3) hai ngon ngu (values, values-en)
phai co CUNG tap dac ta. Co doi chung am bang chuoi mau cu.
"""
import glob, os, re, sys
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
RES = os.path.join(ROOT, 'app', 'src', 'main', 'res')
JAVA = os.path.join(ROOT, 'app', 'src', 'main', 'java')
PASS = FAIL = 0
SPEC = re.compile(r'%(?:(\d+)\$)?([-#+ 0,(<]*)(\d+)?(?:\.(\d+))?([a-zA-Z%])')


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:400]) if d else ''))


def analyze(txt):
    """Tra (loi, [(chi_so_vi_tri hoac None, chuyen_doi)]) cho 1 chuoi se qua String.format."""
    errs, specs, i = [], [], 0
    while True:
        i = txt.find('%', i)
        if i < 0:
            break
        m = SPEC.match(txt, i)
        if not m:
            errs.append('"%s" khong phai dac ta hop le (dung %%%% de in dau %%)' % txt[i:i + 8].replace('\n', ' '))
            i += 1
            continue
        idx, flags, w, p, conv = m.groups()
        i = m.end()
        if conv == '%':
            continue
        if conv not in 'sSdxXfeEgGcCbBhHoOn':
            errs.append('"%s": chuyen doi "%s" khong ton tai' % (m.group(0), conv))
        elif ' ' in flags and conv in 'sSbBcChHn':
            errs.append('"%s": co khoang trang khong dung voi %%%s (FormatFlagsConversionMismatchException luc chay)' % (m.group(0), conv))
        specs.append((idx, conv))
    if len(specs) >= 2 and any(ix is None for ix, _ in specs):
        errs.append('co %d dac ta nhung khong danh so vi tri (%%1$s, %%2$s...) - aapt canh bao' % len(specs))
    return errs, specs


def formatted_names():
    names = set()
    for f in glob.glob(JAVA + '/**/*.kt', recursive=True):
        s = open(f, encoding='utf-8').read()
        names |= set(re.findall(r'getString\(\s*R\.string\.(\w+)\s*,', s))   # CHI getString(R.string.x, thamso...) (khong tinh setPositiveButton(R.string.x, listener) hay android.R.string.*)
    return names


def load(d):
    out = {}
    for f in glob.glob(os.path.join(RES, d, '*.xml')):
        for e in ET.parse(f).getroot():
            if e.tag == 'string' and e.get('name'):
                out[e.get('name')] = ''.join(e.itertext())
    return out


def main():
    used = formatted_names()
    vi, en = load('values'), load('values-en')
    check('tim thay chuoi duoc dinh dang (getString(R.string.x, ...)) trong ma Kotlin', len(used) >= 10, len(used))
    bad = []
    for lang, d in (('vi', vi), ('en', en)):
        for n in sorted(used):
            if n in d:
                errs, _ = analyze(d[n])
                bad += ['%s/%s: %s' % (lang, n, e) for e in errs]
    check('moi chuoi duoc dinh dang co dac ta hop le va danh so vi tri khi co >= 2 (%d chuoi x 2 ngon ngu)' % len(used), not bad, bad[:4])
    diff = []
    for n in sorted(used):
        if n in vi and n in en:
            a = sorted(analyze(vi[n])[1], key=str)
            b = sorted(analyze(en[n])[1], key=str)
            if a != b:
                diff.append('%s: vi=%s en=%s' % (n, a, b))
    check('vi va en co CUNG tap dac ta o moi chuoi dinh dang', not diff, diff[:3])
    check('chuoi dinh dang khong co ban dich thieu (vi/en deu co)', all(n in vi and n in en for n in used), [n for n in used if n not in vi or n not in en][:5])
    # doi chung am: 2 chuoi api_info CU (truoc khi sua) phai bi bat voi dung 2 loai loi that
    old_vi = 'Dia chi:\\n%1$s\\nToken:\\n%2$s\\ncurl %2$s %1$s\\nJSON: pin, % bo nho da dung, gio'
    old_en = 'Address:\\n%1$s\\nToken:\\n%2$s\\nJSON: server running, battery, storage used %, last backup'
    e1, _ = analyze(old_vi)
    e2, _ = analyze(old_en)
    check('DOI CHUNG AM: chuoi api_info cu (vi: "% b") bi bat', any('FormatFlagsConversionMismatch' in x for x in e1), e1)
    check('DOI CHUNG AM: chuoi api_info cu (en: "%, l") bi bat', any('khong phai dac ta hop le' in x or 'khong ton tai' in x for x in e2), e2)
    e3, _ = analyze(old_vi.replace('% bo', '%% bo'))
    check('chuoi da sua ("%%") khong con bi bao', not e3, e3)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
