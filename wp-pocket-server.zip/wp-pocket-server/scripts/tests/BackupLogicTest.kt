import com.wppocket.server.BackupLogic
import com.wppocket.server.BackupLogic.FileKind
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

// Test JVM cho BackupLogic (HANDOFF.md muc 1az). Dung zip THAT, kem DOI CHUNG AM:
// moi loi cu duoc tai hien bang chinh logic cu de chung minh kich ban la co that.

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun zipOf(file: File, entries: List<Pair<String, ByteArray>>, stored: Boolean = false) {
    ZipOutputStream(FileOutputStream(file)).use { z ->
        for ((name, data) in entries) {
            val e = ZipEntry(name)
            if (stored) {
                val c = CRC32(); c.update(data)
                e.method = ZipEntry.STORED; e.size = data.size.toLong(); e.compressedSize = data.size.toLong(); e.crc = c.value
            }
            z.putNextEntry(e); z.write(data); z.closeEntry()
        }
    }
}

val DUMP_OK = ("-- MariaDB dump 10.19\nCREATE TABLE `wp_options` (id int);\n" +
    "INSERT INTO `wp_options` VALUES (1,'siteurl','https://abc-def.trycloudflare.com','yes'),(2,'home','https://abc-def.trycloudflare.com','yes'),(3,'blogname','It''s \\'quoted\\'','yes');\n" +
    "/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;\n-- Dump completed on 2026-10-11  3:00:00\n").toByteArray()

fun main() {
    val dir = Files.createTempDirectory("bltest").toFile()
    fun f(n: String) = File(dir, n)

    // ------------------------------------------------------------ sniffKind
    zipOf(f("a.zip"), listOf("www/i.php" to "x".toByteArray()))
    check("sniff: zip that -> PLAIN_ZIP", BackupLogic.sniffKind(f("a.zip")) == FileKind.PLAIN_ZIP)
    f("rnd.bin").writeBytes(ByteArray(300) { (it * 37 + 11).toByte() })
    check("sniff: du lieu ngau nhien >=44B -> ENCRYPTED_OR_UNKNOWN", BackupLogic.sniffKind(f("rnd.bin")) == FileKind.ENCRYPTED_OR_UNKNOWN)
    f("tiny.bin").writeBytes(ByteArray(10) { 7 })
    check("sniff: 10 byte -> TOO_SMALL", BackupLogic.sniffKind(f("tiny.bin")) == FileKind.TOO_SMALL)
    f("empty.bin").writeBytes(ByteArray(0))
    check("sniff: file rong -> TOO_SMALL", BackupLogic.sniffKind(f("empty.bin")) == FileKind.TOO_SMALL)
    f("renamed.enc").writeBytes(f("a.zip").readBytes())
    check("sniff: zip doi duoi .enc van la PLAIN_ZIP (khong tin duoi file)", BackupLogic.sniffKind(f("renamed.enc")) == FileKind.PLAIN_ZIP)

    // ------------------------------------------------------ isSafeEntryName
    check("ten an toan: www/wp-content/a.php", BackupLogic.isSafeEntryName("www/wp-content/a.php"))
    check("ten an toan: 'a..b' (khong phai thanh phan '..')", BackupLogic.isSafeEntryName("www/a..b/c"))
    check("ten khong an toan: ../x", !BackupLogic.isSafeEntryName("../x"))
    check("ten khong an toan: www/../../x", !BackupLogic.isSafeEntryName("www/../../x"))
    check("ten khong an toan: www\\..\\..\\x (Windows)", !BackupLogic.isSafeEntryName("www\\..\\..\\x"))
    check("ten khong an toan: tuyet doi /etc/passwd", !BackupLogic.isSafeEntryName("/etc/passwd"))
    check("ten khong an toan: C:\\x", !BackupLogic.isSafeEntryName("C:\\x"))
    check("ten khong an toan: byte null", !BackupLogic.isSafeEntryName("www/a\u0000.php"))
    check("ten khong an toan: rong", !BackupLogic.isSafeEntryName(""))

    // --------------------------------------------------------- resolveInside
    val base = f("base").apply { mkdirs() }
    check("resolveInside: ten hop le nam trong base", BackupLogic.resolveInside(base, "wp-content/a.php")?.path?.startsWith(base.canonicalPath) == true)
    check("resolveInside: ../x -> null", BackupLogic.resolveInside(base, "../x") == null)
    check("resolveInside: a/../../x -> null", BackupLogic.resolveInside(base, "a/../../x") == null)
    val outside = f("outside").apply { mkdirs() }
    Files.createSymbolicLink(File(base, "link").toPath(), outside.toPath())
    check("resolveInside: di qua symlink tro ra NGOAI -> null", BackupLogic.resolveInside(base, "link/evil.php") == null)

    // -------------------------------------------------------------- inspect
    val good = f("good.zip")
    zipOf(good, listOf(
        "www/index.php" to "<?php echo 1;".toByteArray(),
        "www/wp-content/a.txt" to ByteArray(5000) { (it % 251).toByte() },
        "database.sql" to DUMP_OK,
    ))
    val gi = BackupLogic.inspect(good)
    check("inspect: backup hop le -> ok, 2 file www, co DB", gi.ok && gi.wwwFiles == 2 && gi.hasDb)
    check("inspect: tong dung luong khop", gi.uncompressedBytes == 13L + 5000L + DUMP_OK.size)

    // Loi 2 (CRC): lat 1 byte trong du lieu STORED
    val victim = f("victim.zip")
    zipOf(victim, listOf("www/index.php" to "AAAA-BBBB-CCCC-DDDD-EEEE".toByteArray(), "database.sql" to DUMP_OK), stored = true)
    val raw = victim.readBytes()
    val idx = String(raw, Charsets.ISO_8859_1).indexOf("AAAA-BBBB")
    raw[idx + 2] = 'Z'.code.toByte()
    val flipped = f("flipped.zip"); flipped.writeBytes(raw)
    var oldVerifyPasses = false
    ZipFile(flipped).use { zf ->               // LOGIC CU cua verifyBackupZip: chi doc het qua ZipFile
        val en = zf.entries(); val buf = ByteArray(1024)
        try { while (en.hasMoreElements()) { zf.getInputStream(en.nextElement()).use { while (it.read(buf) >= 0) {} } }; oldVerifyPasses = true } catch (_: Exception) {}
    }
    check("DOI CHUNG AM: logic cu (ZipFile, khong tu tinh CRC) KHONG phat hien lat bit", oldVerifyPasses)
    val fi = BackupLogic.inspect(flipped)
    check("inspect: lat 1 bit -> BI TU CHOI (sai CRC)", !fi.ok && fi.reason.contains("CRC"))

    val trunc = f("trunc.zip"); trunc.writeBytes(good.readBytes().copyOf((good.length() / 2).toInt()))
    check("inspect: zip bi cat nua -> tu choi", !BackupLogic.inspect(trunc).ok)
    f("garbage.zip").writeBytes(ByteArray(2000) { (it * 13).toByte() })
    check("inspect: khong phai zip -> tu choi", !BackupLogic.inspect(f("garbage.zip")).ok)
    zipOf(f("nowww.zip"), listOf("readme.txt" to "hi".toByteArray()))
    check("inspect: khong co www/ -> tu choi (khong phai backup cua app)", !BackupLogic.inspect(f("nowww.zip")).ok)
    zipOf(f("nodump.zip"), listOf("www/i.php" to "x".toByteArray(), "database.sql" to "INSERT INTO t VALUES (1);\n".toByteArray()))
    check("inspect: database.sql thieu dong '-- Dump completed' -> tu choi", !BackupLogic.inspect(f("nodump.zip")).ok)
    zipOf(f("onlywww.zip"), listOf("www/i.php" to "x".toByteArray()))
    check("inspect: chi co www (khong DB) van hop le", BackupLogic.inspect(f("onlywww.zip")).let { it.ok && !it.hasDb })
    zipOf(f("slip.zip"), listOf("www/index.php" to "x".toByteArray(), "www/../../evil.txt" to "pwn".toByteArray()))
    check("inspect: entry Zip Slip -> tu choi CA FILE", BackupLogic.inspect(f("slip.zip")).let { !it.ok && it.reason.contains("KHONG AN TOAN") })
    zipOf(f("many.zip"), (1..20).map { "www/f$it.txt" to "x".toByteArray() })
    check("inspect: qua nhieu muc (maxEntries=10) -> tu choi", !BackupLogic.inspect(f("many.zip"), maxEntries = 10).ok)
    check("inspect: vuot dung luong trong (cap 1000B) -> tu choi", !BackupLogic.inspect(good, maxUncompressedBytes = 1000).ok)
    check("inspect: du dung luong (cap 1MB) -> ok", BackupLogic.inspect(good, maxUncompressedBytes = 1024 * 1024).ok)

    // -------------------------------------------------------------- extract
    val www = f("www").apply { mkdirs() }
    File(www, "index.php").writeText("OLD-CONTENT")
    val sql = f("out.sql")
    val ex = BackupLogic.extract(good, www, sql)
    check("extract: 2 file duoc khoi phuc", ex.filesRestored == 2)
    check("extract: index.php duoc ghi de dung noi dung", File(www, "index.php").readText() == "<?php echo 1;")
    check("extract: nested wp-content/a.txt co mat dung kich thuoc", File(www, "wp-content/a.txt").length() == 5000L)
    check("extract: database.sql duoc trich ra dung", ex.dbDumpFile != null && sql.readBytes().contentEquals(DUMP_OK))
    check("extract: khong de lai file .wpp-tmp", www.walkTopDown().none { it.name.endsWith(".wpp-tmp") })

    // Loi 1 (Zip Slip): DOI CHUNG AM bang logic cu
    val victimDir = f("victim-root").apply { mkdirs() }
    val wwwA = File(victimDir, "files/www").apply { mkdirs() }
    run { // LOGIC CU cua performRestore: File(wwwDir, relativePath) khong kiem tra
        java.util.zip.ZipInputStream(FileInputStream(f("slip.zip"))).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                if (e.name.startsWith("www/") && !e.isDirectory) {
                    val dest = File(wwwA, e.name.removePrefix("www/")); dest.parentFile?.mkdirs()
                    FileOutputStream(dest).use { zis.copyTo(it) }
                }
                zis.closeEntry(); e = zis.nextEntry
            }
        }
    }
    check("DOI CHUNG AM: logic cu GHI RA NGOAI www/ (evil.txt xuat hien o thu muc cha)", File(victimDir, "evil.txt").exists() || File(victimDir, "files/evil.txt").exists())
    File(victimDir, "evil.txt").delete(); File(victimDir, "files/evil.txt").delete()
    val wwwB = File(victimDir, "files/www2").apply { mkdirs() }
    var threw = false
    try { BackupLogic.extract(f("slip.zip"), wwwB, f("o2.sql")) } catch (e: BackupLogic.UnsafeEntryException) { threw = true }
    check("extract: Zip Slip -> nem UnsafeEntryException", threw)
    check("extract: Zip Slip -> KHONG co file nao thoat ra ngoai", !File(victimDir, "evil.txt").exists() && !File(victimDir, "files/evil.txt").exists())

    // CRC sai khi extract: file dang co KHONG bi thay the
    val wwwC = f("wwwC").apply { mkdirs() }
    File(wwwC, "index.php").writeText("KEEP-ME")
    var threwCrc = false
    try { BackupLogic.extract(flipped, wwwC, f("o3.sql")) } catch (e: Exception) { threwCrc = true }
    check("extract: entry sai CRC -> nem loi", threwCrc)
    check("extract: entry sai CRC -> file dang co GIU NGUYEN (khong bi thay bang du lieu hong)", File(wwwC, "index.php").readText() == "KEEP-ME")
    check("extract: entry sai CRC -> khong de lai .wpp-tmp", wwwC.walkTopDown().none { it.name.endsWith(".wpp-tmp") })

    // ------------------------------------------------------------- portable
    val inc = listOf(
        "wp-content/uploads/2026/10/a.jpg", "wp-content/themes/t/style.css", "wp-content/plugins/akismet/a.php",
        "wp-content/index.php", "wp-content/mu-plugins/my-own.php", "wp-content/languages/vi.mo",
    )
    val exc = listOf(
        "wp-content/cache/x.html", "wp-content/upgrade/tmp.zip", "wp-content/database/.ht.sqlite",
        "wp-content/object-cache.php", "wp-content/db.php", "wp-content/debug.log",
        "wp-content/wppocket-core-rollback/wp-admin/a.php", "wp-content/plugins/sqlite-database-integration/x.php",
        "wp-content/mu-plugins/wppocket-maintenance.php", "wp-content/mu-plugins/wppocket-pagecache.php", "wp-content/mu-plugins/wppocket-pagecache/purge.php", "wp-config.php", "wp-admin/a.php", "index.php",
        "wp-content/uploads/x.partial", "../wp-content/uploads/a", "wp-content",
    )
    check("portable: giu " + inc.size + " duong dan hop le", inc.all { BackupLogic.isPortableIncluded(it) })
    check("portable: loai " + exc.size + " duong dan dac thu/rac/khong an toan", exc.none { BackupLogic.isPortableIncluded(it) })
    check("portable: 'database' o CAP SAU (uploads/database/) KHONG bi loai nham", BackupLogic.isPortableIncluded("wp-content/uploads/database/report.csv"))
    check("portable: plugin ten gan giong (sqlite-database-integration-pro) KHONG bi loai nham", BackupLogic.isPortableIncluded("wp-content/plugins/sqlite-database-integration-pro/x.php"))

    check("parseTablePrefix: wp_", BackupLogic.parseTablePrefix("<?php\n\$table_prefix = 'wp_';\n") == "wp_")
    check("parseTablePrefix: tien to tuy chinh nhay kep", BackupLogic.parseTablePrefix("\$table_prefix  =  \"shop7_\";") == "shop7_")
    check("parseTablePrefix: khong co -> null", BackupLogic.parseTablePrefix("<?php // nothing") == null)
    val dumpF = f("opt.sql"); dumpF.writeBytes(DUMP_OK)
    check("findOptionInDump: siteurl", BackupLogic.findOptionInDump(dumpF, "siteurl") == "https://abc-def.trycloudflare.com")
    check("findOptionInDump: blogname co dau nhay thoat", BackupLogic.findOptionInDump(dumpF, "blogname") == "It's 'quoted'")
    check("findOptionInDump: option khong ton tai -> null", BackupLogic.findOptionInDump(dumpF, "nope") == null)

    val site = f("site-www").apply { mkdirs() }
    fun put(rel: String, content: String) { val t = File(site, rel); t.parentFile.mkdirs(); t.writeText(content) }
    put("wp-config.php", "<?php define('DB_PASSWORD','SECRET-PW');"); put("wp-admin/a.php", "core"); put("index.php", "core")
    for (p in inc + exc.filter { it.startsWith("wp-content/") && it != "wp-content" && !it.startsWith("..") }) put(p, "data:$p")
    val secretOutside = f("secret.txt"); secretOutside.writeText("TOP-SECRET")
    Files.createSymbolicLink(File(site, "wp-content/uploads/leak.txt").toPath(), secretOutside.toPath())
    val pz = f("portable.zip")
    val base0 = BackupLogic.PortableInfo("2026-10-11 03:00", "https://abc-def.trycloudflare.com", "https://abc-def.trycloudflare.com", "wp_", true, false, 0)
    val n = BackupLogic.buildPortableZip(site, dumpF, pz, base0)
    val names = ZipFile(pz).use { zf -> zf.entries().toList().map { it.name } }
    check("portable zip: dem dung so tep wp-content (${inc.size}) -> $n", n == inc.size)
    check("portable zip: co dung " + inc.size + " tep wp-content", names.count { it.startsWith("wp-content/") } == inc.size)
    check("portable zip: co database.sql + README + JSON", "database.sql" in names && "README-MIGRATION.txt" in names && "wp-pocket-export.json" in names)
    check("portable zip: KHONG co wp-config.php (mat khau DB) o bat ky dau", names.none { it.endsWith("wp-config.php") })
    check("portable zip: KHONG co loi WP (wp-admin/index.php goc)", names.none { it.startsWith("wp-admin/") || it == "index.php" })
    check("portable zip: KHONG co file dac thu (cache/object-cache/db.php/sqlite/wppocket)", names.none { it.contains("object-cache") || it.contains("/cache/") || it.endsWith("db.php") || it.contains("sqlite") || it.contains("wppocket") })
    check("portable zip: symlink tro ra ngoai KHONG bi dua vao", names.none { it.endsWith("leak.txt") })
    val allBytes = ZipFile(pz).use { zf -> zf.entries().toList().joinToString("\n") { String(zf.getInputStream(it).readBytes(), Charsets.ISO_8859_1) } }
    check("portable zip: khong ro ri chuoi mat khau DB / TOP-SECRET trong bat ky noi dung nao", !allBytes.contains("SECRET-PW") && !allBytes.contains("TOP-SECRET"))
    val readme = ZipFile(pz).use { zf -> String(zf.getInputStream(zf.getEntry("README-MIGRATION.txt")).readBytes(), Charsets.UTF_8) }
    check("README: ghi tien to bang wp_ va URL cu trong lenh search-replace", readme.contains("table_prefix") && readme.contains("'wp_'") && readme.contains("search-replace 'https://abc-def.trycloudflare.com'"))
    check("README: noi ro KHONG phai .wpress/Duplicator", readme.contains(".wpress") && readme.contains("Duplicator"))
    val json = ZipFile(pz).use { zf -> String(zf.getInputStream(zf.getEntry("wp-pocket-export.json")).readBytes(), Charsets.UTF_8) }
    check("JSON: co so tep + database_included=true", json.contains("\"wp_content_files\": ${inc.size}") && json.contains("\"database_included\": true"))
    check("portable zip KHONG phai dinh dang khoi phuc (inspect tu choi: khong co www/)", !BackupLogic.inspect(pz).ok)

    val pz2 = f("portable-lite.zip")
    BackupLogic.buildPortableZip(site, null, pz2, base0.copy(dbIncluded = false, sqliteMode = true, tablePrefix = null))
    val r2 = ZipFile(pz2).use { zf -> String(zf.getInputStream(zf.getEntry("README-MIGRATION.txt")).readBytes(), Charsets.UTF_8) }
    check("portable Lite: khong co database.sql, README giai thich SQLite", ZipFile(pz2).use { it.getEntry("database.sql") } == null && r2.contains("SQLite"))

    // ------------------------------------------------------- sanitizeDbName
    check("sanitizeDbName: wordpress", BackupLogic.sanitizeDbName("wordpress") == "wordpress")
    check("sanitizeDbName: app\\n (file co xuong dong) -> app", BackupLogic.sanitizeDbName("app\n") == "app")
    check("sanitizeDbName: my_app2", BackupLogic.sanitizeDbName("my_app2") == "my_app2")
    check("sanitizeDbName: null -> wordpress", BackupLogic.sanitizeDbName(null) == "wordpress")
    check("sanitizeDbName: rong -> wordpress", BackupLogic.sanitizeDbName("") == "wordpress")
    check("sanitizeDbName: chen tuy chon '--result-file=/x' -> wordpress", BackupLogic.sanitizeDbName("--result-file=/x") == "wordpress")
    check("sanitizeDbName: co khoang trang 'a b' -> wordpress", BackupLogic.sanitizeDbName("a b") == "wordpress")
    check("sanitizeDbName: duong dan 'a/../b' -> wordpress", BackupLogic.sanitizeDbName("a/../b") == "wordpress")
    check("sanitizeDbName: bat dau bang so -> wordpress", BackupLogic.sanitizeDbName("1app") == "wordpress")
    check("sanitizeDbName: 33 ky tu -> wordpress; 32 ky tu -> giu", BackupLogic.sanitizeDbName("a".repeat(33)) == "wordpress" && BackupLogic.sanitizeDbName("a".repeat(32)) == "a".repeat(32))

    // ------------------------------------------------------- dumpLooksComplete
    check("dumpLooksComplete: dump day du -> true", BackupLogic.dumpLooksComplete(dumpF))
    val cut = f("cut.sql"); cut.writeBytes(DUMP_OK.copyOf(DUMP_OK.size / 2))
    check("dumpLooksComplete: dump bi cut -> false", !BackupLogic.dumpLooksComplete(cut))
    check("dumpLooksComplete: file khong ton tai -> false", !BackupLogic.dumpLooksComplete(f("missing.sql")))
    val big = f("big.sql"); big.writeBytes(ByteArray(5_000_000) { 'a'.code.toByte() } + DUMP_OK)
    check("dumpLooksComplete: file lon 5MB, trailer o cuoi -> true (chi doc phan cuoi)", BackupLogic.dumpLooksComplete(big))

    // (khong xoa `dir` o day: cac kiem tra phia duoi - H1/verify/pickWpPrefix - van dung f(...) trong `dir`; don o cuoi main)
    // ---- 1bd: tem vo hieu hoa cache APCu (hop dong voi object-cache.php / admin-auth.php) ----
    run {
        val base = java.nio.file.Files.createTempDirectory("epoch-test").toFile()
        check("thu muc lamp-run CHUA co -> khong lam gi, tra false (server chua tung chay)", !BackupLogic.bumpObjectCacheEpoch(base) && !File(base, "lamp-run").exists())
        File(base, "lamp-run").mkdirs()
        val ef = File(base, "lamp-run/object-cache-epoch")
        check("co lamp-run -> ghi tem, tra true", BackupLogic.bumpObjectCacheEpoch(base) && ef.isFile && ef.readText().isNotBlank())
        val first = ef.readText()
        BackupLogic.bumpObjectCacheEpoch(base)
        check("lan ghi sau cho CHUOI KHAC (object-cache.php nhan ra de xoa cache)", ef.readText() != first)
        check("khong de lai tep tam .tmp (ghi nguyen tu bang doi ten)", File(base, "lamp-run").list()!!.none { it.endsWith(".tmp") })
        check("tem chi 1 dong, khong xuong dong (PHP so sanh chuoi sau trim)", !ef.readText().contains('\n'))
        base.deleteRecursively()
    }
    // ---- zipDir KHONG theo symlink (HANDOFF.md muc 1bj) ----
    run {
        val base = Files.createTempDirectory("zipsym").toFile()
        val www = File(base, "www").apply { mkdirs() }
        File(www, "index.html").writeText("INDEX")
        File(www, "sub").mkdirs(); File(www, "sub/a.txt").writeText("A")
        val secret = File(base, "secret.txt").apply { writeText("TOPSECRET-OUTSIDE") }
        val libs = File(base, "libs").apply { mkdirs() }; File(libs, "x.so").writeText("LIBDATA-BIG")
        Files.createSymbolicLink(File(www, "leak.txt").toPath(), secret.toPath())
        Files.createSymbolicLink(File(www, "libs-link").toPath(), libs.toPath())
        val zipFile = File(base, "out.zip")
        ZipOutputStream(FileOutputStream(zipFile)).use { BackupLogic.zipDir(www, "www", it) }
        val names = ArrayList<String>(); val allText = StringBuilder()
        ZipFile(zipFile).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement(); names.add(e.name)
                if (!e.isDirectory) allText.append(z.getInputStream(e).readBytes().toString(Charsets.UTF_8))
            }
        }
        check("zipDir: tep thuong va thu muc con duoc zip", "www/index.html" in names && "www/sub/a.txt" in names)
        check("zipDir: symlink toi TEP NGOAI www (leak.txt) KHONG vao zip - khong lo noi dung tep ngoai", "www/leak.txt" !in names && !allText.contains("TOPSECRET"))
        check("zipDir: symlink toi THU MUC (libs-link) KHONG duoc theo - khong nuot thu vien", names.none { it.startsWith("www/libs-link") } && !allText.contains("LIBDATA"))
        check("dirSize: khong tinh phan symlink tro toi", BackupLogic.dirSize(www) == ("INDEX".length + "A".length).toLong())
        check("isSymlink: symlink -> true; tep that / thu muc that -> false", BackupLogic.isSymlink(File(www, "leak.txt")) && !BackupLogic.isSymlink(File(www, "index.html")) && !BackupLogic.isSymlink(File(www, "sub")))
        base.deleteRecursively()
    }
    // ---------------------------------------------------- H1: cau truc dump WordPress (1bl)
    val DUMP_WP = ("-- MariaDB dump 10.19\nCREATE TABLE `wp_options` (id int);\nCREATE TABLE `wp_posts` (id int);\n" +
        "INSERT INTO `wp_options` VALUES (1,'siteurl','x','yes');\n-- Dump completed on 2026-10-11  3:00:00\n").toByteArray()
    zipOf(f("wp-ok.zip"), listOf("www/wp-config.php" to "<?php".toByteArray(), "www/index.php" to "x".toByteArray(), "database.sql" to DUMP_WP))
    check("inspect WP: dump co options+posts+INSERT options -> OK", BackupLogic.inspect(f("wp-ok.zip")).ok)
    zipOf(f("wp-noposts.zip"), listOf("www/wp-config.php" to "<?php".toByteArray(), "database.sql" to DUMP_OK))
    val rNoPosts = BackupLogic.inspect(f("wp-noposts.zip"))
    check("inspect WP: dump thieu bang posts -> tu choi, ly do noi 'WordPress'", !rNoPosts.ok && rNoPosts.reason.contains("WordPress"))
    val dumpNoInsert = ("-- d\nCREATE TABLE `wp_options` (id int);\nCREATE TABLE `wp_posts` (id int);\n-- Dump completed on 2026-10-11  3:00:00\n").toByteArray()
    zipOf(f("wp-noinsert.zip"), listOf("www/wp-includes/version.php" to "<?php".toByteArray(), "database.sql" to dumpNoInsert))
    check("inspect WP (nhan dien qua wp-includes/version.php, giong goi di dong khong co wp-config): dump khong co du lieu options -> tu choi", !BackupLogic.inspect(f("wp-noinsert.zip")).ok)
    zipOf(f("nonwp.zip"), listOf("www/index.php" to "x".toByteArray(), "database.sql" to DUMP_OK))
    check("inspect KHONG phai WordPress (khong co wp-config/wp-includes): khong ep cau truc bang -> van OK (khong gay hoi quy)", BackupLogic.inspect(f("nonwp.zip")).ok)
    val dumpPrefix = String(DUMP_WP).replace("wp_", "abc_").toByteArray()
    zipOf(f("wp-prefix.zip"), listOf("www/wp-config.php" to "<?php".toByteArray(), "database.sql" to dumpPrefix))
    check("inspect WP: tien to bang tuy y (abc_options/abc_posts) van OK", BackupLogic.inspect(f("wp-prefix.zip")).ok)
    var cutOk = true
    for (cut in 1 until DUMP_WP.size) {
        val sc = BackupLogic.DumpScanner()
        sc.feed(DUMP_WP.copyOfRange(0, cut), cut)
        sc.feed(DUMP_WP.copyOfRange(cut, DUMP_WP.size), DUMP_WP.size - cut)
        if (!sc.looksLikeWordPress() || sc.tables != setOf("wp_options", "wp_posts")) cutOk = false
    }
    check("DumpScanner: cat doi dump o MOI vi tri byte (mau CREATE TABLE/INSERT bi cat giua 2 khoi doc) van nhan du", cutOk)
    val tiny = BackupLogic.DumpScanner()
    for (b in DUMP_WP) tiny.feed(byteArrayOf(b), 1)
    check("DumpScanner: nap tung byte mot van nhan du", tiny.looksLikeWordPress())
    val empty = BackupLogic.DumpScanner()
    empty.feed(ByteArray(0), 0)
    check("DumpScanner: chua nap gi -> khong phai WordPress", !empty.looksLikeWordPress())

    // ---------------------------------------------------- H1 (1bm): doi ten database trong dump de nap thu
    check("classify: USE / CREATE DATABASE (kieu mysqldump that, ke ca /*!NNNNN ... */) duoc nhan ra",
        BackupLogic.classifyDumpHead("USE `wordpress`;\n") == BackupLogic.DumpLineKind.USE_DB &&
            BackupLogic.classifyDumpHead("CREATE DATABASE /*!32312 IF NOT EXISTS*/ `wordpress` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;\n") == BackupLogic.DumpLineKind.CREATE_DB &&
            BackupLogic.classifyDumpHead("/*M!100000 USE `wordpress`;*/\n") == BackupLogic.DumpLineKind.USE_DB)
    check("classify: lenh nguy hiem (DROP DATABASE/GRANT/CREATE USER/SET PASSWORD/lenh client \\!, \\., SYSTEM, SOURCE, LOAD DATA) la DANGEROUS",
        listOf("DROP DATABASE `wordpress`;", "/*!40000 DROP DATABASE IF EXISTS `wordpress`*/;", "drop database x;", "GRANT ALL ON *.* TO 'a'", "CREATE USER 'a'",
            "SET PASSWORD FOR 'a'='b'", "\\! rm -rf /", "\\. /etc/passwd", "system id", "source /x.sql", "LOAD DATA INFILE '/x'", "FLUSH PRIVILEGES", "  DROP SCHEMA y").all { BackupLogic.classifyDumpHead(it + "\n") == BackupLogic.DumpLineKind.DANGEROUS })
    check("classify: DELIMITER va trigger/view co DEFINER la UNSUPPORTED (khong phai loi backup)",
        BackupLogic.classifyDumpHead("DELIMITER ;;\n") == BackupLogic.DumpLineKind.UNSUPPORTED && BackupLogic.classifyDumpHead("/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER t BEFORE INSERT ON x */;;\n") == BackupLogic.DumpLineKind.UNSUPPORTED)
    check("classify: dong DU LIEU chua chu nguy hiem/DEFINER trong noi dung van la PASS (chi xet tien to)",
        BackupLogic.classifyDumpHead("INSERT INTO `wp_posts` VALUES (1,'DROP DATABASE wordpress; GRANT ALL; DEFINER=x');\n") == BackupLogic.DumpLineKind.PASS &&
            BackupLogic.classifyDumpHead("CREATE TABLE `wp_x` (\n") == BackupLogic.DumpLineKind.PASS && BackupLogic.classifyDumpHead("-- Dump completed on 2026-10-11\n") == BackupLogic.DumpLineKind.PASS &&
            BackupLogic.classifyDumpHead("DROP TABLE IF EXISTS `wp_posts`;\n") == BackupLogic.DumpLineKind.PASS && BackupLogic.classifyDumpHead("LOCK TABLES `wp_posts` WRITE;\n") == BackupLogic.DumpLineKind.PASS && BackupLogic.classifyDumpHead("\n") == BackupLogic.DumpLineKind.PASS)
    check("isSafeDbIdent: chu/so/gach duoi <=40; khong cho dau nhay, khoang trang, cham, dai qua",
        BackupLogic.isSafeDbIdent("wordpress_verify") && !BackupLogic.isSafeDbIdent("a`b") && !BackupLogic.isSafeDbIdent("a b") && !BackupLogic.isSafeDbIdent("") && !BackupLogic.isSafeDbIdent("a.b") && !BackupLogic.isSafeDbIdent("x".repeat(41)) && !BackupLogic.isSafeDbIdent("t\u00ean"))
    val bigLine = "x".repeat(2_000_000)
    val dumpIn = "-- MariaDB dump\nCREATE DATABASE /*!32312 IF NOT EXISTS*/ `wordpress` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;\nUSE `wordpress`;\n" +
        "DROP TABLE IF EXISTS `wp_posts`;\nCREATE TABLE `wp_posts` (\n  `ID` int\n);\nINSERT INTO `wp_posts` VALUES (1,'Xin ch\u00e0o \u1ee9ng d\u1ee5ng \uD83D\uDE00 USE `wordpress`;'),(2,'$bigLine');\n" +
        "/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;\n-- Dump completed on 2026-10-11  3:00:00\n"
    val fin = f("dump-in.sql"); val fout = f("dump-out.sql")
    fin.writeBytes(dumpIn.toByteArray(Charsets.UTF_8))
    val rw = BackupLogic.rewriteDumpForVerify(fin, fout, "wordpress_verify")
    val expectedOut = dumpIn.replace("CREATE DATABASE /*!32312 IF NOT EXISTS*/ `wordpress` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;\nUSE `wordpress`;\n",
        "CREATE DATABASE IF NOT EXISTS `wordpress_verify`;\nUSE `wordpress_verify`;\n")
    check("rewrite: dung 2 dong (CREATE DATABASE + USE) duoc doi ten, ok=true, rewritten=2", rw.ok && rw.rewritten == 2)
    check("rewrite: MOI byte khac giu nguyen (UTF-8 tieng Viet, emoji, dong 2MB, chuoi 'USE `wordpress`;' nam TRONG du lieu khong bi dung)", String(fout.readBytes(), Charsets.UTF_8) == expectedOut)
    fin.writeBytes("USE `wordpress`;\nDROP DATABASE IF EXISTS `x`;\nINSERT INTO t VALUES (1);\n".toByteArray())
    val rwBad = BackupLogic.rewriteDumpForVerify(fin, fout, "wordpress_verify")
    check("rewrite: gap DROP DATABASE -> ok=false, khong phai unsupported", !rwBad.ok && !rwBad.unsupported)
    fin.writeBytes("CREATE TABLE a (b int);\nDELIMITER ;;\n".toByteArray())
    val rwUns = BackupLogic.rewriteDumpForVerify(fin, fout, "wordpress_verify")
    check("rewrite: gap DELIMITER -> ok=false va unsupported=true (bao 'bo qua', khong bao 'that bai')", !rwUns.ok && rwUns.unsupported)
    check("rewrite: ten database tam khong an toan bi tu choi truoc khi doc file", !BackupLogic.rewriteDumpForVerify(fin, fout, "x`; DROP DATABASE wordpress; --").ok)
    fin.writeBytes("-- chi co chu thich\nINSERT INTO t VALUES (1);".toByteArray())
    val rwNoNl = BackupLogic.rewriteDumpForVerify(fin, fout, "v")
    check("rewrite: file khong co USE va dong cuoi khong co xuong dong -> ok, rewritten=0, noi dung y nguyen", rwNoNl.ok && rwNoNl.rewritten == 0 && String(fout.readBytes()) == "-- chi co chu thich\nINSERT INTO t VALUES (1);")
    zipOf(f("verify-src.zip"), listOf("www/wp-config.php" to "<?php".toByteArray(), "database.sql" to DUMP_WP))
    val dumpOutFile = f("extracted.sql")
    check("extractDbDump: lay dung database.sql ra file; zipHasEntry nhan dung co/khong", BackupLogic.extractDbDump(f("verify-src.zip"), dumpOutFile) && dumpOutFile.readBytes().contentEquals(DUMP_WP) &&
        BackupLogic.zipHasEntry(f("verify-src.zip"), "www/wp-config.php") && !BackupLogic.zipHasEntry(f("verify-src.zip"), "www/khong-co.php"))
    zipOf(f("verify-nodb.zip"), listOf("www/index.php" to "x".toByteArray()))
    check("extractDbDump: zip khong co database.sql -> false", !BackupLogic.extractDbDump(f("verify-nodb.zip"), f("none.sql")))

    check("pickWpPrefix: wp_ / tien to tuy y / khong tien to; chon tien to NGAN nhat; khong co cap -> null; tien to khong an toan -> bo",
        BackupLogic.pickWpPrefix(listOf("wp_options", "wp_posts", "wp_users")) == "wp_" && BackupLogic.pickWpPrefix(listOf("abc7_options", "abc7_posts")) == "abc7_" &&
            BackupLogic.pickWpPrefix(listOf("options", "posts")) == "" && BackupLogic.pickWpPrefix(listOf("wp_woo_options", "wp_woo_posts", "wp_options", "wp_posts")) == "wp_" &&
            BackupLogic.pickWpPrefix(listOf("wp_options", "wp_users")) == null && BackupLogic.pickWpPrefix(emptyList()) == null &&
            BackupLogic.pickWpPrefix(listOf("a`b_options", "a`b_posts")) == null)
    dir.deleteRecursively()
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
