#!/bin/sh
# Chay kiem thu JVM cho UploadLogic.kt (can kotlinc + java). Khong can Android SDK. HANDOFF.md muc 1bo-F.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/UploadLogic.kt" "$HERE/UploadLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" UploadLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
