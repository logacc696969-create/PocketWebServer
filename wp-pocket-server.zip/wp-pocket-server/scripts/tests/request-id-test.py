#!/usr/bin/env python3
"""AE3 (PDF 2, HANDOFF.md muc 1bp): ma request trong nginx-access.log + header X-Request-ID, KHONG lam vo trang analytics.
Dung CHINH regex cua admin-analytics.php (trich tu file that) de chung minh dong log dinh dang moi van doc duoc. Khong can nginx/php."""
import os, re, subprocess, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "tools"))
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
rd = lambda p: open(os.path.join(ROOT, p), encoding="utf-8").read()
tpl = rd("scripts/runtimes/templates/nginx.conf.template")
php = rd("scripts/runtimes/templates/admin-analytics.php")

# ---- cau hinh nginx ----
m = re.search(r"log_format wp_pocket (.*?);", tpl, re.S)
fmt = "".join(re.findall(r"'([^']*)'", m.group(1)))
check("log_format: 'rid=$request_id' nam CUOI CUNG, ngay sau 'rt=$request_time'", fmt.endswith("rt=$request_time rid=$request_id"), fmt)
check("log_format: van giu nguyen cac truong combined (khong doi thu tu cac truong cu)", fmt.startswith('$remote_addr - $remote_user [$time_local] "$request" $status $body_bytes_sent "$http_referer" "$http_user_agent" rt='))
n_hdr = tpl.count("add_header X-Request-ID $request_id always;")
check("add_header X-Request-ID co o server chinh VA o location tep tinh (noi co add_header rieng) = 2", n_hdr == 2, str(n_hdr))
# moi location co add_header rieng phai nhac lai header nay (nginx khong ke thua add_header vao location co add_header rieng)
code = re.sub(r"(?m)#.*$", "", tpl)   # bo chu thich (co cau chu nhac toi add_header se gay bao dong gia)
blocks = re.split(r"(?m)^\s*location ", code)[1:]
miss = [b.split("{")[0].strip() for b in blocks if "add_header" in b and "X-Request-ID" not in b]
check("moi location co add_header rieng deu nhac lai X-Request-ID (khong location nao bi mat header): %s" % miss, miss == [])
r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts/tools/nginx-lint.py"), os.path.join(ROOT, "scripts/runtimes/templates/nginx.conf.template")], capture_output=True, text=True)
check("nginx-lint sach sau thay doi", r.returncode == 0, r.stdout + r.stderr)

# ---- regex that cua admin-analytics.php ----
pm = re.search(r"\$pattern = '/(.*)/';", php)
rx = re.compile(pm.group(1))
old = '203.0.113.9 - - [22/Oct/2026:10:15:03 +0700] "GET /wp-login.php HTTP/1.1" 200 1234 "-" "Mozilla/5.0" rt=0.321'
new = old + " rid=8f14e45fceea167a5a36dedd4bea2543"
mo, mn = rx.match(old), rx.match(new)
check("regex that cua admin-analytics.php doc duoc dong log DINH DANG CU", mo is not None)
check("... va doc duoc dong log DINH DANG MOI (them rid=) voi cac nhom bat giong het", mn is not None and mn.groups() == mo.groups(), str(mn and mn.groups()))
check("nhom 'rt' van la 0.321 (rid khong lan vao)", mn and mn.group(9) == "0.321")
bad = old.replace("rt=0.321", "rid=8f14e45fceea167a5a36dedd4bea2543 rt=0.321")
check("DOI CHUNG AM: chen rid TRUOC rt thi regex vo -> day la ly do bat buoc de rid o CUOI", rx.match(bad) is None)
check("analytics.php khong neo cuoi dong ($) - them truong o cuoi la an toan", not re.search(r"rt=\(\[\\d\.\]\+\)\$/", php) and pm.group(1).endswith("rt=([\\d.]+)"))
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
