#!/usr/bin/env python3
"""Kiem thu presets/ + scripts/tools/apply_preset.py (HANDOFF.md muc 1az, J4)."""
import json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
TOOL = os.path.join(ROOT, "scripts", "tools", "apply_preset.py")
sys.path.insert(0, os.path.dirname(TOOL))
import apply_preset as ap

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: passed += 1; print("PASS:", name)
    else: failed += 1; print("FAIL:", name, detail)

tmp = tempfile.mkdtemp(prefix="preset-test-")
def run(*args):
    out = os.path.join(tmp, "out.json")
    if os.path.exists(out): os.remove(out)
    r = subprocess.run([sys.executable, TOOL, *args, "--out", out], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr, (json.load(open(out)) if os.path.exists(out) else None)
def jq(expr, path):
    return subprocess.run(["jq", "-r", expr, path], capture_output=True, text=True).stdout.strip()

presets = ap.load_presets()
check("co 11 preset (7 cu + php-local + php-git + python-wsgi + python-asgi)", len(presets) == 11 and {"python-wsgi", "python-asgi"} <= set(presets), str(sorted(presets)))
default_cfg = json.load(open(os.path.join(ROOT, "site.config.json"), encoding="utf-8"))
check("site.config.json hien tai hop le", ap.validate(default_cfg) == [], str(ap.validate(default_cfg)))
wp, miss = ap.apply(presets["wordpress"], {})
check("preset wordpress == site.config.json mac dinh (khong lech nhau)", wp == default_cfg)

REQ = {"repo": "https://github.com/ban/app.git"}
for name, p in sorted(presets.items()):
    args = [name] + (["--repo", REQ["repo"]] if p.get("_requires") else [])
    rc, out, cfg = run(*args)
    check("preset %s -> ghi duoc, hop le" % name, rc == 0 and cfg is not None and ap.validate(cfg) == [], out)
    if cfg:
        check("preset %s: khong ro ri khoa noi bo (_preset/_requires)" % name, "_preset" not in cfg and "_requires" not in cfg)
        outp = os.path.join(tmp, "out.json")
        # doc bang CHINH cac lenh jq ma script runtime/site_source dung
        check("preset %s: jq doc .runtime/.site_source.type khop" % name, jq(".runtime", outp) == cfg["runtime"] and jq(".site_source.type", outp) == cfg["site_source"]["type"])
        check("preset %s: jq '.port // 8080' ra so" % name, jq(".port // 8080", outp) == "8080")

rc, out, cfg = run("node-local")
check("node-local: entry server.js doc dung bang jq cua node.sh", cfg and subprocess.run(["jq", "-r", '.entry // "server.js"', os.path.join(tmp, "out.json")], capture_output=True, text=True).stdout.strip() == "server.js")
rc, out, cfg = run("python-local")
check("python-local: entry app.py", cfg and cfg["entry"] == "app.py" and cfg["runtime"] == "python")
rc, out, cfg = run("wordpress", "--port", "9000")
check("override --port 9000", rc == 0 and cfg["port"] == 9000)
rc, out, cfg = run("node-git", "--repo", "git@github.com:ban/app.git", "--branch", "release/1.2", "--entry", "dist/main.js")
check("git ssh + nhanh co '/' + entry co thu muc con", rc == 0 and cfg["site_source"]["branch"] == "release/1.2" and cfg["entry"] == "dist/main.js", out)
rc, out, cfg = run("static-local", "--runtime", "static", "--type", "zip", "--url", "https://example.com/d.zip?token=a&x=1")
check("zip URL co ?query&tham so duoc chap nhan", rc == 0 and cfg["site_source"]["url"].endswith("x=1"), out)

rc, out, cfg = run("node-local", "--no-install-deps")
check("--no-install-deps -> install_deps=false trong file ghi ra, jq doc dung (khong roi vao bay '// true')", rc == 0 and cfg["install_deps"] is False and jq("if .install_deps == false then \"false\" else \"true\" end", os.path.join(tmp, "out.json")) == "false", out)
rc, out, cfg = run("wordpress")
check("mac dinh install_deps=true trong moi preset", rc == 0 and cfg["install_deps"] is True)
check("moi preset co install_deps (khong preset nao cu thieu truong)", all("install_deps" in p for p in presets.values()))
bad = dict(default_cfg); bad["install_deps"] = "false"
check("TU CHOI: install_deps la chuoi 'false' (khong phai boolean)", any("install_deps" in m for m in ap.validate(bad)))

rc, out, cfg = run("php-local")
check("php-local: runtime php, docroot=public, profile=generic, jq doc dung", rc == 0 and cfg["runtime"] == "php" and cfg["docroot"] == "public" and cfg["profile"] == "generic" and jq(".docroot", os.path.join(tmp, "out.json")) == "public", out)
rc, out, cfg = run("php-git", "--repo", REQ["repo"], "--db-name", "my_shop")
check("php-git + --db-name my_shop", rc == 0 and cfg["db_name"] == "my_shop" and cfg["profile"] == "generic", out)
rc, out, cfg = run("static-local", "--docroot", "dist")
check("static-local + --docroot dist (runtime static duoc phep)", rc == 0 and cfg["docroot"] == "dist", out)
rc, out, cfg = run("php-local", "--docroot", "web/public")
check("docroot nhieu cap web/public duoc phep", rc == 0 and cfg["docroot"] == "web/public", out)
check("moi preset co docroot/profile/db_name", all(k in p for p in presets.values() for k in ("docroot", "profile", "db_name")))

# Tu choi - KHONG ghi file
bad_cases = [
    ("preset khong ton tai", ["nope"]),
    ("git thieu --repo", ["node-git"]),
    ("port 80 (<1024)", ["wordpress", "--port", "80"]),
    ("port 65535 (staging can PORT+1)", ["wordpress", "--port", "65535"]),
    ("port 0", ["wordpress", "--port", "0"]),
    ("runtime khong ho tro", ["wordpress", "--runtime", "ruby"]),
    ("wordpress + runtime node (vo nghia)", ["wordpress", "--runtime", "node"]),
    ("entry co '..'", ["node-local", "--entry", "../etc/passwd"]),
    ("entry bat dau '/'", ["node-local", "--entry", "/etc/passwd"]),
    ("entry co dau nhay (se pha JSON exec)", ["node-local", "--entry", 'a".js']),
    ("entry co khoang trang", ["node-local", "--entry", "my app.js"]),
    ("entry kieu chen lenh", ["node-local", "--entry", 'a";touch x;"']),
    ("repo bat dau '-' (chen tuy chon git)", ["node-git", "--repo", "--upload-pack=touch x"]),
    ("repo file:// (khong ho tro)", ["node-git", "--repo", "file:///etc"]),
    ("repo co khoang trang/;", ["node-git", "--repo", "https://x.com/a.git; rm -rf /"]),
    ("branch bat dau '-'", ["node-git", "--repo", REQ["repo"], "--branch", "-x"]),
    ("local path tuyet doi", ["static-local", "--path", "/etc"]),
    ("docroot co '..'", ["php-local", "--docroot", "../etc"]),
    ("docroot tuyet doi", ["php-local", "--docroot", "/etc"]),
    ("docroot co khoang trang", ["php-local", "--docroot", "my public"]),
    ("docroot kieu chen lenh", ["php-local", "--docroot", "public;rm -rf /"]),
    ("docroot co thanh phan '.' ", ["php-local", "--docroot", "a/./b"]),
    ("docroot bat dau bang '-' (giong tuy chon)", ["php-local", "--docroot", "-rf"]),
    ("docroot voi runtime node (khong ap dung)", ["node-local", "--docroot", "public"]),
    ("profile khong hop le", ["php-local", "--profile", "joomla"]),
    ("db_name = mysql (trung DB he thong)", ["php-local", "--db-name", "mysql"]),
    ("db_name bat dau bang so", ["php-local", "--db-name", "1app"]),
    ("db_name co dau gach ngang", ["php-local", "--db-name", "my-app"]),
    ("db_name 33 ky tu", ["php-local", "--db-name", "a" * 33]),
    ("profile wordpress + db_name khac 'wordpress'", ["wordpress", "--db-name", "shop"]),
    ("type wordpress + profile generic (mau thuan)", ["wordpress", "--profile", "generic"]),
    ("local path co '..'", ["static-local", "--path", "../x"]),
    ("zip url khong phai http(s)", ["static-local", "--type", "zip", "--url", "ftp://x/y.zip"]),
    ("zip url co dau nhay", ["static-local", "--type", "zip", "--url", 'https://x/y.zip"']),
]
for name, args in bad_cases:
    rc, out, cfg = run(*args)
    check("TU CHOI: " + name, rc != 0 and cfg is None, "rc=%s cfg=%s out=%s" % (rc, cfg, out[:100]))

# ---- front_proxy (HANDOFF.md muc 1bi) ----
rc, out, cfg = run("node-local", "--front-proxy", "true")
check("node-local --front-proxy true -> front_proxy=true (kieu BOOLEAN, khong phai chuoi)", rc == 0 and cfg["front_proxy"] is True, out)
rc, out, cfg = run("static-local", "--front-proxy", "false")
check("static-local --front-proxy false -> front_proxy=false", rc == 0 and cfg["front_proxy"] is False, out)
rc, out, cfg = run("php-local", "--front-proxy", "true")
check("TU CHOI: front_proxy voi runtime php (php da co nginx rieng)", rc != 0 and cfg is None and "front_proxy chi ap dung" in out, out)
check("preset node/python mac dinh front_proxy=false; static mac dinh true", all(presets[n]["front_proxy"] is False for n in ("node-local", "node-git", "python-local", "python-git")) and all(presets[n]["front_proxy"] is True for n in ("static-local", "static-git")), {n: presets[n].get("front_proxy") for n in presets})
check("validate bat gia tri khong phai boolean", any("front_proxy phai la true/false" in e for e in ap.validate(dict(default_cfg, runtime="node", front_proxy="yes", site_source={"type": "local", "path": "site"}))), ap.validate(dict(default_cfg, runtime="node", front_proxy="yes", site_source={"type": "local", "path": "site"})))
rc, out, _ = run("--list")
check("--list in du 7 preset", rc == 0 and all(n in out for n in presets), out)
before = open(os.path.join(ROOT, "site.config.json"), encoding="utf-8").read()
subprocess.run([sys.executable, TOOL, "wordpress", "--port", "80", "--out", os.path.join(tmp, "x.json")], capture_output=True)
check("loi khong dung vao site.config.json that", open(os.path.join(ROOT, "site.config.json"), encoding="utf-8").read() == before)

print("\nTONG KET: pass=%d fail=%d" % (passed, failed))
sys.exit(1 if failed else 0)
