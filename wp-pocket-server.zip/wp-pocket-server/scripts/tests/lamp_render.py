"""Render nginx.conf.template / php-fpm.conf.template DUNG NHU start-lamp.sh (HANDOFF.md muc 1bb).

Danh sach placeholder -> bien duoc TRICH TRUC TIEP tu cac lenh `sed -e "s#__X__#$VAR#g"` trong start-lamp.sh, khong chep lai o tung
test. Neu start-lamp.sh them placeholder moi ma test chua cung cap gia tri bien -> loi ro rang (thay vi nginx/php-fpm that su chay
voi chuoi "__X__" con sot); neu template co placeholder ma start-lamp.sh khong thay -> loi (phat hien lech trong chinh du an).
"""
import os, re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
TPLDIR = os.path.join(ROOT, 'scripts', 'runtimes', 'templates')
START_LAMP = os.path.join(TPLDIR, 'start-lamp.sh')


def sed_pairs(template_name, start_lamp_text=None):
    """[(placeholder, bien_shell)] cua lenh sed render <template_name> trong start-lamp.sh."""
    text = start_lamp_text if start_lamp_text is not None else open(START_LAMP, encoding='utf-8').read()
    end = text.find('"$SUP/%s"' % template_name)
    if end < 0:
        raise LookupError('start-lamp.sh khong co lenh sed render %s' % template_name)
    start = text.rfind('\nsed ', 0, end)          # lenh sed GAN NHAT truoc ten template (khong lan sang khoi sed cua template khac)
    if start < 0:
        raise LookupError('khong thay lenh sed truoc %s' % template_name)
    block = text[start:end]
    return [(ph, var) for _d, ph, var in re.findall(r'-e "s([#|])(__[A-Z0-9_]+__)\1\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?\1g"', block)]


def leftover(text):
    """Placeholder con sot o dong KHONG phai chu thich."""
    return sorted({p for line in text.splitlines() if not line.lstrip().startswith(('#', ';')) for p in re.findall(r'__[A-Z][A-Z0-9_]*__', line)})


def render(template_text, template_name, values, start_lamp_text=None):
    out = template_text
    for ph, var in sed_pairs(template_name, start_lamp_text):
        if var not in values:
            raise KeyError('start-lamp.sh render %s dung bien $%s cho %s nhung test chua cung cap gia tri' % (template_name, var, ph))
        out = out.replace(ph, str(values[var]))
    left = leftover(out)
    if left:
        raise ValueError('template %s con placeholder start-lamp.sh KHONG thay: %s' % (template_name, left))
    if template_name == 'nginx.conf.template' and values.get('RUNDIR') and os.path.isdir(str(values['RUNDIR'])):
        # geo ... { include __RUNDIR__/ban-list.conf; } (HANDOFF.md muc 1br): nginx that bao loi neu file khong ton tai. start-lamp.sh tao file
        # rong truoc khi bat nginx; test render o day cung phai lam dung nhu vay de nginx that (neu co) khoi dong duoc. Chi khi thu muc chay
        # da ton tai (test chay nginx that luon tao truoc; test chi render chuoi khong bi tao thu muc la).
        try:
            open(os.path.join(str(values['RUNDIR']), 'ban-list.conf'), 'a').close()
        except OSError:
            pass
    return out


def sql_init_block(start_lamp_text=None):
    """Noi dung heredoc SQL khoi tao CSDL (giua '<<SQL' va dong 'SQL') trong start-lamp.sh."""
    text = start_lamp_text if start_lamp_text is not None else open(START_LAMP, encoding='utf-8').read()
    m = re.search(r'-uroot <<SQL\n(.*?)\nSQL\n', text, re.S)
    if not m:
        raise LookupError('khong tim thay heredoc SQL khoi tao CSDL')
    return m.group(1)
