#!/bin/sh
# Chay kiem thu JVM cho ApiLogic.kt (can kotlinc + java). HANDOFF.md muc 1bp-L.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/ApiLogic.kt" "$HERE/ApiLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" ApiLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
