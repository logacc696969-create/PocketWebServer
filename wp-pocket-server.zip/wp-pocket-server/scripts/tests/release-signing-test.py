#!/usr/bin/env python3
"""Kiem thu ky ban phat hanh (HANDOFF.md muc 1br-H): script tao khoa (chay THAT bang keytool), apk_signer_check.py (voi apksigner GIA nhung chung chi THAT tu keytool),
va kiem tinh Gradle/CI/.gitignore (khong mat khau trong repo; thieu khoa => khong ky bang khoa debug; tag phat hanh KHONG am tham dung khoa debug)."""
import os, re, shutil, stat, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
TOOLS = os.path.join(ROOT, 'scripts', 'tools')
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:300]) if d else ''))


def rd(*p):
    return open(os.path.join(ROOT, *p), encoding='utf-8').read()


def sh(*a, **k):
    return subprocess.run(list(a), capture_output=True, text=True, **k)


def fp_of(ks, pw, alias):
    r = sh('keytool', '-list', '-v', '-keystore', ks, '-storepass', pw, '-alias', alias)
    m = re.search(r'SHA256:\s*([0-9A-F:]+)', r.stdout + r.stderr)
    return m.group(1).replace(':', '').lower() if m else ''


def fake_apksigner(path, table):
    """apksigner gia: doc ten tep APK -> in ket qua theo `table` {ten: (ma_thoat, v2, sha256)}."""
    lines = ['#!/bin/sh', 'apk="$(basename "$4")"', 'case "$apk" in']
    for name, (rc, v2, fp) in table.items():
        lines.append('  %s) echo "%s"; echo "Verified using v2 scheme (APK Signature Scheme v2): %s"; echo "Signer #1 certificate SHA-256 digest: %s"; exit %d ;;' %
                     (name, 'Verifies' if rc == 0 else 'DOES NOT VERIFY', 'true' if v2 else 'false', fp, rc))
    lines += ['  *) echo unknown; exit 9 ;;', 'esac']
    open(path, 'w').write('\n'.join(lines) + '\n')
    os.chmod(path, 0o755)


def main():
    if not shutil.which('keytool') or not shutil.which('openssl'):
        print('(bo qua: can keytool va openssl)')
        return 0
    tmp = tempfile.mkdtemp(prefix='relsign-')
    try:
        # ---- 1. script tao khoa ----
        dest = os.path.join(tmp, 'keys')
        r = sh('sh', os.path.join(TOOLS, 'make_release_keystore.sh'), dest, 'Chu Thu Nghiem')
        check('make_release_keystore.sh tao khoa that', r.returncode == 0 and os.path.isfile(os.path.join(dest, 'release.jks')), (r.stdout + r.stderr)[-300:])
        sec = open(os.path.join(dest, 'secrets.txt')).read() if os.path.isfile(os.path.join(dest, 'secrets.txt')) else ''
        vals = dict(l.split('=', 1) for l in sec.splitlines() if '=' in l and not l.startswith('#'))
        check('secrets.txt co dung 4 bi-mat can cho CI', set(vals) == {'RELEASE_KEYSTORE_B64', 'RELEASE_KEYSTORE_PASSWORD', 'RELEASE_KEY_ALIAS', 'RELEASE_KEY_PASSWORD'}, list(vals))
        check('mat khau >= 24 ky tu ngau nhien, key == store', len(vals.get('RELEASE_KEYSTORE_PASSWORD', '')) >= 24 and vals.get('RELEASE_KEYSTORE_PASSWORD') == vals.get('RELEASE_KEY_PASSWORD'))
        modes = {n: stat.S_IMODE(os.stat(os.path.join(dest, n)).st_mode) for n in ('release.jks', 'secrets.txt', 'release.jks.b64')}
        check('tep khoa/secrets quyen 0600, thu muc 0700', all(m == 0o600 for m in modes.values()) and stat.S_IMODE(os.stat(dest).st_mode) == 0o700, modes)
        import base64
        b64 = vals.get('RELEASE_KEYSTORE_B64', '')
        check('RELEASE_KEYSTORE_B64 giai ma ra DUNG tep release.jks', base64.b64decode(b64) == open(os.path.join(dest, 'release.jks'), 'rb').read() if b64 else False)
        info = sh('keytool', '-list', '-v', '-keystore', os.path.join(dest, 'release.jks'), '-storepass', vals.get('RELEASE_KEYSTORE_PASSWORD', 'x'))
        check('khoa RSA 4096, han ~30 nam, alias wppocket-release', 'RSA' in info.stdout and '4096' in info.stdout and 'wppocket-release' in info.stdout, info.stdout[-300:])
        r2 = sh('sh', os.path.join(TOOLS, 'make_release_keystore.sh'), dest)
        check('KHONG ghi de khoa da co (mat khoa = mat quyen cap nhat app)', r2.returncode != 0 and 'TU CHOI' in r2.stderr, r2.stderr)
        repo_dest = os.path.join(tmp, 'fakerepo', 'sub')
        os.makedirs(os.path.join(tmp, 'fakerepo', '.git'))
        r3 = sh('sh', os.path.join(TOOLS, 'make_release_keystore.sh'), repo_dest)
        check('TU CHOI tao khoa ben trong kho git (tranh commit nham)', r3.returncode != 0 and 'git' in r3.stderr and not os.path.exists(os.path.join(repo_dest, 'release.jks')), r3.stderr)
        r4 = sh('sh', os.path.join(TOOLS, 'make_release_keystore.sh'))
        check('thieu tham so: bao cach dung, ma thoat 2', r4.returncode == 2)

        # ---- 2. apk_signer_check.py ----
        rel_fp = fp_of(os.path.join(dest, 'release.jks'), vals['RELEASE_KEYSTORE_PASSWORD'], 'wppocket-release')
        dbg_ks = os.path.join(ROOT, 'app', 'debug.keystore')
        dbg_fp = fp_of(dbg_ks, 'android', 'androiddebugkey')
        check('doc duoc dau van tay khoa debug that trong repo', len(dbg_fp) == 64 and dbg_fp != rel_fp, dbg_fp)
        fa = os.path.join(tmp, 'apksigner')
        for n in ('a-arm64-release.apk', 'a-v7-release.apk', 'a-uni-release.apk', 'dbg.apk', 'v1only.apk', 'bad.apk', 'other.apk'):
            open(os.path.join(tmp, n), 'wb').write(b'PK')
        table = {'a-arm64-release.apk': (0, True, rel_fp), 'a-v7-release.apk': (0, True, rel_fp), 'a-uni-release.apk': (0, True, rel_fp),
                 'dbg.apk': (0, True, dbg_fp), 'v1only.apk': (0, False, rel_fp), 'bad.apk': (1, True, rel_fp), 'other.apk': (0, True, 'ab' * 32)}
        fake_apksigner(fa, table)

        def chk(*apks):
            r = sh(sys.executable, os.path.join(TOOLS, 'apk_signer_check.py'), '--apksigner', fa, '--debug-keystore', dbg_ks, *[os.path.join(tmp, a) for a in apks])
            return r.returncode, r.stdout + r.stderr
        rc, out = chk('a-arm64-release.apk', 'a-v7-release.apk', 'a-uni-release.apk')
        check('3 APK cung chung chi phat hanh: OK + in dau van tay', rc == 0 and rel_fp.upper()[:2] in out and 'Chung chi phat hanh' in out, out)
        rc, out = chk('dbg.apk')
        check('APK ky bang khoa DEBUG cong khai: BI TU CHOI', rc == 1 and 'KHOA DEBUG' in out, out)
        rc, out = chk('a-arm64-release.apk', 'other.apk')
        check('cac APK ky bang chung chi KHAC nhau: BI TU CHOI', rc == 1 and 'KHAC NHAU' in out, out)
        rc, out = chk('v1only.apk')
        check('chi ky v1 (khong v2/v3): BI TU CHOI', rc == 1 and 'v2/v3' in out, out)
        rc, out = chk('bad.apk')
        check('apksigner verify that bai: BI TU CHOI', rc == 1 and 'that bai' in out, out)
        def chk2(exp, *apks):
            r = sh(sys.executable, os.path.join(TOOLS, 'apk_signer_check.py'), '--apksigner', fa, '--debug-keystore', dbg_ks, '--expect-sha256', exp, *[os.path.join(tmp, a) for a in apks])
            return r.returncode, r.stdout + r.stderr
        pin = ':'.join(rel_fp[i:i + 2] for i in range(0, 64, 2)).upper()
        rc, out = chk2(pin, 'a-arm64-release.apk', 'a-v7-release.apk')
        check('--expect-sha256 dung (co dau :, hoa/thuong): OK', rc == 0, out)
        rc, out = chk2('cd' * 32, 'a-arm64-release.apk')
        check('--expect-sha256 KHAC chung chi that: BI TU CHOI (secret bi thay)', rc == 1 and 'KHAC dau van tay mong doi' in out, out)
        rc, out = chk2('abc123', 'a-arm64-release.apk')
        check('--expect-sha256 sai dinh dang: BI TU CHOI (khong am tham bo qua)', rc == 1 and 'khong phai dau van tay' in out, out)
        r = sh(sys.executable, os.path.join(TOOLS, 'apk_signer_check.py'), '--apksigner', os.path.join(tmp, 'khong-co'), os.path.join(tmp, 'a-arm64-release.apk'))
        check('apksigner khong chay duoc: loi (khong am tham bao OK)', r.returncode != 0, (r.returncode, r.stdout, r.stderr))

        # ---- 3. kiem tinh Gradle / CI / .gitignore ----
        g = rd('app', 'build.gradle.kts')
        check('Gradle: khoa phat hanh doc tu bien moi truong RELEASE_KEYSTORE_*', all(k in g for k in ('RELEASE_KEYSTORE_FILE', 'RELEASE_KEYSTORE_PASSWORD', 'RELEASE_KEY_ALIAS', 'RELEASE_KEY_PASSWORD')))
        check('Gradle: ban phat hanh isDebuggable = false', re.search(r'release\s*\{[^}]*isDebuggable\s*=\s*false', g, re.S) is not None)
        block = g[g.index('val releaseKeystore'):g.index('buildTypes')]
        check('Gradle: khong co mat khau/tep khoa viet cung cho ban phat hanh', not re.search(r'(storePassword|keyPassword)\s*=\s*"', block) and '.jks' not in block)
        rel_block = g[g.index('buildTypes'):g.index('compileOptions')]
        check('Gradle: ban release KHONG dung signingConfigs.debug khi thieu khoa (chi dung "release" co dieu kien)', 'getByName("debug")' not in rel_block and 'getByName("release")' in rel_block)
        gi = rd('.gitignore')
        check('.gitignore chan *.jks, *.keystore (tru app/debug.keystore)', '*.jks' in gi and '*.keystore' in gi and '!app/debug.keystore' in gi)
        tracked = [os.path.join(dp, f) for dp, _, fs in os.walk(ROOT) for f in fs if f.endswith(('.jks', '.p12', '.pfx'))]
        check('khong co tep .jks/.p12/.pfx nao trong cay ma nguon', not tracked, tracked)
        wf = rd('.github', 'workflows', 'build-apk.yml')
        check('CI: co buoc build ban phat hanh co dieu kien theo secret, giai ma khoa vao RUNNER_TEMP', 'RELEASE_KEYSTORE_B64' in wf and 'assembleRelease' in wf and 'RUNNER_TEMP' in wf and "env.HAS_RELEASE_KEY == 'true'" in wf)
        check('CI: co the ghim dau van tay chung chi bang bien repo RELEASE_CERT_SHA256', 'RELEASE_CERT_SHA256' in wf and '--expect-sha256' in wf)
        check('CI: kiem chu ky bang apk_signer_check.py roi moi upload artifact release', wf.index('apk_signer_check.py') < wf.index('wp-pocket-server-release-apk'))
        check('CI: xoa tep khoa sau khi build (shred/rm) va khong echo secret', ('shred' in wf or 'rm -f "$RUNNER_TEMP/release.jks"' in wf) and not re.search(r'echo\s+["\']?\$\{?\{?\s*secrets\.', wf))
        rel = wf[wf.index('\n  release:'):]
        rel = rel[:rel.index('\n  runtime-packaging:')] if '\n  runtime-packaging:' in rel else rel
        check('CI: job release tai artifact release-apk va TU CHOI neu thieu (tru khi ALLOW_DEBUG_SIGNED_RELEASE=1)', 'wp-pocket-server-release-apk' in rel and 'ALLOW_DEBUG_SIGNED_RELEASE' in rel and 'exit 1' in rel)
        check('CI: job release KHONG tai artifact debug mac dinh (chi khi co bien cho phep)', re.search(r'name:\s*wp-pocket-server-debug-apk', rel) is None or 'ALLOW_DEBUG_SIGNED_RELEASE' in rel[rel.index('wp-pocket-server-debug-apk') - 400:rel.index('wp-pocket-server-debug-apk') + 100])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
