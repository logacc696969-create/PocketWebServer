import com.wppocket.server.PasswordPolicy
import com.wppocket.server.PasswordPolicy.Problem
import java.security.SecureRandom
import java.util.Random

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }
fun p(s: String) = PasswordPolicy.check(s)

fun main() {
    // ---- tu choi: ngan / pho bien ----
    check("rong -> TOO_SHORT", p("") == Problem.TOO_SHORT)
    check("7 ky tu -> TOO_SHORT (ranh gioi: 8 moi dat)", p("Xk9#mQ2") == Problem.TOO_SHORT && p("Xk9#mQ2z") == null)
    // truoc 1bc: do dai >= 6 chap nhan nhung mat khau nay -> bay gio phai bi chan
    for (w in listOf("123456", "password", "qwerty", "111111", "abc123", "letmein", "admin")) {
        check("'$w' (tung duoc chap nhan neu >= 6 ky tu) bay gio bi chan", p(w) != null)
    }
    check("'password' -> TOO_COMMON", p("password") == Problem.TOO_COMMON)
    check("viet HOA 'PASSWORD' van bi chan", p("PASSWORD") == Problem.TOO_COMMON)
    check("duoi so: 'password123' -> TOO_COMMON", p("password123") == Problem.TOO_COMMON)
    check("duoi so + ky hieu: 'Admin2024!' -> TOO_COMMON", p("Admin2024!") == Problem.TOO_COMMON)
    check("leet: 'p@ssw0rd' -> TOO_COMMON", p("p@ssw0rd") == Problem.TOO_COMMON)
    check("leet + duoi: 'P@ssw0rd99' -> TOO_COMMON", p("P@ssw0rd99") == Problem.TOO_COMMON)
    check("dac thu du an: 'wordpress1' / 'wppocket' bi chan", p("wordpress1") == Problem.TOO_COMMON && p("wppocket") == Problem.TOO_COMMON)
    check("tieng Viet: 'matkhau123' / 'anhyeuem' bi chan", p("matkhau123") == Problem.TOO_COMMON && p("anhyeuem") == Problem.TOO_COMMON)

    // ---- tu choi: day / lap ----
    check("'12345678' -> day so (hoac pho bien)", p("12345678") != null)
    check("'87654321' (day so NGUOC) bi chan", p("87654321") == Problem.SEQUENCE_OR_REPEAT)
    check("'abcdefghij' (day chu) bi chan", p("abcdefghij") == Problem.SEQUENCE_OR_REPEAT)
    check("'qwertyuiop' / 'asdfghjkl' (hang phim) bi chan", p("qwertyuiop") != null && p("asdfghjkl") != null)
    check("'aaaaaaaa' -> bi chan", p("aaaaaaaa") != null)
    check("'abababab' / 'abcabcabc' / '12341234' (lap don vi) bi chan",
        p("abababab") == Problem.SEQUENCE_OR_REPEAT && p("abcabcabc") == Problem.SEQUENCE_OR_REPEAT && p("12341234") == Problem.SEQUENCE_OR_REPEAT)
    check("it ky tu khac nhau (< 4) -> LOW_VARIETY: 'aabbaaabb'", p("aabbaaabb") == Problem.LOW_VARIETY)

    // ---- tu choi: dau cach / ky tu dieu khien (LOI KHOA DANG NHAP THAT) ----
    check("dau cach o CUOI bi chan", p("Xk9#mQ2z ") == Problem.WHITESPACE_OR_CONTROL)
    check("dau cach o DAU bi chan", p(" Xk9#mQ2z") == Problem.WHITESPACE_OR_CONTROL)
    check("xuong dong cuoi (EditText cho phep) bi chan", p("Xk9#mQ2z\n") == Problem.WHITESPACE_OR_CONTROL)
    check("xuong dong GIUA bi chan", p("Xk9#mQ\n2z") == Problem.WHITESPACE_OR_CONTROL)
    check("tab bi chan", p("Xk9#\tmQ2z") == Problem.WHITESPACE_OR_CONTROL)
    check("dau cach o GIUA van OK (cum tu): 'Mot cum tu dai 2026'", p("Mot cum tu dai 2026") == null)
    check("thu tu uu tien: dau cach bao truoc 'qua ngan'", p("abc ") == Problem.WHITESPACE_OR_CONTROL)

    // ---- chap nhan: khong nag nguoi dung ----
    for (ok in listOf("Xk9#mQ2z", "correct horse battery staple", "Mot cum tu dai 2026", "T3stK3y-unusual", "v1etnamTr@nsit77", "Zq8wLm3pXv", "kh0ng-ai-doan-duoc"))
        check("'$ok' dat chinh sach", p(ok) == null)
    check("passphrase chu thuong khong ky hieu van dat ('banhmithitnuong')", p("banhmithitnuong") == null)
    check("unicode (tieng Viet co dau) dat: 'Mật khẩu rất dài 99'", p("Mật khẩu rất dài 99") == null)

    // ---- bo sinh mat khau ----
    val rnd = SecureRandom()
    var allOk = true; var lenOk = true; var alphaOk = true
    val seen = HashSet<String>()
    repeat(5000) {
        val g = PasswordPolicy.generate(rnd)
        if (PasswordPolicy.check(g) != null) allOk = false
        if (g.length != PasswordPolicy.GENERATED_LENGTH) lenOk = false
        if (g.any { it !in PasswordPolicy.GENERATED_ALPHABET }) alphaOk = false
        seen.add(g)
    }
    check("5000 mat khau sinh ra DEU dat chinh sach", allOk)
    check("deu dung do dai 16 va chi dung bang ky tu khong de nham", lenOk && alphaOk)
    check("khong trung lap (5000 gia tri khac nhau)", seen.size == 5000)
    check("bang ky tu khong chua I, l, O, 0, 1", PasswordPolicy.GENERATED_ALPHABET.none { it in "IlO01" })
    // Random xac dinh (khong SecureRandom): van ra mat khau hop le va co lap lai den khi dat
    val fixed = PasswordPolicy.generate(Random(42))
    check("generate(Random co dinh) hop le + tai lap duoc", PasswordPolicy.check(fixed) == null && fixed == PasswordPolicy.generate(Random(42)))
    // Random pha: luon tra 0 => 'AAAAAAAAAAAAAAAA' (lap) -> phai LAP LAI chu khong tra mat khau yeu
    var calls = 0
    val stubborn = object : Random() { override fun nextInt(bound: Int): Int { calls++; return if (calls <= PasswordPolicy.GENERATED_LENGTH) 0 else (calls * 7) % bound } }
    val g2 = PasswordPolicy.generate(stubborn)
    check("generate KHONG BAO GIO tra mat khau yeu: Random dau tien cho 'AAAA...' -> tu bo, sinh lai", PasswordPolicy.check(g2) == null && g2 != "A".repeat(16))

    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) kotlin.system.exitProcess(1)
}
