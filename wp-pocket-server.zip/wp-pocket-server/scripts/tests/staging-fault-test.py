#!/usr/bin/env python3
"""Kiem thu CHEN LOI (fault injection) cho _admin/staging.php - xem HANDOFF.md muc 1ax.
staging.php thao tac tren DU LIEU THAT (nhan ban DB + file, ghi de site LIVE khi 'promote',
rm -rf). Bo test dung cong cu GIA (libmysqlcli.so/libmysqldump.so/cp) co the bi bat THAT BAI
dung o tung buoc, de kiem tra: khi 1 buoc loi thi KHONG duoc mat du lieu va KHONG bao 'thanh cong'.
Chay: python3 scripts/tests/staging-fault-test.py   (can php, python3)
Khong dung MariaDB that: day la kiem tra TRINH TU/XU LY LOI cua trang (cac buoc nao chay, co dung
khi loi khong), khong phai kiem tra cu phap SQL. Neu bien moi truong STAGING_PAGE duoc dat, test trang do
(dung de doi chung am voi ban cu).
"""
import importlib.util, os, re, shutil, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check

FAKE_MYSQL = r'''#!/bin/sh
# MySQL CLI gia: ghi lai moi lan goi; nhan SQL qua -e hoac stdin; co the bi bat that bai.
D="$(dirname "$0")"
DB=""; SQL=""
while [ $# -gt 0 ]; do
  case "$1" in
    -e) SQL="$2"; shift ;;
    --socket=*|-u*|-p*) ;;
    -*) ;;
    *) DB="$1" ;;
  esac
  shift
done
if [ -n "$SQL" ]; then
  echo "SQL: $SQL" >> "$D/mysql.log"
  [ -f "$D/fail-mysql-sql" ] && { echo "ERROR 2002: cannot connect" >&2; exit 1; }
  exit 0
fi
cat > "$D/imported-$DB.sql"
echo "IMPORT: $DB bytes=$(wc -c < "$D/imported-$DB.sql")" >> "$D/mysql.log"
[ -f "$D/fail-import-$DB" ] && { echo "ERROR 1062: duplicate entry" >&2; exit 1; }
[ -f "$D/fail-once-import-$DB" ] && { rm -f "$D/fail-once-import-$DB"; echo "ERROR 1062: duplicate entry" >&2; exit 1; }
exit 0
'''
FAKE_DUMP = r'''#!/bin/sh
# mysqldump gia: in dump gia ra stdout; co the that bai CHI cho 1 DB cu the (flag fail-dump-<db>).
D="$(dirname "$0")"
for LAST; do :; done
DB="$LAST"
echo "DUMP: $DB" >> "$D/mysql.log"
if [ -f "$D/fail-dump-$DB" ]; then
  echo "-- DUMP-PARTIAL $DB"
  echo "mysqldump: Got error: 2013: Lost connection to MySQL server during query" >&2
  exit 2
fi
echo "-- DUMP-OF-$DB"
echo "DROP TABLE IF EXISTS wp_options;"
echo "INSERT INTO wp_options VALUES ('siteurl','http://example');"
echo "-- Dump completed on 2026-10-07"
'''
CP_SHIM = r'''#!/bin/sh
# cp co the that bai khi dich la thu muc www (mo phong het bo nho giua chung)
for LAST; do :; done
if [ -f "$FAULT_DIR/fail-cp-to-www" ]; then
  case "$LAST" in */www|*/www.new|*/www.promote-new) exit 1 ;; esac
fi
exec /bin/cp "$@"
'''


def wr(path, text, mode=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w').write(text)
    if mode:
        os.chmod(path, mode)


def main():
    page_src = os.environ.get('STAGING_PAGE') or os.path.join(HERE, '..', 'runtimes', 'templates', 'admin-staging.php')
    tmp = tempfile.mkdtemp(prefix='stg-')
    try:
        os.chmod(tmp, 0o755)
        app, run, www0, adm0 = sec.build_tree(tmp)
        www = os.path.join(app, 'www')  # staging.php dung $APP_HOME/www lam docroot
        shutil.move(www0, www)
        adm = os.path.join(www, '_admin')
        shutil.copy(page_src, os.path.join(adm, 'staging.php'))
        wr(os.path.join(www, 'wp-config.php'),
           "<?php\ndefine('DB_NAME', 'wordpress');\ndefine('DB_USER', 'wordpress');\nrequire_once ABSPATH . 'wp-settings.php';\n")
        wr(os.path.join(www, 'wp-content', 'uploads', 'photo.jpg'), 'IMG')
        open(os.path.join(run, 'mysql.sock'), 'w').write('')  # chi can file_exists()
        ext = os.path.join(tmp, 'ext')
        wr(os.path.join(ext, 'libmysqlcli.so'), FAKE_MYSQL, 0o755)
        wr(os.path.join(ext, 'libmysqldump.so'), FAKE_DUMP, 0o755)
        shim = os.path.join(tmp, 'shim'); wr(os.path.join(shim, 'cp'), CP_SHIM, 0o755)
        marker = os.path.join(www, 'MARKER.txt')
        staging = os.path.join(app, 'www-staging')
        safety = os.path.join(app, 'staging-safety-backups')
        mlog = os.path.join(ext, 'mysql.log')

        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        env = dict(os.environ, APP_HOME=app, EXT_DIR=ext, STAGING_PORT='18999', FAULT_DIR=ext,
                   PATH=shim + os.pathsep + os.environ.get('PATH', ''))
        srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
                                '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=1'],
                               env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
                except OSError: time.sleep(0.1)
            c = sec.Client(port, '10.2.2.2'); c.login()

            def reset():
                for f in os.listdir(ext):
                    if f.startswith(('fail-', 'imported-')) or f == 'mysql.log':  # ke ca 'fail-once-'
                        os.remove(os.path.join(ext, f))
                shutil.rmtree(staging, ignore_errors=True); shutil.rmtree(safety, ignore_errors=True)
                shutil.rmtree(www + '.old-before-promote', ignore_errors=True)
                for d in ('www.new', 'www.promote-new', 'www.old'):
                    shutil.rmtree(os.path.join(app, d), ignore_errors=True)
                wr(marker, 'LIVE-ORIGINAL')

            def act(action):
                tok = c.token('staging')
                sc, body, _ = c.req('POST', '/_admin/staging.php', {'action': action, 'csrf_token': tok})
                return body

            def log():
                return open(mlog).read() if os.path.exists(mlog) else ''

            def cfg(path):
                return open(os.path.join(path, 'wp-config.php')).read() if os.path.isfile(os.path.join(path, 'wp-config.php')) else None

            print('== A. clone (doi chung duong) ==')
            reset()
            body = act('clone')
            check('clone: tao www-staging/ + sua wp-config sang wordpress_staging',
                  os.path.isdir(staging) and "define('DB_NAME', 'wordpress_staging');" in (cfg(staging) or ''), body[-200:])
            check('clone: da DROP/CREATE wordpress_staging, dump DB live, nap vao staging',
                  'DUMP: wordpress' in log() and 'IMPORT: wordpress_staging' in log() and 'CREATE DATABASE wordpress_staging' in log(), log())
            check('clone: site LIVE khong bi dong den', open(marker).read() == 'LIVE-ORIGINAL' and "define('DB_NAME', 'wordpress');" in cfg(www))

            print('== B. promote duong hanh phuc ==')
            wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEW')
            body = act('promote')
            check('promote OK: file LIVE = noi dung staging', open(marker).read() == 'STAGING-NEW', body[-250:])
            check('promote OK: wp-config LIVE tro lai DB_NAME=wordpress, khong con WP_HOME dong',
                  "define('DB_NAME', 'wordpress');" in cfg(www) and '__WP_POCKET_STAGING_DYNAMIC_URL__' not in cfg(www), cfg(www))
            check('promote OK: co ban an toan truoc khi ghi de (dump DB + copy www)',
                  any(f.startswith('pre-promote-db-') for f in os.listdir(safety)) and any(f.startswith('pre-promote-www-') for f in os.listdir(safety)))
            check('promote OK: staging da don (thu muc + DB)', not os.path.exists(staging) and 'DROP DATABASE IF EXISTS wordpress_staging' in log().split('IMPORT: wordpress\n')[-1] if 'IMPORT: wordpress\n' in log() else not os.path.exists(staging))

            print('== C. promote khi DUMP STAGING that bai giua chung ==')
            reset(); act('clone'); wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEW')
            open(os.path.join(ext, 'fail-dump-wordpress_staging'), 'w').close()
            body = act('promote')
            check('dump staging loi -> site LIVE KHONG bi ghi de (file con nguyen ban)', open(marker).read() == 'LIVE-ORIGINAL', open(marker).read())
            check('dump staging loi -> KHONG nap dump hong vao DB live', 'IMPORT: wordpress\n' not in log().replace('IMPORT: wordpress_staging', ''), log())
            check('dump staging loi -> ban staging CON NGUYEN de nguoi dung thu lai', os.path.isdir(staging) and 'DROP DATABASE IF EXISTS wordpress_staging' not in log().split('DUMP: wordpress_staging')[-1])
            check('dump staging loi -> trang BAO LOI (khong noi "Da promote xong")', 'Da promote xong' not in body, body[:200])

            print('== D. promote khi cp ban staging -> www THAT BAI (het bo nho) ==')
            reset(); act('clone'); wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEW')
            open(os.path.join(ext, 'fail-cp-to-www'), 'w').close()
            body = act('promote')
            check('cp loi -> thu muc www VAN TON TAI voi noi dung LIVE cu (site khong sap)',
                  os.path.isdir(www) and os.path.isfile(marker) and open(marker).read() == 'LIVE-ORIGINAL', 'www ton tai=%s' % os.path.isdir(www))
            check('cp loi -> khong con thu muc "*.old-before-promote" bi xoa mat du lieu duy nhat', os.path.isdir(www))
            check('cp loi -> staging con nguyen', os.path.isdir(staging))
            check('cp loi -> trang BAO LOI (khong noi "Da promote xong")', 'Da promote xong' not in body, body[:200])
            if not os.path.isdir(www):
                return finish(1)  # www mat: cac buoc sau vo nghia (server cung se hong)

            print('== E. promote khi NAP vao DB LIVE that bai ==')
            reset(); act('clone'); wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEW')
            open(os.path.join(ext, 'fail-import-wordpress'), 'w').close()
            body = act('promote')
            check('nap DB live loi -> file LIVE khong bi thay (khong de DB live va file lech nhau)', open(marker).read() == 'LIVE-ORIGINAL', open(marker).read())
            check('nap DB live loi -> staging con nguyen', os.path.isdir(staging))
            check('nap DB live loi -> trang BAO LOI + chi duong dan ban an toan de khoi phuc',
                  'Da promote xong' not in body and 'pre-promote-db-' in body, body[:200])

            print('== E2. nap DB live loi MOT LAN -> TU KHOI PHUC tu ban an toan ==')
            reset(); act('clone'); wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEW')
            open(os.path.join(ext, 'fail-once-import-wordpress'), 'w').close()
            body = act('promote')
            check('nap loi 1 lan -> file LIVE khong bi thay', open(marker).read() == 'LIVE-ORIGINAL')
            check('nap loi 1 lan -> DB LIVE duoc khoi phuc tu ban an toan (lan nap cuoi cung la dump cua DB live)',
                  os.path.isfile(os.path.join(ext, 'imported-wordpress.sql')) and 'DUMP-OF-wordpress' in open(os.path.join(ext, 'imported-wordpress.sql')).read()
                  and 'DUMP-OF-wordpress_staging' not in open(os.path.join(ext, 'imported-wordpress.sql')).read(), log())
            check('nap loi 1 lan -> bao da KHOI PHUC, khong noi "Da promote xong"', 'KHOI PHUC database LIVE' in body and 'Da promote xong' not in body, body[:200])

            print('== F. clone khi DUMP DB LIVE that bai ==')
            reset(); open(os.path.join(ext, 'fail-dump-wordpress'), 'w').close()
            body = act('clone')
            check('clone loi dump -> KHONG de lai www-staging/ dang do', not os.path.exists(staging))
            check('clone loi dump -> da DROP database staging (khong de DB thieu du lieu)', 'DROP DATABASE IF EXISTS wordpress_staging' in log().split('DUMP: wordpress')[-1])
            check('clone loi dump -> bao loi, khong noi "Da tao xong"', 'Da tao xong' not in body and 'khong hoan chinh' in body, body[:150])
            check('clone loi dump -> site LIVE nguyen ven', open(marker).read() == 'LIVE-ORIGINAL')
            body = act('promote')
            check('sau clone loi, promote bi tu choi (khong co staging de ghi de DB that)', 'Chua co ban staging' in body, body[:120])

            print('== G. clone khi NAP vao staging that bai ==')
            reset(); open(os.path.join(ext, 'fail-import-wordpress_staging'), 'w').close()
            body = act('clone')
            check('clone loi nap -> don sach (khong www-staging/), bao loi', not os.path.exists(staging) and 'Da tao xong' not in body)
        finally:
            srv.terminate()
            try: srv.wait(timeout=5)
            except Exception: srv.kill()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return finish(0)


def finish(extra):
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL))
    return 0 if sec.FAIL == 0 and not extra else 1


if __name__ == '__main__':
    sys.exit(main())
