#!/bin/sh
# Kiem thu OPcache (HANDOFF.md muc 1aw).
#  Phan 1: chay CHINH cac doan ma trich tu start-lamp.sh (opcache_vars/render_php_ini + vong
#          cho php-fpm co tu lui) voi 1 libphpfpm.so GIA (chet khi OPcache bat) - kiem tra
#          bat/tat/tu lui/marker/Lite.
#  Phan 2: (neu co php-fpm that) kiem tra TREN ENGINE THAT rang "opcache.lockfile_path" co hieu luc:
#          duong dan khong ton tai -> chet voi dung thong bao loi cua Termux; thu muc hop le -> chay
#          va tao file khoa. (Day la bang chung cho ket luan "chi thi nay dat duoc trong php.ini".)
# Chay: sh scripts/tests/opcache-test.sh   (can sh, python3; php-fpm tuy chon)
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../runtimes/templates/start-lamp.sh"
TPL="$HERE/../runtimes/templates/php.ini.template"
W="$(mktemp -d)"
pass=0; fail=0
ok() { if [ "$1" = 0 ]; then echo "PASS: $2"; pass=$((pass+1)); else echo "FAIL: $2"; fail=$((fail+1)); fi; }

# ---- trich cac doan can test tu start-lamp.sh ----
sed -n '/^pid_alive() {/,/^wait_pid_exit() {/p' "$SRC" | sed '$d' > "$W/seg_pid.sh"
sed -n '/^# --- OPcache bat\/tat/,/^# CA cert bundle/p' "$SRC" | sed '$d' > "$W/seg1.sh"
sed -n '/^# --- php-fpm ---/,/^# --- nginx ---/p' "$SRC" | sed '$d' > "$W/seg2.sh"
[ -s "$W/seg_pid.sh" ] && [ -s "$W/seg1.sh" ] && [ -s "$W/seg2.sh" ] || { echo "KHONG trich duoc doan ma tu $SRC"; exit 2; }

mkdir -p "$W/bin" "$W/sup"
cp "$TPL" "$W/sup/php.ini.template"
cat > "$W/bin/libphpfpm.so" <<'EOF'
#!/bin/sh
INI=""
while [ $# -gt 0 ]; do case "$1" in -c) INI="$2"; shift ;; esac; shift; done
if [ "${FAKE_OPCACHE_OK:-0}" != "1" ] && grep -q '^opcache.enable = 1' "$INI"; then
  echo "Fatal Error Unable to create opcache lock file in /nonexistent: No such file or directory (2)"
  exit 1
fi
exec python3 -c "import socket,os,time;s=socket.socket(socket.AF_UNIX);s.bind(os.environ['FPM_SOCK']);s.listen(1);time.sleep(30)"
EOF
chmod +x "$W/bin/libphpfpm.so"

# run_case <ten> <MODE> <marker|-> <FAKE_OPCACHE_OK>  -> in ket qua ra $W/case.out
run_case() {
  D="$W/data-$1"; rm -rf "$D"; mkdir -p "$D/lamp-run"
  [ -n "${PRE_CASE:-}" ] && eval "$PRE_CASE"   # chuan bi them du lieu trong thu muc cua ca nay (sau khi tao, truoc khi chay)
  [ "$3" != "-" ] && printf '%s' "$3" > "$D/opcache-failed"
  (
    BIN="$W/bin"; DATA="$D"; RUNDIR="$D/lamp-run"; SUP="$W/sup"; MODE="$2"
    FPM_SOCK="$RUNDIR/fpm.sock"; export FPM_SOCK FAKE_OPCACHE_OK="$4"
    AUTO_SLEEP_PREPEND_LINE=""; APCU_EXTENSION_LINE=""; APCU_ENABLED_LINE=""; APCU_SHM_SIZE_LINE=""; APCU_ENABLE_CLI_LINE=""
    MYSQL_PID=""
    log() { echo "$*" >> "$D/log.txt"; }
    . "$W/seg_pid.sh"; . "$W/seg1.sh"; . "$W/seg2.sh"
    # don tien trinh gia
    [ -n "$FPM_PID" ] && kill "$FPM_PID" 2>/dev/null
    echo "SOCK=$([ -S "$FPM_SOCK" ] && echo yes || echo no)" > "$D/result.txt"
  ) >/dev/null 2>&1
  INI="$D/lamp-run/php.ini"; LOG="$D/log.txt"
}

echo "== Phan 1: logic bat/tat/tu lui (doan ma that tu start-lamp.sh) =="
ID=$(stat -c %Y "$W/bin/libphpfpm.so")

run_case s1 full - 0
grep -q '^opcache.enable = 0' "$INI"; ok $? "S1 che do Full, OPcache hong: cuoi cung php.ini co opcache.enable = 0"
grep -q 'CHET khi OPcache dang BAT' "$LOG"; ok $? "S1 ghi log 'php-fpm CHET khi OPcache dang BAT' (+ noi dung loi that)"
grep -q 'Unable to create opcache lock file' "$LOG"; ok $? "S1 log chep noi dung loi cua php-fpm de de chan doan"
[ "$(cat "$W/data-s1/opcache-failed" 2>/dev/null)" = "$ID" ]; ok $? "S1 marker = mtime libphpfpm.so ($ID)"
grep -q 'SOCK=yes' "$W/data-s1/result.txt"; ok $? "S1 sau tu lui php-fpm LEN (socket ton tai) trong cung luot"
grep -q '^opcache.lockfile_path' "$INI"; [ $? = 1 ]; ok $? "S1 php.ini cuoi KHONG con dong lockfile_path"

run_case s2 full "$ID" 0
grep -q '^opcache.enable = 0' "$INI" && ! grep -q 'CHET khi OPcache' "$LOG"; ok $? "S2 marker KHOP binary: tat OPcache ngay tu dau, KHONG thu lai (khong vong lap that bai)"
grep -q 'SOCK=yes' "$W/data-s2/result.txt"; ok $? "S2 php-fpm len"

run_case s3 full 999999 0
grep -q 'CHET khi OPcache dang BAT' "$LOG" && [ "$(cat "$W/data-s3/opcache-failed")" = "$ID" ]; ok $? "S3 marker CU (binary da doi) -> thu lai OPcache, that bai thi cap nhat marker"

run_case s4 full - 1
grep -q '^opcache.enable = 1' "$INI" && grep -q "^opcache.lockfile_path = $W/data-s4/lamp-run\$" "$INI" && grep -q '^opcache.memory_consumption = 32' "$INI"; ok $? "S4 php-fpm chay duoc voi OPcache: php.ini co enable=1 + lockfile_path=RUNDIR + memory 32"
[ ! -f "$W/data-s4/opcache-failed" ] && grep -q 'SOCK=yes' "$W/data-s4/result.txt"; ok $? "S4 thanh cong thi KHONG tao marker that bai"
grep -q "^opcache.file_cache = $W/data-s4/lamp-run/opcache-file\$" "$INI" && [ -d "$W/data-s4/lamp-run/opcache-file" ]; ok $? "S4 OPcache BAT: php.ini co opcache.file_cache tro vao thu muc rieng, thu muc DA duoc tao (PHP can thu muc ton tai)"
! grep -q '^opcache.file_cache_only' "$INI"; ok $? "S4 KHONG dung file_cache_only (van dung bo nho chia se o tang 1)"
grep -q '^opcache.file_cache' "$W/data-s1/lamp-run/php.ini"; [ $? = 1 ]; ok $? "S1 OPcache tat sau tu lui: php.ini cuoi KHONG con dong file_cache"

run_case s5 lite - 1
grep -q '^opcache.enable = 0' "$INI" && ! grep -q '^opcache.lockfile_path' "$INI"; ok $? "S5 che do Lite: OPcache LUON tat (php -S khong co vong tu lui)"
grep -q 'che do Lite' "$LOG"; ok $? "S5 log ghi ro ly do"
grep -q '^opcache.file_cache' "$INI"; [ $? = 1 ]; ok $? "S5 che do Lite: KHONG co file_cache"
# vuot 100MB -> don: tao 1 file ~101MB roi chay lai S4
PRE_CASE='mkdir -p "$D/lamp-run/opcache-file"; dd if=/dev/zero of="$D/lamp-run/opcache-file/phinh.bin" bs=1024 count=104000 2>/dev/null'
run_case s6 full - 1; PRE_CASE=
[ ! -f "$W/data-s6/lamp-run/opcache-file/phinh.bin" ] && [ -d "$W/data-s6/lamp-run/opcache-file" ] && grep -q 'file_cache vuot 100MB' "$LOG"; ok $? "S6 thu muc file_cache vuot ~100MB: bi don (log) va tao lai thu muc rong"

echo "== Phan 2: engine PHP-FPM that (mo phong Android: memfd_create() that bai) =="
# PHP >= 8.2/8.5 tren Linux tao khoa bang memfd_create() - khong dung lockfile_path. Android (Bionic < API 30)
# khong co memfd_create nen roi ve open(lockfile_path, O_TMPFILE)/mkstemp -> chet neu thu muc khong ghi duoc.
# Mo phong bang shim LD_PRELOAD lam memfd_create() tra ENOSYS; xem HANDOFF.md muc 1aw.
FPM="${PHP_FPM_BIN:-$(command -v php-fpm8.5 || command -v php-fpm8.4 || command -v php-fpm8.3 || command -v php-fpm8.2 || command -v php-fpm 2>/dev/null)}"
CC_BIN="$(command -v cc || command -v gcc 2>/dev/null)"
if [ -z "$FPM" ] || [ -z "$CC_BIN" ]; then
  echo "(bo qua phan 2: can php-fpm that + trinh bien dich C de dung shim)"
else
  echo "(engine: $("$FPM" -v 2>/dev/null | head -1))"
  mkdir -p "$W/real/lockdir"
  printf '#include <errno.h>\nint memfd_create(const char *n, unsigned int f) { (void)n; (void)f; errno = ENOSYS; return -1; }\n' > "$W/real/memfd_fail.c"
  "$CC_BIN" -shared -fPIC -o "$W/real/memfd_fail.so" "$W/real/memfd_fail.c" 2>/dev/null
  cat > "$W/real/fpm.conf" <<EOF
[global]
pid = $W/real/fpm.pid
error_log = $W/real/fpm.log
daemonize = no
[www]
user = root
group = root
listen = $W/real/real.sock
pm = static
pm.max_children = 1
EOF
  mkini() { printf 'opcache.enable=1\nopcache.lockfile_path=%s\n' "$1" > "$W/real/php.ini"; }
  # chay php-fpm toi da 6s; tra ve: 0 neu chet som (loi khoi dong), 1 neu van song
  start_fpm() {  # $1 = LD_PRELOAD (hoac rong)
    rm -f "$W/real/real.sock" "$W/real/fpm.log"
    LD_PRELOAD="$1" "$FPM" -R --nodaemonize --fpm-config "$W/real/fpm.conf" -c "$W/real/php.ini" > "$W/real/out.txt" 2>&1 &
    P=$!; i=0
    while kill -0 $P 2>/dev/null && [ ! -S "$W/real/real.sock" ] && [ $i -lt 6 ]; do sleep 1; i=$((i+1)); done
    if kill -0 $P 2>/dev/null; then ALIVE=1; else ALIVE=0; fi
  }
  stop_fpm() { kill $P 2>/dev/null; wait $P 2>/dev/null; }

  mkini /data/data/com.termux/files/usr/tmp
  start_fpm ""; stop_fpm
  [ "$ALIVE" = 1 ]; ok $? "DOI CHUNG: memfd_create BINH THUONG + lockfile_path xau -> van chay (khoa bang memfd, khong dung duong dan)"

  mkini /data/data/com.termux/files/usr/tmp
  start_fpm "$W/real/memfd_fail.so"; stop_fpm
  if [ "$ALIVE" = 0 ] && grep -qi 'opcache lock file\|create lock file' "$W/real/out.txt" "$W/real/fpm.log" 2>/dev/null; then
    ok 0 "TAI HIEN loi thiet bi: memfd_create that bai + lockfile_path mac dinh Termux -> php-fpm CHET ($(grep -hi 'lock file' "$W/real/out.txt" "$W/real/fpm.log" 2>/dev/null | head -1 | sed 's/^.*Fatal Error //' | cut -c1-90))"
  else
    echo "INFO: khong tai hien duoc loi (engine nay co the cu hon va khong co nhanh memfd/O_TMPFILE) - bo qua kiem tra am, VAN kiem tra cach sua ben duoi"
  fi

  mkini "$W/real/lockdir"
  start_fpm "$W/real/memfd_fail.so"
  [ "$ALIVE" = 1 ] && [ -S "$W/real/real.sock" ]; ok $? "CACH SUA: memfd_create that bai + lockfile_path = thu muc hop le -> php-fpm LEN va mo socket"
  stop_fpm
fi

echo "== Phan 3: opcache.file_cache tren engine PHP THAT (CLI): tao tep ban dich va chay lai duoc ban dich do =="
PHP_CLI="${PHP_CLI_BIN:-$(command -v php 2>/dev/null)}"
if [ -z "$PHP_CLI" ] || ! "$PHP_CLI" -n -d zend_extension=opcache -r 'exit(extension_loaded("Zend OPcache") ? 0 : 1);' >/dev/null 2>&1; then
  echo "(bo qua phan 3: khong co php CLI hoac khong nap duoc zend_extension=opcache)"
else
  FC="$W/fc"; mkdir -p "$FC"; printf '<?php echo "HELLO-" . (40+2);\n' > "$W/hello.php"
  OUT1=$("$PHP_CLI" -n -d zend_extension=opcache -d opcache.enable=1 -d opcache.enable_cli=1 -d opcache.file_cache="$FC" "$W/hello.php" 2>&1)
  [ "$OUT1" = "HELLO-42" ]; ok $? "chay lan 1 voi file_cache cho ket qua dung ($OUT1)"
  [ -n "$(find "$FC" -name 'hello.php.bin' 2>/dev/null | head -1)" ]; ok $? "file_cache THAT SU tao tep ban dich (hello.php.bin) trong thu muc"
  OUT2=$("$PHP_CLI" -n -d zend_extension=opcache -d opcache.enable=1 -d opcache.enable_cli=1 -d opcache.file_cache="$FC" "$W/hello.php" 2>&1)
  [ "$OUT2" = "HELLO-42" ]; ok $? "chay lan 2 (doc tu file_cache, tien trinh MOI) van dung"
  printf '<?php echo "HELLO-" . (50+5);\n' > "$W/hello.php"; touch -d '+2 seconds' "$W/hello.php" 2>/dev/null
  OUT3=$("$PHP_CLI" -n -d zend_extension=opcache -d opcache.enable=1 -d opcache.enable_cli=1 -d opcache.file_cache="$FC" "$W/hello.php" 2>&1)
  [ "$OUT3" = "HELLO-55" ]; ok $? "DOI CHUNG: sua file nguon -> KHONG phuc vu ban dich cu (cap nhat plugin/WordPress van dung), ket qua: $OUT3"
fi

pkill -f "fpm.sock" 2>/dev/null
rm -rf "$W"
echo; echo "TONG KET: pass=$pass fail=$fail"; [ $fail = 0 ]
