#!/usr/bin/env python3
"""Kiem thu H1 "khoi phuc thu backup vao database tam" (HANDOFF.md muc 1bm; PDF 2 muc H1).
Phan A (luon chay, khong can DB): ban PORT Python 1-1 cua BackupLogic.classifyDumpHead/rewriteDumpForVerify/pickWpPrefix, chay CUNG vector voi
BackupLogicTest.kt (kem fuzz quanh ranh gioi 160 byte) + doi chieu van ban voi Kotlin (hang so, ten database/user, cau lenh SQL).
Phan B (can mariadbd + mariadb-dump + mariadb client): CHAY THAT dung chuoi lenh SQL ma BackupVerifier.kt dung, tren MariaDB that:
  - nap dump THAT (cung tham so mysqldump nhu app) da doi ten vao `wordpress_verify` bang user han che => thanh cong, du lieu/UTF-8 nguyen ven,
  - database THAT `wordpress` KHONG bi dung vao,
  - nap CHINH dump goc (chua USE `wordpress` + DROP TABLE) bang user han che => MARIADB TU CHOI (day la lop bao ve that),
  - cac dump nguy hiem (DROP DATABASE wordpress...) bi tu choi boi ca bo loc lan server,
  - don dep xong khong con database/user tam.
Thieu MariaDB -> bo qua phan B (exit 0)."""
import getpass, os, re, shutil, subprocess, sys, tempfile, time
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
KT = os.path.join(ROOT, 'app/src/main/java/com/wppocket/server/')
PASS = FAIL = 0
def ok(c, n, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('  OK  ', n)
    else: FAIL += 1; print('  FAIL', n, d)

# ============================ PORT (1-1 voi BackupLogic.kt) ============================
HEAD = 160
COND = re.compile(rb'^/\*M?!\d*\s*')
DANGER = [b'DROP DATABASE', b'DROP SCHEMA', b'ALTER DATABASE', b'ALTER SCHEMA', b'CREATE USER', b'DROP USER', b'ALTER USER', b'GRANT ', b'REVOKE ',
          b'SET PASSWORD', b'SHUTDOWN', b'KILL ', b'LOAD DATA', b'RENAME ', b'INSTALL ', b'UNINSTALL ', b'FLUSH ', b'CREATE SERVER', b'DROP SERVER',
          b'SYSTEM ', b'SOURCE ', b'CREATE FUNCTION', b'CREATE AGGREGATE']
def safe_ident(s): return 0 < len(s) <= 40 and re.fullmatch(r'[A-Za-z0-9_]+', s) is not None
def classify(head):
    t = head.lstrip()
    if t.startswith(b'\\'): return 'DANGEROUS'
    u = COND.sub(b'', t, count=1).lstrip().upper()
    if u.startswith(b'USE '): return 'USE_DB'
    if u.startswith(b'CREATE DATABASE') or u.startswith(b'CREATE SCHEMA'): return 'CREATE_DB'
    if any(u.startswith(p) for p in DANGER): return 'DANGEROUS'
    if u.startswith(b'DELIMITER') or (u.startswith(b'CREATE') and b'DEFINER=' in u): return 'UNSUPPORTED'
    return 'PASS'
def rewrite(data, verify_db):
    """-> (ok, reason, rewritten, unsupported, out_bytes)"""
    if not safe_ident(verify_db): return (False, 'ten', 0, False, b'')
    out, i, n, rewritten = bytearray(), 0, len(data), 0
    while i < n:
        j = i; complete = False
        while j - i < HEAD:
            if j >= n: complete = True; break
            j += 1
            if data[j - 1] == 0x0A: complete = True; break
        head = data[i:j]
        if not head: break
        k = classify(head)
        if k == 'DANGEROUS': return (False, 'danger', rewritten, False, b'')
        if k == 'UNSUPPORTED': return (False, 'unsupported', rewritten, True, b'')
        if k == 'USE_DB':
            if not complete: return (False, 'use-long', rewritten, False, b'')
            out += ('USE `%s`;\n' % verify_db).encode(); rewritten += 1; i = j; continue
        if k == 'CREATE_DB':
            if not complete: return (False, 'create-long', rewritten, False, b'')
            out += ('CREATE DATABASE IF NOT EXISTS `%s`;\n' % verify_db).encode(); rewritten += 1; i = j; continue
        out += head
        ended = len(head) > 0 and head[-1] == 0x0A
        if not ended and len(head) == HEAD:
            while j < n:
                out.append(data[j]); j += 1
                if data[j - 1] == 0x0A: break
        i = j
    return (True, '', rewritten, False, bytes(out))
def pick_prefix(tables):
    s = set(tables)
    c = [t[:-len('options')] for t in tables if t.endswith('options')]
    c = [p for p in c if (p + 'posts') in s and (p == '' or safe_ident(p))]
    return min(c, key=len) if c else None

print('== A. port + vector Kotlin ==')
K = lambda s: classify(s.encode())
ok(K('USE `wordpress`;\n') == 'USE_DB' and K('CREATE DATABASE /*!32312 IF NOT EXISTS*/ `wordpress` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;\n') == 'CREATE_DB' and K('/*M!100000 USE `wordpress`;*/\n') == 'USE_DB', 'classify: USE / CREATE DATABASE')
bad = ['DROP DATABASE `wordpress`;', '/*!40000 DROP DATABASE IF EXISTS `wordpress`*/;', 'drop database x;', "GRANT ALL ON *.* TO 'a'", "CREATE USER 'a'", "SET PASSWORD FOR 'a'='b'",
       '\\! rm -rf /', '\\. /etc/passwd', 'system id', 'source /x.sql', "LOAD DATA INFILE '/x'", 'FLUSH PRIVILEGES', '  DROP SCHEMA y']
ok(all(K(b + '\n') == 'DANGEROUS' for b in bad), 'classify: 13 lenh nguy hiem (ke ca lenh client \\!, \\.) la DANGEROUS')
ok(K('DELIMITER ;;\n') == 'UNSUPPORTED' and K('/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER t BEFORE INSERT ON x */;;\n') == 'UNSUPPORTED', 'classify: DELIMITER, trigger/view DEFINER = UNSUPPORTED')
ok(K("INSERT INTO `wp_posts` VALUES (1,'DROP DATABASE wordpress; GRANT ALL; DEFINER=x');\n") == 'PASS' and K('CREATE TABLE `wp_x` (\n') == 'PASS' and K('-- Dump completed on 2026-10-11\n') == 'PASS' and K('DROP TABLE IF EXISTS `wp_posts`;\n') == 'PASS' and K('LOCK TABLES `wp_posts` WRITE;\n') == 'PASS' and K('\n') == 'PASS', 'classify: dong du lieu/DDL thuong = PASS (chi xet tien to)')
ok(safe_ident('wordpress_verify') and not any(safe_ident(x) for x in ('a`b', 'a b', '', 'a.b', 'x' * 41, 't\u00ean')), 'isSafeDbIdent')
big = 'x' * 2000000
dump_in = ("-- MariaDB dump\nCREATE DATABASE /*!32312 IF NOT EXISTS*/ `wordpress` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;\nUSE `wordpress`;\n"
           "DROP TABLE IF EXISTS `wp_posts`;\nCREATE TABLE `wp_posts` (\n  `ID` int\n);\nINSERT INTO `wp_posts` VALUES (1,'Xin ch\u00e0o \u1ee9ng d\u1ee5ng \U0001F600 USE `wordpress`;'),(2,'%s');\n"
           "/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;\n-- Dump completed on 2026-10-11  3:00:00\n") % big
r = rewrite(dump_in.encode(), 'wordpress_verify')
exp = dump_in.replace("CREATE DATABASE /*!32312 IF NOT EXISTS*/ `wordpress` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;\nUSE `wordpress`;\n", "CREATE DATABASE IF NOT EXISTS `wordpress_verify`;\nUSE `wordpress_verify`;\n")
ok(r[0] and r[2] == 2, 'rewrite: doi dung 2 dong, ok')
ok(r[4].decode() == exp, 'rewrite: moi byte khac giu nguyen (UTF-8, emoji, dong 2MB, USE nam TRONG du lieu khong bi dung)')
r = rewrite(b"USE `wordpress`;\nDROP DATABASE IF EXISTS `x`;\nINSERT INTO t VALUES (1);\n", 'v'); ok(not r[0] and not r[3], 'rewrite: DROP DATABASE -> ok=false, khong unsupported')
r = rewrite(b"CREATE TABLE a (b int);\nDELIMITER ;;\n", 'v'); ok(not r[0] and r[3], 'rewrite: DELIMITER -> unsupported')
ok(not rewrite(b'x', 'x`; DROP DATABASE wordpress; --')[0], 'rewrite: ten DB tam khong an toan bi tu choi')
r = rewrite(b"-- chi co chu thich\nINSERT INTO t VALUES (1);", 'v'); ok(r[0] and r[2] == 0 and r[4] == b"-- chi co chu thich\nINSERT INTO t VALUES (1);", 'rewrite: khong co USE, dong cuoi khong co \\n -> y nguyen')
# fuzz ranh gioi dau dong 160 byte: dong thuong dai 158..163 byte (co/khong co \n) + USE dai bat thuong
import random
random.seed(77); badfz = 0
for L in range(150, 175):
    for tail in (b'\n', b''):
        line = b'-- ' + b'a' * (L - 3) + tail
        data = line + b'INSERT INTO t VALUES (2);\n'
        r = rewrite(data, 'v')
        if not (r[0] and r[4] == data): badfz += 1
ok(badfz == 0, 'fuzz: dong thuong dai 150..174 byte (quanh ranh gioi 160) di thang qua nguyen ven (%d loi)' % badfz)
long_use = b'USE `' + b'a' * 200 + b'`;\n'
ok(not rewrite(long_use, 'v')[0], 'rewrite: dong USE dai bat thuong (>160) -> tu choi chu khong doan')
ok(pick_prefix(['wp_options', 'wp_posts', 'wp_users']) == 'wp_' and pick_prefix(['abc7_options', 'abc7_posts']) == 'abc7_' and pick_prefix(['options', 'posts']) == '' and
   pick_prefix(['wp_woo_options', 'wp_woo_posts', 'wp_options', 'wp_posts']) == 'wp_' and pick_prefix(['wp_options', 'wp_users']) is None and pick_prefix([]) is None and
   pick_prefix(['a`b_options', 'a`b_posts']) is None, 'pickWpPrefix')
kt = open(KT + 'BackupLogic.kt', encoding='utf8').read(); bv = open(KT + 'BackupVerifier.kt', encoding='utf8').read()
ok('private const val VERIFY_HEAD_BYTES = 160' in kt and 'DumpLineKind { PASS, USE_DB, CREATE_DB, DANGEROUS, UNSUPPORTED }' in kt, 'Kotlin: 160 byte dau dong + 5 loai dong khop ban port')
ok(all(('"%s"' % p.decode()) in kt for p in DANGER), 'Kotlin: danh sach tien to nguy hiem khop ban port (%d muc)' % len(DANGER))
ok('const val VERIFY_DB = "wordpress_verify"' in bv and 'private const val VERIFY_USER = "wpp_verify"' in bv, 'Kotlin: ten database/user tam')
ok('GRANT ALL PRIVILEGES ON `$VERIFY_DB`.* TO' in bv and 'DROP DATABASE IF EXISTS `$VERIFY_DB`; DROP USER IF EXISTS' in bv and 'MYSQL_PWD' in bv, 'Kotlin: user CHI co quyen tren DB tam, don dep, mat khau qua MYSQL_PWD')
ok(bv.count('cleanup(context)') >= 3 and 'finally {\n                cleanup(context)' in bv, 'Kotlin: don dep truoc khi bat dau, khi that bai tao DB va trong finally')
ok('-u$VERIFY_USER' in bv and '"-uroot"' in bv, 'Kotlin: nap bang user han che (root chi dung de tao/doc/don)')
ok(open(KT + 'WorkScheduler.kt', encoding='utf8').read().count('BackupVerifyWorker.') == 2, 'WorkScheduler: lap lich khi bat backup tu dong, huy khi tat')

# ============================ B. MariaDB that ============================
def which(*n):
    for x in n:
        p = shutil.which(x)
        if p: return p
daemon, install, cli, dump = which('mariadbd', 'mysqld'), which('mariadb-install-db', 'mysql_install_db'), which('mariadb', 'mysql'), which('mariadb-dump', 'mysqldump')
if not all((daemon, install, cli, dump)):
    print('(bo qua phan B: thieu MariaDB that)')
else:
    print('== B. MariaDB that: dung dung chuoi SQL cua BackupVerifier ==')
    tmp = tempfile.mkdtemp(prefix='verify-db-'); os.chmod(tmp, 0o755); proc = None
    try:
        user = 'root' if os.geteuid() == 0 else getpass.getuser(); data = os.path.join(tmp, 'data'); sock = os.path.join(tmp, 'm.sock')
        r = subprocess.run([install, '--user=' + user, '--datadir=' + data, '--auth-root-authentication-method=normal'], capture_output=True, text=True)
        if r.returncode != 0:
            print('(bo qua phan B: khong khoi tao duoc datadir: %s)' % r.stderr[-120:])
        else:
            proc = subprocess.Popen([daemon] + (['--user=root'] if os.geteuid() == 0 else []) + ['--datadir=' + data, '--socket=' + sock, '--skip-networking', '--pid-file=' + tmp + '/m.pid',
                                    '--innodb-buffer-pool-size=32M', '--log-error=' + tmp + '/e.log'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            for _ in range(60):
                if os.path.exists(sock) and subprocess.run([cli, '--socket=' + sock, '-uroot', '-e', 'select 1'], capture_output=True).returncode == 0: break
                time.sleep(0.5)
            def sql(q, db=None, user='root', pw=None, stdin=None):
                cmd = [cli, '--socket=' + sock, '-u' + user, '-N', '-B', '--default-character-set=utf8mb4'] + (['-e', q] if stdin is None else []) + ([db] if db else [])
                env = dict(os.environ); 
                if pw: env['MYSQL_PWD'] = pw
                r = subprocess.run(cmd, capture_output=True, env=env, input=stdin)
                return r.returncode, (r.stdout + r.stderr).decode('utf8', 'replace').strip()
            sql("CREATE DATABASE wordpress CHARACTER SET utf8mb4")
            sql("CREATE TABLE wp_options (option_id INT AUTO_INCREMENT PRIMARY KEY, option_name VARCHAR(191), option_value LONGTEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", 'wordpress')
            sql("CREATE TABLE wp_posts (ID INT AUTO_INCREMENT PRIMARY KEY, post_title TEXT, post_status VARCHAR(20)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", 'wordpress')
            sql("CREATE TABLE wp_sentinel (v VARCHAR(40)) ENGINE=InnoDB", 'wordpress')
            sql("INSERT INTO wp_options (option_name, option_value) VALUES ('siteurl','https://x.example'), ('blogname', REPEAT('a', 5000))", 'wordpress')
            sql("INSERT INTO wp_posts (post_title, post_status) VALUES ('Xin chào ứng dụng 😀 USE `wordpress`;', 'publish'), ('Bai 2', 'draft')", 'wordpress')
            sql("INSERT INTO wp_sentinel VALUES ('KHONG-DUOC-DONG-VAO')", 'wordpress')
            before_real = sql("SELECT (SELECT COUNT(*) FROM wp_posts),(SELECT COUNT(*) FROM wp_options),(SELECT v FROM wp_sentinel)", 'wordpress')[1]
            rd = subprocess.run([dump, '--socket=' + sock, '-uroot', '--single-transaction', '--quick', '--lock-tables=false', '--databases', 'wordpress'], capture_output=True)
            ok(rd.returncode == 0 and b'USE `wordpress`;' in rd.stdout, 'dump THAT cung tham so voi app co "USE `wordpress`;" (dung giong thi can doi ten)')
            dump_bytes = rd.stdout
            VDB, VUSER = 'wordpress_verify', 'wpp_verify'
            def cleanup(): return sql("DROP DATABASE IF EXISTS `%s`; DROP USER IF EXISTS '%s'@'localhost';" % (VDB, VUSER))
            def setup(pw):
                return sql("CREATE DATABASE `%s` CHARACTER SET utf8mb4; CREATE USER '%s'@'localhost' IDENTIFIED BY '%s'; GRANT ALL PRIVILEGES ON `%s`.* TO '%s'@'localhost';" % (VDB, VUSER, pw, VDB, VUSER))
            pw = 'a1b2c3d4e5f60718293a4b5c6d7e8f90'
            ok(cleanup()[0] == 0, 'cleanup khi chua co gi (idempotent) khong loi')
            ok(setup(pw)[0] == 0, 'tao DB tam + user han che + GRANT chi tren DB tam')
            rw = rewrite(dump_bytes, VDB)
            ok(rw[0] and rw[2] == 2, 'rewrite dump THAT: doi dung 2 dong (CREATE DATABASE + USE)', rw[:3])
            rc, out = sql(None, VDB, VUSER, pw, stdin=rw[4])
            ok(rc == 0, 'NAP dump da doi ten vao DB tam bang user han che thanh cong', out[:200])
            names = sql("SELECT table_name FROM information_schema.tables WHERE table_schema='%s'" % VDB)[1].split('\n')
            pfx = pick_prefix([x.strip() for x in names if x.strip()])
            ok(pfx == 'wp_', 'tim dung tien to bang tu information_schema', names)
            posts = sql("SELECT COUNT(*) FROM `%s`.`%sposts`" % (VDB, pfx))[1]; site = sql("SELECT COUNT(*) FROM `%s`.`%soptions` WHERE option_name='siteurl'" % (VDB, pfx))[1]
            ok(posts == '2' and site == '1', 'dem 2 bai/trang va co dong siteurl trong DB tam', (posts, site))
            ok(sql("SELECT post_title FROM `%s`.wp_posts WHERE ID=1" % VDB)[1] == 'Xin chào ứng dụng 😀 USE `wordpress`;', 'tieng Viet + emoji + chuoi "USE `wordpress`;" TRONG du lieu nguyen ven sau nap')
            ok(sql("SELECT (SELECT COUNT(*) FROM wp_posts),(SELECT COUNT(*) FROM wp_options),(SELECT v FROM wp_sentinel)", 'wordpress')[1] == before_real, 'database THAT `wordpress` khong bi dung (so dong + sentinel nguyen)')
            # LOP BAO VE THAT: dump goc khong doi ten, nap bang user han che
            rc, out = sql(None, VDB, VUSER, pw, stdin=dump_bytes)
            ok(rc != 0 and 'denied' in out.lower(), 'nap CHINH dump goc (USE `wordpress`) bang user han che => MARIADB TU CHOI (Access denied)', out[:200])
            ok(sql("SELECT (SELECT COUNT(*) FROM wp_posts),(SELECT COUNT(*) FROM wp_options),(SELECT v FROM wp_sentinel)", 'wordpress')[1] == before_real, 'sau do database that van nguyen ven')
            for name, evil in (('DROP DATABASE', b"DROP DATABASE `wordpress`;\n"), ('DROP TABLE co dinh danh DB', b"DROP TABLE `wordpress`.`wp_sentinel`;\n"), ('GRANT', b"GRANT ALL ON *.* TO 'wpp_verify'@'localhost';\n"),
                               ('CREATE USER', b"CREATE USER 'evil'@'localhost';\n"), ('SET PASSWORD root', b"SET PASSWORD FOR 'root'@'localhost'=PASSWORD('x');\n"), ('INSERT vao DB that', b"INSERT INTO `wordpress`.wp_sentinel VALUES ('hack');\n")):
                rc, out = sql(None, VDB, VUSER, pw, stdin=evil)
                ok(rc != 0, 'server TU CHOI "%s" tu user han che' % name, out[:120])
                # Lop 1 (bo loc client) chi la lop phu: DROP TABLE/INSERT co dinh danh DB khong nam trong danh sach tien to nguy hiem - chinh
                # vi vay lop 2 (quyen cua user) moi la lop BAO VE THAT, va da duoc khang dinh ngay tren.
                print('       (bo loc client %s "%s")' % ('TU CHOI' if not rewrite(evil, VDB)[0] else 'cho qua', name))
            ok(sql("SELECT (SELECT COUNT(*) FROM wp_posts),(SELECT COUNT(*) FROM wp_options),(SELECT v FROM wp_sentinel)", 'wordpress')[1] == before_real, 'sau 6 dump doc: database that van nguyen ven')
            ok(sql("SELECT COUNT(*) FROM mysql.user WHERE user='evil'")[1] == '0', 'khong co user la ("evil") nao duoc tao')
            ok(sql('select 1', None, 'root')[0] == 0, 'root van vao duoc khong mat khau (SET PASSWORD tu user han che da bi chan)')
            ok(cleanup()[0] == 0, 'cleanup sau khi xong')
            left = sql("SELECT (SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name='%s'), (SELECT COUNT(*) FROM mysql.user WHERE user='%s')" % (VDB, VUSER))[1]
            ok(left.replace('\t', ' ') == '0 0', 'khong con database tam / user tam sau don dep', left)
            ok(setup(pw)[0] == 0 and cleanup()[0] == 0, 'chay lai (tao -> don) lan 2 van sach: ton du cua lan truoc khong lam hong lan sau')
    finally:
        if proc:
            proc.terminate()
            try: proc.wait(timeout=10)
            except Exception: proc.kill()
        shutil.rmtree(tmp, ignore_errors=True)
print('TONG KET: pass=%d fail=%d' % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
