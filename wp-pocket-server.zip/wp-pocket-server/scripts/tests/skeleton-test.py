#!/usr/bin/env python3
"""J4 (PDF 2; HANDOFF.md muc 1bq-I): kiem chung skeleton loading cua dong dia chi cong khai - logic thuan (Java that) + noi day tinh."""
import os, re, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
K = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/")
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def rd(p):
    return open(p, encoding="utf-8").read()


kt, jv, ma = rd(K + "SkeletonLogic.kt"), rd(os.path.join(ROOT, "scripts/tests/java/SkeletonLogicPort.java")), rd(K + "MainActivity.kt")
check("SkeletonLogic.kt thuan: khong import android.*", re.search(r"^import android", kt, re.M) is None)
check("hang so PERIOD_MS/ALPHA_MIN giong het Kotlin va Java", "PERIOD_MS = 900L" in kt and "PERIOD_MS = 900L" in jv and "ALPHA_MIN = 0.35f" in kt and "ALPHA_MIN = 0.35f" in jv)
check("dieu kien shouldAnimate giong het Kotlin va Java (loading, !NaN, !Infinite, > 0)", "loading && !animatorScale.isNaN() && !animatorScale.isInfinite() && animatorScale > 0f" in kt and "loading && !Float.isNaN(animatorScale) && !Float.isInfinite(animatorScale) && animatorScale > 0f" in jv)
try:
    mods = subprocess.run(["java", "--list-modules"], capture_output=True, text=True, timeout=60).stdout
except Exception:
    mods = ""
if "jdk.compiler" in mods:
    r = subprocess.run(["java", os.path.join(ROOT, "scripts/tests/java/SkeletonLogicPort.java")], capture_output=True, text=True, timeout=120)
    check("SkeletonLogicPort tren JDK that: 6/6", r.returncode == 0 and "pass=6 fail=0" in r.stdout, r.stdout[-200:])
else:
    print("(bo qua chay Java: can JDK day du)")
check("MainActivity goi updateTunnelSkeleton(running && publicUrl == null) trong vong cap nhat (chi luc dang tao ham)", "updateTunnelSkeleton(running && publicUrl == null)" in ma)
body = ma[ma.index("private fun updateTunnelSkeleton"): ma.index("override fun onDestroy")]
check("ton trong 'xoa hoat anh': doc ANIMATOR_DURATION_SCALE va hoi SkeletonLogic.shouldAnimate", "ANIMATOR_DURATION_SCALE" in body and "SkeletonLogic.shouldAnimate(scale, loading)" in body)
check("idempotent: chi tao animator khi tunnelPulse == null (goi moi giay khong chong chat)", "if (tunnelPulse == null)" in body)
check("tat: cancel + dat lai alpha = 1f (chu khong bi ket o do mo)", "tunnelPulse?.cancel()" in body and "binding.tvPublicUrl.alpha = 1f" in body)
check("onDestroy huy animator va go vong cap nhat (khong ro Activity)", re.search(r"override fun onDestroy\(\) \{[\s\S]*tunnelPulse\?\.cancel\(\)[\s\S]*handler\.removeCallbacksAndMessages\(null\)[\s\S]*super\.onDestroy\(\)", ma) is not None and ma.count("override fun onDestroy") == 1)
check("khong them view/layout moi (nhap nhay tren TextView co san tvPublicUrl)", "tvPublicUrl" in body and "tvPublicUrl" in rd(os.path.join(ROOT, "app/src/main/res/layout/activity_main.xml")))
check("chi dung ObjectAnimator tren 'alpha' (khong lam do layout), lap vo han kieu REVERSE", '"alpha"' in body and "INFINITE" in body and "REVERSE" in body)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
