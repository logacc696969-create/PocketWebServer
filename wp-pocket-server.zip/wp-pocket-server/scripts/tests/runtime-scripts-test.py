#!/usr/bin/env python3
"""Kiem thu TICH HOP node.sh / python.sh / static.sh (HANDOFF.md muc 1bi) KHONG can mang: sao chep thu muc scripts/ sang cho tam, THAY cac ham tai Termux va
lay ma nguon site bang ham GIA (dung cay thu muc Termux gia voi ELF that co DT_NEEDED), roi chay NGUYEN script that. Kiem tra: runtime.json hop le,
file trong out la lib*.so, www.zip co _supervisor/..., va check-runtime-closure bao DU thu vien (doi chung: xoa 1 lib -> bao THIEU).
Can: bash, jq, zip/unzip, python3. Thieu jq -> bo qua."""
import importlib.util, json, os, shutil, subprocess, sys, tempfile, zipfile
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
spec = importlib.util.spec_from_file_location('ecl', os.path.join(HERE, 'elf-closure-test.py')); ecl = importlib.util.module_from_spec(spec); spec.loader.exec_module(ecl)
make_elf = ecl.make_elf
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:260]) if d else ''))

STUB = r'''#!/usr/bin/env bash
# THAY THE termux_fetch.sh / site_source.sh / site_deps.sh bang ham gia (test).
FAKE="$FAKE_TERMUX"
termux_download_with_deps() { cp -a "$FAKE/$1/." "$2/"; }
termux_find_binary() { find "$1" -type f \( -name "$2" \) 2>/dev/null | head -1; }
fetch_site_source() { cp -a "$FAKE_SITE/." "$1/"; }
install_site_deps() { :; }
site_docroot_subdir() { jq -r '.docroot // ""' site.config.json; }
'''

def build_fake(tmp):
    F = os.path.join(tmp, 'fake'); 
    def mk(pkg, rel, needed, soname=None):
        p = os.path.join(F, pkg, rel); os.makedirs(os.path.dirname(p), exist_ok=True); make_elf(p, needed, soname); return p
    def libs(pkg, spec):   # spec: {real: [needed]} -> file that + symlink SONAME
        for real, (soname, needed) in spec.items():
            mk(pkg, 'usr/lib/' + real, needed, soname)
            if soname != real:
                link = os.path.join(F, pkg, 'usr/lib', soname)
                if not os.path.lexists(link): os.symlink(real, link)
    # nodejs
    mk('nodejs', 'usr/bin/node', ['libz.so.1', 'libicuuc.so.77', 'libc++_shared.so', 'libc.so', 'libm.so', 'libdl.so'])
    libs('nodejs', {'libz.so.1.3.1': ('libz.so.1', ['libc.so']), 'libicuuc.so.77.1': ('libicuuc.so.77', ['libc++_shared.so', 'libc.so']), 'libc++_shared.so': ('libc++_shared.so', ['libc.so'])})
    # python (+ stdlib + lib-dynload)
    mk('python', 'usr/bin/python3', ['libpython3.12.so.1.0', 'libz.so.1', 'libc.so'])
    libs('python', {'libpython3.12.so.1.0': ('libpython3.12.so.1.0', ['libz.so.1', 'libc.so']), 'libz.so.1.3.1': ('libz.so.1', ['libc.so'])})
    py = os.path.join(F, 'python', 'usr/lib/python3.12'); os.makedirs(os.path.join(py, 'encodings')); os.makedirs(os.path.join(py, 'test'))
    open(os.path.join(py, 'os.py'), 'w').write('# os'); open(os.path.join(py, 'encodings/__init__.py'), 'w').write(''); open(os.path.join(py, 'test/t.py'), 'w').write('')
    mk('python', 'usr/lib/python3.12/lib-dynload/_socket.cpython-312-aarch64-linux-android.so', ['libpython3.12.so.1.0', 'libc.so'])
    # nginx
    mk('nginx', 'usr/bin/nginx', ['libpcre2-8.so.0', 'libssl.so.3', 'libcrypto.so.3', 'libz.so.1', 'libc.so', 'libm.so'])
    libs('nginx', {'libpcre2-8.so.0.14.0': ('libpcre2-8.so.0', ['libc.so']), 'libssl.so.3': ('libssl.so.3', ['libcrypto.so.3', 'libc.so']), 'libcrypto.so.3': ('libcrypto.so.3', ['libc.so']), 'libz.so.1.3.1': ('libz.so.1', ['libc.so'])})
    # php (cho static front_proxy=false)
    mk('php', 'usr/bin/php', ['libxml2.so.2', 'libz.so.1', 'libc.so'])
    libs('php', {'libxml2.so.2.12.0': ('libxml2.so.2', ['libz.so.1', 'libc.so']), 'libz.so.1.3.1': ('libz.so.1', ['libc.so'])})
    S = os.path.join(tmp, 'site'); os.makedirs(os.path.join(S, 'dist'))
    open(os.path.join(S, 'server.js'), 'w').write('// node'); open(os.path.join(S, 'app.py'), 'w').write('# py'); open(os.path.join(S, 'index.html'), 'w').write('hi'); open(os.path.join(S, 'dist/index.html'), 'w').write('hi')
    return F, S

def run_script(tmp, runtime, cfg, fake, site):
    work = os.path.join(tmp, 'w-' + runtime + '-' + str(abs(hash(json.dumps(cfg, sort_keys=True))) % 10**6)); os.makedirs(work)
    shutil.copytree(os.path.join(ROOT, 'scripts'), os.path.join(work, 'scripts'), ignore=shutil.ignore_patterns('__pycache__'))
    for n in ('termux_fetch.sh', 'site_source.sh', 'site_deps.sh'): open(os.path.join(work, 'scripts/lib', n), 'w').write(STUB)
    open(os.path.join(work, 'site.config.json'), 'w').write(json.dumps(dict(cfg, runtime=runtime)))
    out = os.path.join(work, 'out')
    env = dict(os.environ, FAKE_TERMUX=fake, FAKE_SITE=site)
    r = subprocess.run(['bash', os.path.join(work, 'scripts/runtimes/%s.sh' % runtime), 'aarch64', out], cwd=work, env=env, capture_output=True, text=True)
    return work, out, r

def closure(out, extra=()):
    r = subprocess.run([sys.executable, os.path.join(ROOT, 'scripts/tools/check-runtime-closure.py'), out, os.path.join(out, 'soname-map.txt')] + list(extra), capture_output=True, text=True)
    return r
def www_names(out):
    return set(zipfile.ZipFile(os.path.join(out, 'www.zip')).namelist())
def libs_ok(out): return all(f.startswith('lib') for f in os.listdir(out) if f.endswith('.so'))

JQ_SHIM = r'''#!/usr/bin/env python3
# jq GIA toi thieu (chi khi may khong co jq that - CI dung jq that). Ho tro DUNG cac bieu thuc ma scripts/ dung: ".k // lit", "if has(\"k\") then .k else $d end",
# co -r va --argjson. Ngu nghia "//" giong jq that: ve phai khi ve trai la null HOAC false (chinh vi vay can has() cho front_proxy).
import json, re, sys
a = sys.argv[1:]; raw = False; args = {}; filt = None; files = []
i = 0
while i < len(a):
    if a[i] == '-r': raw = True
    elif a[i] == '--argjson': args[a[i + 1]] = json.loads(a[i + 2]); i += 2
    elif filt is None: filt = a[i]
    else: files.append(a[i])
    i += 1
doc = json.load(open(files[0])) if files else json.load(sys.stdin)
def lit(t):
    t = t.strip()
    if t.startswith('$'): return args[t[1:]]
    return json.loads(t)
m = re.fullmatch(r'\.(\w+)\s*//\s*(.+)', filt.strip())
h = re.fullmatch(r'if has\("(\w+)"\) then \.(\w+) else (\$\w+) end', filt.strip())
if m:
    v = doc.get(m.group(1)); out = lit(m.group(2)) if v in (None, False) else v
elif h:
    out = doc[h.group(2)] if h.group(1) in doc else lit(h.group(3))
else:
    sys.stderr.write('jq gia: khong ho tro bieu thuc: %s\n' % filt); sys.exit(3)
print(out if (raw and isinstance(out, str)) else (str(out).lower() if isinstance(out, bool) else (out if isinstance(out, (int, float)) else json.dumps(out))))
'''

def main():
    tmp = tempfile.mkdtemp(prefix='rt-')
    if not shutil.which('jq'):
        shim = os.path.join(tmp, 'shimbin'); os.makedirs(shim); open(os.path.join(shim, 'jq'), 'w').write(JQ_SHIM); os.chmod(os.path.join(shim, 'jq'), 0o755)
        os.environ['PATH'] = shim + os.pathsep + os.environ['PATH']; print('(khong co jq that: dung jq GIA toi thieu trong test)')
    try:
        fake, site = build_fake(tmp)
        def smap_into_zip(out):   # soname-map nam trong www.zip (_supervisor/soname-map.txt); chep ra out de closure dung
            z = zipfile.ZipFile(os.path.join(out, 'www.zip'))
            open(os.path.join(out, 'soname-map.txt'), 'wb').write(z.read('_supervisor/soname-map.txt'))

        print('== node, mac dinh (direct) ==')
        w, out, r = run_script(tmp, 'node', {'port': 8080, 'entry': 'server.js'}, fake, site)
        check('node.sh chay xong', r.returncode == 0, (r.stdout[-300:], r.stderr[-300:]))
        rj = json.load(open(os.path.join(out, 'runtime.json')))
        check('runtime.json: exec = sh start-generic.sh, GEN_MODE=direct, args tro vao entry', rj['exec'] == ['/system/bin/sh', '${DOCROOT}/_supervisor/start-generic.sh'] and rj['env']['GEN_MODE'] == 'direct' and rj['env']['GEN_APP_ARGS'] == '__DOCROOT__/server.js' and rj['env']['NODE_ENV'] == 'production', rj)
        check('moi file .so trong out bat dau "lib" (jniLibs chi nhan lib*.so) va co libruntimesrv.so', libs_ok(out) and os.path.exists(os.path.join(out, 'libruntimesrv.so')), sorted(os.listdir(out)))
        check('KHONG co nginx khi front_proxy khong bat', not os.path.exists(os.path.join(out, 'libnginx.so')))
        z = www_names(out); check('www.zip co _supervisor/start-generic.sh + soname-map.txt va ma nguon site', {'_supervisor/start-generic.sh', '_supervisor/soname-map.txt', 'server.js'} <= z, sorted(z)[:10])
        smap_into_zip(out); c = closure(out); check('closure: node + libz.so.1 + libicuuc.so.77 + libc++_shared.so DU (qua soname-map)', c.returncode == 0, c.stdout)
        for f in os.listdir(out):
            if f.startswith('libicuuc'): os.remove(os.path.join(out, f))
        c = closure(out); check('DOI CHUNG: xoa libicuuc -> closure bao THIEU libicuuc.so.77', c.returncode == 1 and 'libicuuc.so.77' in c.stdout, c.stdout)

        print('== node, front_proxy: true ==')
        w, out, r = run_script(tmp, 'node', {'port': 8080, 'entry': 'server.js', 'front_proxy': True}, fake, site)
        check('node.sh (front) chay xong', r.returncode == 0, (r.stdout[-300:], r.stderr[-300:]))
        rj = json.load(open(os.path.join(out, 'runtime.json')))
        check('GEN_MODE=proxy, binary van libruntimesrv.so', rj['env']['GEN_MODE'] == 'proxy' and rj['binary'] == 'libruntimesrv.so', rj)
        z = www_names(out); check('www.zip co 3 mau nginx', {'_supervisor/nginx-front.conf.template', '_supervisor/front-locations-proxy.conf.template', '_supervisor/front-locations-static.conf.template'} <= z)
        smap_into_zip(out); c = closure(out); check('closure: node + nginx (pcre2, ssl, crypto, z) DU', c.returncode == 0 and os.path.exists(os.path.join(out, 'libnginx.so')), c.stdout)

        print('== python, mac dinh (http.server tinh) ==')
        w, out, r = run_script(tmp, 'python', {'port': 8080}, fake, site)
        check('python.sh chay xong', r.returncode == 0, (r.stdout[-300:], r.stderr[-300:]))
        rj = json.load(open(os.path.join(out, 'runtime.json')))
        check('direct: http.server tren __PORT__ bind 0.0.0.0', rj['env']['GEN_APP_ARGS'] == '-m http.server __PORT__ --directory __DOCROOT__ --bind 0.0.0.0' and rj['env']['PYTHONUNBUFFERED'] == '1', rj['env'])
        z = www_names(out)
        check('www.zip co THU VIEN CHUAN python (os.py, encodings) trong _supervisor/pyhome, khong co test/', '_supervisor/pyhome/lib/python3.12/os.py' in z and '_supervisor/pyhome/lib/python3.12/encodings/__init__.py' in z and not any('/test/' in n for n in z), sorted(n for n in z if 'pyhome' in n))
        check('www.zip co dynload-map.txt; out co libpydyn_*.so cho module mo rong', '_supervisor/dynload-map.txt' in z and any(f.startswith('libpydyn_') and 'socket' in f for f in os.listdir(out)), sorted(os.listdir(out)))
        smap_into_zip(out); c = closure(out); check('closure: python + libpython3.12.so.1.0 + libz + module _socket DU', c.returncode == 0 and libs_ok(out), c.stdout)

        print('== python, front_proxy + entry ==')
        w, out, r = run_script(tmp, 'python', {'port': 8080, 'entry': 'app.py', 'front_proxy': True}, fake, site)
        rj = json.load(open(os.path.join(out, 'runtime.json')))
        check('proxy + entry: GEN_APP_ARGS = app.py, GEN_MODE=proxy', r.returncode == 0 and rj['env']['GEN_MODE'] == 'proxy' and rj['env']['GEN_APP_ARGS'] == '__DOCROOT__/app.py', (r.stderr[-200:], rj['env']))
        w, out, r = run_script(tmp, 'python', {'port': 8080, 'front_proxy': True}, fake, site)
        rj = json.load(open(os.path.join(out, 'runtime.json')))
        check('proxy khong entry: http.server nghe __APP_PORT__ chi tren 127.0.0.1 (khong lo cong noi bo)', '__APP_PORT__' in rj['env']['GEN_APP_ARGS'] and '--bind 127.0.0.1' in rj['env']['GEN_APP_ARGS'], rj['env']['GEN_APP_ARGS'])

        print('== static: mac dinh = nginx phuc vu thang ==')
        w, out, r = run_script(tmp, 'static', {'port': 8080, 'docroot': 'dist'}, fake, site)
        check('static.sh chay xong', r.returncode == 0, (r.stdout[-300:], r.stderr[-300:]))
        rj = json.load(open(os.path.join(out, 'runtime.json')))
        check('runtime.json: binary=libnginx.so, GEN_MODE=static, GEN_WEB_SUBDIR=dist', rj['binary'] == 'libnginx.so' and rj['env']['GEN_MODE'] == 'static' and rj['env']['GEN_WEB_SUBDIR'] == 'dist', rj)
        check('KHONG mang php (nho hon): khong co libruntimesrv.so, khong co libxml2', not os.path.exists(os.path.join(out, 'libruntimesrv.so')) and not any('xml2' in f for f in os.listdir(out)), sorted(os.listdir(out)))
        smap_into_zip(out); c = closure(out); check('closure: nginx DU', c.returncode == 0 and libs_ok(out), c.stdout)
        w, out, r = run_script(tmp, 'static', {'port': 8080, 'docroot': 'khong-co'}, fake, site)
        check('docroot khong ton tai -> build THAT BAI (khong im lang)', r.returncode != 0 and 'khong co thu muc' in r.stderr, (r.returncode, r.stderr[-200:]))

        print('== static: front_proxy=false -> php -S nhu cu (nhung co dong goi thu vien dung cach) ==')
        w, out, r = run_script(tmp, 'static', {'port': 8080, 'front_proxy': False}, fake, site)
        rj = json.load(open(os.path.join(out, 'runtime.json')))
        check('front_proxy=false (KHONG bi jq coi nhu "khong co"): direct, php -S, binary libruntimesrv.so', r.returncode == 0 and rj['env']['GEN_MODE'] == 'direct' and rj['env']['GEN_APP_ARGS'] == '-S 0.0.0.0:__PORT__ -t __DOCROOT__' and rj['binary'] == 'libruntimesrv.so' and not os.path.exists(os.path.join(out, 'libnginx.so')), (r.stderr[-200:], rj))
        smap_into_zip(out); c = closure(out); check('closure: php + libxml2 + libz DU', c.returncode == 0 and libs_ok(out), c.stdout)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
