import com.wppocket.server.MonitorLogic
import java.io.File

/**
 * HOP DONG giua PHP (admin-auth.php ghi admin-audit.log) va Kotlin
 * (Monitoring.checkAdminAudit -> MonitorLogic.scanAudit doc lai): file audit do
 * PHP THAT ghi ra phai duoc bo phan tich dem DUNG. 2 phia nam o 2 ngon ngu khac
 * nhau, chi lien ket bang dinh dang dong van ban - doi 1 phia ma khong doi phia
 * kia se am tham lam hong canh bao Telegram. Xem HANDOFF.md muc 1av.
 * Tham so: <file audit> <so lan sai mong doi> <so lan khoa mong doi>
 */
fun main(args: Array<String>) {
    val f = File(args[0])
    val expFail = args[1].toInt()
    val expLock = args[2].toInt()
    val (lines, off) = MonitorLogic.readNewLines(f, 0)
    val s = MonitorLogic.scanAudit(lines)
    println("dong doc duoc=${lines.size} sai=${s.failures} khoa=${s.lockouts} ipNhieuNhat=${s.topIp}(${s.topIpFailures})")
    val checks = listOf(
        "so lan sai khop (${s.failures}==$expFail)" to (s.failures == expFail),
        "so lan khoa khop (${s.lockouts}==$expLock)" to (s.lockouts == expLock),
        "IP nhieu su kien nhat la IP bi khoa 10.1.1.1" to (s.topIp == "10.1.1.1"),
        "shouldAlertAudit = true (co IP bi khoa)" to MonitorLogic.shouldAlertAudit(s),
        "offset cuoi = kich thuoc file (doc het, khong sot)" to (off == f.length()),
        "dong dang nhap THANH CONG khong bi tinh la sai" to (lines.any { it.contains("dang nhap THANH CONG") } && s.failures == expFail)
    )
    var ok = true
    for ((name, pass) in checks) {
        println((if (pass) "PASS: " else "FAIL: ") + name)
        if (!pass) ok = false
    }
    if (!ok) System.exit(1)
}
