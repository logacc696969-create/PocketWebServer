#!/usr/bin/env python3
"""Kiem thu pool PHP "hard" (php-harden-on) bang nginx THAT + php-fpm THAT (HANDOFF.md muc 1br-H).

Dung DUNG nginx.conf.template va php-fpm.conf.template cua du an. Chi doi: duong dan, user=root (chay bang root), listen.mode 0666, va (chi o PHAN A) moi pool
chay 1 worker TINH (pm=static, max_children=1): moi request vao 1 pool deu do CUNG MOT tien trinh, nen neu disable_functions co ro sang request khac (loi da gap
voi cach PHP_ADMIN_VALUE theo location) thi se lo ngay o day, khong phai may rui.

PHAN A (probe tong hop): co tat -> ham chay lenh con; bat -> trang cong khai mat ham, _admin/ + wake-mariadb + staging + /healthz VAN DAY DU; xen ke nhieu luot; tat lai
  -> ngay lap tuc (khong HUP). Worker cua pool hard khac worker cua pool www.
PHAN B (WordPress THAT 7.1.4 + SQLite, tuy chon): dang nhap, wp-admin, REST, wp-cron, plugin lon (Yoast, Elementor, CF7, WooCommerce) duoi pool hard - khong mot canh bao
  "disabled for security reasons" trong log PHP => bat tinh nang nay khong lam hong WordPress.
PHAN C (tinh): hai pool dong bo env/php_admin_*; danh sach ham khong chua ham ma WordPress loi can; (neu co WP_REAL_SRC) core WordPress khong goi ham nao trong danh sach.

Can: nginx, php-fpm, php CLI. PHAN B can them WP_REAL_SRC + WP_SQLITE_SRC (xem wp-real-test.py); WP_EXTRA_PLUGINS=<dir1:dir2:...> de thu them plugin.
Thieu cong cu -> bo qua (exit 0). Doi chung am: NGINX_TPL=<template cu> hoac sua php-fpm.conf.template bo pool [hard] -> PHAI do.
"""
import http.client, importlib.util, os, re, shutil, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
TPLDIR = os.path.join(ROOT, 'scripts', 'runtimes', 'templates')
FPM_TPL = os.environ.get('FPM_TPL') or os.path.join(TPLDIR, 'php-fpm.conf.template')
NGX_TPL = os.environ.get('NGINX_TPL') or os.path.join(TPLDIR, 'nginx.conf.template')
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:260]) if d else ''))


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wr(path, txt):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w').write(txt)


def fpm_pools(text):
    """{ten_pool: [dong,...]} (bo dong trong/chu thich)."""
    pools, cur = {}, None
    for line in text.splitlines():
        t = line.strip()
        if not t or t.startswith(';'):
            continue
        m = re.match(r'^\[(\w+)\]$', t)
        if m:
            cur = m.group(1)
            pools[cur] = []
        elif cur:
            pools[cur].append(t)
    return pools


def disabled_list(pool_lines):
    for l in pool_lines:
        m = re.match(r'php_admin_value\[disable_functions\]\s*=\s*(.*)$', l)
        if m:
            return [x.strip() for x in m.group(1).split(',') if x.strip()]
    return []


PROBE = r"""<?php
header('Content-Type: text/plain');
echo json_encode(['pid' => getmypid(), 'shell_exec' => function_exists('shell_exec'), 'exec' => function_exists('exec'), 'system' => function_exists('system'),
  'popen' => function_exists('popen'), 'proc_open' => function_exists('proc_open'), 'curl_init' => function_exists('curl_init'),
  'dis' => ini_get('disable_functions'), 'script' => $_SERVER['SCRIPT_NAME'] ?? '', 'run' => function_exists('shell_exec') ? trim((string) shell_exec('echo hi')) : null]);
"""


def main():
    nginx = which('nginx')
    fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    if not (nginx and fpm and which('php')):
        print('(bo qua: thieu nginx / php-fpm / php CLI)')
        return 0
    import json
    tpl_fpm = open(FPM_TPL, encoding='utf-8').read()
    tpl_ngx = open(NGX_TPL, encoding='utf-8').read()

    # ---------------- PHAN C (tinh) ----------------
    print('== C. Cau hinh tinh ==')
    pools = fpm_pools(tpl_fpm)
    check('php-fpm.conf.template co ca pool [www] va [hard]', 'www' in pools and 'hard' in pools, list(pools))
    if 'www' in pools and 'hard' in pools:
        www, hard = pools['www'], pools['hard']
        envs = lambda ls: sorted(l for l in ls if l.startswith('env['))
        check('moi env[...] cua [www] co mat NGUYEN VAN o [hard] (hai pool dong bo)', envs(www) == envs(hard), set(envs(www)) ^ set(envs(hard)))
        padm = lambda ls: sorted(l for l in ls if l.startswith('php_admin_') and 'disable_functions' not in l)
        check('moi php_admin_* cua [www] co o [hard]', padm(www) == padm(hard), set(padm(www)) ^ set(padm(hard)))
        key = lambda ls, k: [l for l in ls if re.match(r'^%s\s*=' % re.escape(k), l)]
        check('hai pool nghe tren HAI socket khac nhau', key(www, 'listen') != key(hard, 'listen') and key(hard, 'listen'), (key(www, 'listen'), key(hard, 'listen')))
        check('[hard] la pm=ondemand (khong ton RAM khi khong bat)', key(hard, 'pm') == ['pm = ondemand'], key(hard, 'pm'))
        check('[www] KHONG co disable_functions (_admin/wake-mariadb can shell_exec)', not disabled_list(www))
        dis = disabled_list(hard)
        core = ['exec', 'passthru', 'shell_exec', 'system', 'proc_open', 'popen']
        check('[hard] tat du 6 ham chay lenh: ' + ','.join(core), all(f in dis for f in core), [f for f in core if f not in dis])
        need = ['curl_init', 'curl_exec', 'curl_multi_exec', 'curl_setopt', 'fsockopen', 'stream_socket_client', 'mail', 'putenv', 'ini_set', 'file_get_contents', 'fopen',
                'unlink', 'rename', 'chmod', 'touch', 'tempnam', 'move_uploaded_file', 'set_time_limit', 'ignore_user_abort', 'function_exists', 'is_callable', 'call_user_func',
                'unserialize', 'extract', 'assert', 'eval', 'create_function', 'mb_strlen', 'iconv', 'gzinflate', 'openssl_encrypt', 'random_bytes', 'hash_hmac', 'getenv', 'phpinfo',
                'error_log', 'ob_start', 'header', 'session_start', 'scandir', 'glob', 'realpath', 'symlink', 'link', 'readlink', 'sys_get_temp_dir', 'gethostbyname', 'dns_get_record']
        check('[hard] KHONG tat ham WordPress/plugin pho bien can (curl_*, fsockopen, mail, putenv, symlink, ...)', not [f for f in need if f in dis], [f for f in need if f in dis])
    code = '\n'.join(l for l in tpl_ngx.splitlines() if not l.lstrip().startswith('#'))
    check('nginx: "set $wp_pocket_fpm" mac dinh pool www + doi sang hard khi co file php-harden-on', re.search(r'set \$wp_pocket_fpm unix:__FPM_SOCK__;\s*if \(-f __RUNDIR__/php-harden-on\) \{\s*set \$wp_pocket_fpm unix:__RUNDIR__/php-hard\.sock;', code) is not None)
    # Dung 2 noi cong khai dung bien; moi noi khac PHAI giu pool www
    def loc_block(anchor):
        i = code.index(anchor)
        j = code.index('fastcgi_pass', i)
        return code[j:j + 40]
    check('"location = /wp-login.php" dung $wp_pocket_fpm', loc_block('location = /wp-login.php {').startswith('fastcgi_pass $wp_pocket_fpm;'))
    check('"location ~ \\.php$" chinh dung $wp_pocket_fpm', loc_block('location ~ \\.php$ {').startswith('fastcgi_pass $wp_pocket_fpm;'))
    check('wake-mariadb.php LUON o pool www (can shell_exec de bat MariaDB)', loc_block('location = /wake-mariadb.php {').startswith('fastcgi_pass unix:__FPM_SOCK__;'))
    check('_admin/ LUON o pool www', loc_block('location ^~ /_admin/ {').startswith('fastcgi_pass unix:__FPM_SOCK__;'))
    check('chi 2 noi dung $wp_pocket_fpm (khong ro sang noi khac)', code.count('fastcgi_pass $wp_pocket_fpm;') == 2, code.count('fastcgi_pass $wp_pocket_fpm;'))
    wp_src, sq_src = os.environ.get('WP_REAL_SRC'), os.environ.get('WP_SQLITE_SRC')
    if wp_src and os.path.isdir(wp_src) and 'hard' in pools:
        dis = disabled_list(pools['hard'])
        # Duong ma core co goi ham trong danh sach nhung KHONG chay o cau hinh mac dinh cua WordPress (da doc tung cho, WordPress 7.1.4). Them dong moi o day
        # CHI sau khi doc va xac nhan no khong nam tren duong chay thuong.
        known = {
            'wp-includes/class-snoopy.php': 'Snoopy cu: chi goi exec khi $curl_path duoc dat (che do "curl ngoai"), WordPress khong dat',
            'wp-includes/PHPMailer/PHPMailer.php': 'popen chi o transport "sendmail" (isSendmail); WordPress mac dinh dung mail() hoac plugin SMTP',
            'wp-includes/Text/Diff/Engine/shell.php': 'engine "shell" cua Text_Diff; WordPress chon xdiff/native, khong chon shell',
            'wp-includes/ID3/getid3.lib.php': 'getid3_lib::filesize fallback "ls -l | awk" chi cho tep >2GB tren PHP 32-bit',
            'wp-includes/ID3/getid3.php': 'vorbiscomment/dir /x: chi khi tinh md5 du lieu Ogg hoac duong dan helper co dau cach tren Windows',
        }
        hits = {}
        used = set()
        for dp, dn, fs in os.walk(wp_src):
            if os.sep + 'wp-content' + os.sep in dp + os.sep and not dp.endswith('wp-content'):
                dn[:] = []
                continue
            for f in fs:
                if not f.endswith('.php'):
                    continue
                path = os.path.join(dp, f)
                rel = path[len(wp_src):].lstrip(os.sep)
                try:
                    lines = open(path, encoding='utf-8', errors='replace').read().split('\n')
                except OSError:
                    continue
                for i, l in enumerate(lines):
                    t = l.strip()
                    if t.startswith(('//', '*', '/*', '#')):
                        continue
                    for fn in dis:
                        if not re.search(r'(?<![\w>:$\'"])%s\s*\(' % re.escape(fn), l) or re.search(r'function\s+%s\b' % re.escape(fn), l):
                            continue
                        ctx = ' '.join(lines[max(0, i - 5):i + 1])
                        if re.search(r'function_exists|is_callable|disabled|in_array', ctx):
                            continue       # WordPress tu kiem ham con dung duoc truoc khi goi (chiu duoc host tat ham)
                        if rel in known:
                            used.add(rel)
                            continue
                        hits.setdefault(fn, []).append('%s:%d: %s' % (rel, i + 1, t[:70]))
        check('core WordPress KHONG goi ham trong danh sach tat tren duong chay thuong (chi co %d noi da duyet, duong khong chay mac dinh)' % len(used), not hits, {k: v[:2] for k, v in hits.items()})

    # ---------------- PHAN A (probe, 1 worker / pool) ----------------
    tmp = tempfile.mkdtemp(prefix='phpharden-')
    os.chmod(tmp, 0o755)
    procs = []
    try:
        doc, run, files, stg = (os.path.join(tmp, d) for d in ('www', 'run', 'files', 'stg'))
        for d in (doc, run, files, stg):
            os.makedirs(d)
        port, sport = free_port(), free_port()
        sock, hsock = os.path.join(run, 'php-fpm.sock'), os.path.join(run, 'php-hard.sock')
        for p in ('index.php', 'wp-login.php', 'wake-mariadb.php', os.path.join('_admin', 'probe.php'), os.path.join('wp-admin', 'probe.php')):
            wr(os.path.join(doc, p), PROBE)
        wr(os.path.join(doc + '-staging', 'probe.php'), PROBE)   # server staging tro docroot vao "<docroot>-staging"
        wr(os.path.join(doc, 'wp-cron.php'), PROBE)
        conf = tpl_ngx
        for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)), ('__FPM_SOCK__', sock),
                     ('__CF_REALIP_DIRECTIVES__', ''), ('__STAGING_DOCROOT__', stg)):
            conf = conf.replace(k, v)
        # _admin/ chi cho LAN rieng (127.0.0.1 bi chan co chu y - xem chu thich trong template): them allow 127.0.0.1 CHI cho test
        a, b = conf.index('location ^~ /_admin/ {'), conf.index('# === Server block THU HAI')
        conf = conf[:a] + conf[a:b].replace('allow 192.168.0.0/16;', 'allow 127.0.0.1;\n allow 192.168.0.0/16;') + conf[b:]
        wr(os.path.join(tmp, 'nginx.conf'), 'user root;\n' + conf if os.geteuid() == 0 else conf)
        open(os.path.join(run, 'ban-list.conf'), 'a').close()
        for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
            os.makedirs(m, exist_ok=True)
        fc = tpl_fpm
        for k, v in (('__RUNDIR__', run), ('__FPM_SOCK__', sock), ('__FILESDIR__', files), ('__EXT_DIR__', tmp), ('__STAGING_PORT__', str(sport)),
                     ('__MYSQL_SOCK__', os.path.join(run, 'mysql.sock')), ('__DB_NAME__', 'x'), ('__DB_USER__', 'x'), ('__DB_PASS__', 'x')):
            fc = fc.replace(k, v)
        fc = fc.replace('listen.mode = 0660', 'listen.mode = 0666').replace('pm = ondemand', 'pm = static').replace('pm.max_children = 3', 'pm.max_children = 1')
        fc = re.sub(r'(?m)^pm\.process_idle_timeout.*\n', '', fc)
        fc = re.sub(r'(?m)^\[(www|hard)\]$', lambda m: '[%s]\nuser = root\ngroup = root' % m.group(1), fc)
        wr(os.path.join(tmp, 'fpm.conf'), fc)
        wr(os.path.join(tmp, 'php.ini'), 'cgi.fix_pathinfo=0\n')
        fpm_p = subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        procs.append(fpm_p)
        ngx_p = subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        procs.append(ngx_p)
        for _ in range(100):
            try:
                socket.create_connection(('127.0.0.1', port), timeout=0.2).close()
                break
            except OSError:
                time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(sock) and os.path.exists(hsock):
                break
            time.sleep(0.1)
        flag = os.path.join(run, 'php-harden-on')

        def get(path, p=None):
            c = http.client.HTTPConnection('127.0.0.1', p or port, timeout=20)
            try:
                c.request('GET', path, headers={'User-Agent': 'Mozilla/5.0 TestBrowser'})
                r = c.getresponse()
                body = r.read().decode('utf-8', 'replace')
                return r.status, body
            finally:
                c.close()

        def probe(path, p=None):
            sc, body = get(path, p)
            try:
                return sc, json.loads(body)
            except ValueError:
                return sc, {'raw': body[:120]}

        def settle(pred, timeout=6.0):
            """Cho toi khi pred() dung; tra thoi gian cho. Co NHAN dung tuc thi (open_file_cache_errors off), co XOA co hieu luc sau toi da ~2 giay (open_file_cache_valid 2s) - xem chu thich nginx.conf.template."""
            t0 = time.time()
            while time.time() - t0 < timeout:
                try:
                    if pred():
                        return time.time() - t0
                except Exception:
                    pass
                time.sleep(0.25)
            return None

        print('== A. Probe tong hop: nginx + php-fpm that, moi pool 1 worker ==')
        check('hai socket pool deu duoc tao', os.path.exists(sock) and os.path.exists(hsock), os.listdir(run))
        sc, pub0 = probe('/index.php')
        check('TAT (mac dinh): trang cong khai co ham chay lenh', sc == 200 and pub0.get('shell_exec') is True and pub0.get('run') == 'hi', (sc, pub0))
        sc, adm0 = probe('/_admin/probe.php')
        check('TAT: _admin/ vao duoc (thu nghiem allow 127.0.0.1) va co shell_exec', sc == 200 and adm0.get('shell_exec') is True, (sc, adm0))
        www_pid = pub0.get('pid')
        check('TAT: trang cong khai va _admin/ cung 1 worker (pool www 1 worker)', pub0.get('pid') == adm0.get('pid'), (pub0.get('pid'), adm0.get('pid')))

        open(flag, 'w').write('1')
        sc, pub1 = probe('/index.php')
        check('BAT: trang cong khai MAT shell_exec/exec/system/popen/proc_open', sc == 200 and not any(pub1.get(k) for k in ('shell_exec', 'exec', 'system', 'popen', 'proc_open')) and pub1.get('run') is None, (sc, pub1))
        check('BAT: disable_functions thay doi that (ini) o pool hard', 'shell_exec' in (pub1.get('dis') or ''), pub1.get('dis'))
        check('BAT: curl_init VAN CO (WordPress goi HTTP ra ngoai bang curl)', pub1.get('curl_init') == pub0.get('curl_init'), (pub1.get('curl_init'), pub0.get('curl_init')))
        hard_pid = pub1.get('pid')
        check('BAT: request cong khai do worker KHAC worker pool www', hard_pid and hard_pid != www_pid, (hard_pid, www_pid))
        sc, lg = probe('/wp-login.php')
        check('BAT: /wp-login.php (location rieng) cung di pool hard', sc == 200 and lg.get('shell_exec') is False and lg.get('pid') == hard_pid, (sc, lg))
        sc, pm = probe('/wp-admin/probe.php')
        check('BAT: /wp-admin/*.php cung di pool hard', sc == 200 and pm.get('shell_exec') is False and pm.get('pid') == hard_pid, (sc, pm))
        sc, cr = probe('/wp-cron.php')
        check('BAT: /wp-cron.php cung di pool hard (khong can ham lenh)', sc == 200 and cr.get('shell_exec') is False, (sc, cr))

        # ---- Khong ro sang noi can day du ----
        sc, adm1 = probe('/_admin/probe.php')
        check('BAT: _admin/ VAN day du (khong ro tu pool hard): shell_exec chay duoc', sc == 200 and adm1.get('shell_exec') is True and adm1.get('run') == 'hi' and adm1.get('dis') == '', (sc, adm1))
        check('BAT: _admin/ do dung worker pool www (cung worker truoc khi bat)', adm1.get('pid') == www_pid, (adm1.get('pid'), www_pid))
        sc, stg1 = probe('/probe.php', sport)
        check('BAT: server staging (cong rieng) VAN day du', sc == 200 and stg1.get('shell_exec') is True and stg1.get('dis') == '', (sc, stg1))
        open(os.path.join(run, 'mariadb-asleep'), 'w').write('1')
        sc, wk = probe('/index.php')
        check('BAT + MariaDB ngu: trang cong khai duoc rewrite sang wake-mariadb.php chay o pool www (CO shell_exec)', sc == 200 and wk.get('script') == '/wake-mariadb.php' and wk.get('shell_exec') is True and wk.get('run') == 'hi' and wk.get('pid') == www_pid, (sc, wk))
        os.remove(os.path.join(run, 'mariadb-asleep'))
        check('xoa co mariadb-asleep: trang cong khai het bi rewrite sang wake-mariadb trong <= 4s', settle(lambda: probe('/index.php')[1].get('script') != '/wake-mariadb.php', 4) is not None)
        sc, hz = get('/healthz')
        check('BAT: /healthz van pong (ping cua pool www)', sc == 200 and hz.strip() == 'pong', (sc, hz))

        # ---- Xen ke nhieu luot: moi ket qua phai dung (khong ro) ----
        bad = []
        for i in range(12):
            for path, pt, want in (('/index.php', None, False), ('/_admin/probe.php', None, True), ('/wp-admin/probe.php', None, False), ('/probe.php', sport, True), ('/wp-cron.php', None, False), ('/_admin/probe.php', None, True)):
                sc, r = probe(path, pt)
                if sc != 200 or r.get('shell_exec') is not want:
                    bad.append((i, path, sc, r.get('shell_exec')))
        check('BAT: 72 request xen ke cong khai/_admin/staging - KHONG mot lan nao sai (khong ro disable_functions; /wp-login.php khong dua vao vong vi co gioi han 5 lan/phut)', not bad, bad[:3])
        pids_pub = {probe('/index.php')[1].get('pid') for _ in range(5)}
        check('BAT: moi request cong khai di worker pool hard (1 pid duy nhat)', pids_pub == {hard_pid}, pids_pub)

        # ---- Tat lai: ngay lap tuc, khong HUP ----
        os.remove(flag)
        dt = settle(lambda: probe('/index.php')[1].get('shell_exec') is True, 4)
        check('TAT lai (chi xoa file co, KHONG HUP/khoi dong lai): trang cong khai co lai shell_exec trong <= ~2s (open_file_cache_valid 2s)', dt is not None, dt)
        sc, pub2 = probe('/index.php')
        check('TAT lai: ket qua day du (shell_exec chay that)', sc == 200 and pub2.get('shell_exec') is True and pub2.get('run') == 'hi', (sc, pub2))
        check('TAT lai: quay ve worker pool www', pub2.get('pid') == www_pid, (pub2.get('pid'), www_pid))
        sc, lg2 = probe('/wp-login.php')
        check('TAT lai: /wp-login.php cung quay ve pool www', sc == 200 and lg2.get('shell_exec') is True, (sc, lg2))
        open(flag, 'w').write('1')
        check('BAT lai lan 2: mat ham NGAY LAP TUC (khong tre)', probe('/index.php')[1].get('shell_exec') is False)
        os.remove(flag)
        check('TAT lan 2: co lai trong <= ~2s', settle(lambda: probe('/index.php')[1].get('shell_exec') is True, 4) is not None)

        # ---- pool hard chet => 502 (khong am tham chay khong bao ve) ----
        open(flag, 'w').write('1')
        os.remove(hsock)       # mo phong socket pool hard khong con: PHAI bao loi 502, KHONG tu dong lui ve pool www (am tham mat bao ve)
        sc, _ = get('/index.php')
        check('BAT ma pool hard khong nghe duoc: 502 (fail-closed, KHONG tu roi sang pool www)', sc == 502, sc)
        os.remove(flag)
        check('xoa co: site chay lai trong <= ~2s', settle(lambda: get('/index.php')[0] == 200, 4) is not None)
        # ---- log php-fpm khong co canh bao cau hinh ----
        fpm_p.terminate()
        try:
            out = fpm_p.communicate(timeout=10)[0].decode('utf-8', 'replace')
        except Exception:
            fpm_p.kill()
            out = ''
        logtxt = out + (open(os.path.join(run, 'php-fpm.log'), errors='replace').read() if os.path.exists(os.path.join(run, 'php-fpm.log')) else '')
        check('log php-fpm khong co ERROR / "Cannot disable function"', not re.search(r'ERROR|Cannot disable|Unable to disable|unknown', logtxt, re.I), logtxt[-300:])
    finally:
        for p in procs:
            try:
                p.terminate()
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        shutil.rmtree(tmp, ignore_errors=True)

    # ---------------- PHAN B (WordPress that) ----------------
    if wp_src and sq_src and os.path.isdir(wp_src) and os.path.isdir(sq_src) and 'hard' in pools:
        part_b(nginx, fpm, tpl_fpm, tpl_ngx, wp_src, sq_src, check)
    else:
        print('(PHAN B bo qua: can WP_REAL_SRC + WP_SQLITE_SRC)')
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


def part_b(nginx, fpm, tpl_fpm, tpl_ngx, wp_src, sq_src, check):
    import json
    spec = importlib.util.spec_from_file_location('wpreal', os.path.join(HERE, 'wp-real-test.py'))
    wr_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(wr_mod)
    print('== B. WordPress THAT 7.1.4 (SQLite) duoi pool hard ==')
    site = wr_mod.Site(wp_src, sq_src)
    procs = []
    try:
        ok, msg = site.install()
        check('cai WordPress that (SQLite)', ok, msg)
        if not ok:
            return
        run = site.run
        os.makedirs(os.path.join(run, 'php-sessions'), exist_ok=True)
        plugdir = os.path.join(site.site, 'wp-content', 'plugins')
        extra = [p for p in (os.environ.get('WP_EXTRA_PLUGINS') or '').split(':') if p and os.path.isdir(p)]
        activated = []
        for src in extra:
            name = os.path.basename(src.rstrip('/'))
            try:
                shutil.copytree(src, os.path.join(plugdir, name), ignore=shutil.ignore_patterns('.git', 'node_modules', 'tests'), symlinks=False)
            except (OSError, shutil.Error):
                continue
            out = site.cli("$r = activate_plugin(%r . '/' . %r); echo is_wp_error($r) ? 'ERR ' . $r->get_error_message() : 'ACT';" % (name, name + '.php'))
            if 'ACT' in out and 'ERR' not in out:
                activated.append(name)
            else:
                print('INFO: %s: kich hoat thu 1 khong duoc (%s)' % (name, out.strip()[:140]))
                # tep chinh co the ten khac thu muc
                mains = [f for f in os.listdir(os.path.join(plugdir, name)) if f.endswith('.php') and 'Plugin Name:' in open(os.path.join(plugdir, name, f), errors='replace').read(4000)]
                if mains:
                    out = site.cli("$r = activate_plugin(%r); echo is_wp_error($r) ? 'ERR ' . $r->get_error_message() : 'ACT';" % (name + '/' + mains[0]))
                    if 'ACT' in out and 'ERR' not in out:
                        activated.append(name)
                    else:
                        print('INFO: %s: bo qua - khong kich hoat duoc tren SQLite/ban nguon GitHub (%s)' % (name, out.strip()[:140]))
        print('INFO: plugin da kich hoat: %s' % (', '.join(activated) or '(khong)'))
        site.cli("global $wp_rewrite; $wp_rewrite->set_permalink_structure('/%postname%/'); $wp_rewrite->flush_rules(false); echo 'OK';")
        sport = wr_mod.free_port()
        sock, hsock = os.path.join(run, 'php-fpm.sock'), os.path.join(run, 'php-hard.sock')
        app = site.home
        conf = tpl_ngx
        for k, v in (('__RUNDIR__', run), ('__DOCROOT__', site.site), ('__WEBROOT__', site.site), ('__PORT__', str(site.port)), ('__STAGING_PORT__', str(sport)), ('__FPM_SOCK__', sock),
                     ('__CF_REALIP_DIRECTIVES__', ''), ('__STAGING_DOCROOT__', os.path.join(site.tmp, 'stg'))):
            conf = conf.replace(k, v)
        os.makedirs(os.path.join(site.tmp, 'stg'), exist_ok=True)
        wr(os.path.join(site.tmp, 'nginx.conf'), 'user root;\n' + conf if os.geteuid() == 0 else conf)
        open(os.path.join(run, 'ban-list.conf'), 'a').close()
        for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
            os.makedirs(m, exist_ok=True)
        fc = tpl_fpm
        for k, v in (('__RUNDIR__', run), ('__FPM_SOCK__', sock), ('__FILESDIR__', app), ('__EXT_DIR__', site.tmp), ('__STAGING_PORT__', str(sport)),
                     ('__MYSQL_SOCK__', os.path.join(run, 'mysql.sock')), ('__DB_NAME__', 'x'), ('__DB_USER__', 'x'), ('__DB_PASS__', 'x')):
            fc = fc.replace(k, v)
        fc = fc.replace('listen.mode = 0660', 'listen.mode = 0666')
        fc = re.sub(r'(?m)^\[(www|hard)\]$', lambda m: '[%s]\nuser = root\ngroup = root' % m.group(1), fc)
        fc = fc.replace('php_admin_flag[log_errors] = on', 'php_admin_flag[log_errors] = on\nphp_admin_flag[display_errors] = off')
        wr(os.path.join(site.tmp, 'fpm.conf'), fc)
        wr(os.path.join(site.tmp, 'php.ini'), 'cgi.fix_pathinfo=0\nmemory_limit=512M\n')
        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(site.tmp, 'fpm.conf'), '-c', os.path.join(site.tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(site.tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try:
                socket.create_connection(('127.0.0.1', site.port), timeout=0.2).close()
                break
            except OSError:
                time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(sock) and os.path.exists(hsock):
                break
            time.sleep(0.1)

        def http_req(method, path, body=None, headers=None, cookies=None):
            h = {'User-Agent': 'Mozilla/5.0 TestBrowser'}
            h.update(headers or {})
            if cookies:
                h['Cookie'] = '; '.join('%s=%s' % kv for kv in cookies.items())
            c = http.client.HTTPConnection('127.0.0.1', site.port, timeout=120)
            try:
                c.request(method, path, body=body, headers=h)
                r = c.getresponse()
                data = r.read().decode('utf-8', 'replace')
                ck = {}
                for sc in r.msg.get_all('Set-Cookie') or []:
                    kv = sc.split(';', 1)[0]
                    if '=' in kv:
                        k, v = kv.split('=', 1)
                        ck[k] = v
                return r.status, data, ck, {k.lower(): v for k, v in r.getheaders()}
            finally:
                c.close()

        open(os.path.join(run, 'php-harden-on'), 'w').write('1')
        sc, body, _, _ = http_req('GET', '/')
        check('WP that, pool hard: trang chu 200 (co noi dung WordPress)', sc == 200 and ('Test Site' in body or 'wp-content' in body), (sc, body[:100]))
        sc, body, ck0, _ = http_req('GET', '/wp-login.php')
        check('WP that, pool hard: /wp-login.php 200', sc == 200 and 'user_login' in body, sc)
        ck0 = {k: v for k, v in ck0.items()}
        data = 'log=owner&pwd=Pa55word-Test%21&wp-submit=Log+In&redirect_to=' + 'http%3A%2F%2F127.0.0.1%3A' + str(site.port) + '%2Fwp-admin%2F&testcookie=1'
        ck0['wordpress_test_cookie'] = 'WP%20Cookie%20check'
        sc, body, ck, hd = http_req('POST', '/wp-login.php', body=data, headers={'Content-Type': 'application/x-www-form-urlencoded'}, cookies=ck0)
        logged = {k: v for k, v in ck.items() if k.startswith('wordpress_logged_in')}
        check('WP that, pool hard: DANG NHAP duoc (cookie wordpress_logged_in, chuyen huong 302)', sc == 302 and logged, (sc, list(ck)))
        cookies = dict(ck)
        for path, want in (('/wp-admin/', 'Dashboard'), ('/wp-admin/plugins.php', 'Plugins'), ('/wp-admin/options-general.php', 'General Settings'), ('/wp-admin/site-health.php', 'Site Health'),
                           ('/wp-admin/edit.php', 'Posts'), ('/wp-admin/tools.php', 'Tools'), ('/wp-admin/update-core.php', 'Updates')):
            sc, body, _, hd = http_req('GET', path, cookies=cookies)
            if sc == 302 and hd.get('location', '').startswith('http://127.0.0.1:%d/' % site.port):
                print('INFO: %s chuyen huong -> %s (man hinh chao cua plugin vua kich hoat, binh thuong)' % (path, hd.get('location')))
                sc, body, _, hd = http_req('GET', hd['location'][len('http://127.0.0.1:%d' % site.port):], cookies=cookies)
                want = None
            check('WP that, pool hard: %s 200%s' % (path, (' (%s)' % want) if want else ' (sau chuyen huong)'), sc == 200 and (want is None or want in body), (sc, body[:80]))
        sc, body, _, _ = http_req('GET', '/wp-json/', cookies=None)
        check('WP that, pool hard: REST /wp-json/ tra JSON', sc == 200 and '"namespaces"' in body, (sc, body[:80]))
        sc, body, _, _ = http_req('GET', '/wp-cron.php?doing_wp_cron')
        check('WP that, pool hard: wp-cron.php chay (200)', sc == 200, sc)
        sc, body, _, _ = http_req('GET', '/?s=hello')
        check('WP that, pool hard: tim kiem 200', sc == 200, sc)
        sc, body, _, _ = http_req('GET', '/feed/')
        check('WP that, pool hard: /feed/ 200 (XML)', sc == 200 and '<rss' in body, sc)
        for pl in activated:
            sc, body, _, _ = http_req('GET', '/wp-admin/plugins.php', cookies=cookies)
            check('plugin %s dang kich hoat: wp-admin van 200' % pl, sc == 200, sc)
        # khong "disabled for security reasons" o bat ky log nao
        logs = ''
        for n in ('php-error.log', 'php-fpm.log', 'php-slow.log'):
            p = os.path.join(run, n)
            if os.path.exists(p):
                logs += open(p, errors='replace').read()
        for extra_log in (os.path.join(site.tmp, 'php-error.log'),):
            if os.path.exists(extra_log):
                logs += open(extra_log, errors='replace').read()
        dis_hits = re.findall(r'[^\n]*(?:has been disabled for security reasons|Call to undefined function (?:exec|shell_exec|system|passthru|popen|proc_open)\b)[^\n]*', logs)
        check('log PHP (core + %d plugin lon): KHONG co canh bao ham bi tat / "Call to undefined function exec..."' % len(activated), not dis_hits, dis_hits[:3])
        fatals = re.findall(r'[^\n]*PHP Fatal error[^\n]*', logs)
        check('log PHP khong co Fatal error', not fatals, fatals[:2])
    finally:
        for p in procs:
            try:
                p.terminate()
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        try:
            site.stop()
        except Exception:
            pass
        shutil.rmtree(site.tmp, ignore_errors=True)


if __name__ == '__main__':
    sys.exit(main())
