#!/usr/bin/env python3
"""FUZZ ngau nhien co seed cho _admin/ (HANDOFF.md muc 1br; PDF 1 muc M3 "Fuzz test cho _admin/") qua php -S THAT, dung chung khung voi admin-security-test.py.

Khac admin-security-test.py (kich ban viet tay, co chu dich): o day SINH ngau nhien (seed co dinh -> tai lap duoc, doi bang FUZZ_SEED; so luot bang FUZZ_ITERS)
cac yeu cau GET/POST toi MOI trang _admin/ DA DANG NHAP + CSRF hop le, voi tham so/gia tri rac: chuoi dai, unicode, NUL, mang long, duong dan ".." (tuong doi,
tuyet doi, ma hoa 2 lan), chen lenh shell ($(..), `..`, ;.., |..), SQL, XSS, so cuc lon, kieu sai (a[]=, a[b][c]=). ORACLE (neu vi pham = loi that, khong phai test hong):
  1) KHONG 5xx, KHONG "Fatal error / Uncaught / Parse error / Stack trace" trong noi dung tra ve;
  2) KHONG tao file canary bang chen lenh shell (canary nam NGOAI cay web) va KHONG de lo noi dung file canary bi tro toi bang ".." (traversal);
  3) KHONG lo mat khau quan tri / ma bi mat phien; mat khau quan tri + wp-config.php + file canary KHONG bi doi sau toan bo dot fuzz;
  4) KHONG co file moi/doi nao NGOAI cac thu muc cho phep (app_home, www, thu muc phien) - canary + cay tmp con lai nguyen ven;
  5) trang van phuc vu duoc sau dot fuzz (khong bi chet/treo): GET moi trang lai 200.
"""
import hashlib, importlib.util, os, random, re, shutil, sys, tempfile, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location('adminsec', os.path.join(HERE, 'admin-security-test.py'))
AS = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(AS)
PASS = FAIL = 0
SEED = int(os.environ.get('FUZZ_SEED', '20261031'))
ITERS = int(os.environ.get('FUZZ_ITERS', '3000'))
# Trang co the cham mang / cai dat that khi nhan POST hop le: chi fuzz GET (POST rac van duoc gui nhung KHONG kem CSRF hop le -> bi tu choi som, cung la 1 kich ban dang thu)
POST_SKIP = {'install-wp'}
PAGES = [n for n, _ in AS.PAGES if n not in AS.LIB_ONLY] + ['index']


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:300]) if detail else ''))


class Gen:
    def __init__(self, seed, canary_dir, canary_secret_path, pwn_path):
        self.r = random.Random(seed)
        self.cd = canary_dir
        self.cs = canary_secret_path
        self.pwn = pwn_path

    def value(self):
        r = self.r
        pwn = self.pwn
        rel_up = '../' * r.randint(1, 8)
        corpus = [
            '', ' ', '0', '-1', '1', '2147483648', '99999999999999999999', '1e308', 'NaN', 'true', 'null', 'undefined', 'Array',
            'A' * r.choice([10, 300, 5000, 70000]), 'Đăng nhập Ư Ơ ế ồ 日本語 العربية', '‮​﻿', '%', '%00', '\x00', 'a\x00b', '\r\n', 'x\r\nSet-Cookie: pwn=1',
            '<script>alert(1)</script>', '"><img src=x onerror=alert(1)>', "' OR '1'='1", "'; DROP TABLE wp_users;--", '${7*7}', '{{7*7}}', '<?php echo 1;?>',
            rel_up + os.path.basename(self.cs), rel_up + self.cs.lstrip('/'), self.cs, os.path.join(self.cd, 'canary-secret.txt'), '..', '../', '..\\..\\x', '%2e%2e%2f' * 3 + os.path.basename(self.cs),
            '%252e%252e%252f' * 3 + os.path.basename(self.cs), '....//....//' + os.path.basename(self.cs), 'file:///etc/passwd', 'php://filter/convert.base64-encode/resource=' + self.cs, 'http://127.0.0.1:1/x',
            '/etc/passwd', '/proc/self/environ', '~', '*', '?', '|', '&', ';', '`id`',
            '$(touch %s)' % pwn, '`touch %s`' % pwn, ';touch %s;' % pwn, '|touch %s' % pwn, '&& touch %s' % pwn, '\ntouch %s\n' % pwn, "plugin list; touch %s" % pwn,
            "hello' ; touch %s ; '" % pwn, '--url=http://x --exec=touch\\ %s' % pwn, 'option update siteurl %s' % pwn,
        ]
        v = r.choice(corpus)
        if r.random() < 0.15:
            v = v + r.choice(corpus)
        return v

    def key(self, known):
        r = self.r
        k = r.choice(known + ['a', 'id', 'file', 'path', 'name', 'q', 'page', 'v', 'url', 'cmd', 'dir', 'f', 'x', 'action', 'sort', 'limit', 'offset', 'csrf_token', 'admin_password', 'totp_code'])
        t = r.random()
        if t < 0.08:
            return k + '[]'
        if t < 0.14:
            return k + '[x][y]'
        if t < 0.17:
            return k + '\x00'
        if t < 0.20:
            return k * 40
        return k

    def params(self, known, lo=0, hi=7):
        return [(self.key(known), self.value()) for _ in range(self.r.randint(lo, hi))]


def build_fields(adm):
    """Cac ten tham so/hanh dong THAT cua tung trang (lay tu ma nguon) de fuzz co co so; van them khoa ngau nhien."""
    per = {}
    for n in PAGES:
        src = open(os.path.join(adm, n + '.php'), encoding='utf-8').read()
        actions = sorted(set(re.findall(r"\$action\s*===\s*'([a-z_0-9-]+)'", src)) | set(re.findall(r"'action'\s*=>\s*'([a-z_0-9-]+)'", src)))
        fields = sorted(set(re.findall(r"\$_(?:POST|GET|REQUEST)\['([A-Za-z0-9_]+)'\]", src)) - {'csrf_token', 'admin_password'})
        per[n] = (actions, fields)
    return per


def tree_state(roots, skip_names=()):
    """Do 'dau van tay' toan bo cay (ten + kich thuoc + sha1 noi dung file nho) de so sanh truoc/sau."""
    out = {}
    for root in roots:
        for d, dirs, files in os.walk(root):
            for n in dirs:
                out[os.path.join(d, n)] = 'dir'
            for n in files:
                if n in skip_names:
                    continue
                p = os.path.join(d, n)
                try:
                    st = os.stat(p)
                    h = hashlib.sha1(open(p, 'rb').read()).hexdigest() if st.st_size < 2_000_000 else str(st.st_size)
                    out[p] = (st.st_size, h)
                except OSError:
                    out[p] = 'gone'
    return out


def run_tests(port, app, run, www, adm, tmp):
    canary = os.path.join(tmp, 'canary')
    os.makedirs(canary)
    secret = 'CANARY-SECRET-%s-DO-NOT-LEAK' % hashlib.sha1(str(SEED).encode()).hexdigest()[:12]
    secret_path = os.path.join(canary, 'canary-secret.txt')
    open(secret_path, 'w').write(secret + '\n')
    pwn = os.path.join(canary, 'PWNED')
    wpcfg = os.path.join(www, 'wp-config.php')
    pwfile = os.path.join(app, 'admin-password.txt')
    wp_before = open(wpcfg).read()
    pw_before = open(pwfile).read()

    c = AS.Client(port, '10.2.2.2')
    check('dang nhap', c.login())
    fields = build_fields(adm)
    # khong tinh cac file nhat ky/khoa/phien lam thay doi hop le
    SKIP = ('admin-audit.log', 'admin-login-attempts.json')
    # tmp co: app_home, www, sess, ext, canary, php-server.log, spoof.php. Cac cho phep THAY DOI: app_home, www, sess, ext (calls.log), php-server.log
    allowed_change = [app, www, os.path.join(tmp, 'sess'), os.path.join(tmp, 'ext')]
    outside_roots = [canary, os.path.join(tmp, 'spoof.php')]
    before_out = tree_state(outside_roots)
    before_all_tmp = set()
    for d, dirs, files in os.walk(tmp):
        for n in dirs + files:
            before_all_tmp.add(os.path.join(d, n))

    g = Gen(SEED, canary, secret_path, pwn)
    bad5xx, fatals, leaks, hung, reqs = [], [], [], [], 0
    methods = {'GET': 0, 'POST': 0, 'POST_csrf': 0}
    tokens = {}

    def tok(n):
        t = c.token(n)
        tokens[n] = t
        return t

    def examine(label, sc, body):
        if sc >= 500:
            bad5xx.append((label, sc))
        m = AS.FATAL_RE.search(body)
        if m:
            fatals.append((label, m.group(0), body[max(0, m.start() - 60):m.start() + 120].replace('\n', ' ')))
        for needle in (secret, AS.PASSWORD, pw_before.strip()):
            if needle and needle in body:
                leaks.append((label, needle[:12]))

    for it in range(ITERS):
        n = g.r.choice(PAGES)
        actions, known = fields[n]
        kind = g.r.random()
        path = '/_admin/%s.php' % n
        try:
            if kind < 0.35:
                q = g.params(known, 0, 6)
                qs = '&'.join('%s=%s' % (urllib.parse.quote(k, safe='[]'), urllib.parse.quote(v, safe='')) for k, v in q)
                sc, body, _ = c.req('GET', path + ('?' + qs if qs else ''))
                methods['GET'] += 1
                examine('GET %s?%s' % (n, qs[:120]), sc, body)
            elif kind < 0.55 or n in POST_SKIP:
                # POST rac KHONG kem CSRF hop le: phai bi tu choi som, khong tac dung phu
                data = dict(g.params(known, 0, 6))
                if actions and g.r.random() < 0.7:
                    data['action'] = g.r.choice(actions)
                sc, body, _ = c.req('POST', path, data)
                methods['POST'] += 1
                examine('POST(no-csrf) %s %s' % (n, str(data)[:120]), sc, body)
            else:
                t = tokens.get(n) if g.r.random() < 0.8 and tokens.get(n) else tok(n)
                data = dict(g.params(known, 0, 6))
                data['csrf_token'] = t or ''
                data['action'] = g.r.choice(actions) if actions and g.r.random() < 0.85 else g.value()
                sc, body, _ = c.req('POST', path, data)
                methods['POST_csrf'] += 1
                if 'admin_password' not in body and sc < 400:
                    methods['accepted'] = methods.get('accepted', 0) + 1     # trang that su xu ly (khong bi tu choi o cong dang nhap/CSRF)
                if 'admin_password' in body and 'csrf_token' not in body and sc == 200:
                    # bi dang xuat (vd hanh dong logout) -> dang nhap lai de tiep tuc fuzz
                    c.login()
                    tokens.clear()
                examine('POST %s %s' % (n, str(data)[:140]), sc, body)
            reqs += 1
        except Exception as e:           # timeout/ngat ket noi = trang treo hoac chet
            hung.append((n, repr(e)[:120]))
            if len(hung) > 5:
                break
        if it % 50 == 49 and not c.token('maintenance'):
            c.login()
            tokens.clear()

    # ---------- Quet co he thong (xac dinh, khong ngau nhien) ----------
    # Ngau nhien kho trung dung to hop (ten tham so, hanh dong, chuoi doc hai) -> quet MOI trang x MOI ten tham so cua trang (+ ten pho bien) x MOI hanh dong
    # voi tung chuoi doc hai (duong dan canary tuyet doi/tuong doi/ma hoa, chen lenh shell, chuoi rat dai, NUL): oracle nhu tren nhung bat duoc loi hiem.
    payloads = [secret_path, '../' * 6 + secret_path.lstrip('/'), '%2e%2e%2f' * 6 + 'canary/canary-secret.txt', '..%252f' * 6 + secret_path.lstrip('/'),
                '$(touch %s)' % pwn, ';touch %s;' % pwn, '`touch %s`' % pwn, '|touch %s' % pwn, "x' ; touch %s ; '" % pwn, 'wp-content/../../' + secret_path.lstrip('/'),
                'A' * 70000, 'a\x00b']
    common = ['file', 'path', 'name', 'id', 'key', 'cmd', 'dir', 'q', 'v', 'url', 'page', 'limit', 'f', 'target', 'src', 'dest']
    sweep = 0
    for n in PAGES:
        actions, known = fields[n]
        names = sorted(set(known) | set(common))
        for pl in payloads:
            for k in names:
                try:
                    sc, body, _ = c.req('GET', '/_admin/%s.php?%s=%s' % (n, k, urllib.parse.quote(pl, safe='')))
                    sweep += 1
                    examine('SWEEP-GET %s?%s=<%d>' % (n, k, len(pl)), sc, body)
                    if n in POST_SKIP:
                        continue
                    t = tok(n)
                    for a in (actions or ['x']):
                        d = {'action': a, 'csrf_token': t or '', k: pl}
                        sc, body, _ = c.req('POST', '/_admin/%s.php' % n, d)
                        sweep += 1
                        examine('SWEEP-POST %s action=%s %s=<%d>' % (n, a, k, len(pl)), sc, body)
                        if 'admin_password' in body and 'csrf_token' not in body and sc == 200:
                            c.login()
                            t = tok(n)
                except Exception as e:
                    hung.append((n, repr(e)[:120]))
                    if len(hung) > 5:
                        break
    print('INFO: quet co he thong: %d yeu cau' % sweep)
    print('INFO: %d yeu cau (GET %d, POST khong CSRF %d, POST co CSRF %d, trong do duoc trang xu ly %d), seed=%d' % (reqs, methods['GET'], methods['POST'], methods['POST_csrf'], methods.get('accepted', 0), SEED))
    check('fuzz that su cham toi logic cac trang (>= 40%% POST co CSRF duoc xu ly, khong chi bi chan o cong)', methods['POST_csrf'] > 0 and methods.get('accepted', 0) >= 0.4 * methods['POST_csrf'], methods)
    check('khong yeu cau nao tra 5xx', not bad5xx, bad5xx[:3])
    check('khong "Fatal error/Uncaught/Parse error/Stack trace" lo ra trong noi dung', not fatals, fatals[:2])
    check('khong yeu cau nao treo/ngat ket noi', not hung, hung[:3])
    check('khong lo noi dung file canary / mat khau quan tri trong bat ky phan hoi nao', not leaks, leaks[:3])
    check('KHONG tao duoc file canary bang chen lenh shell (PWNED khong ton tai)', not os.path.exists(pwn), os.listdir(canary))
    check('mat khau quan tri + wp-config.php khong bi doi', open(pwfile).read() == pw_before and open(wpcfg).read() == wp_before)
    after_out = tree_state(outside_roots)
    check('file canary + spoof.php (ngoai cay web) nguyen ven', after_out == before_out, set(after_out) ^ set(before_out))
    new_outside = []
    for d, dirs, files in os.walk(tmp):
        for nme in dirs + files:
            p = os.path.join(d, nme)
            if p in before_all_tmp:
                continue
            if any(p == a or p.startswith(a + os.sep) for a in allowed_change) or p == os.path.join(tmp, 'php-server.log'):
                continue
            new_outside.append(p)
    check('khong co file/thu muc moi NGOAI cac thu muc cho phep (app_home, www, sess, ext)', not new_outside, new_outside[:5])
    c2 = AS.Client(port, '10.2.2.3')
    ok_login = c2.login()
    dead = []
    if ok_login:
        for n in PAGES:
            sc, body, _ = c2.req('GET', '/_admin/%s.php' % n)
            if sc != 200 or AS.FATAL_RE.search(body):
                dead.append((n, sc))
    check('sau fuzz van dang nhap duoc va MOI trang GET 200 (khong chet, khong Fatal)', ok_login and not dead, dead[:3])


def main():
    tmp = tempfile.mkdtemp(prefix='adminfuzz-')
    app, run, www, adm = AS.build_tree(tmp)
    port = AS.free_port()
    env = dict(os.environ, APP_HOME=app, EXT_DIR=os.path.join(tmp, 'ext'))
    logf = open(os.path.join(tmp, 'php-server.log'), 'w')
    srv = AS.start_php_server(port, www, tmp, env, logf)
    try:
        run_tests(port, app, run, www, adm, tmp)
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        logf.close()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
