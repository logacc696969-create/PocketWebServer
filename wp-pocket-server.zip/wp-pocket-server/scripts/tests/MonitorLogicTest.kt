import com.wppocket.server.MonitorLogic
import com.wppocket.server.MonitorLogic.BudgetState
import java.io.File

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun main() {
    val MB = 1024L * 1024
    // ---- applyUsage ----
    var s = BudgetState("", 0, -1, 0)
    s = MonitorLogic.applyUsage(s, "2026-10", 5 * MB, true)
    check("lan dau: chi dat moc, KHONG tinh 5MB co san", s.cellBytes == 0L && s.lastTotal == 5 * MB && s.monthKey == "2026-10")
    s = MonitorLogic.applyUsage(s, "2026-10", 8 * MB, true)
    check("4G: +3MB", s.cellBytes == 3 * MB)
    s = MonitorLogic.applyUsage(s, "2026-10", 20 * MB, false)
    check("WiFi: +12MB KHONG tinh vao 4G, moc van tien", s.cellBytes == 3 * MB && s.lastTotal == 20 * MB)
    s = MonitorLogic.applyUsage(s, "2026-10", 1 * MB, true)
    check("counter reset (reboot): coi 1MB la phan tang them", s.cellBytes == 4 * MB && s.lastTotal == 1 * MB)
    val withAlert = s.copy(alertLevel = 80)
    val n = MonitorLogic.applyUsage(withAlert, "2026-11", 3 * MB, true)
    check("sang thang moi: reset bo dem + muc canh bao", n.monthKey == "2026-11" && n.alertLevel == 0)
    check("sang thang moi: chi tinh phan tang tu moc (2MB), khong ca tong tich luy", n.cellBytes == 2 * MB)

    // ---- doi nguon bo dem (uid -> mobile) ----
    val before = BudgetState("2026-10", 7 * MB, 900 * MB, 80)
    val rebased = MonitorLogic.rebaseIfSourceChanged(before, "uid", "mobile")
    check("doi nguon: bo moc cu (lastTotal=-1), GIU bo dem thang + muc canh bao", rebased.lastTotal == -1L && rebased.cellBytes == 7 * MB && rebased.alertLevel == 80)
    check("khong doi nguon: giu nguyen", MonitorLogic.rebaseIfSourceChanged(before, "mobile", "mobile") == before)
    check("lan dau (chua co nguon cu): giu nguyen", MonitorLogic.rebaseIfSourceChanged(before, "", "mobile") == before)
    val afterSwitch = MonitorLogic.applyUsage(rebased, "2026-10", 50 * MB, true)
    check("sau khi doi nguon: gia tri tong cua nguon moi KHONG bi tinh het vao thang (chi dat moc)", afterSwitch.cellBytes == 7 * MB && afterSwitch.lastTotal == 50 * MB)

    // ---- budgetLevel ----
    check("budget=0 -> tat", MonitorLogic.budgetLevel(999 * MB, 0) == 0)
    check("79.9% -> 0", MonitorLogic.budgetLevel(799, 1000) == 0)
    check("80% -> 80", MonitorLogic.budgetLevel(800, 1000) == 80)
    check("99% -> 80", MonitorLogic.budgetLevel(990, 1000) == 80)
    check("100% -> 100", MonitorLogic.budgetLevel(1000, 1000) == 100)
    check("vuot -> 100", MonitorLogic.budgetLevel(5000, 1000) == 100)
    val TB = 1024L * 1024 * 1024 * 1024
    check("khong tran so voi ngan sach 10TB (80% -> 80)", MonitorLogic.budgetLevel(8 * TB, 10 * TB) == 80)
    check("50% cua gia tri cuc lon -> 0 (khong sai vi tran)", MonitorLogic.budgetLevel(Long.MAX_VALUE / 200, Long.MAX_VALUE / 100) == 0)

    // ---- disk ----
    check("usedPercent 85%", MonitorLogic.usedPercent(100, 15) == 85)
    check("usedPercent loi -> -1", MonitorLogic.usedPercent(0, 0) == -1 && MonitorLogic.usedPercent(100, 200) == -1)
    check("duoi nguong -> khong bao", !MonitorLogic.shouldAlertDisk(84, 85, 0, 1000, 500))
    check("dat nguong, chua tung bao -> bao", MonitorLogic.shouldAlertDisk(85, 85, 0, 1000, 500))
    check("trong cooldown -> khong lap", !MonitorLogic.shouldAlertDisk(90, 85, 800, 1000, 500))
    check("het cooldown -> bao lai", MonitorLogic.shouldAlertDisk(90, 85, 400, 1000, 500))

    val dir = File(System.getProperty("java.io.tmpdir"), "mltest-" + System.nanoTime()).apply { mkdirs() }
    File(dir, "big.log").writeBytes(ByteArray(3 * 1024 * 1024))
    File(dir, "small.log").writeBytes(ByteArray(100))
    File(dir, "admin-audit.log").writeBytes(ByteArray(3 * 1024 * 1024))
    File(dir, "data.csv").writeBytes(ByteArray(3 * 1024 * 1024))
    val freed = MonitorLogic.truncateBigLogs(dir, 1024 * 1024, setOf("admin-audit.log"))
    check("cat big.log (3MB) ve 0", File(dir, "big.log").length() == 0L && freed == 3L * 1024 * 1024)
    check("KHONG cat file nho", File(dir, "small.log").length() == 100L)
    check("KHONG cat admin-audit.log (bang chung bao mat)", File(dir, "admin-audit.log").length() == 3L * 1024 * 1024)
    check("KHONG cat file khong phai .log", File(dir, "data.csv").length() == 3L * 1024 * 1024)

    // ---- audit scan ----
    val lines = listOf(
        "2026-10-06 10:00:00 ip=1.1.1.1 dang nhap THANH CONG",
        "2026-10-06 10:01:00 ip=9.9.9.9 dang nhap sai (1/5)",
        "2026-10-06 10:01:05 ip=9.9.9.9 dang nhap sai (2/5)",
        "2026-10-06 10:01:09 ip=2.2.2.2 sai ma 2FA (1/5)",
        "2026-10-06 10:01:30 ip=9.9.9.9 BI KHOA TAM (qua 5 lan sai)",
        "rac khong dung dinh dang",
        "2026-10-06 10:02:00 ip=1.1.1.1 mat khau dung, cho nhap ma 2FA")
    val sum = MonitorLogic.scanAudit(lines)
    check("dem 3 lan sai (2 mat khau + 1 2FA)", sum.failures == 3)
    check("dem 1 lan khoa", sum.lockouts == 1)
    check("IP nhieu nhat = 9.9.9.9 (3 su kien)", sum.topIp == "9.9.9.9" && sum.topIpFailures == 3)
    check("co khoa -> bao dong", MonitorLogic.shouldAlertAudit(sum))
    check("dang nhap thanh cong khong bi tinh la sai", MonitorLogic.scanAudit(listOf(lines[0], lines[6])).failures == 0)
    check("4 lan sai khong khoa -> chua bao", !MonitorLogic.shouldAlertAudit(MonitorLogic.AuditSummary(4, 0, "x", 4)))
    check("5 lan sai -> bao", MonitorLogic.shouldAlertAudit(MonitorLogic.AuditSummary(5, 0, "x", 5)))
    // 1bc: dong audit MOI do admin-auth.php / sessions.php ghi (khuon dong y het admin-session-test.py muc 9) KHONG duoc tinh la
    // "dang nhap sai" hay "khoa" - neu khong, moi lan thu hoi phien/doi mat khau se bao dong gia qua Telegram.
    val newEvents = listOf(
        "2026-10-15 12:00:00 ip=192.168.1.10 phien bi huy: mat khau quan tri da doi",
        "2026-10-15 12:00:01 ip=192.168.1.11 phien bi huy: phien da bi thu hoi",
        "2026-10-15 12:00:02 ip=192.168.1.12 phien bi huy: phien cu (truoc khi co quan ly phien) - dang nhap lai",
        "2026-10-15 12:00:03 ip=192.168.1.10 thu hoi phien a1b2c3",
        "2026-10-15 12:00:04 ip=192.168.1.10 thu hoi tat ca phien khac (3)",
        "2026-10-15 12:00:05 ip=192.168.1.10 dang xuat",
        // 1bk (G4): vet thao tac nhay cam do wp_pocket_csrf_verify() / admin-wpcli.php ghi
        "2026-10-15 12:00:07 ip=192.168.1.10 thao tac maintenance.php action=enable",
        "2026-10-15 12:00:08 ip=192.168.1.10 thao tac wpcli.php",
        "2026-10-15 12:00:09 ip=192.168.1.10 wp-cli plugin install"
    )
    val sumNew = MonitorLogic.scanAudit(newEvents)
    check("dong audit moi (huy phien/thu hoi/dang xuat) KHONG tinh la dang nhap sai/khoa", sumNew.failures == 0 && sumNew.lockouts == 0)
    check("... va khong gay canh bao Telegram", !MonitorLogic.shouldAlertAudit(sumNew))
    val mixed = MonitorLogic.scanAudit(newEvents + "2026-10-15 12:00:06 ip=10.0.0.9 dang nhap sai (mat khau)")
    check("xen lan 1 dong dang nhap sai that -> dem dung 1 (khong bi lan voi dong moi)", mixed.failures == 1 && mixed.lockouts == 0)
    check("khong co gi -> khong bao", !MonitorLogic.shouldAlertAudit(MonitorLogic.scanAudit(emptyList())))

    // ---- readNewLines ----
    val af = File(dir, "audit.log")
    af.writeText("a1\na2\n")
    var (l1, off1) = MonitorLogic.readNewLines(af, 0)
    check("doc 2 dong dau", l1 == listOf("a1", "a2") && off1 == 6L)
    af.appendText("a3\na4-dang-ghi-do")
    var (l2, off2) = MonitorLogic.readNewLines(af, off1)
    check("chi doc dong MOI + bo dong chua ket thuc", l2 == listOf("a3") && off2 == 9L)
    af.appendText("\n")
    var (l3, off3) = MonitorLogic.readNewLines(af, off2)
    check("lan sau doc nguyen ven dong truoc do dang ghi", l3 == listOf("a4-dang-ghi-do"))
    var (l4, off4) = MonitorLogic.readNewLines(af, off3)
    check("khong co gi moi -> rong, offset giu nguyen", l4.isEmpty() && off4 == off3)
    af.writeText("moi1\n")            // file bi cat/xoay vong (nho hon offset)
    var (l5, off5) = MonitorLogic.readNewLines(af, off4)
    check("file bi xoay vong (nho hon offset) -> doc lai tu dau", l5 == listOf("moi1") && off5 == 5L)
    check("file khong ton tai -> rong", MonitorLogic.readNewLines(File(dir, "khong-co"), 99).first.isEmpty())
    // tieng Viet co dau: offset tinh theo BYTE, khong theo ky tu
    val vf = File(dir, "vi.log"); vf.writeText("Đăng nhập sai\nlần hai\n", Charsets.UTF_8)
    var (lv, offv) = MonitorLogic.readNewLines(vf, 0)
    check("UTF-8: offset theo BYTE = file.length", lv.size == 2 && offv == vf.length())
    // file lon: gioi han maxBytes
    val bf = File(dir, "huge.log"); bf.writeText((1..50000).joinToString("") { "dong-so-$it\n" })
    var (lb, offb) = MonitorLogic.readNewLines(bf, 0, maxBytes = 1000)
    check("gioi han maxBytes: chi doc <=1000B cuoi, bo dong cut dau", lb.isNotEmpty() && lb.all { it.startsWith("dong-so-") && it.length >= 9 } && offb == bf.length())

    // ---- pin ----
    check("pin 14% khong sac -> yeu", MonitorLogic.isLowBattery(14, false))
    check("pin 14% DANG SAC -> khong yeu", !MonitorLogic.isLowBattery(14, true))
    check("pin 15% -> khong yeu (nguong loai tru)", !MonitorLogic.isLowBattery(15, false))
    check("pin khong doc duoc (-1) -> khong yeu", !MonitorLogic.isLowBattery(-1, false))
    // ---- B6: viec nang chi khi sac ----
    check("isCharging: dang cam AC (plugged=1), status DISCHARGING(3) -> sac", MonitorLogic.isCharging(3, 1))
    check("isCharging: status CHARGING(2), plugged=0 -> sac", MonitorLogic.isCharging(2, 0))
    check("isCharging: status FULL(5) -> sac", MonitorLogic.isCharging(5, 0))
    check("isCharging: DISCHARGING(3), khong cam -> khong sac", !MonitorLogic.isCharging(3, 0))
    check("isCharging: khong doc duoc (-1,0) -> khong sac", !MonitorLogic.isCharging(-1, 0))
    check("wantDefer: tuy chon BAT + khong sac -> hoan", MonitorLogic.wantDeferHeavyJobs(true, false))
    check("wantDefer: tuy chon BAT + dang sac -> khong hoan", !MonitorLogic.wantDeferHeavyJobs(true, true))
    check("wantDefer: tuy chon TAT -> khong bao gio hoan", !MonitorLogic.wantDeferHeavyJobs(false, false))
    val flag = File(dir, "lamp-run/defer-heavy-jobs")
    check("syncFlagFile: bat -> tao file (tao ca thu muc cha)", MonitorLogic.syncFlagFile(flag, true, 1_700_000_000_000L) && flag.exists())
    check("syncFlagFile: mtime duoc dat dung", flag.lastModified() == 1_700_000_000_000L)
    MonitorLogic.syncFlagFile(flag, true, 1_700_000_900_000L)
    check("syncFlagFile: goi lai khi bat -> LAM MOI mtime (de PHP biet app con song)", flag.lastModified() == 1_700_000_900_000L)
    check("syncFlagFile: tat -> xoa file", !MonitorLogic.syncFlagFile(flag, false, 0L) && !flag.exists())
    check("syncFlagFile: tat khi chua co file -> khong loi", !MonitorLogic.syncFlagFile(flag, false, 0L))
    dir.deleteRecursively()
    // ---- 1bc: canh bao moi truong ----
    val ok = MonitorLogic.EnvSnapshot(restrictBackgroundStatus = 1, vpnActive = false, onCellular = false, roaming = false, standbyBucket = 10, batteryPct = 80, charging = false)
    check("moi truong binh thuong -> khong van de", MonitorLogic.envIssues(ok).isEmpty())
    check("Data Saver ENABLED (3) -> DATA_SAVER", MonitorLogic.envIssues(ok.copy(restrictBackgroundStatus = 3)) == listOf(MonitorLogic.EnvIssue.DATA_SAVER))
    check("Data Saver WHITELISTED (2, app duoc mien) -> KHONG bao", MonitorLogic.envIssues(ok.copy(restrictBackgroundStatus = 2)).isEmpty())
    check("Data Saver DISABLED (1) / khong ro (-1) -> KHONG bao", MonitorLogic.envIssues(ok.copy(restrictBackgroundStatus = 1)).isEmpty() && MonitorLogic.envIssues(ok.copy(restrictBackgroundStatus = -1)).isEmpty())
    check("VPN -> VPN_ACTIVE", MonitorLogic.envIssues(ok.copy(vpnActive = true)) == listOf(MonitorLogic.EnvIssue.VPN_ACTIVE))
    check("roaming + dang dung mang di dong -> ROAMING", MonitorLogic.envIssues(ok.copy(roaming = true, onCellular = true)) == listOf(MonitorLogic.EnvIssue.ROAMING))
    check("roaming nhung dang dung WiFi -> KHONG bao (khong ton cuoc)", MonitorLogic.envIssues(ok.copy(roaming = true, onCellular = false)).isEmpty())
    check("standby RARE (40) va RESTRICTED (45) -> STANDBY_RESTRICTED", MonitorLogic.envIssues(ok.copy(standbyBucket = 40)).size == 1 && MonitorLogic.envIssues(ok.copy(standbyBucket = 45)).size == 1)
    check("standby ACTIVE/WORKING_SET/FREQUENT (10/20/30) va khong ro (-1) -> KHONG bao",
        listOf(10, 20, 30, -1).all { MonitorLogic.envIssues(ok.copy(standbyBucket = it)).isEmpty() })
    check("pin <= 5% va KHONG sac -> BATTERY_CRITICAL", MonitorLogic.envIssues(ok.copy(batteryPct = 5)) == listOf(MonitorLogic.EnvIssue.BATTERY_CRITICAL))
    check("pin 6% -> chua bao (ranh gioi), pin 0% van bao", MonitorLogic.envIssues(ok.copy(batteryPct = 6)).isEmpty() && MonitorLogic.envIssues(ok.copy(batteryPct = 0)).size == 1)
    check("pin thap nhung DANG SAC -> KHONG bao", MonitorLogic.envIssues(ok.copy(batteryPct = 3, charging = true)).isEmpty())
    check("pin khong doc duoc (-1) -> KHONG bao dong gia", MonitorLogic.envIssues(ok.copy(batteryPct = -1)).isEmpty())
    check("nhieu van de cung luc -> bao du theo thu tu khai bao",
        MonitorLogic.envIssues(MonitorLogic.EnvSnapshot(3, true, true, true, 45, 2, false)) ==
            listOf(MonitorLogic.EnvIssue.DATA_SAVER, MonitorLogic.EnvIssue.VPN_ACTIVE, MonitorLogic.EnvIssue.ROAMING, MonitorLogic.EnvIssue.STANDBY_RESTRICTED, MonitorLogic.EnvIssue.BATTERY_CRITICAL))
    val day = 24L * 3600 * 1000
    check("chua tung bao -> bao", MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.VPN_ACTIVE, 0L, day))
    check("VPN: vua bao hom qua -> CHUA bao lai (cooldown 7 ngay)", !MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.VPN_ACTIVE, day, 2 * day))
    check("VPN: sau 7 ngay -> bao lai", MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.VPN_ACTIVE, day, 8 * day))
    check("ROAMING cooldown 24h (tien that): 23h chua, 25h co", !MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.ROAMING, 1000L, 1000L + 23 * 3600_000L) && MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.ROAMING, 1000L, 1000L + 25 * 3600_000L))
    check("BATTERY_CRITICAL cooldown 6h: 5h chua, 7h co", !MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.BATTERY_CRITICAL, 1000L, 1000L + 5 * 3600_000L) && MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.BATTERY_CRITICAL, 1000L, 1000L + 7 * 3600_000L))
    check("moi van de cooldown rieng: bao VPN khong chan bao ROAMING", MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.ROAMING, 0L, day))
    // ---- H4: uptime ----
    val now0 = 1_800_000_000L
    check("uptime: chua co mau -> percent null (khong bao 100% khi chua co du lieu)", MonitorLogic.uptimeStats(emptyList(), now0, 86400).percent == null)
    check("uptime: chua co du lieu -> dong chu hop ly", MonitorLogic.formatUptimeLine("24 gio", MonitorLogic.UptimeStats(0, 0)) == "24 gio: chua co du lieu")
    check("uptime: 95/96 -> 99.0% (lam tron 1 so)", MonitorLogic.formatUptimeLine("24 gio", MonitorLogic.UptimeStats(96, 95)) == "24 gio: 99.0% (95/96 lan kiem tra)")
    check("uptime: 2/3 -> 66.7%", MonitorLogic.formatUptimeLine("7 ngay", MonitorLogic.UptimeStats(3, 2)).startsWith("7 ngay: 66.7%"))
    val csv = "1799990000,1\nrac\n1799990900,0\n,1\n1799991800,2\n1799991800,1\n  1799992700 , 1  \n"
    val parsed = MonitorLogic.parseUptimeCsv(csv)
    check("parse: bo dong hong (khong dau phay, rong, co 2, thieu epoch), giu dong hop le + dong co khoang trang", parsed.size == 4 && parsed[1].up == false && parsed[3].tsSec == 1799992700L)
    check("format -> parse khu hoi", MonitorLogic.parseUptimeCsv(MonitorLogic.formatUptimeCsv(parsed)) == parsed)
    val st = MonitorLogic.uptimeStats(parsed, 1799993000L, 3600L)
    check("cua so 1 gio: dem du 4 mau, 3 len", st.samples == 4 && st.upCount == 3)
    check("cua so hep 1000s chi con mau gan nhat", MonitorLogic.uptimeStats(parsed, 1799993000L, 1000L).samples == 1)
    check("mau tuong lai (dong ho chinh lui) bi bo khoi thong ke", MonitorLogic.uptimeStats(parsed, 1799991000L, 99999L).samples == 2)
    val appended = MonitorLogic.appendUptimeSample(parsed, 1799993600L, false)
    check("append: them o cuoi", appended.size == 5 && appended.last() == MonitorLogic.UptimeSample(1799993600L, false))
    val aged = MonitorLogic.appendUptimeSample(parsed, 1799990000L + 40L * 86400, true)
    check("append: mau cu hon 30 ngay bi cat, chi con mau moi", aged.size == 1 && aged[0].up)
    val skew = MonitorLogic.appendUptimeSample(parsed, 1799991000L, true)
    check("append: dong ho lui - mau tuong lai bi bo", skew.size == 3 && skew.all { it.tsSec <= 1799991000L })
    val many = (1..50).map { MonitorLogic.UptimeSample(1799000000L + it, true) }
    val capped = MonitorLogic.appendUptimeSample(many, 1799000100L, false, maxSamples = 10)
    check("append: gioi han so mau, giu cac mau MOI NHAT", capped.size == 10 && capped.last().up == false && capped.first().tsSec == 1799000042L)
    check("hang so: giu 30 ngay, toi da 4000 mau", MonitorLogic.UPTIME_KEEP_SEC == 2_592_000L && MonitorLogic.UPTIME_MAX_SAMPLES == 4000)
    // ---- T2: JSON canh bao webhook ----
    check("jsonEscape: nhay kep + gach cheo + xuong dong + tab", MonitorLogic.jsonEscape("a\"b\\c\nd\te") == "a\\\"b\\\\c\\nd\\te")
    check("jsonEscape: ky tu dieu khien 0x01 -> \\u0001", MonitorLogic.jsonEscape("x\u0001y") == "x\\u0001y")
    check("jsonEscape: tieng Viet + emoji giu nguyen", MonitorLogic.jsonEscape("Kh\u00f4ng ph\u1ea3n h\u1ed3i \uD83D\uDE00") == "Kh\u00f4ng ph\u1ea3n h\u1ed3i \uD83D\uDE00")
    check("buildAlertJson: khung co dinh", MonitorLogic.buildAlertJson("site_down", "hi", 1760000000L) == "{\"app\":\"wp-pocket-server\",\"event\":\"site_down\",\"ts\":1760000000,\"text\":\"hi\"}")
    check("buildAlertJson: su kien la -> unknown (khong gui chuoi tuy y vao truong event)", MonitorLogic.buildAlertJson("<script>", "x", 1L).contains("\"event\":\"unknown\""))
    check("buildAlertJson: chen nhay kep/ngoac vao text khong pha cau truc JSON (text bi escape nguyen ven)", MonitorLogic.buildAlertJson("backup_failed", "\"}, \"event\":\"hack", 1L) == """{"app":"wp-pocket-server","event":"backup_failed","ts":1,"text":"\"}, \"event\":\"hack"}""")
    val longText = "a".repeat(2000)
    check("buildAlertJson: text dai bi cat 1000 ky tu", MonitorLogic.buildAlertJson("backup_ok", longText, 1L).length == MonitorLogic.buildAlertJson("backup_ok", "a".repeat(1000), 1L).length)
    val cutPair = "a".repeat(999) + "\uD83D\uDE00"
    check("buildAlertJson: cat giua cap thay the (emoji) thi bo nua cap, khong de lai ky tu mo coi", !MonitorLogic.buildAlertJson("backup_ok", cutPair, 1L).contains("\uD83D"))
    // ---- AJ2/AJ3: nhiet do pin ----
    check("temp: 36.5 / 0.0 / -30.0 / 150.0 la hop le; 150.1, TEMP_UNKNOWN, rac lon la khong doc duoc",
        MonitorLogic.batteryTempKnown(365) && MonitorLogic.batteryTempKnown(0) && MonitorLogic.batteryTempKnown(-300) && MonitorLogic.batteryTempKnown(1500) &&
            !MonitorLogic.batteryTempKnown(1501) && !MonitorLogic.batteryTempKnown(MonitorLogic.TEMP_UNKNOWN) && !MonitorLogic.batteryTempKnown(99999))
    check("temp: nguong warm 40.0 (399 khong, 400 co) va hot 45.0 (449 khong, 450 co)",
        !MonitorLogic.isWarm(399) && MonitorLogic.isWarm(400) && !MonitorLogic.isHot(449) && MonitorLogic.isHot(450) && MonitorLogic.isWarm(450))
    check("temp: khong doc duoc thi KHONG bao nong (khong bao dong gia)", !MonitorLogic.isWarm(MonitorLogic.TEMP_UNKNOWN) && !MonitorLogic.isHot(MonitorLogic.TEMP_UNKNOWN))
    check("formatTempC: 365 -> 36.5, 400 -> 40.0, 5 -> 0.5, -35 -> -3.5, khong ro -> ?",
        MonitorLogic.formatTempC(365) == "36.5" && MonitorLogic.formatTempC(400) == "40.0" && MonitorLogic.formatTempC(5) == "0.5" &&
            MonitorLogic.formatTempC(-35) == "-3.5" && MonitorLogic.formatTempC(MonitorLogic.TEMP_UNKNOWN) == "?")
    val snapCool = MonitorLogic.EnvSnapshot(1, false, false, false, 10, 80, true)
    check("envIssues: snapshot cu (7 tham so, khong nhiet do) khong sinh van de nhiet do", MonitorLogic.envIssues(snapCool).isEmpty())
    check("envIssues: 41.0 C -> chi DEVICE_WARM", MonitorLogic.envIssues(snapCool.copy(batteryTempTenthsC = 410)) == listOf(MonitorLogic.EnvIssue.DEVICE_WARM))
    check("envIssues: 45.0 C -> chi DEVICE_HOT (khong bao them WARM)", MonitorLogic.envIssues(snapCool.copy(batteryTempTenthsC = 450)) == listOf(MonitorLogic.EnvIssue.DEVICE_HOT))
    check("envIssues: 39.9 C -> khong bao gi", MonitorLogic.envIssues(snapCool.copy(batteryTempTenthsC = 399)).isEmpty())
    check("envIssues: pin gan can + nong -> BATTERY_CRITICAL roi DEVICE_HOT (dung thu tu khai bao)",
        MonitorLogic.envIssues(snapCool.copy(batteryPct = 3, charging = false, batteryTempTenthsC = 470)) == listOf(MonitorLogic.EnvIssue.BATTERY_CRITICAL, MonitorLogic.EnvIssue.DEVICE_HOT))
    check("cooldown: DEVICE_HOT nhac lai sau 30 phut, DEVICE_WARM sau 2 gio",
        !MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.DEVICE_HOT, 1_000L, 1_000L + 29 * 60_000L) && MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.DEVICE_HOT, 1_000L, 1_000L + 30 * 60_000L) &&
            !MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.DEVICE_WARM, 1_000L, 1_000L + 119 * 60_000L) && MonitorLogic.shouldAlertEnv(MonitorLogic.EnvIssue.DEVICE_WARM, 1_000L, 1_000L + 120 * 60_000L))
    check("wantDeferHeavyJobs: nong thi hoan ke ca khi dang sac va chua bat tuy chon; khong nong giu hanh vi cu",
        MonitorLogic.wantDeferHeavyJobs(false, true, true) && MonitorLogic.wantDeferHeavyJobs(true, false) && !MonitorLogic.wantDeferHeavyJobs(true, true) &&
            !MonitorLogic.wantDeferHeavyJobs(false, false) && MonitorLogic.wantDeferHeavyJobs(true, false, false))
    check("shouldDeferBackupForHeat: nong thi hoan toi da 3 lan lien tiep roi van chay; khong nong khong hoan",
        MonitorLogic.shouldDeferBackupForHeat(true, 0) && MonitorLogic.shouldDeferBackupForHeat(true, 2) && !MonitorLogic.shouldDeferBackupForHeat(true, 3) &&
            !MonitorLogic.shouldDeferBackupForHeat(false, 0) && MonitorLogic.shouldDeferBackupForHeat(true, 5, maxDeferrals = 9))
    // ---- Su kien bao mat (HANDOFF.md muc 1br): scanSecurityEvents / shouldAlertSecurity ----
    val sec = listOf(
        "2026-10-30 10:00:00 ip=- PHAT HIEN MA DOC/THAY DOI LA (critical): wp-content/uploads/a.php [php-trong-uploads]",
        "2026-10-30 10:00:01 ip=45.1.2.3 TAI KHOAN QUAN TRI MOI: hacker (id 9)",
        "2026-10-30 10:00:02 ip=45.1.2.3 QUYEN QUAN TRI DUOC CAP CHO: editor1 (id 2)",
        "2026-10-30 10:00:03 ip=45.1.2.3 EMAIL QUAN TRI DA DOI: b***@example.com -> a***@evil.io",
        "2026-10-30 10:00:04 ip=45.1.2.3 PLUGIN VUA DUOC KICH HOAT: seo-booster/seo-booster.php",
        "2026-10-30 10:00:05 ip=62.1.1.1 DANG NHAP QUAN TRI TU MANG MOI: admin (id 1)",
        "2026-10-30 10:00:06 ip=45.2.2.2 TAM KHOA DANG NHAP tai khoan id:1 (qua nhieu lan sai tu nhieu mang) ~15 phut",
        "2026-10-30 10:00:07 ip=203.0.113.9 IP bi tu dong chan 1 gio (lan thu 1, 12.0 diem; do-duong-dan-nhay-cam)",
        "dong rac khong co ip",
        "2026-10-30 10:00:08 ip=1.1.1.1 su kien la khong thuoc nhom nao"
    )
    val ss = MonitorLogic.scanSecurityEvents(sec)
    check("su kien bao mat: 4 nghiem trong, 3 luu y, 1 IP bi chan; dong rac/su kien la bi bo qua", ss.urgent == 4 && ss.notices == 3 && ss.autoBans == 1)
    check("mau dai dien: toi da 3, nghiem trong truoc", ss.samples.size == 3 && ss.samples[0].startsWith("PHAT HIEN MA DOC") && ss.samples.none { it.startsWith("PLUGIN") })
    check("co nghiem trong -> bao", MonitorLogic.shouldAlertSecurity(ss))
    check("chi co luu y (plugin kich hoat) -> bao", MonitorLogic.shouldAlertSecurity(MonitorLogic.scanSecurityEvents(listOf(sec[4]))))
    check("chi 1-19 IP bi tu dong chan (ngay thuong co ke quet) -> KHONG bao", !MonitorLogic.shouldAlertSecurity(MonitorLogic.scanSecurityEvents(List(19) { sec[7] })))
    check("tu 20 IP bi chan trong 1 dot -> bao (dot tan cong lon)", MonitorLogic.shouldAlertSecurity(MonitorLogic.scanSecurityEvents(List(20) { sec[7] })))
    check("khong co gi -> khong bao", !MonitorLogic.shouldAlertSecurity(MonitorLogic.scanSecurityEvents(emptyList())))
    val inj = MonitorLogic.scanSecurityEvents(listOf("2026-10-30 10:00:00 ip=1.2.3.4 TAI KHOAN QUAN TRI MOI: x\u0007\u001b[31m" + "A".repeat(500)))
    check("noi dung do ke tan cong dieu khien: ky tu dieu khien bi loai, cat <= 140 ky tu", inj.samples.size == 1 && inj.samples[0].none { it < ' ' } && inj.samples[0].length <= 140)
    // ---- 2FA WordPress (mu-plugin hai buoc, 1br-H): moi su kien PHP ghi ra phai duoc phan loai dung ----
    val tf = MonitorLogic.scanSecurityEvents(listOf(
        "2026-10-30 11:00:00 ip=45.1.2.3 2FA KHONG DOC DUOC bi mat cua admin (doi muoi AUTH_KEY? sua meta?) - dang nhap tai khoan nay tam KHONG can ma",
        "2026-10-30 11:00:01 ip=45.1.2.3 2FA BI DAT LAI: boss (boi quan tri hacker)",
        "2026-10-30 11:00:02 ip=62.1.1.1 2FA DA BAT: boss",
        "2026-10-30 11:00:03 ip=62.1.1.1 2FA DA TAT: boss (chinh nguoi dung, co ma)",
        "2026-10-30 11:00:04 ip=62.1.1.1 2FA MA KHOI PHUC DA DUNG: boss (con 7 ma)",
        "2026-10-30 11:00:05 ip=62.1.1.1 2FA MA KHOI PHUC DA TAO LAI: boss"))
    check("su kien 2FA: 2 nghiem trong (khong doc duoc bi mat, bi dat lai) + 4 luu y (bat/tat/ma khoi phuc dung/tao lai)", tf.urgent == 2 && tf.notices == 4 && tf.autoBans == 0)
    check("su kien 2FA nghiem trong len dau mau dai dien", tf.samples.size == 3 && tf.samples[0].startsWith("2FA KHONG DOC DUOC") && tf.samples[1].startsWith("2FA BI DAT LAI"))
    check("chi mot su kien 2FA DA BAT -> van bao (ke chiem phien co the bat 2FA de khoa chu site)", MonitorLogic.shouldAlertSecurity(MonitorLogic.scanSecurityEvents(listOf("2026-10-30 11:00:02 ip=62.1.1.1 2FA DA BAT: boss"))))
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
