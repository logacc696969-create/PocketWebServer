import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ban Java SAT NGUYEN BAN cua AlertRules.kt + AlertThresholds.kt (HANDOFF.md muc 1bq-B). Chay: java AlertRulesPort.java
 * In "pass=N fail=M"; thoat 0 neu fail=0. scripts/tests/alert-rules-test.py doi chieu van ban Kotlin <-> Java va chay file nay.
 */
public class AlertRulesPort {

    // ------------------------------------------------------------- AlertThresholds
    static final int DISK_MIN = 50, DISK_MAX = 99, DISK_DEFAULT = 85;
    static final int BATT_CRIT_MIN = 1, BATT_CRIT_MAX = 30, BATT_CRIT_DEFAULT = 5;
    static final int WARM_MIN = 30, WARM_MAX = 55, WARM_DEFAULT = 40;
    static final int HOT_MIN = 35, HOT_MAX = 65, HOT_DEFAULT = 45;

    record Values(int diskPct, int batteryCriticalPct, int warmC, int hotC) {
        int warmTenths() { return warmC * 10; }
        int hotTenths() { return hotC * 10; }
    }

    static int clamp(int v, int min, int max) { return v < min ? min : (v > max ? max : v); }

    static Values sanitize(int disk, int battCritical, int warmC, int hotC) {
        int d = clamp(disk, DISK_MIN, DISK_MAX);
        int b = clamp(battCritical, BATT_CRIT_MIN, BATT_CRIT_MAX);
        int w = clamp(warmC, WARM_MIN, WARM_MAX);
        int h = clamp(hotC, HOT_MIN, HOT_MAX);
        if (h <= w) h = Math.min(HOT_MAX, w + 1);
        return new Values(d, b, w, h);
    }

    static Integer parseField(String raw, int min, int max) {
        if (raw == null) return null;
        String t = raw.trim();
        if (t.isEmpty() || t.length() > 3) return null;
        for (int i = 0; i < t.length(); i++) { char c = t.charAt(i); if (c < '0' || c > '9') return null; }
        int v = Integer.parseInt(t);
        return (v >= min && v <= max) ? v : null;
    }

    // ------------------------------------------------------------- AlertRules
    static final int MAX_RULES = 20, MAX_TEXT_CHARS = 4000, DEFAULT_COOLDOWN_MIN = 60, MIN_COOLDOWN_MIN = 15, MAX_COOLDOWN_MIN = 10080, MAX_FOR_MIN = 1440;

    enum Metric {
        DISK_PERCENT("disk_percent", 0.0, 100.0), BATTERY_PERCENT("battery_percent", 0.0, 100.0), BATTERY_TEMP_C("battery_temp_c", -20.0, 100.0),
        RAM_PERCENT("ram_percent", 0.0, 100.0), LOAD_AVG_1M("load_avg_1m", 0.0, 64.0), DATA_MONTH_MB("data_month_mb", 0.0, 10000000.0);
        final String key; final double min, max;
        Metric(String k, double mn, double mx) { key = k; min = mn; max = mx; }
        static Metric byKey(String k) { for (Metric m : values()) if (m.key.equals(k)) return m; return null; }
    }

    enum Op {
        GT(">"), GE(">="), LT("<"), LE("<=");
        final String symbol;
        Op(String s) { symbol = s; }
        boolean test(double v, double t) {
            switch (this) { case GT: return v > t; case GE: return v >= t; case LT: return v < t; default: return v <= t; }
        }
        static Op bySymbol(String s) { for (Op o : values()) if (o.symbol.equals(s)) return o; return null; }
    }

    record Rule(String name, Metric metric, Op op, double threshold, int forMinutes, int cooldownMinutes) {}

    enum ErrorCode { BAD_FORMAT, BAD_NAME, DUP_NAME, UNKNOWN_METRIC, BAD_OP, BAD_NUMBER, OUT_OF_RANGE, BAD_DURATION, DURATION_RANGE, TOO_MANY, TOO_LONG, UNKNOWN_WORD }

    record ParseError(int line, ErrorCode code, String detail) {}
    record ParseResult(List<Rule> rules, List<ParseError> errors) {}

    static final Pattern NAME_RE = Pattern.compile("[a-z0-9_]{1,32}");
    static final Pattern LINE_RE = Pattern.compile("^([^:\\s]*)\\s*:\\s*([A-Za-z0-9_]+)\\s*([<>=]{1,2})\\s*(\\S+)\\s*(.*)$");
    static final Pattern NUMBER_RE = Pattern.compile("-?[0-9]+(\\.[0-9]+)?");
    static final Pattern DUR_RE = Pattern.compile("([0-9]{1,5})([mhd])");

    static ParseResult parse(String text) {
        List<Rule> rules = new ArrayList<>();
        List<ParseError> errors = new ArrayList<>();
        if (text.length() > MAX_TEXT_CHARS) {
            errors.add(new ParseError(0, ErrorCode.TOO_LONG, String.valueOf(MAX_TEXT_CHARS)));
            return new ParseResult(rules, errors);
        }
        Set<String> seen = new HashSet<>();
        int lineNo = 0;
        for (String raw : text.split("\n", -1)) {
            lineNo++;
            String body = raw.trim();
            int hash = body.indexOf('#');
            if (hash >= 0) body = body.substring(0, hash).trim();
            if (body.isEmpty()) continue;
            Matcher m = LINE_RE.matcher(body);
            if (!m.matches()) { errors.add(new ParseError(lineNo, ErrorCode.BAD_FORMAT, body)); continue; }
            String name = m.group(1), metricKey = m.group(2), opSym = m.group(3), numRaw = m.group(4), rest = m.group(5).trim();
            if (!NAME_RE.matcher(name).matches()) { errors.add(new ParseError(lineNo, ErrorCode.BAD_NAME, name)); continue; }
            if (!seen.add(name)) { errors.add(new ParseError(lineNo, ErrorCode.DUP_NAME, name)); continue; }
            Metric metric = Metric.byKey(metricKey);
            if (metric == null) { errors.add(new ParseError(lineNo, ErrorCode.UNKNOWN_METRIC, metricKey)); continue; }
            Op op = Op.bySymbol(opSym);
            if (op == null) { errors.add(new ParseError(lineNo, ErrorCode.BAD_OP, opSym)); continue; }
            if (!NUMBER_RE.matcher(numRaw).matches()) { errors.add(new ParseError(lineNo, ErrorCode.BAD_NUMBER, numRaw)); continue; }
            double value = Double.parseDouble(numRaw);
            if (value < metric.min || value > metric.max) {
                errors.add(new ParseError(lineNo, ErrorCode.OUT_OF_RANGE, formatNumber(metric.min) + ".." + formatNumber(metric.max)));
                continue;
            }
            int forMin = 0, coolMin = DEFAULT_COOLDOWN_MIN;
            boolean sawFor = false, sawCool = false, bad = false;
            if (!rest.isEmpty()) {
                String[] toks = rest.split("\\s+");
                int i = 0;
                while (i < toks.length) {
                    String word = toks[i];
                    if (!word.equals("for") && !word.equals("cooldown")) { errors.add(new ParseError(lineNo, ErrorCode.UNKNOWN_WORD, word)); bad = true; break; }
                    if ((word.equals("for") && sawFor) || (word.equals("cooldown") && sawCool)) { errors.add(new ParseError(lineNo, ErrorCode.BAD_FORMAT, word)); bad = true; break; }
                    if (i + 1 >= toks.length) { errors.add(new ParseError(lineNo, ErrorCode.BAD_DURATION, word)); bad = true; break; }
                    Matcher d = DUR_RE.matcher(toks[i + 1]);
                    if (!d.matches()) { errors.add(new ParseError(lineNo, ErrorCode.BAD_DURATION, toks[i + 1])); bad = true; break; }
                    int n = Integer.parseInt(d.group(1));
                    String unit = d.group(2);
                    int minutes = unit.equals("m") ? n : (unit.equals("h") ? n * 60 : n * 1440);
                    if (word.equals("for")) {
                        if (minutes < 0 || minutes > MAX_FOR_MIN) { errors.add(new ParseError(lineNo, ErrorCode.DURATION_RANGE, "0.." + MAX_FOR_MIN + "m")); bad = true; break; }
                        forMin = minutes; sawFor = true;
                    } else {
                        if (minutes < MIN_COOLDOWN_MIN || minutes > MAX_COOLDOWN_MIN) { errors.add(new ParseError(lineNo, ErrorCode.DURATION_RANGE, MIN_COOLDOWN_MIN + ".." + MAX_COOLDOWN_MIN + "m")); bad = true; break; }
                        coolMin = minutes; sawCool = true;
                    }
                    i += 2;
                }
            }
            if (bad) continue;
            if (rules.size() >= MAX_RULES) { errors.add(new ParseError(lineNo, ErrorCode.TOO_MANY, String.valueOf(MAX_RULES))); continue; }
            rules.add(new Rule(name, metric, op, value, forMin, coolMin));
        }
        return new ParseResult(rules, errors);
    }

    record State(long firstTrueAtMs, long lastAlertAtMs) {}
    static final State EMPTY_STATE = new State(0L, 0L);
    record Eval(boolean fire, State state, long heldMinutes) {}

    static Eval evaluate(Rule rule, Double value, long nowMs, State st) {
        if (value == null || value.isNaN() || value.isInfinite()) return new Eval(false, new State(0L, st.lastAlertAtMs()), 0L);
        if (!rule.op().test(value, rule.threshold())) return new Eval(false, new State(0L, st.lastAlertAtMs()), 0L);
        long first = (st.firstTrueAtMs() >= 1L && st.firstTrueAtMs() <= nowMs) ? st.firstTrueAtMs() : nowMs;
        long held = (nowMs - first) / 60000L;
        boolean holdOk = held >= rule.forMinutes();
        long last = st.lastAlertAtMs();
        boolean coolOk = last <= 0L || nowMs < last || nowMs - last >= rule.cooldownMinutes() * 60000L;
        return new Eval(holdOk && coolOk, new State(first, last), held);
    }

    static State markAlerted(State st, long nowMs) { return new State(st.firstTrueAtMs(), nowMs); }
    static String encodeState(State st) { return st.firstTrueAtMs() + "," + st.lastAlertAtMs(); }

    static State decodeState(String raw) {
        if (raw == null) return EMPTY_STATE;
        String[] parts = raw.split(",", -1);
        if (parts.length != 2) return EMPTY_STATE;
        try {
            long a = Long.parseLong(parts[0].trim()), b = Long.parseLong(parts[1].trim());
            if (a < 0L || b < 0L) return EMPTY_STATE;
            return new State(a, b);
        } catch (NumberFormatException e) { return EMPTY_STATE; }
    }

    static Double parseLoadAvg(String text) {
        if (text == null) return null;
        String t = text.trim();
        if (t.isEmpty()) return null;
        String first = t.split("\\s+")[0];
        double v;
        try { v = Double.parseDouble(first); } catch (NumberFormatException e) { return null; }
        return (Double.isNaN(v) || Double.isInfinite(v) || v < 0.0) ? null : v;
    }

    static Double ramPercent(long totalBytes, long availBytes) {
        if (totalBytes <= 0L || availBytes < 0L || availBytes > totalBytes) return null;
        return (totalBytes - availBytes) * 100.0 / totalBytes;
    }

    static String formatNumber(double v) {
        long r = Math.round(v * 10.0);
        boolean neg = r < 0;
        long a = neg ? -r : r;
        String s = (a / 10) + "." + (a % 10);
        return neg ? "-" + s : s;
    }

    static String describe(Rule rule, double value, long heldMinutes) {
        return "quy tac canh bao '" + rule.name() + "': " + rule.metric().key + " = " + formatNumber(value)
            + " (dieu kien " + rule.op().symbol + " " + formatNumber(rule.threshold())
            + (rule.forMinutes() > 0 ? ", keo dai " + heldMinutes + " phut" : "") + ").";
    }

    // ------------------------------------------------------------- chay thu
    static int pass = 0, fail = 0;
    static void check(String name, boolean ok) { if (ok) { pass++; System.out.println("PASS: " + name); } else { fail++; System.out.println("FAIL: " + name); } }
    static ErrorCode firstErr(String text) { ParseResult r = parse(text); return r.errors().isEmpty() ? null : r.errors().get(0).code(); }
    static final long MIN = 60000L;

    public static void main(String[] a) {
        // ---- cu phap hop le
        ParseResult ok = parse("high_ram: ram_percent > 90 for 5m\n# ghi chu\n\ndisk_full: disk_percent >= 90 cooldown 24h\nhot: battery_temp_c>=47 for 1h cooldown 2h  # nong\nneg: battery_temp_c < -5\n");
        check("4 quy tac hop le, khong loi (gom dong trong, #, ghi chu cuoi dong, khong co dau cach quanh toan tu)", ok.rules().size() == 4 && ok.errors().isEmpty());
        Rule r0 = ok.rules().get(0), r1 = ok.rules().get(1), r2 = ok.rules().get(2), r3 = ok.rules().get(3);
        check("high_ram: ram_percent > 90, for 5m, cooldown mac dinh 60", r0.metric() == Metric.RAM_PERCENT && r0.op() == Op.GT && r0.threshold() == 90.0 && r0.forMinutes() == 5 && r0.cooldownMinutes() == 60);
        check("disk_full: >= 90, for 0, cooldown 24h = 1440 phut", r1.op() == Op.GE && r1.forMinutes() == 0 && r1.cooldownMinutes() == 1440);
        check("hot: for 1h = 60, cooldown 2h = 120, nhiet do 47", r2.forMinutes() == 60 && r2.cooldownMinutes() == 120 && r2.threshold() == 47.0);
        check("nguong am hop le cho nhiet do (-5)", r3.threshold() == -5.0 && r3.op() == Op.LT);
        check("CRLF (Windows/dan tu may khac) duoc chap nhan", parse("a: disk_percent > 80\r\nb: ram_percent > 80\r\n").rules().size() == 2);
        check("cooldown dung 1d = 1440; for 24h = 1440 (bien tren)", parse("a: disk_percent > 1 for 24h cooldown 1d").rules().size() == 1 && parse("a: disk_percent > 1 for 24h cooldown 1d").rules().get(0).cooldownMinutes() == 1440);
        check("thu tu 'cooldown' truoc 'for' van duoc", parse("a: disk_percent > 1 cooldown 30m for 10m").rules().get(0).forMinutes() == 10);
        // ---- moi ma loi + so dong
        check("thieu dau ':' -> BAD_FORMAT", firstErr("high_ram ram_percent > 90") == ErrorCode.BAD_FORMAT);
        check("ten HOA/ky tu la -> BAD_NAME", firstErr("High-RAM: ram_percent > 90") == ErrorCode.BAD_NAME && firstErr("A: ram_percent > 90") == ErrorCode.BAD_NAME);
        check("ten qua 32 ky tu -> BAD_NAME", firstErr("a".repeat(33) + ": ram_percent > 90") == ErrorCode.BAD_NAME && parse("a".repeat(32) + ": ram_percent > 90").rules().size() == 1);
        check("ten trung -> DUP_NAME (o dong 2)", parse("x: ram_percent > 90\nx: disk_percent > 90").errors().get(0).code() == ErrorCode.DUP_NAME && parse("x: ram_percent > 90\nx: disk_percent > 90").errors().get(0).line() == 2);
        check("chi so la -> UNKNOWN_METRIC (kem ten chi so)", firstErr("x: cpu_percent > 90") == ErrorCode.UNKNOWN_METRIC && parse("x: cpu_percent > 90").errors().get(0).detail().equals("cpu_percent"));
        check("toan tu '=' / '=>' / '==' -> BAD_OP", firstErr("x: ram_percent = 90") == ErrorCode.BAD_OP && firstErr("x: ram_percent => 90") == ErrorCode.BAD_OP && firstErr("x: ram_percent == 90") == ErrorCode.BAD_OP);
        check("so khong hop le -> BAD_NUMBER (90%, 9,5, 1e3, .5, 90.)", firstErr("x: ram_percent > 90%") == ErrorCode.BAD_NUMBER && firstErr("x: ram_percent > 9,5") == ErrorCode.BAD_NUMBER && firstErr("x: ram_percent > 1e3") == ErrorCode.BAD_NUMBER && firstErr("x: ram_percent > .5") == ErrorCode.BAD_NUMBER && firstErr("x: ram_percent > 90.") == ErrorCode.BAD_NUMBER);
        check("ngoai khoang cua chi so -> OUT_OF_RANGE (ram 101, load 65, nhiet do -21)", firstErr("x: ram_percent > 101") == ErrorCode.OUT_OF_RANGE && firstErr("x: load_avg_1m > 65") == ErrorCode.OUT_OF_RANGE && firstErr("x: battery_temp_c < -21") == ErrorCode.OUT_OF_RANGE && parse("x: load_avg_1m > 64").rules().size() == 1);
        check("thoi luong sai -> BAD_DURATION (5, 5s, m5, thieu gia tri)", firstErr("x: ram_percent > 9 for 5") == ErrorCode.BAD_DURATION && firstErr("x: ram_percent > 9 for 5s") == ErrorCode.BAD_DURATION && firstErr("x: ram_percent > 9 for m5") == ErrorCode.BAD_DURATION && firstErr("x: ram_percent > 9 for") == ErrorCode.BAD_DURATION);
        check("cooldown < 15m -> DURATION_RANGE; > 7d -> DURATION_RANGE; for > 24h -> DURATION_RANGE", firstErr("x: ram_percent > 9 cooldown 5m") == ErrorCode.DURATION_RANGE && firstErr("x: ram_percent > 9 cooldown 8d") == ErrorCode.DURATION_RANGE && firstErr("x: ram_percent > 9 for 25h") == ErrorCode.DURATION_RANGE && parse("x: ram_percent > 9 cooldown 15m").rules().size() == 1 && parse("x: ram_percent > 9 cooldown 7d").rules().size() == 1);
        check("tu la o cuoi dong -> UNKNOWN_WORD; lap 'for' hai lan -> BAD_FORMAT", firstErr("x: ram_percent > 9 then telegram") == ErrorCode.UNKNOWN_WORD && firstErr("x: ram_percent > 9 for 5m for 6m") == ErrorCode.BAD_FORMAT);
        // gioi han
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20; i++) sb.append("r").append(i).append(": disk_percent > 9\n");
        check("dung 20 quy tac OK", parse(sb.toString()).rules().size() == 20 && parse(sb.toString()).errors().isEmpty());
        sb.append("r20: disk_percent > 9\n");
        ParseResult over = parse(sb.toString());
        check("quy tac thu 21 -> TOO_MANY (o dong 21), 20 quy tac dau van duoc giu", over.rules().size() == 20 && over.errors().size() == 1 && over.errors().get(0).code() == ErrorCode.TOO_MANY && over.errors().get(0).line() == 21);
        ParseResult big = parse("# " + "x".repeat(MAX_TEXT_CHARS));
        check("van ban > 4000 ky tu -> TOO_LONG (dong 0), khong lay quy tac nao", big.rules().isEmpty() && big.errors().get(0).code() == ErrorCode.TOO_LONG && big.errors().get(0).line() == 0);
        ParseResult mixed = parse("good: disk_percent > 90\nbad line\nalso_good: ram_percent > 80");
        check("co dong loi thi cac dong hop le van duoc phan tich (loi bao dung dong 2)", mixed.rules().size() == 2 && mixed.errors().size() == 1 && mixed.errors().get(0).line() == 2);
        check("van ban rong -> khong quy tac, khong loi", parse("").rules().isEmpty() && parse("").errors().isEmpty());
        // ---- danh gia
        Rule rule = parse("high_ram: ram_percent > 90 for 5m cooldown 60m").rules().get(0);
        long t0 = 1_000_000_000_000L;
        Eval e = evaluate(rule, 50.0, t0, EMPTY_STATE);
        check("dieu kien sai -> khong bao, firstTrue = 0", !e.fire() && e.state().firstTrueAtMs() == 0L);
        e = evaluate(rule, 95.0, t0, EMPTY_STATE);
        check("lan DAU dung (for 5m) -> chua bao, ghi moc bat dau", !e.fire() && e.state().firstTrueAtMs() == t0);
        Eval e2 = evaluate(rule, 95.0, t0 + 15 * MIN, e.state());
        check("lan kiem tra sau 15 phut (>= for 5m) -> BAO", e2.fire() && e2.heldMinutes() == 15);
        State marked = markAlerted(e2.state(), t0 + 15 * MIN);
        Eval e3 = evaluate(rule, 96.0, t0 + 30 * MIN, marked);
        check("trong cooldown 60 phut -> khong bao lai", !e3.fire());
        Eval e4 = evaluate(rule, 96.0, t0 + 75 * MIN, marked);
        check("het cooldown (60 phut ke tu lan bao) -> bao lai", e4.fire());
        Eval e5 = evaluate(rule, 96.0, t0 + 30 * MIN, e2.state());
        check("gui Telegram THAT BAI (khong markAlerted) -> lan sau van con co hoi bao", e5.fire());
        Eval e6 = evaluate(rule, 70.0, t0 + 45 * MIN, marked);
        check("dieu kien het dung -> reset moc bat dau nhung GIU lastAlert (khong bao lien tuc khi dao dong quanh nguong)", !e6.fire() && e6.state().firstTrueAtMs() == 0L && e6.state().lastAlertAtMs() == marked.lastAlertAtMs());
        check("gia tri khong doc duoc (null/NaN/Infinity) khong bao gio gay canh bao va reset moc", !evaluate(rule, null, t0, e.state()).fire() && !evaluate(rule, Double.NaN, t0, e.state()).fire() && !evaluate(rule, Double.POSITIVE_INFINITY, t0, e.state()).fire() && evaluate(rule, null, t0, e.state()).state().firstTrueAtMs() == 0L);
        Eval cb = evaluate(rule, 95.0, t0, new State(t0 + 10_000_000L, 0L));
        check("dong ho chinh lui (moc bat dau o tuong lai) -> bat dau lai, khong bao nham", !cb.fire() && cb.state().firstTrueAtMs() == t0);
        check("lan bao cuoi o tuong lai (dong ho lui) -> coi nhu het cooldown, khong bi chan vo han", evaluate(parse("a: disk_percent > 1").rules().get(0), 50.0, t0, new State(0L, t0 + 999_999_999L)).fire());
        Rule immediate = parse("d: disk_percent >= 90").rules().get(0);
        check("quy tac khong co 'for' bao ngay lan dau dieu kien dung", evaluate(immediate, 90.0, t0, EMPTY_STATE).fire() && !evaluate(immediate, 89.9, t0, EMPTY_STATE).fire());
        Rule lt = parse("b: battery_percent < 20").rules().get(0);
        check("toan tu < / <= dung bien (20 khong < 20; 19.9 co)", !evaluate(lt, 20.0, t0, EMPTY_STATE).fire() && evaluate(lt, 19.9, t0, EMPTY_STATE).fire() && evaluate(parse("b: battery_percent <= 20").rules().get(0), 20.0, t0, EMPTY_STATE).fire());
        // ---- luu trang thai
        check("encode/decode trang thai khu hoi", decodeState(encodeState(new State(123L, 456L))).equals(new State(123L, 456L)));
        check("trang thai hong (null, '', 'x', '1', '1,2,3', '-1,5', 'a,b') -> EMPTY, khong nem loi", decodeState(null).equals(EMPTY_STATE) && decodeState("").equals(EMPTY_STATE) && decodeState("x").equals(EMPTY_STATE) && decodeState("1").equals(EMPTY_STATE) && decodeState("1,2,3").equals(EMPTY_STATE) && decodeState("-1,5").equals(EMPTY_STATE) && decodeState("a,b").equals(EMPTY_STATE));
        // ---- doc chi so
        check("loadavg: '0.52 0.58 0.59 1/345 12345' -> 0.52; hong -> null", parseLoadAvg("0.52 0.58 0.59 1/345 12345\n") == 0.52 && parseLoadAvg("") == null && parseLoadAvg(null) == null && parseLoadAvg("abc 1 2") == null && parseLoadAvg("-1 0 0") == null && parseLoadAvg("NaN 0 0") == null);
        check("ramPercent: 4GB tong, 1GB trong = 75%; so lieu vo ly -> null", ramPercent(4L << 30, 1L << 30) == 75.0 && ramPercent(0, 0) == null && ramPercent(100, 200) == null && ramPercent(100, -1) == null && ramPercent(100, 0) == 100.0);
        // ---- dinh dang
        check("formatNumber: 93.24 -> 93.2; -5 -> -5.0; 1e7 -> 10000000.0 (khong ky hieu khoa hoc); 0.05 -> 0.1", formatNumber(93.24).equals("93.2") && formatNumber(-5).equals("-5.0") && formatNumber(1e7).equals("10000000.0") && formatNumber(0.05).equals("0.1") && formatNumber(-0.04).equals("0.0"));
        check("describe co ten, chi so, gia tri, dieu kien, thoi gian giu", describe(rule, 93.24, 15).equals("quy tac canh bao 'high_ram': ram_percent = 93.2 (dieu kien > 90.0, keo dai 15 phut)."));
        check("describe bo 'keo dai' khi khong co 'for'", describe(immediate, 91.0, 0).equals("quy tac canh bao 'd': disk_percent = 91.0 (dieu kien >= 90.0)."));
        // ---- nguong
        Values def = new Values(DISK_DEFAULT, BATT_CRIT_DEFAULT, WARM_DEFAULT, HOT_DEFAULT);
        check("mac dinh = 85/5/40/45 (khop hang so cu trong ma)", def.equals(new Values(85, 5, 40, 45)) && def.warmTenths() == 400 && def.hotTenths() == 450);
        check("sanitize kep tung gia tri (dia 1 -> 50, 100 -> 99; pin 0 -> 1, 99 -> 30; nong 5 -> 30)", sanitize(1, 0, 5, 45).equals(new Values(50, 1, 30, 45)) && sanitize(100, 99, 99, 45).equals(new Values(99, 30, 55, 56)));
        check("qua nong luon > nong (nong 50, qua nong 40 -> 51); khong vuot HOT_MAX", sanitize(85, 5, 50, 40).hotC() == 51 && sanitize(85, 5, 55, 36).hotC() == 56 && sanitize(85, 5, 40, 45).equals(def));
        check("parseField: '85', ' 85 ' hop le; '', '8 5', '085'(<=3 chu so hop le), '1000', '-5', 'abc', null, chu so la-tinh/Arab -> null/hop le dung", parseField("85", 50, 99) == 85 && parseField(" 85 ", 50, 99) == 85 && parseField("", 50, 99) == null && parseField("8 5", 50, 99) == null && parseField("085", 50, 99) == 85 && parseField("1000", 50, 99) == null && parseField("-5", 1, 30) == null && parseField("abc", 1, 30) == null && parseField(null, 1, 30) == null && parseField("\u0668\u0665", 50, 99) == null && parseField("49", 50, 99) == null && parseField("99", 50, 99) == 99 && parseField("100", 50, 99) == null);
        System.out.println("pass=" + pass + " fail=" + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
