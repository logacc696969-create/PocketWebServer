import java.util.*;

/** Ban Java sat nguyen cua DbCheckLogic.kt (HANDOFF.md muc 1bp) voi dau ra MAU dung dinh dang MariaDB batch (-N -B). */
public class DbCheckPort {
    static String q(String s) { return "`" + s.replace("`", "``") + "`"; }
    static String checkSql(String db, List<String> t) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < t.size(); i += 100) { List<String> n = new ArrayList<>(); for (String x : t.subList(i, Math.min(i + 100, t.size()))) n.add(q(db) + "." + q(x)); sb.append("CHECK TABLE ").append(String.join(", ", n)).append(" QUICK;\n"); } return sb.toString(); }
    static int[] parse(String out, List<String> problems) {
        Map<String, List<String[]>> rows = new LinkedHashMap<>(); int parsed = 0;
        for (String raw : out.split("\n", -1)) { String[] c = raw.replace("\r", "").split("\t", -1); if (c.length < 4) continue; parsed++; rows.computeIfAbsent(c[0], k -> new ArrayList<>()).add(new String[]{c[2].toLowerCase(), c[3]}); }
        int ok = 0, skipped = 0;
        for (Map.Entry<String, List<String[]>> e : rows.entrySet()) {
            List<String[]> r = e.getValue(); boolean unsup = false, err = false, warn = false; String last = "";
            for (String[] x : r) { if (x[1].contains("doesn't support check")) unsup = true; if (x[0].equals("error")) err = true; if (x[0].equals("warning")) warn = true; if (x[0].equals("status")) last = x[1]; }
            if (unsup && !err) { skipped++; continue; }
            if (!err && !warn && (last.equals("OK") || last.equals("Table is already up to date"))) { ok++; continue; }
            List<String> msgs = new ArrayList<>(); for (String[] x : r) if (!x[0].equals("note") && !x[1].equals("OK") && !msgs.contains(x[1])) msgs.add(x[1]);
            problems.add(e.getKey() + ": " + (msgs.isEmpty() ? last : String.join("; ", msgs.subList(0, Math.min(2, msgs.size())))));
        }
        return new int[]{rows.size(), ok, skipped, parsed};
    }
    static int pass = 0, fail = 0;
    static void check(String n, boolean c) { if (c) { pass++; System.out.println("PASS: " + n); } else { fail++; System.out.println("FAIL: " + n); } }
    public static void main(String[] a) {
        String healthy = "wordpress.wp_options\tcheck\tstatus\tOK\nwordpress.wp_posts\tcheck\tstatus\tOK\nwordpress.wp_users\tcheck\tstatus\tOK\n";
        List<String> p = new ArrayList<>(); int[] r = parse(healthy, p);
        check("CSDL khoe: 3 bang OK, khong van de", r[0] == 3 && r[1] == 3 && p.isEmpty() && r[3] == 3);
        String bad = healthy + "wordpress.wp_old\tcheck\twarning\tTable is marked as crashed\nwordpress.wp_old\tcheck\terror\tFound 1 keys of 0\nwordpress.wp_old\tcheck\tstatus\tCorrupt\n";
        p = new ArrayList<>(); r = parse(bad, p);
        check("bang MyISAM hong (warning+error+Corrupt): 1 van de, 3 bang con lai OK", r[0] == 4 && r[1] == 3 && p.size() == 1 && p.get(0).startsWith("wordpress.wp_old: ") && p.get(0).contains("crashed"));
        p = new ArrayList<>(); r = parse("db.v\tcheck\tnote\tThe storage engine for the table doesn't support check\n" + healthy, p);
        check("bang khong ho tro check (note) -> BO QUA, khong bao la loi", r[2] == 1 && p.isEmpty() && r[1] == 3);
        p = new ArrayList<>(); r = parse("db.t\tcheck\tstatus\tTable is already up to date\n", p);
        check("'Table is already up to date' tinh la OK", r[1] == 1 && p.isEmpty());
        p = new ArrayList<>(); r = parse("db.t\tcheck\tstatus\tOperation failed\n", p);
        check("status khac OK (Operation failed) -> la van de", p.size() == 1 && p.get(0).contains("Operation failed"));
        p = new ArrayList<>(); r = parse("ERROR 2002 (HY000): Can't connect to local MySQL server\n\n", p);
        check("dong loi ket noi (khong co 4 cot) -> khong co dong nao parse duoc (runner coi la 'failed', khong bao OK gia)", r[3] == 0 && r[0] == 0);
        p = new ArrayList<>(); r = parse(healthy.replace("\n", "\r\n"), p);
        check("dau ra co CRLF van parse dung", r[1] == 3);
        String sql = checkSql("wordpress", Arrays.asList("wp_posts", "we`ird"));
        check("SQL: tach CSDL va bang bang dau ` , nhan doi dau ` trong ten, dung QUICK", sql.equals("CHECK TABLE `wordpress`.`wp_posts`, `wordpress`.`we``ird` QUICK;\n"));
        List<String> many = new ArrayList<>(); for (int i = 0; i < 250; i++) many.add("t" + i);
        check("250 bang -> 3 cau CHECK (moi cau <= 100 bang)", checkSql("d", many).split("\n").length == 3);
        System.out.println("\nTONG KET: pass=" + pass + " fail=" + fail); System.exit(fail > 0 ? 1 : 0);
    }
}
