import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** Ban Java sat nguyen cua FatalLogLogic.kt tren JDK that (RandomAccessFile that, xoay vong that) - HANDOFF.md muc 1bp. */
public class FatalLogPort {
    static final long MAX_READ = 256L * 1024L;
    static final Pattern MARK = Pattern.compile("PHP (Fatal error|Parse error):");
    static boolean isFatal(String l) { return MARK.matcher(l).find(); }
    static String classify(String l) {
        if (l.contains("Allowed memory size of")) return "memory";
        if (l.contains("Maximum execution time of")) return "timeout";
        if (l.contains("PHP Parse error:")) return "parse";
        if (l.contains("Uncaught")) return "uncaught";
        return "other";
    }
    static String after(String l) { int i = l.indexOf("] "); return i < 0 ? l : l.substring(i + 2); }
    static String sig(String l) { String s = after(l).replaceAll("[0-9]+", "#").trim(); return s.length() > 160 ? s.substring(0, 160) : s; }
    static class Group { String kind; int count; String sample; }
    static List<Group> scan(List<String> lines) {
        Map<String, Group> m = new LinkedHashMap<>();
        for (String l : lines) {
            if (!isFatal(l)) continue;
            String s = sig(l); Group g = m.get(s);
            if (g == null) { g = new Group(); g.kind = classify(l); g.count = 1; String smp = after(l).trim(); g.sample = smp.length() > 200 ? smp.substring(0, 200) : smp; m.put(s, g); } else g.count++;
        }
        return new ArrayList<>(m.values());
    }
    static Object[] readNew(File f, long from) throws IOException {
        if (!f.isFile()) return new Object[]{new ArrayList<String>(), 0L};
        long len = f.length(); long start = (from >= 0 && from <= len) ? from : 0L;
        if (len - start > MAX_READ) start = len - MAX_READ;
        if (len == start) return new Object[]{new ArrayList<String>(), len};
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            raf.seek(start); byte[] buf = new byte[(int) (len - start)]; raf.readFully(buf);
            return new Object[]{new ArrayList<>(Arrays.asList(new String(buf, "UTF-8").split("\n", -1))), len};
        }
    }
    @SuppressWarnings("unchecked") static List<String> lines(Object[] r) { return (List<String>) r[0]; }

    static int pass = 0, fail = 0;
    static void check(String n, boolean c) { if (c) { pass++; System.out.println("PASS: " + n); } else { fail++; System.out.println("FAIL: " + n); } }
    static void append(File f, String s) throws IOException { try (FileOutputStream o = new FileOutputStream(f, true)) { o.write(s.getBytes("UTF-8")); } }

    public static void main(String[] a) throws Exception {
        String TS = "[22-Oct-2026 10:15:03 Asia/Ho_Chi_Minh] ";
        List<String> log = Arrays.asList(
            TS + "PHP Warning:  Undefined variable $x in /data/www/a.php on line 5",
            TS + "PHP Fatal error:  Allowed memory size of 134217728 bytes exhausted (tried to allocate 262144 bytes) in /data/www/wp-includes/class-wp.php on line 100",
            "[22-Oct-2026 10:16:44 Asia/Ho_Chi_Minh] PHP Fatal error:  Allowed memory size of 134217728 bytes exhausted (tried to allocate 20480 bytes) in /data/www/wp-includes/class-wp.php on line 101",
            TS + "PHP Fatal error:  Maximum execution time of 60 seconds exceeded in /data/www/wp-content/plugins/slow/x.php on line 9",
            TS + "PHP Parse error:  syntax error, unexpected token \"}\" in /data/www/wp-content/themes/t/functions.php on line 33",
            TS + "PHP Fatal error:  Uncaught Error: Call to undefined function foo() in /data/www/p.php:12",
            "Stack trace:", "#0 {main}", "  thrown in /data/www/p.php on line 12",
            TS + "PHP Notice:  Trying to access array offset in /data/www/n.php on line 3");
        List<Group> g = scan(log);
        check("phan loai dung 4 loai tren dong log PHP that (memory, timeout, parse, uncaught)", g.size() == 4 && g.get(0).kind.equals("memory") && g.get(1).kind.equals("timeout") && g.get(2).kind.equals("parse") && g.get(3).kind.equals("uncaught"));
        check("2 loi memory khac so/thoi gian duoc GOM lam 1 nhom dem 2", g.get(0).count == 2);
        check("Warning/Notice/dong Stack trace khong bi tinh la fatal", g.stream().mapToInt(x -> x.count).sum() == 5);
        check("mau loi bo tien to thoi gian", !g.get(0).sample.startsWith("["));

        File tmp = Files.createTempDirectory("fatal").toFile(); File f = new File(tmp, "php-error.log");
        try {
            check("file chua co -> khong dong nao, offset 0", lines(readNew(f, 0)).isEmpty() && (Long) readNew(f, 0)[1] == 0L);
            append(f, TS + "PHP Fatal error:  Uncaught Error: A in /x.php:1\n");
            Object[] r1 = readNew(f, 0); long off1 = (Long) r1[1];
            check("doc lan dau: thay 1 fatal, offset = do dai file", scan(lines(r1)).size() == 1 && off1 == f.length());
            check("khong co gi moi -> khong doc lai (khong bao trung)", scan(lines(readNew(f, off1))).isEmpty());
            append(f, TS + "PHP Fatal error:  Maximum execution time of 30 seconds exceeded in /y.php on line 2\n");
            Object[] r2 = readNew(f, off1);
            check("chi doc phan MOI: chi thay loi timeout, khong lap lai loi cu", scan(lines(r2)).size() == 1 && scan(lines(r2)).get(0).kind.equals("timeout"));
            try (RandomAccessFile raf = new RandomAccessFile(f, "rw")) { raf.setLength(0); }   // file bi cat (rotate / don log khi day dia)
            append(f, TS + "PHP Parse error:  syntax error in /z.php on line 3\n");
            Object[] r3 = readNew(f, (Long) r2[1]);
            check("file bi cat/xoay vong (nho hon offset cu) -> doc lai tu dau, khong mat loi moi", scan(lines(r3)).size() == 1 && scan(lines(r3)).get(0).kind.equals("parse"));
            StringBuilder big = new StringBuilder(); for (int i = 0; i < 8000; i++) big.append(TS).append("PHP Notice:  filler line number ").append(i).append(" xxxxxxxxxxxxxxxxxxxx\n");
            Files.write(f.toPath(), big.toString().getBytes("UTF-8")); append(f, TS + "PHP Fatal error:  Uncaught Error: CUOI in /w.php:1\n");
            Object[] r4 = readNew(f, 0);
            check("file lon (> 256 KB): chi doc phan cuoi toi da 256 KB nhung van thay loi o CUOI file", f.length() > MAX_READ && scan(lines(r4)).size() == 1 && String.join("\n", lines(r4)).length() <= MAX_READ + 10);
        } finally { for (File x : tmp.listFiles()) x.delete(); tmp.delete(); }
        System.out.println("\nTONG KET: pass=" + pass + " fail=" + fail); System.exit(fail > 0 ? 1 : 0);
    }
}
