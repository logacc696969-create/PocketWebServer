import java.security.SecureRandom;
import java.util.*;

/** Ban Java sat nguyen cua ApiLogic.kt tren JDK that (SecureRandom that) - HANDOFF.md muc 1bp-L. In cac dong "JSON:" de Python phan tich bang json.loads. */
public class ApiLogicPort {
    static final String HEX = "0123456789abcdef";
    static String generateToken(SecureRandom r) { byte[] b = new byte[32]; r.nextBytes(b); StringBuilder sb = new StringBuilder(); for (byte x : b) { sb.append(HEX.charAt((x >> 4) & 0xF)); sb.append(HEX.charAt(x & 0xF)); } return sb.toString(); }
    static boolean isValidToken(String t) { if (t == null || t.length() < 32 || t.length() > 64) return false; for (char c : t.toCharArray()) if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false; return true; }
    static String jsonEscape(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) { if (c == '"') sb.append("\\\""); else if (c == '\\') sb.append("\\\\"); else if (c == '\n') sb.append("\\n"); else if (c == '\r') sb.append("\\r"); else if (c == '\t') sb.append("\\t"); else if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c); }
        return sb.toString();
    }
    static String build(long now, boolean running, int bat, boolean chg, int disk, long lastBk, int cnt, String ver) {
        StringBuilder sb = new StringBuilder("{\"schema\":\"wp-pocket-status/1\"");
        sb.append(",\"generated_at\":").append(now).append(",\"server_running\":").append(running ? "true" : "false");
        sb.append(",\"battery_pct\":").append(bat >= 0 && bat <= 100 ? String.valueOf(bat) : "null").append(",\"charging\":").append(chg ? "true" : "false");
        sb.append(",\"disk_used_pct\":").append(disk >= 0 && disk <= 100 ? String.valueOf(disk) : "null");
        sb.append(",\"last_backup_at\":").append(lastBk > 0 ? String.valueOf(lastBk) : "null").append(",\"backup_count\":").append(cnt >= 0 ? String.valueOf(cnt) : "0");
        return sb.append(",\"app_version\":\"").append(jsonEscape(ver)).append("\"}").toString();
    }
    static int pass = 0, fail = 0;
    static void check(String n, boolean c) { if (c) { pass++; System.out.println("PASS: " + n); } else { fail++; System.out.println("FAIL: " + n); } }
    public static void main(String[] a) {
        SecureRandom r = new SecureRandom(); Set<String> seen = new HashSet<>(); boolean allValid = true; for (int i = 0; i < 200; i++) { String t = generateToken(r); seen.add(t); allValid &= t.length() == 64 && isValidToken(t); }
        check("token SecureRandom: 200 token deu 64 ky tu hex hop le va KHONG trung nhau (256 bit)", allValid && seen.size() == 200);
        String t0 = generateToken(r); check("token khong chua ky tu nguy hiem cho cau hinh nginx/shell (chi 0-9a-f)", t0.matches("[0-9a-f]{64}"));
        check("isValidToken: bien 32/64 hop le, 31/65 khong", isValidToken("a".repeat(32)) && isValidToken("0".repeat(64)) && !isValidToken("a".repeat(31)) && !isValidToken("a".repeat(65)));
        check("isValidToken: chu hoa, ky tu la, dau nhay, $, ;, khoang trang, xuong dong, rong, null deu bi tu choi", !isValidToken("A".repeat(40)) && !isValidToken("g".repeat(40)) && !isValidToken("a".repeat(39) + "\"") && !isValidToken("a".repeat(39) + "$") && !isValidToken("a".repeat(39) + ";") && !isValidToken("a".repeat(39) + " ") && !isValidToken("a".repeat(39) + "\n") && !isValidToken("") && !isValidToken(null));
        check("jsonEscape: nhay kep, gach cheo, xuong dong, tab, ky tu dieu khien", "a\\\"b\\\\c\\nd\\te\\u0001".equals(jsonEscape("a\"b\\c\nd\te\u0001")));
        System.out.println("JSON:" + build(1_700_000_000L, true, 83, true, 41, 1_699_990_000L, 5, "1.2.3"));
        System.out.println("JSON:" + build(1_700_000_000L, false, -1, false, -1, 0, -1, "ver \"x\" \\ \n\t\u0002 tiếng Việt"));
        System.out.println("JSON:" + build(1_700_000_000L, true, 101, true, 100, -5, 0, ""));
        System.out.println("\nTONG KET: pass=" + pass + " fail=" + fail); System.exit(fail > 0 ? 1 : 0);
    }
}
