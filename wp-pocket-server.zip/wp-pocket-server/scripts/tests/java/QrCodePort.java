import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Ban Java SAT NGUYEN BAN cua app/src/main/java/com/wppocket/server/QrCode.kt (HANDOFF.md muc 1bq).
 * Chay: java QrCodePort.java selftest            -> kiem bang dung luong/vi tri can chinh theo gia tri chuan
 *       java QrCodePort.java caps                -> "phien_ban MUC dung_luong_byte" cho moi to hop
 *       java QrCodePort.java dump <tep.tsv>      -> moi dong "ECC<TAB>base64(bytes)" -> in "ECC version mask size hang/hang/..." (1 = module toi)
 * Ma duoc giai bang bo giai ma QR that (OpenCV) trong scripts/tests/qr-code-test.py.
 */
public class QrCodePort {

    enum Ecc {
        LOW(1), MEDIUM(0), QUARTILE(3), HIGH(2);
        final int formatBits;
        Ecc(int f) { formatBits = f; }
    }

    final int version;
    final Ecc ecc;
    final int size;
    private final boolean[][] modules;
    private final boolean[][] isFunction;
    int mask;

    private QrCodePort(int version, Ecc ecc, byte[] dataCodewords) {
        this.version = version;
        this.ecc = ecc;
        this.size = version * 4 + 17;
        this.modules = new boolean[size][size];
        this.isFunction = new boolean[size][size];
        drawFunctionPatterns();
        byte[] all = addEccAndInterleave(dataCodewords);
        drawCodewords(all);
        int best = 0;
        int bestPenalty = Integer.MAX_VALUE;
        for (int m = 0; m < 8; m++) {
            applyMask(m);
            drawFormatBits(m);
            int p = penaltyScore();
            if (p < bestPenalty) { best = m; bestPenalty = p; }
            applyMask(m);
        }
        mask = best;
        applyMask(best);
        drawFormatBits(best);
    }

    boolean isDark(int x, int y) { return x >= 0 && x < size && y >= 0 && y < size && modules[y][x]; }

    private void setFunction(int x, int y, boolean dark) { modules[y][x] = dark; isFunction[y][x] = true; }

    private void drawFunctionPatterns() {
        for (int i = 0; i < size; i++) { setFunction(6, i, i % 2 == 0); setFunction(i, 6, i % 2 == 0); }
        drawFinder(3, 3);
        drawFinder(size - 4, 3);
        drawFinder(3, size - 4);
        int[] align = alignmentPositions(version);
        int n = align.length;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (!((i == 0 && j == 0) || (i == 0 && j == n - 1) || (i == n - 1 && j == 0)))
                    drawAlignment(align[i], align[j]);
        drawFormatBits(0);
        drawVersion();
    }

    private void drawFinder(int cx, int cy) {
        for (int dy = -4; dy <= 4; dy++)
            for (int dx = -4; dx <= 4; dx++) {
                int dist = Math.max(Math.abs(dx), Math.abs(dy));
                int x = cx + dx, y = cy + dy;
                if (x >= 0 && x < size && y >= 0 && y < size) setFunction(x, y, dist != 2 && dist != 4);
            }
    }

    private void drawAlignment(int cx, int cy) {
        for (int dy = -2; dy <= 2; dy++)
            for (int dx = -2; dx <= 2; dx++)
                setFunction(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
    }

    private void drawFormatBits(int m) {
        int data = (ecc.formatBits << 3) | m;
        int rem = data;
        for (int i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
        int bits = ((data << 10) | rem) ^ 0x5412;
        for (int i = 0; i <= 5; i++) setFunction(8, i, getBit(bits, i));
        setFunction(8, 7, getBit(bits, 6));
        setFunction(8, 8, getBit(bits, 7));
        setFunction(7, 8, getBit(bits, 8));
        for (int i = 9; i < 15; i++) setFunction(14 - i, 8, getBit(bits, i));
        for (int i = 0; i < 8; i++) setFunction(size - 1 - i, 8, getBit(bits, i));
        for (int i = 8; i < 15; i++) setFunction(8, size - 15 + i, getBit(bits, i));
        setFunction(8, size - 8, true);
    }

    private void drawVersion() {
        if (version < 7) return;
        int rem = version;
        for (int i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
        int bits = (version << 12) | rem;
        for (int i = 0; i < 18; i++) {
            boolean dark = getBit(bits, i);
            int a = size - 11 + i % 3;
            int b = i / 3;
            setFunction(a, b, dark);
            setFunction(b, a, dark);
        }
    }

    private byte[] addEccAndInterleave(byte[] data) {
        int numBlocks = NUM_ERROR_CORRECTION_BLOCKS[ecc.ordinal()][version];
        int blockEccLen = ECC_CODEWORDS_PER_BLOCK[ecc.ordinal()][version];
        int rawCodewords = numRawDataModules(version) / 8;
        int numShortBlocks = numBlocks - rawCodewords % numBlocks;
        int shortBlockLen = rawCodewords / numBlocks;
        List<int[]> blocks = new ArrayList<>();
        int[] div = rsComputeDivisor(blockEccLen);
        int k = 0;
        for (int i = 0; i < numBlocks; i++) {
            int datLen = shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1);
            int[] dat = new int[datLen];
            for (int t = 0; t < datLen; t++) dat[t] = data[k + t] & 0xFF;
            k += datLen;
            int[] e = rsComputeRemainder(dat, div);
            int[] block = new int[shortBlockLen + 1];
            System.arraycopy(dat, 0, block, 0, datLen);
            System.arraycopy(e, 0, block, shortBlockLen + 1 - blockEccLen, blockEccLen);
            blocks.add(block);
        }
        byte[] result = new byte[rawCodewords];
        int r = 0;
        for (int i = 0; i < shortBlockLen + 1; i++)
            for (int j = 0; j < numBlocks; j++)
                if (i != shortBlockLen - blockEccLen || j >= numShortBlocks)
                    result[r++] = (byte) blocks.get(j)[i];
        return result;
    }

    private void drawCodewords(byte[] data) {
        int i = 0;
        for (int right = size - 1; right >= 1; right -= 2) {
            if (right == 6) right = 5;
            for (int vert = 0; vert < size; vert++) {
                for (int j = 0; j < 2; j++) {
                    int x = right - j;
                    boolean upward = ((right + 1) & 2) == 0;
                    int y = upward ? size - 1 - vert : vert;
                    if (!isFunction[y][x] && i < data.length * 8) {
                        modules[y][x] = getBit(data[i >>> 3] & 0xFF, 7 - (i & 7));
                        i++;
                    }
                }
            }
        }
    }

    private void applyMask(int m) {
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++) {
                boolean invert;
                switch (m) {
                    case 0: invert = (x + y) % 2 == 0; break;
                    case 1: invert = y % 2 == 0; break;
                    case 2: invert = x % 3 == 0; break;
                    case 3: invert = (x + y) % 3 == 0; break;
                    case 4: invert = (x / 3 + y / 2) % 2 == 0; break;
                    case 5: invert = x * y % 2 + x * y % 3 == 0; break;
                    case 6: invert = (x * y % 2 + x * y % 3) % 2 == 0; break;
                    default: invert = ((x + y) % 2 + x * y % 3) % 2 == 0; break;
                }
                if (!isFunction[y][x] && invert) modules[y][x] = !modules[y][x];
            }
    }

    private int penaltyScore() {
        int result = 0;
        for (int y = 0; y < size; y++) {
            int run = 1;
            for (int x = 1; x < size; x++) {
                if (modules[y][x] == modules[y][x - 1]) run++;
                else { if (run >= 5) result += run - 2; run = 1; }
            }
            if (run >= 5) result += run - 2;
        }
        for (int x = 0; x < size; x++) {
            int run = 1;
            for (int y = 1; y < size; y++) {
                if (modules[y][x] == modules[y - 1][x]) run++;
                else { if (run >= 5) result += run - 2; run = 1; }
            }
            if (run >= 5) result += run - 2;
        }
        for (int y = 0; y < size - 1; y++)
            for (int x = 0; x < size - 1; x++) {
                boolean c = modules[y][x];
                if (c == modules[y][x + 1] && c == modules[y + 1][x] && c == modules[y + 1][x + 1]) result += 3;
            }
        for (int y = 0; y < size; y++) {
            boolean[] line = new boolean[size];
            for (int t = 0; t < size; t++) line[t] = modules[y][t];
            result += finderLikePenalty(line);
        }
        for (int x = 0; x < size; x++) {
            boolean[] line = new boolean[size];
            for (int t = 0; t < size; t++) line[t] = modules[t][x];
            result += finderLikePenalty(line);
        }
        int dark = 0;
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) if (modules[y][x]) dark++;
        int total = size * size;
        int k = (Math.abs(dark * 20 - total * 10) + total - 1) / total - 1;
        result += k * 10;
        return result;
    }

    private static int finderLikePenalty(boolean[] line) {
        int result = 0;
        boolean[] pat = {true, false, true, true, true, false, true};
        for (int i = 0; i + 7 <= line.length; i++) {
            boolean match = true;
            for (int p = 0; p < 7; p++) if (line[i + p] != pat[p]) { match = false; break; }
            if (match) {
                boolean before = i >= 4;
                if (before) for (int p = 1; p <= 4; p++) if (line[i - p]) { before = false; break; }
                boolean after = i + 7 + 4 <= line.length;
                if (after) for (int p = 0; p < 4; p++) if (line[i + 7 + p]) { after = false; break; }
                if (before) result += 40;
                if (after) result += 40;
            }
        }
        return result;
    }

    static final int MIN_VERSION = 1, MAX_VERSION = 40;

    static final int[][] ECC_CODEWORDS_PER_BLOCK = {
        {-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
        {-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28},
        {-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
        {-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30}
    };
    static final int[][] NUM_ERROR_CORRECTION_BLOCKS = {
        {-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25},
        {-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49},
        {-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68},
        {-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81}
    };

    static QrCodePort encodeBytes(byte[] data, Ecc ecc, boolean boost) {
        int version = MIN_VERSION;
        int usedBits = 0;
        while (true) {
            int cap = numDataCodewords(version, ecc) * 8;
            int used = dataBits(data.length, version);
            if (used != -1 && used <= cap) { usedBits = used; break; }
            if (version >= MAX_VERSION) return null;
            version++;
        }
        Ecc e = ecc;
        if (boost) {
            for (Ecc cand : new Ecc[]{Ecc.MEDIUM, Ecc.QUARTILE, Ecc.HIGH})
                if (usedBits <= numDataCodewords(version, cand) * 8) e = cand;
        }
        int capBits = numDataCodewords(version, e) * 8;
        List<Integer> bits = new ArrayList<>();
        appendBits(bits, 0x4, 4);
        appendBits(bits, data.length, charCountBits(version));
        for (byte b : data) appendBits(bits, b & 0xFF, 8);
        appendBits(bits, 0, Math.min(4, capBits - bits.size()));
        appendBits(bits, 0, (8 - bits.size() % 8) % 8);
        int pad = 0xEC;
        while (bits.size() < capBits) { appendBits(bits, pad, 8); pad = pad ^ 0xEC ^ 0x11; }
        byte[] dataCodewords = new byte[bits.size() / 8];
        for (int i = 0; i < bits.size(); i++)
            if (bits.get(i) == 1) dataCodewords[i >>> 3] = (byte) (dataCodewords[i >>> 3] | (1 << (7 - (i & 7))));
        return new QrCodePort(version, e, dataCodewords);
    }

    static int byteCapacity(int version, Ecc ecc) {
        int bits = numDataCodewords(version, ecc) * 8 - 4 - charCountBits(version);
        int cap = bits / 8;
        int maxByCount = (1 << charCountBits(version)) - 1;
        return Math.min(cap, maxByCount);
    }

    static int charCountBits(int version) { return version <= 9 ? 8 : 16; }

    private static int dataBits(int len, int version) {
        int cc = charCountBits(version);
        if (len >= (1 << cc)) return -1;
        return 4 + cc + 8 * len;
    }

    private static void appendBits(List<Integer> bits, int value, int len) {
        for (int i = len - 1; i >= 0; i--) bits.add((value >>> i) & 1);
    }

    static int numRawDataModules(int ver) {
        int result = (16 * ver + 128) * ver + 64;
        if (ver >= 2) {
            int numAlign = ver / 7 + 2;
            result -= (25 * numAlign - 10) * numAlign - 55;
            if (ver >= 7) result -= 36;
        }
        return result;
    }

    static int numDataCodewords(int ver, Ecc ecc) {
        return numRawDataModules(ver) / 8 - ECC_CODEWORDS_PER_BLOCK[ecc.ordinal()][ver] * NUM_ERROR_CORRECTION_BLOCKS[ecc.ordinal()][ver];
    }

    static int[] alignmentPositions(int ver) {
        if (ver == 1) return new int[0];
        int numAlign = ver / 7 + 2;
        int step = ver == 32 ? 26 : ((ver * 4 + 4) + (numAlign * 2 - 2) - 1) / (numAlign * 2 - 2) * 2;
        int[] result = new int[numAlign];
        result[0] = 6;
        int pos = ver * 4 + 17 - 7;
        for (int i = numAlign - 1; i >= 1; i--) { result[i] = pos; pos -= step; }
        return result;
    }

    private static boolean getBit(int x, int i) { return ((x >>> i) & 1) != 0; }

    private static int rsMultiply(int x, int y) {
        int z = 0;
        for (int i = 7; i >= 0; i--) {
            z = (z << 1) ^ ((z >>> 7) * 0x11D);
            z ^= ((y >>> i) & 1) * x;
        }
        return z;
    }

    private static int[] rsComputeDivisor(int degree) {
        int[] result = new int[degree];
        result[degree - 1] = 1;
        int root = 1;
        for (int i = 0; i < degree; i++) {
            for (int j = 0; j < degree; j++) {
                result[j] = rsMultiply(result[j], root);
                if (j + 1 < degree) result[j] ^= result[j + 1];
            }
            root = rsMultiply(root, 0x02);
        }
        return result;
    }

    private static int[] rsComputeRemainder(int[] data, int[] divisor) {
        int[] result = new int[divisor.length];
        for (int b : data) {
            int factor = b ^ result[0];
            System.arraycopy(result, 1, result, 0, result.length - 1);
            result[result.length - 1] = 0;
            for (int i = 0; i < divisor.length; i++) result[i] ^= rsMultiply(divisor[i], factor);
        }
        return result;
    }

    // ------------------------------------------------------------------ chay thu

    static int pass = 0, fail = 0;
    static void check(String name, boolean ok) {
        if (ok) { pass++; System.out.println("PASS: " + name); }
        else { fail++; System.out.println("FAIL: " + name); }
    }

    public static void main(String[] args) throws Exception {
        if (args.length >= 1 && args[0].equals("dump")) {
            for (String line : Files.readAllLines(Paths.get(args[1]), StandardCharsets.UTF_8)) {
                if (line.isEmpty()) continue;
                String[] p = line.split("\t", -1);
                Ecc ecc = Ecc.valueOf(p[0]);
                byte[] data = Base64.getDecoder().decode(p[1]);
                boolean boost = p.length < 3 || !p[2].equals("noboost");
                QrCodePort q = encodeBytes(data, ecc, boost);
                if (q == null) { System.out.println("NULL"); continue; }
                StringBuilder sb = new StringBuilder();
                sb.append(q.ecc.name()).append(' ').append(q.version).append(' ').append(q.mask).append(' ').append(q.size).append(' ');
                for (int y = 0; y < q.size; y++) {
                    if (y > 0) sb.append('/');
                    for (int x = 0; x < q.size; x++) sb.append(q.isDark(x, y) ? '1' : '0');
                }
                System.out.println(sb);
            }
            return;
        }
        if (args.length >= 1 && args[0].equals("caps")) {
            for (int v = 1; v <= 40; v++)
                for (Ecc e : Ecc.values())
                    System.out.println(v + " " + e.name() + " " + byteCapacity(v, e));
            return;
        }
        // selftest: so ma tu DU LIEU chuan (ISO/IEC 18004 bang 7) cho cac phien ban/muc; dung luong byte = ma tu - 2 (v1-9) hoac - 3 (v10-40)
        int[][] known = {
            // version, L, M, Q, H (ma tu du lieu)
            {1, 19, 16, 13, 9}, {2, 34, 28, 22, 16}, {3, 55, 44, 34, 26}, {4, 80, 64, 48, 36}, {5, 108, 86, 62, 46},
            {6, 136, 108, 76, 60}, {7, 156, 124, 88, 66}, {8, 194, 154, 110, 86}, {9, 232, 182, 132, 100},
            {10, 274, 216, 154, 122}, {15, 523, 415, 295, 223}, {20, 861, 669, 485, 385},
            {27, 1468, 1128, 808, 628}, {30, 1735, 1373, 985, 745}, {40, 2956, 2334, 1666, 1276}
        };
        Ecc[] order = {Ecc.LOW, Ecc.MEDIUM, Ecc.QUARTILE, Ecc.HIGH};
        boolean capOk = true;
        for (int[] row : known)
            for (int e = 0; e < 4; e++) {
                int got = numDataCodewords(row[0], order[e]);
                if (got != row[1 + e]) { capOk = false; System.out.println("  lech ma tu du lieu v" + row[0] + " " + order[e] + ": " + got + " != " + row[1 + e]); }
                int wantBytes = row[1 + e] - (row[0] <= 9 ? 2 : 3);
                if (byteCapacity(row[0], order[e]) != wantBytes) { capOk = false; System.out.println("  lech dung luong byte v" + row[0] + " " + order[e]); }
            }
        check("ma tu du lieu + dung luong byte khop bang chuan (15 phien ban x 4 muc)", capOk);
        boolean align = java.util.Arrays.equals(alignmentPositions(2), new int[]{6, 18})
            && java.util.Arrays.equals(alignmentPositions(7), new int[]{6, 22, 38})
            && java.util.Arrays.equals(alignmentPositions(14), new int[]{6, 26, 46, 66})
            && java.util.Arrays.equals(alignmentPositions(32), new int[]{6, 34, 60, 86, 112, 138})
            && java.util.Arrays.equals(alignmentPositions(40), new int[]{6, 30, 58, 86, 114, 142, 170});
        check("vi tri mau can chinh khop bang chuan (v2, v7, v14, v32, v40)", align);
        boolean tooLong = encodeBytes(new byte[2954], Ecc.LOW, false) == null && encodeBytes(new byte[2953], Ecc.LOW, false) != null;
        check("2953 byte vua v40-L, 2954 byte -> null (khong nem loi)", tooLong);
        boolean sizes = true;
        for (int v = 1; v <= 40; v++) {
            int raw = numRawDataModules(v);
            for (Ecc e : order) {
                int blocks = NUM_ERROR_CORRECTION_BLOCKS[e.ordinal()][v];
                int ecl = ECC_CODEWORDS_PER_BLOCK[e.ordinal()][v];
                if ((raw / 8) < blocks * ecl || (raw / 8 - blocks * ecl) <= 0) sizes = false;
                // tong ma tu (du lieu + sua loi) phai chia hop le cho cac khoi
                if (numDataCodewords(v, e) + blocks * ecl != raw / 8) sizes = false;
            }
        }
        check("40 phien ban x 4 muc: tong ma tu du lieu + sua loi = ma tu tho", sizes);
        System.out.println("pass=" + pass + " fail=" + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
