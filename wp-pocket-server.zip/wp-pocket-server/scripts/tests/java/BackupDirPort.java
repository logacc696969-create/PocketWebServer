import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Predicate;

/** Ban Java sat nguyen cua BackupDirLogic.kt tren JDK that (tep that, mtime that) - HANDOFF.md muc 1bp-K. */
public class BackupDirPort {
    static boolean isBackupFile(String n) { return n.startsWith("backup-") && (n.endsWith(".zip") || n.endsWith(".zip.enc")); }
    static File pick(List<File> cands, boolean prefer, Predicate<File> removable, Predicate<File> usable) {
        List<File> present = new ArrayList<>(); for (File c : cands) if (c != null) present.add(c);
        if (prefer) for (File c : present) if (removable.test(c) && usable.test(c)) return c;
        return present.isEmpty() ? null : present.get(0);
    }
    static List<File> listAll(List<File> dirs) {
        List<File> all = new ArrayList<>();
        for (File d : dirs) { File[] fs = d.listFiles(); if (fs == null) continue; for (File f : fs) if (f.isFile() && isBackupFile(f.getName())) all.add(f); }
        all.sort((a, b) -> Long.compare(b.lastModified(), a.lastModified())); return all;
    }
    static List<File> excess(List<File> all, int keep) { List<File> s = new ArrayList<>(all); s.sort((a, b) -> Long.compare(b.lastModified(), a.lastModified())); return s.size() <= keep ? new ArrayList<>() : new ArrayList<>(s.subList(keep, s.size())); }

    static int pass = 0, fail = 0;
    static void check(String n, boolean c) { if (c) { pass++; System.out.println("PASS: " + n); } else { fail++; System.out.println("FAIL: " + n); } }
    static File mk(File dir, String name, long mtime) throws IOException { dir.mkdirs(); File f = new File(dir, name); Files.write(f.toPath(), new byte[]{1}); f.setLastModified(mtime); return f; }

    public static void main(String[] a) throws Exception {
        check("isBackupFile: nhan .zip va .zip.enc, tu choi .partial / ten khac / thu muc con", isBackupFile("backup-20261022-101500.zip") && isBackupFile("backup-x.zip.enc") && !isBackupFile("backup-x.zip.partial") && !isBackupFile("notes.zip") && !isBackupFile("backup-x.txt"));
        File prim = new File("/p/files"), sd = new File("/sd/files"), sd2 = new File("/sd2/files");
        Predicate<File> rem = f -> !f.equals(prim), ok = f -> true, bad = f -> false;
        check("mac dinh (khong bat tuy chon): LUON bo nho chinh du co the nho - hanh vi cu giu nguyen", prim.equals(pick(Arrays.asList(prim, sd), false, rem, ok)));
        check("bat tuy chon + the nho ghi duoc -> the nho", sd.equals(pick(Arrays.asList(prim, sd), true, rem, ok)));
        check("bat tuy chon + the nho KHONG ghi duoc (chi doc/chua mount) -> ve bo nho chinh, khong that bai", prim.equals(pick(Arrays.asList(prim, sd), true, rem, bad)));
        check("bat tuy chon + khong co the (chi 1 phan tu / phan tu 2 null) -> bo nho chinh", prim.equals(pick(Arrays.asList(prim), true, rem, ok)) && prim.equals(pick(Arrays.asList(prim, null), true, rem, ok)));
        check("nhieu the: chon the DAU TIEN ghi duoc", sd2.equals(pick(Arrays.asList(prim, sd, sd2), true, rem, f -> f.equals(sd2))));
        check("phan tu null o dau bo qua; tat ca null -> null (nguoi goi tu ve getExternalFilesDir)", sd.equals(pick(Arrays.asList(null, sd), false, rem, ok)) && pick(Arrays.asList(null, null), true, rem, ok) == null && pick(new ArrayList<File>(), false, rem, ok) == null);

        Path tmp = Files.createTempDirectory("bkdir"); File A = new File(tmp.toFile(), "primary/backups"), B = new File(tmp.toFile(), "sd/backups"); long t0 = 1_700_000_000_000L;
        try {
            mk(A, "backup-1.zip", t0 + 1000); mk(B, "backup-2.zip.enc", t0 + 2000); mk(A, "backup-3.zip", t0 + 3000); mk(B, "backup-4.zip", t0 + 4000);
            mk(A, "backup-5.zip", t0 + 5000); mk(B, "backup-6.zip", t0 + 6000); mk(A, "backup-7.zip.enc", t0 + 7000);
            mk(A, "backup-9.zip.partial", t0 + 9000); mk(B, "random.zip", t0 + 9500); new File(A, "backup-dir.zip").mkdirs();
            List<File> all = listAll(Arrays.asList(A, B));
            check("listAll gop CA HAI noi, chi tep backup hop le (bo .partial, ten la, thu muc), moi nhat truoc", all.size() == 7 && all.get(0).getName().equals("backup-7.zip.enc") && all.get(6).getName().equals("backup-1.zip"));
            check("listAll: thu muc khong ton tai (the nho bi rut) -> bo qua, khong nem loi", listAll(Arrays.asList(A, new File(tmp.toFile(), "khong-co"))).size() == 4);
            List<File> ex = excess(all, 5);
            check("excess: giu 5 moi nhat TINH TREN TAT CA noi -> xoa dung 2 ban cu nhat (1 o chinh, 1 o the nho)", ex.size() == 2 && ex.get(0).getName().equals("backup-2.zip.enc") && ex.get(1).getName().equals("backup-1.zip"));
            for (File f : ex) f.delete();
            List<File> after = listAll(Arrays.asList(A, B));
            check("sau khi xoa: con dung 5 ban moi nhat, ban .partial va ten la KHONG bi dong toi", after.size() == 5 && new File(A, "backup-9.zip.partial").exists() && new File(B, "random.zip").exists());
            check("excess khi it hon keep -> rong", excess(after, 5).isEmpty() && excess(new ArrayList<>(), 5).isEmpty());
        } finally {
            Files.walk(tmp).sorted(Comparator.reverseOrder()).forEach(p -> { try { Files.deleteIfExists(p); } catch (IOException e) {} });
        }
        System.out.println("\nTONG KET: pass=" + pass + " fail=" + fail); System.exit(fail > 0 ? 1 : 0);
    }
}
