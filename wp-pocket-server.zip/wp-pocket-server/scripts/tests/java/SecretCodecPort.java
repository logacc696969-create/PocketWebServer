import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Ban Java sat nguyen cua SecretCodec.kt chay tren JDK THAT (javax.crypto AES-GCM that) - HANDOFF.md muc 1bp-I. */
public class SecretCodecPort {
    static final String PREFIX = "enc1:"; static final int TAG_BITS = 128, IV_BYTES = 12;
    static boolean isSealed(String s) { return s != null && s.startsWith(PREFIX); }
    static String seal(SecretKey key, String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = c.getIV(); byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        byte[] out = new byte[iv.length + ct.length]; System.arraycopy(iv, 0, out, 0, iv.length); System.arraycopy(ct, 0, out, iv.length, ct.length);
        return PREFIX + Base64.getEncoder().encodeToString(out);
    }
    static String open(SecretKey key, String stored) {
        if (!isSealed(stored)) return stored;
        try {
            byte[] raw = Base64.getDecoder().decode(stored.substring(PREFIX.length()));
            if (raw.length < IV_BYTES + TAG_BITS / 8) return null;
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(TAG_BITS, raw, 0, IV_BYTES));
            return new String(c.doFinal(raw, IV_BYTES, raw.length - IV_BYTES), StandardCharsets.UTF_8);
        } catch (Exception e) { return null; }
    }
    static int pass = 0, fail = 0;
    static void check(String n, boolean c) { if (c) { pass++; System.out.println("PASS: " + n); } else { fail++; System.out.println("FAIL: " + n); } }
    static SecretKey newKey() throws Exception { KeyGenerator g = KeyGenerator.getInstance("AES"); g.init(256); return g.generateKey(); }

    public static void main(String[] a) throws Exception {
        SecretKey k = newKey(), other = newKey();
        String tg = "7123456789:AAH-xYz_exampleTELEGRAMtoken0123456789";
        String s = seal(k, tg);
        check("khu hoi: ma hoa roi giai ma ra DUNG token goc", tg.equals(open(k, s)));
        check("dinh dang: bat dau 'enc1:' va KHONG chua token dang ro", s.startsWith("enc1:") && !s.contains(tg) && !s.contains("AAH"));
        byte[] raw = Base64.getDecoder().decode(s.substring(5));
        check("do dai = IV 12 + ban ma + the GCM 16", raw.length == 12 + tg.getBytes(StandardCharsets.UTF_8).length + 16);
        check("moi lan ma hoa ra chuoi KHAC nhau (IV ngau nhien) nhung deu giai ma dung", !s.equals(seal(k, tg)) && tg.equals(open(k, seal(k, tg))));
        raw[20] ^= 1; String tampered = PREFIX + Base64.getEncoder().encodeToString(raw);
        check("bi sua 1 bit -> the GCM bat duoc, tra null (khong tra rac, khong nem loi)", open(k, tampered) == null);
        check("sai khoa (vd Keystore bi xoa/khoi phuc may) -> null, khong nem loi", open(other, s) == null);
        check("gia tri cu DANG RO duoc tra nguyen (tuong thich nguoc, di tru)", "plain-old-token".equals(open(k, "plain-old-token")) && open(k, "") != null && "".equals(open(k, "")));
        check("chuoi 'enc1:' hong dinh dang (Base64 loi / qua ngan) -> null", open(k, "enc1:!!!not-base64!!!") == null && open(k, "enc1:AAAA") == null && open(k, "enc1:") == null);
        String vn = "mật khẩu: tiếng Việt có dấu 🔐 \"quote\" \\ \n dòng 2";
        check("Unicode/ky tu dac biet (tieng Viet, emoji, xuong dong) di qua nguyen ven", vn.equals(open(k, seal(k, vn))));
        StringBuilder big = new StringBuilder(); for (int i = 0; i < 5000; i++) big.append("x");
        check("chuoi dai 5000 ky tu nguyen ven", big.toString().equals(open(k, seal(k, big.toString()))));
        check("isSealed: nhan dien dung, null an toan", isSealed(s) && !isSealed("abc") && !isSealed(null) && !isSealed("ENC1:x"));
        String h1 = seal(k, "https://hc-ping.com/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee");
        check("URL heartbeat/webhook cung duoc bao ve (khong lo duong dan/UUID trong chuoi luu)", !h1.contains("hc-ping") && !h1.contains("aaaaaaaa"));
        System.out.println("\nTONG KET: pass=" + pass + " fail=" + fail); System.exit(fail > 0 ? 1 : 0);
    }
}
