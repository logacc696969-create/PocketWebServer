/** Ban Java SAT NGUYEN BAN cua SkeletonLogic.kt (HANDOFF.md muc 1bq-I). Chay: java SkeletonLogicPort.java */
public class SkeletonLogicPort {
    static final long PERIOD_MS = 900L;
    static final float ALPHA_MIN = 0.35f;

    static boolean shouldAnimate(float animatorScale, boolean loading) {
        return loading && !Float.isNaN(animatorScale) && !Float.isInfinite(animatorScale) && animatorScale > 0f;
    }

    static int pass = 0, fail = 0;
    static void check(String n, boolean ok) { if (ok) { pass++; System.out.println("PASS: " + n); } else { fail++; System.out.println("FAIL: " + n); } }

    public static void main(String[] a) {
        check("dang tai + he thong cho hoat anh (scale 1.0) -> nhap nhay", shouldAnimate(1f, true));
        check("scale 0.5 / 10 (hoat anh cham/nhanh) van nhap nhay", shouldAnimate(0.5f, true) && shouldAnimate(10f, true));
        check("scale 0 ('Xoa hoat anh' cua he thong) -> KHONG nhap nhay", !shouldAnimate(0f, true));
        check("scale am / NaN / vo cuc -> KHONG nhap nhay (khong tin gia tri la)", !shouldAnimate(-1f, true) && !shouldAnimate(Float.NaN, true) && !shouldAnimate(Float.POSITIVE_INFINITY, true) && !shouldAnimate(Float.NEGATIVE_INFINITY, true));
        check("khong tai -> khong nhap nhay du he thong cho phep", !shouldAnimate(1f, false));
        check("hang so: chu ky 900 ms, alpha thap nhat 0.35 (con doc duoc, khong bien mat)", PERIOD_MS == 900L && ALPHA_MIN > 0.2f && ALPHA_MIN < 0.6f);
        System.out.println("pass=" + pass + " fail=" + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
