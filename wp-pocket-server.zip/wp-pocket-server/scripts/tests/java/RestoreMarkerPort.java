import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Ban Java SAT NGUYEN BAN cua RestoreMarker.kt (HANDOFF.md muc 1bq-E).
 *   java RestoreMarkerPort.java begin <dir> <ten> <nowMs>
 *   java RestoreMarkerPort.java hang  <dir> <ten> <nowMs>   # ghi dau danh dau roi NGU 120 giay (de test SIGKILL giua luc "khoi phuc")
 *   java RestoreMarkerPort.java read  <dir> <nowMs>         # in ABSENT | MARKER <ten> <startedAtMs> interrupted=<true|false>
 *   java RestoreMarkerPort.java finish <dir>
 *   java RestoreMarkerPort.java sanitize <ten>
 */
public class RestoreMarkerPort {
    static final String FILE_NAME = "restore-in-progress";
    static final long STALE_AFTER_MS = 15L * 60_000L;
    static final int MAX_NAME = 100;

    record Marker(String backupName, long startedAtMs) {}

    static File file(File dir) { return new File(dir, FILE_NAME); }
    static File tmpFile(File dir) { return new File(dir, FILE_NAME + ".tmp"); }

    static String sanitizeName(String name) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            if (sb.length() >= MAX_NAME) break;
            char c = name.charAt(i);
            sb.append(((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-') ? c : '_');
        }
        return sb.toString();
    }

    static boolean begin(File dir, String backupName, long nowMs) {
        try {
            File f = file(dir), tmp = tmpFile(dir);
            Files.write(tmp.toPath(), ("v1\n" + nowMs + "\n" + sanitizeName(backupName) + "\n").getBytes(StandardCharsets.UTF_8));
            if (!tmp.renameTo(f)) {
                f.delete();
                if (!tmp.renameTo(f)) { tmp.delete(); return false; }
            }
            return true;
        } catch (Exception e) { return false; }
    }

    static void finish(File dir) {
        try { file(dir).delete(); } catch (Exception ignored) { }
        try { tmpFile(dir).delete(); } catch (Exception ignored) { }
    }

    static Marker read(File dir) {
        File f = file(dir);
        if (!f.exists()) return null;
        try {
            String[] lines = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8).split("\n", -1);
            Long started = null;
            if (lines.length > 1) { try { started = Long.parseLong(lines[1].trim()); } catch (NumberFormatException e) { started = null; } }
            if (lines.length == 0 || !lines[0].equals("v1") || started == null || started < 0L) return new Marker("?", 0L);
            String name = lines.length > 2 ? lines[2].trim() : "";
            return new Marker(name.isEmpty() ? "?" : name, started);
        } catch (Exception e) { return new Marker("?", 0L); }
    }

    static boolean isInterrupted(Marker m, long nowMs) {
        if (m.startedAtMs() <= 0L) return true;
        if (nowMs < m.startedAtMs()) return false;
        return nowMs - m.startedAtMs() >= STALE_AFTER_MS;
    }

    static String describe(Marker m) {
        return "Lan khoi phuc truoc (" + m.backupName() + ") bi gian doan giua chung (tat app/mat dien/het pin?) - website co the dang o trang thai do dang "
            + "(mot so tep moi, mot so tep cu; co so du lieu co the chua duoc khoi phuc). Hay chay lai Khoi phuc tu CUNG ban backup do.";
    }

    public static void main(String[] a) throws Exception {
        switch (a[0]) {
            case "begin": System.out.println(begin(new File(a[1]), a[2], Long.parseLong(a[3]))); break;
            case "hang":
                System.out.println(begin(new File(a[1]), a[2], Long.parseLong(a[3])));
                System.out.flush();
                Thread.sleep(120_000);
                break;
            case "read": {
                Marker m = read(new File(a[1]));
                if (m == null) System.out.println("ABSENT");
                else System.out.println("MARKER " + m.backupName() + " " + m.startedAtMs() + " interrupted=" + isInterrupted(m, Long.parseLong(a[2])));
                break;
            }
            case "finish": finish(new File(a[1])); System.out.println("ok"); break;
            case "sanitize": System.out.println(sanitizeName(a.length > 1 ? a[1] : "")); break;
            case "describe": System.out.println(describe(new Marker(a[1], 1L))); break;
            default: System.exit(64);
        }
    }
}
