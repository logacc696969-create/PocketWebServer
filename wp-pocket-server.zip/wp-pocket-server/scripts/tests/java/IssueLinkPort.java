import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

/**
 * Ban Java SAT NGUYEN BAN cua IssueLink.kt (+ UpdateLogic.isValidRepo) (HANDOFF.md muc 1br). Chay: java IssueLinkPort.java <repo> <version> <device>
 * In URL hoac "NULL". scripts/tests/issue-link-test.py goi tren nhieu dau vao that va phan tich ket qua bang urllib.parse.
 */
public class IssueLinkPort {
    static final String TEMPLATE = "beta-report.yml", LABEL = "beta", TITLE_PREFIX = "[beta] ";
    static final int MAX_VALUE = 100;
    static final Pattern REPO = Pattern.compile("^[A-Za-z0-9._-]{1,100}/[A-Za-z0-9._-]{1,100}$");

    static boolean isValidRepo(String s) {
        if (s == null) return false;
        String t = s.trim();
        if (!REPO.matcher(t).matches()) return false;
        for (String part : t.split("/")) {
            boolean allDots = true;
            for (int i = 0; i < part.length(); i++) if (part.charAt(i) != '.') { allDots = false; break; }
            if (allDots) return false;
        }
        return true;
    }

    static String clean(String raw) {
        StringBuilder sb = new StringBuilder();
        boolean lastSpace = false;
        String s = raw == null ? "" : raw;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            char ch = Character.isISOControl(c) ? ' ' : c;
            if (ch == ' ') {
                if (!lastSpace && sb.length() > 0) sb.append(' ');
                lastSpace = true;
            } else {
                sb.append(ch);
                lastSpace = false;
            }
            if (sb.length() >= MAX_VALUE) break;
        }
        return sb.toString().trim();
    }

    static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    static String url(String repo, String version, String device) {
        if (!isValidRepo(repo)) return null;
        String[][] params = {{"template", TEMPLATE}, {"labels", LABEL}, {"title", TITLE_PREFIX}, {"version", clean(version)}, {"device", clean(device)}};
        StringBuilder sb = new StringBuilder("https://github.com/" + repo.trim() + "/issues/new?");
        for (int i = 0; i < params.length; i++) {
            if (i > 0) sb.append('&');
            sb.append(params[i][0]).append('=').append(enc(params[i][1]));
        }
        return sb.toString();
    }

    public static void main(String[] a) {
        String u = url(a.length > 0 ? a[0] : null, a.length > 1 ? a[1] : null, a.length > 2 ? a[2] : null);
        System.out.println(u == null ? "NULL" : u);
    }
}
