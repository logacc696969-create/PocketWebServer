import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.zip.*;

/** Ban Java SAT NGUYEN BAN cua UpdateMergeLogic.kt chay tren JDK THAT (java.nio, ZipInputStream, symlink that) - HANDOFF.md muc 1bp.
 *  Kotlin goi dung cac API nay nen hanh vi (walkFileTree khong theo symlink, canonicalPath, ZipInputStream) duoc kiem tren chinh JDK. */
public class UpdateMergePort {
    static final List<String> REPLACED_DIRS = Arrays.asList("_admin", "_supervisor", "mariadb-share", "wp-admin", "wp-includes");
    static final List<String> REGENERATED_FILES = Arrays.asList("wp-config.php");

    static String safeRelPath(String name) {
        if (name.indexOf('\u0000') >= 0) return null;
        if (name.startsWith("/")) return null;
        List<String> parts = new ArrayList<>();
        for (String seg : name.split("/", -1)) {
            if (seg.isEmpty() || seg.equals(".")) continue;
            if (seg.equals("..")) return null;
            parts.add(seg);
        }
        return String.join("/", parts);
    }

    static void deleteNoFollow(File target) throws IOException {
        Path root = target.toPath();
        if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) return;
        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            @Override public FileVisitResult visitFile(Path f, BasicFileAttributes a) { try { Files.deleteIfExists(f); } catch (IOException e) {} return FileVisitResult.CONTINUE; }
            @Override public FileVisitResult visitFileFailed(Path f, IOException e) { return FileVisitResult.CONTINUE; }
            @Override public FileVisitResult postVisitDirectory(Path d, IOException e) { try { Files.deleteIfExists(d); } catch (IOException x) {} return FileVisitResult.CONTINUE; }
        });
    }

    static void prepareForMerge(File docRoot) throws IOException {
        for (String d : REPLACED_DIRS) deleteNoFollow(new File(docRoot, d));
        for (String f : REGENERATED_FILES) deleteNoFollow(new File(docRoot, f));
    }

    static boolean isInside(String rootCanon, File f) {
        String c; try { c = f.getCanonicalPath(); } catch (IOException e) { return false; }
        return c.equals(rootCanon) || c.startsWith(rootCanon + File.separator);
    }

    static void ensureParentDirs(File targetDir, File parent) {
        String rel = targetDir.toPath().relativize(parent.toPath()).toString();
        File cur = targetDir;
        if (!rel.isEmpty()) for (String seg : rel.split(File.separator)) {
            if (seg.isEmpty()) continue;
            cur = new File(cur, seg);
            if (cur.exists() && !cur.isDirectory()) cur.delete();
        }
        parent.mkdirs();
    }

    /** returns {written, skippedLinks, skippedConflicts} */
    static int[] extractMerge(InputStream in, File targetDir) throws IOException {
        targetDir.mkdirs();
        String rootCanon = targetDir.getCanonicalPath();
        int written = 0, links = 0, conflicts = 0;
        try (ZipInputStream zis = new ZipInputStream(in)) {
            ZipEntry e = zis.getNextEntry();
            while (e != null) {
                String rel = safeRelPath(e.getName());
                if (rel == null) throw new IOException("Zip entry khong hop le (Zip Slip): " + e.getName());
                if (!rel.isEmpty()) {
                    File out = new File(targetDir, rel);
                    File parent = out.getParentFile() != null ? out.getParentFile() : targetDir;
                    if (!isInside(rootCanon, parent)) links++;
                    else if (e.isDirectory()) {
                        if (Files.isSymbolicLink(out.toPath())) links++;
                        else { if (out.exists() && !out.isDirectory()) out.delete(); out.mkdirs(); }
                    } else {
                        boolean skip = false;
                        if (Files.isSymbolicLink(out.toPath())) Files.delete(out.toPath());
                        else if (out.isDirectory()) { conflicts++; skip = true; }
                        if (!skip) {
                            ensureParentDirs(targetDir, parent);
                            try (FileOutputStream fos = new FileOutputStream(out)) { zis.transferTo(fos); }
                            written++;
                        }
                    }
                }
                zis.closeEntry();
                e = zis.getNextEntry();
            }
        }
        return new int[]{written, links, conflicts};
    }

    // ---------------- test ----------------
    static int pass = 0, fail = 0;
    static void check(String n, boolean c) { if (c) { pass++; System.out.println("PASS: " + n); } else { fail++; System.out.println("FAIL: " + n); } }
    static byte[] zipOf(Map<String, String> files, String... dirs) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bos)) {
            for (String d : dirs) { z.putNextEntry(new ZipEntry(d.endsWith("/") ? d : d + "/")); z.closeEntry(); }
            for (Map.Entry<String, String> en : files.entrySet()) { z.putNextEntry(new ZipEntry(en.getKey())); z.write(en.getValue().getBytes("UTF-8")); z.closeEntry(); }
        }
        return bos.toByteArray();
    }
    static void write(File base, String rel, String c) throws IOException { File f = new File(base, rel); f.getParentFile().mkdirs(); Files.write(f.toPath(), c.getBytes("UTF-8")); }
    static String read(File base, String rel) throws IOException { File f = new File(base, rel); return f.isFile() ? new String(Files.readAllBytes(f.toPath()), "UTF-8") : null; }
    static int[] merge(byte[] z, File d) throws IOException { return extractMerge(new ByteArrayInputStream(z), d); }
    static boolean exists(File f) { return Files.exists(f.toPath(), LinkOption.NOFOLLOW_LINKS); }

    public static void main(String[] a) throws Exception {
        File tmp = Files.createTempDirectory("updmerge-java").toFile();
        try {
            check("safeRelPath: chuan hoa va tu choi", "a/b".equals(safeRelPath("./a//b/")) && safeRelPath("a/../../x") == null && safeRelPath("/etc/passwd") == null && safeRelPath("a\u0000b") == null && "".equals(safeRelPath("./")));
            Map<String, String> bundle = new LinkedHashMap<>();
            bundle.put("index.php", "NEW-INDEX"); bundle.put("wp-config.php.template", "TEMPLATE-v2"); bundle.put("_admin/new-page.php", "ADMIN-NEW");
            bundle.put("_supervisor/start-lamp.sh", "START-v2"); bundle.put("mariadb-share/errmsg.sys", "ERR"); bundle.put("wp-includes/version.php", "6.9");
            bundle.put("wp-admin/index.php", "WPADMIN"); bundle.put("wp-content/plugins/bundled/b.php", "BUNDLED-v2"); bundle.put("wp-content/database/index.php", "SILENCE");
            byte[] zipNew = zipOf(bundle, "wp-content/cache");
            File d1 = new File(tmp, "fresh"); prepareForMerge(d1); int[] r1 = merge(zipNew, d1);
            boolean all = true; for (Map.Entry<String, String> en : bundle.entrySet()) all &= en.getValue().equals(read(d1, en.getKey()));
            check("cai moi: moi tep dung noi dung, khong bo qua gi", all && r1[0] == bundle.size() && r1[1] == 0 && r1[2] == 0);

            File d2 = new File(tmp, "upd");
            Map<String, String> user = new LinkedHashMap<>();
            user.put("wp-content/uploads/2026/10/anh.jpg", "JPEGDATA"); user.put("wp-content/plugins/my-plugin/x.php", "MYPLUGIN");
            user.put("wp-content/themes/my-theme/style.css", "MYTHEME"); user.put("wp-content/database/.ht.sqlite", "SQLITE-ALL-POSTS");
            user.put("wp-content/languages/vi.mo", "VI"); user.put("extra/readme.txt", "USER-ADDED");
            Map<String, String> stale = new LinkedHashMap<>();
            stale.put("_admin/old-page.php", "S"); stale.put("wp-includes/stale.php", "S"); stale.put("mariadb-share/old.sys", "S"); stale.put("_supervisor/old.sh", "S");
            for (Map.Entry<String, String> en : user.entrySet()) write(d2, en.getKey(), en.getValue());
            for (Map.Entry<String, String> en : stale.entrySet()) write(d2, en.getKey(), en.getValue());
            write(d2, "index.php", "OLD-INDEX"); write(d2, "wp-config.php", "OLD-CONFIG");
            prepareForMerge(d2); merge(zipNew, d2);
            boolean keep = true; for (Map.Entry<String, String> en : user.entrySet()) keep &= en.getValue().equals(read(d2, en.getKey()));
            check("cap nhat tren JDK that: uploads/plugin/theme/SQLite/languages/tep nguoi dung GIU NGUYEN", keep);
            boolean gone = true; for (String k : stale.keySet()) gone &= read(d2, k) == null;
            check("cap nhat: tep cu trong REPLACED_DIRS bi go, ma moi ghi de, wp-config.php xoa de sinh lai", gone && "ADMIN-NEW".equals(read(d2, "_admin/new-page.php")) && "NEW-INDEX".equals(read(d2, "index.php")) && read(d2, "wp-config.php") == null && "TEMPLATE-v2".equals(read(d2, "wp-config.php.template")));
            prepareForMerge(d2); merge(zipNew, d2);
            boolean keep2 = true; for (Map.Entry<String, String> en : user.entrySet()) keep2 &= en.getValue().equals(read(d2, en.getKey()));
            check("chay lai (idempotent): du lieu van nguyen", keep2 && "NEW-INDEX".equals(read(d2, "index.php")));

            boolean threw = false; File victim = new File(tmp, "evil.txt");
            try { merge(zipOf(Collections.singletonMap("../evil.txt", "x")), new File(tmp, "slip1")); } catch (IOException e) { threw = true; }
            check("Zip Slip tren ZipInputStream that: ../ bi tu choi, khong ghi ra ngoai", threw && !victim.exists());

            File d4 = new File(tmp, "sym"), outside = new File(tmp, "outside-cache"); outside.mkdirs(); write(outside, "keep.txt", "KEEP"); new File(d4, "wp-content").mkdirs();
            Files.createSymbolicLink(new File(d4, "wp-content/cache").toPath(), outside.toPath());
            prepareForMerge(d4);
            Map<String, String> sz = new LinkedHashMap<>(); sz.put("wp-content/cache/junk.txt", "J"); sz.put("wp-content/cache/sub/deep.txt", "D"); sz.put("ok.txt", "OK");
            int[] r4 = merge(zipOf(sz, "wp-content/cache"), d4);
            check("symlink cache -> ngoai: KHONG ghi xuyen link, link con, khong nem loi", !exists(new File(outside, "junk.txt")) && !exists(new File(outside, "sub")) && Files.isSymbolicLink(new File(d4, "wp-content/cache").toPath()) && "OK".equals(read(d4, "ok.txt")) && r4[1] >= 2 && "KEEP".equals(read(outside, "keep.txt")));

            File d5 = new File(tmp, "sym2"), out2 = new File(tmp, "outside-lib"); out2.mkdirs(); write(out2, "libz.so.1", "LIB"); new File(d5, "_supervisor/pyhome").mkdirs();
            Files.createSymbolicLink(new File(d5, "_supervisor/pyhome/lib-dynload").toPath(), out2.toPath());
            Files.createSymbolicLink(new File(d5, "wp-admin").toPath(), out2.toPath());
            prepareForMerge(d5);
            check("walkFileTree KHONG theo symlink: chi xoa link, noi dung dich con nguyen", "LIB".equals(read(out2, "libz.so.1")) && !exists(new File(d5, "_supervisor")) && !exists(new File(d5, "wp-admin")));

            File d6 = new File(tmp, "sym3"), out3 = new File(tmp, "outside-file"); write(out3, "secret.txt", "SECRET"); d6.mkdirs();
            Files.createSymbolicLink(new File(d6, "index.php").toPath(), new File(out3, "secret.txt").toPath());
            merge(zipOf(Collections.singletonMap("index.php", "BUNDLE-INDEX")), d6);
            check("tep goi trung ten symlink-toi-tep: thay bang tep that, dich khong bi ghi de", "BUNDLE-INDEX".equals(read(d6, "index.php")) && !Files.isSymbolicLink(new File(d6, "index.php").toPath()) && "SECRET".equals(read(out3, "secret.txt")));

            File d7 = new File(tmp, "conf"); write(d7, "foo/user-data.txt", "UDATA"); write(d7, "bar", "A-USER-FILE");
            Map<String, String> cz = new LinkedHashMap<>(); cz.put("foo", "FILE-NAMED-FOO"); cz.put("bar/baz.txt", "BAZ");
            int[] r7 = merge(zipOf(cz), d7);
            check("xung dot loai: giu thu muc nguoi dung; thu muc goi nhuong cho tep trung ten", r7[2] == 1 && "UDATA".equals(read(d7, "foo/user-data.txt")) && "BAZ".equals(read(d7, "bar/baz.txt")));

            // DOI CHUNG AM tren JDK that: xoa kieu cu (theo symlink) se pha noi dung dich
            File d8 = new File(tmp, "oldstyle"), out8 = new File(tmp, "outside-old"); out8.mkdirs(); write(out8, "precious.txt", "PRECIOUS"); d8.mkdirs();
            Files.createSymbolicLink(new File(d8, "link").toPath(), out8.toPath());
            try (java.util.stream.Stream<Path> w = Files.walk(d8.toPath(), FileVisitOption.FOLLOW_LINKS)) { w.sorted(Comparator.reverseOrder()).forEach(p -> { try { Files.deleteIfExists(p); } catch (IOException e) {} }); }
            check("DOI CHUNG AM: xoa kieu CU (di xuyen symlink) lam MAT tep o ngoai - nen UpdateMergeLogic dung walkFileTree khong theo symlink", !exists(new File(out8, "precious.txt")));
        } finally {
            Files.walkFileTree(tmp.toPath(), new SimpleFileVisitor<Path>() {
                @Override public FileVisitResult visitFile(Path f, BasicFileAttributes at) throws IOException { Files.deleteIfExists(f); return FileVisitResult.CONTINUE; }
                @Override public FileVisitResult postVisitDirectory(Path d, IOException e) throws IOException { Files.deleteIfExists(d); return FileVisitResult.CONTINUE; }
            });
        }
        System.out.println("\nTONG KET: pass=" + pass + " fail=" + fail);
        System.exit(fail > 0 ? 1 : 0);
    }
}
