import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;

/** Chung minh tren JDK THAT (HttpURLConnection + may chu HTTP that) hai khang dinh cua HANDOFF.md muc 1bo-F/1bp:
 *  (1) setFixedLengthStreamingMode(header+tep+footer) gui DUNG tung byte voi Content-Length dung, KHONG dem tep trong RAM;
 *  (2) DOI CHUNG AM: khong dat streaming -> HttpURLConnection dem ca than trong heap -> OutOfMemoryError voi tep lon.
 *  Chay: java UploadStreamingPort.java correct | stream <tep> | buffer <tep>   (stream/buffer chay voi -Xmx48m). */
public class UploadStreamingPort {
    // ---- ban Java sat nguyen cua UploadLogic.buildMultipart ----
    static String clean(String s) { return s.replace("\"", "'").replace("\r", " ").replace("\n", " "); }
    static byte[][] build(String boundary, List<String[]> fields, String fileField, String fileName, String ctype) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : fields) sb.append("--").append(boundary).append("\r\nContent-Disposition: form-data; name=\"").append(clean(f[0])).append("\"\r\n\r\n").append(f[1]).append("\r\n");
        sb.append("--").append(boundary).append("\r\nContent-Disposition: form-data; name=\"").append(clean(fileField)).append("\"; filename=\"").append(clean(fileName)).append("\"\r\nContent-Type: ").append(ctype).append("\r\n\r\n");
        return new byte[][]{sb.toString().getBytes(StandardCharsets.UTF_8), ("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8)};
    }

    static volatile long srvBytes; static volatile long srvCrc; static volatile String srvCL, srvTE; static volatile byte[] srvBody;

    static HttpServer startServer(boolean keepBody) throws IOException {
        HttpServer s = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0);
        s.createContext("/up", ex -> {
            srvCL = ex.getRequestHeaders().getFirst("Content-Length"); srvTE = ex.getRequestHeaders().getFirst("Transfer-Encoding");
            CRC32 crc = new CRC32(); long n = 0; byte[] buf = new byte[65536]; ByteArrayOutputStream keep = keepBody ? new ByteArrayOutputStream() : null;
            try (InputStream in = ex.getRequestBody()) { int r; while ((r = in.read(buf)) > 0) { crc.update(buf, 0, r); n += r; if (keep != null) keep.write(buf, 0, r); } }
            srvBytes = n; srvCrc = crc.getValue(); srvBody = keep == null ? null : keep.toByteArray();
            byte[] ok = "ok".getBytes(); ex.sendResponseHeaders(200, ok.length); ex.getResponseBody().write(ok); ex.close();
        });
        s.start(); return s;
    }

    static int send(HttpServer s, Path file, boolean streaming) throws Exception {
        String boundary = "----WPPocketBoundary" + System.currentTimeMillis();
        List<String[]> fields = new ArrayList<>(); fields.add(new String[]{"chat_id", "-100123"}); fields.add(new String[]{"caption", "Sao luu: tiếng Việt"});
        byte[][] body = build(boundary, fields, "document", file.getFileName().toString(), "application/zip");
        long total = body[0].length + Files.size(file) + body[1].length;
        HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:" + s.getAddress().getPort() + "/up").openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true);
        if (streaming) c.setFixedLengthStreamingMode(total);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (OutputStream out = c.getOutputStream()) { out.write(body[0]); try (InputStream in = Files.newInputStream(file)) { in.transferTo(out); } out.write(body[1]); }
        int code = c.getResponseCode(); c.disconnect();
        System.out.println("tong du kien=" + total + " may chu nhan=" + srvBytes + " Content-Length=" + srvCL + " Transfer-Encoding=" + srvTE + " http=" + code);
        return (code == 200 && srvBytes == total) ? 0 : 1;
    }

    public static void main(String[] a) throws Exception {
        String mode = a[0];
        if (mode.equals("correct")) {
            Path f = Files.createTempFile("up", ".zip"); byte[] data = new byte[3 * 1024 * 1024 + 123]; new Random(7).nextBytes(data);
            System.arraycopy("\r\n--BND--\r\nlooks-like-boundary".getBytes(), 0, data, 1000, 29); Files.write(f, data);
            HttpServer s = startServer(true); int rc = send(s, f, true); s.stop(0);
            String bd = srvBody == null ? "" : new String(srvBody, StandardCharsets.ISO_8859_1);
            byte[] head = build("X", Collections.emptyList(), "document", "n", "application/zip")[0];
            boolean fileIntact = false; int p = bd.indexOf("\r\n\r\n", bd.indexOf("filename=")); if (p > 0) { byte[] got = Arrays.copyOfRange(srvBody, p + 4, p + 4 + data.length); fileIntact = Arrays.equals(got, data); }
            boolean ok = rc == 0 && srvCL != null && srvTE == null && fileIntact && bd.contains("name=\"chat_id\"") && bd.endsWith("--\r\n");
            System.out.println(ok ? "PASS: streaming do dai co dinh: dung tung byte, co Content-Length, KHONG chunked, tep nhi phan nguyen ven" : "FAIL: correct");
            Files.deleteIfExists(f); System.exit(ok ? 0 : 1);
        }
        Path f = Paths.get(a[1]); HttpServer s = startServer(false);
        if (mode.equals("stream")) {
            int rc = send(s, f, true); s.stop(0);
            System.out.println(rc == 0 ? "PASS: gui tep lon bang streaming voi heap nho, khong het bo nho" : "FAIL: stream"); System.exit(rc);
        }
        try { send(s, f, false); s.stop(0); System.out.println("FAIL: ma CU lai khong het bo nho - doi chung am vo hieu"); System.exit(1); }
        catch (Throwable t) { Throwable r = t; while (r.getCause() != null) r = r.getCause(); boolean oom = (t instanceof OutOfMemoryError) || (r instanceof OutOfMemoryError); s.stop(0);
            System.out.println(oom ? "PASS: DOI CHUNG AM: khong dat streaming -> OutOfMemoryError (" + r.getClass().getSimpleName() + ") - dung la loi cu" : "FAIL: loi khac OOM: " + t); System.exit(oom ? 0 : 1); }
    }
}
