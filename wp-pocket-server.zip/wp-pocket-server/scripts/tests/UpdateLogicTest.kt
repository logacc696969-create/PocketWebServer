import com.wppocket.server.UpdateLogic

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }

fun main() {
    // ---- so sanh phien ban ----
    check("v0.2.0 moi hon 0.1.0", UpdateLogic.isNewer("v0.2.0", "0.1.0"))
    check("cung phien ban -> khong moi", !UpdateLogic.isNewer("v0.1.0", "0.1.0"))
    check("tag cu hon -> khong moi", !UpdateLogic.isNewer("v0.0.9", "0.1.0"))
    check("so 2 chu so: 1.10.0 > 1.9.0 (khong so sanh chuoi)", UpdateLogic.isNewer("1.10.0", "1.9.0") && !UpdateLogic.isNewer("1.9.0", "1.10.0"))
    check("do dai khac nhau: 1.0.1 > 1.0 ; 1.0.0 == 1.0", UpdateLogic.isNewer("1.0.1", "1.0") && !UpdateLogic.isNewer("1.0.0", "1.0") && !UpdateLogic.isNewer("1.0", "1.0.0"))
    check("pre-release cua CHINH phien ban dang chay khong moi hon ban on dinh; ban on dinh moi hon pre-release cua no", !UpdateLogic.isNewer("v1.2.3-beta", "1.2.3") && UpdateLogic.isNewer("1.2.3", "1.2.3-beta2") && UpdateLogic.isNewer("v1.2.4-rc1", "1.2.3"))
    check("hai pre-release: theo so (beta10 > beta2), theo ten (alpha < beta < rc), bang nhau -> khong moi",
        UpdateLogic.isNewer("1.0.0-beta2", "1.0.0-beta1") && UpdateLogic.isNewer("1.0.0-beta10", "1.0.0-beta2") && !UpdateLogic.isNewer("1.0.0-beta2", "1.0.0-beta10") &&
        UpdateLogic.isNewer("1.0.0-rc1", "1.0.0-beta9") && !UpdateLogic.isNewer("1.0.0-alpha1", "1.0.0-beta1") && !UpdateLogic.isNewer("1.0.0-beta1", "1.0.0-beta1"))
    check("metadata +build bi bo qua", !UpdateLogic.isNewer("1.2.3+5", "1.2.3") && !UpdateLogic.isNewer("1.2.3", "1.2.3+5"))
    check("chu hoa V cung duoc", UpdateLogic.isNewer("V2.0", "1.9"))
    check("khong doc duoc so -> KHONG bao nham ban moi", !UpdateLogic.isNewer("nightly", "0.1.0") && !UpdateLogic.isNewer("v1.0", "") && !UpdateLogic.isNewer("", "1.0"))
    check("so qua dai (>6 chu so, vd ngay thang) -> khong tran Int, khong bao nham", !UpdateLogic.isNewer("20261017123456", "0.1.0"))

    // ---- repo hop le ----
    check("repo hop le", UpdateLogic.isValidRepo("owner/repo") && UpdateLogic.isValidRepo(" my-org/wp.pocket_server ") && UpdateLogic.isValidRepo("o/r\n") && UpdateLogic.isValidRepo("a.b/c.d") && UpdateLogic.isValidRepo("..a/b"))
    check("repo khong hop le bi tu choi", listOf("", "owner", "a/b/c", "a b/c", "a/b?x=1", "../x", "a/../b", "a/b#f", "http://x/y", "a/b;rm", "./x", "x/..", "x/.").none { UpdateLogic.isValidRepo(it) } && !UpdateLogic.isValidRepo(null))

    // ---- URL ----
    check("URL API dung", UpdateLogic.latestApiUrl("o/r") == "https://api.github.com/repos/o/r/releases/latest")
    check("URL kenh beta dung (ke ca pre-release, ban moi nhat)", UpdateLogic.latestApiUrl("o/r", true) == "https://api.github.com/repos/o/r/releases?per_page=1" && UpdateLogic.latestApiUrl(" o/r ", false) == "https://api.github.com/repos/o/r/releases/latest")
    check("URL trang phat hanh dung", UpdateLogic.releasePageUrl("o/r", "v1.0.0") == "https://github.com/o/r/releases/tag/v1.0.0")

    // ---- doc tag_name ----
    val json = "{\"url\":\"x\",\"html_url\":\"https://github.com/o/r/releases/tag/v1.2.3\",\"tag_name\": \"v1.2.3\",\"name\":\"v1.2.3\"}"
    check("parseTag lay dung tag_name (co/khong khoang trang quanh dau hai cham)", UpdateLogic.parseTag(json) == "v1.2.3" && UpdateLogic.parseTag("{\"tag_name\":\"v9\"}") == "v9")
    check("JSON danh sach (kenh beta): lay tag dau tien", UpdateLogic.parseTag("[{\"tag_name\":\"v2.0.0-beta1\",\"prerelease\":true},{\"tag_name\":\"v1.0.0\"}]") == "v2.0.0-beta1")
    check("thieu tag_name -> null", UpdateLogic.parseTag("{\"message\":\"Not Found\"}") == null)
    check("tag chua ky tu la (chen duong dan/script) bi tu choi", UpdateLogic.parseTag("{\"tag_name\":\"v1/../../evil\"}") == null && UpdateLogic.parseTag("{\"tag_name\":\"v1 2\"}") == null && UpdateLogic.parseTag("{\"tag_name\":\"v1<script>\"}") == null)

    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
