#!/usr/bin/env python3
"""Kiem thu trang _admin/security.php (Trung tam bao mat, HANDOFF.md muc 1br) qua php -S THAT, dung chung khung voi admin-security-test.py
(cay _admin/ that, dang nhap that, CSRF that). Khong can nginx/WordPress/mang.

Trong tam: (1) MOI hanh dong ghi deu doi CSRF dung va chi hoat dong sau dang nhap; (2) huy chan/cach ly/khoi phuc/bo qua thuc su doi file dung;
(3) cach ly KHONG the dung de di chuyen file ngoai danh sach quet (wp-config.php, ../...); (4) ten file doc hai trong ket qua quet khong chen duoc HTML;
(5) cong tat chi nhan ten trong danh sach cho phep (khong the tao file tuy y trong lamp-run/); (6) trang khong loi khi lamp-run trong/hong.
"""
import importlib.util, json, os, re, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location('adminsec', os.path.join(HERE, 'admin-security-test.py'))
AS = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(AS)
TPL = AS.TPL
PASS = FAIL = 0


def check(name, cond, detail=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('PASS: ' + name)
    else:
        FAIL += 1
        print('FAIL: ' + name + (('  -> ' + str(detail)[:300]) if detail else ''))


def php_cli(*args):
    return subprocess.run(['php', '-d', 'date.timezone=UTC'] + [str(a) for a in args], capture_output=True, text=True)


def run_tests(port, app, run, www, adm, tmp):
    guard = os.path.join(TPL, 'security-guard.php')
    scan = os.path.join(TPL, 'security-scan.php')
    c = AS.Client(port, '10.2.2.2')
    check('dang nhap', c.login())
    anon_get = lambda path: AS.Client(port, '10.9.9.9').req('GET', path)

    def post(action, **fields):
        tok = c.token('security')
        data = {'action': action, 'csrf_token': tok}
        data.update(fields)
        return c.req('POST', '/_admin/security.php', data)

    def page():
        sc, body, _ = c.req('GET', '/_admin/security.php')
        return sc, body

    # ----- 0) Trang rong: lamp-run chua co gi -----
    sc, body = page()
    check('trang rong (chua co log/quet/ban): 200, khong Fatal/Warning, co cac muc chinh', sc == 200 and not AS.FATAL_RE.search(body) and not AS.WARN_RE.search(body)
          and 'Trung tam bao mat' in body and 'Chua co ket qua quet' in body and 'Khong co IP nao dang bi chan' in body, body[:200])
    check('trang rong: bao "Chua quet" va "Chua bat 2FA"', 'Chua quet ma doc' in body and 'Chua bat 2FA' in body)

    # ----- 1) IP bi chan: tao ban that bang guard -----
    ip1, ip2 = '203.0.113.50', '198.51.100.77'
    now = int(time.time())
    with open(os.path.join(run, 'nginx-security.log'), 'w') as f:
        for ip in (ip1, ip2):
            for p in ('/.env', '/.git/config', '/wp-config.php.bak', '/backup.sql', '/.aws/credentials', '/phpinfo.php'):
                f.write('%d.123 %s 404 GET "%s" "curl/8"\n' % (now - 5, ip, p))
    r = php_cli(guard, run)
    check('guard tao ban cho 2 IP (chuan bi du lieu)', r.returncode == 0 and os.path.exists(os.path.join(run, 'ban-list.conf')) and ip1 in open(os.path.join(run, 'ban-list.conf')).read(), (r.stdout, r.stderr))
    sc, body = page()
    check('trang liet ke 2 IP bi chan + ly do', ip1 in body and ip2 in body and 'Huy chan' in body, body[body.find('IP dang bi'):][:300])
    sc, _, _ = c.req('POST', '/_admin/security.php', {'action': 'unban', 'key': ip1})
    check('huy chan thieu CSRF: khong doi gi', ip1 in open(os.path.join(run, 'ban-list.conf')).read())
    sc, _, _ = c.req('POST', '/_admin/security.php', {'action': 'unban', 'key': ip1, 'csrf_token': 'a' * 64})
    check('huy chan CSRF sai: khong doi gi', ip1 in open(os.path.join(run, 'ban-list.conf')).read())
    if os.path.exists(os.path.join(run, 'ban-reload')):
        os.remove(os.path.join(run, 'ban-reload'))
    sc, body, _ = post('unban', key=ip1)
    lst = open(os.path.join(run, 'ban-list.conf')).read()
    check('huy chan: go khoi ban-list.conf + dat co ban-reload (supervisor HUP nginx)', ip1 not in lst and ip2 in lst and os.path.exists(os.path.join(run, 'ban-reload')) and 'Da huy chan' in body, (lst, body[:200]))
    sc, body, _ = post('unban', key='8.8.8.8')
    check('huy chan IP khong co trong danh sach: tu choi', 'khong con' in body.lower() or 'Muc chan khong con' in body, body[:200])
    sc, body, _ = post('unban', key='../../etc/passwd')
    check('huy chan khoa la (duong dan): tu choi, khong loi', 'Muc chan khong con' in body and not AS.FATAL_RE.search(body))

    # ----- 2) IP tin cay -----
    sc, body, _ = post('allow_save', entries="203.0.113.7\n198.51.100.0/24 # van phong\n2001:db8::/32")
    af = os.path.join(run, 'security-allow.txt')
    txt = open(af).read() if os.path.exists(af) else ''
    check('luu IP tin cay (IPv4, CIDR, IPv6/32) hop le', '203.0.113.7' in txt and '198.51.100.0/24' in txt and '2001:db8::/32' in txt and 'Da luu 3' in body, (txt, body[:200]))
    sc, body, _ = post('allow_save', entries="1.2.3.4\nkhong-phai-ip\n300.1.1.1\n10.0.0.0/33")
    check('IP tin cay co dong sai: tu choi het, KHONG ghi de file cu', 'khong phai IP/CIDR hop le' in body.lower() or 'Dong khong phai IP' in body, body[:200])
    check('... file cu giu nguyen', open(af).read() == txt)
    sc, body, _ = post('allow_save', entries="<script>alert(1)</script>")
    check('IP tin cay chua HTML: tu choi + thong bao loi duoc escape', '<script>alert(1)' not in body, body[:200])
    sc, body, _ = post('allow_save', entries="")
    check('luu danh sach rong: xoa file', not os.path.exists(af))

    # ----- 3) Quet: tao site co file nguy hiem -----
    up = os.path.join(www, 'wp-content', 'uploads', '2026')
    os.makedirs(up, exist_ok=True)
    open(os.path.join(up, 'cache.php'), 'w').write("<?php echo 1;\n")
    evil = '<img src=x onerror=alert(1)>.php'
    open(os.path.join(up, evil), 'w').write("<?php echo 2;\n")
    open(os.path.join(www, 'wp-content', 'plugins', 'shell.php'), 'w').write("<?php @eval(base64_decode($_POST['x']));\n")
    r = php_cli(scan, www, run)
    check('quet bang CLI (chuan bi du lieu): thoat 0', r.returncode == 0 and 'nghiem trong' in r.stdout, (r.stdout, r.stderr))
    sc, body = page()
    check('trang hien phat hien: php-trong-uploads, nghi-web-shell, co nut Cach ly', 'php-trong-uploads' in body and 'nghi-web-shell' in body and 'Cach ly' in body and 'NGUY HIEM' in body, body[:300])
    check('XSS: ten file doc hai KHONG chen duoc the HTML (da escape)', '<img src=x onerror' not in body and '&lt;img src=x onerror=alert(1)&gt;.php' in body)
    sc, body, _ = c.req('POST', '/_admin/security.php', {'action': 'quarantine', 'file': 'wp-content/plugins/shell.php'})
    check('cach ly thieu CSRF: file con nguyen', os.path.exists(os.path.join(www, 'wp-content', 'plugins', 'shell.php')))
    for bad in ['wp-config.php', '../app_home/admin-password.txt', '/etc/passwd', 'wp-content/plugins/hello.php', '']:
        sc, body, _ = post('quarantine', file=bad)
        check('cach ly tu choi file ngoai danh sach quet: %r' % bad, 'Khong cach ly duoc' in body, body[:200])
    check('... wp-config.php va mat khau admin con nguyen', os.path.exists(os.path.join(www, 'wp-config.php')) and os.path.exists(os.path.join(app, 'admin-password.txt')))
    sc, body, _ = post('quarantine', file='wp-content/plugins/shell.php')
    check('cach ly dung file trong danh sach: file bien mat khoi site, co muc "Da cach ly"', not os.path.exists(os.path.join(www, 'wp-content', 'plugins', 'shell.php')) and 'Da cach ly' in body and 'Khoi phuc' in body, body[:300])
    qdir = os.path.join(run, 'quarantine')
    idx = json.load(open(os.path.join(qdir, 'index.json')))
    qid = list(idx)[0]
    sc, body, _ = post('restore', id='../index')
    check('khoi phuc id la: tu choi', 'Khong khoi phuc duoc' in body)
    sc, body, _ = post('restore', id=qid)
    check('khoi phuc: file ve dung cho', os.path.exists(os.path.join(www, 'wp-content', 'plugins', 'shell.php')) and 'Da khoi phuc' in body, body[:300])
    # bo qua
    sha = ''
    r = php_cli('-r', 'echo sha1_file($argv[1]);', os.path.join(www, 'wp-content', 'plugins', 'shell.php'))
    sha = r.stdout.strip()
    sc, body, _ = post('ignore', file='wp-content/plugins/shell.php', sha1='khong-hex')
    check('danh dau an toan voi sha1 sai dinh dang: tu choi', 'Du lieu khong hop le' in body)
    sc, body, _ = post('ignore', file='wp-content/plugins/shell.php', sha1=sha)
    check('danh dau an toan: ghi security-ignore.json', 'Da danh dau an toan' in body and os.path.exists(os.path.join(run, 'security-ignore.json')), body[:200])
    php_cli(scan, www, run)
    sc, body = page()
    check('quet lai sau khi bo qua: shell.php het bi bao, cache.php (uploads) van bi bao', '<b>nghi-web-shell</b>' not in body and '<b>php-trong-uploads</b>' in body, body[body.find('Ket qua quet'):][:400])
    # quet ngay + chap nhan
    for fn in ('security-scan-now',):
        p = os.path.join(run, fn)
        if os.path.exists(p):
            os.remove(p)
    sc, body, _ = post('scan_now')
    check('"Quet ngay": tao co security-scan-now cho supervisor', os.path.exists(os.path.join(run, 'security-scan-now')) and 'Da yeu cau quet' in body, body[:200])
    sc, body, _ = post('scan_accept')
    check('"Chap nhan": xoa moc + yeu cau quet lai', not os.path.exists(os.path.join(run, 'security-baseline.json')) and os.path.exists(os.path.join(run, 'security-scan-now')) and 'MOC moi' in body, body[:200])
    sc, body, _ = post('scan_fetch')
    check('"Tai checksum loi" khong co mang/khong phai WordPress: bao loi gon, khong Fatal', not AS.FATAL_RE.search(body) and ('Khong tai duoc' in body or 'Da tai' in body), body[:200])

    # ----- 4) Phong thu dang nhap (Shield) -----
    json.dump({'v': 1, 'u': {'id:1': {'f': [], 'i': {}, 'lock': int(time.time()) + 600, 'last': int(time.time())}, 'n:vong': {'f': [], 'i': {}, 'lock': int(time.time()) - 5}}, 'k': {'id:1': {'abc': int(time.time())}}},
              open(os.path.join(run, 'shield-login.json'), 'w'))
    sc, body = page()
    check('trang liet ke tai khoan dang phong thu (id:1) va KHONG liet ke muc da het han', 'id:1' in body and 'n:vong' not in body, body[body.find('phong thu'):][:300])
    sc, body, _ = post('login_clear', key='id:1')
    d = json.load(open(os.path.join(run, 'shield-login.json')))
    check('go phong thu: xoa trang thai, GIU danh sach mang quen (k)', 'id:1' not in d['u'] and 'abc' in d['k']['id:1'], d)
    open(os.path.join(run, 'shield-login.json'), 'w').write('{rac')
    sc, body = page()
    check('file shield-login.json hong: trang van 200, khong loi', sc == 200 and not AS.FATAL_RE.search(body))
    sc, body, _ = post('login_clear', key='')
    check('go phong thu khi file hong: tu phuc hoi, khong loi', not AS.FATAL_RE.search(body) and json.load(open(os.path.join(run, 'shield-login.json')))['v'] == 1)

    # ----- 5) Cong tat -----
    for name in ('block-ai-on', 'shield-allow-user-api', 'maintenance-mode', 'shield-off', 'shield-allow-file-edit', 'shield-allow-app-passwords', 'twofa-off', 'vuln-check-on', 'php-harden-on', 'shield-rest-gate-on', 'conn-limit-on', 'login-gate-off'):
        p = os.path.join(run, name)
        if os.path.exists(p):
            os.remove(p)
    sc, body, _ = c.req('POST', '/_admin/security.php', {'action': 'flag', 'name': 'block-ai-on', 'value': 'on'})
    check('cong tat thieu CSRF: khong tao file', not os.path.exists(os.path.join(run, 'block-ai-on')))
    post('flag', name='block-ai-on', value='on')
    check('bat block-ai-on: tao file co', os.path.exists(os.path.join(run, 'block-ai-on')))
    sc, body = page()
    check('trang hien block-ai-on dang BAT', re.search(r'block-ai-on</b> <span class="state on">BAT', body) is not None)
    post('flag', name='block-ai-on', value='off')
    check('tat block-ai-on: xoa file co', not os.path.exists(os.path.join(run, 'block-ai-on')))
    before = sorted(os.listdir(run))
    for bad in ('../admin-password', 'ban-list.conf', 'security-state.json', 'a/b', '', 'nginx.conf', 'block-ai-on/../x'):
        post('flag', name=bad, value='on')
    check('cong tat: ten ngoai danh sach (duong dan/file he thong) KHONG tao/ghi de gi', sorted(os.listdir(run)) == before and not os.path.exists(os.path.join(app, 'admin-password')), set(os.listdir(run)) ^ set(before))
    # shield-rest-gate-on + danh sach REST cho phep (HANDOFF.md muc 1br-H)
    rf = os.path.join(run, 'shield-rest-allow.txt')
    sc, body = page()
    check('khong phai site WordPress (khong co wp-load.php): khong goi y cong REST', 'Chua bat cong REST' not in body)
    wl = os.path.join(www, 'wp-load.php')
    open(wl, 'w').write('<?php\n')
    sc, body = page()
    check('site WordPress, cong REST tat: tu kiem tra goi y bat cong REST (muc warn)', 'Chua bat cong REST' in body)
    post('flag', name='shield-rest-gate-on', value='on')
    check('bat shield-rest-gate-on: tao file co', os.path.exists(os.path.join(run, 'shield-rest-gate-on')))
    sc, body = page()
    check('trang hien shield-rest-gate-on dang BAT, tu kiem tra bao "Cong REST dang bat"', re.search(r'shield-rest-gate-on</b> <span class="state on">BAT', body) is not None and 'Cong REST dang bat' in body and 'Chua bat cong REST' not in body)
    os.remove(wl)
    post('flag', name='shield-rest-gate-on', value='off')
    check('tat shield-rest-gate-on: xoa file co', not os.path.exists(os.path.join(run, 'shield-rest-gate-on')))
    sc, body, _ = c.req('POST', '/_admin/security.php', {'action': 'rest_allow_save', 'entries': '/wp/v2/posts'})
    check('luu REST cho phep thieu CSRF: khong tao file', not os.path.exists(rf))
    post('rest_allow_save', entries="# ghi chu\n/WP/v2/Posts   # chu thuong hoa\n/mysite/v1/form\n/wp/v2/posts\n\n")
    check('luu REST cho phep: ghi dong hop le, chu thuong, bo trung/ghi chu/dong trong', os.path.exists(rf) and open(rf).read() == '/wp/v2/posts\n/mysite/v1/form\n', open(rf).read() if os.path.exists(rf) else None)
    sc, body = page()
    check('trang hien lai danh sach da luu trong o nhap', '/mysite/v1/form' in body and '/wp/v2/posts' in body)
    before = open(rf).read()
    for bad in ('khong-co-gach', '/', '/a b', '/../etc/passwd', '//x', '/chu-hoa-co-dau-é', '/x;rm -rf', '/<script>'):
        post('rest_allow_save', entries='/ok-dong\n' + bad)
        check('luu REST cho phep: dong sai %r bi tu choi, KHONG ghi gi' % bad, open(rf).read() == before, open(rf).read())
    post('rest_allow_save', entries='\n'.join('/r%d' % i for i in range(101)))
    check('luu REST cho phep: tren 100 tien to bi tu choi, khong ghi', open(rf).read() == before)
    post('rest_allow_save', entries='')
    check('luu rong: xoa file danh sach (chi con danh sach co san)', not os.path.exists(rf))
    # moi file co tren lamp-run chi gom dung ten mong doi
    # php-harden-on (pool PHP "cung", HANDOFF.md muc 1br-H): cong + muc tu kiem tra o che do day du; khong nhac o che do Lite (khong co php-fpm)
    sc, body = page()
    check('php-harden-on tat: tu kiem tra goi y bat pool PHP cung (muc warn)', 'Chua bat pool PHP' in body)
    post('flag', name='php-harden-on', value='on')
    check('bat php-harden-on: tao file co lamp-run/php-harden-on (nginx doc moi request, khong can HUP)', os.path.exists(os.path.join(run, 'php-harden-on')))
    sc, body = page()
    check('php-harden-on bat: trang hien BAT + tu kiem tra bao "da tat exec/system/shell_exec"', re.search(r'php-harden-on</b> <span class="state on">BAT', body) is not None and 'da tat exec/system/shell_exec' in body and 'Chua bat pool PHP' not in body)
    open(os.path.join(run, 'lite-mode'), 'w').write('1')
    sc, body = page()
    check('che do Lite: KHONG hien muc tu kiem tra pool PHP cung (khong co php-fpm de ap dung)', 'pool PHP' not in body.split('Cong tat')[0] and sc == 200)
    os.remove(os.path.join(run, 'lite-mode'))
    post('flag', name='php-harden-on', value='off')
    check('tat php-harden-on: xoa file co', not os.path.exists(os.path.join(run, 'php-harden-on')))
    # conn-limit-on (gioi han request PHP dong thoi / IP, HANDOFF.md muc 1br-H): cung kieu voi php-harden-on, chi che do day du
    sc, body = page()
    check('conn-limit-on tat: tu kiem tra goi y bat gioi han dong thoi (muc warn)', 'Chua bat gioi han request PHP dong thoi' in body)
    post('flag', name='conn-limit-on', value='on')
    check('bat conn-limit-on: tao file co lamp-run/conn-limit-on (nginx doc moi request, khong can HUP)', os.path.exists(os.path.join(run, 'conn-limit-on')))
    sc, body = page()
    check('conn-limit-on bat: trang hien BAT + tu kiem tra bao "toi da 5 request PHP cung luc"', re.search(r'conn-limit-on</b> <span class="state on">BAT', body) is not None and 'toi da 5 request PHP cung luc' in body and 'Chua bat gioi han request PHP dong thoi' not in body)
    open(os.path.join(run, 'lite-mode'), 'w').write('1')
    sc, body = page()
    check('che do Lite: KHONG hien muc tu kiem tra gioi han dong thoi (khong co nginx)', 'gioi han request PHP dong thoi' not in body.split('Cong tat')[0] and sc == 200)
    os.remove(os.path.join(run, 'lite-mode'))
    post('flag', name='conn-limit-on', value='off')
    check('tat conn-limit-on: xoa file co', not os.path.exists(os.path.join(run, 'conn-limit-on')))
    # URL dang nhap bi mat (lamp-run/login-gate.conf, HANDOFF.md muc 1br-H): chi WordPress + che do day du; viec nginx THAT chay da nam o login-gate-test.py
    gf = os.path.join(run, 'login-gate.conf')
    CARD = '<h2>URL dang nhap bi mat</h2>'
    sc, body = page()
    check('khong phai site WordPress: KHONG co muc "URL dang nhap bi mat"', CARD not in body)
    if os.path.exists(os.path.join(run, 'ban-reload')):
        os.remove(os.path.join(run, 'ban-reload'))   # con sot tu cac phan truoc (huy chan IP...)
    post('gate_on')
    check('khong phai WordPress: gate_on bi tu choi, KHONG tao login-gate.conf', not os.path.exists(gf) and not os.path.exists(os.path.join(run, 'ban-reload')))
    wl = os.path.join(www, 'wp-load.php')
    open(wl, 'w').write('<?php\n')
    sc, body = page()
    check('site WordPress, che do day du: co muc "URL dang nhap bi mat", trang thai tat, KHONG co o tu kiem tra "bat" (tuy chon, khong nhac nho)', CARD in body and 'Trang thai: tat' in body and 'dang bat: /wp-login.php' not in body)
    sc, body, _ = c.req('POST', '/_admin/security.php', {'action': 'gate_on'})
    check('gate_on thieu CSRF: khong tao tep', not os.path.exists(gf))
    post('gate_on')
    gtxt = open(gf).read() if os.path.exists(gf) else ''
    m1 = re.search(r'^location = /([a-f0-9]{24}) \{$', gtxt, re.M)
    t1 = re.search(r'wppgate=([a-f0-9]{32});', gtxt)
    check('gate_on: tao login-gate.conf dung dinh dang (duong dan 24 hex, cookie 32 hex)', m1 is not None and t1 is not None and gtxt.count(t1.group(1)) == 2, gtxt[:160])
    check('gate_on: tep quyen 0600, khong con .tmp, tao co ban-reload (supervisor HUP nginx)', (os.stat(gf).st_mode & 0o777) == 0o600 and not os.path.exists(gf + '.tmp') and os.path.exists(os.path.join(run, 'ban-reload')), oct(os.stat(gf).st_mode & 0o777))
    sc, body = page()
    check('trang hien duong dan bi mat /<slug> va BAT; tu kiem tra "URL dang nhap bi mat dang bat"', m1 is not None and ('/' + m1.group(1)) in body and 'Trang thai: BAT' in body and 'dang bat: /wp-login.php' in body)
    check('trang KHONG in token cookie (chi duong dan bi mat)', t1 is not None and t1.group(1) not in body)
    audit = open(os.path.join(run, 'admin-audit.log')).read() if os.path.exists(os.path.join(run, 'admin-audit.log')) else ''
    check('nhat ky quan tri ghi "security: login gate on" NHUNG khong ghi duong dan/token bi mat', 'security: login gate on' in audit and m1 is not None and m1.group(1) not in audit and t1.group(1) not in audit, audit[-200:])
    os.remove(os.path.join(run, 'ban-reload'))
    post('gate_on')
    gtxt2 = open(gf).read()
    m2 = re.search(r'^location = /([a-f0-9]{24}) \{$', gtxt2, re.M)
    t2 = re.search(r'wppgate=([a-f0-9]{32});', gtxt2)
    check('gate_on lan 2 (doi URL): duong dan + cookie MOI, khac hoan toan, cu khong con trong tep; lai tao ban-reload', m1 and m2 and t2 and m2.group(1) != m1.group(1) and t2.group(1) != t1.group(1) and m1.group(1) not in gtxt2 and t1.group(1) not in gtxt2 and os.path.exists(os.path.join(run, 'ban-reload')))
    open(os.path.join(run, 'login-gate-off'), 'w').write('')
    sc, body = page()
    check('co login-gate-off dang bat: tu kiem tra canh bao "dang bi TAT khan cap"', 'dang bi TAT khan cap' in body and re.search(r'login-gate-off</b> <span class="state on">BAT', body) is not None)
    os.remove(os.path.join(run, 'login-gate-off'))
    open(os.path.join(run, 'lite-mode'), 'w').write('1')
    sc, body = page()
    check('che do Lite: KHONG hien muc "URL dang nhap bi mat" (khong co nginx)', CARD not in body and 'dang bat: /wp-login.php' not in body and sc == 200)
    post('gate_on')
    check('che do Lite: gate_on bi tu choi, tep khong bi ghi lai', open(gf).read() == gtxt2)
    os.remove(os.path.join(run, 'lite-mode'))
    os.remove(os.path.join(run, 'ban-reload'))
    post('gate_off')
    check('gate_off: xoa login-gate.conf + tao ban-reload', not os.path.exists(gf) and os.path.exists(os.path.join(run, 'ban-reload')))
    sc, body = page()
    check('sau gate_off: trang thai tat, khong con duong dan bi mat', 'Trang thai: tat' in body and m2.group(1) not in body)
    post('gate_off')
    check('gate_off khi chua bat: khong loi', not AS.FATAL_RE.search(page()[1]))
    os.remove(os.path.join(run, 'ban-reload'))
    os.remove(wl)
    # (tep gia lap wp-load.php da go de cac phan sau cua test van chay nhu site khong phai WordPress)
    post('flag', name='maintenance-mode', value='on')
    check('khoa khan cap: bat maintenance-mode', os.path.exists(os.path.join(run, 'maintenance-mode')))
    post('flag', name='maintenance-mode', value='off')
    check('khoa khan cap: tat', not os.path.exists(os.path.join(run, 'maintenance-mode')))

    # ----- 6) Su kien + tu kiem tra -----
    with open(os.path.join(run, 'security-events.log'), 'a') as f:
        f.write("2026-10-30 10:00:00 ip=1.2.3.4 PHAT HIEN <script>alert(1)</script>\n")
    sc, body = page()
    check('su kien hien ra, HTML duoc escape', '&lt;script&gt;alert(1)&lt;/script&gt;' in body and '<script>alert(1)' not in body)
    open(os.path.join(run, 'realip-missing'), 'w').write('')
    sc, body = page()
    check('co realip-missing: tu kiem tra bao DO (khong phan biet duoc khach that)', 'Khong phan biet duoc khach that' in body)
    open(os.path.join(app, 'admin-totp-enabled.flag'), 'w').write('1')
    sc, body = page()
    check('co 2FA: tu kiem tra bao XANH, het canh bao 2FA', '2FA) cho _admin/ dang bat' in body and 'Chua bat 2FA' not in body)
    os.remove(os.path.join(app, 'admin-totp-enabled.flag'))
    os.remove(os.path.join(run, 'realip-missing'))
    sc, body, _ = post('khong-co-hanh-dong')
    check('hanh dong la: bao loi, khong Fatal', 'Hanh dong khong hop le' in body and not AS.FATAL_RE.search(body))
    # ----- 6b) Lo hong da biet (1br-H, tuy chon, mac dinh TAT) -----
    for n in ('vuln-check-on', 'vuln-check-now', 'security-vuln.json'):
        if os.path.exists(os.path.join(run, n)):
            os.remove(os.path.join(run, n))
    sc, body = page()
    check('lo hong da biet: muc hien o trang thai TAT, co canh bao tu kiem tra, co ghi ro "gui ra" ben thu ba', 'Lo hong da biet cua plugin' in body and re.search(r'Lo hong da biet cua plugin.*?TAT', body, re.S) is not None
          and 'Chua bat kiem LO HONG DA BIET' in body and 'gui ra www.wpvulnerability.net' in body and 'name="action" value="vuln_now"' not in body, body[body.find('Lo hong da biet'):][:300])
    sc, body, _ = post('vuln_now')
    check('"Kiem ngay" khi dang TAT: bao loi, KHONG tao file co', 'dang TAT' in body and not os.path.exists(os.path.join(run, 'vuln-check-now')), body[:200])
    post('flag', name='vuln-check-on', value='on')
    check('bat vuln-check-on tu Cong tat: tao file co', os.path.exists(os.path.join(run, 'vuln-check-on')))
    sc, body = page()
    check('sau khi bat: hien BAT + nut "Kiem ngay" + "Chua co ket qua"', re.search(r'Lo hong da biet cua plugin.*?BAT', body, re.S) is not None and 'name="action" value="vuln_now"' in body and 'Kiem lo hong chua co ket qua' in body)
    sc, body, _ = c.req('POST', '/_admin/security.php', {'action': 'vuln_now'})
    check('"Kiem ngay" thieu CSRF: khong tao file co', not os.path.exists(os.path.join(run, 'vuln-check-now')))
    sc, body, _ = post('vuln_now')
    check('"Kiem ngay" dung CSRF: tao co vuln-check-now cho supervisor', os.path.exists(os.path.join(run, 'vuln-check-now')) and 'Da yeu cau kiem' in body, body[:200])
    evil = {'at': now, 'enabled': True, 'core': '6.9.5', 'plugins': 2, 'themes': 1, 'requests': 3, 'failed': 1, 'truncated': True, 'skipped': ['plugin <b>x</b>: khong doc duoc'],
            'counts': {'critical': 1, 'high': 0, 'medium': 0, 'low': 0}, 'findings': [
                {'sev': 'critical', 'kind': 'lo-hong-plugin', 'type': 'plugin', 'slug': '<img src=x onerror=alert(1)>', 'version': '1.0', 'title': '<script>alert(1)</script> RCE', 'score': 9.8, 'unfixed': 1,
                 'src': [{'name': 'CVE-2026-1', 'link': 'javascript:alert(1)'}, {'name': '<i>ok</i>', 'link': 'https://example.test/cve?a=1&b="2"'}]}]}
    json.dump(evil, open(os.path.join(run, 'security-vuln.json'), 'w'))
    sc, body = page()
    vs = body[body.find('Lo hong da biet cua plugin'):body.find('IP dang bi tu dong chan')]
    check('ket qua lo hong: du lieu tu ben ngoai KHONG chen duoc HTML/script', '<script>alert(1)' not in vs and '<img src=x' not in vs and '&lt;script&gt;alert(1)&lt;/script&gt;' in vs and '&lt;img src=x' in vs, vs[:400])
    check('lien ket "javascript:" khong thanh href; lien ket https thanh href co rel noopener nofollow, ten nguon duoc escape',
          'href="javascript:' not in vs and re.search(r'href="https://example\.test/cve\?a=1&amp;b=&quot;2&quot;" rel="noopener noreferrer nofollow"', vs) is not None and '&lt;i&gt;ok&lt;/i&gt;' in vs, vs[-500:])
    check('hien CHUA CO BAN VA, diem CVSS, canh bao CHUA XONG, loi mang, muc khong kiem duoc (da escape)', 'CHUA CO BAN VA' in vs and 'CVSS 9.8' in vs and 'CHUA XONG' in vs and '1 loi mang' in vs and 'plugin &lt;b&gt;x&lt;/b&gt;' in vs)
    check('tu kiem tra: co lo hong nghiem trong -> muc DO "CO LO HONG nghiem trong"', 'dang chay ban CO LO HONG nghiem trong' in body)
    json.dump(dict(evil, findings=[], counts={'critical': 0, 'high': 0, 'medium': 0, 'low': 0}, truncated=False), open(os.path.join(run, 'security-vuln.json'), 'w'))
    sc, body = page()
    check('khong co phat hien: bao "Khong thay lo hong" + tu kiem tra xanh', 'Khong thay lo hong da biet nao' in body)
    json.dump({'at': now, 'enabled': True, 'findings': 'rac', 'counts': 'rac'}, open(os.path.join(run, 'security-vuln.json'), 'w'))
    sc, body = page()
    check('file ket qua lo hong sai kieu: trang van 200, khong Fatal/Warning', sc == 200 and not AS.FATAL_RE.search(body) and not AS.WARN_RE.search(body), body[:200])
    open(os.path.join(run, 'security-vuln.json'), 'w').write('{rac')
    sc, body = page()
    check('file ket qua lo hong hong: trang van 200', sc == 200 and not AS.FATAL_RE.search(body) and not AS.WARN_RE.search(body))
    post('flag', name='vuln-check-on', value='off')
    check('tat vuln-check-on: xoa file co', not os.path.exists(os.path.join(run, 'vuln-check-on')))
    sc, body, _ = anon_get('/_admin/security-vuln-lib.php')
    check('security-vuln-lib.php truy cap truc tiep: khong loi, khong lo thong tin', not AS.FATAL_RE.search(body) and body.strip() == '', body[:100])
    lib = os.path.join(adm, 'security-vuln-lib.php')
    if os.path.exists(lib):
        os.rename(lib, lib + '.off')
        sc, body = page()
        check('ban cai cu chua co thu vien kiem lo hong: trang van chay, khong Fatal', sc == 200 and not AS.FATAL_RE.search(body) and 'Trung tam bao mat' in body, body[:200])
        os.rename(lib + '.off', lib)
    # nhat ky kiem toan: hanh dong ghi duoc ghi vao admin-audit.log
    audit = open(os.path.join(run, 'admin-audit.log')).read()
    check('hanh dong quan tri ghi vao admin-audit.log ("security: unban/quarantine/...")', 'security: unban ' + ip1 in audit and 'security: quarantine wp-content/plugins/shell.php' in audit, audit[-300:])
    # chua dang nhap
    anon = AS.Client(port, '10.9.9.9')
    sc, body, _ = anon.req('GET', '/_admin/security.php')
    check('chua dang nhap: chi thay form dang nhap', 'admin_password' in body and 'IP dang bi' not in body)
    sc, _, _ = AS.Client(port, '8.8.8.8').req('GET', '/_admin/security.php')
    check('IP ngoai LAN: 403', sc == 403, sc)
    sc, body, _ = anon.req('GET', '/_admin/security-lib.php')
    check('security-lib.php truy cap truc tiep: khong loi, khong lo thong tin', not AS.FATAL_RE.search(body) and body.strip() == '', body[:100])
    sc, body, _ = anon.req('GET', '/_admin/security-scan-lib.php')
    check('security-scan-lib.php truy cap truc tiep: khong loi, khong lo thong tin', not AS.FATAL_RE.search(body) and body.strip() == '', body[:100])


def main():
    tmp = tempfile.mkdtemp(prefix='seccenter-')
    app, run, www, adm = AS.build_tree(tmp)
    port = AS.free_port()
    env = dict(os.environ, APP_HOME=app, EXT_DIR=os.path.join(tmp, 'ext'))
    logf = open(os.path.join(tmp, 'php-server.log'), 'w')
    srv = AS.start_php_server(port, www, tmp, env, logf)
    try:
        run_tests(port, app, run, www, adm, tmp)
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        logf.close()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
