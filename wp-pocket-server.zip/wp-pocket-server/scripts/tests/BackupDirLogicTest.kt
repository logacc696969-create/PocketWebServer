import com.wppocket.server.BackupDirLogic
import java.io.File
import java.nio.file.Files

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }
fun mk(dir: File, name: String, mtime: Long): File { dir.mkdirs(); val f = File(dir, name); f.writeBytes(byteArrayOf(1)); f.setLastModified(mtime); return f }

fun main() {
    check("isBackupFile", BackupDirLogic.isBackupFile("backup-1.zip") && BackupDirLogic.isBackupFile("backup-1.zip.enc") && !BackupDirLogic.isBackupFile("backup-1.zip.partial") && !BackupDirLogic.isBackupFile("x.zip"))
    val prim = File("/p/files"); val sd = File("/sd/files")
    val rem = { f: File -> f != prim }
    check("mac dinh -> bo nho chinh", BackupDirLogic.pickWriteDir(listOf(prim, sd), false, rem, { true }) == prim)
    check("bat + the ghi duoc -> the nho", BackupDirLogic.pickWriteDir(listOf(prim, sd), true, rem, { true }) == sd)
    check("bat + the khong ghi duoc -> bo nho chinh", BackupDirLogic.pickWriteDir(listOf(prim, sd), true, rem, { false }) == prim)
    check("null o cuoi / tat ca null", BackupDirLogic.pickWriteDir(listOf(prim, null), true, rem, { true }) == prim && BackupDirLogic.pickWriteDir(listOf(null, null), true, rem, { true }) == null)
    val tmp = Files.createTempDirectory("bkdir-kt").toFile()
    try {
        val a = File(tmp, "primary/backups"); val b = File(tmp, "sd/backups"); val t0 = 1_700_000_000_000L
        mk(a, "backup-1.zip", t0 + 1000); mk(b, "backup-2.zip.enc", t0 + 2000); mk(a, "backup-3.zip", t0 + 3000); mk(b, "backup-4.zip", t0 + 4000)
        mk(a, "backup-5.zip", t0 + 5000); mk(b, "backup-6.zip", t0 + 6000); mk(a, "backup-7.zip.enc", t0 + 7000); mk(a, "backup-9.zip.partial", t0 + 9000)
        val all = BackupDirLogic.listAll(listOf(a, b))
        check("listAll gop 2 noi, bo .partial, moi nhat truoc", all.size == 7 && all[0].name == "backup-7.zip.enc" && all[6].name == "backup-1.zip")
        val ex = BackupDirLogic.excess(all, 5)
        check("excess giu 5 tren ca hai noi", ex.size == 2 && ex[0].name == "backup-2.zip.enc" && ex[1].name == "backup-1.zip")
        check("thu muc khong ton tai -> bo qua", BackupDirLogic.listAll(listOf(a, File(tmp, "khong-co"))).size == 4)
    } finally { tmp.deleteRecursively() }
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
