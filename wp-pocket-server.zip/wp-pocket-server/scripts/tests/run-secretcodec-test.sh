#!/bin/sh
# Chay kiem thu JVM cho SecretCodec.kt (can kotlinc + java). HANDOFF.md muc 1bp-I.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/SecretCodec.kt" "$HERE/SecretCodecTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" SecretCodecTestKt
rc=$?; rm -rf "$OUT"; exit $rc
