#!/usr/bin/env python3
"""AG2, AG3 (PDF 2; HANDOFF.md muc 1bq-L): kiem chung docs/VALUE_AND_AUDIENCE.md - moi tuyen bo gia tri CO bang chung that trong repo, tai lieu noi ro gioi han,
khong chua tuyen bo ve so lieu thi truong/nguoi dung, README tro toi tai lieu."""
import os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def rd(p):
    return open(os.path.join(ROOT, p), encoding="utf-8").read()


doc, readme = rd("docs/VALUE_AND_AUDIENCE.md"), rd("README.md")
K = "app/src/main/java/com/wppocket/server/"
T = "scripts/runtimes/templates/"
# Moi tuyen bo U1..U7: (cac tep PHAI duoc ghi trong hang cua tai lieu, va moi tep PHAI chua mau dung)
EVIDENCE = {
    "U1": [(K + "ServerForegroundService.kt", r"cloudflared"), ("README.md", r"CGNAT")],
    "U2": [("site.config.json", r'"runtime"'), ("scripts/tools/apply_preset.py", r'RUNTIMES\s*=')],
    "U3": [(T + "start-lamp.sh", r"mariadbd"), (T + "start-lamp.sh", r"php-fpm")],
    "U4": [(T + "nginx.conf.template", r"allow 192\.168\.0\.0/16"), (T + "admin-auth.php", r"<\?php")],
    "U5": [(K + "BackupVerifier.kt", r"object BackupVerifier"), (K + "TelegramNotifier.kt", r"Telegram")],
    "U6": [("docs/ALERT_RULES.md", r"cooldown"), (K + "AlertRules.kt", r"object AlertRules"), ("scripts/tools/wppocket_cli.py", r"def fetch_status")],
    "U7": [("TERMS.md", r"Giai đoạn thử nghiệm miễn phí"), ("docs/COMPETITIVE_ANALYSIS.md", r"Điểm yếu thật")],
}
for uid, items in EVIDENCE.items():
    row = [l for l in doc.split("\n") if l.startswith("| %s |" % uid)]
    ok = bool(row)
    why = []
    for path, pat in items:
        in_row = ("`%s`" % path) in row[0] if row else False
        exists = os.path.exists(os.path.join(ROOT, path))
        match = exists and re.search(pat, rd(path)) is not None
        if not (in_row and match):
            ok = False
            why.append((path, "co trong hang" if in_row else "THIEU trong hang", "khop mau" if match else "KHONG khop mau/khong ton tai"))
    check("tuyen bo %s: moi bang chung duoc ghi trong hang tai lieu, tep ton tai va chua dung mau" % uid, ok, why)
ids_in_doc = re.findall(r"^\| (U\d+) \|", doc, re.M)
check("tai lieu co DUNG 7 tuyen bo U1..U7 (khong co tuyen bo nao ngoai danh sach kiem)", ids_in_doc == ["U%d" % i for i in range(1, 8)], ids_in_doc)

# gioi han / trung thuc
check("tai lieu ghi 'Do tin cay' o dau: viet tu ma nguon, KHONG tu nghien cuu nguoi dung/thi truong", "Độ tin cậy" in doc.split("\n")[2] and "không từ nghiên cứu người dùng" in doc)
check("tai lieu noi chua co nguoi dung that / chua khao sat (muc 'Chua lam')", "chưa có người dùng thật" in doc and "Chưa khảo sát người dùng thật" in doc)
bad = [p for p in (r"\d+\s*(triệu|nghìn|ngàn)\s*(người dùng|lượt tải)", r"hàng (nghìn|triệu) người", r"phổ biến nhất", r"tốt nhất", r"số 1", r"nhanh nhất", r"rẻ nhất", r"đảm bảo 99", r"uptime 99") if re.search(p, doc, re.I)]
check("khong co tuyen bo so lieu thi truong/xep hang/uptime (%s)" % bad, not bad, bad)
aud = doc.split("### Phù hợp")[1]
good, notgood = aud.split("### KHÔNG phù hợp")[0], aud.split("### KHÔNG phù hợp")[1].split("### Mức kỹ thuật")[0]
check("5 nhom PHU HOP va >= 6 nhom KHONG phu hop (nguoi dung can biet khi nao KHONG nen dung)", len(re.findall(r"^\d\. ", good, re.M)) == 5 and len(re.findall(r"^\d\. ", notgood, re.M)) >= 6, (len(re.findall(r"^\d\. ", good, re.M)), len(re.findall(r"^\d\. ", notgood, re.M))))
check("nhom KHONG phu hop khop gioi han that: 1 website duy nhat, khong SLA, khong email server", "một website duy nhất" in notgood and "không SLA" in notgood and "email" in notgood.lower())
check("'1 website duy nhat' khop thiet ke that: README noi 'mot website duy nhat'", "một website duy nhất" in readme.lower() or "**một website duy nhất**" in readme)
check("phan Phu hop khop tinh nang that: Cloudflare Tunnel/CGNAT trong README, ma QR (K4) co that", "CGNAT" in readme and os.path.exists(os.path.join(ROOT, K + "QrCode.kt")) and "mã QR" in good)
check("khau hieu chinh thuc de chu du an chon (khong tu chot)", "CHỦ DỰ ÁN QUYẾT: khẩu hiệu" in doc)
check("tro toi cac tai lieu that (ton tai)", all(os.path.exists(os.path.join(ROOT, p)) for p in ("docs/BETA_PROGRAM.md", "docs/COMPETITIVE_ANALYSIS.md", "docs/DISASTER_RECOVERY.md", "docs/LEGAL_NOTES_VN.md", "docs/ALERT_RULES.md")))
check("README tro toi VALUE_AND_AUDIENCE o dau tai lieu va co trong bang tai lieu; neu 'khong phu hop' + 'thu nghiem mien phi'", "docs/VALUE_AND_AUDIENCE.md" in readme and readme.index("VALUE_AND_AUDIENCE") < readme.index("Cloudflare Quick Tunnel") and "Không phù hợp" in readme and "thử nghiệm miễn phí" in readme)
check("COMPETITIVE_ANALYSIS van nhac 'chua kiem voi ban hien tai cua doi thu' (khong dung lam loi quang cao)", "chưa so với bản hiện tại của đối thủ" in rd("docs/COMPETITIVE_ANALYSIS.md") and "không nên dùng làm lời quảng cáo" in doc)

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
