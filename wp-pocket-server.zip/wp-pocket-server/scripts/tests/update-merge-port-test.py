#!/usr/bin/env python3
"""Kiem thu HANH VI cua UpdateMergeLogic (cap nhat APK khong xoa du lieu nguoi dung) - HANDOFF.md muc 1bo.

Vi sao la ban PORT: sandbox/may khong co kotlinc. Thuat toan duoc dich 1-1 sang Python (os/zipfile that,
symlink that) va chay tren cay thu muc + zip THAT; test JVM `UpdateMergeLogicTest.kt` kiem CUNG cac khang
dinh bang Kotlin that o CI. Phan cuoi doi chieu VAN BAN voi ma Kotlin (cung hang so, dich vu da goi ham moi,
khong con xoa sach docroot) de ban port khong the lech am tham khoi ma that.

Co DOI CHUNG AM: ban cu (xoa sach roi giai nen) PHAI lam mat uploads/SQLite - neu khong, test khong chung minh gi.
"""
import os, re, shutil, sys, tempfile, zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
KT = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/UpdateMergeLogic.kt")
SVC = os.path.join(ROOT, "app/src/main/java/com/wppocket/server/ServerForegroundService.kt")

REPLACED_DIRS = ["_admin", "_supervisor", "mariadb-share", "wp-admin", "wp-includes"]
REGENERATED_FILES = ["wp-config.php"]

pass_n = 0; fail_n = 0
def check(name, cond):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name)

# ---------------- ban port 1-1 cua UpdateMergeLogic.kt ----------------
class UnsafeZip(Exception): pass

def safe_rel_path(name):
    if "\x00" in name: return None
    if name.startswith("/"): return None
    parts = []
    for seg in name.split("/"):
        if seg == "" or seg == ".": continue
        if seg == "..": return None
        parts.append(seg)
    return "/".join(parts)

def delete_no_follow(path):
    if not os.path.lexists(path): return
    if os.path.islink(path) or not os.path.isdir(path):
        try: os.unlink(path)
        except OSError: pass
        return
    for name in os.listdir(path):
        delete_no_follow(os.path.join(path, name))
    try: os.rmdir(path)
    except OSError: pass

def prepare_for_merge(doc):
    for d in REPLACED_DIRS: delete_no_follow(os.path.join(doc, d))
    for f in REGENERATED_FILES: delete_no_follow(os.path.join(doc, f))

def is_inside(root_canon, p):
    c = os.path.realpath(p)
    return c == root_canon or c.startswith(root_canon + os.sep)

def ensure_parent_dirs(target, parent):
    rel = os.path.relpath(parent, target)
    cur = target
    if rel != ".":
        for seg in rel.split(os.sep):
            if not seg: continue
            cur = os.path.join(cur, seg)
            if os.path.exists(cur) and not os.path.isdir(cur):
                os.unlink(cur)
    os.makedirs(parent, exist_ok=True)

def extract_merge(zip_path, target):
    os.makedirs(target, exist_ok=True)
    root_canon = os.path.realpath(target)
    written = links = conflicts = 0
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            rel = safe_rel_path(info.filename)
            if rel is None:
                raise UnsafeZip("Zip entry khong hop le: " + info.filename)
            if rel == "": continue
            out = os.path.join(target, rel)
            parent = os.path.dirname(out) or target
            is_dir = info.filename.endswith("/")
            if not is_inside(root_canon, parent):
                links += 1
            elif is_dir:
                if os.path.islink(out):
                    links += 1
                else:
                    if os.path.exists(out) and not os.path.isdir(out): os.unlink(out)
                    os.makedirs(out, exist_ok=True)
            else:
                skip = False
                if os.path.islink(out):
                    os.unlink(out)
                elif os.path.isdir(out):
                    conflicts += 1; skip = True
                if not skip:
                    ensure_parent_dirs(target, parent)
                    with z.open(info) as src, open(out, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    written += 1
    return written, links, conflicts

def old_update_buggy(zip_path, target):
    """Hanh vi CU (doi chung am): xoa sach roi giai nen."""
    shutil.rmtree(target, ignore_errors=True)
    os.makedirs(target)
    with zipfile.ZipFile(zip_path) as z: z.extractall(target)

# ---------------- tien ich ----------------
def make_zip(path, files, dirs=()):
    with zipfile.ZipFile(path, "w") as z:
        for d in dirs: z.writestr(d if d.endswith("/") else d + "/", "")
        for n, c in files.items(): z.writestr(n, c)

def write(base, rel, content):
    p = os.path.join(base, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f: f.write(content)

def read(base, rel):
    try:
        with open(os.path.join(base, rel)) as f: return f.read()
    except OSError: return None

def tree(base):
    out = {}
    for dp, dn, fn in os.walk(base):
        for f in fn:
            p = os.path.join(dp, f)
            if os.path.islink(p): out[os.path.relpath(p, base)] = "LINK->" + os.readlink(p)
            else:
                with open(p, "rb") as fh: out[os.path.relpath(p, base)] = fh.read()
    return out

BUNDLE = {
    "index.php": "NEW-INDEX",
    "wp-config.php.template": "TEMPLATE-v2",
    "_admin/new-page.php": "ADMIN-NEW",
    "_admin/index.php": "ADMIN-INDEX-v2",
    "_supervisor/start-lamp.sh": "START-v2",
    "mariadb-share/errmsg.sys": "ERR-v2",
    "wp-includes/version.php": "6.9",
    "wp-admin/index.php": "WPADMIN-v2",
    "wp-content/plugins/bundled/b.php": "BUNDLED-v2",
    "wp-content/database/index.php": "<?php // silence",
    "wp-content/themes/twenty/style.css": "TWENTY-v2",
}

def main():
    tmp = tempfile.mkdtemp(prefix="updmerge-")
    try:
        # ---- 1. safeRelPath ----
        check("safeRelPath: ten thuong giu nguyen, './' va '//' duoc chuan hoa",
              safe_rel_path("a/b.txt") == "a/b.txt" and safe_rel_path("./a//b/") == "a/b" and safe_rel_path("a/") == "a")
        check("safeRelPath: '..' / tuyet doi / NUL -> khong an toan",
              safe_rel_path("../x") is None and safe_rel_path("a/../../x") is None and safe_rel_path("a/..") is None
              and safe_rel_path("/etc/passwd") is None and safe_rel_path("a\x00b") is None)
        check("safeRelPath: thu muc goc ('./', '/' sau chuan hoa '') -> chuoi rong (bo qua)", safe_rel_path("./") == "" and safe_rel_path(".") == "")
        check("safeRelPath: dau '\\' khong phai phan cach tren Android (giu nhu ten tep)", safe_rel_path("a\\b") == "a\\b" and safe_rel_path("..\\x") == "..\\x")

        zip_new = os.path.join(tmp, "new.zip"); make_zip(zip_new, BUNDLE, dirs=["wp-content/cache"])

        # ---- 2. cai moi vao thu muc rong ----
        d1 = os.path.join(tmp, "fresh"); prepare_for_merge(d1)
        w, l, c = extract_merge(zip_new, d1)
        check("cai moi: moi tep cua goi co mat dung noi dung", all(read(d1, k) == v for k, v in BUNDLE.items()))
        check("cai moi: dem tep ghi = so tep trong goi, khong bo qua gi", (w, l, c) == (len(BUNDLE), 0, 0))

        # ---- 3. cap nhat GIU du lieu nguoi dung, thay ma nguon chuong trinh ----
        d2 = os.path.join(tmp, "upd")
        user = {
            "wp-content/uploads/2026/10/anh.jpg": "JPEGDATA",
            "wp-content/plugins/my-plugin/x.php": "MYPLUGIN",
            "wp-content/themes/my-theme/style.css": "MYTHEME",
            "wp-content/database/.ht.sqlite": "SQLITE-ALL-POSTS",
            "wp-content/languages/vi.mo": "VI",
            "extra/readme.txt": "USER-ADDED-VIA-FILE-MANAGER",
        }
        stale = {"_admin/old-page.php": "STALE-ADMIN", "wp-includes/stale.php": "STALE-CORE", "mariadb-share/old.sys": "OLD", "_supervisor/old.sh": "OLD"}
        for k, v in {**user, **stale, "index.php": "OLD-INDEX", "wp-config.php": "OLD-CONFIG-WITH-OLD-SALT"}.items(): write(d2, k, v)
        prepare_for_merge(d2); extract_merge(zip_new, d2)
        check("cap nhat: uploads + plugin tu cai + theme tu cai + SQLITE + languages + tep nguoi dung them -> GIU NGUYEN",
              all(read(d2, k) == v for k, v in user.items()))
        check("cap nhat: tep cung duong dan voi goi bi ghi de bang ban moi (code duoc cap nhat)", read(d2, "index.php") == "NEW-INDEX" and read(d2, "wp-content/plugins/bundled/b.php") == "BUNDLED-v2")
        check("cap nhat: tep cu cua chuong trinh trong REPLACED_DIRS bi go (khong con tep mo coi cua ban cu)",
              all(read(d2, k) is None for k in stale) and read(d2, "_admin/new-page.php") == "ADMIN-NEW")
        check("cap nhat: wp-config.php bi xoa de start-lamp.sh sinh lai tu mau moi; mau moi co mat",
              read(d2, "wp-config.php") is None and read(d2, "wp-config.php.template") == "TEMPLATE-v2")
        check("cap nhat: wp-content/database/index.php cua goi duoc ghi nhung .ht.sqlite khong bi dung toi",
              read(d2, "wp-content/database/index.php") == "<?php // silence" and read(d2, "wp-content/database/.ht.sqlite") == "SQLITE-ALL-POSTS")

        # ---- 3b. DOI CHUNG AM: hanh vi cu lam mat du lieu ----
        d2b = os.path.join(tmp, "upd-old")
        for k, v in user.items(): write(d2b, k, v)
        old_update_buggy(zip_new, d2b)
        lost = [k for k, v in user.items() if read(d2b, k) != v]
        check("DOI CHUNG AM: ban CU (xoa sach roi giai nen) lam MAT uploads + SQLite + plugin/theme tu cai (test co kha nang bat loi)",
              "wp-content/uploads/2026/10/anh.jpg" in lost and "wp-content/database/.ht.sqlite" in lost and len(lost) == len(user))

        # ---- 4. idempotent + thu lai sau khi dang do ----
        before = tree(d2)
        prepare_for_merge(d2); extract_merge(zip_new, d2)
        after = tree(d2)
        # wp-config.php khong ton tai o ca 2 phia vi chay ca prepare; khac biet duy nhat co the co la khong co
        check("chay lai (idempotent): cay thu muc giong het", before == after)

        d3 = os.path.join(tmp, "partial")
        for k, v in user.items(): write(d3, k, v)
        bad = os.path.join(tmp, "bad.zip")
        with zipfile.ZipFile(bad, "w") as z:
            z.writestr("index.php", "HALF-NEW"); z.writestr("../evil.txt", "x"); z.writestr("late.php", "never")
        prepare_for_merge(d3)
        raised = False
        try: extract_merge(bad, d3)
        except UnsafeZip: raised = True
        check("goi hong giua chung: nem loi (Zip Slip) va KHONG co tep nao thoat ra ngoai", raised and not os.path.exists(os.path.join(tmp, "evil.txt")))
        check("goi hong giua chung: du lieu nguoi dung van nguyen ven", all(read(d3, k) == v for k, v in user.items()))
        prepare_for_merge(d3); extract_merge(zip_new, d3)
        check("thu lai bang goi tot sau khi dang do: hoan tat va van giu du lieu", read(d3, "index.php") == "NEW-INDEX" and all(read(d3, k) == v for k, v in user.items()))

        # ---- 5. Zip Slip ----
        for nm in ["../evil.txt", "a/../../evil.txt", "/abs-evil.txt", "a/b/../../../evil.txt"]:
            zp = os.path.join(tmp, "slip.zip")
            with zipfile.ZipFile(zp, "w") as z: z.writestr(nm, "x")
            dd = os.path.join(tmp, "slipdst"); shutil.rmtree(dd, ignore_errors=True)
            r = False
            try: extract_merge(zp, dd)
            except UnsafeZip: r = True
            check("Zip Slip: '%s' bi tu choi, khong ghi ra ngoai" % nm, r and not os.path.exists(os.path.join(tmp, "evil.txt")) and not os.path.exists("/abs-evil.txt"))

        # ---- 6. symlink ----
        d4 = os.path.join(tmp, "sym"); outside = os.path.join(tmp, "outside-cache"); os.makedirs(outside); write(outside, "keep.txt", "CACHE-KEEP")
        os.makedirs(os.path.join(d4, "wp-content")); os.symlink(outside, os.path.join(d4, "wp-content", "cache"))
        zs = os.path.join(tmp, "sym.zip"); make_zip(zs, {"wp-content/cache/junk.txt": "JUNK", "wp-content/cache/sub/deep.txt": "DEEP", "ok.txt": "OK"}, dirs=["wp-content/cache"])
        prepare_for_merge(d4); w, l, c = extract_merge(zs, d4)
        check("symlink wp-content/cache -> ngoai: KHONG ghi xuyen qua link, link giu nguyen, khong nem loi",
              not os.path.exists(os.path.join(outside, "junk.txt")) and not os.path.exists(os.path.join(outside, "sub")) and os.path.islink(os.path.join(d4, "wp-content", "cache")) and read(d4, "ok.txt") == "OK" and l >= 2)
        check("symlink: noi dung dich cua link khong bi dong vao", read(outside, "keep.txt") == "CACHE-KEEP")

        d5 = os.path.join(tmp, "sym2"); out2 = os.path.join(tmp, "outside-lib"); os.makedirs(out2); write(out2, "libz.so.1", "LIB")
        os.makedirs(os.path.join(d5, "_supervisor", "pyhome")); os.symlink(out2, os.path.join(d5, "_supervisor", "pyhome", "lib-dynload"))
        os.symlink(os.path.join(out2, "libz.so.1"), os.path.join(d5, "_supervisor", "z.so"))
        os.symlink(out2, os.path.join(d5, "wp-admin"))        # REPLACED_DIR chinh no la symlink
        prepare_for_merge(d5)
        check("xoa REPLACED_DIRS KHONG theo symlink: chi xoa link, noi dung dich con nguyen",
              read(out2, "libz.so.1") == "LIB" and not os.path.lexists(os.path.join(d5, "_supervisor")) and not os.path.lexists(os.path.join(d5, "wp-admin")))

        d6 = os.path.join(tmp, "sym3"); out3 = os.path.join(tmp, "outside-file"); write(out3, "secret.txt", "SECRET")
        os.makedirs(d6); os.symlink(os.path.join(out3, "secret.txt"), os.path.join(d6, "index.php"))
        zf = os.path.join(tmp, "symf.zip"); make_zip(zf, {"index.php": "BUNDLE-INDEX"})
        extract_merge(zf, d6)
        check("tep goi trung ten voi symlink-toi-tep: thay bang tep that, tep dich khong bi ghi de",
              read(d6, "index.php") == "BUNDLE-INDEX" and not os.path.islink(os.path.join(d6, "index.php")) and read(out3, "secret.txt") == "SECRET")

        # ---- 7. xung dot loai ----
        d7 = os.path.join(tmp, "conf"); write(d7, "foo/user-data.txt", "UDATA"); write(d7, "bar", "A-USER-FILE")
        zc = os.path.join(tmp, "conf.zip"); make_zip(zc, {"foo": "BUNDLE-FILE-NAMED-FOO", "bar/baz.txt": "BAZ"})
        w, l, c = extract_merge(zc, d7)
        check("xung dot: tep goi trung ten THU MUC nguoi dung -> bo qua, GIU thu muc va du lieu (khong xoa)",
              c == 1 and read(d7, "foo/user-data.txt") == "UDATA" and os.path.isdir(os.path.join(d7, "foo")))
        check("xung dot: thu muc goi trung ten TEP nguoi dung -> nhuong cho thu muc, giai nen duoc", read(d7, "bar/baz.txt") == "BAZ")

        # ---- 8. doi chieu VAN BAN voi ma Kotlin that ----
        kt = open(KT, encoding="utf-8").read(); svc = open(SVC, encoding="utf-8").read()
        def kt_list(name):
            m = re.search(r"val %s: List<String> = listOf\(([^)]*)\)" % name, kt)
            return re.findall(r'"([^"]+)"', m.group(1)) if m else None
        check("doi chieu: REPLACED_DIRS trong Kotlin == hang so cua ban port", kt_list("REPLACED_DIRS") == REPLACED_DIRS)
        check("doi chieu: REGENERATED_FILES trong Kotlin == hang so cua ban port", kt_list("REGENERATED_FILES") == REGENERATED_FILES)
        check("an toan: REPLACED_DIRS khong chua thu muc du lieu nguoi dung (wp-content, uploads, database...)",
              not any(("wp-content" in d) or ("upload" in d) or ("database" in d) or d in ("", ".", "www") for d in kt_list("REPLACED_DIRS")))
        m = re.search(r"private fun prepareRuntimeIfNeeded\(\) \{(.*?)ensureAdminPassword\(\)\n    \}", svc, re.S)
        body = m.group(1) if m else ""
        check("dich vu: prepareRuntimeIfNeeded dung prepareForMerge + extractMerge", "UpdateMergeLogic.prepareForMerge(docRoot)" in body and "UpdateMergeLogic.extractMerge(" in body)
        check("dich vu: KHONG con xoa sach docroot (deleteRecursively) trong prepareRuntimeIfNeeded", "deleteRecursively" not in body)
        check("dich vu: ham unzip cu (khong gop de) da bi go", "private fun unzip(" not in svc)
        check("Kotlin: bo xoa khong theo symlink (walkFileTree, khong FOLLOW_LINKS) - khong dung deleteRecursively trong logic",
              "walkFileTree" in kt and not re.search(r"(?<!NO)FOLLOW_LINKS", kt) and not re.search(r"^[^*/\n]*\.deleteRecursively\(", kt, re.M))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
    sys.exit(1 if fail_n else 0)

if __name__ == "__main__":
    main()
