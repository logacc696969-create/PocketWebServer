#!/usr/bin/env python3
"""Bang doi chieu 285 muc 2 PDF voi code (HANDOFF.md muc 1bp-M): moi muc co dong, bang chung co that, tai lieu sinh ra khong cu, co doi chung am."""
import copy, os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "tools"))
import pdf_traceability as P
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
items = P.load_items()
check("PDF1 co 86 muc, PDF2 co 199 muc (danh sach trong repo)", len(items[1]) == 86 and len(items[2]) == 199)
errs = P.verify()
check("MOI muc cua 2 PDF deu co dong; moi dong DONE/PARTIAL co bang chung THAT (tep ton tai + ky hieu co that): %s" % errs[:3], errs == [])
check("khong con trang thai 'chua ra' - chi 6 trang thai da dinh nghia", {s for s, _n, _e in P.ROWS.values()} <= set(P.ORDER))
check("DONE/PARTIAL deu co it nhat 1 bang chung; DECLINED deu co ly do", all(e for s, _n, e in P.ROWS.values() if s in ("DONE", "PARTIAL")) and all(n for s, n, _e in P.ROWS.values() if s == "DECLINED"))
doc = open(os.path.join(ROOT, "docs/PDF_TRACEABILITY.md"), encoding="utf-8").read()
check("docs/PDF_TRACEABILITY.md == ban sinh ra tu bang (khong bi cu; sua bang thi phai chay --write)", doc == P.render())
check("tai lieu neu ro 'Da lam' KHONG co nghia da chay thu tren dien thoai that", "KHÔNG có nghĩa đã chạy thử trên điện thoại thật" in doc)
c = P.counts(); tot = sum(c.values())
check("tong 285 dong = 86 + 199", tot == 285)
h = open(os.path.join(ROOT, "HANDOFF.md"), encoding="utf-8").read()
m = re.search(r"### 1bp-M\..*?(?=\n### |\n## )", h, re.S)
sec = m.group(0) if m else ""
want = {s: sum(v for (p, st), v in c.items() if st == s) for s in P.ORDER}
check("HANDOFF 1bp-M ghi DUNG so lieu thuc (Da lam %d, Mot phan %d, Co y khong %d, Chua lam %d, Cho chu du an %d, Khong phai ky thuat %d)" % tuple(want[s] for s in P.ORDER),
      m is not None and all(("%d" % want[s]) in sec for s in P.ORDER) and "KHÔNG" in sec)
# doi chung am
bad = copy.deepcopy(P.ROWS); bad[(2, "S8")] = ("DONE", "x", [("app/src/main/baseline-prof.txt", r"KhongCoChuoiNay")])
orig = P.ROWS; P.ROWS = bad; e1 = P.verify(); P.ROWS = orig
check("DOI CHUNG AM: bang chung sai ky hieu -> bi bat", any("S8" in x for x in e1))
bad = copy.deepcopy(P.ROWS); del bad[(1, "A1")]; P.ROWS = bad; e2 = P.verify(); P.ROWS = orig
check("DOI CHUNG AM: bo sot 1 muc cua PDF -> bi bat", any("THIEU" in x and "A1" in x for x in e2))
bad = copy.deepcopy(P.ROWS); bad[(2, "S8")] = ("DONE", "x", []); P.ROWS = bad; e3 = P.verify(); P.ROWS = orig
check("DOI CHUNG AM: danh dau DONE ma khong co bang chung -> bi bat", any("KHONG co bang chung" in x for x in e3))
check("moi muc 'Cho chu du an' gom Y5 (LICENSE) - chua chon giay phep thi bang noi thang", P.ROWS[(2, "Y5")][0] == "OWNER" and not os.path.exists(os.path.join(ROOT, "LICENSE")))
check("LICENSE_OPTIONS.md co mat va neu thanh phan GPL (MariaDB, Tiny File Manager, WordPress)", all(k in open(os.path.join(ROOT, "docs/LICENSE_OPTIONS.md"), encoding="utf-8").read() for k in ("MariaDB", "Tiny File Manager", "WordPress", "chưa có giấy phép")))
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
