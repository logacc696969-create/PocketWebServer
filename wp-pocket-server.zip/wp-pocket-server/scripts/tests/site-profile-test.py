#!/usr/bin/env python3
"""Kiem thu ho so site (docroot / profile / db_name) - HANDOFF.md muc 1bb: scripts/lib/site_profile.sh + prepare_admin_tools THAT +
menu _admin/index.php render bang PHP + doan SQL khoi tao CSDL + dong bo voi start-lamp.sh.

Phan can mang (Adminer/Tiny File Manager tai tu GitHub) bi bo qua neu khong tai duoc.
"""
import json, os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
sys.path.insert(0, HERE)
import lamp_render as lr

passed = failed = 0
def check(name, cond, detail=''):
    global passed, failed
    if cond: passed += 1; print('PASS:', name)
    else: failed += 1; print('FAIL:', name, ('  -> ' + str(detail)[:260]) if detail != '' else '')

tmp = tempfile.mkdtemp(prefix='site-profile-')
def wr(p, t):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(t)

def lib(fn, *args, cfg=None):
    env = dict(os.environ)
    if cfg is not None:
        c = os.path.join(tmp, 'cfg-%d.json' % abs(hash(json.dumps(cfg, sort_keys=True)))); wr(c, json.dumps(cfg)); env['SITE_CONFIG'] = c
    else:
        env['SITE_CONFIG'] = os.path.join(tmp, 'nonexistent.json')
    r = subprocess.run(['bash', '-c', 'source scripts/lib/site_profile.sh; %s "$@"' % fn, 'x', *args], cwd=ROOT, env=env, capture_output=True, text=True)
    return r.returncode, r.stdout.strip(), r.stderr.strip()

try:
    # ------------------------------------------------------------ docroot
    for raw, want in (('', ''), ('public', 'public'), ('/public/', 'public'), ('./public', 'public'), ('web/public', 'web/public'), ('dist', 'dist'), ('.', ''), ('my.app_v2/pub-lic', 'my.app_v2/pub-lic')):
        rc, out, err = lib('site_docroot_subdir', cfg={'docroot': raw})
        check('docroot %r -> %r' % (raw, want), rc == 0 and out == want, (rc, out, err))
    rc, out, _ = lib('site_docroot_subdir', cfg={})
    check('docroot khong khai bao -> rong (hanh vi cu)', rc == 0 and out == '')
    rc, out, _ = lib('site_docroot_subdir')
    check('khong co file cau hinh -> rong, khong loi', rc == 0 and out == '')
    for bad in ('../etc', 'a/../b', 'a/..', 'a b', 'a;b', 'a"b', 'a$b', 'a//b', 'a/./b', '$(id)', 'a`id`', "a'b", 'a\\b', '-rf', 'a\nb'):
        rc, out, err = lib('site_docroot_subdir', cfg={'docroot': bad})
        check('docroot TU CHOI %r' % bad, rc != 0 and 'LOI' in err and out == '', (rc, out, err))

    # ------------------------------------------------------------ profile
    def tree(name, files=(), dirs=()):
        d = os.path.join(tmp, name); os.makedirs(d)
        for f in files: wr(os.path.join(d, f), 'x')
        for x in dirs: os.makedirs(os.path.join(d, x), exist_ok=True)
        return d
    cases = [
        ('explicit wordpress tren cay Laravel', {'profile': 'wordpress'}, tree('t1', ['composer.json', 'public/index.php']), 'wordpress'),
        ('explicit generic tren cay WordPress', {'profile': 'generic'}, tree('t2', ['wp-includes/version.php']), 'generic'),
        ('auto + type=wordpress', {'site_source': {'type': 'wordpress'}}, tree('t3'), 'wordpress'),
        ('auto + co wp-includes/version.php', {'site_source': {'type': 'local'}}, tree('t4', ['wp-includes/version.php']), 'wordpress'),
        ('auto + co wp-config.php', {'site_source': {'type': 'git'}}, tree('t5', ['wp-config.php']), 'wordpress'),
        ('auto + co thu muc wp-content', {'site_source': {'type': 'zip'}}, tree('t6', [], ['wp-content']), 'wordpress'),
        ('auto + nguon TRONG -> wordpress (giu cai WP 1-click)', {'site_source': {'type': 'local'}}, tree('t7'), 'wordpress'),
        ('auto + chi co .gitkeep -> wordpress', {'site_source': {'type': 'local'}}, tree('t8', ['.gitkeep']), 'wordpress'),
        ('auto + Laravel (composer.json + public/) -> generic', {'site_source': {'type': 'git'}}, tree('t9', ['composer.json', 'public/index.php', 'artisan']), 'generic'),
        ('auto + PHP thuan (index.php) -> generic', {'site_source': {'type': 'local'}}, tree('t10', ['index.php']), 'generic'),
        ('khong khai bao gi + nguon trong -> wordpress (hanh vi cu)', {}, tree('t11'), 'wordpress'),
    ]
    for name, cfg, d, want in cases:
        rc, out, err = lib('site_resolve_profile', d, cfg=cfg)
        check('profile: ' + name, rc == 0 and out == want, (rc, out, err))
    rc, out, err = lib('site_resolve_profile', tree('t12', ['index.php']), cfg={'profile': 'joomla'})
    check('profile TU CHOI gia tri la', rc != 0 and 'LOI' in err, (rc, out, err))

    # ------------------------------------------------------------ db_name
    for prof, cfg, want in (('wordpress', {}, 'wordpress'), ('generic', {}, 'app'), ('generic', {'db_name': 'my_shop'}, 'my_shop'), ('wordpress', {'db_name': 'wordpress'}, 'wordpress'), ('generic', {'db_name': 'A' + 'b' * 31}, 'A' + 'b' * 31)):
        rc, out, err = lib('site_resolve_db_name', prof, cfg=cfg)
        check('db_name %s %s -> %s' % (prof, cfg, want), rc == 0 and out == want, (rc, out, err))
    for prof, name in (('generic', 'mysql'), ('generic', 'Information_Schema'), ('generic', 'sys'), ('generic', '1app'), ('generic', 'my-app'), ('generic', 'a b'), ('generic', "a';DROP"), ('generic', 'a' * 33), ('generic', '`x`'), ('wordpress', 'shop')):
        rc, out, err = lib('site_resolve_db_name', prof, cfg={'db_name': name})
        check('db_name TU CHOI %s/%r' % (prof, name), rc != 0 and 'LOI' in err and out == '', (rc, out, err))

    # ------------------------------------------------------------ file env
    st = os.path.join(tmp, 'envtest'); os.makedirs(st)
    lib('site_write_profile_env', st, 'generic', 'public', 'app')
    r = subprocess.run(['sh', '-c', '. "%s/_supervisor/site-profile.env"; echo "$SITE_PROFILE|$WEB_SUBDIR|$DB_NAME"' % st], capture_output=True, text=True)
    check('site-profile.env doc duoc bang sh (. file) nhu start-lamp.sh', r.stdout.strip() == 'generic|public|app', r)

    # ------------------------------------------------------------ prepare_admin_tools THAT (can mang cho Adminer/TFM)
    ADMIN_WP_ONLY = ['install-wp.php', 'wpcli.php', 'staging.php', 'core-rollback.php', 'safe-mode.php']
    ADMIN_COMMON = ['index.php', 'auth.php', 'info.php', 'logs.php', 'metrics.php', 'analytics.php', 'maintenance.php', '2fa.php', 'sessions.php', 'health.php', 'protect.php']
    def admin(name, sub, profile):
        st = os.path.join(tmp, name); os.makedirs(os.path.join(st, sub) if sub else st)
        r = subprocess.run(['bash', '-c', 'source scripts/lib/admin_tools.sh; prepare_admin_tools "$1" "$2" "$3"', 'x', st, sub, profile], cwd=ROOT, capture_output=True, text=True, timeout=240)
        return st, os.path.join(st, sub, '_admin') if sub else os.path.join(st, '_admin'), r
    st1, ad1, r1 = admin('adm-generic', 'public', 'generic')
    check('generic + docroot public: _admin/ nam BEN TRONG web root (public/_admin), khong o goc du an', r1.returncode == 0 and os.path.isdir(ad1) and not os.path.exists(os.path.join(st1, '_admin')), r1.stderr[-200:])
    have = set(os.listdir(ad1)) if os.path.isdir(ad1) else set()
    check('generic: 5 trang chi danh cho WordPress KHONG duoc trien khai', not (set(ADMIN_WP_ONLY) & have), sorted(set(ADMIN_WP_ONLY) & have))
    check('generic: cac trang dung chung van co (%d)' % len(ADMIN_COMMON), all(f in have for f in ADMIN_COMMON), [f for f in ADMIN_COMMON if f not in have])
    st2, ad2, r2 = admin('adm-wp', '', 'wordpress')
    have2 = set(os.listdir(ad2)) if os.path.isdir(ad2) else set()
    check('wordpress (mac dinh, khong docroot con): du 5 trang WP + trang chung, _admin/ o goc (hanh vi cu)', r2.returncode == 0 and all(f in have2 for f in ADMIN_WP_ONLY + ADMIN_COMMON), [f for f in ADMIN_WP_ONLY + ADMIN_COMMON if f not in have2])
    st3, ad3, r3 = admin('adm-default', '', '')
    check('tham so thu 2/3 de trong -> mac dinh wordpress (tuong thich nguoc voi cach goi cu 1 tham so)', r3.returncode == 0 and 'wpcli.php' in os.listdir(ad3))
    for f in ('index.php',) + tuple(sorted(have & set(ADMIN_COMMON))):
        pass
    bad_lint = [f for f in os.listdir(ad1) if f.endswith('.php') and f not in ('db.php', 'files.php') and subprocess.run(['php', '-l', os.path.join(ad1, f)], capture_output=True).returncode != 0] if os.path.isdir(ad1) else ['?']
    check('moi trang PHP trien khai deu qua php -l', not bad_lint, bad_lint)
    idx_g = open(os.path.join(ad1, 'index.php')).read(); idx_w = open(os.path.join(ad2, 'index.php')).read()
    check("menu duoc nuong ho so: generic -> '__SITE_PROFILE__' da thay, khong con placeholder", "'generic' === 'wordpress'" in idx_g and '__SITE_PROFILE__' not in idx_g and "'wordpress' === 'wordpress'" in idx_w)

    # ---- render menu bang PHP CLI (stub auth.php): 4 tinh huong
    def menu(profile_src, wp_config):
        d = os.path.join(tmp, 'menu-%s-%s' % (profile_src, wp_config)); os.makedirs(d + '/_admin')
        shutil.copy(os.path.join(ad1 if profile_src == 'generic' else ad2, 'index.php'), d + '/_admin/index.php'); wr(d + '/_admin/auth.php', '<?php\n')
        if wp_config: wr(d + '/wp-config.php', '<?php')
        r = subprocess.run(['php', '-d', 'display_errors=0', d + '/_admin/index.php'], capture_output=True, text=True, env=dict(os.environ, APP_HOME=os.path.join(tmp, 'apphome')))
        return r.stdout
    WPS = ('WP-CLI', 'wpcli.php', 'staging.php', 'core-rollback.php', 'safe-mode.php', 'install-wp.php')
    mg = menu('generic', False)
    check('menu generic (khong co wp-config.php): KHONG con nut "Cai WordPress", WP-CLI, Staging, Rollback, Che do an toan', len(mg) > 500 and not [w for w in WPS if w in mg], [w for w in WPS if w in mg])
    check('menu generic van co Database (Adminer), File Manager, Nhat ky, Bao tri', all(x in mg for x in ('db.php', 'files.php', 'logs.php', 'maintenance.php')), [x for x in ('db.php', 'files.php', 'logs.php', 'maintenance.php') if x not in mg])
    mw0 = menu('wordpress', False)
    check('menu wordpress CHUA cai: co the nut "Cai WordPress" (install-wp.php) + WP-CLI/Staging/Rollback (hanh vi cu)', all(x in mw0 for x in ('install-wp.php', 'wpcli.php', 'staging.php', 'core-rollback.php')), [x for x in ('install-wp.php', 'wpcli.php', 'staging.php', 'core-rollback.php') if x not in mw0])
    mw1 = menu('wordpress', True)
    check('menu wordpress DA cai (co wp-config.php): co che do an toan, KHONG con nut cai WordPress', 'safe-mode.php' in mw1 and 'install-wp.php' not in mw1)
    mg1 = menu('generic', True)
    check('generic dung khi vo tinh co file wp-config.php: van KHONG hien trang WordPress (ho so quyet dinh, khong doan)', not [w for w in WPS if w in mg1], [w for w in WPS if w in mg1])

    # ---- Tiny File Manager: goc ra khoi web root (can mang)
    f1 = os.path.join(ad1, 'files.php')
    if os.path.isfile(f1) and os.path.getsize(f1) > 100000:
        t1 = open(f1, errors='replace').read()
        check("TFM voi docroot 'public': $root_path tro len 1 cap (thay ca du an: .env, composer.json, vendor/)", "$root_path = realpath($_SERVER['DOCUMENT_ROOT'] . '/..');" in t1, re.findall(r'^\$root_path.*', t1, re.M)[:2])
        check('TFM da sua van la PHP hop le (php -l)', subprocess.run(['php', '-l', f1], capture_output=True).returncode == 0)
        stx, adx, rx = admin('adm-deep', 'web/public', 'generic')
        tx = open(os.path.join(adx, 'files.php'), errors='replace').read() if os.path.isfile(os.path.join(adx, 'files.php')) else ''
        check("TFM voi docroot 'web/public' (2 cap): '/../..'", "realpath($_SERVER['DOCUMENT_ROOT'] . '/../..')" in tx, re.findall(r'^\$root_path.*', tx, re.M)[:2])
        t2 = open(os.path.join(ad2, 'files.php'), errors='replace').read()
        check('TFM khong co docroot con (wordpress): giu nguyen $root_path = $_SERVER[DOCUMENT_ROOT]', "$root_path = $_SERVER['DOCUMENT_ROOT'];" in t2)
    else:
        print('(bo qua 3 kiem tra TFM: khong tai duoc Tiny File Manager - can mang GitHub)')

    # ------------------------------------------------------------ dong bo voi start-lamp.sh
    SL = open(lr.START_LAMP, encoding='utf-8').read()
    check('start-lamp.sh doc site-profile.env va dat mac dinh cu (wordpress / goc / CSDL wordpress) khi thieu file',
          re.search(r'SITE_PROFILE=wordpress\nWEB_SUBDIR=""\nDB_NAME=wordpress\nif \[ -f "\$SUP/site-profile.env" \]; then \. "\$SUP/site-profile.env"; fi', SL) is not None)
    check('start-lamp.sh ghi lamp-run/db-name va lamp-run/site-profile (Kotlin/BackupManager doc)', 'echo "$DB_NAME" > "$RUNDIR/db-name"' in SL and 'echo "$SITE_PROFILE" > "$RUNDIR/site-profile"' in SL)
    check('start-lamp.sh: Lite mode phuc vu WEBROOT (php -S -t "$WEBROOT")', '-t "$WEBROOT" "$SUP/router-lite.php"' in SL)
    for tname in ('nginx.conf.template', 'php-fpm.conf.template'):
        try:
            txt = open(os.path.join(lr.TPLDIR, tname), encoding='utf-8').read()
            vals = {v: '/x' for _, v in lr.sed_pairs(tname)}
            lr.render(txt, tname, vals)
            check('%s: moi placeholder khong-chu-thich deu duoc start-lamp.sh thay (khong lech)' % tname, True)
        except Exception as e:
            check('%s: moi placeholder khong-chu-thich deu duoc start-lamp.sh thay' % tname, False, e)
    nx = open(os.path.join(lr.TPLDIR, 'nginx.conf.template'), encoding='utf-8').read()
    check('nginx: root chinh dung __WEBROOT__; staging van dung __DOCROOT__-staging (WordPress khong doi)', re.search(r'^\s*root __WEBROOT__;', nx, re.M) is not None and '__DOCROOT__-staging' in nx)
    fpm = open(os.path.join(lr.TPLDIR, 'php-fpm.conf.template'), encoding='utf-8').read()
    check('php-fpm: truyen du 6 bien DB_* cho ung dung', all(re.search(r'^env\[%s\] = ' % k, fpm, re.M) for k in ('DB_CONNECTION', 'DB_HOST', 'DB_SOCKET', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD')))

    # ------------------------------------------------------------ SQL khoi tao: render that bang sh (heredoc khong trich dan)
    def render_sql(db):
        script = 'DB_NAME="%s"; DB_USER="%s"; DB_PASS="%s"\ncat <<SQL\n%s\nSQL\n' % (db, db, db, lr.sql_init_block())
        return subprocess.run(['sh', '-c', script], capture_output=True, text=True).stdout
    sw, sa = render_sql('wordpress'), render_sql('app')
    check("SQL cho 'wordpress': tao DB/user/quyen dung ten (dau backtick va '\\_' nguyen ven)", '`wordpress`' in sw and "'wordpress'@'localhost' IDENTIFIED BY 'wordpress'" in sw and '`wordpress\\_%`' in sw, sw[:300])
    check("SQL cho 'app': tao DB/user app, KHONG con ten 'wordpress' o cau lenh nao", '`app`' in sa and "'app'@'localhost'" in sa and '`app\\_%`' in sa and 'wordpress' not in re.sub(r'--.*', '', sa), re.sub(r'--.*', '', sa)[:300])
finally:
    shutil.rmtree(tmp, ignore_errors=True)

print('\nTONG KET: pass=%d fail=%d' % (passed, failed))
sys.exit(1 if failed else 0)
