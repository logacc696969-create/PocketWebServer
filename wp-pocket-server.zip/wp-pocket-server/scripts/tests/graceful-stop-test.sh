#!/bin/sh
# Kiem thu HANH VI THAT (khong mock) cua bo ham "tat sach" trong start-lamp.sh
# (xem HANDOFF.md muc 1au). Trich thang cac ham tu start-lamp.sh nen luon test
# DUNG ma dang chay - khong the lech voi ban sao.
# Chay: sh scripts/tests/graceful-stop-test.sh   (can sh/dash/bash, sleep, kill)
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../runtimes/templates/start-lamp.sh"
W="$(mktemp -d)"; RUNDIR="$W/run"; mkdir -p "$RUNDIR"
log() { echo "  [log] $*"; }
{ sed -n '/^pid_alive() {/,/^cleanup_on_signal() {/p' "$SRC" | sed '$d'
  sed -n '/^stop_requested() {/,/^}/p' "$SRC"; } > "$W/funcs.sh"
[ -s "$W/funcs.sh" ] || { echo "KHONG trich duoc ham tu $SRC"; exit 2; }
. "$W/funcs.sh"
now() { date +%s; }
pass=0; fail=0
ok() { if [ "$1" = 0 ]; then echo "PASS: $2"; pass=$((pass+1)); else echo "FAIL: $2"; fail=$((fail+1)); fi; }
good() { sh -c 'trap "exit 0" TERM; while :; do sleep 1; done' & }

echo "== T1: tien trinh ngoan thoat khi nhan TERM =="
good; P=$!; t0=$(now); stop_one Good $P 10; t1=$(now)
pid_alive $P; [ $? = 1 ]; ok $? "da tat"; [ $((t1-t0)) -le 3 ]; ok $? "nhanh (<=3s)"

echo "== T2: tien trinh bo qua TERM -> SIGKILL sau timeout =="
sh -c 'trap "" TERM; while :; do sleep 1; done' & P=$!
t0=$(now); stop_one Stubborn $P 2; t1=$(now); sleep 1
pid_alive $P; [ $? = 1 ]; ok $? "bi KILL cuong buc"
[ $((t1-t0)) -ge 2 ] && [ $((t1-t0)) -le 5 ]; ok $? "doi ~2s truoc khi KILL"

echo "== T3: PID KHONG phai con cua shell (mariadbd do wake-mariadb.php bat) =="
OTHER=$(sh -c 'sh -c "trap \"sleep 3; exit 0\" TERM; while :; do sleep 1; done" >/dev/null 2>&1 & echo $!')
sleep 1
wait $OTHER 2>/dev/null; [ $? -ne 0 ]; ok $? "xac nhan 'wait' (cach CU) hong voi non-child"
t0=$(now); stop_one NonChild $OTHER 10; t1=$(now)
pid_alive $OTHER; [ $? = 1 ]; ok $? "stop_one tat duoc non-child"
[ $((t1-t0)) -ge 3 ]; ok $? "stop_one THAT SU doi flush ~3s"

echo "== T5: token phien =="
WPP_SESSION=abc123; export WPP_SESSION
stop_requested; [ $? = 1 ]; ok $? "khong co file -> khong dung"
printf OLD999 > "$RUNDIR/stop-requested"
stop_requested; [ $? = 1 ]; ok $? "token CU khong dung nham phien moi"
printf abc123 > "$RUNDIR/stop-requested"
stop_requested; [ $? = 0 ]; ok $? "token khop -> dung"
unset WPP_SESSION
stop_requested; [ $? = 1 ]; ok $? "chay tay (khong co WPP_SESSION) -> khong bao gio dung"

echo "== T6: stop_all_gracefully khi MariaDB 'ngu' + pid moi do wake ghi =="
good; NG=$!; good; FP=$!
sh -c 'trap "sleep 1; exit 0" TERM; while :; do sleep 1; done' & NEWDB=$!
sleep 1; NGINX_PID=$NG; FPM_PID=$FP; MYSQL_PID=999999
echo $NEWDB > "$RUNDIR/mariadb-new-pid"
stop_all_gracefully; sleep 1
pid_alive $NEWDB; [ $? = 1 ]; ok $? "mariadbd moi cung duoc tat, khong mo coi"
pid_alive $NG; [ $? = 1 ]; ok $? "nginx tat"; pid_alive $FP; [ $? = 1 ]; ok $? "php-fpm tat"
[ ! -f "$RUNDIR/mariadb-new-pid" ]; ok $? "don file mariadb-new-pid"

rm -rf "$W"
echo; echo "TONG KET: pass=$pass fail=$fail"; [ $fail = 0 ]
