#!/usr/bin/env python3
"""AH3, AI1, K2 (PDF 2; HANDOFF.md muc 1bq-G): kiem chung docs/GOVERNANCE.md, docs/EXTENDING.md, docs/VIDEO_TUTORIAL_SCRIPT.md khop voi repo.

Khong the kiem noi dung 'hay' bang may; kiem cac dieu KIEM DUOC: duong dan ton tai, danh sach runtime/cong cu admin/kenh thong bao khop ma, tai lieu noi
'khong co plugin loader' dung la khong co loader dong trong ma, ke hoach 'them runtime' chay thu duoc (gia lap them 1 runtime vao validate), moi nhan nut
trong kich ban video la nhan THAT trong strings.xml, thoi gian canh quay tang dan va <= 4 phut, quan tri khong mau thuan voi trang thai LICENSE/TERMS.
"""
import glob, os, re, sys, importlib.util

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
pass_n = fail_n = 0


def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1
        print("PASS:", name)
    else:
        fail_n += 1
        print("FAIL:", name, ("-> %s" % str(extra)[:300]) if extra else "")


def rd(p):
    return open(os.path.join(ROOT, p), encoding="utf-8").read()


gov, ext, vid = rd("docs/GOVERNANCE.md"), rd("docs/EXTENDING.md"), rd("docs/VIDEO_TUTORIAL_SCRIPT.md")

# ---------------------------------------------------------------- duong dan tham chieu
missing = []
for name, text in (("GOVERNANCE", gov), ("EXTENDING", ext), ("VIDEO", vid)):
    for m in re.finditer(r"`([A-Za-z0-9_./${}<>*-]+\.(?:md|py|sh|yml|kt|json|java|php|xml))`", text):
        p = m.group(1)
        if any(c in p for c in "<>*${}") or "values-xx" in p:
            continue
        if ("/" in p or p.endswith(".md")) and not any(os.path.exists(os.path.join(ROOT, base, p)) for base in ("", "docs", "scripts/tests", "scripts/runtimes", "app/src/main/java/com/wppocket/server", "app/src/main/res")):
            missing.append((name, p))
check("moi duong dan tham chieu trong 3 tai lieu deu ton tai", not missing, missing[:6])

# ---------------------------------------------------------------- EXTENDING
spec = importlib.util.spec_from_file_location("apply_preset", os.path.join(ROOT, "scripts/tools/apply_preset.py"))
AP = importlib.util.module_from_spec(spec)
spec.loader.exec_module(AP)
rts = set(AP.RUNTIMES)
check("EXTENDING liet ke dung cac runtime that: %s" % sorted(rts), rts == {"php", "node", "python", "static"} and all(("`%s`" % r) in ext for r in rts))
check("moi runtime co scripts/runtimes/<ten>.sh va dung ham chung generic_* (hoac PHP rieng)", all(os.path.exists(os.path.join(ROOT, "scripts/runtimes/%s.sh" % r)) for r in rts) and all("generic_" in rd("scripts/runtimes/%s.sh" % r) for r in ("node", "python", "static")))
check("EXTENDING chi dan mau python.sh va goi generic_install_supervisor TRUOC make_reproducible_zip (dung thu tu trong python.sh that)", "python.sh" in ext and "generic_install_supervisor" in ext and "make_reproducible_zip" in ext and rd("scripts/runtimes/python.sh").index("generic_install_supervisor") < rd("scripts/runtimes/python.sh").index("make_reproducible_zip"))
cfg = {"config_version": 1, "runtime": "ruby", "port": 8080}
before = AP.validate(dict(cfg))
AP.RUNTIMES = tuple(AP.RUNTIMES) + ("ruby",)
after = AP.validate(dict(cfg))
check("gia lap buoc 2 cua tai lieu: runtime 'ruby' bi validate TU CHOI cho den khi them vao RUNTIMES, sau do hop le", any("runtime" in e for e in before) and not any("runtime" in e for e in after), (before, after))
check("buoc 3: preset-test dem so preset co dinh - tai lieu noi can cap nhat con so", "preset-test.py" in ext and re.search(r"len\(presets\) == \d+", rd("scripts/tests/preset-test.py")) is not None)
adm = sorted(os.path.basename(p) for p in glob.glob(os.path.join(ROOT, "scripts/runtimes/templates/admin-*.php")))
at = rd("scripts/lib/admin_tools.sh")
unref = [a for a in adm if a not in at and a not in ("admin-totp-lib.php",)]
check("moi cong cu admin-*.php (%d tep) duoc admin_tools.sh nhac toi (tai lieu 'chep boi admin_tools.sh' dung)" % len(adm), not unref, unref)
check("kiem thu bao mat admin ton tai va EXTENDING nhac (admin-security-test.py)", os.path.exists(os.path.join(ROOT, "scripts/tests/admin-security-test.py")) and "admin-security-test.py" in ext)
for f in ("TelegramNotifier.kt", "AlertWebhook.kt", "WebhookUploader.kt", "AlertRules.kt"):
    check("kenh thong bao %s co that va duoc EXTENDING nhac" % f, os.path.exists(os.path.join(ROOT, "app/src/main/java/com/wppocket/server", f)) and f in ext)
check("ALERT_EVENTS dinh nghia trong MonitorLogic.kt (EXTENDING nhac dung)", "ALERT_EVENTS" in rd("app/src/main/java/com/wppocket/server/MonitorLogic.kt") and "ALERT_EVENTS" in ext)
dyn = [os.path.basename(p) for p in glob.glob(os.path.join(ROOT, "app/src/main/java/**/*.kt"), recursive=True) if re.search(r"DexClassLoader|PathClassLoader|InMemoryDexClassLoader|System\.load\(|Class\.forName\((?!\"com\.wppocket\.server\.)", open(p, encoding="utf-8", errors="replace").read())]
check("EXTENDING noi 'khong co bo nap plugin': dung la khong co nap ma dong (DexClassLoader/PathClassLoader/System.load, Class.forName voi ten ngoai com.wppocket.server.* - CrashLogger chi nap BuildConfig cua chinh app) trong Kotlin", "không có bộ nạp plugin" in ext and not dyn, dyn)

# ---------------------------------------------------------------- GOVERNANCE
for tok in ("BDFL", "CI xanh", "TERMS.md` điều 7", "CHỦ DỰ ÁN QUYẾT", "chưa nhận mã từ bên ngoài", "CLA", "Chỉ chủ dự án", "mất dữ liệu > sập/treo", "PDF_TRACEABILITY.md"):
    check("GOVERNANCE co '%s'" % tok, tok in gov)
check("GOVERNANCE co >= 3 cho trong 'CHU DU AN QUYET' (khong quyet thay)", gov.count("CHỦ DỰ ÁN QUYẾT") >= 3, gov.count("CHỦ DỰ ÁN QUYẾT"))
has_lic = os.path.exists(os.path.join(ROOT, "LICENSE"))
check("khong co LICENSE <=> GOVERNANCE van noi 'chua co LICENSE/chua chon' (khong mau thuan)", has_lic == ("chưa có `LICENSE`" not in gov))
check("GOVERNANCE tro dung toi cong CI: workflow build-apk.yml ton tai va co chay kiem thu", os.path.exists(os.path.join(ROOT, ".github/workflows/build-apk.yml")) and "build-apk.yml" in gov and "for t in" in rd(".github/workflows/build-apk.yml"))
check("TERMS co dieu 7 ma GOVERNANCE tham chieu", "7. **Giai đoạn thử nghiệm miễn phí (beta).**" in rd("TERMS.md"))
check("GOVERNANCE khong hua nhan PR trong khi chua chon giay phep: CONTRIBUTING khong moi gui pull request", not re.search(r"(?i)pull request|gửi PR|mở PR", rd("CONTRIBUTING.md")) or has_lic)

# ---------------------------------------------------------------- VIDEO
vi = rd("app/src/main/res/values/strings.xml")
labels_real = {}
for m in re.finditer(r'<string name="([a-z_0-9]+)"[^>]*>(.*?)</string>', vi, re.S):
    labels_real[m.group(2).replace("\\'", "'").replace("&gt;", ">").replace("&lt;", "<").replace("&amp;", "&")] = m.group(1)
quoted = re.findall(r"「([^」]+)」", vid)
bad = [q for q in quoted if q not in labels_real]
check("moi nhan 「...」 trong kich ban video (%d nhan) la nhan THAT trong strings.xml tieng Viet" % len(quoted), len(quoted) >= 12 and not bad, bad)
rows = re.findall(r"^\| (\d+) \((\d+):(\d\d)\) \|(.*)\|(.*)\|\s*$", vid, re.M)
check("co >= 18 canh quay, moi canh 3 cot (canh, hinh, loi thoai) khong rong", len(rows) >= 18 and all(r[3].strip() and r[4].strip() for r in rows), len(rows))
videos = vid.split("## Video ")[1:]
ok_t = True
ends = []
for v in videos:
    ts = [int(m.group(2)) * 60 + int(m.group(3)) for m in re.finditer(r"^\| (\d+) \((\d+):(\d\d)\)", v, re.M)]
    ns = [int(m.group(1)) for m in re.finditer(r"^\| (\d+) \(", v, re.M)]
    if not ts or ts[0] != 0 or ts != sorted(set(ts)) or ns != list(range(1, len(ns) + 1)) or ts[-1] >= 240:
        ok_t = False
    ends.append(ts[-1] if ts else -1)
check("3 video: canh danh so 1..n, moc thoi gian tang dan tu 0:00, canh cuoi < 4:00 (moi video <= 4 phut)", len(videos) == 3 and ok_t, ends)
hint = re.search(r'<string name="alert_rules_hint">([^<]*)</string>', vi).group(1).replace("&gt;", ">")
check("quy tac mau trong video 3 giong het goi y trong app (alert_rules_hint)", ("`" + hint + "`") in vid, hint)
check("lenh wppocket trong video ton tai va dung cu phap that (status, --check)", os.path.exists(os.path.join(ROOT, "scripts/tools/wppocket_cli.py")) and "wppocket_cli.py status" in vid and "--check" in vid)
check("video noi ro ban THU NGHIEM va khong dung cho site quan trong (khop BETA_PROGRAM)", "thử nghiệm miễn phí" in vid and "đừng dùng cho site quan trọng" in vid.lower())
check("kich ban nhac che token/IP/mat khau truoc khi dang", "làm mờ" in vid and "token/IP/mật khẩu" in vid)

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(0 if fail_n == 0 else 1)
