#!/bin/bash
# Kiem thu make_reproducible_zip (HANDOFF.md muc 1ay): cung noi dung -> cung BYTE, du thu tu tao file/mtime khac nhau.
# Chay: sh scripts/tests/reproducible-zip-test.sh   (can bash, zip, unzip)
HERE="$(cd "$(dirname "$0")" && pwd)"
command -v zip >/dev/null && command -v unzip >/dev/null || { echo "(bo qua: thieu zip/unzip)"; exit 0; }
W="$(mktemp -d)"; pass=0; fail=0
ok() { if [ "$1" = 0 ]; then echo "PASS: $2"; pass=$((pass+1)); else echo "FAIL: $2"; fail=$((fail+1)); fi; }
mk1() { mkdir -p "$1/wp-content/uploads" "$1/empty-dir" "$1/_admin"
        printf 'a' > "$1/a.php"; printf 'bb' > "$1/wp-content/uploads/x.jpg"; printf '#!/bin/sh\n' > "$1/run.sh"; chmod 755 "$1/run.sh"
        printf 'c' > "$1/_admin/z.php"; printf 'real' > "$1/real.txt"; ln -s real.txt "$1/link.txt"; }
mk2() { mkdir -p "$1/_admin" "$1/empty-dir" "$1/wp-content/uploads"   # THU TU TAO NGUOC
        printf 'c' > "$1/_admin/z.php"; printf '#!/bin/sh\n' > "$1/run.sh"; chmod 755 "$1/run.sh"; printf 'bb' > "$1/wp-content/uploads/x.jpg"
        printf 'real' > "$1/real.txt"; ln -s real.txt "$1/link.txt"; printf 'a' > "$1/a.php"; }
mk1 "$W/t1"; mk2 "$W/t2"
touch -d '2001-02-03 04:05:06' "$W/t1/a.php"; touch -d '2024-12-31 23:59:59' "$W/t2/a.php"; sleep 1.2
# DOI CHUNG AM - phai chay TRUOC make_reproducible_zip (ham do dat lai mtime cua cay nguon): lenh cu `zip -qr` tren 2 cay
# CUNG NOI DUNG (chi khac mtime cua a.php, nhu 2 lan checkout/tai khac nhau) cho zip KHAC nhau.
mkdir -p "$W/out"
(cd "$W/t1" && zip -qr "$W/out/old1.zip" .); (cd "$W/t2" && zip -qr "$W/out/old2.zip" .)
[ "$(sha256sum < "$W/out/old1.zip")" != "$(sha256sum < "$W/out/old2.zip")" ]; ok $? "DOI CHUNG AM: lenh cu 'zip -qr' tren 2 cay cung noi dung (khac mtime) cho zip KHAC nhau - day la loi that"
. "$HERE/../lib/reproducible_zip.sh"
mkdir -p "$W/out"
SOURCE_DATE_EPOCH=1700000000 make_reproducible_zip "$W/t1" "$W/out/1.zip"
SOURCE_DATE_EPOCH=1700000000 make_reproducible_zip "$W/t2" "$W/out/2.zip"
[ "$(sha256sum < "$W/out/1.zip")" = "$(sha256sum < "$W/out/2.zip")" ]; ok $? "2 cay co CUNG noi dung nhung KHAC thu tu tao file va mtime -> zip GIONG TUNG BYTE"
mkdir "$W/x" && (cd "$W/x" && unzip -q ../out/1.zip)
[ -f "$W/x/a.php" ] && [ -f "$W/x/wp-content/uploads/x.jpg" ] && [ -f "$W/x/_admin/z.php" ]; ok $? "giai nen dung day du file"
[ -d "$W/x/empty-dir" ]; ok $? "giu thu muc rong"
[ -x "$W/x/run.sh" ]; ok $? "giu bit thuc thi"
[ -f "$W/x/link.txt" ] && [ "$(cat "$W/x/link.txt")" = "real" ]; ok $? "symlink duoc theo nhu hanh vi cu (zip khong dung -y)"
SOURCE_DATE_EPOCH=1800000000 make_reproducible_zip "$W/t1" "$W/out/3.zip"
[ "$(sha256sum < "$W/out/1.zip")" != "$(sha256sum < "$W/out/3.zip")" ]; ok $? "doi SOURCE_DATE_EPOCH -> zip khac (mtime thuc su duoc dat theo bien nay)"
unzip -l "$W/out/1.zip" | grep -q "2023-11-1[45]"; ok $? "mtime trong zip = SOURCE_DATE_EPOCH (1700000000 = 2023-11-14/15)"
rm -rf "$W"; echo; echo "TONG KET: pass=$pass fail=$fail"; [ $fail = 0 ]
