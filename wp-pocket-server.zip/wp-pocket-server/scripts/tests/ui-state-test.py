#!/usr/bin/env python3
"""J6 (HANDOFF.md muc 1bp-K): trang thai nut Bat/Tat. Nut Tat KHONG BAO GIO bi khoa boi vong lam moi (de dung duoc server crash-loop)."""
import os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
ma = open(os.path.join(ROOT, "app/src/main/java/com/wppocket/server/MainActivity.kt"), encoding="utf-8").read()
ok = lambda n, c: (print(("PASS: " if c else "FAIL: ") + n), c)[1]
r = [ok("vong lam moi khoa nut Bat khi server dang chay (btnStart.isEnabled = !running)", "binding.btnStart.isEnabled = !running" in ma),
     ok("KHONG dong nao tat nut Tat (btnStop.isEnabled = false/!running/...) - dung duoc server crash-loop/dang khoi dong", not re.search(r"btnStop\.isEnabled\s*=\s*(false|!)", ma) and not re.search(r"btnStop\.isEnabled\s*=\s*running", ma)),
     ok("setBusyButtonsEnabled khong dong toi nut Bat/Tat (backup khong duoc chan viec dung server)", not re.search(r"fun setBusyButtonsEnabled\(.*?\n    \}", ma, re.S) or "btnStop" not in re.search(r"fun setBusyButtonsEnabled\(.*?\n    \}", ma, re.S).group(0))]
print("\nTONG KET: pass=%d fail=%d" % (sum(r), len(r) - sum(r))); sys.exit(0 if all(r) else 1)
