#!/usr/bin/env python3
"""Kiem thu IPv6 co dieu kien (HANDOFF.md muc 1bi).
Phan 1 (shell, chay duoc moi noi): trich DOAN MA THAT tu start-lamp.sh, chay voi php CLI gia (thanh cong/that bai/khong co) -> file ipv6-listen.conf
  chi duoc ghi khi bind duoc; DISABLE_IPV6=1 tat han; khong co php cli thi an toan = chi IPv4.
Phan 2 (nginx that + IPv6 loopback): IPv6 CHI nhan nguon loopback/link-local/ULA - nguon khac bi cat (444). Doi chung: bo '::1/128 1;' khoi geo thi
  chinh ket noi tu [::1] phai bi cat (chung minh nhanh chan THAT SU chay); khong co file ipv6-listen.conf thi KHONG nghe IPv6 va IPv4 van chay.
Can: sh (phan 1); nginx + python IPv6 loopback (phan 2). Thieu thi bo qua phan do."""
import http.client, os, re, shutil, socket, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TPLDIR = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
PASS = FAIL = 0
def check(n, c, d=''):
    global PASS, FAIL
    if c: PASS += 1; print('PASS: ' + n)
    else: FAIL += 1; print('FAIL: ' + n + (('  -> ' + str(d)[:200]) if d else ''))

def phase1():
    print('== Phan 1: doan ma that trong start-lamp.sh ==')
    src = open(os.path.join(TPLDIR, 'start-lamp.sh'), encoding='utf-8').read()
    m = re.search(r'(# --- IPv6 co dieu kien.*?)\n# --- nginx ---', src, re.S)
    check('trich duoc doan IPv6 tu start-lamp.sh', bool(m))
    if not m: return
    seg = m.group(1)
    tmp = tempfile.mkdtemp(prefix='ipv6sh-')
    try:
        def run(php_script, disable=None, port='8080'):
            d = tempfile.mkdtemp(dir=tmp); binp = os.path.join(d, 'bin'); rundir = os.path.join(d, 'run'); os.makedirs(binp); os.makedirs(rundir)
            if php_script is not None:
                open(os.path.join(binp, 'libphpcli.so'), 'w').write('#!/bin/sh\n' + php_script + '\n'); os.chmod(os.path.join(binp, 'libphpcli.so'), 0o755)
            open(os.path.join(d, 'seg.sh'), 'w').write('log() { echo "$*" >> "$RUNDIR/log.txt"; }\n' + seg + '\n')
            env = dict(os.environ, BIN=binp, RUNDIR=rundir, PORT=port); env.pop('DISABLE_IPV6', None)
            if disable is not None: env['DISABLE_IPV6'] = disable
            subprocess.run(['sh', os.path.join(d, 'seg.sh')], env=env, capture_output=True)
            f = os.path.join(rundir, 'ipv6-listen.conf')
            return (open(f).read() if os.path.exists(f) else None), (open(os.path.join(rundir, 'log.txt')).read() if os.path.exists(os.path.join(rundir, 'log.txt')) else '')
        c, lg = run('exit 0')
        check('bind IPv6 thu duoc -> ghi dung "listen [::]:PORT;"', c == 'listen [::]:8080;\n', c)
        check('...va ghi log ro rang', 'IPv6: bind thu duoc' in lg, lg)
        c, lg = run('exit 1')
        check('bind IPv6 that bai -> KHONG ghi file (chi IPv4 nhu truoc)', c is None, c)
        c, lg = run('exit 0', disable='1')
        check('DISABLE_IPV6=1 -> KHONG ghi file du bind duoc', c is None, c)
        c, lg = run(None)
        check('khong co libphpcli.so -> an toan: KHONG ghi file', c is None, c)
        c, lg = run('exit 0', port='9090')
        check('dung bien PORT', c == 'listen [::]:9090;\n', c)
        d = tempfile.mkdtemp(dir=tmp); os.makedirs(os.path.join(d, 'run')); open(os.path.join(d, 'run', 'ipv6-listen.conf'), 'w').write('listen [::]:1;\n')
        open(os.path.join(d, 'seg.sh'), 'w').write('log() { :; }\n' + seg + '\n')
        subprocess.run(['sh', os.path.join(d, 'seg.sh')], env=dict(os.environ, BIN=os.path.join(d, 'bin'), RUNDIR=os.path.join(d, 'run'), PORT='8080'), capture_output=True)
        check('file cu cua lan chay truoc bi XOA khi lan nay khong bind duoc (khong "de lai" IPv6 sau khi may doi mang)', not os.path.exists(os.path.join(d, 'run', 'ipv6-listen.conf')))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def phase2():
    print('== Phan 2: nginx that + IPv6 loopback ==')
    nginx = shutil.which('nginx')
    if not nginx: print('(bo qua phan 2: thieu nginx)'); return
    try:
        t = socket.socket(socket.AF_INET6); t.bind(('::1', 0)); t.close()
    except OSError:
        print('(bo qua phan 2: may nay khong bind duoc ::1)'); return
    def get(port, host, path='/'):
        c = http.client.HTTPConnection(host, port, timeout=10)
        try:
            c.request('GET', path); r = c.getresponse(); b = r.read().decode('utf-8', 'replace'); return r.status, b
        finally: c.close()
    def start(tweak=None, with_file=True):
        tmp = tempfile.mkdtemp(prefix='ipv6ng-'); os.chmod(tmp, 0o755)
        doc, run = os.path.join(tmp, 'www'), os.path.join(tmp, 'run'); os.makedirs(doc); os.makedirs(run); os.makedirs(os.path.join(tmp, 'stg'))
        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        s = socket.socket(); s.bind(('127.0.0.1', 0)); sport = s.getsockname()[1]; s.close()
        conf = open(os.path.join(TPLDIR, 'nginx.conf.template'), encoding='utf-8').read()
        if tweak: conf = tweak(conf)
        for k, v in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)),
                     ('__FPM_SOCK__', os.path.join(run, 'x.sock')), ('__CF_REALIP_DIRECTIVES__', ''), ('__STAGING_DOCROOT__', os.path.join(tmp, 'stg'))):
            conf = conf.replace(k, v)
        open(os.path.join(tmp, 'nginx.conf'), 'w').write(conf)
        open(os.path.join(run, 'ban-list.conf'), 'a').close()   # geo include (HANDOFF.md muc 1br) can file ton tai luc nginx khoi dong
        for mm in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)): os.makedirs(mm, exist_ok=True)
        open(os.path.join(doc, 'index.html'), 'w').write('IPV6-OK')
        if with_file: open(os.path.join(run, 'ipv6-listen.conf'), 'w').write('listen [::]:%d;\n' % port)
        p = subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        return tmp, port, p
    def stop(tmp, p):
        p.terminate()
        try: p.wait(timeout=5)
        except Exception: p.kill()
        shutil.rmtree(tmp, ignore_errors=True)

    tmp, port, p = start()
    try:
        r4 = get(port, '127.0.0.1'); check('IPv4 van chay khi bat IPv6', r4[0] == 200 and 'IPV6-OK' in r4[1], r4)
        try: r6 = get(port, '::1')
        except Exception as e: r6 = ('loi', str(e))
        check('IPv6 qua [::1] (loopback) DUOC nhan va phuc vu', r6[0] == 200 and 'IPV6-OK' in r6[1], r6)
    finally: stop(tmp, p)

    tmp, port, p = start(tweak=lambda c: c.replace('        ::1/128 1;\n', ''))
    try:
        try: r = get(port, '::1'); got = r
        except Exception as e: got = ('cat ket noi', type(e).__name__)
        check('DOI CHUNG: nguon IPv6 KHONG nam trong geo (bo ::1) -> bi cat (444), khong phuc vu', got[0] != 200 and 'IPV6-OK' not in str(got), got)
        r4 = get(port, '127.0.0.1'); check('...nhung IPv4 van binh thuong (geo chi ap cho nguon IPv6)', r4[0] == 200, r4)
    finally: stop(tmp, p)

    tmp, port, p = start(with_file=False)
    try:
        try: get(port, '::1'); refused = False
        except Exception: refused = True
        check('khong co ipv6-listen.conf -> KHONG nghe IPv6 (ket noi [::1] bi tu choi)', refused)
        r4 = get(port, '127.0.0.1'); check('...va IPv4 van chay', r4[0] == 200, r4)
    finally: stop(tmp, p)

def main():
    phase1(); phase2()
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL)); return 0 if FAIL == 0 else 1
if __name__ == '__main__': sys.exit(main())
