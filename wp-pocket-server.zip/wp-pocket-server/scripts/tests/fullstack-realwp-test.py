#!/usr/bin/env python3
"""Kiem thu HANH VI THAT cua stack du an (HANDOFF.md muc 1ba): nginx + php-fpm + WordPress THAT + MariaDB THAT, dung
nginx.conf.template / php-fpm.conf.template / php.ini.template THAT (dien placeholder y het start-lamp.sh) va cay website do
CHINH fetch_site_source tao.

Tai sao: bang doi chieu PDF DeepSeek chi cho biet "co chu trong file" - nhung F2 (WP-Cron) tung co chu ma chay rong. O day do
HANH VI cua tung ky thuat bang request that: header bao mat, gzip, cache tinh, gioi han upload (nginx / post_max_size /
upload_max_filesize phai khop), memory_limit, timezone, expose_php, realip qua Cloudflare, rate-limit wp-login, xmlrpc, file .bak,
maintenance, robots.txt, sitemap, favicon, cron qua nginx, nhan biet HTTPS sau Cloudflare Tunnel (mixed content / cookie Secure).

Chay: python3 scripts/tests/fullstack-realwp-test.py   (can nginx, php-fpm, MariaDB, jq, unzip + WordPress zip nhu staging-realwp-test.py)
Thieu cong cu -> bo qua (exit 0). NGINX_TPL=<nginx.conf.template khac> de doi chung am.
Loai bo DUY NHAT khi chay tren Ubuntu: dong extension_dir/extension .so cua Termux; fpm.sock mode 0666 + user=root khi chay bang root.
"""
import http.client, importlib.util, json, os, re, shutil, signal, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
TPLDIR = os.path.join(ROOT, 'scripts', 'runtimes', 'templates')
spec = importlib.util.spec_from_file_location('rw', os.path.join(HERE, 'staging-realwp-test.py'))
rw = importlib.util.module_from_spec(spec); spec.loader.exec_module(rw)
sys.path.insert(0, HERE)
import lamp_render as lr

PASS = FAIL = 0
def check(name, cond, detail=''):
    global PASS, FAIL
    if cond: PASS += 1; print('PASS:', name)
    else: FAIL += 1; print('FAIL:', name, ('  -> ' + str(detail)[:230]) if detail != '' else '')
def info(msg): print('INFO:', msg)

class R:
    def __init__(self, status, h, cookies, body): self.status, self.h, self.cookies, self.body = status, h, cookies, body
    @property
    def text(self): return self.body.decode('utf-8', 'replace')

def req(port, method, path, headers=None, body=None, src=None, timeout=90):
    c = http.client.HTTPConnection('127.0.0.1', port, timeout=timeout, source_address=((src, 0) if src else None))
    c.request(method, path, body=body, headers=headers or {})
    r = c.getresponse(); data = r.read()
    out = R(r.status, {k.lower(): v for k, v in r.getheaders()}, r.msg.get_all('Set-Cookie') or [], data); c.close(); return out

def multipart(field, size):
    b = '----wpp' + os.urandom(6).hex()
    head = ('--%s\r\nContent-Disposition: form-data; name="%s"; filename="f.bin"\r\nContent-Type: application/octet-stream\r\n\r\n' % (b, field)).encode()
    tail = ('\r\n--%s--\r\n' % b).encode()
    return {'Content-Type': 'multipart/form-data; boundary=' + b}, head + (b'x' * size) + tail

PROBE = r"""<?php
header('Content-Type: application/json');
if (isset($_GET['sleep'])) { sleep((int)$_GET['sleep']); }
$sizes = []; foreach ($_FILES as $k => $f) { $sizes[$k] = $f['size'] ?? null; $e = $f['error'] ?? null; }
echo json_encode(['remote_addr' => $_SERVER['REMOTE_ADDR'] ?? null, 'https' => $_SERVER['HTTPS'] ?? null,
  'ini' => ['memory_limit' => ini_get('memory_limit'), 'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size'), 'max_execution_time' => ini_get('max_execution_time'),
            'date.timezone' => ini_get('date.timezone'), 'expose_php' => ini_get('expose_php'), 'display_errors' => ini_get('display_errors')],
  'files' => $sizes, 'err' => $e ?? null, 'tz_now' => date('e'), 'x_powered' => array_values(array_filter(headers_list(), fn($h) => stripos($h, 'x-powered-by') === 0))]);
"""

def main():
    nginx = rw.which('nginx'); fpm = rw.which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    mariadbd = rw.which('mariadbd', 'mysqld'); install = rw.which('mariadb-install-db', 'mysql_install_db'); cli = rw.which('mariadb', 'mysql')
    if not all((nginx, fpm, mariadbd, install, cli, rw.which('php'), rw.which('bash'), rw.which('jq'), rw.which('unzip'))):
        print('(bo qua: thieu nginx/php-fpm/MariaDB/jq/unzip)'); return 0
    wpzip = rw.get_wp_zip()
    if not wpzip: print('(bo qua: khong co WordPress zip)'); return 0
    nginx_v = subprocess.run([nginx, '-V'], capture_output=True, text=True); has_realip = 'http_realip_module' in (nginx_v.stdout + nginx_v.stderr)

    tmp = tempfile.mkdtemp(prefix='fullstack-'); os.chmod(tmp, 0o755)
    procs = []; db = None
    try:
        # ---------- cay website that (CHINH fetch_site_source) ----------
        latest = os.path.join(tmp, 'latest.zip'); rw.repack_as_latest_zip(wpzip, latest)
        shim = os.path.join(tmp, 'shim'); os.makedirs(shim)
        keys = ['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT']
        rw.wr(os.path.join(tmp, 'salts.txt'), ''.join("define('%s',%s'%s');\n" % (k, ' ' * (17 - len(k)), os.urandom(24).hex()) for k in keys))
        rw.wr(os.path.join(shim, 'curl'), '#!/bin/sh\nout=""; url=""\nwhile [ $# -gt 0 ]; do case "$1" in -o) out="$2"; shift 2;; -*) shift;; *) url="$1"; shift;; esac; done\n'
              'case "$url" in\n  https://wordpress.org/latest.zip) cp "$WP_ZIP" "$out";;\n  https://api.wordpress.org/secret-key/1.1/salt/) cat "$SALT_FILE";;\n  *) exit 22;;\nesac\n')
        os.chmod(os.path.join(shim, 'curl'), 0o755)
        for p in ('/tmp/wp-extract', '/tmp/wordpress.zip'):
            try: shutil.rmtree(p, ignore_errors=True) if os.path.isdir(p) else (os.path.exists(p) and os.remove(p))
            except OSError: pass
        doc = os.path.join(tmp, 'app', 'www'); app = os.path.join(tmp, 'app'); run = os.path.join(app, 'lamp-run')
        os.makedirs(run); os.makedirs(os.path.join(run, 'php-sessions'))
        env = dict(os.environ, PATH=shim + ':' + os.environ['PATH'], WP_ZIP=latest, SALT_FILE=os.path.join(tmp, 'salts.txt'), SITE_CONFIG=os.path.join(ROOT, 'site.config.json'))
        r = subprocess.run(['bash', '-c', 'set -euo pipefail; source scripts/lib/site_source.sh; fetch_site_source "$1"', 'x', doc], cwd=ROOT, env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=300)
        check('fetch_site_source that tao cay WordPress 6.8.1', r.returncode == 0 and os.path.isfile(os.path.join(doc, 'wp-config.php.template')), r.stderr[-200:])

        # ---------- MariaDB that ----------
        sock = os.path.join(run, 'mysql.sock'); data = os.path.join(tmp, 'data')
        r = subprocess.run([install, '--user=' + rw.DB_OS_USER, '--datadir=' + data, '--auth-root-authentication-method=normal'], capture_output=True, text=True)
        if r.returncode != 0: print('(bo qua: khong khoi tao duoc MariaDB: %s)' % r.stderr[-120:]); return 0
        db = subprocess.Popen([mariadbd] + ([] if os.geteuid() != 0 else ['--user=root']) + ['--datadir=' + data, '--socket=' + sock, '--skip-networking', '--pid-file=' + os.path.join(tmp, 'm.pid'),
                               '--innodb-buffer-pool-size=64M', '--log-error=' + os.path.join(tmp, 'err.log'),
                               '--character-set-server=latin1', '--collation-server=latin1_swedish_ci'],  # mo phong mac dinh cua ban MariaDB KHONG co file cau hinh (Ubuntu doc /etc/mysql nen mac dinh utf8mb4)
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            if os.path.exists(sock) and subprocess.run([cli, '--socket=' + sock, '-uroot', '-e', 'select 1'], capture_output=True).returncode == 0: break
            time.sleep(0.5)
        else: print('(bo qua: mariadbd khong len)'); return 0
        def sql(q, dbname=None):
            cmd = [cli, '--socket=' + sock, '--default-character-set=utf8mb4', '-uroot', '-N', '-B', '-e', q] + ([dbname] if dbname else [])
            return subprocess.run(cmd, capture_output=True, text=True).stdout.strip()
        sql("CREATE DATABASE wordpress CHARACTER SET utf8mb4"); sql("CREATE USER 'wordpress'@'localhost' IDENTIFIED BY 'wordpress'"); sql("GRANT ALL ON `wordpress%`.* TO 'wordpress'@'localhost'")
        tpl = os.path.join(doc, 'wp-config.php.template'); cfg_text = open(tpl).read().replace('__MYSQL_SOCK__', sock)
        rw.wr(os.path.join(doc, 'wp-config.php'), cfg_text); os.remove(tpl)

        # ---------- render 3 template THAT y het start-lamp.sh ----------
        port = rw.free_port(); sport = rw.free_port(); fsock = os.path.join(run, 'php-fpm.sock')
        realip = 'set_real_ip_from 127.0.0.1; real_ip_header CF-Connecting-IP; real_ip_recursive off;' if has_realip else '# (bo qua: nginx build nay khong co module realip)'
        # Render bang DANH SACH sed TRICH TU start-lamp.sh (scripts/tests/lamp_render.py) - lech voi start-lamp.sh se loi ngay
        vals = dict(DOCROOT=doc, WEBROOT=doc, PORT=port, STAGING_PORT=sport, FPM_SOCK=fsock, RUNDIR=run, CF_REALIP_LINE=realip,
                    DATA=app, BIN=tmp, MYSQL_SOCK=sock, DB_NAME='wordpress', DB_USER='wordpress', DB_PASS='wordpress')
        ngx = lr.render(open(os.environ.get('NGINX_TPL') or os.path.join(TPLDIR, 'nginx.conf.template'), encoding='utf-8').read(), 'nginx.conf.template', vals)
        if os.geteuid() == 0: ngx = 'user root;\n' + ngx  # chi khi test chay bang root: worker nginx mac dinh la 'nobody' khong doc duoc cay WordPress (tren thiet bi moi tien trinh cung uid)
        rw.wr(os.path.join(tmp, 'nginx.conf'), ngx)
        for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', ngx)): os.makedirs(m, exist_ok=True)
        fpmc = lr.render(open(os.path.join(TPLDIR, 'php-fpm.conf.template'), encoding='utf-8').read(), 'php-fpm.conf.template', vals)
        fpmc = fpmc.replace('listen.mode = 0660', 'listen.mode = 0666')  # chi de nginx worker 'nobody' noi duoc khi test chay bang root
        if os.geteuid() == 0: fpmc = fpmc.replace('[www]\n', '[www]\nuser = root\ngroup = root\n', 1)
        rw.wr(os.path.join(tmp, 'php-fpm.conf'), fpmc)
        ini = open(os.path.join(TPLDIR, 'php.ini.template'), encoding='utf-8').read()
        for k in ('__OPCACHE_ENABLE_LINE__', '__OPCACHE_LOCK_LINE__', '__OPCACHE_MEM_LINE__', '__OPCACHE_FILE_LINE__', '__APCU_EXTENSION_LINE__', '__APCU_ENABLED_LINE__', '__APCU_SHM_SIZE_LINE__', '__APCU_ENABLE_CLI_LINE__', '__AUTO_SLEEP_PREPEND__'): ini = ini.replace(k, '')
        ini = ini.replace('__RUNDIR__', run)
        ini = re.sub(r'^extension_dir\s*=.*$', '', ini, flags=re.M)  # .so Termux khong ton tai tren Ubuntu; MOI thiet lap khac giu nguyen
        # Chi cho TEST: tat WP-Cron tu spawn + chan HTTP ra ngoai (khong co mang)
        rw.wr(os.path.join(tmp, 'prepend.php'), "<?php if (!defined('WP_HTTP_BLOCK_EXTERNAL')) define('WP_HTTP_BLOCK_EXTERNAL', true);\nif (!defined('DISABLE_WP_CRON')) define('DISABLE_WP_CRON', true);\n")
        ini += '\nauto_prepend_file = "%s"\n' % os.path.join(tmp, 'prepend.php')
        rw.wr(os.path.join(tmp, 'php.ini'), ini)
        rw.wr(os.path.join(doc, 'wp-probe.php'), PROBE)

        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'php-fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        nginx_p = subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); procs.append(nginx_p)
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(fsock): break
            time.sleep(0.1)
        H = lambda **k: k  # noqa
        probe = lambda path='', **kw: req(port, 'GET', '/wp-probe.php' + path, **kw)
        pr = probe(); check('stack that len: /wp-probe.php qua nginx -> php-fpm (template that) tra JSON', pr.status == 200 and pr.text.startswith('{'), (pr.status, pr.text[:120]))
        if pr.status != 200:
            for f in ('php-fpm.log', 'nginx-error.log'):
                p = os.path.join(run, f); print('---', f, '---'); print(open(p).read()[-500:] if os.path.exists(p) else '(khong co)')
            return 1
        P = json.loads(pr.text)

        # ---------- cai WordPress that qua nginx ----------
        req(port, 'GET', '/wp-admin/install.php?step=1')
        form = 'weblog_title=Site+Fullstack&user_name=admin&admin_password=Pa55-w0rd-Test-9876%21&admin_password2=Pa55-w0rd-Test-9876%21&pw_weak=1&admin_email=a%40example.com&blog_public=1&Submit=Install+WordPress&language='
        ri = req(port, 'POST', '/wp-admin/install.php?step=2', {'Content-Type': 'application/x-www-form-urlencoded'}, form.encode())
        n = sql("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='wordpress'")
        check('WordPress that cai xong qua nginx (12 bang)', ri.status == 200 and n == '12', (ri.status, n, ri.text[-200:]))
        home = req(port, 'GET', '/', {'Accept-Encoding': 'gzip'}); import gzip
        html = gzip.decompress(home.body).decode('utf-8', 'replace') if home.h.get('content-encoding') == 'gzip' else home.text
        check('trang chu WordPress that qua nginx: 200 + ten site', home.status == 200 and 'Site Fullstack' in html, (home.status, html[:150]))

        print('== A0. Ma hoa/collation (O5): WordPress tu chon utf8mb4 du MariaDB mac dinh la latin1 ==')
        srv_cs = sql("SELECT @@character_set_server")
        cols = sql("SELECT DISTINCT table_collation FROM information_schema.tables WHERE table_schema='wordpress'").split()
        check('12 bang WordPress that deu utf8mb4 (server mac dinh la %s - khong can them co character-set-server)' % srv_cs, bool(cols) and all(c.startswith('utf8mb4_') for c in cols), cols)
        ins = subprocess.run(['php', '-r', "require '%s/wp-load.php'; echo wp_insert_post(['post_title'=>'Tiếng Việt có dấu ơ ư ạ 😀','post_content'=>'Nội dung 😀','post_status'=>'publish']);" % doc], capture_output=True, text=True, env=dict(os.environ, HTTP_HOST='127.0.0.1'))
        rp1 = req(port, 'GET', '/?p=%s' % ins.stdout.strip())
        if rp1.status == 301 and rp1.h.get('location'): rp1 = req(port, 'GET', re.sub(r'^https?://[^/]+', '', rp1.h['location']))  # WordPress chuyen ?p=ID ve permalink
        body_t = rp1.text
        check('tieng Viet co dau + emoji luu va hien thi dung qua nginx/php-fpm/MariaDB (khong thanh ?? hoac mojibake)', 'Tiếng Việt có dấu ơ ư ạ' in body_t, (rp1.status, rp1.h.get('location'), ins.stdout.strip()[:40], ins.stderr[-120:], re.findall(r'<title>[^<]*', body_t)[:1]))

        print('== A. Header bao mat (G3) ==')
        css = next((p for p in ('/wp-includes/css/dashicons.min.css', '/wp-includes/css/buttons.min.css', '/wp-includes/css/admin-bar.min.css') if os.path.exists(doc + p)), None)
        js = '/wp-includes/js/jquery/jquery.min.js'
        SEC = ('x-frame-options', 'x-content-type-options', 'referrer-policy')
        check('HTML (trang chu): du 3 header bao mat', all(k in home.h for k in SEC), {k: home.h.get(k) for k in SEC})
        rc = req(port, 'GET', css, {'Accept-Encoding': 'gzip'}); rj = req(port, 'GET', js)
        check('file TINH (css): CUNG du 3 header bao mat (add_header o location tinh co lam mat header cua server{}?)', all(k in rc.h for k in SEC), {k: rc.h.get(k) for k in SEC})
        check('file TINH (js): X-Content-Type-Options: nosniff', rj.h.get('x-content-type-options') == 'nosniff', rj.h)
        r404 = req(port, 'GET', '/khong-ton-tai-123.css')
        check('trang loi 404 cua file tinh cung co header bao mat', r404.status == 404 and 'x-content-type-options' in r404.h, (r404.status, r404.h))

        print('== B. Nen gzip va cache tinh (I1, I2) ==')
        check('404 cua file tinh KHONG mang Cache-Control immutable/max-age 30 ngay (khong bi trinh duyet/Cloudflare giu 404 sau khi file duoc tao)', r404.status == 404 and 'immutable' not in r404.h.get('cache-control', '') and 'max-age=2592000' not in r404.h.get('cache-control', ''), r404.h.get('cache-control'))
        check('HTML gzip khi client xin gzip, co Vary: Accept-Encoding', home.h.get('content-encoding') == 'gzip' and 'accept-encoding' in home.h.get('vary', '').lower(), home.h)
        check('CSS gzip', rc.h.get('content-encoding') == 'gzip', rc.h)
        check('client khong xin gzip -> khong nen (identity)', req(port, 'GET', css).h.get('content-encoding') is None)
        check('file tinh: Cache-Control public, max-age=2592000, immutable', rc.h.get('cache-control') == 'public, max-age=2592000, immutable', rc.h.get('cache-control'))

        print('== C. Gioi han PHP / upload phai KHOP nginx (O1, O2, O6, R4) ==')
        ini_ = P['ini']
        check('php-fpm that nhan DUNG php.ini.template: memory_limit=128M, max_exec=60, upload=post=32M', ini_['memory_limit'] == '128M' and ini_['max_execution_time'] == '60' and ini_['upload_max_filesize'] == '32M' and ini_['post_max_size'] == '32M', ini_)
        check('timezone = Asia/Ho_Chi_Minh (O6); expose_php tat; display_errors tat', ini_['date.timezone'] == 'Asia/Ho_Chi_Minh' and P['tz_now'] == 'Asia/Ho_Chi_Minh' and ini_['expose_php'] in ('', '0') and ini_['display_errors'] in ('', '0'), (ini_, P['tz_now']))
        check('KHONG co header X-Powered-By (R4)', 'x-powered-by' not in pr.h and P['x_powered'] == [], pr.h)
        check("nginx client_max_body_size (32m) >= PHP post_max_size (32M): 3 chi so khop nhau", re.search(r'client_max_body_size\s+32m;', ngx) is not None and ini_['post_max_size'] == '32M')
        mh, mb = multipart('f', 3 * 1024 * 1024); r3 = req(port, 'POST', '/wp-probe.php', mh, mb)
        check('upload 3MB (WordPress hay gap) QUA nginx+PHP, PHP nhan du 3MB', r3.status == 200 and json.loads(r3.text)['files'].get('f') == 3 * 1024 * 1024, (r3.status, r3.text[:150]))
        mh, mb = multipart('f', 31 * 1024 * 1024); r31 = req(port, 'POST', '/wp-probe.php', mh, mb)
        check('upload 31MB (sat tran 32M) van qua: PHP nhan du', r31.status == 200 and json.loads(r31.text)['files'].get('f') == 31 * 1024 * 1024, (r31.status, r31.text[:150]))
        mh, mb = multipart('f', 33 * 1024 * 1024); r33 = req(port, 'POST', '/wp-probe.php', mh, mb)
        check('upload 33MB (vuot tran): nginx tra 413, khong lang le cat cut', r33.status == 413, r33.status); del mb

        print('== D. IP that qua Cloudflare (O7) va rate limit dang nhap (A6) ==')
        if has_realip:
            ra = json.loads(probe(headers={'CF-Connecting-IP': '203.0.113.7'}).text)
            check('tu cloudflared (127.0.0.1) co CF-Connecting-IP -> PHP thay IP khach that', ra['remote_addr'] == '203.0.113.7', ra['remote_addr'])
            rb = json.loads(probe(headers={'CF-Connecting-IP': '203.0.113.7'}, src='127.0.0.2').text)
            check('tu nguon KHONG tin cay (127.0.0.2) gia mao CF-Connecting-IP -> BI BO QUA (khong cho khach tu dat IP)', rb['remote_addr'] == '127.0.0.2', rb['remote_addr'])
        else:
            info('nginx build nay khong co module realip -> bo qua 2 kiem tra IP that (start-lamp.sh cung bo qua, ghi canh bao)')
        codes = [req(port, 'GET', '/wp-login.php', src='127.0.0.5').status for _ in range(9)]
        check('rate limit wp-login 5r/m burst=3: vai request dau qua, cac request sau bi chan (503)', codes[:4].count(200) >= 3 and codes[-1] == 503, codes)

        print('== E. Chan file/duong dan nhay cam, xmlrpc, favicon, sitemap (G2, R1-R3) ==')
        for rel, content in (('x.bak', 'S'), ('wp-config.php.old', 'S'), ('.env', 'S'), ('.git/config', 'S'), ('site.template', 'S'), ('a.swp', 'S')): rw.wr(os.path.join(doc, rel), content)
        for p in ('/x.bak', '/wp-config.php.old', '/.env', '/.git/config', '/site.template', '/a.swp'):
            rr = req(port, 'GET', p); check('chan %s -> 403' % p, rr.status == 403 and 'S' != rr.text, rr.status)
        check('GET /wp-config.php truc tiep: khong lo noi dung (PHP chay, tra rong)', 'DB_PASSWORD' not in req(port, 'GET', '/wp-config.php').text)
        check('xmlrpc.php -> 403 (G2)', req(port, 'GET', '/xmlrpc.php').status == 403 and req(port, 'POST', '/xmlrpc.php', {'Content-Type': 'text/xml'}, b'<methodCall/>').status == 403)
        check('/favicon.ico khong co file -> 204 (khong 404 lam ban log)', req(port, 'GET', '/favicon.ico').status == 204)
        rs = req(port, 'GET', '/wp-sitemap.xml'); check('wp-sitemap.xml (sitemap ao cua WordPress) qua nginx: 200 + XML', rs.status == 200 and ('<sitemapindex' in rs.text or '<urlset' in rs.text), (rs.status, rs.text[:100]))

        print('== F. robots.txt, bao tri, cron qua nginx (G6, A8, F2) ==')
        rt = req(port, 'GET', '/robots.txt'); check('Quick Tunnel (khong co tunnel-named): robots.txt chan toan bo', rt.status == 200 and 'Disallow: /\n' in rt.text and 'wp-admin' not in rt.text, rt.text)
        rw.wr(os.path.join(run, 'tunnel-named'), '1'); time.sleep(2.6)
        rt = req(port, 'GET', '/robots.txt'); check('Named Tunnel (co tunnel-named): robots.txt do WordPress sinh (cho phep index)', rt.status == 200 and 'wp-admin' in rt.text, rt.text[:100])
        os.remove(os.path.join(run, 'tunnel-named'))
        rw.wr(os.path.join(run, 'maintenance-mode'), '1'); time.sleep(2.6)
        rm = req(port, 'GET', '/'); check('bat maintenance-mode: trang chu 503 + trang bao tri tieng Viet', rm.status == 503 and 'bao tri' in rm.text.lower(), (rm.status, rm.text[:80]))
        check('maintenance: wp-login cung 503; header bao mat van co tren trang 503', req(port, 'GET', '/wp-login.php', src='127.0.0.6').status == 503 and 'x-frame-options' in rm.h, rm.h)
        os.remove(os.path.join(run, 'maintenance-mode')); time.sleep(2.6)
        check('tat maintenance-mode: site tro lai 200 sau ~2s (open_file_cache_valid)', req(port, 'GET', '/').status == 200)
        due = subprocess.run(['php', '-r', "require '%s/wp-load.php'; wp_clear_scheduled_hook('wp_pocket_test'); wp_schedule_single_event(time()-30,'wp_pocket_test'); echo count(array_filter((array)_get_cron_array(), fn($h)=>isset($h['wp_pocket_test'])));" % doc],
                             capture_output=True, text=True, env=dict(os.environ, HTTP_HOST='127.0.0.1'))
        rcron = req(port, 'GET', '/wp-cron.php')
        left = subprocess.run(['php', '-r', "require '%s/wp-load.php'; echo count(array_filter((array)_get_cron_array(), fn($h)=>isset($h['wp_pocket_test'])));" % doc], capture_output=True, text=True, env=dict(os.environ, HTTP_HOST='127.0.0.1')).stdout.strip()
        check('wp-cron.php qua nginx+php-fpm that: su kien den han DUOC CHAY (cron that, khong tham so)', rcron.status == 200 and due.stdout.strip() == '1' and left == '0', (rcron.status, due.stdout[-80:], left))

        print('== G. Nhan biet HTTPS sau Cloudflare Tunnel (mixed content) ==')
        tun = 'abc-def.trycloudflare.com'
        sql("UPDATE wp_options SET option_value='https://%s' WHERE option_name IN ('siteurl','home')" % tun, 'wordpress')
        rw.bump_object_cache_epoch(app)   # sua wp_options bang SQL (nhu Adminer): san pham bao hieu cache APCu qua POST db.php (HANDOFF.md muc 1bd)
        CF = {'Host': tun, 'X-Forwarded-Proto': 'https', 'CF-Visitor': '{"scheme":"https"}', 'CF-Connecting-IP': '203.0.113.20'}
        pj = json.loads(probe(headers=CF).text)
        check('PHP thay $_SERVER[HTTPS]=on khi Cloudflare gui X-Forwarded-Proto: https', pj['https'] == 'on', pj['https'])
        pl = json.loads(probe(headers={'Host': tun}).text)
        check('khong co X-Forwarded-Proto (truy cap LAN http): HTTPS KHONG bi bat', pl['https'] in (None, ''), pl['https'])
        # --- HSTS co dieu kien (HANDOFF 1be): chi khi that su qua HTTPS Cloudflare; LAN http:// khong duoc nhan (RFC 6797 muc 7.2) ---
        HS = 'strict-transport-security'
        r_cf = req(port, 'GET', '/', CF)
        check('HSTS: qua Cloudflare https -> Strict-Transport-Security: max-age=2592000 (khong includeSubDomains/preload)', r_cf.h.get(HS) == 'max-age=2592000', r_cf.h.get(HS))
        r_lan = req(port, 'GET', '/', {'Host': tun})
        check('HSTS: truy cap LAN http (khong X-Forwarded-Proto) -> KHONG co header', HS not in r_lan.h, r_lan.h.get(HS))
        r_http = req(port, 'GET', '/', {'Host': tun, 'X-Forwarded-Proto': 'http'})
        check('HSTS: X-Forwarded-Proto: http -> KHONG co header', HS not in r_http.h, r_http.h.get(HS))
        CSP = 'content-security-policy'
        check("CSP tap con an toan: trang HTML co 'frame-ancestors 'self'' va 'base-uri 'self'' (qua Cloudflare va LAN)", all(rx.h.get(CSP) == "frame-ancestors 'self'; base-uri 'self'" for rx in (r_cf, r_lan)), (r_cf.h.get(CSP), r_lan.h.get(CSP)))
        check('CSP KHONG chan script/style: khong co default-src/script-src/style-src/object-src (se vo wp-admin)', not any(d in (r_cf.h.get(CSP) or '') for d in ('default-src', 'script-src', 'style-src', 'object-src')), r_cf.h.get(CSP))
        r_cf_css = req(port, 'GET', css, CF)
        check('HSTS: file TINH qua https cung co header (add_header o location tinh tat ke thua tu server{})', r_cf_css.h.get(HS) == 'max-age=2592000', r_cf_css.h.get(HS))
        r_cf_404 = req(port, 'GET', '/khong-ton-tai-123.css', CF)
        check('HSTS: 404 cua file tinh qua https van co header (always)', r_cf_404.status == 404 and r_cf_404.h.get(HS) == 'max-age=2592000', (r_cf_404.status, r_cf_404.h.get(HS)))
        r_lan_css = req(port, 'GET', css, {'Host': tun})
        check('HSTS: file TINH qua LAN http -> KHONG co header', HS not in r_lan_css.h, r_lan_css.h.get(HS))
        rh = req(port, 'GET', '/', dict(CF, **{'Accept-Encoding': 'gzip'}))
        page = gzip.decompress(rh.body).decode('utf-8', 'replace') if rh.h.get('content-encoding') == 'gzip' else rh.text
        urls = re.findall(r"""(?:src|href)=["'](https?://%s[^"']*)""" % re.escape(tun), page)
        httpu = [u for u in urls if u.startswith('http://')]
        check('trang chu qua tunnel https: moi URL tai nguyen cua site la https:// (khong mixed content) [%d URL]' % len(urls), rh.status == 200 and len(urls) > 3 and not httpu, (rh.status, len(urls), httpu[:3]))
        rl = req(port, 'GET', '/wp-login.php', CF, src='127.0.0.7')
        lurls = re.findall(r"""(?:src|href|action)=["'](https?://%s[^"']*)""" % re.escape(tun), rl.text)
        check('wp-login.php qua tunnel: URL (form/css/js) deu https://', rl.status == 200 and lurls and not [u for u in lurls if u.startswith('http://')], (rl.status, rl.h.get('location'), [u for u in lurls if u.startswith('http://')][:3]))
        lh = dict(CF, **{'Cookie': 'wordpress_test_cookie=WP%20Cookie%20check', 'Content-Type': 'application/x-www-form-urlencoded', 'CF-Connecting-IP': '203.0.113.21'})
        rp = req(port, 'POST', '/wp-login.php', lh, ('log=admin&pwd=Pa55-w0rd-Test-9876%21&wp-submit=Log+In&redirect_to=https%3A%2F%2F' + tun + '%2Fwp-admin%2F&testcookie=1').encode(), src='127.0.0.8')
        auth = [c for c in rp.cookies if c.startswith('wordpress_') and 'test_cookie' not in c and 'wordpress_logged_in' not in c]
        check('dang nhap qua tunnel https: cookie xac thuc la ban SECURE (wordpress_sec_..., co thuoc tinh Secure)', rp.status == 302 and auth and all(c.startswith('wordpress_sec_') and '; secure' in c.lower() for c in auth), (rp.status, rp.h.get('location'), [c[:60] for c in rp.cookies]))
        # Gioi han da biet cua WordPress voi 1 siteurl (KHONG phai do ban sua o tren): siteurl=https -> WordPress tu bat FORCE_SSL_ADMIN;
        # wp-login.php qua IP LAN http goi wp_safe_redirect(https://IP-LAN/...) nhung host LAN khong nam trong danh sach host cho phep nen
        # WordPress roi ve admin_url() = wp-admin cua URL TUNNEL (X-Redirect-By: WordPress). Tuc la vao admin bang IP LAN luc dang dung
        # URL tunnel https se bi day sang tunnel (can Internet). Ghi nhan hanh vi, khong khang dinh.
        rlan = req(port, 'GET', '/wp-login.php', {'Host': '192.168.1.50:8080'}, src='127.0.0.9')
        info('wp-login qua IP LAN http khi siteurl=https: HTTP %s -> %s (WordPress day sang URL tunnel; hanh vi co san, xem HANDOFF 1ba-F)' % (rlan.status, rlan.h.get('location')))
        sql("UPDATE wp_options SET option_value='http://127.0.0.1:%d' WHERE option_name IN ('siteurl','home')" % port, 'wordpress')
        rw.bump_object_cache_epoch(app)   # sua wp_options bang SQL (nhu Adminer): san pham bao hieu cache APCu qua POST db.php (HANDOFF.md muc 1bd)

        print('== H. Nhat ky truy cap co thoi gian xu ly (O8) ==')
        os.kill(int(open(os.path.join(run, 'nginx.pid')).read().strip()), signal.SIGUSR1); time.sleep(1.0)
        al = open(os.path.join(run, 'nginx-access.log'), errors='replace').read()
        check('access log co rt=<giay> (request_time) de biet request nao cham', re.search(r'rt=\d+\.\d{3}', al) is not None, al[-160:])
        # Dong bo log_format that <-> regex cua trang Analytics (A5): lay regex TRUC TIEP tu admin-analytics.php
        src = open(os.path.join(TPLDIR, 'admin-analytics.php'), encoding='utf-8').read()
        pm = re.search(r"\$pattern = '(/.*/)';", src)
        rx = re.compile(pm.group(1)[1:-1].replace('\\\\', '\\')) if pm else None
        lines = [l for l in al.splitlines() if l.strip()]
        ok = [l for l in lines if rx and rx.match(l)]
        check('Analytics (A5): regex trong admin-analytics.php doc DUOC moi dong log that cua nginx (%d dong)' % len(lines), bool(rx) and len(lines) > 20 and len(ok) == len(lines), (len(ok), len(lines), [l for l in lines if rx and not rx.match(l)][:1]))
        t0 = time.time(); ps = probe('?sleep=6'); took = time.time() - t0
        time.sleep(0.5); slow = os.path.join(run, 'php-slow.log')
        if os.path.exists(slow) and 'wp-probe.php' in open(slow, errors='replace').read():
            check('php-fpm slowlog ghi request >5s kem stack trace', True)
        else:
            fl = open(os.path.join(run, 'php-fpm.log'), errors='replace').read() if os.path.exists(os.path.join(run, 'php-fpm.log')) else ''
            info('slowlog KHONG ghi duoc trong moi truong nay (sleep %.1fs; log fpm: %s) - thuong do thieu quyen ptrace; can thu tren thiet bi that' % (took, fl.strip().splitlines()[-1][:120] if fl.strip() else 'trong'))
    finally:
        for p in procs + ([db] if db else []):
            try: p.terminate(); p.wait(timeout=15)
            except Exception:
                try: p.kill()
                except Exception: pass
        shutil.rmtree(tmp, ignore_errors=True); shutil.rmtree('/tmp/wp-extract', ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
