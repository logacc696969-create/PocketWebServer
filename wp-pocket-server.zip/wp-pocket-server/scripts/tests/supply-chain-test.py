#!/usr/bin/env python3
"""Kiem thu xac minh TOAN VEN file tai ve luc build (HANDOFF.md muc 1bc - de xuat Z1/Z2/Z3 cua PDF "chat luong tinh phi").

Dung server HTTP cuc bo gia lap: kho Termux (Packages + .deb that dung `ar`), GitHub (chuyen huong `releases/latest` -> tag,
ghi chu phat hanh co SHA-256), wordpress.org (latest.zip + .sha1, co the "CDN lech"), nguon Adminer/TFM ghim.
Moi kich ban tan cong/hong deu chay script THAT (bash), khong mo phong logic bang Python.

DOI CHUNG AM (chung minh test co phat hien duoc loi cu): chay lai voi script GOC (trong zip nhan duoc, truoc 1bc):
  ORIG_TERMUX_FETCH=<termux_fetch.sh goc> ORIG_CLOUDFLARED=<prepare_cloudflared.sh goc> python3 scripts/tests/supply-chain-test.py
Khi do cac kiem tra "chan file hong/bi doi" PHAI do (script goc chap nhan tat ca).

Mang that (tuy chon, bo qua neu khong co): kiem pins.env khop file that tren GitHub.
Chay: python3 scripts/tests/supply-chain-test.py
"""
import gzip, hashlib, http.server, io, os, re, shutil, subprocess, sys, tarfile, tempfile, threading, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
LIB = os.path.join(ROOT, 'scripts', 'lib')
VERIFY = os.path.join(LIB, 'verify_download.sh')
TERMUX_FETCH = os.environ.get('ORIG_TERMUX_FETCH') or os.path.join(LIB, 'termux_fetch.sh')
CLOUDFLARED = os.environ.get('ORIG_CLOUDFLARED') or os.path.join(ROOT, 'scripts', 'prepare_cloudflared.sh')
NEGATIVE = bool(os.environ.get('ORIG_TERMUX_FETCH') or os.environ.get('ORIG_CLOUDFLARED'))

PASS = FAIL = 0
def check(name, cond, detail=''):
    global PASS, FAIL
    if cond: PASS += 1; print('PASS: ' + name)
    else: FAIL += 1; print('FAIL: ' + name + ((' -> ' + str(detail)[:400]) if detail else ''))

def sha(b, algo='sha256'): return hashlib.new(algo, b).hexdigest()

# ---------------------------------------------------------------- server gia
class Server:
    """routes: path -> bytes | (status, bytes) | (status, bytes, {header}) | callable(count)->(status, bytes, headers)."""
    def __init__(self):
        self.routes, self.hits = {}, {}
        outer = self
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _serve(self, head):
                path = self.path.split('?')[0]
                outer.hits[path] = outer.hits.get(path, 0) + 1
                r = outer.routes.get(path)
                if callable(r): r = r(outer.hits[path])
                if r is None: self.send_response(404); self.send_header('Content-Length', '0'); self.end_headers(); return
                if isinstance(r, bytes): r = (200, r, {})
                if len(r) == 2: r = (r[0], r[1], {})
                st, body, hd = r
                self.send_response(st)
                for k, v in hd.items(): self.send_header(k, v)
                self.send_header('Content-Length', str(len(body))); self.end_headers()
                if not head: self.wfile.write(body)
            def do_GET(self): self._serve(False)
            def do_HEAD(self): self._serve(True)
        self.httpd = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H)
        self.port = self.httpd.server_address[1]
        self.url = 'http://127.0.0.1:%d' % self.port
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
    def close(self): self.httpd.shutdown()

def run(script, env=None, cwd=ROOT, timeout=120):
    e = dict(os.environ); e['VERIFY_REPORT'] = ''          # khong ghi vao bao cao that cua CI (job-level VERIFY_REPORT) khi test khong tu dat
    e.update(env or {})
    if not (env and 'VERIFY_STRICT' in env): e.pop('VERIFY_STRICT', None)   # CI co the dat VERIFY_STRICT=1: test tu quyet dinh
    p = subprocess.run(['bash', '-c', 'set -euo pipefail\n' + script], cwd=cwd, env=e, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout, p.stderr

def report(path):
    if not os.path.exists(path): return []
    return [l.rstrip('\n').split('\t') for l in open(path, encoding='utf-8') if l.strip()]

# ---------------------------------------------------------------- 1. don vi: thu vien verify
def t_unit(tmp):
    print('\n== 1. verify_download.sh (don vi) ==')
    h64, h40 = 'a' * 63 + 'b', 'c' * 39 + 'd'
    def ext(algo, text):
        rc, out, _ = run('source %s\nprintf %%s %s | verify_extract_hash %s || true' % (VERIFY, repr(text), algo))
        return out.strip()
    check('trich sha256 tu dong dang "<hash>  cacert.pem" (curl.se)', ext('sha256', h64 + '  cacert.pem') == h64)
    check('trich sha256 tu HTML co dau ":" (release notes cloudflared)', ext('sha256', '<p>cloudflared-linux-arm64: ' + h64 + '</p>') == h64)
    check('chu HOA duoc chuan hoa thanh chu thuong', ext('sha256', h64.upper()) == h64)
    check('chuoi sha512 (128 hex) KHONG bi nhan nham la sha256', ext('sha256', h64 + h64) == '')
    check('sha1 40 hex duoc nhan dung; sha256 ben trong khong lam sai lech', ext('sha1', h40 + ' latest.zip') == h40)
    check('rong -> rong (khong in rac)', ext('sha256', 'khong co hash o day') == '')

    f = os.path.join(tmp, 'f.bin'); open(f, 'wb').write(b'hello')
    good, bad = sha(b'hello'), sha(b'hellO')
    rep = os.path.join(tmp, 'rep1.tsv')
    env = {'VERIFY_REPORT': rep}
    rc, out, err = run('source %s\nverify_file nhan %s sha256 %s nguon' % (VERIFY, f, good), env)
    check('hash khop -> exit 0, bao cao OK', rc == 0 and report(rep)[-1][:3] == ['nhan', 'OK', 'sha256'], (rc, err, report(rep)))
    rc, out, err = run('source %s\nverify_file nhan %s sha256 %s nguon' % (VERIFY, f, good.upper()), env)
    check('hash chu HOA van khop', rc == 0, (rc, err))
    rc, out, err = run('source %s\nverify_file nhan %s sha256 %s nguon\necho SAU_VERIFY' % (VERIFY, f, bad), env)
    check('hash SAI -> exit 1 va KHONG chay tiep lenh sau (set -e khong can thiet)', rc == 1 and 'SAU_VERIFY' not in out, (rc, out))
    check('hash SAI -> thong bao neu ro mong doi/thuc te', 'KHONG KHOP' in err and good in err and bad in err, err)
    check('hash SAI -> ghi MISMATCH vao bao cao', report(rep)[-1][1] == 'MISMATCH')
    rep2 = os.path.join(tmp, 'rep2.tsv')
    rc, out, err = run('source %s\nverify_file nhan %s sha256 "" nguon' % (VERIFY, f), {'VERIFY_REPORT': rep2})
    check('KHONG co hash -> canh bao + UNVERIFIED, KHONG dung build (exit 0)', rc == 0 and 'CHUA duoc xac minh' in err and report(rep2)[-1][1] == 'UNVERIFIED', (rc, err))
    rc, out, err = run('source %s\nverify_file nhan %s sha256 "" nguon' % (VERIFY, f), {'VERIFY_STRICT': '1'})
    check('KHONG co hash + VERIFY_STRICT=1 -> exit 1', rc == 1 and 'VERIFY_STRICT' in err, (rc, err))
    rc, out, err = run('source %s\nverify_file nhan %s sha256 %s nguon' % (VERIFY, f, bad), {'VERIFY_STRICT': '1'})
    check('hash SAI van exit 1 du strict hay khong', rc == 1)
    rc, out, err = run('source %s\nverify_matches sha256 %s %s && echo KHOP || echo LECH; verify_matches sha256 %s "" && echo KHOP || echo LECH' % (VERIFY, f, good, f))
    check('verify_matches: khop -> 0; expected rong -> 1 (khong coi rong la khop)', out.split() == ['KHOP', 'LECH'], out)
    check('verify_note chi GHI (RECORDED), khong dung build', run('source %s\nverify_note plugin %s' % (VERIFY, f), {'VERIFY_REPORT': os.path.join(tmp, 'rep3.tsv')})[0] == 0
          and report(os.path.join(tmp, 'rep3.tsv'))[-1][1] == 'RECORDED')
    elf, html = os.path.join(tmp, 'elf'), os.path.join(tmp, 'html')
    open(elf, 'wb').write(b'\x7fELF\x02\x01\x01' + b'\0' * 20); open(html, 'wb').write(b'<html>404</html>')
    check('verify_elf: ELF -> 0, HTML -> 1', run('source %s\nverify_elf %s && verify_elf %s' % (VERIFY, elf, html))[0] == 1
          and run('source %s\nverify_elf %s' % (VERIFY, elf))[0] == 0)

# ---------------------------------------------------------------- 2. kho Termux gia
def make_deb(files):
    """.deb that: ar(debian-binary, control.tar.gz, data.tar.gz). files: {'data/data/.../x': bytes}."""
    def tgz(entries):
        bio = io.BytesIO()
        with tarfile.open(fileobj=bio, mode='w:gz') as tf:
            for n, b in entries.items():
                ti = tarfile.TarInfo(n); ti.size = len(b); ti.mode = 0o755; tf.addfile(ti, io.BytesIO(b))
        return bio.getvalue()
    d = tempfile.mkdtemp()
    try:
        open(os.path.join(d, 'debian-binary'), 'wb').write(b'2.0\n')
        open(os.path.join(d, 'control.tar.gz'), 'wb').write(tgz({'control': b'Package: x\n'}))
        open(os.path.join(d, 'data.tar.gz'), 'wb').write(tgz(files))
        out = os.path.join(d, 'x.deb')
        subprocess.run(['ar', 'rc', out, 'debian-binary', 'control.tar.gz', 'data.tar.gz'], cwd=d, check=True)
        return open(out, 'rb').read()
    finally: shutil.rmtree(d)

def packages_index(pkgs):
    """pkgs: {ten: (filename, deb_bytes, sha_or_None)}"""
    out = []
    for n, (fn, deb, s) in pkgs.items():
        out.append('Package: %s\nVersion: 1.0\nFilename: %s\nSize: %d\n%sDescription: t\n' % (n, fn, len(deb), ('SHA256: %s\n' % s) if s else ''))
    return gzip.compress(('\n'.join(out) + '\n').encode())

def t_termux(tmp):
    print('\n== 2. termux_fetch.sh: xac minh .deb voi SHA256 trong index (Z1) ==')
    debA = make_deb({'./data/data/com.termux/files/usr/bin/phpA': b'#!/bin/sh\necho A\n' * 50})
    debB = make_deb({'./data/data/com.termux/files/usr/lib/libB.so': b'LIBB' * 400})
    srv = Server()
    try:
        def serve(shaA=None, shaB=None, bodyA=None, no_sha=False):
            srv.routes.clear(); srv.hits.clear()
            idx = packages_index({'phpA': ('pool/p/phpA.deb', debA, None if no_sha else (shaA or sha(debA))),
                                  'libB': ('pool/l/libB.deb', debB, None if no_sha else (shaB or sha(debB)))})
            srv.routes['/dists/stable/main/binary-aarch64/Packages.gz'] = idx
            srv.routes['/pool/p/phpA.deb'] = bodyA if bodyA is not None else debA
            srv.routes['/pool/l/libB.deb'] = debB
        def go(work, extract, env=None):
            e = {'TERMUX_REPO': srv.url, 'TERMUX_ARCH': 'aarch64', 'TERMUX_WORK': work, 'VERIFY_REPORT': os.path.join(work, 'rep.tsv'),
                 'VERIFY_RETRY_SLEEP': '0'}; e.update(env or {})
            os.makedirs(work, exist_ok=True)
            return run('source %s\ntermux_download_with_deps phpA %s libB' % (TERMUX_FETCH, extract), e)

        # 2a. kho dung -> OK
        serve(); w, x = os.path.join(tmp, 'w1'), os.path.join(tmp, 'x1')
        rc, out, err = go(w, x)
        extracted = os.path.exists(os.path.join(x, 'data/data/com.termux/files/usr/bin/phpA')) and os.path.exists(os.path.join(x, 'data/data/com.termux/files/usr/lib/libB.so'))
        check('kho dung: tai + giai nen ca 2 goi (exit 0)', rc == 0 and extracted, (rc, err[-300:]))
        if not NEGATIVE or 'verify' in open(TERMUX_FETCH).read():
            check('kho dung: bao cao ghi OK cho tung goi', [r[1] for r in report(os.path.join(w, 'rep.tsv')) if r[0].startswith('termux:')] == ['OK', 'OK'], report(os.path.join(w, 'rep.tsv')))

        # 2b. .deb bi DOI tren may chu (khac SHA256 trong index) -> phai DUNG
        serve(bodyA=make_deb({'./data/data/com.termux/files/usr/bin/phpA': b'MALWARE' * 50}))
        w, x = os.path.join(tmp, 'w2'), os.path.join(tmp, 'x2')
        rc, out, err = go(w, x)
        planted = os.path.exists(os.path.join(x, 'data/data/com.termux/files/usr/bin/phpA'))
        check('.deb bi doi tren may chu -> DUNG build (exit != 0) va KHONG giai nen ma doc', rc != 0 and not planted, (rc, planted, err[-200:]))
        check('.deb bi doi -> thong bao "KHONG KHOP"', 'KHONG KHOP' in err or 'khong khop' in err, err[-300:])

        # 2c. cache co file BI CAT DO (size > 0): script goc chap nhan (chi kiem -s); script moi phai bo + tai lai
        serve(); w, x = os.path.join(tmp, 'w3'), os.path.join(tmp, 'x3'); os.makedirs(w)
        open(os.path.join(w, 'pkg_phpA.deb'), 'wb').write(debA[:len(debA) // 2])
        rc, out, err = go(w, x)
        ok_extract = os.path.exists(os.path.join(x, 'data/data/com.termux/files/usr/bin/phpA'))
        check('cache co .deb BI CAT DO -> tu bo cache va tai lai dung (exit 0, giai nen day du)', rc == 0 and ok_extract, (rc, ok_extract, err[-300:]))
        check('cache hong -> da tai lai tu may chu (khong dung file cut)', srv.hits.get('/pool/p/phpA.deb', 0) == 1, srv.hits)
        check('sau do cache la ban DAY DU, dung hash', sha(open(os.path.join(w, 'pkg_phpA.deb'), 'rb').read()) == sha(debA))

        # 2d. cache DUNG -> khong tai lai qua mang (giu nguyen tinh nang cache cua L3)
        serve(); w, x = os.path.join(tmp, 'w4'), os.path.join(tmp, 'x4'); os.makedirs(w)
        open(os.path.join(w, 'pkg_phpA.deb'), 'wb').write(debA)
        rc, out, err = go(w, x)
        check('cache DUNG -> KHONG tai lai qua mang (giu loi ich cache)', rc == 0 and srv.hits.get('/pool/p/phpA.deb', 0) == 0, (rc, srv.hits))

        # 2e. tai bi ngat (may chu tra khong du byte) -> khong de file cut mang ten that trong cache
        serve()
        def short(n): return (200, debB, {})  # placeholder, thay duoi
        w, x = os.path.join(tmp, 'w5'), os.path.join(tmp, 'x5')
        class Cut(http.server.BaseHTTPRequestHandler): pass
        srv.routes['/pool/p/phpA.deb'] = lambda n: (200, debA[:len(debA) // 2], {})   # Content-Length khop nen curl khong bao loi => hash lech
        rc, out, err = go(w, x)
        check('may chu tra file cut (khong khop index) -> DUNG build', rc != 0, (rc, err[-200:]))

        # 2f. index THIEU SHA256
        serve(no_sha=True); w, x = os.path.join(tmp, 'w6'), os.path.join(tmp, 'x6')
        rc, out, err = go(w, x)
        check('index thieu SHA256 -> canh bao UNVERIFIED nhung van build (exit 0)', rc == 0 and 'CHUA duoc xac minh' in err, (rc, err[-200:]))
        w, x = os.path.join(tmp, 'w7'), os.path.join(tmp, 'x7')
        rc, out, err = go(w, x, {'VERIFY_STRICT': '1'})
        check('index thieu SHA256 + VERIFY_STRICT=1 -> dung build', rc != 0)
    finally: srv.close()

# ---------------------------------------------------------------- 3. cloudflared
def t_cloudflared(tmp):
    print('\n== 3. prepare_cloudflared.sh: xac minh theo ghi chu phat hanh (Z3) ==')
    elf64 = b'\x7fELF\x02\x01\x01\0' + os.urandom(2000)
    elf32 = b'\x7fELF\x01\x01\x01\0' + os.urandom(1500)
    TAG = '2099.1.0'
    srv = Server()
    try:
        def serve(notes=None, bin64=None, latest=True):
            srv.routes.clear(); srv.hits.clear()
            if latest: srv.routes['/releases/latest'] = (302, b'', {'Location': srv.url + '/releases/tag/' + TAG})
            srv.routes['/releases/latest/download/cloudflared-linux-arm64'] = (302, b'', {'Location': srv.url + '/releases/download/%s/cloudflared-linux-arm64' % TAG})
            srv.routes['/releases/download/%s/cloudflared-linux-arm64' % TAG] = bin64 if bin64 is not None else elf64
            srv.routes['/releases/download/%s/cloudflared-linux-arm' % TAG] = elf32
            if notes is None:
                notes = ('<div class="markdown-body"><p>SHA256 Checksums:</p><pre>cloudflared-linux-arm: %s\ncloudflared-linux-arm64: %s\n</pre></div>'
                         % (sha(elf32), sha(elf64))).encode()
            srv.routes['/releases/tag/' + TAG] = notes
        def go(arch, out, env=None):
            e = {'CFD_REPO_URL': srv.url, 'VERIFY_REPORT': os.path.join(out + '.rep'), 'VERIFY_STRICT': '0'}; e.update(env or {})
            return run('bash %s %s %s' % (CLOUDFLARED, arch, out), e)

        serve(); o = os.path.join(tmp, 'c1')
        rc, out, err = go('arm64', o)
        check('ban dung: tai theo TAG (qua chuyen huong latest), exit 0', rc == 0 and os.path.isfile(o + '/libcfd.so'), (rc, err[-300:]))
        check('ban dung: file thanh libcfd.so, thuc thi duoc, dung noi dung', os.access(o + '/libcfd.so', os.X_OK) and open(o + '/libcfd.so', 'rb').read() == elf64)
        if not NEGATIVE:
            check('ban dung: bao cao OK + tag trong nhan', report(o + '.rep') and report(o + '.rep')[-1][1] == 'OK' and TAG in report(o + '.rep')[-1][0], report(o + '.rep'))
            check('ban dung: KHONG de lai file .part', not os.path.exists(o + '/libcfd.so.part'))
        o = os.path.join(tmp, 'c2')
        rc, out, err = go('arm', o)
        check('arch=arm (32-bit): chon DUNG hash "arm:" chu khong nham voi "arm64:"', rc == 0 and open(o + '/libcfd.so', 'rb').read() == elf32, (rc, err[-300:]))

        # binary bi doi (ELF hop le nhung khac hash cong bo) -> phai DUNG, khong dong goi
        serve(bin64=b'\x7fELF\x02\x01\x01\0' + b'BACKDOOR' * 300); o = os.path.join(tmp, 'c3')
        rc, out, err = go('arm64', o)
        check('binary KHAC hash cong bo -> DUNG build (exit != 0), KHONG tao libcfd.so', rc != 0 and not os.path.exists(o + '/libcfd.so'), (rc, os.listdir(o) if os.path.isdir(o) else None))

        # tra trang loi HTML (200) thay vi binary
        serve(bin64=b'<html><body>rate limited</body></html>'); o = os.path.join(tmp, 'c4')
        rc, out, err = go('arm64', o)
        check('may chu tra trang HTML thay vi binary -> DUNG build', rc != 0 and not os.path.exists(o + '/libcfd.so'), (rc, err[-200:]))

        # ghi chu phat hanh khong co hash
        serve(notes=b'<p>Release notes without checksums</p>'); o = os.path.join(tmp, 'c5')
        rc, out, err = go('arm64', o)
        check('ghi chu KHONG co hash -> canh bao UNVERIFIED nhung van build (exit 0)', rc == 0 and 'CHUA duoc xac minh' in err and os.path.isfile(o + '/libcfd.so'), (rc, err[-200:]))
        o = os.path.join(tmp, 'c6')
        rc, out, err = go('arm64', o, {'VERIFY_STRICT': '1'})
        check('ghi chu KHONG co hash + VERIFY_STRICT=1 -> dung build', rc != 0 and not os.path.exists(o + '/libcfd.so'), rc)

        # khong xac dinh duoc tag -> lui ve latest/download (co canh bao), khong the doi chieu
        serve(latest=False); srv.routes['/releases/latest'] = (200, b'', {}); o = os.path.join(tmp, 'c7')
        rc, out, err = go('arm64', o)
        check('khong xac dinh duoc tag -> lui ve /latest/download + canh bao, van tai duoc (exit 0)', rc == 0 and 'khong xac dinh duoc tag' in err and os.path.isfile(o + '/libcfd.so'), (rc, err[-300:]))
    finally: srv.close()

# ---------------------------------------------------------------- 4. cong cu quan tri ghim
def t_admin_tools(tmp):
    print('\n== 4. admin_tools.sh: Adminer/TFM GHIM phien ban + SHA256 (Z2) ==')
    adminer = b"<?php\n// fake adminer\necho 'ADMINER';\n"
    tfm = b"<?php\n// fake tfm\n$use_auth = true;\n$root_path = $_SERVER['DOCUMENT_ROOT'];\necho 'TFM';\n"
    srv = Server()
    try:
        def pins(path, a_sha, t_sha, a_url='/adminer.php', t_url='/tfm.php'):
            open(path, 'w').write('ADMINER_VERSION=9.9.9\nADMINER_URL="%s%s"\nADMINER_SHA256=%s\nTFM_VERSION=9.9\nTFM_URL="%s%s"\nTFM_SHA256=%s\n' % (srv.url, a_url, a_sha, srv.url, t_url, t_sha))
        srv.routes['/adminer.php'] = adminer; srv.routes['/tfm.php'] = tfm
        def go(name, a_sha, t_sha, a_url='/adminer.php', t_url='/tfm.php', env=None):
            pf = os.path.join(tmp, name + '.pins'); pins(pf, a_sha, t_sha, a_url, t_url)
            st = os.path.join(tmp, name + '-stg'); os.makedirs(st, exist_ok=True)
            e = {'PINS_FILE': pf, 'VERIFY_REPORT': os.path.join(tmp, name + '.rep')}; e.update(env or {})
            rc, out, err = run('source scripts/lib/admin_tools.sh\nprepare_admin_tools %s "" generic' % st, e)
            return rc, out, err, os.path.join(st, '_admin'), report(os.path.join(tmp, name + '.rep'))
        rc, out, err, ad, rep = go('ok', sha(adminer), sha(tfm))
        check('ghim dung: cai ca db.php + files.php (exit 0)', rc == 0 and os.path.isfile(ad + '/db.php') and os.path.isfile(ad + '/files.php'), (rc, err[-300:]))
        check('ghim dung: da chen cong auth vao ca 2 file', all('auth.php' in open(ad + '/' + f).read() for f in ('db.php', 'files.php')))
        check('ghim dung: TFM da tat dang nhap rieng (use_auth = false)', 'use_auth = false;' in open(ad + '/files.php').read())
        check('ghim dung: bao cao OK cho ca 2 cong cu', sorted(r[1] for r in rep) == ['OK', 'OK'] and any('adminer-9.9.9' in r[0] for r in rep), rep)
        rc, out, err, ad, rep = go('badA', 'f' * 64, sha(tfm))
        check('Adminer sai hash -> DUNG build (exit != 0), KHONG con db.php do tai', rc != 0 and not os.path.exists(ad + '/db.php'), (rc, err[-250:]))
        rc, out, err, ad, rep = go('badT', sha(adminer), '0' * 64)
        check('TFM sai hash -> DUNG build (exit != 0), KHONG con files.php do tai', rc != 0 and not os.path.exists(ad + '/files.php'), (rc, err[-250:]))
        rc, out, err, ad, rep = go('gone', sha(adminer), sha(tfm), a_url='/khong-co.php')
        check('Adminer khong tai duoc (404) -> bo qua cong cu + canh bao, build chinh van chay (hanh vi cu giu nguyen)',
              rc == 0 and not os.path.exists(ad + '/db.php') and os.path.isfile(ad + '/files.php') and 'khong tai duoc Adminer' in err, (rc, err[-250:]))
        rc, out, err, ad, rep = go('nopin', '', '')
        check('khong ghim hash -> UNVERIFIED (canh bao) nhung van cai (exit 0)', rc == 0 and os.path.isfile(ad + '/db.php') and all(r[1] == 'UNVERIFIED' for r in rep), (rc, rep))
        rc, out, err, ad, rep = go('nopin2', '', '', env={'VERIFY_STRICT': '1'})
        check('khong ghim hash + VERIFY_STRICT=1 -> dung build', rc != 0)
    finally: srv.close()
    # pins.env that: cu phap + khong con URL "latest"/"master"
    pe = open(os.path.join(LIB, 'pins.env'), encoding='utf-8').read()
    check('pins.env co SHA256 64 hex cho ca 2 cong cu', len(re.findall(r'^(?:ADMINER|TFM)_SHA256=[0-9a-f]{64}$', pe, re.M)) == 2)
    at = open(os.path.join(LIB, 'admin_tools.sh'), encoding='utf-8').read()
    code = '\n'.join(l for l in at.splitlines() if not l.lstrip().startswith('#'))
    check('admin_tools.sh KHONG con tai "latest.php"/nhanh "master" mac dinh khi co ghim', 'latest.php' not in re.sub(r'\$\{ADMINER_URL:-[^}]*\}', '', code) and '/master/' not in re.sub(r'\$\{TFM_URL:-[^}]*\}', '', code))

# ---------------------------------------------------------------- 5. sidecar hash (WordPress sha1, wp-cli, cacert)
def t_sidecar(tmp):
    print('\n== 5. fetch_with_sidecar_hash (WordPress .sha1, WP-CLI .sha256, cacert.pem.sha256) ==')
    data = os.urandom(5000)
    srv = Server()
    try:
        def go(name, algo, env=None):
            out = os.path.join(tmp, name)
            e = {'VERIFY_REPORT': out + '.rep', 'VERIFY_RETRY_SLEEP': '0'}; e.update(env or {})
            rc, so, se = run('source %s\nrc=0; fetch_with_sidecar_hash lbl %s/f.bin %s/f.bin.%s %s %s || rc=$?\necho RC=$rc' % (VERIFY, srv.url, srv.url, algo, algo, out), e)
            m = re.search(r'RC=(\d+)', so); return rc, int(m.group(1)) if m else None, se, out
        srv.routes['/f.bin'] = data
        srv.routes['/f.bin.sha1'] = (sha(data, 'sha1') + '  f.bin\n').encode()
        srv.routes['/f.bin.sha256'] = (sha(data) + '  f.bin\n').encode()
        rc, inner, err, out = go('s1', 'sha1')
        check('sha1 dung (dang "<hash>  ten"): tai + xac minh OK', rc == 0 and inner == 0 and open(out, 'rb').read() == data, (rc, inner, err[-200:]))
        rc, inner, err, out = go('s2', 'sha256')
        check('sha256 dung: OK', rc == 0 and inner == 0 and open(out, 'rb').read() == data)
        srv.routes['/f.bin.sha256'] = ('0' * 64 + '  f.bin\n').encode()
        rc, inner, err, out = go('s3', 'sha256')
        check('hash cong bo KHAC file (that su bi doi) -> thoat 1, KHONG tao file dich', rc == 1 and not os.path.exists(out), (rc, inner))
        check('  ... va co thu lai 1 lan truoc khi ket luan (tai file 2 lan)', srv.hits.get('/f.bin', 0) >= 2, srv.hits)
        # CDN lech: lan 1 hash cu, lan 2 hash dung -> phai THANH CONG
        srv.hits.clear()
        srv.routes['/f.bin.sha256'] = lambda n: (200, ((('1' * 64) if n == 1 else sha(data)) + '  f.bin\n').encode(), {})
        rc, inner, err, out = go('s4', 'sha256')
        check('CDN lech tam thoi (lan 1 hash cu, lan 2 dung) -> thu lai roi THANH CONG', rc == 0 and inner == 0 and open(out, 'rb').read() == data, (rc, inner, err[-200:]))
        # khong co sidecar
        srv.routes['/f.bin.sha256'] = (404, b'')
        rc, inner, err, out = go('s5', 'sha256')
        check('khong co file hash (404) -> UNVERIFIED, van lay file (exit 0)', rc == 0 and inner == 0 and 'CHUA duoc xac minh' in err and os.path.exists(out), (rc, inner, err[-200:]))
        rc, inner, err, out = go('s6', 'sha256', {'VERIFY_STRICT': '1'})
        check('khong co file hash + strict -> dung', rc != 0)
        # file chinh 404 -> tra 3, khong crash
        srv.routes.pop('/f.bin')
        rc, inner, err, out = go('s7', 'sha256')
        check('file chinh 404 -> tra 3 (nguoi goi quyet dinh bo qua/dung), khong tao file', rc == 0 and inner == 3 and not os.path.exists(out) and not os.path.exists(out + '.part'), (rc, inner))
    finally: srv.close()

# ---------------------------------------------------------------- 6. site_source type=zip + sha256 tuy chon
def t_site_zip(tmp):
    print('\n== 6. site_source.type=zip: site_source.sha256 tuy chon ==')
    zbio = io.BytesIO()
    import zipfile
    with zipfile.ZipFile(zbio, 'w') as z: z.writestr('index.php', '<?php echo 1;')
    zb = zbio.getvalue()
    srv = Server(); srv.routes['/site.zip'] = zb
    try:
        def go(name, sha_val):
            cfg = os.path.join(tmp, name + '.json')
            import json
            ss = {'type': 'zip', 'url': srv.url + '/site.zip'}
            if sha_val is not None: ss['sha256'] = sha_val
            json.dump({'site_source': ss}, open(cfg, 'w'))
            stg = os.path.join(tmp, name + '-stg')
            rc, out, err = run('source scripts/lib/site_source.sh\nfetch_site_source %s' % stg, {'SITE_CONFIG': cfg, 'VERIFY_REPORT': os.path.join(tmp, name + '.rep')})
            return rc, err, os.path.exists(os.path.join(stg, 'index.php'))
        rc, err, ok = go('z1', sha(zb)); check('zip + sha256 dung -> giai nen (exit 0)', rc == 0 and ok, (rc, err[-200:]))
        rc, err, ok = go('z2', '0' * 64); check('zip + sha256 SAI -> DUNG build, khong giai nen', rc != 0 and not ok, (rc, err[-200:]))
        rc, err, ok = go('z3', None); check('zip khong khai bao sha256 -> van chay nhu cu (canh bao UNVERIFIED)', rc == 0 and ok and 'CHUA duoc xac minh' in err, (rc, err[-200:]))
    finally: srv.close()

# ---------------------------------------------------------------- 7. quet tinh: khong con diem tai nao bi bo sot
def t_static():
    print('\n== 7. quet tinh: moi diem tai file deu co xac minh/ghi nhan ==')
    # (tep, mau trong dong curl) -> ly do cho phep khong xac minh
    allowed = {
        ('scripts/lib/termux_fetch.sh', 'Packages.gz'): 'index goi (nguon cua cac SHA256; chua co chu ky GPG - xem HANDOFF 1bc)',
        ('scripts/lib/site_source.sh', 'wp-mail-smtp'): 'verify_note (nha phat hanh khong cong bo hash)',
        ('scripts/lib/site_source.sh', 'sqlite-integration'): 'verify_note (nha phat hanh khong cong bo hash)',
        ('scripts/lib/site_source.sh', 'site-source.zip'): 'verify_file voi site_source.sha256 tuy chon',
        ('scripts/lib/verify_download.sh', '.part'): 'chinh thu vien xac minh',
        ('scripts/prepare_cloudflared.sh', 'libcfd.so.part'): 'xac minh ngay sau (verify_file)',
        ('scripts/lib/termux_fetch.sh', 'tmp_deb.part'): 'xac minh ngay sau (verify_file)',
    }
    problems = []
    for dp, _d, fs in os.walk(os.path.join(ROOT, 'scripts')):
        for f in fs:
            if not f.endswith('.sh'): continue
            p = os.path.join(dp, f); rel = os.path.relpath(p, ROOT)
            if '/tests/' in rel: continue
            lines = open(p, encoding='utf-8').read().splitlines()
            for i, l in enumerate(lines):
                if l.lstrip().startswith('#') or 'curl ' not in l: continue
                joined = ' '.join(lines[i:i + 3])
                if not re.search(r'(-o\b|--output)', joined): continue
                if any(k[0] == rel and k[1] in joined for k in allowed): continue
                problems.append('%s:%d: %s' % (rel, i + 1, l.strip()[:110]))
    check('moi lenh "curl -o" trong scripts/ deu nam trong danh sach da xac minh/ghi nhan (khong co diem tai moi bi bo quen)', not problems, '; '.join(problems))
    # moi cho goi verify co that
    need = {'scripts/prepare_cloudflared.sh': 'verify_file', 'scripts/lib/admin_tools.sh': 'download_pinned', 'scripts/lib/termux_fetch.sh': 'verify_file',
            'scripts/runtimes/php.sh': 'fetch_with_sidecar_hash', 'scripts/lib/site_source.sh': 'fetch_with_sidecar_hash'}
    for rel, fn in need.items():
        code = '\n'.join(l for l in open(os.path.join(ROOT, rel), encoding='utf-8').read().splitlines() if not l.lstrip().startswith('#'))
        check('%s goi %s' % (rel, fn), fn in code)

# ---------------------------------------------------------------- 8. mang that (tuy chon)
def t_live():
    print('\n== 8. (mang that) pins.env khop file that tren GitHub ==')
    pe = {}
    for l in open(os.path.join(LIB, 'pins.env'), encoding='utf-8'):
        m = re.match(r'^([A-Z0-9_]+)=("?)(.*)\2$', l.strip())
        if m: pe[m.group(1)] = m.group(3)
    def expand(v): return re.sub(r'\$\{(\w+)\}', lambda m: pe.get(m.group(1), ''), v)
    for tool in ('ADMINER', 'TFM'):
        url = expand(pe[tool + '_URL'])
        try: data = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'wp-pocket-test'}), timeout=60).read()
        except Exception as e:
            print('(bo qua: khong tai duoc %s: %s)' % (url, type(e).__name__)); continue
        check('%s: SHA256 trong pins.env KHOP file that (%s)' % (tool, url.split('/')[-1]), sha(data) == pe[tool + '_SHA256'], sha(data))
        if tool == 'TFM':
            check('TFM ghim: con DUNG 2 mau ma admin_tools.sh sua bang sed ($use_auth, $root_path)',
                  b'use_auth = true;' in data and b"$root_path = $_SERVER['DOCUMENT_ROOT'];" in data)

def main():
    tmp = tempfile.mkdtemp(prefix='sc-')
    try:
        t_unit(tmp); t_termux(tmp); t_cloudflared(tmp); t_admin_tools(tmp); t_sidecar(tmp); t_site_zip(tmp); t_static(); t_live()
    finally: shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0

if __name__ == '__main__': sys.exit(main())
