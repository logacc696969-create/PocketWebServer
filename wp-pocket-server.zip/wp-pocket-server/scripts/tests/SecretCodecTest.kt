import com.wppocket.server.SecretCodec
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

var pass = 0; var fail = 0
fun check(name: String, cond: Boolean) { if (cond) { pass++; println("PASS: $name") } else { fail++; println("FAIL: $name") } }
fun newKey(): SecretKey { val g = KeyGenerator.getInstance("AES"); g.init(256); return g.generateKey() }

fun main() {
    val k = newKey(); val other = newKey()
    val tg = "7123456789:AAH-xYz_exampleTELEGRAMtoken0123456789"
    val s = SecretCodec.seal(k, tg)
    check("khu hoi dung", SecretCodec.open(k, s) == tg)
    check("dinh dang enc1: va khong lo token", s.startsWith("enc1:") && !s.contains("AAH"))
    check("moi lan ma hoa khac nhau nhung deu mo duoc", s != SecretCodec.seal(k, tg) && SecretCodec.open(k, SecretCodec.seal(k, tg)) == tg)
    check("sai khoa -> null", SecretCodec.open(other, s) == null)
    val raw = java.util.Base64.getDecoder().decode(s.substring(5)); raw[20] = (raw[20].toInt() xor 1).toByte()
    check("bi sua 1 bit -> null", SecretCodec.open(k, "enc1:" + java.util.Base64.getEncoder().encodeToString(raw)) == null)
    check("gia tri cu dang ro tra nguyen", SecretCodec.open(k, "plain-old") == "plain-old")
    check("hong dinh dang -> null", SecretCodec.open(k, "enc1:!!!") == null && SecretCodec.open(k, "enc1:AAAA") == null && SecretCodec.open(k, "enc1:") == null)
    val vn = "mật khẩu: tiếng Việt \"q\" \\ \n 2"
    check("Unicode nguyen ven", SecretCodec.open(k, SecretCodec.seal(k, vn)) == vn)
    check("isSealed", SecretCodec.isSealed(s) && !SecretCodec.isSealed("abc") && !SecretCodec.isSealed(null))
    println("\nTONG KET: pass=$pass fail=$fail")
    if (fail > 0) System.exit(1)
}
