#!/usr/bin/env python3
"""Kiem thu Shield + Scanner tren WORDPRESS THAT (HANDOFF.md muc 1br-H).

Cac test khac (shield-test.py, security-scan-test.py) dung WordPress GIA LAP nho. Test nay dung ma nguon WordPress THAT (core + cac theme/plugin mac dinh),
cai dat that (SQLite, khong can MariaDB), dang nhap that qua HTTP, de bat loi ma gia lap khong thay: hook doi ten, thu tu nap, thong bao that, bao dong gia
tren thu vien hop phap (vd 15 file loi WordPress bi bao "web shell" khi chua co checksum - da sua o 1br-H).

Can: php CLI co pdo_sqlite (dung `php -S`, KHONG can nginx/php-fpm/MariaDB), va hai bien moi truong tro toi ma nguon (tai tu GitHub, khong can wordpress.org):
  WP_REAL_SRC=<WordPress that>     git clone --depth 1 --branch 7.1.4 https://github.com/WordPress/WordPress.git
  WP_SQLITE_SRC=<plugin SQLite>    git clone --depth 1 https://github.com/WordPress/sqlite-database-integration.git
Thieu mot trong hai thi bo qua (exit 0). Tuy chon: WP_EXTRA_PLUGINS=<dir1:dir2> - them cac thu muc ma nguon plugin de do bao dong gia (chi quet, khong chay).
Dung WP that => IP khach duoc gia lap bang header X-Test-IP (auto_prepend_file dat REMOTE_ADDR) - giong nginx realip.
"""
import hashlib, http.client, json, os, re, shutil, socket, subprocess, sys, tempfile, time, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:260]) if d else ''))


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


class Site:
    def __init__(self, wp_src, sq_src):
        self.tmp = tempfile.mkdtemp(prefix='wpreal-')
        self.site = os.path.join(self.tmp, 'site')
        self.home = os.path.join(self.tmp, 'home')
        self.run = os.path.join(self.home, 'lamp-run')
        os.makedirs(self.run)
        self.port = free_port()
        shutil.copytree(wp_src, self.site, ignore=shutil.ignore_patterns('.git'), symlinks=False)
        plug = os.path.join(self.site, 'wp-content', 'plugins', 'sqlite-database-integration')
        shutil.copytree(os.path.join(sq_src, 'packages', 'plugin-sqlite-database-integration'), plug, symlinks=False)   # symlinks=False: bien symlink thanh ban sao that
        db = open(os.path.join(plug, 'db.copy'), encoding='utf-8').read()
        db = db.replace('{SQLITE_IMPLEMENTATION_FOLDER_PATH}', plug).replace('{SQLITE_PLUGIN}', 'sqlite-database-integration/load.php')
        open(os.path.join(self.site, 'wp-content', 'db.php'), 'w').write(db)
        os.makedirs(os.path.join(self.site, 'wp-content', 'database'), exist_ok=True)
        open(os.path.join(self.site, 'wp-config.php'), 'w').write(
            "<?php\ndefine('DB_NAME','wp'); define('DB_USER',''); define('DB_PASSWORD',''); define('DB_HOST','');\n"
            "define('DB_CHARSET','utf8'); define('DB_COLLATE','');\n"
            "define('AUTH_KEY','a');define('SECURE_AUTH_KEY','b');define('LOGGED_IN_KEY','c');define('NONCE_KEY','d');\n"
            "define('AUTH_SALT','e');define('SECURE_AUTH_SALT','f');define('LOGGED_IN_SALT','g');define('NONCE_SALT','h');\n"
            "$table_prefix='wp_'; define('WP_DEBUG', false);\nif (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');\nrequire_once ABSPATH . 'wp-settings.php';\n")
        open(os.path.join(self.tmp, 'spoof.php'), 'w').write("<?php\nif (isset($_SERVER['HTTP_X_TEST_IP'])) { $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_X_TEST_IP']; }\n")
        self.proc = None
        self.base = 'http://127.0.0.1:%d' % self.port

    def env(self):
        e = dict(os.environ)
        e['APP_HOME'] = self.home
        return e

    def cli(self, code, timeout=120, https=False):
        """Chay 1 doan PHP trong boi canh WordPress (nap wp-load.php) - nhu wp-cli. https=True: gia lap request HTTPS (WordPress chi cho mat khau ung dung qua HTTPS)."""
        pre = ("<?php\n$_SERVER['HTTP_HOST']='127.0.0.1:%d'; $_SERVER['REQUEST_URI']='/'; $_SERVER['SERVER_NAME']='127.0.0.1';%s\n"
               "require %r; require_once ABSPATH . 'wp-admin/includes/plugin.php'; require_once ABSPATH . 'wp-admin/includes/user.php';\n"
               % (self.port, " $_SERVER['HTTPS']='on';" if https else '', self.site + '/wp-load.php'))
        f = os.path.join(self.tmp, 'cli-%d.php' % int(time.time() * 1000))
        open(f, 'w').write(pre + code + "\n")
        r = subprocess.run(['php', f], env=self.env(), capture_output=True, text=True, timeout=timeout)
        return (r.stdout + r.stderr).strip()

    def install(self):
        f = os.path.join(self.tmp, 'install.php')
        open(f, 'w').write(
            "<?php\ndefine('WP_INSTALLING', true);\n$_SERVER['HTTP_HOST']='127.0.0.1:%d'; $_SERVER['REQUEST_URI']='/'; $_SERVER['SERVER_NAME']='127.0.0.1';\n"
            "require %r;\nrequire_once ABSPATH . 'wp-admin/includes/upgrade.php';\n"
            "$r = wp_install('Test Site', 'owner', 'owner@example.test', true, '', 'Pa55word-Test!');\n"
            "update_option('siteurl','%s'); update_option('home','%s'); echo 'OK ' . $r['user_id'];\n" % (self.port, self.site + '/wp-load.php', self.base, self.base))
        r = subprocess.run(['php', f], env=self.env(), capture_output=True, text=True, timeout=300)
        return 'OK 1' in r.stdout, (r.stdout + r.stderr)[-400:]

    def install_shield(self):
        mu = os.path.join(self.site, 'wp-content', 'mu-plugins')
        os.makedirs(os.path.join(mu, 'wppocket-shield'), exist_ok=True)
        shutil.copy(os.path.join(TPL, 'wppocket-shield-loader.php'), os.path.join(mu, 'wppocket-shield.php'))
        shutil.copy(os.path.join(TPL, 'wppocket-shield-logic.php'), os.path.join(mu, 'wppocket-shield', 'shield.php'))

    def start(self):
        self.log = open(os.path.join(self.tmp, 'server.log'), 'w')
        self.proc = subprocess.Popen(['php', '-d', 'auto_prepend_file=' + os.path.join(self.tmp, 'spoof.php'), '-d', 'display_errors=0',
                                      '-d', 'log_errors=1', '-d', 'error_log=' + os.path.join(self.tmp, 'php-error.log'),
                                      '-d', 'opcache.enable=0',      # php -S (SAPI cli-server) DUNG opcache neu php.ini bat: sua file roi thu ngay se thay ma CU (revalidate 2 giay) -> test sai

                                      '-S', '127.0.0.1:%d' % self.port, '-t', self.site], env=self.env(), stdout=self.log, stderr=self.log)
        for _ in range(100):
            try:
                socket.create_connection(('127.0.0.1', self.port), 1).close()
                return True
            except OSError:
                time.sleep(0.1)
        return False

    def stop(self):
        if self.proc:
            self.proc.terminate()
            try:
                self.proc.wait(5)
            except Exception:
                self.proc.kill()

    def req(self, method, path, ip='203.0.113.10', data=None, jar=None, headers=None):
        h = {'X-Test-IP': ip, 'Host': '127.0.0.1:%d' % self.port}
        if jar:
            h['Cookie'] = '; '.join('%s=%s' % kv for kv in jar.items())
        if headers:
            h.update(headers)
        body = None
        if isinstance(data, str):        # than tho (vd XML-RPC)
            body = data
            h['Content-Type'] = 'text/xml'
        elif data is not None:
            body = urllib.parse.urlencode(data)
            h['Content-Type'] = 'application/x-www-form-urlencoded'
        c = http.client.HTTPConnection('127.0.0.1', self.port, timeout=60)
        c.request(method, path, body=body, headers=h)
        r = c.getresponse()
        txt = r.read().decode('utf-8', 'replace')
        newjar = dict(jar or {})
        for k, v in r.getheaders():
            if k.lower() == 'set-cookie':
                nv = v.split(';', 1)[0]
                if '=' in nv:
                    a, b = nv.split('=', 1)
                    newjar[a] = b
        loc = r.getheader('Location') or ''
        c.close()
        return r.status, txt, newjar, loc

    def login(self, user, pwd, ip):
        jar = {'wordpress_test_cookie': 'WP%20Cookie%20check'}
        st, txt, jar, loc = self.req('POST', '/wp-login.php', ip, {'log': user, 'pwd': pwd, 'wp-submit': 'Log In', 'redirect_to': self.base + '/wp-admin/', 'testcookie': '1'}, jar)
        ok = st == 302 and any(k.startswith('wordpress_logged_in_') for k in jar)
        m = re.search(r'(?s)id="login_error"[^>]*>(.*?)</div>', txt)
        err = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', m.group(1))).strip() if m else ''
        return ok, err, jar

    def flag(self, name, on=True):
        p = os.path.join(self.run, name)
        if on:
            open(p, 'w').close()
        elif os.path.exists(p):
            os.remove(p)

    def events(self):
        p = os.path.join(self.run, 'security-events.log')
        return open(p, encoding='utf-8', errors='replace').read() if os.path.exists(p) else ''


def scan(site, extra=()):
    r = subprocess.run(['php', os.path.join(TPL, 'security-scan.php'), site.site, site.run, 'scan'] + list(extra), env=site.env(), capture_output=True, text=True, timeout=300)
    p = os.path.join(site.run, 'security-scan.json')
    return (json.load(open(p)) if os.path.exists(p) else {}), r.stdout + r.stderr


def make_checksums(wp_src, run, version):
    cs = {}
    for d, ds, fs in os.walk(wp_src):
        ds[:] = [x for x in ds if x != '.git']
        for f in fs:
            p = os.path.join(d, f)
            cs[os.path.relpath(p, wp_src)] = hashlib.md5(open(p, 'rb').read()).hexdigest()
    json.dump({'version': version, 'locale': 'en_US', 'fetched': 0, 'checksums': cs}, open(os.path.join(run, 'wp-core-checksums.json'), 'w'))
    return len(cs)


def main():
    wp_src, sq_src = os.environ.get('WP_REAL_SRC', ''), os.environ.get('WP_SQLITE_SRC', '')
    if not (os.path.isfile(os.path.join(wp_src, 'wp-load.php')) and os.path.isdir(os.path.join(sq_src, 'packages', 'plugin-sqlite-database-integration'))):
        print('(bo qua: dat WP_REAL_SRC va WP_SQLITE_SRC - xem dau file)')
        return 0
    try:
        ext = subprocess.run(['php', '-r', 'echo extension_loaded("pdo_sqlite") ? "1" : "0";'], capture_output=True, text=True).stdout
    except Exception:
        ext = '0'
    if ext != '1':
        print('(bo qua: PHP thieu pdo_sqlite)')
        return 0
    ver = re.search(r"\$wp_version\s*=\s*'([^']+)'", open(os.path.join(wp_src, 'wp-includes', 'version.php')).read()).group(1)
    S = Site(wp_src, sq_src)
    try:
        ok, out = S.install()
        check('cai WordPress THAT %s (SQLite) bang wp_install()' % ver, ok, out)
        if not ok:
            return 1
        S.install_shield()
        check('mu-plugin Shield nap duoc: CLI chay wp-load.php khong loi', 'Fatal' not in S.cli("echo 'alive';") and 'alive' in S.cli("echo 'alive';"))
        check('server php -S len', S.start())

        print('== 1. Shield tren WordPress that: an ten tai khoan, giau phien ban ==')
        st, txt, _, _ = S.req('GET', '/')
        check('trang chu 200', st == 200, st)
        check('khong con the <meta name="generator">', 'name="generator"' not in txt)
        check('?ver= cua script/style bi bam (khong lo phien ban WordPress %s)' % ver, ('ver=' + ver) not in txt and 'ver=' in txt, re.findall(r'ver=[0-9a-z.]+', txt)[:3])
        st, txt, _, _ = S.req('GET', '/?rest_route=/wp/v2/users')
        check('khach khong doc duoc /wp/v2/users (REST)', st in (401, 403, 404) and 'owner' not in txt, (st, txt[:120]))
        st, txt, _, loc = S.req('GET', '/?author=1')
        check('?author=1 bi chuyen ve trang chu (khong lo ten tai khoan)', st == 301 and loc.rstrip('/') == S.base, (st, loc))
        # ?author_name=<ten> va /author/<ten>/ KHONG bi chan co chu dich: ke tan cong phai da biet ten, va trang tac gia la noi dung cong khai cua nhieu blog
        # (xem docs/SECURITY.md muc 5 - gioi han). Shield chi chan duong DO ten (?author=<so>), thong bao dang nhap chung chung va khoa theo tai khoan.
        st, txt, _, _ = S.req('GET', '/?sitemap=index')
        check('sitemap khong liet ke "users"', 'users' not in txt, txt[:200])
        st, txt, _, _ = S.req('POST', '/xmlrpc.php', data='<?xml version="1.0"?><methodCall><methodName>system.listMethods</methodName><params></params></methodCall>')
        check('xmlrpc.php: system.listMethods KHONG tra danh sach ham (xmlrpc_enabled=false chi chan ham can dang nhap - phai bo cac ham wp.*/pingback)', 'wp.getUsersBlogs' not in txt and 'wp.' not in txt and 'pingback' not in txt, (st, txt[:200]))
        st, txt, _, _ = S.req('POST', '/xmlrpc.php', data='<?xml version="1.0"?><methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>owner</value></param><param><value>sai</value></param></params></methodCall>')
        check('xmlrpc.php: wp.getUsersBlogs (do mat khau qua XML-RPC) khong dung duoc', 'does not exist' in txt.lower() or 'disabled' in txt.lower() or st in (403, 404, 405), (st, txt[:200]))
        st, txt, _, _ = S.req('GET', '/?rest_route=/wp/v2/users/me/application-passwords')
        check('khach khong thay endpoint mat khau ung dung', st in (401, 403, 404, 501), st)
        check('wp_is_application_passwords_available() = false', S.cli("echo wp_is_application_passwords_available() ? 'YES' : 'NO';").endswith('NO'))
        check('DISALLOW_FILE_EDIT duoc dat', S.cli("echo defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT ? 'YES' : 'NO';").endswith('YES'))

        print('== 2. thong bao dang nhap chung chung (khong lo tai khoan co that hay khong) ==')
        ok1, e1, _ = S.login('owner', 'sai-mat-khau-1', '45.33.1.1')
        ok2, e2, _ = S.login('khong-ton-tai-xyz', 'sai-mat-khau-1', '45.33.2.1')
        check('sai mat khau cua tai khoan CO THAT: khong dang nhap', not ok1)
        check('thong bao CHUNG CHUNG, giong nhau cho tai khoan co that va khong ton tai', e1 != '' and e1 == e2, (e1, e2))
        check('thong bao khong chua "incorrect"/"not registered"/"Unknown"/ten tai khoan', not re.search(r'incorrect|not registered|unknown|owner|khong-ton-tai', e1 + e2, re.I), e1)

        print('== 3. dang nhap dung + khu vuc quan tri that ==')
        ok, e, jar = S.login('owner', 'Pa55word-Test!', '203.0.113.10')
        check('dang nhap DUNG tu mang quen 203.0.113.x -> 302 + cookie dang nhap', ok, e)
        st, txt, _, _ = S.req('GET', '/wp-admin/', '203.0.113.10', jar=jar)
        check('wp-admin/ (da dang nhap) 200 va hien Dashboard', st == 200 and 'Dashboard' in txt, st)
        st, txt, _, _ = S.req('GET', '/wp-admin/theme-editor.php', '203.0.113.10', jar=jar)
        check('trinh sua theme trong admin bi chan (DISALLOW_FILE_EDIT)', 'name="newcontent"' not in txt, st)
        st, nonce, _, _ = S.req('GET', '/wp-admin/admin-ajax.php?action=rest-nonce', '203.0.113.10', jar=jar)
        nonce = nonce.strip()
        st, txt, _, _ = S.req('GET', '/?rest_route=/wp/v2/users', '203.0.113.10', jar=jar, headers={'X-WP-Nonce': nonce})
        check('admin DA dang nhap van doc duoc /wp/v2/users (trinh soan thao khoi khong hong)', st == 200 and 'owner' in txt, (st, txt[:100]))
        st, txt, _, _ = S.req('GET', '/?rest_route=/wp/v2/users/me/application-passwords', '203.0.113.10', jar=jar, headers={'X-WP-Nonce': nonce})
        check('admin cung KHONG tao duoc mat khau ung dung (Shield tat)', st in (404, 501) or 'not available' in txt.lower() or 'rest_no_route' in txt, (st, txt[:120]))
        # WordPress chi bat mat khau ung dung qua HTTPS (hoac moi truong local) -> phai gia lap HTTPS de thay tac dung CUA SHIELD (qua HTTP no tat san, khong phan biet duoc)
        check('qua HTTPS, khong co co: Shield tat mat khau ung dung', S.cli("echo wp_is_application_passwords_available() ? 'YES' : 'NO';", https=True).endswith('NO'))
        S.flag('shield-allow-app-passwords')
        check('qua HTTPS, co shield-allow-app-passwords: mat khau ung dung HOAT DONG lai', S.cli("echo wp_is_application_passwords_available() ? 'YES' : 'NO';", https=True).endswith('YES'))
        S.flag('shield-allow-app-passwords', False)
        S.flag('shield-off')
        check('qua HTTPS, co shield-off: cung hoat dong lai (Shield tat het)', S.cli("echo wp_is_application_passwords_available() ? 'YES' : 'NO';", https=True).endswith('YES'))
        S.flag('shield-off', False)
        S.flag('shield-allow-user-api')
        st, txt, _, _ = S.req('GET', '/?rest_route=/wp/v2/users', '45.33.9.9')
        check('co shield-allow-user-api thi khach doc duoc /wp/v2/users', st == 200 and 'owner' in txt, (st, txt[:100]))
        S.flag('shield-allow-user-api', False)

        print('== 4. do mat khau phan tan: nhieu mang, moi mang vai lan ==')
        for i in range(1, 26):
            S.login('owner', 'doan-%d' % i, '45.40.%d.7' % i)
        store = os.path.join(S.run, 'shield-login.json')
        check('shield-login.json duoc tao', os.path.exists(store))
        raw = open(store).read() if os.path.exists(store) else ''
        check('file trang thai KHONG chua IP tho', not re.search(r'45\.40\.|203\.0\.113', raw), raw[:160])
        ok, e, _ = S.login('owner', 'Pa55word-Test!', '45.99.1.1')
        check('sau 25 lan sai: DUNG mat khau nhung tu mang LA van bi tu choi (phong thu tai khoan)', not ok and e != '', (ok, e))
        check('thong bao khi bi khoa la thong bao khoa chung (khong noi mat khau dung)', 'Too many' in e or 'try again' in e.lower(), e)
        ok, e, jar2 = S.login('owner', 'Pa55word-Test!', '203.0.113.77')
        check('chu site tu MANG QUEN (cung /24 da tung dang nhap) van vao duoc khi dang bi do', ok, e)
        check('su kien "TAM KHOA DANG NHAP" duoc ghi', 'TAM KHOA DANG NHAP' in S.events(), S.events()[-300:])
        os.remove(store)
        ok, e, _ = S.login('owner', 'Pa55word-Test!', '45.99.1.1')
        check('xoa shield-login.json (cach phuc hoi) -> mang moi dang nhap duoc lai', ok, e)

        print('== 5. nhat ky su kien nhay cam voi WordPress that ==')
        before = S.events()
        out = S.cli("$id = wp_insert_user(['user_login'=>'sneaky','user_pass'=>'x-Y9!zzzzzzzz','user_email'=>'s@example.test','role'=>'administrator']); echo is_wp_error($id) ? 'ERR' : 'ID'.$id;")
        ev = S.events()[len(before):]
        check('tao tai khoan quan tri (wp_insert_user) -> co su kien ghi ten "sneaky"', 'sneaky' in ev and 'QUAN TRI' in ev, (out, ev[:300]))
        before = S.events()
        S.cli("$u = get_user_by('login','owner'); $e = new WP_User(2); $e->set_role('administrator');")
        out = S.cli("$id = wp_insert_user(['user_login'=>'editor1','user_pass'=>'x-Y9!zzzzzzzz','user_email'=>'e@example.test','role'=>'editor']); $u = new WP_User($id); $u->set_role('administrator'); echo 'ok';")
        ev = S.events()[len(before):]
        check('NANG QUYEN thanh quan tri (set_role) -> co su kien', 'editor1' in ev and 'QUAN TRI' in ev, (out, ev[:300]))
        before = S.events()
        S.cli("update_option('admin_email','boss2@example.test');")
        check('doi email quan tri -> co su kien (email bi che)', 'EMAIL QUAN TRI' in S.events()[len(before):] and 'boss2@example.test' not in S.events(), S.events()[len(before):][:200])
        before = S.events()
        out = S.cli("$r = activate_plugin('hello.php'); echo is_wp_error($r) ? 'ERR' : 'OK';")
        check('kich hoat plugin -> co su kien PLUGIN VUA DUOC KICH HOAT', 'hello.php' in S.events()[len(before):], (out, S.events()[len(before):][:200]))
        before = S.events()
        S.login('owner', 'Pa55word-Test!', '78.20.30.40')
        ev = S.events()[len(before):]
        check('admin dang nhap tu MANG MOI (da co mang quen khac) -> co su kien', 'MANG MOI' in ev and 'owner' in ev, ev[:200])

        print('== 6. cong tat khan cap ==')
        S.flag('shield-off')
        st, txt, _, _ = S.req('GET', '/?rest_route=/wp/v2/users', '45.33.9.9')
        check('shield-off: Shield nhuong het (REST users lai doc duoc) va site van 200', st == 200, st)
        S.flag('shield-off', False)

        print('== 7. Scanner tren cay WordPress that ==')
        n = make_checksums(wp_src, S.run, ver)
        for f in ('security-scan.json', 'security-baseline.json', 'security-seen.json'):
            p = os.path.join(S.run, f)
            if os.path.exists(p):
                os.remove(p)
        res, out = scan(S)
        c = res.get('counts', {})
        check('co checksum chinh thuc (%d file): loi WordPress duoc xac minh' % n, res.get('core', {}).get('verified') is True, res.get('core'))
        check('cai dat WordPress SACH + plugin SQLite + Shield: 0 phat hien nghiem trong/cao/trung binh (khong bao dong gia)', c.get('critical', 9) + c.get('high', 9) + c.get('medium', 9) == 0,
              [(f['kind'], f['file']) for f in res.get('findings', [])][:6])
        # KHONG co checksum (dien thoai moi bat, chua co mang): truoc 1br-H bao 15 file hop le la ma doc
        os.remove(os.path.join(S.run, 'wp-core-checksums.json'))
        for f in ('security-baseline.json', 'security-seen.json'):
            p = os.path.join(S.run, f)
            if os.path.exists(p):
                os.remove(p)
        res2, out2 = scan(S)
        c2 = res2.get('counts', {})
        check('KHONG co checksum (chua tai duoc): ma WordPress that van khong bi bao la ma doc (truoc day 15 file bi bao nham)',
              c2.get('critical', 9) + c2.get('high', 9) + c2.get('medium', 9) == 0, [(f['kind'], f['file']) for f in res2.get('findings', [])][:6])
        check('... va ket qua noi ro loi WordPress CHUA xac minh', res2.get('core', {}).get('verified') is False, res2.get('core'))
        make_checksums(wp_src, S.run, ver)
        scan(S)   # lap lai baseline sach co checksum
        # chen ma doc that
        up = os.path.join(S.site, 'wp-content', 'uploads')
        os.makedirs(up, exist_ok=True)
        open(os.path.join(up, 'shell.php'), 'w').write('<?php @eval(base64_decode($_POST["x"])); ?>')
        open(os.path.join(up, 'pic.jpg'), 'wb').write(b'\xff\xd8\xff\xe0JFIF\x00<?php system($_GET["c"]); ?>')
        os.makedirs(os.path.join(S.site, 'wp-content', 'plugins', 'fake-seo'), exist_ok=True)
        open(os.path.join(S.site, 'wp-content', 'plugins', 'fake-seo', 'fake-seo.php'), 'w').write('<?php /* Plugin Name: Fake SEO */ $f = $_POST["k"]; $f($_POST["v"]); ?>')
        open(os.path.join(S.site, 'wp-content', 'mu-plugins', 'zz-evil.php'), 'w').write('<?php add_action("init", function(){ if(isset($_GET["z"])) { eval($_GET["z"]); } }); ?>')
        open(os.path.join(S.site, 'wp-config-backup.php'), 'w').write('<?php echo 1; ?>')
        with open(os.path.join(S.site, 'wp-includes', 'version.php'), 'a') as fh:
            fh.write('\n// injected\n')
        with open(os.path.join(S.site, 'wp-content', 'db.php'), 'a') as fh:
            fh.write('\n// injected\n')
        res3, out3 = scan(S)
        kinds = {}
        for f in res3.get('findings', []):
            kinds.setdefault(f['kind'], []).append(f['file'])
        check('PHP trong uploads/ -> critical php-trong-uploads', any('shell.php' in x for x in kinds.get('php-trong-uploads', [])), list(kinds))
        check('anh JPEG chua <?php -> anh-chua-ma-php', any('pic.jpg' in x for x in kinds.get('anh-chua-ma-php', [])), list(kinds))
        check('plugin gia fake-seo -> plugin-moi', any('fake-seo' in x for x in kinds.get('plugin-moi', [])), list(kinds))
        check('plugin gia co "$f($_POST[..])" -> nghi-web-shell', any('fake-seo.php' in x for x in kinds.get('nghi-web-shell', [])), list(kinds))
        check('mu-plugin la -> diem-bam-tru-moi', any('zz-evil.php' in x for x in kinds.get('diem-bam-tru-moi', [])), list(kinds))
        check('file PHP la o goc site -> php-la-o-goc-site', any('wp-config-backup.php' in x for x in kinds.get('php-la-o-goc-site', [])), list(kinds))
        check('file loi bi sua (wp-includes/version.php) -> core-bi-sua', any('version.php' in x for x in kinds.get('core-bi-sua', [])), list(kinds))
        check('drop-in db.php bi sua -> diem-bam-tru-doi', any('db.php' in x for x in kinds.get('diem-bam-tru-doi', [])), list(kinds))
        check('khong bao nham: tong phat hien khop dung nhom da chen (khong co file hop le nao bi keo vao)',
              all(k in ('php-trong-uploads', 'anh-chua-ma-php', 'plugin-moi', 'nghi-web-shell', 'ma-dang-ngo', 'diem-bam-tru-moi', 'diem-bam-tru-doi', 'php-la-o-goc-site', 'core-bi-sua')
                  for k in kinds), list(kinds))

        print('== 8. Do bao dong gia tren plugin pho bien (neu co WP_EXTRA_PLUGINS) ==')
        sys.path.insert(0, HERE)
        for d in [x for x in os.environ.get('WP_EXTRA_PLUGINS', '').split(':') if x and os.path.isdir(x)]:
            code = ("define('WPP_SCAN_AS_LIB', true); require %r; $n=0; $bad=[]; "
                    "$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(%r, FilesystemIterator::SKIP_DOTS)); "
                    "foreach ($it as $f) { if (!preg_match(WPP_SCAN_EXT_RX, $f->getFilename())) continue; $n++; "
                    "[$s,$h] = wpp_scan_score_content((string) @file_get_contents($f->getPathname(), false, null, 0, WPP_SCAN_MAX_BYTES)); if ($s >= WPP_SCAN_MED_SCORE) $bad[] = $f->getPathname().' '.$s.' '.implode(',', $h); } "
                    "echo $n.'|'.implode(\"\\n\", $bad);" % (os.path.join(TPL, 'security-scan.php'), d))
            r = subprocess.run(['php', '-r', code], capture_output=True, text=True, timeout=300)
            nfiles, _, bad = r.stdout.partition('|')
            check('plugin pho bien %s (%s file PHP): 0 bao dong gia' % (os.path.basename(d.rstrip('/')), nfiles), bad.strip() == '' and nfiles.strip().isdigit(), bad[:300] + r.stderr[:100])

        print('== 9. server van song, khong loi nghiem trong trong log PHP ==')
        st, txt, _, _ = S.req('GET', '/')
        check('trang chu van 200 sau toan bo kich ban', st == 200, st)
        pe = os.path.join(S.tmp, 'php-error.log')
        errs = [l for l in (open(pe).read().splitlines() if os.path.exists(pe) else []) if re.search(r'Fatal|Parse error|Uncaught', l)]
        check('log loi PHP khong co Fatal/Parse/Uncaught', not errs, errs[:3])
    finally:
        S.stop()
        shutil.rmtree(S.tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
