#!/usr/bin/env python3
"""Kiem thu validate_config.py (PDF 2 AF1/AF2; HANDOFF.md muc 1bo). Khong can jq/php/mang."""
import json, os, re, subprocess, sys, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "tools"))
import validate_config as vc, apply_preset as ap  # noqa: E402

pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)

def errs(**over):
    cfg = json.load(open(os.path.join(ROOT, "site.config.json"), encoding="utf-8"))
    ss = over.pop("site_source", None)
    cfg.update(over)
    if ss is not None: cfg["site_source"] = {**cfg["site_source"], **ss}
    return vc.check_text(json.dumps(cfg))

# ---- file that + preset ----
check("site.config.json cua du an hop le va co config_version", vc.check_text(open(os.path.join(ROOT, "site.config.json"), encoding="utf-8").read()) == []
      and json.load(open(os.path.join(ROOT, "site.config.json")))["config_version"] == vc.CONFIG_VERSION)
presets = ap.load_presets()
bad = []
for n, p in presets.items():
    cfg, _ = ap.apply(p, {"repo": "https://github.com/a/b.git"})
    if vc.check_text(json.dumps(cfg)) != [] or cfg.get("config_version") != vc.CONFIG_VERSION: bad.append(n)
check("moi preset (%d) sinh ra cau hinh hop le co config_version" % len(presets), not bad, str(bad))

# ---- AF1 config_version ----
check("vang config_version -> van hop le (tuong thich nguoc voi file cu)", vc.check_text(json.dumps({k: v for k, v in json.load(open(os.path.join(ROOT, "site.config.json"))).items() if k != "config_version"})) == [])
check("config_version moi hon cong cu hieu -> DUNG voi thong bao ro", any("moi hon" in m for m in errs(config_version=vc.CONFIG_VERSION + 1)))
check("config_version sai kieu (chuoi / bool / 0 / so thuc) -> loi", all(any("config_version" in m for m in errs(config_version=v)) for v in ("1", True, 0, 1.5, None)))

# ---- AF2 khoa la + goi y ----
e = errs(instal_deps=False)
check("go sai 'instal_deps' -> loi kem goi y 'install_deps'", any("instal_deps" in m and "install_deps" in m for m in e), str(e))
e = errs(runtim="php")
check("go sai 'runtim' -> goi y 'runtime'", any("runtim" in m and "'runtime'" in m for m in e), str(e))
e = errs(site_source={"typ": "wordpress"})
check("go sai khoa trong site_source ('typ') -> goi y 'type'", any("typ" in m and "'type'" in m and "site_source" in m for m in e), str(e))
check("khoa bat dau '_' la ghi chu, duoc bo qua (ca cap goc lan site_source)", errs(_ghichu="x", site_source={"_note": "y"}) == [])
e = errs(zzzzzzzz=1)
check("khoa hoan toan la -> liet ke cac khoa hop le thay vi goi y sai", any("zzzzzzzz" in m and "runtime" in m for m in e), str(e))
check("khong dung o loi dau: 2 loi cung luc deu duoc bao", len(errs(instal_deps=False, port=80)) >= 2)

# ---- gia tri (dung chung validate() cua apply_preset) ----
check("port 80 bi tu choi (Android khong bind <1024)", any("port" in m for m in errs(port=80)))
check("runtime la -> loi", any("runtime" in m for m in errs(runtime="ruby")))
check("type=git thieu repo -> loi", any("repo" in m for m in errs(site_source={"type": "git", "repo": ""})))
check("site_source khong phai doi tuong -> loi ro, khong ngoai le", any("site_source phai la doi tuong" in m for m in vc.check_text('{"runtime":"php","site_source":"x"}')))

# ---- sha256 ----
zipcfg = {"site_source": {"type": "zip", "url": "https://example.com/a.zip"}}
check("sha256 hop le (64 hex) voi type=zip -> ok", errs(**{"site_source": {**zipcfg["site_source"], "sha256": "a" * 64}}) == [])
check("sha256 sai do dai -> loi", any("sha256" in m for m in errs(site_source={**zipcfg["site_source"], "sha256": "abc"})))
check("sha256 voi type khac zip -> loi (khong am tham bi bo qua)", any("sha256" in m and "zip" in m for m in errs(site_source={"sha256": "a" * 64})))

# ---- JSON sai cu phap: dong/cot + goi y ----
e = vc.check_text('{\n  "runtime": "php",\n  "port": 8080,\n}\n')
check("dau phay thua: bao dong 4 (hoac 3) + goi y dau phay", len(e) == 1 and "dong" in e[0] and "dau phay" in e[0], str(e))
e = vc.check_text("{\n  // ghi chu\n  \"runtime\": \"php\"\n}\n")
check("chu thich // -> goi y dung khoa '_'", len(e) == 1 and "chu thich" in e[0] and "'_'" in e[0], str(e))
e = vc.check_text("{'runtime': 'php'}")
check("nhay don -> goi y nhay kep", len(e) == 1 and "nhay" in e[0].lower(), str(e))
e = vc.check_text('{"runtime": "php" "port": 8080}')
check("thieu dau phay -> goi y thieu dau phay", len(e) == 1 and "thieu dau phay" in e[0], str(e))
check("goc khong phai doi tuong ([]) -> loi ro", "DOI TUONG" in vc.check_text("[]")[0])
check("file rong -> loi cu phap, khong ngoai le", len(vc.check_text("")) == 1)

# ---- CLI + CI ----
with tempfile.TemporaryDirectory() as d:
    good = os.path.join(d, "g.json"); open(good, "w").write(open(os.path.join(ROOT, "site.config.json"), encoding="utf-8").read())
    badp = os.path.join(d, "b.json"); open(badp, "w").write('{"runtim": "php", "port": 80}')
    script = os.path.join(ROOT, "scripts/tools/validate_config.py")
    r1 = subprocess.run([sys.executable, script, good], capture_output=True, text=True)
    r2 = subprocess.run([sys.executable, script, badp], capture_output=True, text=True)
    r3 = subprocess.run([sys.executable, script, os.path.join(d, "none.json")], capture_output=True, text=True)
    r4 = subprocess.run([sys.executable, script, badp], capture_output=True, text=True, env={**os.environ, "GITHUB_ACTIONS": "true"})
    check("CLI: hop le -> ma 0", r1.returncode == 0 and "hop le" in r1.stdout, r1.stderr)
    check("CLI: sai -> ma 1, liet ke ca hai loi tren stderr", r2.returncode == 1 and "runtim" in r2.stderr and "port" in r2.stderr, r2.stderr)
    check("CLI: file khong ton tai -> ma 1, khong traceback", r3.returncode == 1 and "Traceback" not in r3.stderr)
    check("CLI: trong GitHub Actions in them dong ::error", "::error file=" in r4.stdout)
ci = open(os.path.join(ROOT, ".github/workflows/build-apk.yml"), encoding="utf-8").read()
i_val = ci.find("validate_config.py"); i_jq = ci.find("jq -r '.runtime' site.config.json")
check("CI: kiem tra site.config.json chay TRUOC buoc doc bang jq", 0 < i_val < i_jq)
check("CI: test nay nam trong danh sach test", "config-validate-test.py" in ci)

# ---- doi chieu: moi khoa script that su doc deu duoc cong cu chap nhan (chong lech khi them khoa moi) ----
used_top, used_ss = set(), set()
for base in ("scripts/lib", "scripts/runtimes"):
    for dp, _, fns in os.walk(os.path.join(ROOT, base)):
        for fn in fns:
            if not fn.endswith(".sh"): continue
            t = open(os.path.join(dp, fn), encoding="utf-8", errors="replace").read()
            for m in re.finditer(r"""(?:_sp_cfg|jq -r)\s+['"]\.([a-z_0-9]+)(?:\.([a-z_0-9]+))?""", t):
                a, b = m.group(1), m.group(2)
                if a == "site_source" and b: used_ss.add(b)
                elif a not in ("require",): used_top.add(a)   # .require = composer.json, khong phai site.config.json
check("moi khoa goc ma script doc (%s) co trong TOP_KEYS" % sorted(used_top), used_top <= set(vc.TOP_KEYS), str(used_top - set(vc.TOP_KEYS)))
check("moi khoa site_source ma script doc (%s) co trong SS_KEYS" % sorted(used_ss), used_ss <= set(vc.SS_KEYS), str(used_ss - set(vc.SS_KEYS)))

print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n))
sys.exit(1 if fail_n else 0)
