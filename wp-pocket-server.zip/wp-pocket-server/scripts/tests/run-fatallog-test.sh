#!/bin/sh
# Chay kiem thu JVM cho FatalLogLogic.kt (can kotlinc + java). HANDOFF.md muc 1bp.
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
kotlinc -nowarn "$HERE/../../app/src/main/java/com/wppocket/server/FatalLogLogic.kt" "$HERE/FatalLogLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" FatalLogLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
