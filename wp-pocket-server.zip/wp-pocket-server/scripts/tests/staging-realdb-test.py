#!/usr/bin/env python3
"""Kiem thu TICH HOP _admin/staging.php voi MARIADB THAT (mariadbd + mariadb + mariadb-dump) - HANDOFF.md muc 1ay.
Bo staging-fault-test.py dung cong cu GIA nen khong kiem duoc 2 gia dinh cua trang: (1) file dump that
ket thuc bang "-- Dump completed" (dump_is_complete), (2) nap dump de len bang dang co nhe nho "DROP TABLE IF EXISTS".
Test nay chay CHINH trang that voi DB that, kiem ca vong doi du lieu va 1 LOI THAT (khong chen): DB staging bi xoa
truoc khi promote. Tu khoi dong mariadbd rieng (datadir/socket trong thu muc tam, --skip-networking).
Can: mariadbd, mariadb-install-db, mariadb, mariadb-dump (hoac mysqld...), php, python3. Thieu -> bo qua (exit 0).
"""
import importlib.util, os, re, shutil, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
# Chay duoc CA voi user thuong (runner CI khong phai root): mariadb-install-db --user=<chinh minh>; mariadbd khong dung --user.
import getpass
DB_OS_USER = 'root' if os.geteuid() == 0 else getpass.getuser()
spec = importlib.util.spec_from_file_location('sec', os.path.join(HERE, 'admin-security-test.py'))
sec = importlib.util.module_from_spec(spec); spec.loader.exec_module(sec)
check = sec.check


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p


def wr(p, t):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w').write(t)


def main():
    mariadbd = which('mariadbd', 'mysqld')
    install = which('mariadb-install-db', 'mysql_install_db')
    cli = which('mariadb', 'mysql')
    dump = which('mariadb-dump', 'mysqldump')
    if not all((mariadbd, install, cli, dump)):
        print('(bo qua: thieu MariaDB that - can mariadbd, mariadb-install-db, mariadb, mariadb-dump)')
        return 0
    tmp = tempfile.mkdtemp(prefix='stgdb-')
    db = None
    srv = None
    try:
        os.chmod(tmp, 0o755)
        app, run, www0, adm0 = sec.build_tree(tmp)
        www = os.path.join(app, 'www')
        shutil.move(www0, www)
        shutil.copy(os.environ.get('STAGING_PAGE') or os.path.join(HERE, '..', 'runtimes', 'templates', 'admin-staging.php'), os.path.join(www, '_admin', 'staging.php'))  # STAGING_PAGE: doi chung am
        wr(os.path.join(www, 'wp-config.php'),
           "<?php\ndefine('DB_NAME', 'wordpress');\ndefine('DB_USER', 'wordpress');\nrequire_once ABSPATH . 'wp-settings.php';\n")
        wr(os.path.join(www, 'MARKER.txt'), 'LIVE-ORIGINAL')
        wr(os.path.join(www, 'wp-content', 'uploads', 'anh.jpg'), 'IMG')
        sock = os.path.join(run, 'mysql.sock')
        data = os.path.join(tmp, 'data')
        r = subprocess.run([install, '--user=' + DB_OS_USER, '--datadir=' + data, '--auth-root-authentication-method=normal'], capture_output=True, text=True)
        if r.returncode != 0:
            print('(bo qua: khong khoi tao duoc datadir MariaDB: %s)' % r.stderr[-120:]); return 0
        db = subprocess.Popen([mariadbd] + ([] if os.geteuid() != 0 else ['--user=root']) + ['--datadir=' + data, '--socket=' + sock, '--skip-networking',
                               '--pid-file=' + os.path.join(tmp, 'm.pid'), '--innodb-buffer-pool-size=32M',
                               '--log-error=' + os.path.join(tmp, 'err.log')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            if os.path.exists(sock) and subprocess.run([cli, '--socket=' + sock, '-uroot', '-e', 'select 1'], capture_output=True).returncode == 0:
                break
            time.sleep(0.5)
        else:
            print('(bo qua: mariadbd khong len)'); return 0

        def sql(q, user='root', pw=None, dbname=None):
            # --default-character-set=utf8mb4: mac dinh cua client co the la latin1/utf8mb3 -> INSERT co emoji LOI
            # va (neu nuot stderr) bang rong ma khong ai biet -> phep so checksum "khop" tro nen vo nghia.
            cmd = [cli, '--socket=' + sock, '--default-character-set=utf8mb4', '-u' + user, '-N', '-B', '-e', q]
            if pw: cmd.insert(3, '-p' + pw)
            if dbname: cmd.append(dbname)
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                print('   [sql loi] %s -> %s' % (q[:60], r.stderr.strip()[:120]))
            return r.stdout.strip()

        def live_count(t): return sql("SELECT COUNT(*) FROM %s" % t, dbname='wordpress')
        sql("CREATE DATABASE wordpress CHARACTER SET utf8mb4")
        sql("CREATE USER 'wordpress'@'localhost' IDENTIFIED BY 'wordpress'")
        sql("GRANT ALL ON `wordpress%`.* TO 'wordpress'@'localhost'")
        sql("CREATE TABLE wp_options (option_id INT AUTO_INCREMENT PRIMARY KEY, option_name VARCHAR(191), option_value LONGTEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", dbname='wordpress')
        sql("INSERT INTO wp_options (option_name, option_value) VALUES ('siteurl','http://live.example'),('blogname','Tiếng Việt 😀 gốc')", dbname='wordpress')
        sql("CREATE TABLE wp_posts (ID INT AUTO_INCREMENT PRIMARY KEY, post_title TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", dbname='wordpress')
        sql("INSERT INTO wp_posts (post_title) VALUES ('Bài viết 1'),('Post 2 🚀')", dbname='wordpress')

        check('du lieu goc da vao DB LIVE (2 option + 2 bai viet, ke ca tieng Viet/emoji) - neu khong, moi phep so sanh sau do vo nghia',
              live_count('wp_options') == '2' and live_count('wp_posts') == '2', (live_count('wp_options'), live_count('wp_posts')))
        ext = os.path.join(tmp, 'ext-db'); os.makedirs(ext)  # build_tree da co 'ext' (libphpcli gia cho wpcli) - dung thu muc rieng
        os.symlink(cli, os.path.join(ext, 'libmysqlcli.so'))
        os.symlink(dump, os.path.join(ext, 'libmysqldump.so'))
        s = socket.socket(); s.bind(('127.0.0.1', 0)); port = s.getsockname()[1]; s.close()
        srv = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', www, '-d', 'session.save_path=' + os.path.join(tmp, 'sess'),
                                '-d', 'auto_prepend_file=' + os.path.join(tmp, 'spoof.php'), '-d', 'display_errors=1'],
                               env=dict(os.environ, APP_HOME=app, EXT_DIR=ext, STAGING_PORT='18999'),
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(100):
            try: socket.create_connection(('127.0.0.1', port), timeout=0.2).close(); break
            except OSError: time.sleep(0.1)
        c = sec.Client(port, '10.2.2.2'); c.login()
        staging = os.path.join(app, 'www-staging')
        safety = os.path.join(app, 'staging-safety-backups')

        def act(action):
            tok = c.token('staging')
            return c.req('POST', '/_admin/staging.php', {'action': action, 'csrf_token': tok})[1]

        def live(q): return sql(q, dbname='wordpress')
        def stg(q): return sql(q, dbname='wordpress_staging')
        def checksum(dbname):
            return sql("CHECKSUM TABLE wp_options, wp_posts", dbname=dbname)

        print('== 1. clone voi MariaDB that ==')
        body = act('clone')
        check('clone: bao "Da tao xong ban staging", co www-staging/', 'Da tao xong ban staging' in body and os.path.isdir(staging), body[-250:])
        check('clone: DB wordpress_staging co CUNG du lieu (checksum cac bang trung khop voi LIVE)',
              checksum('wordpress_staging') and [x.split('\t')[1] for x in checksum('wordpress_staging').splitlines()] == [x.split('\t')[1] for x in checksum('wordpress').splitlines()],
              (checksum('wordpress'), checksum('wordpress_staging')))
        check('clone: tieng Viet + emoji (utf8mb4) di qua dump/nap NGUYEN VEN', stg("SELECT option_value FROM wp_options WHERE option_name='blogname'") == 'Tiếng Việt 😀 gốc', stg("SELECT option_value FROM wp_options WHERE option_name='blogname'"))
        check('clone: wp-config cua staging tro toi wordpress_staging, LIVE khong bi doi', "'wordpress_staging'" in open(os.path.join(staging, 'wp-config.php')).read() and "define('DB_NAME', 'wordpress');" in open(os.path.join(www, 'wp-config.php')).read())

        print('== 2. promote (staging da sua) -> LIVE ==')
        stg("UPDATE wp_options SET option_value='TEN-STAGING' WHERE option_name='blogname'")
        stg("INSERT INTO wp_posts (post_title) VALUES ('Bai chi co o staging')")
        wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEW')
        body = act('promote')
        check('promote: bao "Da promote xong"', 'Da promote xong' in body, body[-300:])
        check('promote: DB LIVE nhan du lieu staging (ten moi + bai viet moi, tong 3 bai)',
              live("SELECT option_value FROM wp_options WHERE option_name='blogname'") == 'TEN-STAGING' and live("SELECT COUNT(*) FROM wp_posts") == '3',
              (live("SELECT option_value FROM wp_options WHERE option_name='blogname'"), live("SELECT COUNT(*) FROM wp_posts")))
        check('promote: file LIVE = staging, wp-config LIVE tro lai DB_NAME=wordpress',
              open(os.path.join(www, 'MARKER.txt')).read() == 'STAGING-NEW' and "define('DB_NAME', 'wordpress');" in open(os.path.join(www, 'wp-config.php')).read())
        check('promote: da don DB wordpress_staging va thu muc www-staging', stg('SELECT 1') == '' and not os.path.exists(staging))
        dumps = [f for f in os.listdir(safety) if f.startswith('pre-promote-db-')]
        check('promote: co ban an toan DB truoc khi ghi de', len(dumps) == 1, os.listdir(safety))
        if dumps:
            sql("CREATE DATABASE wordpress_restorecheck CHARACTER SET utf8mb4")
            rr = subprocess.run([cli, '--socket=' + sock, '-uroot', 'wordpress_restorecheck'], stdin=open(os.path.join(safety, dumps[0])), capture_output=True, text=True)
            check('ban an toan KHOI PHUC DUOC that: nap vao DB moi cho ra du lieu GOC (ten cu + 2 bai)',
                  rr.returncode == 0 and sql("SELECT option_value FROM wp_options WHERE option_name='blogname'", dbname='wordpress_restorecheck') == 'Tiếng Việt 😀 gốc'
                  and sql("SELECT COUNT(*) FROM wp_posts", dbname='wordpress_restorecheck') == '2', rr.stderr[-200:])

        print('== 3. LOI THAT (khong chen): DB staging bi xoa truoc khi promote ==')
        act('clone')
        wr(os.path.join(staging, 'MARKER.txt'), 'STAGING-NEWER')
        sql("DROP DATABASE wordpress_staging")  # mat DB staging - loi that
        before_sum = checksum('wordpress'); before_marker = open(os.path.join(www, 'MARKER.txt')).read()
        body = act('promote')
        check('DB staging mat -> promote DUNG, khong noi "Da promote xong"', 'Da promote xong' not in body and ('khong hoan chinh' in body or 'DUNG' in body), body[-300:])
        check('DB staging mat -> DB LIVE va file LIVE KHONG bi doi', checksum('wordpress') == before_sum and open(os.path.join(www, 'MARKER.txt')).read() == before_marker)
        check('DB staging mat -> thu muc www-staging van con (khong mat them du lieu)', os.path.isdir(staging))
    finally:
        for pr in (srv, db):
            if pr:
                pr.terminate()
                try: pr.wait(timeout=10)
                except Exception: pr.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (sec.PASS, sec.FAIL))
    return 0 if sec.FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
