#!/usr/bin/env python3
"""Kiem thu quet LO HONG DA BIET (security-vuln.php, HANDOFF.md muc 1br-H).

KHONG goi mang that: dung 1 may chu HTTP gia lap tren 127.0.0.1 tra du lieu TU SOAN theo cau truc ban ghi cua API WPVulnerability (lay tu ma nguon plugin
WPVulnerability: data.vulnerability[].operator{min_version,min_operator,max_version,max_operator,unfixed,closed}, impact.cvss{score,severity}, source[]).
=> Kiem duoc logic (so phien ban, cache, gioi han, xu ly loi, du lieu doc hai tu ben ngoai) nhung KHONG chung minh dich vu that (www.wpvulnerability.net) con
dung dinh dang nay - xem docs/SECURITY.md muc gioi han. Neu dat WP_REAL_SRC (WordPress that) / WP_EXTRA_PLUGINS (ma nguon plugin that) thi kiem them viec
DOC PHIEN BAN tu tieu de plugin/theme that.
"""
import fcntl, json, os, re, shutil, subprocess, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
SRC = os.path.normpath(os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'java', 'com', 'wppocket', 'server'))
VULN = os.environ.get('VULN_LOGIC') or os.path.join(TPL, 'security-vuln.php')      # VULN_LOGIC: chi de chay "doi chung am" (bien the co chu y gay loi phai lam test THAT BAI)
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:300]) if d else ''))


def rec(name, min_v='', min_op='', max_v='', max_op='', sev='h', score=7.5, unfixed=0, closed=0, src=None, extra=None):
    r = {'name': name, 'description': '<b>mo ta dai khong can luu</b>', 'operator': {'min_version': min_v or None, 'min_operator': min_op or None, 'max_version': max_v or None,
         'max_operator': max_op or None, 'unfixed': str(unfixed), 'closed': str(closed)}, 'impact': {'cvss': {'version': '3.1', 'score': score, 'severity': sev}, 'cwe': []},
         'source': src if src is not None else [{'name': 'CVE-2026-1111', 'id': 'CVE-2026-1111', 'description': 'x', 'link': 'https://example.test/cve/1111', 'date': '2026-01-01'}]}
    if extra:
        r.update(extra)
    return r


def body(recs, name='x'):
    return json.dumps({'error': 0, 'message': None, 'data': {'name': name, 'link': 'https://example.test/', 'latest': 0, 'closed': 0, 'vulnerability': recs}})


class Mock:
    """May chu API gia lap: ROUTES {'/plugin/<slug>/': (status, body)}; ghi lai moi yeu cau (duong dan + tieu de)."""

    def __init__(self):
        self.routes, self.hits, self.headers = {}, [], []
        outer = self

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                outer.hits.append(self.path)
                outer.headers.append({k.lower(): v for k, v in self.headers.items()})
                st, b = outer.routes.get(self.path, (200, json.dumps({'error': 1, 'message': 'not found', 'data': None})))
                bb = b.encode() if isinstance(b, str) else b
                self.send_response(st)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(bb)))
                self.end_headers()
                self.wfile.write(bb)

            def log_message(self, *a):
                pass
        self.srv = ThreadingHTTPServer(('127.0.0.1', 0), H)
        self.port = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def stop(self):
        self.srv.shutdown()


def php_lib(code, timeout=120):
    r = subprocess.run(['php', '-d', 'display_errors=1', '-d', 'date.timezone=UTC', '-r', 'define("WPP_VULN_AS_LIB", 1); require %r; %s' % (VULN, code)], capture_output=True, text=True, timeout=timeout)
    return (r.stdout + r.stderr).strip()


def cli(docroot, rundir, mode='check'):
    r = subprocess.run(['php', '-d', 'display_errors=1', VULN, docroot, rundir, mode], capture_output=True, text=True, timeout=120)
    return r.returncode, (r.stdout + r.stderr).strip()


def mkplugin(root, slug, version, name=None, extra_files=None):
    d = os.path.join(root, 'wp-content', 'plugins', slug)
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, slug + '.php'), 'w').write("<?php\n/**\n * Plugin Name: %s\n * Version: %s\n * Description: x\n */\n" % (name or slug.title(), version))


def set_version(root, slug, version):
    p = os.path.join(root, 'wp-content', 'plugins', slug, slug + '.php')
    t = open(p).read()
    open(p, 'w').write(re.sub(r'Version: \S+', 'Version: ' + version, t))


def main():
    tmp = tempfile.mkdtemp(prefix='vuln-')
    M = Mock()
    try:
        root = os.path.join(tmp, 'www')
        run = os.path.join(tmp, 'run')
        os.makedirs(os.path.join(root, 'wp-includes'))
        os.makedirs(run)
        open(os.path.join(root, 'wp-load.php'), 'w').write('<?php\n')
        open(os.path.join(root, 'wp-includes', 'version.php'), 'w').write("<?php\n$wp_version = '6.9.5';\n$wp_local_package = 'en_US';\n")
        os.makedirs(os.path.join(root, 'wp-content', 'themes', 'old-theme'))
        open(os.path.join(root, 'wp-content', 'themes', 'old-theme', 'style.css'), 'w').write("/*\nTheme Name: Old Theme\nVersion: 1.0.0\n*/\n")
        for slug, ver in (('vuln-plug', '1.2.0'), ('fixed-plug', '2.0.0'), ('unfixed-plug', '3.1.0'), ('unknown-plug', '1.0'), ('low-plug', '0.9')):
            mkplugin(root, slug, ver)
        os.makedirs(os.path.join(root, 'wp-content', 'plugins', 'Bad Name'))
        open(os.path.join(root, 'wp-content', 'plugins', 'Bad Name', 'x.php'), 'w').write("<?php\n/* Plugin Name: Bad\nVersion: 1 */\n")
        os.makedirs(os.path.join(root, 'wp-content', 'plugins', 'no-header'))
        open(os.path.join(root, 'wp-content', 'plugins', 'no-header', 'a.php'), 'w').write("<?php\necho 1;\n")
        open(os.path.join(root, 'wp-content', 'plugins', 'hello.php'), 'w').write("<?php\n/* Plugin Name: Hello\nVersion: 1.7 */\n")
        M.routes = {
            '/core/6.9.5/': (200, body([rec('WordPress < 7.0.2 - SQLi', '', '', '7.0.2', 'lt', sev='c', score=9.8, src=[{'name': 'CVE-2026-7777', 'link': 'https://example.test/c7777'}])])),
            '/plugin/vuln-plug/': (200, body([rec('Vuln Plug <= 1.2.5 - Unauth RCE', '', '', '1.2.5', 'le', sev='h', score=8.1), rec('Vuln Plug < 1.0 - Cu da va', '', '', '1.0', 'lt')])),
            '/plugin/fixed-plug/': (200, body([rec('Fixed Plug < 1.9 - XSS', '', '', '1.9', 'lt', sev='m', score=5.4)])),
            '/plugin/unfixed-plug/': (200, body([rec('Unfixed Plug >= 3.0 - CSRF', '3.0.0', 'ge', '', '', sev='m', score=6.1, unfixed=1)])),
            '/plugin/low-plug/': (200, body([rec('Low Plug <= 1.0 - info leak', '', '', '1.0', 'le', sev='l', score=3.1)])),
            '/theme/old-theme/': (200, body([rec('Old Theme <= 1.0 - XSS', '', '', '1.0.0', 'le', sev='h', score=7.2)])),
        }
        open(os.path.join(run, 'vuln-api-base'), 'w').write('http://127.0.0.1:%d\n' % M.port)
        paths = {k: os.path.join(run, v) for k, v in dict(flag='vuln-check-on', result='security-vuln.json', cache='vuln-cache.json', events='security-events.log', seen='vuln-seen.json', base='vuln-api-base').items()}

        print('== 1. kiem ke (doc phien ban tu tieu de) ==')
        inv = json.loads(php_lib('echo json_encode(wpp_vuln_inventory(%r));' % root))
        check('loi WordPress 6.9.5, 5 plugin co thu muc hop le, 1 theme', inv['core'] == '6.9.5' and sorted(inv['plugins']) == ['fixed-plug', 'low-plug', 'unfixed-plug', 'unknown-plug', 'vuln-plug'] and list(inv['themes']) == ['old-theme'], inv)
        check('plugin 1 file (hello.php) KHONG duoc kiem ke; thu muc ten la ("Bad Name") va thu muc khong co tieu de bi bo qua + ghi lai ly do',
              'hello' not in inv['plugins'] and 'Bad Name' not in inv['plugins'] and any('Bad Name' in s for s in inv['skipped']) and any('no-header' in s for s in inv['skipped']), inv['skipped'])
        check('phien ban doc dung tu tieu de', inv['plugins']['vuln-plug']['version'] == '1.2.0' and inv['plugins']['unfixed-plug']['version'] == '3.1.0' and inv['themes']['old-theme']['version'] == '1.0.0')

        print('== 2. MAC DINH TAT: khong mo ket noi nao ==')
        rc, out = cli(root, run)
        check('khong co co vuln-check-on: bao dang TAT, thoat 0', rc == 0 and 'TAT' in out, out)
        check('... va KHONG co yeu cau nao toi API (khong gui gi ra ngoai)', M.hits == [], M.hits)
        r = json.load(open(paths['result']))
        check('ket qua ghi {enabled:false}, khong co phat hien', r['enabled'] is False and r['findings'] == [], r)

        print('== 3. bat: phat hien dung ban dang cai ==')
        open(paths['flag'], 'w').close()
        rc, out = cli(root, run)
        r = json.load(open(paths['result']))
        got = {(f['type'], f['slug'], f['sev']) for f in r['findings']}
        want = {('core', '6.9.5', 'critical'), ('plugin', 'vuln-plug', 'high'), ('plugin', 'unfixed-plug', 'medium'), ('plugin', 'low-plug', 'low'), ('theme', 'old-theme', 'high')}
        check('phat hien DUNG 5 muc (core critical, vuln-plug high, unfixed-plug medium, low-plug low, old-theme high)', {(a, b if a != 'core' else '6.9.5', c) for a, b, c in got} == want, got)
        check('KHONG bao: fixed-plug (da vuot ban va 1.9), unknown-plug (API khong biet), ban ghi cu "< 1.0" cua vuln-plug (1.2.0 khong thuoc)',
              not any(f['slug'] in ('fixed-plug', 'unknown-plug') for f in r['findings']) and sum(1 for f in r['findings'] if f['slug'] == 'vuln-plug') == 1, [f['slug'] for f in r['findings']])
        check('ban ghi unfixed duoc danh dau chua co ban va', any(f['slug'] == 'unfixed-plug' and f['unfixed'] == 1 for f in r['findings']))
        check('sap xep: nghiem trong truoc', r['findings'][0]['sev'] == 'critical' and r['counts'] == {'critical': 1, 'high': 2, 'medium': 1, 'low': 1}, r['counts'])
        check('so yeu cau = 7 (core + 5 plugin + 1 theme), khong yeu cau cho "Bad Name"/"no-header"/hello', len(M.hits) == 7 and not any('Bad' in h or 'hello' in h or 'no-header' in h for h in M.hits), M.hits)
        check('yeu cau KHONG chua gi ngoai duong dan va tieu de co ban (khong cookie/ten mien site/xac thuc)',
              all(set(h) <= {'host', 'user-agent', 'accept', 'connection'} for h in M.headers) and all(h.get('user-agent', '').startswith('WPPocketServer') for h in M.headers), M.headers[0])
        ev = open(paths['events']).read()
        lines = [l for l in ev.split('\n') if l]
        check('su kien: 4 dong (core/vuln-plug/old-theme "NGHIEM TRONG" + unfixed-plug "LO HONG PLUGIN"); muc thap KHONG co su kien',
              len(lines) == 4 and sum('LO HONG NGHIEM TRONG' in l for l in lines) == 3 and sum('LO HONG PLUGIN (medium)' in l for l in lines) == 1 and not any('low-plug' in l for l in lines), ev)
        check('su kien co ma CVE va co dau "CHUA CO BAN VA" khi chua co ban va', 'CVE-2026-7777' in ev and 'CVE-2026-1111' in ev and re.search(r'unfixed-plug 3\.1\.0 \[CHUA CO BAN VA\]', ev) is not None, ev)
        check('moi dong su kien dung dinh dang "YYYY-MM-DD HH:MM:SS ip=- ..."', all(re.match(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d ip=- \S', l) for l in lines))

        print('== 4. cache va khong lap lai canh bao ==')
        n = len(M.hits)
        rc, out = cli(root, run)
        check('chay lai ngay: 0 yeu cau moi (dung cache 12 gio)', len(M.hits) == n, len(M.hits) - n)
        check('... va KHONG ghi lai su kien da bao (chong spam Telegram moi gio)', open(paths['events']).read() == ev)
        set_version(root, 'vuln-plug', '1.9.0')
        rc, out = cli(root, run)
        r = json.load(open(paths['result']))
        check('CAP NHAT plugin len ban da va (1.9.0): het canh bao NGAY, khong can cho cache het han va khong goi them API', len(M.hits) == n and not any(f['slug'] == 'vuln-plug' for f in r['findings']), [f['slug'] for f in r['findings']])
        set_version(root, 'vuln-plug', '1.2.0')
        out = php_lib('$r = wpp_vuln_run(%r, %r, time() + 13 * 3600); echo $r["requests"], " ", count($r["findings"]);' % (root, run))
        check('sau 13 gio cache het han: hoi lai toan bo (7 yeu cau), van 5 phat hien', out == '7 5', out)

        print('== 5. loi mang / du lieu xau: khong sap, giu du lieu cu ==')
        M.routes['/plugin/vuln-plug/'] = (500, 'loi may chu')
        M.routes['/plugin/unfixed-plug/'] = (200, '<html>khong phai json</html>')
        M.routes['/plugin/low-plug/'] = (200, '')
        M.routes['/theme/old-theme/'] = (200, '{"data":')
        n = len(M.hits)
        out = php_lib('$r = wpp_vuln_run(%r, %r, time() + 26 * 3600); echo $r["failed"], " ", $r["counts"]["high"], " ", $r["counts"]["medium"], " ", $r["counts"]["critical"];' % (root, run))
        check('4 yeu cau loi (500/HTML/rong/JSON cut) duoc dem la loi, KHONG sap; du lieu cu van con nen van bao (high 2, medium 1, critical 1)', out == '4 2 1 1', out)
        n2 = len(M.hits)
        out = php_lib('$r = wpp_vuln_run(%r, %r, time() + 26 * 3600 + 1800); echo $r["requests"];' % (root, run))
        check('that bai KHONG duoc thu lai ngay (chi sau 1 gio): 30 phut sau 0 yeu cau', out == '0', out)
        out = php_lib('$r = wpp_vuln_run(%r, %r, time() + 26 * 3600 + 3700); echo $r["requests"];' % (root, run))
        check('sau hon 1 gio thu lai dung 4 muc da that bai', out == '4', out)
        M.routes['/plugin/vuln-plug/'] = (200, body([rec('Vuln Plug <= 1.2.5 - Unauth RCE', '', '', '1.2.5', 'le')]))
        M.routes['/plugin/unfixed-plug/'] = (200, body([rec('Unfixed Plug >= 3.0 - CSRF', '3.0.0', 'ge', '', '', sev='m', unfixed=1)]))
        M.routes['/plugin/low-plug/'] = (200, body([rec('Low Plug <= 1.0 - info leak', '', '', '1.0', 'le', sev='l')]))
        M.routes['/theme/old-theme/'] = (200, body([rec('Old Theme <= 1.0 - XSS', '', '', '1.0.0', 'le')]))
        print('== 6. du lieu DOC HAI tu ben ngoai ==')
        evil = rec('<script>alert(1)</script>' + 'A' * 400 + "\x07\x1b[31m", '', '', '1.2.5', 'le', src=[{'name': 'CVE-2026-1' + 'X' * 100, 'link': 'javascript:alert(1)'}, {'name': "x\ny", 'link': 'https://ok.example/p'}])
        M.routes['/plugin/vuln-plug/'] = (200, body([evil, {'operator': 'khong-phai-mang'}, 'chuoi', None, rec('Op la', '1.0', 'system', '9.9', 'le')]))
        run2 = os.path.join(tmp, 'run2')
        os.makedirs(run2)
        shutil.copy(paths['base'], os.path.join(run2, 'vuln-api-base'))
        open(os.path.join(run2, 'vuln-check-on'), 'w').close()
        rc, out = cli(root, run2)
        r = json.load(open(os.path.join(run2, 'security-vuln.json')))
        f = [x for x in r['findings'] if x['slug'] == 'vuln-plug']
        check('ban ghi rac (mang sai kieu, chuoi, null, toan tu la "system") bi bo qua; ban ghi hop le van duoc xu ly, khong sap', rc == 0 and len(f) == 1, (rc, out, f))
        check('tieu de bi cat <= 200 ky tu va bo ky tu dieu khien', f and len(f[0]['title']) <= 200 and not re.search(r'[\x00-\x1f\x7f]', f[0]['title']), f[0]['title'][:60] if f else '')
        check('lien ket "javascript:" bi bo, lien ket https giu lai; ten nguon bi cat', f and [s['link'] for s in f[0]['src']] == ['', 'https://ok.example/p'] and all(len(s['name']) <= 40 for s in f[0]['src']), f[0]['src'] if f else '')
        evl = open(os.path.join(run2, 'security-events.log')).read()
        check('dong su kien khong chua ky tu dieu khien tu du lieu ngoai, 1 dong/su kien', not re.search(r'[\x00-\x09\x0b-\x1f\x7f]', evl) and all(re.match(r'^\d{4}-\d\d-\d\d ', l) for l in evl.split('\n') if l), repr(evl[:200]))
        M.routes['/plugin/vuln-plug/'] = (200, 'x' * (3 * 1024 * 1024))
        shutil.rmtree(os.path.join(run2)); os.makedirs(run2)
        shutil.copy(paths['base'], os.path.join(run2, 'vuln-api-base')); open(os.path.join(run2, 'vuln-check-on'), 'w').close()
        t0 = time.time()
        rc, out = cli(root, run2)
        check('phan hoi 3MB (khong phai JSON) bi cat o 2MB, xu ly xong nhanh, khong het bo nho', rc == 0 and time.time() - t0 < 30, (rc, out[-100:]))

        print('== 7. dia chi API: chi nhan dia chi hop le ==')
        for bad in ('file:///etc/passwd', 'http://a b/', 'ftp://x/', 'http://127.0.0.1:1/x?y=1', 'javascript:alert(1)', "http://x/'; DROP", 'http://' + 'a' * 400, ''):
            open(paths['base'], 'w').write(bad)
            out = php_lib('echo wpp_vuln_api_base(%r);' % run)
            check('vuln-api-base khong hop le %r -> dung dia chi mac dinh' % bad[:30], out == 'https://www.wpvulnerability.net', out)
        for good, exp in (('https://mirror.example/api/', 'https://mirror.example/api'), ('http://192.168.1.5:8080', 'http://192.168.1.5:8080')):
            open(paths['base'], 'w').write(good + '\n')
            check('vuln-api-base hop le %r duoc dung' % good, php_lib('echo wpp_vuln_api_base(%r);' % run) == exp)
        open(paths['base'], 'w').write('http://127.0.0.1:%d\n' % M.port)

        print('== 8. gioi han so yeu cau / thoi gian ==')
        run3 = os.path.join(tmp, 'run3')
        os.makedirs(run3)
        open(os.path.join(run3, 'vuln-check-on'), 'w').write('')
        open(os.path.join(run3, 'vuln-api-base'), 'w').write('http://127.0.0.1:%d' % M.port)
        root3 = os.path.join(tmp, 'www3')
        shutil.copytree(root, root3)
        for i in range(100):
            mkplugin(root3, 'bulk-%03d' % i, '1.0')
        n = len(M.hits)
        out = php_lib('$r = wpp_vuln_run(%r, %r, time()); echo $r["requests"], " ", $r["truncated"] ? "T" : "F";' % (root3, run3))
        check('107 muc can hoi: chi gui toi da 80 yeu cau/lan va danh dau CHUA XONG', out == '80 T' and len(M.hits) - n == 80, (out, len(M.hits) - n))
        out = php_lib('$r = wpp_vuln_run(%r, %r, time()); echo $r["requests"], " ", $r["truncated"] ? "T" : "F";' % (root3, run3))
        check('lan sau tiep tuc phan con lai (khong hoi lai 80 muc da co cache): 27 yeu cau, xong', out == '27 F', out)

        print('== 9. so sanh phien ban (version_compare cua PHP) ==')
        cases = [  # (ban ghi op, phien ban, ky vong)
            (('', '', '1.2.5', 'le'), '1.2.5', 1), (('', '', '1.2.5', 'le'), '1.2.6', 0), (('', '', '1.2.5', 'lt'), '1.2.5', 0), (('', '', '1.2.5', 'lt'), '1.2.4', 1),
            (('1.0', 'ge', '1.9', 'lt'), '1.0', 1), (('1.0', 'ge', '1.9', 'lt'), '1.9', 0), (('1.0', 'gt', '1.9', 'lt'), '1.0', 0), (('1.0', 'ge', '', ''), '99.1', 1),
            (('', '', '1.2.5', 'le'), '1.2.5-beta1', 1), (('', '', '2.0.0', 'lt'), '2.0.0-rc1', 1), (('', '', '10.0', 'lt'), '9.9.9', 1), (('', '', '1.2', 'le'), '1.10', 0),
            (('', '', '', ''), '1.0', 0), (('1.0', 'system', '', ''), '2.0', 0), (('', '', '1.0', ''), '0.5', 0), (('', 'ge', '', 'le'), '1.0', 0),
        ]
        bad = []
        for (mn, mo, mx, xo), ver, exp in cases:
            rr = {'op': {'min_version': mn, 'min_operator': mo, 'max_version': mx, 'max_operator': xo}}
            got = php_lib('echo wpp_vuln_applicable(json_decode(%r, true), %r) ? 1 : 0;' % (json.dumps(rr), ver))
            if got != str(exp):
                bad.append((mn, mo, mx, xo, ver, exp, got))
        check('%d truong hop so sanh phien ban (bien, tien ban -beta/-rc, 1.10 > 1.9, toan tu la, thieu can) deu dung' % len(cases), not bad, bad)

        print('== 10. khoa chong chay song song ==')
        lock = os.path.join(run, 'vuln-check.lock')
        fh = open(lock, 'w')
        fcntl.flock(fh, fcntl.LOCK_EX)
        n = len(M.hits)
        rc, out = cli(root, run)
        check('co lan kiem khac dang chay (giu khoa): ban thu hai thoat ngay, khong hoi API', rc == 0 and 'dang co lan kiem khac' in out and len(M.hits) == n, out)
        fcntl.flock(fh, fcntl.LOCK_UN)
        fh.close()

        print('== 11. su kien duoc ung dung Android phan loai ==')
        kt = open(os.path.join(SRC, 'MonitorLogic.kt'), encoding='utf-8').read()
        urg = re.findall(r'"([^"]+)"', re.search(r'SECURITY_URGENT = listOf\(([^)]*)\)', kt).group(1))
        note = re.findall(r'"([^"]+)"', re.search(r'SECURITY_NOTICE = listOf\(([^)]*)\)', kt).group(1))
        evs = [re.search(r'ip=\S+\s+(.*)', l).group(1) for l in ev.split('\n') if l]
        check('Python: 3 dong "LO HONG NGHIEM TRONG" khop tien to khan, 1 dong "LO HONG PLUGIN" khop tien to luu y',
              sum(any(e.startswith(p) for p in urg) for e in evs) == 3 and sum(any(e.startswith(p) for p in note) for e in evs) == 1, (urg, note, evs))
        if shutil.which('kotlinc') and shutil.which('kotlin'):
            out = tempfile.mkdtemp(prefix='vuln-kt-')
            try:
                r = subprocess.run(['kotlinc', '-nowarn', os.path.join(SRC, 'MonitorLogic.kt'), os.path.join(SRC, 'AlertThresholds.kt'), os.path.join(HERE, 'SecurityEventsContractTest.kt'), '-d', out], capture_output=True, text=True)
                check('Kotlin bien dich', r.returncode == 0, r.stderr[-300:])
                if r.returncode == 0:
                    r = subprocess.run(['kotlin', '-cp', out, 'SecurityEventsContractTestKt', paths['events'], '3', '1', '0'], capture_output=True, text=True)
                    check('Kotlin: nhat ky do PHP that ghi -> 3 khan + 1 luu y, moi dong duoc phan loai', r.returncode == 0 and 'FAIL' not in r.stdout, r.stdout[-400:] + r.stderr[-200:])
            finally:
                shutil.rmtree(out, ignore_errors=True)
        else:
            print('(bo qua phan Kotlin: khong co kotlinc/kotlin)')

        print('== 12. doc phien ban tu ma nguon WordPress / plugin THAT (neu co) ==')
        wp = os.environ.get('WP_REAL_SRC', '')
        if os.path.isfile(os.path.join(wp, 'wp-load.php')):
            real = json.loads(php_lib('echo json_encode(wpp_vuln_inventory(%r));' % wp))
            ver = re.search(r"\$wp_version\s*=\s*'([^']+)'", open(os.path.join(wp, 'wp-includes', 'version.php')).read()).group(1)
            check('WordPress that: phien ban loi doc dung (%s)' % ver, real['core'] == ver, real['core'])
            akp = os.path.join(wp, 'wp-content', 'plugins', 'akismet', 'akismet.php')
            if os.path.isfile(akp):       # ban WordPress tren GitHub khong kem Akismet; ban zip wordpress.org thi co
                av = re.search(r'^\s*\*?\s*Version:\s*(\S+)', open(akp).read(), re.M)
                check('plugin Akismet that: doc dung phien ban tu tieu de', av is not None and dict(real['plugins']).get('akismet', {}).get('version') == av.group(1), (real['plugins'], av and av.group(1)))
            check('theme that (Twenty ...): doc duoc ten + phien ban', any(k.startswith('twenty') and re.match(r'^\d', v['version']) for k, v in real['themes'].items()), real['themes'])
        extra = [d for d in os.environ.get('WP_EXTRA_PLUGINS', '').split(':') if d and os.path.isdir(d)]
        if extra:
            r3 = os.path.join(tmp, 'realplug')
            os.makedirs(os.path.join(r3, 'wp-content', 'plugins'))
            for d in extra:
                shutil.copytree(d, os.path.join(r3, 'wp-content', 'plugins', os.path.basename(d.rstrip('/'))), symlinks=False, ignore=shutil.ignore_patterns('.git', 'node_modules', 'vendor', 'tests'))
            real = json.loads(php_lib('echo json_encode(wpp_vuln_inventory(%r));' % r3))
            names = [os.path.basename(d.rstrip('/')) for d in extra]
            check('plugin that (%s): ca %d plugin deu doc duoc phien ban tu tieu de' % (', '.join(names), len(names)), all(n in real['plugins'] and re.match(r'^\d', real['plugins'][n]['version']) for n in names), (real['plugins'], real['skipped']))
        if not (os.path.isfile(os.path.join(wp, 'wp-load.php')) or extra):
            print('(bo qua phan 12: dat WP_REAL_SRC / WP_EXTRA_PLUGINS)')
    finally:
        M.stop()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
