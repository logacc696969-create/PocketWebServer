#!/usr/bin/env python3
"""Kiem thu CHUOI chan IP bang nginx THAT + php-fpm THAT (HANDOFF.md muc 1br-H):
   nginx ghi nginx-security.log (IP khach that qua CF-Connecting-IP/realip) -> security-guard.php cham diem + ghi ban-list.conf -> co ban-reload
   -> HUP nginx (start-lamp.sh lam viec nay) -> IP bi chan nhan 444 (dong ket noi, khong tra noi dung) va KHONG vao log chinh -> huy chan -> vao lai.
Cac test rieng (security-guard-test.py: cham diem/ghi file; nginx-deny-test.py: luat chan) khong kiem DUOC chuoi noi giua chung - chi nginx that moi lo ra
loi dinh dang log, thu tu include, geo khong nap lai, buffer log chua flush...

Can: nginx CO module realip (nginx -V), php-fpm, php CLI, python3. Thieu thi bo qua (exit 0).
"""
import http.client, json, os, re, shutil, signal, socket, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
TPLDIR = os.path.normpath(os.path.join(HERE, '..', 'runtimes', 'templates'))
TPL = os.environ.get('NGINX_TPL') or os.path.join(TPLDIR, 'nginx.conf.template')
GUARD = os.path.join(TPLDIR, 'security-guard.php')
PASS = FAIL = 0


def check(n, c, d=''):
    global PASS, FAIL
    if c:
        PASS += 1
        print('PASS: ' + n)
    else:
        FAIL += 1
        print('FAIL: ' + n + (('  -> ' + str(d)[:240]) if d else ''))


def which(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wr(root, rel, txt):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w').write(txt)


def main():
    nginx = which('nginx')
    fpm = which('php-fpm8.5', 'php-fpm8.4', 'php-fpm8.3', 'php-fpm8.2', 'php-fpm')
    php = which('php')
    if not (nginx and fpm and php):
        print('(bo qua: thieu nginx / php-fpm / php CLI)')
        return 0
    v = subprocess.run([nginx, '-V'], capture_output=True, text=True)
    if 'http_realip_module' not in (v.stdout + v.stderr):
        print('(bo qua: nginx khong co module realip - khong gia lap duoc IP khach that; app o che do nay cung khong chan duoc IP)')
        return 0
    tmp = tempfile.mkdtemp(prefix='secnginx-')
    os.chmod(tmp, 0o755)
    doc, run = os.path.join(tmp, 'www'), os.path.join(tmp, 'run')
    os.makedirs(run)
    os.makedirs(os.path.join(tmp, 'stg'))
    wr(doc, 'index.php', '<?php echo "INDEX-OK";\n')
    wr(doc, 'wp-login.php', '<?php http_response_code(200); echo "LOGIN-FORM";\n')   # dang nhap SAI cua WordPress that tra 200
    port, sport = free_port(), free_port()
    sock = os.path.join(run, 'fpm.sock')
    conf = open(TPL, encoding='utf-8').read()
    for k, val in (('__RUNDIR__', run), ('__DOCROOT__', doc), ('__WEBROOT__', doc), ('__PORT__', str(port)), ('__STAGING_PORT__', str(sport)), ('__FPM_SOCK__', sock),
                   ('__CF_REALIP_DIRECTIVES__', 'set_real_ip_from 127.0.0.1; real_ip_header CF-Connecting-IP; real_ip_recursive off;')):   # dung dong start-lamp.sh sinh ra
        conf = conf.replace(k, val)
    conf = conf.replace('__STAGING_DOCROOT__', os.path.join(tmp, 'stg'))
    open(os.path.join(tmp, 'nginx.conf'), 'w').write(conf)
    open(os.path.join(run, 'ban-list.conf'), 'a').close()
    for m in set(re.findall(r'(?:client_body|proxy|fastcgi|uwsgi|scgi)_temp_path\s+([^;\s]+)', conf)):
        os.makedirs(m, exist_ok=True)
    open(os.path.join(tmp, 'fpm.conf'), 'w').write('[global]\npid=%s/fpm.pid\nerror_log=%s/fpm.log\ndaemonize=no\n[www]\nuser=root\ngroup=root\nlisten=%s\nlisten.mode=0666\npm=static\npm.max_children=2\n' % (tmp, tmp, sock))
    open(os.path.join(tmp, 'php.ini'), 'w').write('cgi.fix_pathinfo=0\n')
    procs = []

    def get(path, ip=None, method='GET', ua='Mozilla/5.0 (X11; Linux) TestBrowser', body=None):
        """Tra (status, headers, body) hoac ('CLOSED', None, None) neu nginx dong ket noi khong tra loi (444)."""
        h = {'User-Agent': ua}
        if ip:
            h['CF-Connecting-IP'] = ip
        if body is not None:
            h['Content-Type'] = 'application/x-www-form-urlencoded'
        c = http.client.HTTPConnection('127.0.0.1', port, timeout=20)
        try:
            c.request(method, path, body=body, headers=h)
            r = c.getresponse()
            return r.status, {k.lower(): x for k, x in r.getheaders()}, r.read().decode('utf-8', 'replace')
        except (http.client.RemoteDisconnected, ConnectionResetError, http.client.BadStatusLine):
            return 'CLOSED', None, None
        finally:
            c.close()

    def flush_logs():
        """access_log co buffer=8k flush=15s: USR1 (reopen) ghi het buffer ra file ngay."""
        pid = int(open(os.path.join(run, 'nginx.pid')).read().strip()) if os.path.exists(os.path.join(run, 'nginx.pid')) else procs[1].pid
        os.kill(pid, signal.SIGUSR1)
        time.sleep(0.6)

    def guard():
        r = subprocess.run([php, GUARD, run], capture_output=True, text=True, timeout=60)
        return r.stdout + r.stderr

    def hup():
        """Lam nhu start-lamp.sh khi thay ban-reload: xoa co, HUP nginx, cho worker moi."""
        if os.path.exists(os.path.join(run, 'ban-reload')):
            os.remove(os.path.join(run, 'ban-reload'))
            os.kill(procs[1].pid, signal.SIGHUP)
            time.sleep(1.0)
            return True
        return False

    def log(name):
        p = os.path.join(run, name)
        return open(p, encoding='utf-8', errors='replace').read() if os.path.exists(p) else ''

    try:
        procs.append(subprocess.Popen([fpm, '-R', '--nodaemonize', '--fpm-config', os.path.join(tmp, 'fpm.conf'), '-c', os.path.join(tmp, 'php.ini')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        procs.append(subprocess.Popen([nginx, '-c', os.path.join(tmp, 'nginx.conf'), '-g', 'daemon off;'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for _ in range(100):
            try:
                socket.create_connection(('127.0.0.1', port), timeout=0.2).close()
                break
            except OSError:
                time.sleep(0.1)
        for _ in range(100):
            if os.path.exists(sock):
                break
            time.sleep(0.1)
        sc, hd, b = get('/')
        check('nginx + php-fpm that hoat dong', sc == 200 and 'INDEX-OK' in b, (sc, (b or '')[:60]))
        if sc != 200:
            return 1

        print('== 1. dau van tay + phuong thuc ==')
        check('header Server khong lo so phien ban nginx (server_tokens off)', hd.get('server') == 'nginx', hd.get('server'))
        sc, _, _ = get('/', method='TRACE')
        check('TRACE -> 405 (phuong thuc la bi tu choi som)', sc == 405, sc)
        sc, _, _ = get('/', method='PROPFIND')
        check('PROPFIND -> 405', sc == 405, sc)

        print('== 2. nginx ghi nginx-security.log voi IP KHACH THAT (realip) dung dinh dang ==')
        A, B = '198.51.100.7', '198.51.100.8'
        get('/.env', A)
        get('/khong-co-file-nay.php', B)    # .php khong ton tai -> nginx tra 404 ngay (duong dan khong-.php di vao index.php nhu WordPress => 200)
        get('/', B)   # 200 binh thuong: KHONG duoc vao log bao mat
        flush_logs()
        sec = log('nginx-security.log')
        check('log bao mat co dong cua IP khach that (khong phai 127.0.0.1)', re.search(r'^\d+\.\d+ 198\.51\.100\.7 404 GET "/\.env" "', sec, re.M) is not None, sec[:300])
        check('log bao mat ghi 404 thuong cua IP khac', re.search(r' 198\.51\.100\.8 404 GET "/khong-co-file-nay\.php"', sec) is not None, sec[-300:])
        check('request 200 binh thuong KHONG vao log bao mat (it ghi flash)', not re.search(r'GET "/" "', sec), sec[:300])
        check('realip hoat dong: khong dong nao cua 127.0.0.1 nhac toi /.env hay file-nay.php (do IP khach that gui)', not re.search(r' 127\.0\.0\.1 \d+ GET "/(?:\.env|khong-co-file-nay\.php)"', sec), sec[-300:])
        check('request khong co header CF (TRACE tu 127.0.0.1) van ghi dung IP ket noi', ' 127.0.0.1 405 TRACE ' in sec, sec[-300:])

        print('== 3. guard cham diem -> ban-list.conf -> HUP -> 444 ==')
        out = guard()
        bl = log('ban-list.conf')
        check('guard chan IP quet .env (tep nhay cam = 10 diem -> chan ngay)', '198.51.100.7' in out and '198.51.100.7 1;' in bl, (out, bl))
        check('KHONG chan IP chi 404 thuong 1 lan', '198.51.100.8' not in bl, bl)
        check('guard tao co ban-reload', os.path.exists(os.path.join(run, 'ban-reload')))
        sc, _, b = get('/', A)
        check('TRUOC khi HUP: nginx chua nap danh sach (geo chi doc luc nap) -> van 200 (day la ly do phai co HUP)', sc == 200, sc)
        check('start-lamp.sh gui HUP khi thay ban-reload', hup())
        sc, _, b = get('/', A)
        check('SAU HUP: IP bi chan nhan 444 (nginx dong ket noi, KHONG tra noi dung)', sc == 'CLOSED', sc)
        sc, _, b = get('/wp-login.php', A)
        check('... cua dang nhap cung bi chan (ban co hieu luc toan site)', sc == 'CLOSED', sc)
        sc, _, b = get('/', B)
        check('IP khac (khong vi pham) van 200', sc == 200 and 'INDEX-OK' in b, sc)
        sc, _, b = get('/')
        check('khach 127.0.0.1 (khong CF header) van 200', sc == 200, sc)

        print('== 4. IP bi chan KHONG con ghi vao log chinh (chong day flash) ==')
        flush_logs()
        before = len(log('nginx-access.log'))
        for _ in range(30):
            get('/', A)
        flush_logs()
        after = log('nginx-access.log')
        check('30 request tu IP bi chan: khong them dong nao vao nginx-access.log', len(after) == before or '198.51.100.7' not in after[before:], after[before:][:200])
        sc, _, _ = get('/', B)
        flush_logs()
        check('IP binh thuong van duoc ghi vao log chinh', '198.51.100.8' in log('nginx-access.log') or ' / ' in log('nginx-access.log'))

        print('== 5. dung IP khong bi chan oan ==')
        for i in range(25):
            get('/khong-co-%d' % i)       # 127.0.0.1 quet 25 lan 404
        flush_logs()
        guard()
        check('guard KHONG BAO GIO chan 127.0.0.1 / IP rieng (khi thieu realip moi khach deu la 127.0.0.1)', '127.0.0.1' not in log('ban-list.conf'), log('ban-list.conf'))
        C = '203.0.113.60'
        for i in range(12):
            get('/khong-co-%d' % i, C, ua='Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)')
        flush_logs()
        guard()
        check('crawler tu nhan dien (Googlebot) 404 12 lan khong bi chan', C not in log('ban-list.conf'), log('ban-list.conf'))

        print('== 6. cac nguon chan khac: UA cong cu quet, do mat khau wp-login, do phien ban ==')
        D, E, F = '203.0.113.70', '203.0.113.71', '203.0.113.72'
        get('/khong-co.php', D, ua='sqlmap/1.7.2#stable (https://sqlmap.org)')   # request 200 khong vao log bao mat => can 1 request 4xx de guard thay UA
        for i in range(6):
            get('/wp-login.php', E, method='POST', body='log=admin&pwd=x%d' % i)    # moi lan tra 200 (dang nhap sai)
        get('/wp-content/plugins/akismet/readme.txt', F)
        get('/wp-content/plugins/woocommerce/readme.txt', F)
        flush_logs()
        guard()
        bl = log('ban-list.conf')
        check('User-Agent cong cu quet (sqlmap) bi chan ngay o request loi dau tien (10 diem)', D in bl, bl)
        check('6 lan POST wp-login.php that bai tu 1 IP -> bi chan (do mat khau)', E in bl, bl)
        check('do phien ban plugin qua readme.txt 2 lan -> bi chan', F in bl, bl)
        hup()
        sc, _, _ = get('/', E)
        check('sau HUP: IP do mat khau nhan 444', sc == 'CLOSED', sc)

        print('== 7. huy chan (UI) -> vao lai duoc ==')
        code = ("define('WPP_GUARD_AS_LIB', true); require %r; echo wpp_guard_unban(%r, %r) ? 'UNBANNED' : 'NO';" % (GUARD, run, A))
        r = subprocess.run([php, '-r', code], capture_output=True, text=True)
        check('wpp_guard_unban go IP khoi danh sach', 'UNBANNED' in r.stdout and A not in log('ban-list.conf'), (r.stdout, r.stderr[:100], log('ban-list.conf')))
        check('... va tao co ban-reload', hup())
        sc, _, b = get('/', A)
        check('sau HUP: IP da huy chan vao lai duoc (200)', sc == 200 and 'INDEX-OK' in b, sc)

        print('== 8. crawler AI: mac dinh KHONG chan, bat co thi chan, nguoi dung that khong bi anh huong ==')
        sc, _, _ = get('/', '203.0.113.80', ua='Mozilla/5.0 (compatible; GPTBot/1.1; +https://openai.com/gptbot)')
        check('mac dinh (khong co block-ai-on): GPTBot van 200', sc == 200, sc)
        open(os.path.join(run, 'block-ai-on'), 'w').close()
        sc, _, _ = get('/', '203.0.113.80', ua='Mozilla/5.0 (compatible; GPTBot/1.1; +https://openai.com/gptbot)')
        check('co block-ai-on: GPTBot -> 403 (co hieu luc ngay, khong can HUP vi dung -f)', sc == 403, sc)
        sc, _, _ = get('/', '203.0.113.80', ua='Mozilla/5.0 (compatible; ClaudeBot/1.0; +claudebot@anthropic.com)')
        check('co block-ai-on: ClaudeBot -> 403', sc == 403, sc)
        sc, _, _ = get('/', '203.0.113.80', ua='ChatGPT-User/1.0')
        check('co block-ai-on: ChatGPT-User (bo lay trang theo yeu cau nguoi dung that) KHONG bi chan', sc == 200, sc)
        sc, _, _ = get('/', '203.0.113.80', ua='Mozilla/5.0 (X11; Linux x86_64) Chrome/120 Safari/537.36')
        check('co block-ai-on: trinh duyet that van 200', sc == 200, sc)
        sc, _, _ = get('/', '203.0.113.80', ua='Googlebot/2.1 (+http://www.google.com/bot.html)')
        check('co block-ai-on: Googlebot (tim kiem) van 200', sc == 200, sc)
        os.remove(os.path.join(run, 'block-ai-on'))

        print('== 9. ban-list.conf bi hong cu phap -> sanitize cuu duoc, nginx khoi dong lai duoc ==')
        open(os.path.join(run, 'ban-list.conf'), 'a').write('khong phai ip 1;\n}}}\n')
        r = subprocess.run([php, GUARD, run, 'sanitize'], capture_output=True, text=True)
        t = subprocess.run([nginx, '-t', '-c', os.path.join(tmp, 'nginx.conf')], capture_output=True, text=True)
        check('sau sanitize: nginx -t thanh cong (dong rac bi loai truoc khi nginx doc)', t.returncode == 0 and 'loai bo' in r.stdout, (r.stdout, (t.stdout + t.stderr)[-200:]))

        print('== 10. (1br-H) KHONG duoc dat disable_functions qua fastcgi_param PHP_ADMIN_VALUE theo location (ro sang request khac cua cung worker) ==')
        tpl = open(TPL, encoding='utf-8').read()
        code_only = '\n'.join(l.split('#', 1)[0] for l in tpl.splitlines())   # bo chu thich
        check('nginx.conf.template khong dat PHP_ADMIN_VALUE/PHP_VALUE cho disable_functions', not re.search(r'PHP_(?:ADMIN_)?VALUE[^;\n]*disable_functions', code_only, re.I), None)
        check('... va khong co include php-harden* (tinh nang da go: xem HANDOFF.md muc 1br-H)', 'php-harden' not in code_only)
    finally:
        for p in reversed(procs):
            try:
                p.terminate()
                p.wait(5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nTONG KET: pass=%d fail=%d' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
