#!/usr/bin/env python3
"""Kiem thu run-coverage.sh (L6; HANDOFF.md muc 1bp-J) bang kotlinc/kotlin GIA: chung minh 2 shim hoat dong that
(class duoc sao chep ra thu muc chung, agent JaCoCo duoc gan vao JAVA_OPTS cua `kotlin`, test loi duoc dem). Khong can mang/kotlinc."""
import os, subprocess, sys, tempfile, stat, yaml
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
pass_n = fail_n = 0
def check(name, cond, extra=""):
    global pass_n, fail_n
    if cond: pass_n += 1; print("PASS:", name)
    else: fail_n += 1; print("FAIL:", name, extra)
sc = os.path.join(ROOT, "scripts/tests/run-coverage.sh")
check("run-coverage.sh co cu phap shell hop le (sh -n)", subprocess.run(["sh", "-n", sc]).returncode == 0)
wf = yaml.safe_load(open(os.path.join(ROOT, ".github/workflows/coverage.yml"), encoding="utf-8"))
on = wf.get("on", wf.get(True))
check("workflow coverage CHI chay thu cong (workflow_dispatch), khong anh huong build chinh", list(on.keys()) == ["workflow_dispatch"])
check("workflow: quyen chi doc, phien ban JaCoCo co dinh, co buoc in SHA-256 de ghim", wf["permissions"] == {"contents": "read"} and wf["env"]["JACOCO_VERSION"] == "0.8.12" and any("In SHA-256" in s.get("name", "") for s in wf["jobs"]["coverage"]["steps"]))

with tempfile.TemporaryDirectory() as d:
    bindir = os.path.join(d, "bin"); os.makedirs(bindir); out = os.path.join(d, "out"); log = os.path.join(d, "kotlin-calls.log")
    def script(name, body):
        p = os.path.join(bindir, name); open(p, "w").write("#!/bin/sh\n" + body); os.chmod(p, os.stat(p).st_mode | stat.S_IEXEC)
    # kotlinc gia: ghi 1 class gia vao thu muc sau -d
    script("kotlinc", 'prev=""; for a in "$@"; do [ "$prev" = "-d" ] && { mkdir -p "$a/com/wppocket/server"; echo x > "$a/com/wppocket/server/Fake.class"; }; prev="$a"; done\nexit 0\n')
    # kotlin gia: ghi JAVA_OPTS nhan duoc
    script("kotlin", 'echo "JAVA_OPTS=$JAVA_OPTS" >> "%s"\nexit 0\n' % log)
    env = {**os.environ, "PATH": bindir + os.pathsep + os.environ["PATH"], "COVERAGE_OUT": out, "COVERAGE_SKIP_REPORT": "1", "JACOCO_AGENT": "/tmp/agent.jar"}
    r = subprocess.run(["sh", sc], capture_output=True, text=True, env=env)
    check("chay duoc voi kotlinc/kotlin gia (ma thoat 0)", r.returncode == 0, r.stdout + r.stderr)
    n_tests = len([f for f in os.listdir(os.path.join(ROOT, "scripts/tests")) if f.startswith("run-") and f.endswith("-test.sh") and f != "run-coverage.sh"])
    check("chay MOI script run-*-test.sh (%d) va bao OK cho tung cai" % n_tests, r.stdout.count("OK   run-") == n_tests and "LOI" not in r.stdout, r.stdout)
    check("shim kotlinc: class cua moi lan bien dich duoc sao ra thu muc chung", os.path.exists(os.path.join(out, "classes", "com", "wppocket", "server", "Fake.class")))
    calls = open(log).read() if os.path.exists(log) else ""
    check("shim kotlin: moi lan chay deu gan agent JaCoCo, ghi vao jacoco.exec, chi do com.wppocket.*", calls.count("-javaagent:/tmp/agent.jar=destfile=") == n_tests and "jacoco.exec,append=true,includes=com.wppocket.*" in calls, calls[:300])
    # test loi duoc dem, khong bi nuot
    script("kotlinc", "exit 1\n")
    r2 = subprocess.run(["sh", sc], capture_output=True, text=True, env=env)
    check("DOI CHUNG AM: kotlinc loi thi script bao LOI cho tung test (khong nuot loi)", r2.stdout.count("LOI  run-") == n_tests, r2.stdout)
print("\nTONG KET: pass=%d fail=%d" % (pass_n, fail_n)); sys.exit(1 if fail_n else 0)
