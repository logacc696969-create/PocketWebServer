#!/bin/sh
# Chay kiem thu JVM cho MonitorLogic.kt (can kotlinc + java). Khong can Android SDK.
# MonitorLogic.kt dung AlertThresholds.kt (1bq-B: nguong canh bao chinh duoc) nen PHAI bien dich cung - thieu thi loi "unresolved reference AlertThresholds".
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$(mktemp -d)"
SRC="$HERE/../../app/src/main/java/com/wppocket/server"
kotlinc -nowarn "$SRC/MonitorLogic.kt" "$SRC/AlertThresholds.kt" "$HERE/MonitorLogicTest.kt" -d "$OUT" \
  && kotlin -cp "$OUT" MonitorLogicTestKt
rc=$?; rm -rf "$OUT"; exit $rc
