#!/usr/bin/env bash
# Tải binary cloudflared chính thức (viết bằng Go, build tĩnh - KHÔNG dùng
# kho Termux, KHÔNG có vấn đề thiếu .so như php/node/python) để chạy
# Cloudflare Quick Tunnel: cho URL https công khai ngay lập tức, không cần
# tài khoản, không cần mở port router (kiến trúc outbound-only).
#
# Usage: scripts/prepare_cloudflared.sh <goarch: arm64|arm> <out_dir>
set -euo pipefail

GOARCH="${1:-arm64}"   # arm64 (may 64-bit, da so may hien nay) | arm (may cu 32-bit)
OUT_DIR="${2:-./cloudflared-out}"
mkdir -p "$OUT_DIR"

URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${GOARCH}"
echo "== Tai cloudflared ($GOARCH) tu $URL =="
curl -fsSL -o "$OUT_DIR/libcfd.so" "$URL"
chmod 755 "$OUT_DIR/libcfd.so"

echo "Xong: $OUT_DIR/libcfd.so"
