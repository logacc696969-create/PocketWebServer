#!/usr/bin/env bash
# Tải binary cloudflared chính thức (viết bằng Go, build tĩnh - KHÔNG dùng
# kho Termux, KHÔNG có vấn đề thiếu .so như php/node/python) để chạy
# Cloudflare Quick Tunnel: cho URL https công khai ngay lập tức, không cần
# tài khoản, không cần mở port router (kiến trúc outbound-only).
#
# Usage: scripts/prepare_cloudflared.sh <goarch: arm64|arm> <out_dir>
#
# XÁC MINH TOÀN VẸN (HANDOFF.md mục 1bc, đề xuất Z3): trước đây tải thẳng `releases/latest/download/...` và đóng gói
# vào APK mà KHÔNG kiểm gì. Nay:
#   1. Xác định tag hiện hành qua chuyển hướng của `releases/latest` (KHÔNG dùng API: giới hạn 60 yêu cầu/giờ/IP,
#      runner GitHub dùng chung IP nên hay bị 403) rồi tải đúng URL CỦA TAG đó (binary và hash cùng một bản phát hành).
#   2. Ghi chú phát hành của cloudflared công bố SHA-256 từng binary ("cloudflared-linux-arm64: <64 hex>") - đối chiếu.
#      Đã kiểm trên bản thật 2026.10.0: hash tải về khớp đúng dòng này; binary arm64 là ELF tĩnh (statically linked).
#   3. Kiểm magic ELF (chặn việc lưu nhầm trang lỗi HTML thành "binary").
# Sai hash -> DỪNG build. Không đọc được hash -> cảnh báo UNVERIFIED (VERIFY_STRICT=1 thì dừng).
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/verify_download.sh
source "$HERE/lib/verify_download.sh"

GOARCH="${1:-arm64}"   # arm64 (may 64-bit, da so may hien nay) | arm (may cu 32-bit)
OUT_DIR="${2:-./cloudflared-out}"
mkdir -p "$OUT_DIR"

REPO_URL="${CFD_REPO_URL:-https://github.com/cloudflare/cloudflared}"   # ghi de duoc de test (scripts/tests/supply-chain-test.py)
TAG="${CFD_TAG:-}"
if [[ -z "$TAG" ]]; then
  loc="$(curl -sSI --max-time 30 --retry 2 "$REPO_URL/releases/latest" 2>/dev/null | tr -d '\r' | awk 'tolower($1)=="location:"{print $2}' | tail -n1 || true)"
  TAG="${loc##*/}"
fi

if [[ -n "$TAG" ]]; then
  URL="$REPO_URL/releases/download/$TAG/cloudflared-linux-${GOARCH}"
else
  echo "  !!! CANH BAO: khong xac dinh duoc tag moi nhat - dung /releases/latest/download (khong the doi chieu hash cung ban)" >&2
  URL="$REPO_URL/releases/latest/download/cloudflared-linux-${GOARCH}"
fi
echo "== Tai cloudflared ($GOARCH, tag ${TAG:-?}) tu $URL =="
curl -fsSL --retry 3 -o "$OUT_DIR/libcfd.so.part" "$URL"

EXPECTED=""
NOTES_URL=""
if [[ -n "$TAG" ]]; then
  NOTES_URL="$REPO_URL/releases/tag/$TAG"
  # "arm:" khong khop nham "arm64:" vi dau ':' nam ngay sau ten kien truc.
  EXPECTED="$(curl -fsSL --max-time 60 --retry 2 "$NOTES_URL" 2>/dev/null \
    | grep -oE "cloudflared-linux-${GOARCH}:[[:space:]]*[0-9a-fA-F]{64}" | head -n1 | verify_extract_hash sha256 || true)"
fi

verify_elf "$OUT_DIR/libcfd.so.part" || { echo "!!! LOI: file tai ve khong phai ELF (co the la trang loi) - DUNG build" >&2; rm -f "$OUT_DIR/libcfd.so.part"; exit 1; }
verify_file "cloudflared-linux-${GOARCH}@${TAG:-latest}" "$OUT_DIR/libcfd.so.part" sha256 "$EXPECTED" "${NOTES_URL:-khong co}"
mv -f "$OUT_DIR/libcfd.so.part" "$OUT_DIR/libcfd.so"
chmod 755 "$OUT_DIR/libcfd.so"

echo "Xong: $OUT_DIR/libcfd.so"
