#!/usr/bin/env bash
# Kich ban HON LOAN tren DIEN THOAI THAT qua adb (AA2; HANDOFF.md muc 1bq-E) - phan KHONG chay duoc trong CI/moi truong khong co thiet bi:
# giet app, giet daemon, day bo nho, mat mang. Moi kich ban: GAY SU CO -> DOI -> KIEM TRA phuc hoi bang API trang thai chi doc (scripts/tools/wppocket_cli.py).
#
#   scripts/chaos/chaos-device.sh <kich_ban> --yes [--serial SO] [--pkg com.wppocket.server] [--host IP_DIEN_THOAI --port 8080]
#                                [--wait 300] [--leave-mb 300] [--net-off 45]
#   kich ban: kill-app | kill-daemons | fill-disk | network-off | status
#
# YEU CAU: adb; ban APK DEBUG (run-as chi dung duoc voi ban debuggable); API trang thai da bat trong app + WPPOCKET_TOKEN trong moi truong (hoac cau hinh
# `wppocket config set`) neu muon tu dong KIEM TRA phuc hoi (--host). Khong co --host thi chi gay su co + in huong dan kiem tay.
# AN TOAN: bat buoc --yes cho moi kich ban pha; fill-disk CHI ghi vao thu muc cua app va LUON de lai it nhat --leave-mb MB trong (dung chung bo nho voi ung
# dung khac!), tep luon bi xoa khi thoat (trap) va viec xoa duoc kiem tra; network-off LUON bat lai mang khi thoat (trap), ke ca khi bi Ctrl-C.
# Ma thoat: 0 phuc hoi dung | 1 KHONG phuc hoi trong thoi gian cho | 2 loi moi truong (thieu adb/run-as/thiet bi) | 64 sai cu phap.
set -u

PKG="com.wppocket.server"; SERIAL=""; HOST=""; PORT="8080"; WAIT=300; LEAVE_MB=300; NET_OFF=45; YES=0
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLI="$HERE/../tools/wppocket_cli.py"
SCENARIO="${1:-}"; [ $# -gt 0 ] && shift
while [ $# -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --serial) SERIAL="${2:-}"; shift ;;
    --pkg) PKG="${2:-}"; shift ;;
    --host) HOST="${2:-}"; shift ;;
    --port) PORT="${2:-}"; shift ;;
    --wait) WAIT="${2:-}"; shift ;;
    --leave-mb) LEAVE_MB="${2:-}"; shift ;;
    --net-off) NET_OFF="${2:-}"; shift ;;
    *) echo "tham so la: $1" >&2; exit 64 ;;
  esac
  shift
done
case "$SCENARIO" in kill-app|kill-daemons|fill-disk|network-off|status) ;; *) echo "kich ban: kill-app | kill-daemons | fill-disk | network-off | status" >&2; exit 64 ;; esac
for v in "$WAIT" "$LEAVE_MB" "$NET_OFF" "$PORT"; do case "$v" in ''|*[!0-9]*) echo "so khong hop le: $v" >&2; exit 64 ;; esac; done
case "$PKG" in *[!A-Za-z0-9._]*|'') echo "ten goi khong hop le" >&2; exit 64 ;; esac
[ "$SCENARIO" != "status" ] && [ "$YES" != 1 ] && { echo "Kich ban '$SCENARIO' se GAY SU CO that tren dien thoai - them --yes de xac nhan." >&2; exit 64; }

command -v adb >/dev/null 2>&1 || { echo "Khong co adb trong PATH" >&2; exit 2; }
ADB=(adb); [ -n "$SERIAL" ] && ADB=(adb -s "$SERIAL")
"${ADB[@]}" get-state >/dev/null 2>&1 || { echo "Khong thay thiet bi adb (dung --serial neu nhieu thiet bi)" >&2; exit 2; }
sh_app() { "${ADB[@]}" shell run-as "$PKG" "$@"; }
log() { echo "[chaos $(date +%H:%M:%S)] $*"; }

# KIEM TRA phuc hoi bang API chi doc: doi toi da $WAIT giay cho toi khi status --check = OK (0).
verify() {
  if [ -z "$HOST" ]; then log "Khong co --host: khong tu kiem tra duoc. Kiem tay: mo app, xem trang thai server + nhat ky."; return 0; fi
  local end=$(( $(date +%s) + WAIT )) rc=3 step=10
  [ "$WAIT" -lt 10 ] && step=1
  while [ "$(date +%s)" -lt "$end" ]; do
    python3 "$CLI" status --check --host "$HOST" --port "$PORT" --max-staleness 20m >/tmp/chaos-verify.$$ 2>&1; rc=$?
    [ "$rc" = 0 ] && { log "PHUC HOI: $(cat /tmp/chaos-verify.$$)"; rm -f /tmp/chaos-verify.$$; return 0; }
    sleep "$step"
  done
  log "KHONG phuc hoi sau ${WAIT}s (ma cuoi $rc): $(cat /tmp/chaos-verify.$$ 2>/dev/null)"; rm -f /tmp/chaos-verify.$$; return 1
}

case "$SCENARIO" in
  status) verify; exit $? ;;
  kill-app)
    log "force-stop $PKG (nhu vuot khoi danh sach gan day / bi he thong giet)"
    "${ADB[@]}" shell am force-stop "$PKG" || exit 2
    log "mo lai app"; "${ADB[@]}" shell monkey -p "$PKG" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1
    verify; exit $? ;;
  kill-daemons)
    sh_app true >/dev/null 2>&1 || { echo "run-as that bai: can ban APK DEBUG (debuggable)" >&2; exit 2; }
    log "SIGKILL moi tien trinh nhi phan cua app (libnginx/libphp/libmariadbd/...), giu nguyen tien trinh app"
    sh_app sh -c 'for d in /proc/[0-9]*; do c=$(tr "\0" " " < "$d/cmdline" 2>/dev/null); case "$c" in *lib*.so*) kill -9 "${d#/proc/}" 2>/dev/null ;; esac; done'
    verify; exit $? ;;
  fill-disk)
    sh_app true >/dev/null 2>&1 || { echo "run-as that bai: can ban APK DEBUG (debuggable)" >&2; exit 2; }
    FREE_MB="$("${ADB[@]}" shell df -m /data 2>/dev/null | awk 'NR>1 {print $4; exit}' | tr -d '\r')"
    case "$FREE_MB" in ''|*[!0-9]*) echo "Khong doc duoc dung luong trong (df /data)" >&2; exit 2 ;; esac
    COUNT=$(( FREE_MB - LEAVE_MB ))
    [ "$COUNT" -gt 0 ] || { echo "Chi con ${FREE_MB} MB trong, it hon --leave-mb ${LEAVE_MB}: khong day them" >&2; exit 2; }
    cleanup_fill() { sh_app rm -f files/chaos-fill.bin >/dev/null 2>&1; if sh_app test -e files/chaos-fill.bin >/dev/null 2>&1; then echo "CANH BAO: chua xoa duoc files/chaos-fill.bin - xoa tay!" >&2; fi; }
    trap 'exit 130' INT TERM   # de trap EXIT chay ca khi bi Ctrl-C/TERM (bash khong chay EXIT trap khi bi tin hieu giet truc tiep)
    trap cleanup_fill EXIT
    log "ghi ${COUNT} MB vao files/chaos-fill.bin (con lai ~${LEAVE_MB} MB trong)"
    sh_app dd if=/dev/zero of=files/chaos-fill.bin bs=1048576 count="$COUNT" 2>&1 | tail -1
    log "cho app thich ung (canh bao bo nho / log / backup) ..."; sleep 30
    cleanup_fill; trap - EXIT
    verify; exit $? ;;
  network-off)
    restore_net() { "${ADB[@]}" shell svc wifi enable >/dev/null 2>&1; "${ADB[@]}" shell svc data enable >/dev/null 2>&1; log "da bat lai wifi + du lieu di dong"; }
    trap 'exit 130' INT TERM
    trap restore_net EXIT
    log "tat wifi + du lieu di dong trong ${NET_OFF}s (tunnel rot; backup/upload/Telegram dang chay se that bai)"
    "${ADB[@]}" shell svc wifi disable; "${ADB[@]}" shell svc data disable
    sleep "$NET_OFF"
    restore_net; trap - EXIT
    verify; exit $? ;;
esac
