# Chạy ứng dụng Python (Flask, Django, Starlette…) bằng máy chủ WSGI/ASGI đi kèm

Runtime Python trước đây chỉ có hai cách: chạy thẳng một file (`"entry": "app.py"`, app tự bind cổng) hoặc `http.server` cho file tĩnh. Không có gunicorn/waitress (cần cài thêm, nhiều gói không chạy được trên Android). Nay có **máy chủ WSGI đi kèm** `scripts/runtimes/wpp_wsgi.py`, **chỉ dùng thư viện chuẩn của Python**, nên không thêm phụ thuộc nào.

## Dùng thế nào

Trong `site.config.json` (hoặc `python3 scripts/tools/apply_preset.py python-wsgi`):

```json
{
  "runtime": "python",
  "wsgi": "app:app",
  "entry": "",
  "front_proxy": true,
  "install_deps": true,
  "site_source": { "type": "local", "path": "site" }
}
```

| Khung | Giá trị `wsgi` |
|---|---|
| Flask (`app = Flask(__name__)` trong `app.py`) | `app:app` |
| Django (dự án `mysite`) | `mysite.wsgi:application` |
| Nhà máy ứng dụng (gọi hàm không tham số) | `app:create_app()` |
| Đối tượng lồng nhau | `pkg.mod:obj.app` |

- `wsgi` và `entry` **loại trừ nhau** (khai báo cả hai là lỗi). Chỉ dùng với `runtime: python`.
- Thư viện của ứng dụng (Flask, Django…) khai trong `requirements.txt`; CI cài lúc build (chỉ gói dạng wheel, không chạy script của gói) → `.pylibs`. Gói cần mã native (`.so`) không chạy được trên Android.
- **Nên bật `front_proxy: true`**: nginx đứng trước giữ body lớn, nén gzip, thêm header bảo mật, trả `/healthz`, và gửi `X-Forwarded-For`/`X-Forwarded-Proto`; máy chủ WSGI khi đó chỉ nghe `127.0.0.1` (cổng nội bộ) và **tin** hai header này. Không bật `front_proxy` thì máy chủ WSGI nghe thẳng `0.0.0.0:PORT` và **không** tin header nào (chống giả IP).

## Máy chủ làm gì (thiết kế cho điện thoại)

- **Đa luồng có giới hạn** (mặc định 16): quá tải trả `503` ngay kèm `Retry-After` thay vì tạo luồng vô hạn làm cạn RAM.
- **Thời hạn mỗi kết nối** 30 giây: khách chậm hoặc treo không giữ luồng mãi.
- **Giới hạn body** 64 MB → `413` *trước khi* gọi ứng dụng; body `chunked` → `411` (nginx luôn gửi `Content-Length`). `wsgi.input` bị chặn theo `Content-Length` nên `read()` không tham số không bao giờ treo.
- **Dừng sạch**: `SIGTERM`/`SIGINT` → ngừng nhận kết nối, thoát mã 0. Từ chối sớm (413/411/400) có "lingering close" để khách đọc được phản hồi thay vì nhận RST.
- Lỗi của ứng dụng → `500` và **traceback ra stderr** (xem trong nhật ký app); máy chủ không sập. Khách ngắt giữa chừng không sinh traceback.
- Chỉnh bằng tham số của `wpp_wsgi.py` (`--threads`, `--timeout`, `--max-body`, `--access-log`) nếu chạy tay; mặc định phù hợp với đa số.

## Ứng dụng ASGI (Starlette, FastAPI…)

Thay `wsgi` bằng `asgi` (hoặc `python3 scripts/tools/apply_preset.py python-asgi`):

```json
{ "runtime": "python", "asgi": "app:app", "entry": "", "wsgi": "", "front_proxy": true }
```

Cùng máy chủ, thêm cầu nối ASGI → WSGI (`AsgiBridge` trong `wpp_wsgi.py`, chỉ thư viện chuẩn; thay uvicorn). `wsgi`, `asgi`, `entry` **loại trừ nhau**.

- **Có:** HTTP (đủ method, header, body, `scope` ASGI 3.0 gồm `client`, `server`, `scheme`, `state`), **lifespan** (`startup` chạy **trước** khi nhận khách; `startup.failed` → không mở cổng, thoát mã khác 0 như uvicorn; app không hỗ trợ lifespan thì chạy bình thường; `shutdown` chạy khi `SIGTERM`), nhiều yêu cầu chạy **đồng thời** trên một vòng lặp asyncio, tin `X-Forwarded-*` như bên WSGI.
- **Không có — nói thẳng:** **WebSocket**, **streaming/SSE thật** (phản hồi được **gom đủ rồi mới gửi**; ứng dụng không kết thúc trong `--asgi-timeout` giây — mặc định 60 — thì trả `504`), HTTP/2.
- **Cảnh báo về FastAPI:** FastAPI bản mới cần `pydantic-core` (mã native, biên dịch bằng Rust) — **gói loại này không chạy được trên Android** (chỉ cài được gói thuần Python, xem mục trên). **Starlette** thuần Python nên là lựa chọn an toàn; FastAPI cũ dùng pydantic 1.x thuần Python **có thể** chạy nhưng **chưa kiểm**. Chưa thử Starlette/FastAPI thật (môi trường kiểm không cài sẵn; `asgi-server-test.py` dùng ứng dụng ASGI viết tay đúng đặc tả và sẽ tự chạy thêm một ứng dụng Starlette nếu có).

## Không hỗ trợ (nói thẳng)

- **WebSocket / Server-Sent Events**: máy chủ không giữ kết nối dài (mỗi yêu cầu một kết nối, đóng sau khi trả lời) — cả WSGI lẫn ASGI. Cần WebSocket thì dùng runtime Node (nginx phía trước có chuyển tiếp header `Upgrade`).
- **HTTP keep-alive** giữa nginx và ứng dụng: không có (nginx tự xử lý với khách).
- Chưa thử với Flask/Django/Starlette thật *trên điện thoại*; trên máy phát triển đã kiểm bằng HTTP thật (xem `scripts/tests/wsgi-server-test.py` và `scripts/tests/asgi-server-test.py`).
