# Ghi chú pháp lý tham khảo: dữ liệu cá nhân (Việt Nam) và mật mã/xuất khẩu

> **Đây là bản tổng hợp thông tin để chủ dự án đem hỏi luật sư, KHÔNG phải tư vấn pháp lý** và không kết luận thay luật sư. Dữ kiện bên ngoài dưới đây được tra cứu ngày **27/10/2026** từ các bài của hãng luật/cổng văn bản pháp luật (nguồn ghi ở cuối mỗi mục); văn bản có thể đã đổi — hãy đối chiếu bản gốc. Phần "app thực sự làm gì" được đối chiếu với mã nguồn.

## A. Bảo vệ dữ liệu cá nhân (PDF 2, mục Y3)

### A1. Khung pháp lý hiện hành — PDF nhắc đã **cũ**

PDF DeepSeek nêu **Nghị định 13/2023/NĐ-CP**. Theo các nguồn tra cứu:

- **Luật Bảo vệ dữ liệu cá nhân số 91/2025/QH15** (Quốc hội thông qua 26/6/2025) **có hiệu lực từ 01/01/2026**.
- **Nghị định 356/2025/NĐ-CP** quy định chi tiết Luật, **có hiệu lực từ 01/01/2026 và thay thế Nghị định 13/2023/NĐ-CP**.

Vì vậy mọi đối chiếu phải theo Luật 91/2025/QH15 + Nghị định 356/2025/NĐ-CP, không theo Nghị định 13/2023. Các nguồn còn nói Nghị định 356 điều chỉnh cách phân loại dữ liệu cá nhân (mở rộng dữ liệu cơ bản/nhạy cảm), **siết yêu cầu về sự đồng ý** của chủ thể dữ liệu, quy định thời hạn thực hiện quyền của chủ thể, nhân sự/bộ phận bảo vệ dữ liệu, có cơ chế áp dụng riêng cho doanh nghiệp nhỏ/khởi nghiệp/hộ kinh doanh, và **thông báo trong 72 giờ** khi lộ/mất dữ liệu nhạy cảm tới cơ quan chuyên trách và chủ thể dữ liệu. *Chi tiết từng điều khoản, điều kiện áp dụng cho cá nhân tự phát hành ứng dụng: chưa đọc nguyên văn — việc cho luật sư.*

Nguồn: luatvietnam.vn (Nghị định 356/2025/NĐ-CP); lsvn.vn ("Một số thay đổi… từ 01/01/2026", 04/01/2026); PwC Việt Nam (28/01/2026); EY Việt Nam legal alert (03/2026); KPMG (06/2025).

### A2. App này xử lý dữ liệu cá nhân nào (đối chiếu `PRIVACY.md` và mã)

| Dữ liệu | Ở đâu | Ai là bên kiểm soát/xử lý? (câu hỏi cho luật sư) |
|---|---|---|
| Dữ liệu của **khách truy cập website** (IP trong nhật ký nginx, bình luận, đơn hàng…) | Trên điện thoại của người vận hành; qua Cloudflare | **Người vận hành website** (không phải tác giả app) — app không gửi gì về tác giả |
| Dữ liệu của **chính người dùng app** (token Telegram, mật khẩu quản trị, địa chỉ IP đăng nhập) | Chỉ trong bộ nhớ riêng của app; token API mã hoá bằng Android Keystore | Người dùng tự giữ; **tác giả không thu thập** |
| **Telemetry/báo cáo sự cố/tài khoản** | **Không có** (không SDK phân tích, `allowBackup=false`) | — |
| Backup chứa dữ liệu trên | Trên máy; gửi Telegram/webhook **chỉ khi người dùng cấu hình** | Người dùng; có tuỳ chọn mã hoá AES-256-GCM |

Hệ quả cần luật sư xác nhận, **không tự kết luận**: (1) nếu tác giả không nhận bất kỳ dữ liệu cá nhân nào thì có là "bên kiểm soát/xử lý" theo Luật 91/2025 hay không; (2) trong **giai đoạn thử nghiệm** nếu người thử gửi nhật ký/ảnh chụp màn hình cho tác giả (tự nguyện) thì tác giả *có* nhận dữ liệu — xem `docs/BETA_PROGRAM.md` để giảm thiểu (hướng dẫn che IP/token, chỉ gửi đoạn cần thiết); (3) nghĩa vụ của **người vận hành website** (chính sách riêng tư, căn cứ xử lý, thông báo vi phạm 72 giờ nếu dữ liệu nhạy cảm) — app chỉ nhắc ở `PRIVACY.md` mục 5, chưa có công cụ hỗ trợ.

### A3. Việc kỹ thuật có thể làm để giúp người vận hành (chưa làm, không bắt buộc)

Nhật ký truy cập tự xoá theo kích thước (đã có); công cụ xoá/xuất dữ liệu theo IP; mẫu chính sách riêng tư cho website (mục Q1 của PDF, chưa làm).

## B. Mật mã dân sự và xuất khẩu (PDF 2, mục Y7)

### B1. App dùng mật mã ở đâu (đối chiếu mã)

- **AES-256-GCM** (`SecretCodec.kt`, `Cipher.getInstance("AES/GCM/NoPadding")`) và khoá dẫn xuất **PBKDF2WithHmacSHA256** (`BackupManager.kt`) để mã hoá **backup** tuỳ chọn; khoá lưu bằng **Android Keystore** (`SecretStore.kt`).
- TLS: do hệ điều hành và `cloudflared` (Apache-2.0) / PHP (CA bundle) cung cấp, không tự cài đặt thuật toán TLS.
- Không có mật mã tự chế; dùng thư viện chuẩn của Android/Java.

### B2. Hoa Kỳ — EAR (xuất khẩu phần mềm mật mã)

Nếu phân phối ra ngoài Việt Nam, mã mật mã *công khai* (mã nguồn tự do) thường thuộc diện nhẹ hơn, nhưng **các nguồn tra cứu mâu thuẫn nhau về thủ tục hiện hành**:

- Trang của BIS (bis.gov, "Encryption items not subject to the EAR") nêu: mã nguồn mật mã *công khai* **không còn chịu EAR sau khi gửi email thông báo** theo §742.15(b); mã đối tượng tương ứng cũng vậy.
- Bài của Jones Day (04/2021) về quy tắc cuối cùng ngày 29/3/2021 nêu rằng quy tắc **bỏ yêu cầu gửi email thông báo** này.

Không biết nguồn nào phản ánh đúng văn bản hiện hành (có thể do ngày đăng khác nhau). **Việc cho luật sư/đối chiếu 15 CFR §742.15, §734.3(b)(3), §740.17 tại eCFR ở thời điểm phát hành.** Lưu ý thêm (BIS): một sản phẩm không tự động thành "công khai" chỉ vì có gọi/tích hợp mã nguồn mở công khai. Đây là lý do việc **chọn giấy phép** (mã nguồn mở hay đóng) ảnh hưởng tới phân loại — xem `docs/LICENSE_OPTIONS.md`.

Nguồn: bis.gov (Encryption items not subject to the EAR); Jones Day (2021); Gibson Dunn (2011, lịch sử); govinfo (Federal Register 76 FR 1061).

### B3. Việt Nam — mật mã dân sự (điểm **mới** hơn PDF)

Theo các nguồn tra cứu, hoạt động mật mã dân sự nay được quy định chi tiết bởi **Nghị định 341/2026/NĐ-CP** (hướng dẫn **Luật An ninh mạng 2025**; một nguồn ghi hiệu lực **từ 01/9/2026**), kế thừa Nghị định 211/2025/NĐ-CP (hiệu lực 09/9/2025, hướng dẫn Luật An toàn thông tin mạng). Nội dung đáng chú ý:

- **Doanh nghiệp** kinh doanh sản phẩm/dịch vụ mật mã dân sự **thuộc Danh mục (Phụ lục I)** phải có Giấy phép kinh doanh (thời hạn 10 năm); xuất/nhập khẩu sản phẩm **thuộc Danh mục (Phụ lục II)** cần giấy phép của Ban Cơ yếu Chính phủ (thời hạn 3 năm); sản phẩm lưỡng dụng (mật mã + an ninh mạng) do Bộ Công an cấp phép riêng.
- Một nguồn nhấn mạnh: **không phải mọi doanh nghiệp kinh doanh mật mã dân sự đều phải xin giấy phép** — phụ thuộc Danh mục.
- Kinh doanh không phép bị phạt hành chính (một nguồn ghi mức đến 180 triệu đồng theo Nghị định 211/2025).

**Câu hỏi mở (chưa trả lời được từ tài liệu tra cứu):** ứng dụng như thế này — mật mã chỉ là tính năng phụ (mã hoá backup), không phải sản phẩm bảo mật — **có nằm trong Danh mục Phụ lục I/II không**, và việc **phát hành miễn phí** (không "kinh doanh") thay đổi gì? Đây chính xác là việc phải hỏi luật sư; **không** nên tự suy ra "không cần".

Nguồn: lsvn.vn / thuvienphapluat.vn (Nghị định 341/2026/NĐ-CP); luatvietnam.vn; vneconomy.vn (Nghị định 211/2025/NĐ-CP); dhtaxlaw.com.vn.

## C. Danh sách đem đi hỏi luật sư

1. Luật 91/2025/QH15 + Nghị định 356/2025/NĐ-CP: tác giả có là bên kiểm soát/xử lý dữ liệu không khi không thu thập dữ liệu nhưng nhận nhật ký tự nguyện từ người thử?
2. Người vận hành website là cá nhân: các nghĩa vụ nào áp dụng, có ngoại lệ cho cá nhân/hộ kinh doanh/doanh nghiệp nhỏ?
3. Nghị định 341/2026/NĐ-CP, Phụ lục I và II: ứng dụng có mã hoá backup AES-256-GCM thuộc Danh mục nào, nếu có?
4. Phát hành miễn phí qua kênh nào thì coi là "kinh doanh" theo luật mật mã dân sự? Khi sau này tính phí có đổi không?
5. EAR: thủ tục thông báo hiện hành khi mã nguồn công khai; ảnh hưởng của lựa chọn giấy phép (mã nguồn mở hay đóng).
6. Điều khoản sử dụng/giấy phép dùng thử (`TERMS.md`) có đủ cho giai đoạn thử nghiệm miễn phí và cho việc tính phí sau này không (xem `docs/LICENSE_OPTIONS.md`).
