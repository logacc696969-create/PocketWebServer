# Ngưỡng và quy tắc cảnh báo

Mở app → **Ngưỡng và quy tắc cảnh báo…**. Cảnh báo gửi qua **Telegram** (cần cấu hình Telegram trước). App kiểm tra khoảng **15 phút một lần**, nên mọi thời gian trong tài liệu này có độ phân giải thực tế là 15 phút.

## 1. Bốn ngưỡng có sẵn (chỉnh được)

| Ngưỡng | Mặc định | Khoảng cho phép | Khi vượt |
|---|---|---|---|
| Bộ nhớ đã dùng | 85 | 50–99 | Tự dọn log lớn, báo Telegram tối đa 1 lần/24 giờ |
| Pin cạn (và không sạc) | 5 | 1–30 | Báo "pin sắp hết, máy có thể tắt đột ngột" |
| Pin ấm (°C) | 40 | 30–55 | Báo nên làm mát |
| Pin quá nóng (°C) | 45 | 35–65 | App hoãn việc nặng và backup định kỳ (tối đa 3 chu kỳ liên tiếp), báo Telegram |

Quy tắc an toàn: giá trị luôn bị kẹp vào khoảng cho phép (không ai đặt được "cảnh báo khi bộ nhớ đầy 1%" gây spam), và ngưỡng quá nóng luôn lớn hơn ngưỡng ấm. Nút **Mặc định** đặt lại bốn ô về giá trị trên. Không lưu nếu có ô nhập sai; lỗi hiện ngay tại ô.

## 2. Quy tắc tự định nghĩa

Mỗi dòng một quy tắc:

```
ten_quy_tac: chi_so toan_tu gia_tri [for N(m|h|d)] [cooldown N(m|h|d)]
```

Ví dụ:

```
# RAM quá cao liên tục 15 phút
high_ram: ram_percent > 90 for 15m

# Bộ nhớ gần đầy, chỉ báo mỗi ngày một lần
disk_full: disk_percent >= 90 cooldown 24h

# Pin nóng kéo dài 1 giờ
hot: battery_temp_c >= 43 for 1h cooldown 2h
```

- **Tên**: chữ thường a–z, số, dấu gạch dưới, tối đa 32 ký tự, không trùng nhau.
- **Toán tử**: `>`  `>=`  `<`  `<=`.
- **Giá trị**: số thập phân dùng dấu chấm (`90`, `47.5`, `-5`). Không dùng `%`, dấu phẩy hay ký hiệu khoa học (`1e3`).
- **for**: điều kiện phải đúng **liên tục** bấy lâu mới báo (0 đến 24h; mặc định 0 = báo ngay lần kiểm tra đầu tiên điều kiện đúng).
- **cooldown**: khoảng cách tối thiểu giữa hai lần báo (15m đến 7d; mặc định 60m).
- Dòng trống và dòng bắt đầu bằng `#` được bỏ qua; có thể ghi chú cuối dòng sau `#`.
- Tối đa **20** quy tắc, tối đa 4000 ký tự.

### Chỉ số

| Chỉ số | Ý nghĩa | Khoảng |
|---|---|---|
| `disk_percent` | % bộ nhớ trong đã dùng | 0–100 |
| `battery_percent` | % pin | 0–100 |
| `battery_temp_c` | Nhiệt độ pin (°C) | -20–100 |
| `ram_percent` | % RAM của cả máy đang dùng | 0–100 |
| `load_avg_1m` | Tải trung bình 1 phút (`/proc/loadavg`) | 0–64 |
| `data_month_mb` | Dữ liệu di động đã dùng trong tháng (MB) | 0–10000000 |

> `load_avg_1m`: một số bản Android không cho ứng dụng thường đọc `/proc/loadavg`. Khi không đọc được, chỉ số đó **không bao giờ gây cảnh báo** (không báo giả).

## 3. Hành vi (để khỏi bất ngờ)

- Chỉ số **không đọc được** (lỗi cảm biến, thiếu quyền) → không bao giờ báo, và bộ đếm "đúng liên tục" được đặt lại.
- Điều kiện hết đúng giữa chừng → bộ đếm `for` bắt đầu lại, nhưng thời điểm báo gần nhất được giữ nên giá trị dao động quanh ngưỡng không gây báo dồn dập.
- Chỉ ghi nhận "đã báo" khi Telegram **gửi thành công**. Telegram lỗi thì lần kiểm tra sau vẫn có cơ hội báo lại.
- Đồng hồ máy bị chỉnh lùi: bộ đếm bắt đầu lại và không bị chặn vô hạn.
- Xoá hoặc đổi tên một quy tắc thì trạng thái cũ của nó được dọn đi.
- Có dòng lỗi khi lưu → **không lưu gì cả** và báo lỗi cụ thể theo dòng (sai cú pháp, trùng tên, chỉ số lạ, toán tử lạ, số sai, ngoài khoảng, thời lượng sai, vượt giới hạn).
- Quy tắc **không** thay thế các cảnh báo có sẵn (site down, backup lỗi, đăng nhập sai…): chúng vẫn chạy như cũ.

## 4. Giới hạn hiện tại

- Chỉ gửi qua Telegram (chưa qua webhook).
- Chưa thử trên máy thật: phần Kotlin/XML mới chưa được biên dịch; logic thuần (cú pháp, đánh giá, ngưỡng) đã kiểm bằng bản Java sát nguyên bản trên JDK thật (`scripts/tests/alert-rules-test.py`).
