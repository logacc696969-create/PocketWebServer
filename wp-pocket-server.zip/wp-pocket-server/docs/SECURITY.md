# Bảo mật máy chủ trong thời đại tấn công bằng AI

Tài liệu này mô tả **các lớp bảo vệ có thật trong code** (vòng 31, `HANDOFF.md` mục 1br), cách dùng, cách tắt khi gặp sự cố, và — quan trọng không kém — **những gì chúng KHÔNG làm được**. Mọi dòng "đã có" đều có test đi kèm trong `scripts/tests/`.

> **Đọc trước:** không có lớp nào ở đây thay thế được việc **cập nhật WordPress/plugin ngay khi có bản vá** và việc **đặt Cloudflare (WAF, Bot Fight Mode) phía trước**. Đây là các lớp giảm bề mặt tấn công và tự chặn nguồn quét, chạy được trên một chiếc điện thoại không có người trực.

## 1. Vì sao cần: bối cảnh đe doạ

Các nguồn công khai gần đây (xem mục 9) cho thấy kẻ tấn công dùng AI để:

- **Khai thác lỗ hổng rất nhanh sau khi công bố** — có vụ ghi nhận khai thác sau khoảng 90 phút đến 5 giờ (lỗ hổng "wp2shell" của WordPress tháng 7/2026). Cửa sổ "vài ngày để vá" không còn.
- **Quét hàng loạt từ IP máy chủ đám mây**, lọc mục tiêu theo **phiên bản plugin** đọc từ `readme.txt`/`changelog` hoặc đuôi `?ver=`.
- **Dò mật khẩu phân tán**: hàng trăm IP, mỗi IP thử vài lần để lọt dưới ngưỡng "mỗi IP".
- **Cài cửa hậu**: tài khoản quản trị tạo ngầm, plugin giả mạo chứa web shell, file PHP giấu trong `uploads/`.
- **Crawler AI** chiếm 30–60% băng thông của nhiều site — tải thật với gói dữ liệu di động.

Điện thoại chạy server không có đội vận hành, nên các lớp dưới đây **tự động hoá việc chặn, phát hiện và cảnh báo**.

## 2. Tổng quan các lớp

| Lớp | Việc làm | Nằm ở đâu | Test |
|---|---|---|---|
| nginx cứng hoá | Ẩn phiên bản, cắt kết nối chậm (slowloris), từ chối phương thức lạ, trả 404 cho `readme/changelog/license`, chặn file rò rỉ, danh sách IP bị chặn (444), log bảo mật riêng | `nginx.conf.template` | `nginx-lint.py`, `nginx-deny-test.py`, `security-nginx-test.py` (38, chạy trên nginx 1.31.8 + php-fpm 8.3 thật) |
| PHP cứng hoá | `allow_url_include=0`, `enable_dl=0`, `zend.exception_ignore_args`, cookie phiên `HttpOnly`/`SameSite=Lax`/strict | `php.ini.template` | `php-tuning-test.py` |
| **Guard** (fail2ban thu gọn) | Đọc `nginx-security.log`, chấm điểm theo IP, tự chặn (1 giờ → 1 ngày → 7 ngày) | `security-guard.php` | `security-guard-test.py` (69) |
| **Scanner** | So khớp lõi WordPress với checksum chính thức, phát hiện PHP trong `uploads/`, web shell, thay đổi điểm bám trụ, cách ly file | `security-scan.php` | `security-scan-test.py` (102) |
| **Shield** (mu-plugin) | Chống dò tên tài khoản, chống dò mật khẩu phân tán, nhật ký sự kiện nhạy cảm, giảm dấu vân tay phiên bản | `wppocket-shield-*.php` | `shield-test.py` (89) |
| **Trung tâm bảo mật** | Trang `_admin/security.php`: xem/mở chặn IP, chạy quét, cách ly/khôi phục, bật tắt công tắc | `admin-security.php` | `security-center-test.py` (70), `admin-security-test.py` (77) |
| **Đăng nhập hai bước WordPress** (mu-plugin) | TOTP (RFC 6238) cho `wp-login.php`, mã khôi phục dùng một lần, tuỳ chọn từng người dùng | `wppocket-2fa-*.php` | `wp-2fa-test.py` (91, chạy trên WordPress 7.1.4 thật) |
| **Lỗ hổng đã biết** (tuỳ chọn) | Đối chiếu plugin/theme/lõi đang cài với cơ sở dữ liệu lỗ hổng công khai; **mặc định TẮT** vì gửi tên + phiên bản ra ngoài | `security-vuln.php` | `security-vuln-test.py` (47) |
| Cảnh báo Telegram | Ứng dụng đọc `security-events.log` và báo khi có sự kiện nghiêm trọng (giới hạn 10 phút/lần) | `Monitoring.kt`, `MonitorLogic.kt` | `MonitorLogicTest.kt` (129), `security-events-contract-test.py` (7) |
| Điểm sức khoẻ | Trang `_admin/health.php` có điểm tổng hợp, thêm dòng "Quét mã độc" và "IP khách thật" | `admin-health.php` | `health-test.py` (36) |
| Trang `_admin/` | Khoá đăng nhập nguyên tử, danh sách Host cho phép (chống DNS rebinding), cờ cookie, TOTP dùng một lần | `admin-auth.php`, `admin-totp-lib.php` | `admin-session-test.py`, `admin-security-test.py` |
| Fuzz | Gửi đầu vào ngẫu nhiên có hạt giống cố định vào mọi trang `_admin/`, có đối chứng âm | `admin-fuzz-test.py` (11) | — |

## 3. Guard: tự chặn IP

`start-lamp.sh` gọi `security-guard.php` định kỳ (chế độ Full). Guard đọc `lamp-run/nginx-security.log` (chỉ ghi 4xx và request tới `wp-login.php`/`xmlrpc.php`, nên ít ghi xuống flash), chấm điểm trong cửa sổ trượt **10 phút**; **≥ 10 điểm → chặn**.

| Hành vi | Điểm |
|---|---|
| Mẫu tấn công rõ (chuỗi chèn mã, file nhạy cảm `.env`/`.git`/`wp-config.php.bak`, công cụ lạ `phpmyadmin`…, tên web shell, User-Agent công cụ quét như `sqlmap`/`wpscan`) | 10 → chặn ngay |
| Đo phiên bản qua `readme`/`changelog` plugin | 5 |
| `xmlrpc.php` (đã bị chặn, vẫn thử) | 5 |
| POST `wp-login.php` thất bại | 2 (5 lần/10 phút → chặn) |
| `.php` không tồn tại (404) | 3 |
| 403/405/429 thường | 2 |
| 404 thường | 1 (0 với crawler tự nhận diện như Googlebot) |
| 4xx trong `/wp-admin/`, `/wp-json/`, `wp-cron` | 0,2 |

Mức chặn leo thang theo tái phạm trong 30 ngày: **1 giờ → 24 giờ → 7 ngày**. IP vừa đăng nhập WordPress thành công được giảm nhẹ điểm 24 giờ để không tự chặn chủ site.

Chặn bằng cách ghi `lamp-run/ban-list.conf` (một dòng `IP 1;`), nginx nạp lại qua tín hiệu HUP do `start-lamp.sh` gửi. IP bị chặn nhận `444` (đóng kết nối không trả nội dung, không tốn PHP/MariaDB) và **không còn ghi vào log chính**.

**Không bao giờ chặn:** IP riêng/loopback/link-local (cả IPv4 lẫn IPv6), và mọi IP trong `lamp-run/security-allow.txt` (Trung tâm bảo mật có mục "IP tin cậy (không bao giờ bị chặn)"). Giới hạn: tối đa 2000 IP bị chặn, theo dõi 5000 IP, đọc tối đa 2 MB log mỗi lần chạy.

**Điều kiện để chặn đúng IP khách thật:** nginx phải có module `realip` (để lấy IP thật từ Cloudflare). Nếu thiếu, mọi khách đều là `127.0.0.1` → guard **không chặn gì cả** (an toàn nhưng mất tác dụng), và `lamp-run/realip-missing` được tạo; Trung tâm bảo mật và điểm sức khoẻ hiển thị cảnh báo này.

## 4. Scanner: quét mã độc và theo dõi thay đổi

Supervisor tự quét lần đầu khoảng 1 phút sau khi khởi động, rồi **mỗi giờ**; hoặc bấm "Quét ngay" ở Trung tâm bảo mật (hoặc CLI `security-scan.php <docroot> <lamp-run> scan`). Kết quả ở `lamp-run/security-scan.json`.

Phát hiện (mỗi loại có mức nghiêm trọng):

- **`php-trong-uploads`**, `anh-chua-ma-php` (ảnh chứa mã PHP — "polyglot"), `htaccess-trong-uploads`: nơi người dùng được tải file lên không bao giờ nên có PHP chạy được.
- **`core-bi-sua`**, `core-file-la`, `core-thieu-file`: so với **checksum lõi WordPress chính thức** (`api.wordpress.org`, tải qua `fetch-core`, lưu `wp-core-checksums.json`). Khi chưa tải được (không mạng), kết quả ghi **`loi-doi-chua-xac-minh`** thay vì im lặng coi như sạch.
- **`php-la-o-goc-site`**: file PHP lạ ở thư mục gốc.
- **`diem-bam-tru-moi/doi/mat`**: so với "đường cơ sở" (`security-baseline.json`) của các file PHP kẻ tấn công hay dùng để cài cửa hậu: mọi `.php` ở **thư mục gốc**, các drop-in trực tiếp trong `wp-content/` (`db.php`, `advanced-cache.php`, `object-cache.php`…) và mọi file trong **`mu-plugins/`** (tự chạy mà không cần kích hoạt). Chỉ áp dụng cho site WordPress.
- **`plugin-moi` / `theme-moi`**: plugin/theme xuất hiện sau lần chấp nhận gần nhất (bắt plugin giả mạo).
- **`nghi-web-shell`**, **`ma-dang-ngo`**: chấm điểm nội dung (hàm thực thi + dữ liệu từ request + che giấu) và chữ ký phổ biến.

Thiết kế để **ít báo nhầm**: cập nhật WordPress/plugin chính thống được ghi nhận qua danh sách "đã quản lý" và làm mới đường cơ sở; đường cơ sở không được tạo khi site chưa cài xong hoặc lần quét bị cắt ngắn; có "chấp nhận" (`accept`) và "bỏ qua" (`ignore`) theo từng phát hiện.

**Cách ly (quarantine):** chỉ file nằm trong **kết quả quét gần nhất** mới cách ly được (chống bị lừa cách ly file tuỳ ý); file được chuyển vào `lamp-run/quarantine/` kèm `index.json`, **khôi phục được** từ Trung tâm bảo mật.

## 5. Shield: lớp bên trong WordPress (mu-plugin)

`wppocket-shield.php` (loader, nuốt mọi lỗi bằng `try/catch Throwable`) nạp `wppocket-shield/shield.php`. Tự cài vào site mới (`site_source.sh`) và **vào cả site cũ** (`start-lamp.sh`), trừ khi có `lamp-run/shield-no-install`.

1. **Chống dò tên tài khoản:** ẩn `/wp-json/wp/v2/users` với khách, chặn `?author=N`, bỏ "users" khỏi sitemap, thông báo đăng nhập sai chung chung.
2. **Chống dò mật khẩu phân tán** (đếm theo **tài khoản**, không theo IP): quá **20** lần sai/15 phút trên một tài khoản (bất kể IP) → tài khoản vào "chế độ phòng thủ" ~15 phút: **chỉ mạng (/24, hoặc /48 với IPv6) đã từng đăng nhập thành công trong 60 ngày** mới vào được. Một mạng sai ≥ 8 lần vào một tài khoản bị chặn riêng. Chủ site từ mạng quen không bị ảnh hưởng. Trạng thái ở `lamp-run/shield-login.json`; khoá mạng được băm HMAC, không lưu IP thô.
3. **Nhật ký sự kiện nhạy cảm** vào `lamp-run/security-events.log`: tài khoản quản trị **mới**, cấp quyền quản trị, đổi email quản trị, bật plugin, admin đăng nhập từ mạng lạ. (Vụ tháng 7/2026: hơn 100 tài khoản admin tạo ngầm.)
4. **Giảm dấu vân tay:** bỏ thẻ `generator`, băm `?ver=` của script/style, `DISALLOW_FILE_EDIT` (một admin bị chiếm không sửa thẳng mã PHP được), XML-RPC tắt, **mật khẩu ứng dụng tắt** (cửa hậu qua mặt được 2FA).

Shield **không** khoá IP, **không** xoá tài khoản/plugin, **không** đổi dữ liệu WordPress — chỉ ghi sự kiện và từ chối.

## 5b. Đăng nhập hai bước (TOTP) cho WordPress

`wppocket-2fa.php` (loader nuốt mọi lỗi bằng `try/catch Throwable`) nạp `wppocket-2fa/2fa.php`. Tự cài như Shield (site mới và site cũ), trừ khi có `lamp-run/twofa-no-install`. **Không ai bị ép dùng:** chỉ người dùng đã tự bật ở trang **Hồ sơ (Profile)** mới phải nhập mã; chưa ai bật thì đăng nhập y như cũ.

- **Mã:** TOTP chuẩn RFC 6238 (SHA-1, 6 chữ số, 30 giây, chấp nhận lệch ±1 bước) — dùng được với Google Authenticator, Authy, Aegis, 1Password… Mỗi mã chỉ dùng **một lần** (chống phát lại).
- **Bí mật được mã hoá** trong CSDL (libsodium `secretbox`; không có thì OpenSSL AES-256-GCM; thiếu cả hai thì **không cho bật**), khoá dẫn xuất từ `AUTH_KEY` + `SECURE_AUTH_KEY` của site. Có 8 mã khôi phục, lưu dạng băm HMAC, dùng một lần.
- **Thông báo lỗi thống nhất** cho sai tên/mật khẩu/mã (không lộ tài khoản nào có 2FA). Số lần sai vẫn được Shield đếm theo tài khoản và guard đếm theo IP (khoảng 80 lần đoán mã/giờ trong trường hợp xấu nhất — xác suất lọt cực thấp nhưng **không bằng 0**).
- **Không tự khoá chủ site:** nếu không giải mã được bí mật (đổi khoá, hỏng dữ liệu) thì **cho qua** thay vì khoá người dùng ra; có công tắc tắt khẩn cấp cho cả site (`twofa-off`, xem mục 6–7).

## 5c. Lỗ hổng đã biết của plugin/theme/lõi (tuỳ chọn, mặc định TẮT)

Kẻ tấn công dùng AI khai thác lỗ hổng trong vài giờ sau khi công bố, nên biết **plugin nào đang chạy bản có lỗ hổng** quan trọng hơn mọi lớp chặn. Bật công tắc `vuln-check-on` ở Trung tâm bảo mật: supervisor chạy `security-vuln.php` khoảng 2 phút sau khi khởi động rồi **mỗi giờ** (hoặc bấm "Kiểm ngay"), hỏi `www.wpvulnerability.net` (dịch vụ công khai, dữ liệu lấy từ nguồn mở) về từng plugin/theme và phiên bản WordPress.

- **Gửi ra ngoài:** *tên thư mục plugin/theme + phiên bản + phiên bản WordPress* — **không** gửi tên miền, nội dung site hay IP riêng của site (xem `PRIVACY.md`). Vì vậy tính năng **mặc định TẮT**; có thể đổi địa chỉ dịch vụ tương thích (chỉ `http(s)`).
- **Cách tính:** so khớp khoảng phiên bản bằng `version_compare` ở phía máy; dữ liệu từ ngoài được coi là **không đáng tin** (làm sạch, giới hạn kích thước/số lần gọi — tối đa 80 yêu cầu và 50 giây mỗi lần chạy; kết quả lưu đệm 12 giờ, lỗi mạng thử lại sau 1 giờ).
- **Kết quả:** thẻ "Lỗ hổng đã biết" ở Trung tâm bảo mật (mức nghiêm trọng, điểm CVSS, liên kết), dòng trong "tự kiểm tra", và cảnh báo Telegram (`LO HONG NGHIEM TRONG` là khẩn). Mạng lỗi thì giữ kết quả cũ.
- **Giới hạn:** không biết lỗ hổng của plugin trả phí/tự viết không có trên wordpress.org; cơ sở dữ liệu có thể chậm hơn thực tế; "không thấy lỗ hổng" **không có nghĩa là an toàn**.

## 6. Các công tắc (file cờ trong `lamp-run/`)

Đặt/xoá ở **Trung tâm bảo mật** (`_admin/security.php`, chỉ trong LAN, cần mật khẩu + TOTP nếu đã bật). Danh sách cờ trong whitelist: `block-ai-on`, `maintenance-mode`, `shield-off`, `shield-allow-user-api`, `shield-allow-file-edit`, `shield-allow-app-passwords`, `vuln-check-on`, `twofa-off`.

| Cờ | Tác dụng |
|---|---|
| `block-ai-on` | nginx trả 403 cho crawler AI thu thập/huấn luyện (GPTBot, ClaudeBot, CCBot…). **Mặc định tắt** vì ảnh hưởng cách site hiện trong công cụ tìm kiếm AI. Không chặn bot lấy trang theo yêu cầu người dùng. |
| `maintenance-mode` | chế độ bảo trì của nginx (có từ trước; nay bật/tắt được cả ở đây) |
| `shield-off` | tắt toàn bộ Shield (tắt khẩn cấp) |
| `shield-allow-user-api` | cho khách đọc REST users (site headless/ứng dụng) |
| `shield-allow-file-edit` | cho sửa file plugin/theme trong trang quản trị |
| `shield-allow-app-passwords` | cho mật khẩu ứng dụng |
| `vuln-check-on` | bật kiểm lỗ hổng đã biết (**gửi tên + phiên bản plugin/theme ra `wpvulnerability.net`**; mặc định tắt) |
| `twofa-off` | **tắt khẩn cấp** đăng nhập hai bước cho cả site (khi mất điện thoại mà chưa đặt lại được) — ai đã bật hai bước chỉ cần mật khẩu cho đến khi xoá cờ |
| `shield-no-install` (đặt tay) | không tự cài Shield vào site cũ |
| `twofa-no-install` (đặt tay) | không tự cài mu-plugin hai bước (chủ site tự quản lý hoặc đã gỡ) |

## 7. Phục hồi khi bị khoá nhầm

| Tình huống | Cách xử lý |
|---|---|
| Tự khoá IP của mình | `_admin/security.php` → nút "Huỷ chặn"; hoặc thêm IP vào "IP tin cậy"; hoặc xoá dòng trong `lamp-run/ban-list.conf` rồi tạo `lamp-run/ban-reload` |
| Tài khoản WordPress vào "phòng thủ" nhầm | Trung tâm bảo mật → nút "Gỡ phòng thủ"; hoặc xoá `lamp-run/shield-login.json` (chỉ mất bộ nhớ "mạng quen" — lần đầu mỗi mạng sẽ không còn được ưu tiên trong lúc phòng thủ) |
| Shield gây lỗi site | tạo `lamp-run/shield-off`; tệ nhất xoá `wp-content/mu-plugins/wppocket-shield.php` và tạo `shield-no-install` |
| Scanner báo nhầm file hợp lệ | "Bỏ qua" hoặc "Chấp nhận" từng phát hiện |
| File bị cách ly nhầm | "Khôi phục" ở Trung tâm bảo mật |
| Mất điện thoại, không vào được WordPress vì hai bước | (1) dùng một **mã khôi phục** đã lưu; (2) quản trị viên khác tắt hai bước cho bạn ở trang sửa người dùng; (3) tạo `lamp-run/twofa-off` (bật/tắt ở Trung tâm bảo mật, hoặc tạo file trực tiếp); (4) WP-CLI: `wp user meta delete <ID> wppocket_2fa` |

## 8. Những gì **chưa** làm và giới hạn trung thực

**Chưa làm (có lý do):**

- **URL đăng nhập bí mật và cổng REST** — phá plugin/công cụ hợp pháp (ứng dụng di động, headless) và dễ khoá chính chủ site; đã có 2FA + chặn dò + Cloudflare Access/Turnstile.
- **`limit_conn`** — qua Cloudflare mọi kết nối đến từ vài IP; đặt sai ngưỡng sẽ chặn khách thật mà không có lưu lượng thật để chỉnh.
- **Khoá hàm chạy lệnh hệ thống (`disable_functions`) cho PHP công khai — ĐÃ THỬ và GỠ BỎ.** Làm bằng `fastcgi_param PHP_ADMIN_VALUE` theo từng location rồi chạy trên nginx + php-fpm thật thì phát hiện **mất hàm là vĩnh viễn với worker đó**: mọi request sau trên cùng worker (kể cả `_admin/` và đánh thức MariaDB) cũng mất `shell_exec`, và tắt cờ không hoàn tác được. Cách đúng là một **pool php-fpm riêng** cho phần công khai, nhưng cần reload php-fpm khi bật/tắt mà hành vi đó trên Android chưa kiểm được. Chi tiết và bằng chứng: `HANDOFF.md` mục 1br-H. Bù lại, PHP trong `uploads/` đã bị chặn thực thi và bị quét.

**Giới hạn của những gì đã làm:**

- **Đã chạy trên nginx 1.31.8, PHP-FPM 8.3.36 và WordPress 7.1.4 thật** (dựng từ mã nguồn trên GitHub; WordPress chạy bằng SQLite): chuỗi chặn IP (`security-nginx-test.py`), quét mã độc trên cây WordPress sạch + cùng plugin lớn (Yoast, Elementor, Contact Form 7, WooCommerce) không báo nhầm (`wp-real-test.py`), và 2FA (`wp-2fa-test.py`). Các lần chạy này đã **tìm ra lỗi thật** và đã sửa (xem `HANDOFF.md` mục 1br-H).
- **Vẫn CHƯA chạy trên điện thoại thật, và CHƯA kiểm với MariaDB.** PHP của Termux/Android có thể khác bản dựng thử (ví dụ thiếu libsodium thì 2FA dùng OpenSSL; thiếu cả hai thì không bật được). `fullstack-realwp`, `generic-php` cần MariaDB nên vẫn tự bỏ qua ở môi trường phát triển; `front-proxy-test` và `pagecache-test` báo lỗi **giống hệt trên bản gốc** (không do thay đổi này).
- **Không gọi được dịch vụ thật** `wpvulnerability.net` và `api.wordpress.org` từ môi trường phát triển (bị chặn): logic kiểm lỗ hổng được test bằng máy chủ giả lập theo đúng cấu trúc đọc từ mã nguồn plugin WPVulnerability; checksum lõi được test bằng checksum lập từ chính mã nguồn WordPress thật. Nếu dịch vụ đổi định dạng, thẻ "Lỗ hổng đã biết" sẽ báo lỗi/trống chứ không báo sai.
- Phần Kotlin: 35 tệp (gồm `Monitoring.kt`, `Prefs.kt`, `MonitorLogic.kt`) đã **biên dịch 0 lỗi** với `android.jar` API 34; **11 tệp dùng `androidx`** (Worker/Activity…) vẫn chưa biên dịch được ở đây.
- Scanner là **heuristic**: có thể báo nhầm và có thể bỏ sót mã độc được che giấu kỹ. Không thay thế quét bằng công cụ chuyên dụng và **sao lưu ngoài máy**.
- Guard chỉ chặn được IP khách thật khi nginx có `realip`; Cloudflare WAF vẫn hiệu quả hơn nhiều cho tấn công khối lượng lớn.
- Kẻ tấn công trả tiền cho hàng nghìn IP có thể lọt dưới ngưỡng theo IP; lớp Shield (đếm theo tài khoản) giảm nhưng không loại trừ rủi ro này.
- Không lớp nào chặn được khai thác lỗ hổng chưa vá **không để lại dấu vết trong log 4xx** — chỉ có thể phát hiện sau (qua Scanner) và hạn chế hậu quả (`DISALLOW_FILE_EDIT`, không PHP trong uploads, sao lưu).

## 9. Nguồn tham khảo

- The Next Web — bài về khai thác WordPress "wp2shell" (7/2026) và tốc độ khai thác sau công bố.
- itproexpert.com / Patchstack — tổng hợp lỗ hổng plugin WordPress và tài khoản quản trị ngầm.
- wplus.net — tổng hợp tấn công quét hàng loạt và crawler AI.
- Môi trường thử thật dựng từ GitHub: `nginx/nginx`, `php/php-src`, `WordPress/WordPress`, `WordPress/sqlite-database-integration`, `javiercasares/wpvulnerability` (đọc cấu trúc API), `Reginer/aosp-android-jar`, `Yoast/wordpress-seo`, `elementor/elementor`, `takayukister/contact-form-7`, `woocommerce/woocommerce`, `skvadrik/re2c`.

(Các số liệu như "90 phút đến 5 giờ", "hơn 100 tài khoản admin" lấy từ các nguồn trên và **chưa được kiểm độc lập** trong dự án.)
