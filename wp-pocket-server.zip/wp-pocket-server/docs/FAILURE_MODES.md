# Các kiểu hỏng và cách app phản ứng (FMEA rút gọn)

Tài liệu này trả lời: **cái gì có thể hỏng, app biết bằng cách nào, tự làm gì, người dùng mất gì, và cần làm gì.** Mọi con số trong bảng được bộ test `docs-consistency-test.py` đối chiếu với code; đổi code mà quên sửa tài liệu thì test đỏ. Cột "Đã thử trên máy thật?" ghi thẳng những chỗ **chưa** kiểm chứng ngoài môi trường test.

<!-- code-fact: HEALTH_PERIOD_MIN=15 -->
<!-- code-fact: HEALTH_FAIL_THRESHOLD=2 -->
<!-- code-fact: DISK_ALERT_PCT=85 -->
<!-- code-fact: DISK_ALERT_COOLDOWN_H=24 -->
<!-- code-fact: HEAT_HOT_TENTHS=450 -->
<!-- code-fact: HEAT_MAX_DEFERRALS=3 -->
<!-- code-fact: MAX_FAILED_ATTEMPTS=5 -->
<!-- code-fact: LOCKOUT_SEC=900 -->
<!-- code-fact: AUDIT_ALERT_COOLDOWN_MIN=30 -->
<!-- code-fact: SESSION_IDLE_SEC=1800 -->
<!-- code-fact: MARIADB_STOP_TIMEOUT=20 -->
<!-- code-fact: TELEGRAM_MAX_MB=50 -->
<!-- code-fact: PHP_FATAL_COOLDOWN_MIN=60 -->

| # | Sự cố | App phát hiện bằng | App tự làm | Người dùng mất gì | Người dùng cần làm |
|---|-------|--------------------|-----------|--------------------|---------------------|
| 1 | Website không trả lời (nginx/php-fpm/MariaDB chết) | `HealthCheckWorker` chạy mỗi 15 phút; báo khi thất bại liên tiếp 2 lần (~30 phút) | Gửi cảnh báo (Telegram/webhook nếu đã cấu hình) | Thời gian site ngừng (tối đa vài chục phút trước khi biết) | Mở app, xem log; khởi động lại server |
| 2 | Điện thoại tắt nguồn, hết pin, mất mạng, bị người dùng/hệ điều hành tắt app | Không có gì chạy được nữa; chỉ dịch vụ giám sát **bên ngoài** mới biết | Không | Site ngừng cho đến khi mở lại | Bật máy/mạng, mở app. Không có SLA — xem mục "Giới hạn" của README |
| 3 | Bộ nhớ gần đầy (≥ 85%) | Giám sát dung lượng | Cảnh báo, tối đa 1 lần/24 giờ | Nếu đầy hẳn: backup/upload/ghi log có thể lỗi | Dọn bộ nhớ; xoá backup cũ; xem "Dữ liệu trên máy". 85% là mặc định, chỉnh được ở "Ngưỡng và quy tắc cảnh báo…" (docs/ALERT_RULES.md) |
| 4 | Máy nóng (≥ 45,0 °C) | Đọc nhiệt độ pin | Hoãn backup **định kỳ** (không hoãn khi bấm tay) tối đa 3 lần liên tiếp, lần sau vẫn chạy | Backup chậm hơn dự kiến | Để máy thoáng, tránh vừa sạc vừa chạy nặng |
| 5 | Dò mật khẩu `_admin/` | Đếm lần sai theo IP | Sai 5 lần → khoá IP đó 900 giây (15 phút), ghi nhật ký kiểm toán, cảnh báo (tối đa 1 lần/30 phút) | Không mất gì | Xem nhật ký kiểm toán; bật 2FA |
| 6 | Quên tắt trang quản trị | Phiên không hoạt động | Hết phiên sau 1800 giây (30 phút) | Không | Đăng nhập lại |
| 7 | Tắt server khi MariaDB đang ghi | Lệnh tắt của app | Dừng theo thứ tự nginx, php-fpm, MariaDB (cuối cùng); mỗi tiến trình nhận tín hiệu dừng sạch, chờ nginx/php-fpm tối đa 5 giây, MariaDB tối đa 20 giây rồi mới buộc dừng | Nếu buộc dừng: lần khởi động sau MariaDB tự chạy phục hồi InnoDB (chậm hơn bình thường) | Chờ khởi động xong; kiểm tra site |
| 8 | Backup tạo xong nhưng zip hỏng | `verifyBackupZip` ngay sau khi tạo | Xoá file hỏng, báo lỗi backup (WorkManager thử lại); không để lại bản trông bình thường nhưng hỏng | Bản backup đó | Chạy backup lại |
| 9 | Backup **không gửi được ra ngoài máy** (mạng lỗi, hoặc tệp > 50 MB với Telegram) | Kết quả gửi (từ vòng 1bo; trước đó bị bỏ qua và vẫn báo "backup_ok") | Gửi tin cảnh báo "CHƯA có bản sao ngoài máy"; sự kiện `backup_failed` | Không có bản sao ngoài máy cho lần đó (xem DISASTER_RECOVERY.md) | Dùng webhook nhận được tệp lớn, hoặc "Xuất backup ra ngoài…" thủ công |
| 10 | Gửi backup lớn làm cạn RAM | Trước 1bo: **không phát hiện** (OutOfMemoryError) | Từ 1bo: gửi theo luồng, độ dài biết trước, không đệm cả file | — | — (đã sửa; chưa thử trên máy thật) |
| 11 | Cài đè APK mới | Dấu cập nhật của APK | Từ 1bo: **gộp đè**, giữ uploads/plugin/theme/SQLite/tệp tự thêm; thay mã chương trình | Trước 1bo: **mất toàn bộ thư mục website** | Đăng nhập WordPress lại một lần (`wp-config.php` sinh lại) |
| 12 | Cập nhật APK bị ngắt giữa chừng (mất điện) | Dấu cập nhật chưa được ghi | Lần khởi động sau tự thử lại (giải nén đè là idempotent) | Không | Mở app lại |
| 13 | `site.config.json` sai cú pháp/gõ sai khoá | `validate_config.py` ở bước đầu của CI | Dừng build với thông báo dòng/cột và gợi ý | Chỉ mất thời gian build | Sửa file theo gợi ý |
| 14 | Plugin/theme gây lỗi PHP nghiêm trọng (hết bộ nhớ, quá thời gian, cú pháp, không xử lý) — trang trắng/HTTP 500 | Mỗi chu kỳ sức khoẻ đọc phần MỚI của `lamp-run/php-error.log` (PHP tự ghi sẵn), gom nhóm và phân loại | Báo Telegram tối đa 1 lần/60 phút; chưa gửi được thì lần sau đọc lại đúng đoạn đó | Trang lỗi cho đến khi sửa/gỡ plugin | Nếu "hết bộ nhớ" hoặc "quá thời gian": thử hồ sơ **Hiệu năng PHP** nặng hơn; nếu "cú pháp/không xử lý": gỡ plugin/theme vừa cài |
| 15 | Nghi ngờ bảng CSDL hỏng (mất điện, bị buộc dừng) | Người dùng bấm **Kiểm tra cơ sở dữ liệu** (CHECK TABLE QUICK, chỉ đọc) | Chỉ báo, **không tự sửa** | Không mất gì do bước kiểm tra | Sao lưu ngay; cân nhắc khôi phục bản gần nhất |

## Giới hạn của chính tài liệu này
- Các hàng 1–13 mô tả hành vi **theo code và test**, chưa được kiểm chứng trên thiết bị thật trong vòng 1bo (môi trường làm việc không có Android/kotlinc/PHP). Hàng 9–11 là sửa mới của 1bo, cần thử thật: cài đè APK khi có ảnh tải lên; gửi backup > 50 MB.
- `BackupVerifier` còn kiểm tra định kỳ các bản backup đã lưu và phát sự kiện `backup_verify_failed`; cơ chế này **chưa được mô tả chi tiết ở đây** (chưa rà kỹ trong vòng 1bo).
- Chưa có thống kê tần suất hay mức nghiêm trọng thực tế (không có dữ liệu vận hành). Không cho điểm RPN giả tạo.
