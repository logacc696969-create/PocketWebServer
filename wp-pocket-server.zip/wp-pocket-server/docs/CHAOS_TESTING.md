# Kiểm thử hỗn loạn (chaos testing)

Mục tiêu: chủ động gây sự cố thật rồi kiểm xem hệ thống phục hồi đúng không, thay vì chỉ kiểm đường đi thuận lợi. PDF đề xuất bốn kịch bản: rút mạng giữa lúc backup, tắt app giữa lúc restore, đầy đĩa giữa lúc `mysqldump`, giết MariaDB giữa lúc ghi. Bảng dưới nói thẳng cái nào **đã kiểm tự động**, cái nào **chỉ có kịch bản chạy trên điện thoại**, cái nào **chưa kiểm được**.

| Sự cố | Cơ chế bảo vệ trong mã | Kiểm thế nào | Trạng thái |
|---|---|---|---|
| Giết cứng app / nginx (bộ giám sát runtime Node/Python/tĩnh) | `start-generic.sh`: một tiến trình chết → dừng tiến trình kia, thoát 1 để Kotlin khởi động lại | `chaos-test.py` (script thật, tiến trình giả, seed ngẫu nhiên) | Tự động trong CI |
| Giết cứng **chính bộ giám sát** (SIGKILL, không kịp dọn) | `kill_stale` (tệp pid + khớp cmdline) **và quét `/proc`** theo đường dẫn đầy đủ của binary | `chaos-test.py` | Tự động trong CI |
| Tệp pid hỏng / trỏ tới tiến trình không liên quan | Không giết tiến trình lạ (khớp cmdline); tệp hỏng bị xoá | `chaos-test.py` | Tự động trong CI |
| App chết ngay khi khởi động (vòng lặp sập) | Thoát 1 nhanh, không để lại tiến trình/tệp rác | `chaos-test.py` | Tự động trong CI |
| Đầy đĩa **lúc khởi động** (không ghi được cấu hình) | `startup_abort`: dọn app/nginx đã chạy rồi thoát khác 0 | `chaos-test.py` (`ulimit -f`) | Tự động trong CI |
| Đóng băng app (SIGSTOP) | Bộ giám sát không coi là chết; **không** tự phát hiện treo (việc của `HealthCheckWorker`) | `chaos-test.py` | Tự động trong CI |
| Tắt app **giữa lúc restore** | Kiểm toàn vẹn + dung lượng **trước khi** chạm dữ liệu; ghi tệp nguyên vẹn từng cái; **dấu "đang khôi phục"** (`RestoreMarker`) → báo Telegram nếu bị gián đoạn | `restore-marker-test.py` (SIGKILL JVM thật) + kiểm tĩnh thứ tự trong `performRestore` | Tự động (logic); Kotlin chưa biên dịch |
| Tắt app **giữa lúc backup** | Ghi `.zip.partial` rồi mới đổi tên sau khi kiểm hợp lệ; `cleanupStaleLeftovers` dọn `.partial` mồ côi; xoay vòng chỉ sau khi thành công | Đọc mã (HANDOFF 1az/1bp); **chưa có test chạy được** | Chưa kiểm tự động |
| Đầy đĩa giữa lúc `mysqldump` | Kiểm dung lượng trước khi backup; lỗi → xoá `.partial`/dump | Chỉ qua `chaos-device.sh fill-disk` trên điện thoại | Chỉ kịch bản thiết bị |
| Rút mạng giữa lúc upload backup | Upload tách khỏi việc tạo backup (backup cục bộ giữ nguyên) | Chỉ qua `chaos-device.sh network-off` | Chỉ kịch bản thiết bị |
| Giết MariaDB giữa lúc ghi | InnoDB tự phục hồi khi khởi động lại; start-lamp.sh dọn pid/socket cũ | Chỉ qua `chaos-device.sh kill-daemons` | Chỉ kịch bản thiết bị |

## Chạy

```
python3 scripts/tests/chaos-test.py                       # mặc định seed 20261026, 28 vòng (~1 phút)
CHAOS_SEED=7 CHAOS_ROUNDS=60 python3 scripts/tests/chaos-test.py   # seed/số vòng khác: tái lập được nếu có lỗi
python3 scripts/tests/restore-marker-test.py              # cần JDK
python3 scripts/tests/chaos-device-test.py                # kiểm chính kịch bản adb bằng adb giả
```

Trên điện thoại (bản APK **debug**, cắm USB, bật API trạng thái và đặt `WPPOCKET_TOKEN`):

```
scripts/chaos/chaos-device.sh kill-daemons --yes --host 192.168.1.23
scripts/chaos/chaos-device.sh fill-disk   --yes --host 192.168.1.23 --leave-mb 500
scripts/chaos/chaos-device.sh network-off --yes --host 192.168.1.23 --net-off 60
```

Mỗi kịch bản: gây sự cố → đợi → hỏi API trạng thái chỉ đọc (`wppocket status --check`) đến khi OK hoặc hết `--wait`. Mã thoát 0 phục hồi / 1 không phục hồi / 2 lỗi môi trường. An toàn: bắt buộc `--yes`; `fill-disk` chỉ ghi trong thư mục của app và **luôn để lại ít nhất `--leave-mb` MB** (bộ nhớ dùng chung với ứng dụng khác), luôn xoá tệp khi thoát; `network-off` **luôn bật lại mạng** kể cả khi Ctrl-C/TERM.

## Phát hiện từ vòng kiểm này (đã sửa)

1. **Khởi động thất bại giữa chừng bỏ app mồ côi vĩnh viễn** (`start-generic.sh`). `set -e` + `sed`/`echo` lỗi (đầy đĩa, thiếu mẫu) thoát ngay khi app đã chạy nền; chưa ghi được `front-app.pid` nên lần khởi động sau cũng không tìm thấy. Sửa: `startup_abort` (bẫy `EXIT`) TERM → KILL sau 2 s cho mọi thứ đã chạy; tắt bẫy khi hai tiến trình đã lên.
2. **`kill_stale` chỉ dựa vào tệp pid** → tệp hỏng/mất thì tiến trình mồ côi sống mãi; và chỉ gửi TERM rồi `sleep 1` (tiến trình bỏ qua TERM sống mãi). Sửa: quét `/proc` theo đường dẫn đầy đủ của binary (đường dẫn `nativeLibraryDir` riêng của app, không thể trùng tiến trình khác), bỏ qua chính nó, thêm KILL cứng.
3. **Khoảng trống "tắt app giữa lúc restore"**: `BackupLogic.extract` ghi từng tệp nguyên vẹn nhưng **cả tập không nguyên tử**, và cơ sở dữ liệu được nạp **sau** khi giải nén, nên kill giữa chừng để lại site nửa cũ nửa mới **mà không có dấu vết nào**. Sửa một phần: `RestoreMarker` (ghi trước khi chạm dữ liệu, xoá khi xong; còn sau 15 phút → báo Telegram một lần, yêu cầu chạy lại khôi phục từ cùng bản backup).

## Chưa làm (nói thẳng)

- Restore **vẫn chưa nguyên tử** và **không tự tạo bản sao an toàn** trước khi ghi đè: chỉ *phát hiện* được gián đoạn, chưa *tự phục hồi*. Hướng đúng: giải nén vào thư mục mới rồi đổi tên hoán đổi + bản backup "trước khi khôi phục" không làm trôi bản tốt khỏi vòng xoay `KEEP_BACKUPS`. Cần Kotlin chạy được để làm an toàn.
- Dấu "đang khôi phục" chưa hiện trên giao diện (mới báo Telegram) và chưa đưa vào API trạng thái.
- Kịch bản backup bị giết giữa chừng và `mysqldump` đầy đĩa chưa có test chạy được (cần Kotlin + MariaDB).
- Chưa chạy `chaos-device.sh` trên điện thoại thật; các lệnh `run-as`/`svc`/`monkey` mới được kiểm bằng adb giả.
