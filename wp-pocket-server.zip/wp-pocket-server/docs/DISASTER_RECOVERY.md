# Khôi phục sau sự cố: RPO, RTO và quy trình

Tài liệu nói thật mức bảo vệ mà app **đang** cho, và những chỗ nó **không** cho.

<!-- code-fact: KEEP_BACKUPS=5 -->
<!-- code-fact: BACKUP_DEFAULT_HOURS=24 -->
<!-- code-fact: TELEGRAM_MAX_MB=50 -->
<!-- code-fact: BACKUP_CONTAINS=database.sql,www -->
<!-- code-fact: ALLOW_BACKUP=false -->

## 1. Backup chứa gì và KHÔNG chứa gì
- **Chứa:** toàn bộ thư mục website `www/` (kèm `wp-config.php`, ảnh, plugin, theme; ở chế độ Lite còn cả CSDL SQLite) và, ở chế độ Full, một tệp `database.sql` (bản dump MariaDB).
- **KHÔNG chứa:** các thiết lập và bí mật của app (token Telegram, URL webhook, token Cloudflare Tunnel, **cụm mật khẩu mã hoá backup**), mật khẩu quản trị `admin-password.txt`, cấu hình 2FA. App đặt `allowBackup="false"` nên Android cũng không sao lưu chúng lên đám mây.
- Hệ quả: sau khi khôi phục lên máy mới phải **cấu hình lại** các thứ trên (các giá trị này được mã hoá bằng khoá Keystore gắn với máy cũ nên cũng không thể sao chép sang máy mới). Nếu bật mã hoá backup mà không ghi lại cụm mật khẩu ở nơi khác, mất máy là mất luôn khả năng giải mã.

## 2. RPO (tối đa mất bao nhiêu dữ liệu)
| Tình huống | RPO |
|------------|-----|
| Máy còn nguyên, hỏng phần mềm/CSDL | Khoảng thời gian từ backup trong máy gần nhất: mặc định 24 giờ (có thể đổi); app giữ 5 bản gần nhất nên lịch sử mặc định ~5 ngày |
| Mất/hỏng máy, **có** cấu hình Telegram/webhook và lần gửi gần nhất thành công | Từ lần gửi thành công gần nhất |
| Mất/hỏng máy, chỉ có backup trong máy | **Mất tất cả** — bản trong máy nằm cùng chiếc máy |
| Gửi Telegram nhưng tệp > 50 MB | Telegram từ chối. Từ 1bo app báo rõ "CHƯA có bản sao ngoài máy"; trước 1bo vẫn báo thành công (lỗi đã sửa) |

Nội dung thay đổi **sau** lần backup cuối (bài viết, đơn hàng, bình luận mới) không được bảo vệ.

## 3. RTO (mất bao lâu để chạy lại)
**Chưa đo.** Không có số liệu đo trên thiết bị thật nên tài liệu không đưa con số. Thời gian phụ thuộc kích thước site, tốc độ máy và mạng. Hãy tự diễn tập (mục 5) và ghi con số của bạn vào đây.

## 4. Quy trình khôi phục lên máy mới
1. Cài APK, mở app, để server khởi động lần đầu.
2. Đưa tệp backup vào máy (từ Telegram/webhook/nơi bạn lưu) và dùng **Nhập backup từ file…**. Nếu là bản mã hoá (`.zip.enc`) nhập đúng cụm mật khẩu.
3. Cấu hình lại: tunnel (token Cloudflare), Telegram/webhook, mã hoá backup, 2FA. Mật khẩu quản trị mới được sinh trên máy mới.
4. Với Quick Tunnel, địa chỉ công khai **đổi** — cập nhật liên kết đã chia sẻ. Named Tunnel giữ nguyên tên miền.
5. Đăng nhập WordPress, kiểm tra ảnh, plugin, bài viết.

## 5. Diễn tập (khuyến nghị mỗi quý)
Khôi phục một bản backup thật lên máy phụ hoặc máy ảo, đo thời gian từ bước 1 đến bước 5, và kiểm tra site chạy đúng. Bản backup chưa từng khôi phục thử thì chưa thể coi là backup.

## 6. Thẻ nhớ không phải bản sao ngoài máy
Tuỳ chọn **Lưu backup mới trên thẻ nhớ khi có** giúp backup sống sót nếu bộ nhớ trong hỏng mà thẻ còn nguyên, và đỡ tốn bộ nhớ trong. Nó **không** thay thế bản sao ngoài máy: mất cả điện thoại thì thẻ mất cùng. Chỉ các tệp zip backup được lưu sang thẻ; CSDL và website vẫn ở bộ nhớ trong. Rút thẻ giữa chừng thì lần backup sau tự lưu lại vào bộ nhớ trong.

## 7. Vì sao backup trong máy cũng cần cẩn thận
Backup lưu ở thư mục riêng của app trên bộ nhớ ngoài. Android 11 trở lên chặn ứng dụng khác đọc; trên Android 8–10 một số ứng dụng có quyền đọc bộ nhớ có thể đọc được. Backup chứa `wp-config.php` (mật khẩu CSDL và khoá bảo mật) nên nên bật mã hoá backup.
