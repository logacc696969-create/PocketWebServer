# Giá trị cốt lõi và đối tượng dùng

> **Độ tin cậy:** viết từ **mã nguồn và tài liệu của dự án**, không từ nghiên cứu người dùng hay khảo sát thị trường (chưa có người dùng thật nào — đang trong giai đoạn thử nghiệm miễn phí, xem `docs/BETA_PROGRAM.md`). Mỗi tuyên bố bên dưới kèm **bằng chứng trong repo** và được test kiểm là còn đúng (`scripts/tests/value-docs-test.py`). Không có tuyên bố nào về số liệu thị trường, người dùng hay doanh thu.

## 1. Tuyên bố giá trị (AG2)

**Một câu:** *Chạy một website trên điện thoại Android cũ và đưa ra Internet trong vài phút — không cần thuê VPS, không cần mở cổng router, không cần IP tĩnh — với backup, cảnh báo và trang quản trị ngay trong tay.*

PDF gợi ý ba câu cụ thể; đây là bản đã đối chiếu với những gì app **thực sự làm** (không hứa hơn):

| # | Tuyên bố | Bằng chứng trong repo |
|---|---|---|
| U1 | **Ra Internet không cần mở cổng/IP tĩnh**: Cloudflare Quick Tunnel cho URL https công khai ngay; có thể dùng tên miền riêng (Named Tunnel) | `README.md` (đoạn mở đầu, CGNAT), `app/src/main/java/com/wppocket/server/ServerForegroundService.kt` (`cloudflared`) |
| U2 | **Một website, chọn kiểu backend bằng một tệp**: WordPress/PHP, Node, Python (WSGI/ASGI) hoặc tĩnh — sửa `site.config.json`, không đụng mã Kotlin | `site.config.json`, `scripts/tools/apply_preset.py` (`RUNTIMES`) |
| U3 | **WordPress chạy trên nền thật**: nginx + php-fpm + MariaDB (không phải máy chủ dev + SQLite) | `scripts/runtimes/templates/start-lamp.sh` (`mariadbd`, `php-fpm`) |
| U4 | **Quản trị ngay trên web, không cần máy tính**: trang `_admin/` (cài WordPress 1 chạm, 2FA, chế độ bảo trì, thống kê) chỉ mở cho mạng LAN, mật khẩu riêng mỗi máy | `scripts/runtimes/templates/nginx.conf.template` (`allow 192.168.0.0/16`), `scripts/runtimes/templates/admin-auth.php` |
| U5 | **Không mất dữ liệu âm thầm**: backup có xác minh, mã hoá tuỳ chọn, gửi Telegram/webhook, cảnh báo khi không có bản sao ngoài máy | `app/src/main/java/com/wppocket/server/BackupVerifier.kt`, `app/src/main/java/com/wppocket/server/TelegramNotifier.kt` |
| U6 | **Biết khi có chuyện** mà không cần mở app: cảnh báo qua Telegram, ngưỡng và quy tắc tự viết, theo dõi từ máy tính | `docs/ALERT_RULES.md`, `app/src/main/java/com/wppocket/server/AlertRules.kt`, `scripts/tools/wppocket_cli.py` |
| U7 | **Nói thẳng giới hạn**: bản thử nghiệm, có thể lỗi, không SLA | `TERMS.md` (điều 7), `docs/COMPETITIVE_ANALYSIS.md` (mục "Điểm yếu thật") |

**Khẩu hiệu thử (chủ dự án chọn):** "Server bỏ túi: WordPress trên điện thoại cũ, ra Internet không cần VPS" · "Backup tự động lên Telegram, không lo mất dữ liệu" · "Quản trị qua web, không cần máy tính". **[CHỦ DỰ ÁN QUYẾT: khẩu hiệu chính thức — chưa quyết]**

**Khác gì các giải pháp có sẵn:** xem `docs/COMPETITIVE_ANALYSIS.md` (so sánh dựa trên tài liệu công khai **cũ**, chưa kiểm với bản hiện tại của đối thủ — không nên dùng làm lời quảng cáo).

## 2. Đối tượng dùng (AG3)

### Phù hợp

1. **Người muốn tự host một blog/website nhỏ gần như miễn phí** (blogger, dự án cá nhân, trang giới thiệu nhỏ) và có sẵn một điện thoại Android cũ.
2. **Lập trình viên cần môi trường thử/demo nhanh**: dựng WordPress hoặc ứng dụng Flask/Django/Node thử, cho khách xem qua một liên kết (có mã QR) rồi tắt đi, không phải thuê máy chủ.
3. **Người ở sau CGNAT** (mạng di động/cáp quang hộ gia đình) không mở được cổng — đúng vấn đề Cloudflare Tunnel giải quyết.
4. **Người muốn học vận hành web server** (nginx, PHP-FPM, MariaDB, backup, cảnh báo) trên thiết bị rẻ, ít rủi ro.
5. **Người thử nghiệm** trong giai đoạn miễn phí hiện tại, chấp nhận lỗi và sẵn sàng báo lại (`docs/BETA_PROGRAM.md`).

### KHÔNG phù hợp (nói thẳng, kẻo mất công và mất dữ liệu)

1. **Website thương mại/quan trọng, cần uptime** — điện thoại có thể tắt, mất mạng, hỏng; không SLA, không dự phòng địa lý (`docs/DISASTER_RECOVERY.md`).
2. **Lưu lượng lớn** — giới hạn là RAM/CPU điện thoại; không mở rộng ngang được.
3. **Nhiều website trên một máy** — thiết kế là **một website duy nhất**.
4. **Máy chủ email, cơ sở dữ liệu dùng chung, dịch vụ cần IP tĩnh/cổng riêng.**
5. **Dữ liệu nhạy cảm phải tuân thủ chặt** (y tế, thanh toán) — chưa có đánh giá bảo mật độc lập; pháp lý xem `docs/LEGAL_NOTES_VN.md`.
6. **Người không muốn dùng điện thoại chạy liên tục** — chạy 24/7 làm nóng máy và hao pin (`docs/ALERT_RULES.md` có ngưỡng nhiệt độ/pin).

### Mức kỹ thuật cần có

Cài APK ngoài cửa hàng, cấp quyền chạy nền/bỏ tối ưu pin, đọc được hướng dẫn trong `README.md`. Không cần biết dòng lệnh để chạy WordPress cơ bản; cần biết cơ bản khi dùng Node/Python hoặc theo dõi bằng `wppocket`.

## 3. Chưa làm

Chưa khảo sát người dùng thật; chưa có kênh phản hồi chính thức (chủ dự án chọn); chưa có trang giới thiệu/ảnh chụp màn hình; khẩu hiệu chưa chốt.
