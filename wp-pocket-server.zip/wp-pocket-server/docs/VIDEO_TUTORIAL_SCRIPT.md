# Kịch bản video hướng dẫn

Video không phải việc của mã nên không thể "làm" ở đây; để **bất kỳ ai quay được trong một buổi** (và phụ đề dùng lại cho bài viết), tài liệu này cung cấp **kịch bản, danh sách cảnh quay và lời thoại**. Mọi chữ nằm trong dấu ngoặc góc kiểu Nhật là **nhãn nút thật** trong app (kiểm tự động với `strings.xml` tiếng Việt bởi `scripts/tests/extending-docs-test.py`) — nếu đổi nhãn nút thì test báo để sửa kịch bản.

**Quy cách gợi ý:** quay màn hình điện thoại dọc 1080×2340, 30 fps, thu tiếng riêng, phụ đề tiếng Việt cứng (khoảng 40% người xem tắt tiếng), **che token/IP/mật khẩu bằng làm mờ** trước khi đăng (`docs/BETA_PROGRAM.md`). Mỗi video ≤ 4 phút. Dùng điện thoại phụ, site thử.

## Video 1 — Cài và chạy lần đầu (3 phút)

| Cảnh | Hình | Lời thoại |
|---|---|---|
| 1 (0:00) | Màn hình chính app | "WP Pocket Server biến điện thoại cũ thành web server chạy WordPress. Đây là bản **thử nghiệm miễn phí**: có thể lỗi, đừng dùng cho site quan trọng." |
| 2 (0:20) | Cài APK, mở app | "Cài xong, mở app. Lần đầu app hướng dẫn vài bước." |
| 3 (0:45) | Bấm 「Bỏ qua tối ưu hoá pin」 | "Bước quan trọng nhất: cho app chạy nền. Bấm **Bỏ qua tối ưu hoá pin** rồi chọn Cho phép." |
| 4 (1:10) | Bấm 「Mở cài đặt Tự khởi động của hãng máy」 | "Máy Xiaomi, Oppo, Vivo… còn có mục Tự khởi động riêng; bật cho app." |
| 5 (1:35) | Bấm 「Bật server」, chờ trạng thái 「Đang chạy」 | "Bấm **Bật server**. Khi trạng thái là **Đang chạy**, địa chỉ website hiện ra." |
| 6 (2:05) | Bấm 「Mở trang quản trị」 | "Bấm **Mở trang quản trị**, mật khẩu ở ngay trong app; có nút **Sao chép**." |
| 7 (2:40) | Bấm 「Chia sẻ liên kết / mã QR」 | "Muốn cho người khác xem site? Bấm **Chia sẻ liên kết / mã QR** rồi cho họ quét mã." |
| 8 (3:00) | Màn hình chính | "Hết video 1. Video sau: sao lưu và cảnh báo." |

## Video 2 — Sao lưu và khôi phục an toàn (3 phút 30)

| Cảnh | Hình | Lời thoại |
|---|---|---|
| 1 (0:00) | Màn hình chính | "Sao lưu là thứ cứu bạn khi điện thoại hỏng." |
| 2 (0:15) | Bấm 「Backup ngay」 | "Bấm **Backup ngay**. App tạo file, **kiểm tra** file hợp lệ rồi mới tính là xong." |
| 3 (0:50) | Bấm 「Xuất backup ra ngoài…」 | "Quan trọng: **xuất backup ra ngoài điện thoại** — máy tính hoặc đám mây. Backup chỉ nằm trong máy thì mất máy là mất hết." |
| 4 (1:30) | Bấm 「Khôi phục từ backup」 | "Khôi phục thử trên **site thử**, đừng thử trên site thật. App kiểm file và dung lượng **trước khi** ghi đè." |
| 5 (2:15) | Cảnh báo | "Đừng tắt app giữa lúc khôi phục. Nếu lỡ tắt, sau 15 phút app báo Telegram; chạy lại khôi phục từ **cùng bản backup**." |
| 6 (3:00) | Bấm 「Nhập backup từ file…」 | "Chuyển sang máy mới: **Nhập backup từ file…**, rồi khôi phục." |

## Video 3 — Cảnh báo và theo dõi (3 phút 30)

| Cảnh | Hình | Lời thoại |
|---|---|---|
| 1 (0:00) | Telegram | "Để biết server có vấn đề mà không cần mở app, hãy cấu hình Telegram." |
| 2 (0:40) | Bấm 「Ngưỡng và quy tắc cảnh báo…」 | "Bấm **Ngưỡng và quy tắc cảnh báo…** để chỉnh bốn ngưỡng: bộ nhớ đầy, pin cạn, pin ấm, pin quá nóng." |
| 3 (1:30) | Gõ quy tắc `high_ram: ram_percent > 90 for 15m` | "Tự viết quy tắc: mỗi dòng một quy tắc. Ví dụ báo khi RAM trên 90% liên tục 15 phút. Sai cú pháp thì app báo dòng nào và lỗi gì, bấm **Lưu**." |
| 4 (2:20) | Bấm 「Địa chỉ và token API…」 | "Muốn theo dõi từ máy tính? Bật API trạng thái, lấy token ở **Địa chỉ và token API…**." |
| 5 (2:50) | Terminal: `python3 scripts/tools/wppocket_cli.py status` | "Trên máy tính cùng mạng, lệnh `wppocket status` cho biết server chạy chưa, pin, bộ nhớ, backup. Thêm `--check` để dùng với cron." |
| 6 (3:20) | Bấm 「Xem log (luôn bấm được, kể cả khi server lỗi)」 | "Có sự cố? Bấm **Xem log**, rồi **Chia sẻ** — nhớ che token và IP trước khi gửi cho chủ dự án." |

## Phụ đề

Phụ đề lấy nguyên cột "Lời thoại" (mỗi dòng ≤ 42 ký tự, ≤ 2 dòng, mỗi dòng hiện 2–4 giây). Bản tiếng Anh: dịch cùng cấu trúc, dùng nhãn nút trong `values-en/strings.xml`.

## Chưa làm

Chưa quay video; chưa dịch tiếng Anh; chưa có video cho runtime Node/Python (`docs/PYTHON_WSGI.md`).
