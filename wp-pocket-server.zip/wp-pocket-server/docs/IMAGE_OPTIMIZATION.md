# Tối ưu ảnh khi tải lên (WordPress)

PDF (mục I4) nói chưa có tối ưu ảnh/WebP. Ảnh chụp bằng điện thoại thường 3–8 MB; trên điện thoại làm server, bộ nhớ và dữ liệu di động đều quý. Bản này thêm một **mu-plugin** (`wppocket-images`) cài sẵn cho site WordPress. Nó chỉ tác động tới **ảnh tải lên sau khi bật**, không đổi ảnh cũ.

## Làm gì

| Việc | Mặc định | Hằng số trong `wp-config.php` |
|---|---|---|
| Giới hạn cạnh dài của ảnh **hiển thị** (WordPress tự tạo bản `-scaled`) | **1920 px** (WordPress mặc định 2560) | `WPP_IMG_MAX_PX` (1024–4096) |
| Chất lượng JPEG của các kích thước phụ | 82 | `WPP_IMG_QUALITY` (40–95) |
| Chất lượng WebP | 80 | `WPP_IMG_WEBP_QUALITY` (40–95) |
| Tạo kích thước phụ dạng **WebP** cho ảnh JPEG mới (nếu máy chủ hỗ trợ WebP; không thì giữ nguyên) | **Bật** | `WPP_IMG_WEBP` (`true`/`false`) |
| **Xoá ảnh gốc cực lớn** sau khi đã có bản thu nhỏ | **TẮT** | `WPP_IMG_DROP_ORIGINAL` (`true` để bật) |

Giá trị ngoài khoảng bị **kẹp** vào khoảng cho phép; giá trị lạ bị bỏ qua (dùng mặc định). Ví dụ trong `wp-config.php`: `define('WPP_IMG_MAX_PX', 1600);`

## Lưu ý quan trọng

- **Tiết kiệm bộ nhớ thật sự nằm ở `WPP_IMG_DROP_ORIGINAL`**: WordPress giữ ảnh gốc cực lớn bên cạnh bản `-scaled`, nên chỉ thu nhỏ bản hiển thị **không** giải phóng dung lượng. Bật tuỳ chọn này thì **mất ảnh gốc** (không khôi phục được qua WordPress). Mặc định tắt vì mất dữ liệu là rủi ro lớn hơn tiết kiệm vài MB.
- WebP chỉ tạo khi PHP trên máy có hỗ trợ WebP (GD hoặc Imagick). Bản PHP đóng gói có thể không có; khi đó plugin không làm gì (không lỗi).
- Chỉ **JPEG → WebP**; PNG giữ nguyên (ảnh chụp màn hình/đồ hoạ dễ giảm chất lượng).
- Cấu trúc 2 tệp có chủ đích (cùng kiểu `wppocket-pagecache`): `wppocket-images.php` cực ngắn nạp `wppocket-images/optimize.php` qua `try/catch Throwable` — lỗi trong logic chỉ làm mất tính năng này, **không làm hỏng website**.

## Chưa kiểm (nói thẳng)

- **PHP không có sẵn trong môi trường phát triển**, nên mu-plugin **chưa được chạy** với WordPress thật. Đã kiểm bằng phân tích văn bản (`scripts/tests/image-optimize-test.py`): cú pháp cân bằng, chỉ gọi hàm trong danh sách cho phép, tên hook và số tham số đúng với tài liệu WordPress, tương thích PHP 7.4, mặc định/khoảng khớp tài liệu này, ngưỡng an toàn (không xoá gì khi tắt tuỳ chọn). CI sẽ chạy `php -l` nếu có PHP.
- Chưa đo mức tiết kiệm dung lượng thực tế; chưa kiểm hỗ trợ WebP của bản PHP đóng gói; chưa kiểm cùng các plugin tối ưu ảnh khác.
- Chưa có công cụ chuyển đổi hàng loạt ảnh cũ.
