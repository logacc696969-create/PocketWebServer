# So sánh với các giải pháp tương tự

> **Độ tin cậy:** phần "đối thủ" dựa trên bài viết/tài liệu công khai **cũ (khoảng 2013–2015)** tìm được ngày 24/10/2026; các ứng dụng đó có thể đã đổi nhiều. Không kiểm chứng bản hiện tại nên **không** đưa nhận định "tốt hơn/kém hơn" về tính năng của họ. Phần về WP Pocket Server lấy từ code của dự án.

## Các giải pháp "server trên Android" đã biết
| Giải pháp | Mô tả theo nguồn công khai | Ghi chú |
|-----------|----------------------------|---------|
| KSWEB | Bộ gồm web server, FTP, PHP, MySQL và bộ lập lịch; chạy không cần root (trừ cổng 80); chạy được WordPress/Joomla/Drupal theo mô tả của nhà phát hành | Bán có phí/dùng thử theo các bài cũ |
| Servers Ultimate (Pro) | Ứng dụng có phí, nhiều loại server (PHP/Lighttpd, MySQL, FTP, mail, SMB, Git…) theo tài liệu của Tiki | Bản miễn phí giới hạn theo bài cũ |
| Tự dựng bằng Termux (nginx/PHP/MariaDB) | Linh hoạt nhưng người dùng tự cài, tự cấu hình, tự vận hành | Dự án này đã **cố ý không** dùng Termux lúc chạy (xem HANDOFF.md) |

## WP Pocket Server khác ở đâu (theo code, chưa so với bản hiện tại của đối thủ)
- Truy cập từ Internet bằng **Cloudflare Tunnel**, không cần mở cổng/IP tĩnh.
- Vận hành qua **Telegram/webhook** (cảnh báo, lệnh `/backup`), kèm giám sát sức khoẻ.
- Backup có xác minh, mã hoá tuỳ chọn, nhập/xuất, và (từ 1bo) cảnh báo khi bản sao ngoài máy không tồn tại.
- Trang quản trị `_admin/` có khoá IP sau nhiều lần sai, 2FA, nhật ký kiểm toán, hết phiên.
- Gói website dựng sẵn từ CI theo `site.config.json`, kèm SBOM và checksum cho chuỗi cung ứng.

## Điểm yếu thật của WP Pocket Server (không né)
- Chưa có thử nghiệm dài hạn trên nhiều dòng máy; nhiều phần mới chỉ qua test tự động (xem từng mục "chưa kiểm chứng" trong HANDOFF.md).
- Backup lớn hơn 50 MB không dùng được Telegram.
- Không có SLA; một điện thoại là một điểm hỏng duy nhất (xem `docs/DISASTER_RECOVERY.md`).
- Chưa có giấy phép mã nguồn (chờ chủ dự án).

## Nguồn
Tổng hợp từ các trang công khai (SourceForge mô tả Servers Ultimate/KSWEB, Slashdot, hướng dẫn cài KSWEB trên MakeTechEasier/Laptop Mag, tài liệu Tiki về Servers Ultimate Pro), truy cập 24/10/2026. Hãy tự kiểm chứng trước khi trích dẫn.
