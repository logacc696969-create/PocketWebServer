# Chương trình thử nghiệm miễn phí (beta)

WP Pocket Server ban đầu **phát hành miễn phí** để người dùng đóng vai **người kiểm thử**: dùng thật, xem app **chạy có ổn định không**, báo lại chỗ chưa ổn. Sau giai đoạn này chủ dự án mới xem xét chuyện tính phí (xem `docs/LICENSE_OPTIONS.md`, `TERMS.md` điều 7). Tài liệu này dành cho **người thử**.

## Trước khi cài (đọc kỹ)

- Đây là bản thử nghiệm: **có thể lỗi, kể cả mất dữ liệu**. **Đừng dùng cho website quan trọng.** Nên dùng một điện thoại phụ.
- **Luôn giữ bản sao lưu ngoài điện thoại** (tải file backup về máy tính). App có backup/restore, nhưng restore **chưa nguyên tử**: nếu tắt app giữa lúc khôi phục, site có thể dở dang (app sẽ báo qua Telegram sau 15 phút nếu đã cấu hình; xem `docs/CHAOS_TESTING.md`).
- Chạy server 24/7 làm điện thoại nóng và hao pin: cắm sạc, để thoáng; xem `docs/ALERT_RULES.md` để đặt ngưỡng cảnh báo.
- Không có bảo đảm vận hành liên tục (không SLA): điện thoại có thể tắt, mất mạng hoặc hỏng.

## Nên thử gì (để đo độ ổn định)

1. **Chạy liên tục 24 giờ** (tắt màn hình). Có tự dừng/khởi động lại không? Có cảnh báo Telegram không?
2. **Đổi mạng** (Wi-Fi ↔ dữ liệu di động), tắt/mở lại Wi-Fi: tunnel có tự nối lại không?
3. **Backup rồi khôi phục thử** trên một site thử (không phải site thật).
4. **Cập nhật** WordPress/plugin; **tải ảnh lên**; bật tắt chế độ bảo trì.
5. Để pin xuống thấp / máy nóng: app có hoãn việc nặng và báo đúng không?
6. (Tuỳ chọn) trên máy tính cùng mạng: `python3 scripts/tools/wppocket_cli.py status --check --max-staleness 15m` theo dõi tự động (`docs/CLI.md`).

## Cách báo lỗi

- **Cách nhanh nhất**: trong app mở **Nhật ký** → **Báo lỗi (mở form GitHub)**. Nút này chỉ mở trình duyệt tới form Issue **chỉ điền sẵn phiên bản app và mẫu máy** (không gửi nhật ký, IP, token; app không tự gửi gì). Bạn tự dán nhật ký **đã che** rồi bấm gửi. Bản build thủ công không biết kho mã nguồn nên nút báo "chưa biết kho".
- Dùng mẫu **"Báo cáo bản thử nghiệm"** (`.github/ISSUE_TEMPLATE/beta-report.yml`) nếu chủ dự án dùng GitHub Issues. **Kênh báo cáo do chủ dự án chọn** (GitHub Issues, Telegram, email…) — chưa quyết; khi chọn xong hãy ghi vào đây.
- Ghi rõ: **phiên bản app**, **mẫu điện thoại + bản Android**, **runtime** (WordPress/PHP/Node/Python), **chế độ** (Lite/Full), **các bước** tái hiện, **điều xảy ra** và **điều mong đợi**.
- Ưu tiên cao nhất: **mất dữ liệu**, app **sập/treo**, **không khởi động lại** sau sự cố. Sau đó: cảnh báo sai/thiếu, chậm, giao diện.

## Che thông tin nhạy cảm TRƯỚC khi gửi

Nhật ký và ảnh chụp màn hình có thể chứa: **Bot Token Telegram**, **Chat ID**, **URL tunnel**, **địa chỉ IP** (của bạn và khách), **mật khẩu `_admin/`**, tên miền. Thay bằng `***`. **Tuyệt đối không gửi**: `admin-password.txt`, `wp-config.php`, file backup chưa mã hoá, token API trạng thái. Chỉ gửi đoạn nhật ký cần thiết (vài chục dòng quanh lúc lỗi).

## Quyền riêng tư

App **không gửi dữ liệu nào** về chủ dự án (xem `PRIVACY.md`). Chỉ những gì **bạn tự gửi** trong báo cáo mới đến tay chủ dự án.

## Khi nào kết thúc

Chủ dự án sẽ thông báo. **Chưa quyết:** giá, đối tượng tính phí, và việc bản thử nghiệm đã tải có tiếp tục miễn phí hay không (`TERMS.md` điều 7). Cho đến khi quyết, **đừng coi miễn phí là vĩnh viễn**.
