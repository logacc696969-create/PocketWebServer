# Đối chiếu từng mục của hai PDF với code

> Sinh tự động bởi `scripts/tools/pdf_traceability.py --write`; **không sửa tay**. Mỗi dòng **Đã làm / Làm một phần** có bằng chứng (tệp + ký hiệu) mà công cụ kiểm tra là có thật trong repo; test `pdf-traceability-test.py` chạy kiểm tra này ở CI. Hai PDF là phân tích của một AI khác (DeepSeek) về dự án — chúng có thể sai hoặc lỗi thời, nên "mục trong PDF" không đồng nghĩa "việc nên làm".

> **"Đã làm" nghĩa là có mã/tài liệu và bằng chứng trong repo — KHÔNG có nghĩa đã chạy thử trên điện thoại thật.** Phần Kotlin/XML/Gradle của các vòng 1bo–1bp chưa từng được biên dịch (xem `HANDOFF.md`), và CI chưa chạy thật trên bản này.

## PDF 1 — Phân tích tính năng còn thiếu (86 mục)

| Trạng thái | Số mục |
|---|---|
| Đã làm | 79 |
| Làm một phần | 4 |
| Cố ý không làm (có lý do) | 2 |
| Chưa làm | 0 |
| Chờ chủ dự án | 0 |
| Không phải kỹ thuật cần áp dụng | 1 |

| Mã | Mục trong PDF | Trạng thái | Ghi chú / bằng chứng |
|---|---|---|---|
| A1 | Retention policy cho backup (rotation + GFS) | Đã làm | giữ 5 bản gộp mọi nơi lưu — `BackupManager.kt`; `BackupDirLogic.kt` |
| A2 | Verify backup sau khi tạo | Đã làm | kiểm zip + dump ngay sau khi tạo; kiểm định kỳ — `BackupManager.kt`; `BackupVerifier.kt` |
| A3 | Uptime monitoring + alerting (khác HealthCheckWorker) | Đã làm | health check 15 phút + heartbeat ngoài — `HealthCheckWorker.kt`; `Prefs.kt` |
| A4 | Dashboard metrics theo thời gian (không chỉ snapshot) | Đã làm | trang metrics theo thời gian — `admin-metrics.php` |
| A5 | Traffic analytics nhẹ (thay vì chỉ access log thô) | Đã làm | phân tích truy cập nhẹ — `admin-analytics.php` |
| A6 | Rate limiting + chống brute-force login _admin/ | Đã làm | 5 lần sai → khoá IP 15 phút — `admin-auth.php` |
| A7 | 2FA (TOTP) cho _admin/ | Đã làm | TOTP 2FA — `admin-totp-lib.php`; `admin-2fa.php` |
| A8 | Maintenance mode 1 nút | Đã làm | chế độ bảo trì — `admin-maintenance.php` |
| A9 | WP-CLI bundled | Đã làm | WP-CLI qua _admin — `admin-wpcli.php` |
| A10 | Clone / staging site | Đã làm | staging/clone — `admin-staging.php` |
| B1 | Battery-aware scheduling | Đã làm | nhận biết đang sạc/pin — `MonitorLogic.kt` |
| B2 | Thermal awareness | Đã làm | ngưỡng nhiệt 45 °C — `MonitorLogic.kt` |
| B3 | Network-aware behavior (WiFi vs 4G) | Đã làm | NetworkCallback đổi mạng — `ServerForegroundService.kt` |
| B4 | Disk-full prevention | Đã làm | cảnh báo đĩa (mặc định ≥ 85%, chỉnh được ở "Ngưỡng và quy tắc cảnh báo…") — `AlertThresholds.kt`; `Monitoring.kt` |
| B5 | Graceful degradation khi RAM thấp | Đã làm | onTrimMemory — `ServerForegroundService.kt` |
| B6 | Charging + screen-off = "golden time" cho tác vụ nặng | Đã làm | backup định kỳ tránh lúc máy nóng/RAM thấp (HEAT_MAX_BACKUP_DEFERRALS) VÀ có tuỳ chọn "chỉ khi đang sạc" (WorkManager setRequiresCharging, công tắc trong app); MẶC ĐỊNH TẮT có lý do (máy không bao giờ cắm sạc thì bật cờ này nghĩa là KHÔNG BAO GIỜ backup tự động) [ĐÍNH CHÍNH 1br: bảng cũ ghi "chưa ép chỉ khi đang sạc" nhưng tuỳ chọn đã có trong code] — `MonitorLogic.kt`; `BackupWorker.kt`; `Prefs.kt` |
| B7 | Data usage budget cho 4G | Đã làm | theo dõi dữ liệu di động — `Prefs.kt` |
| F1 | Log rotation (khác với buffer= / flush= đã làm) | Đã làm | xoay vòng log — `ServerForegroundService.kt` |
| F2 | WP-Cron thật (không phải WP-Cron giả lập) | Đã làm | wp-cron thật — `start-lamp.sh` |
| F3 | Database maintenance định kỳ | Đã làm | tối ưu CSDL định kỳ — `Monitoring.kt` |
| F4 | Cache warming sau restart | Đã làm | làm ấm cache sau khởi động — `start-lamp.sh` |
| F5 | Search-replace URL khi tunnel URL đổi | Đã làm | tự cập nhật siteurl/home WordPress khi URL Quick Tunnel đổi — `ServerForegroundService.kt` |
| F6 | Backup encryption trước khi upload | Đã làm | mã hoá backup AES-GCM + PBKDF2 — `BackupManager.kt` |
| F7 | Kiểm tra dung lượng trống TRƯỚC khi backup | Đã làm | kiểm dung lượng trước backup — `BackupManager.kt` |
| G1 | Hardening wp-config.php cơ bản | Đã làm | DISALLOW_FILE_EDIT… — `site_source.sh` |
| G2 | Block XML-RPC + wp-login brute-force ở nginx | Đã làm | chặn xmlrpc + limit_req — `nginx.conf.template`; `nginx.conf.template` |
| G3 | Security headers | Đã làm | header bảo mật — `nginx.conf.template` |
| G4 | Audit log cho _admin/ | Đã làm | nhật ký kiểm toán — `admin-auth.php` |
| G5 | Session timeout + CSRF token cho _admin/ | Đã làm | hết phiên 30 phút + CSRF — `admin-auth.php`; `admin-auth.php` |
| G6 | robots.txt cho URL tunnel | Đã làm | robots.txt cho URL tunnel — `ServerForegroundService.kt` |
| G7 | Che Bot Token / webhook URL trong log | Đã làm | che token/URL trong log — `TelegramNotifier.kt` |
| H1 | npm install / pip install lúc runtime | Làm một phần | cài npm/pip/composer lúc BUILD (CI), không cài lúc chạy trên điện thoại (không có npm/pip trên máy) — `site_deps.sh` |
| H2 | WSGI/ASGI server cho Python | Đã làm | máy chủ WSGI + ASGI đi kèm (wpp_wsgi.py, chỉ stdlib) thay gunicorn và uvicorn: WSGI đa luồng có giới hạn, thời hạn kết nối, giới hạn body, dừng sạch, tin X-Forwarded-* chỉ khi có nginx; ASGI qua AsgiBridge (HTTP + lifespan, phản hồi gom đủ rồi gửi, KHÔNG WebSocket/SSE); khai báo "wsgi" hoặc "asgi". Giới hạn nói rõ trong docs/PYTHON_WSGI.md (FastAPI cần pydantic-core native — không chạy được trên Android; chưa thử Starlette/FastAPI thật) — `wpp_wsgi.py`; `python.sh`; `wpp_wsgi.py`; `asgi-server-test.py`; `PYTHON_WSGI.md` |
| H3 | WebSocket support trong nginx | Đã làm | WebSocket qua proxy — `front-locations-proxy.conf.template` |
| H4 | Reverse proxy tới service khác trên LAN | Đã làm | reverse proxy front_proxy — `nginx-front.conf.template` |
| H5 | Composer cho PHP (nếu không phải WordPress) | Đã làm | composer cho PHP — `php.sh` |
| I1 | gzip/brotli cho nginx | Đã làm | gzip — `nginx.conf.template` |
| I2 | Static file caching headers | Đã làm | header cache tệp tĩnh — `nginx.conf.template` |
| I3 | HTTP/2 giữa nginx        ↔ cloudflared | Cố ý không làm (có lý do) | nginx↔cloudflared dùng HTTP/1.1: lợi ích không đo được ở loopback, bỏ — `HANDOFF.md` |
| I4 | APCu cho PHP | Đã làm | APCu + object cache — `object-cache.php` |
| I5 | OPcache preload (khi fix được lock file) | Đã làm | opcache.file_cache — `php.ini.template` |
| I6 | PHP-FPM status page | Đã làm | trang php-fpm status — `nginx.conf.template` |
| J1 | Export full site (migrate sang máy khác) | Đã làm | xuất backup ra ngoài — `BackupManager.kt` |
| J2 | Import site từ hosting có sẵn | Đã làm | nhập backup từ file — `MainActivity.kt` |
| J3 | Export site ra hosting thật | Làm một phần | backup = www/ + database.sql chuẩn, dựng lại được trên hosting khác; chưa có bộ xuất tương thích plugin di chuyển — `DATA_AND_SECRETS.md` |
| J4 | Sample configs / templates | Đã làm | 9 preset — `apply_preset.py`; `wordpress.json` |
| J5 | Chọn phiên bản WordPress / PHP | Cố ý không làm (có lý do) | Termux chỉ cung cấp 1 bản PHP/WordPress mới nhất; muốn nhiều bản phải tự build (PDF cũng ghi 'để sau') — `HANDOFF.md` |
| K1 | Quick Settings Tile (Android 7+) | Đã làm | Quick Settings Tile — `QuickToggleTileService.kt` |
| K2 | Home screen Widget | Đã làm | widget màn hình chính — `WppocketWidgetProvider.kt` |
| K3 | Notification actions | Đã làm | nút trên thông báo — `ServerForegroundService.kt` |
| K4 | QR code share URL | Đã làm | mã QR tự viết (QrCode.kt, 40 phiên bản x 4 mức sửa lỗi) + hộp thoại chia sẻ; kiểm bằng bộ giải mã QR thật (OpenCV) và bộ giải mã ma trận độc lập — `QrCode.kt`; `QrDrawable.kt`; `MainActivity.kt`; `qr-code-test.py` |
| K5 | Onboarding wizard | Đã làm | hướng dẫn lần đầu — `MainActivity.kt` |
| K6 | i18n (tiếng Anh) | Đã làm | tiếng Anh — `strings.xml` |
| K7 | Deep link + share intent | Đã làm | deep link wppocket://open-admin (mở trực tiếp trang quản trị) và share intent ACTION_SEND text/plain (nhận chuỗi chia sẻ từ app khác, điền vào ô token tunnel); xử lý cả khi Activity đang mở (onNewIntent) [ĐÍNH CHÍNH 1br: bảng cũ ghi "deep link tuỳ chỉnh xem manifest" nhưng cả hai đã có] — `AndroidManifest.xml`; `AndroidManifest.xml`; `MainActivity.kt` |
| K8 | Crash log trong app | Đã làm | ghi crash log — `CrashLogger.kt` |
| L1 | Multi-ABI build | Đã làm | tách APK theo ABI — `build.gradle.kts` |
| L2 | Test automation trong CI | Đã làm | kiểm tra tự động trong CI — `build-apk.yml` |
| L3 | Build caching | Đã làm | cache build — `build-apk.yml` |
| L4 | APK size budget + alert | Đã làm | ngân sách dung lượng APK — `build-apk.yml` |
| L5 | Reproducible build | Đã làm | build tái lập được — `reproducible_zip.sh` |
| M1 | Load test | Đã làm | test tải — `loadtest.sh` |
| M2 | End-to-end test trên emulator | Đã làm | e2e trên emulator — `build-apk.yml` |
| M3 | Fuzz test cho _admin/ | Đã làm | fuzz ngẫu nhiên có seed (tái lập được) cho MỌI trang _admin đã đăng nhập: ~3000 yêu cầu ngẫu nhiên + quét có hệ thống ~11.600 yêu cầu (mọi trang × mọi tham số × mọi hành động × chuỗi độc hại: đường dẫn canary, '..' mã hoá, chèn lệnh shell, NUL, chuỗi 70KB); oracle: không 5xx/Fatal, không tạo file canary bằng chèn lệnh, không lộ file/mật khẩu, không tạo file ngoài thư mục cho phép; thử đột biến (chèn lỗ hổng cố ý) xác nhận oracle bắt được; ĐÃ TÌM VÀ SỬA 1 lỗi thật (byte NUL làm trang WP-CLI Fatal 500). Chưa chạy với WordPress/MariaDB thật — `admin-fuzz-test.py`; `admin-fuzz-test.py`; `admin-wpcli.php` |
| O1 | Upload size mismatch (3 chỗ phải khớp!) | Đã làm | 3 tầng upload khớp + hồ sơ PHP — `nginx.conf.template`; `php-tuning-test.py` |
| O2 | memory_limit + max_execution_time | Đã làm | memory_limit/max_execution_time — `php.ini.template` |
| O3 | FS_METHOD = 'direct' trong wp-config.php | Đã làm | FS_METHOD direct — `site_source.sh` |
| O4 | mysqldump --single-transaction cho InnoDB | Đã làm | mysqldump --single-transaction — `BackupManager.kt` |
| O5 | Character set / collation MariaDB vs MySQL | Đã làm | utf8mb4 — `start-lamp.sh` |
| O6 | Timezone 3 tầng lệch nhau | Đã làm | date.timezone — `php.ini.template` |
| O7 | Real client IP qua Cloudflare Tunnel | Đã làm | IP thật qua Cloudflare — `nginx.conf.template` |
| O8 | php-fpm slow log + nginx $request_time | Đã làm | slowlog + $request_time — `php-fpm.conf.template`; `nginx.conf.template` |
| O9 | Graceful shutdown — SIGTERM vs SIGKILL | Đã làm | dừng sạch có thời hạn — `start-lamp.sh` |
| O10 | Stale PID / socket file sau crash | Đã làm | dọn socket cũ sau khi bị kill đột ngột — `start-lamp.sh` |
| P1 | Version upgrade path (Termux bump version) | Làm một phần | ghim phiên bản + công cụ khoá Termux có; tệp khoá thật chưa sinh (cần mạng) — `termux_lock.py` |
| P2 | Emergency "safe mode" | Đã làm | chế độ an toàn plugin — `admin-safe-mode.php` |
| P3 | Rollback WordPress core sau update | Đã làm | hoàn tác lõi WordPress — `admin-core-rollback.php` |
| P4 | Đổi admin password | Đã làm | đổi mật khẩu quản trị — `MainActivity.kt` |
| Q1 | Privacy policy + cookie consent | Làm một phần | có PRIVACY.md; chưa gói sẵn plugin cookie consent (chỉ hướng dẫn) — `PRIVACY.md` |
| Q2 | DKIM/SPF/DMARC khi dùng SMTP ngoài | Đã làm | hướng dẫn DKIM/SPF — `README.md` |
| Q3 | Data retention policy | Đã làm | chính sách lưu giữ dữ liệu — `DATA_AND_SECRETS.md` |
| R1 | /favicon.ico — nếu không có, mỗi visitor mất 1 request 404. Không phải | Đã làm | favicon — `nginx.conf.template` |
| R2 | robots.txt đã nhắc (G6), nhưng còn sitemap.xml — WordPress tự sinh nếu | Đã làm | sitemap WordPress chạy qua nginx — `fullstack-realwp-test.py` |
| R3 | Block wp-config.php.bak , .git , .env — mặc dù nginx chỉ serve file .p | Đã làm | chặn .bak/.old — `nginx.conf.template` |
| R4 | X-Powered-By header — PHP mặc định gửi → lộ PHP version. expose_php =  | Đã làm | expose_php off — `php.ini.template` |
| R5 | ETag / Last-Modified — nginx mặc định có, nhưng có thể conflict với Wo | Không phải kỹ thuật cần áp dụng | nginx mặc định đủ dùng, PDF nói không cần sửa |
| R6 | IPv6 loopback — nếu nginx listen [::1] thay vì 127.0.0.1 , cloudflared | Đã làm | kiểm IPv6 loopback — `ipv6-test.py` |

## PDF 2 — Phân tích chất lượng tính phí (199 mục)

| Trạng thái | Số mục |
|---|---|
| Đã làm | 106 |
| Làm một phần | 34 |
| Cố ý không làm (có lý do) | 17 |
| Chưa làm | 0 |
| Chờ chủ dự án | 6 |
| Không phải kỹ thuật cần áp dụng | 36 |

| Mã | Mục trong PDF | Trạng thái | Ghi chú / bằng chứng |
|---|---|---|---|
| A1 | Không có Onboarding / First-run experience (backlog, ưu tiên | Đã làm | hướng dẫn lần đầu — `MainActivity.kt` |
| A2 | Không có Dark Mode / Material You (không có trong backlog) | Đã làm | theme DayNight theo hệ thống — `themes.xml` |
| A3 | Không có QR code chia sẻ URL (backlog) | Đã làm | mã QR chia sẻ URL (xem PDF1 K4) — không thêm thư viện, tự vẽ bằng Canvas — `QrCode.kt`; `QrDrawable.kt`; `MainActivity.kt` |
| A4 | Không có Widget / Quick Settings Tile (backlog) | Đã làm | Quick Settings Tile + widget — `QuickToggleTileService.kt`; `WppocketWidgetProvider.kt` |
| A5 | Không có Notification Actions (backlog) | Đã làm | nút trên thông báo — `ServerForegroundService.kt` |
| A6 | Log viewer còn thô (mục 7.0 đã có nhưng chưa polish) | Đã làm | trình xem log: lọc + chia sẻ — `LogViewerActivity.kt` |
| A7 | Dashboard web ( _admin/index.php ) chưa responsive tốt trên | Đã làm | trang quản trị có viewport cho di động — `admin-health.php` |
| A8 | Không có Progress indicator cho tác vụ dài | Đã làm | thanh tiến trình tác vụ dài (1bo-C) — `MainActivity.kt` |
| B1 | APCu chưa được wire vào (mục 10 — đã tra cứu nhưng chưa làm) | Đã làm | APCu nối vào object cache — `object-cache.php` |
| B2 | Chưa có Thermal-aware scheduling (backlog B2) | Đã làm | ngưỡng nhiệt — `MonitorLogic.kt` |
| B3 | Chưa có Network-aware behavior (backlog B3) | Đã làm | đổi mạng WiFi↔4G — `ServerForegroundService.kt` |
| B4 | Chưa có Data usage tracking | Đã làm | theo dõi dữ liệu di động — `Prefs.kt` |
| B5 | Chưa có Battery optimization cho MariaDB Auto-Sleep | Làm một phần | tham số MariaDB tiết kiệm RAM theo chế độ (Dual-Mode); chưa có hồ sơ riêng theo pin — `start-lamp.sh` |
| B6 | Chưa có Process priority tuning | Cố ý không làm (có lý do) | nice/ionice cho backup: HANDOFF ghi chưa kiểm chứng được hành vi kế thừa độ ưu tiên của WorkManager → không viết trên giả định — `HANDOFF.md` |
| C1 | Chưa có Export/Import site (backlog) | Đã làm | xuất/nhập site — `BackupManager.kt` |
| C2 | Chưa có WP-CLI bundled (backlog) | Đã làm | WP-CLI — `admin-wpcli.php` |
| C3 | Chưa có Staging/Clone site (backlog) | Đã làm | staging — `admin-staging.php` |
| C4 | Chưa có Update mechanism | Đã làm | kiểm tra bản cập nhật — `UpdateChecker.kt` |
| C5 | Chưa có Crash reporting | Đã làm | ghi crash log — `CrashLogger.kt` |
| C6 | Chưa có License/Activation (nếu thực sự bán) | Không phải kỹ thuật cần áp dụng | dự án không bán/không kích hoạt bản quyền |
| C7 | Chưa có Custom Domain support (đầy đủ) | Làm một phần | Named Tunnel + tên miền riêng có hướng dẫn; chưa có công cụ kiểm tra trạng thái tên miền — `README.md` |
| C8 | Chưa có Email deliverability wizard | Làm một phần | hướng dẫn DKIM/SPF trong README; chưa có trình hướng dẫn tương tác — `README.md` |
| C9 | Chưa có SEO tools / Site health | Đã làm | trang sức khoẻ site — `admin-health.php` |
| C10 | Chưa có Rate limiting nâng cao | Đã làm | giới hạn tốc độ toàn site (bật/tắt trong _admin/protect.php; mặc định TẮT có lý do: thiếu realip thì mọi khách chung 1 bộ đếm) + tự động chặn IP theo điểm (fail2ban-lite, leo thang 1 giờ→1 ngày→7 ngày) + phòng thủ tài khoản WordPress chống dò mật khẩu phân tán. Chuỗi tự chặn IP (nginx ghi log → guard chấm điểm → ban-list → HUP → 444, hủy chặn, không chặn oan) đã kiểm trên nginx 1.31.8 + php-fpm THẬT (security-nginx-test.py) và phòng thủ tài khoản trên WordPress 7.1.4 THẬT (wp-real-test.py); giới hạn tốc độ limit_req chưa đo dưới tải thật — `nginx.conf.template`; `security-guard.php`; `wppocket-shield-logic.php`; `security-nginx-test.py` |
| G1 | Chưa có Content Security Policy (CSP) | Đã làm | CSP — `nginx.conf.template` |
| G2 | Chưa có Session management / Device management | Đã làm | trang quản lý phiên — `admin-sessions.php` |
| G3 | Chưa có Password policy | Đã làm | chính sách mật khẩu — `PasswordPolicy.kt` |
| G4 | Chưa có Audit log đầy đủ (mới có login) | Đã làm | nhật ký kiểm toán — `admin-auth.php` |
| G5 | Chưa có Malware / Vulnerability scanning | Làm một phần | bộ quét mã độc/file lạ heuristic (security-scan.php): so checksum lõi WordPress với bản chính thức, PHP trong uploads/, ảnh chứa PHP (polyglot), file lạ ở thư mục gốc, mu-plugin/drop-in/wp-config đổi so với mốc, plugin/theme mới, dấu hiệu web-shell; cách ly/khôi phục được; quét sau khi khởi động rồi mỗi giờ + cảnh báo Telegram. Quét LỖ HỔNG ĐÃ BIẾT của plugin/theme/lõi (security-vuln.php, TÙY CHỌN mặc định TẮT vì gửi slug+phiên bản tới www.wpvulnerability.net): kiểm bằng máy chủ giả lập dữ liệu tự soạn theo cấu trúc API lấy từ mã nguồn plugin WPVulnerability — CHƯA gọi được dịch vụ thật ở môi trường này (proxy chặn). Bộ quét mã độc đã chạy trên WordPress 7.1.4 THẬT + 4 plugin lớn (0 báo nhầm sau khi sửa 1 lỗi báo nhầm tìm được); heuristic vẫn có thể báo nhầm/bỏ sót — `security-vuln.php`; `security-vuln-test.py`; `wp-real-test.py`; `security-scan.php`; `admin-security.php`; `start-lamp.sh`; `security-scan-test.py` |
| G6 | Chưa có GDPR / Cookie consent tools | Làm một phần | hướng dẫn GDPR/cookie trong tài liệu; chưa gói plugin — `PRIVACY.md` |
| G7 | Chưa có IP whitelist/blacklist nâng cao | Đã làm | luật IP cho _admin (có nút gỡ khẩn cấp) — `MainActivity.kt` |
| H1 | Chưa có Backup verification (test restore tự động) | Đã làm | verify zip + dump, kiểm định kỳ — `BackupVerifier.kt` |
| H2 | Chưa có Backup retention policy | Đã làm | giữ 5 bản — `BackupManager.kt` |
| H3 | Chưa có Backup encryption | Đã làm | mã hoá AES-GCM — `BackupManager.kt` |
| H4 | Chưa có Health score / Uptime tracking | Đã làm | trang Sức khoẻ site có "điểm sức khoẻ" gộp 0–100 (mục đỏ trừ 20, cảnh báo trừ 6) + dòng kết quả quét mã độc + cảnh báo thiếu realip; thêm health check/uptime sẵn có — `admin-health.php`; `HealthCheckWorker.kt` |
| H5 | Chưa có Alerting thresholds có thể cấu hình | Đã làm | 4 ngưỡng (bộ nhớ đầy, pin cạn, pin ấm, pin quá nóng) chỉnh được trong hộp thoại "Ngưỡng và quy tắc cảnh báo…"; luôn bị kẹp vào khoảng hợp lý, quá nóng > ấm; mặc định giữ nguyên 85%/5%/40 °C/45 °C — `AlertThresholds.kt`; `Monitoring.kt`; `MainActivity.kt` |
| H6 | Chưa có Error tracking (Sentry-like) | Đã làm | theo dõi lỗi PHP nghiêm trọng (1bp-C) — `FatalLogLogic.kt` |
| H7 | Chưa có Log analysis tự động | Đã làm | phân tích truy cập tự động — `admin-analytics.php` |
| I1 | Chưa có PHP version switcher | Cố ý không làm (có lý do) | Termux chỉ có một bản PHP — `HANDOFF.md` |
| I2 | Chưa có Plugin/Theme management từ app | Làm một phần | quản lý plugin qua WP-CLI trong _admin; chưa có màn hình trong app — `admin-wpcli.php` |
| I3 | Chưa có Database optimization | Đã làm | tối ưu CSDL định kỳ — `Monitoring.kt` |
| I4 | Chưa có Image optimization | Làm một phần | mu-plugin wppocket-images (2 tệp, loader + logic nạp qua try/catch Throwable): giới hạn ảnh hiển thị 1920px, chất lượng nén, kích thước phụ WebP cho ảnh JPEG mới, tuỳ chọn xoá ảnh gốc (mặc định TẮT); kiểm bằng phân tích văn bản — CHƯA chạy PHP/WordPress thật (không có PHP ở đây), chưa đo mức tiết kiệm, chưa có chuyển đổi hàng loạt ảnh cũ — `wppocket-images-optimize.php`; `wppocket-images-loader.php`; `IMAGE_OPTIMIZATION.md` |
| I5 | Chưa có Child theme generator | Làm một phần | tạo child theme qua WP-CLI nếu có trong danh sách lệnh — `admin-wpcli.php` |
| I6 | Chưa có Page cache (nginx fastcgi_cache) | Đã làm | page cache — `wppocket-pagecache-loader.php` |
| I7 | Chưa có Search-replace tool | Đã làm | search-replace — `admin-wpcli.php` |
| I8 | Chưa có Scheduled posts verification | Đã làm | wp-cron thật → bài hẹn giờ đăng — `start-lamp.sh` |
| J1 | Chưa có Haptic feedback | Đã làm | rung nhẹ khi bấm Bật/Tắt server và Backup (tôn trọng cài đặt rung của hệ thống) [ĐÍNH CHÍNH 1bq: bảng cũ ghi "Chưa làm" nhưng code đã có từ trước] — `MainActivity.kt` |
| J2 | Chưa có Pull-to-refresh | Cố ý không làm (có lý do) | trạng thái đã tự làm mới mỗi giây (1bp-J) — `MainActivity.kt` |
| J3 | Chưa có Empty states / Error states đẹp | Làm một phần | có chuỗi trạng thái trống cho vài màn hình; chưa rà đủ mọi màn — `strings.xml` |
| J4 | Chưa có Skeleton loading | Làm một phần | skeleton loading ở chỗ chờ thật duy nhất: dòng địa chỉ công khai nhấp nháy độ trong khi hầm Cloudflare đang được tạo; tôn trọng cài đặt xoá hoạt ảnh của hệ thống; không thêm view mới. CHƯA nhìn trên máy; màn hình khác đọc trạng thái tức thời nên không có trạng thái tải — `SkeletonLogic.kt`; `MainActivity.kt` |
| J5 | Chưa có Bottom navigation | Cố ý không làm (có lý do) | màn hình chính là 1 cuộn dọc, không có điều hướng đa màn (HANDOFF 1bc) — `HANDOFF.md` |
| J6 | Chưa có Floating Action Button cho action chính | Làm một phần | không có FAB; nút Bật bị khoá khi server chạy (1bp-K), nút Tắt luôn bật — `MainActivity.kt` |
| J7 | Chưa có Animation/transition | Cố ý không làm (có lý do) | hiệu ứng chuyển cảnh cần nhìn trên máy (HANDOFF 1bc) — `HANDOFF.md` |
| J8 | Chưa có Accessibility | Làm một phần | rà trợ năng bằng a11y_audit.py (8 quy tắc, tự kiểm 8/8, layout sạch): sửa 2 nút có vùng chạm < 48dp, ô số phút Auto-Sleep thiếu nhãn, trạng thái server thiếu live region; hộp thoại tạo bằng mã có contentDescription. CHƯA thử TalkBack thật, chưa kiểm cỡ chữ 200%, chưa đo tương phản màu — `a11y_audit.py`; `activity_main.xml`; `ACCESSIBILITY.md` |
| J9 | Chưa có i18n đầy đủ | Đã làm | tiếng Anh đầy đủ (kiểm tương đương khoá) — `i18n-parity-test.py` |
| K1 | Chưa có In-app help / FAQ | Đã làm | trợ giúp trong app — `strings.xml` |
| K2 | Chưa có Video tutorials | Làm một phần | kịch bản 3 video (cài đặt, sao lưu/khôi phục, cảnh báo/theo dõi) với cảnh quay + lời thoại + phụ đề; mọi nhãn nút trích dẫn được test đối chiếu với strings.xml thật. CHƯA quay video, chưa dịch tiếng Anh — `VIDEO_TUTORIAL_SCRIPT.md`; `extending-docs-test.py` |
| K3 | Chưa có Community / Support channel | Chờ chủ dự án | kênh hỗ trợ/cộng đồng do chủ dự án lập — đã chuẩn bị quy trình + mẫu báo cáo beta (docs/BETA_PROGRAM.md, .github/ISSUE_TEMPLATE/beta-report.yml); chủ dự án chọn kênh |
| K4 | Chưa có Changelog trong app | Đã làm | Có gì mới trong app — `strings.xml` |
| K5 | Chưa có "Report a bug" tích hợp | Đã làm | nút "Báo lỗi (mở form GitHub)" ở màn hình Nhật ký: mở form Issue điền sẵn CHỈ phiên bản app + mẫu máy (không nhật ký/IP/token; app không tự gửi gì); kho lấy từ assets/update-repo.txt do CI ghi (cùng nguồn kiểm tra cập nhật) nên không cần chủ dự án quyết URL; build tay → báo rõ "chưa biết kho". Chia sẻ log/crash log vẫn giữ — `IssueLink.kt`; `LogViewerActivity.kt`; `issue-link-test.py` |
| L1 | Chưa có Unit tests | Đã làm | unit test — `BackupLogicTest.kt` |
| L2 | Chưa có Integration tests cho bash/PHP | Đã làm | test tích hợp bash/PHP — `admin-security-test.py` |
| L3 | Chưa có Static analysis | Làm một phần | lex-check, android-ref-check, kotlin-typecheck, nginx-lint, php -l; chưa có detekt/ktlint — `lex-check.py` |
| L4 | Chưa có Dependency scanning | Đã làm | Dependabot — `dependabot.yml` |
| L5 | Chưa có SBOM | Đã làm | SBOM — `make_sbom.py` |
| L6 | Chưa có Code coverage | Làm một phần | workflow đo độ phủ JaCoCo chạy thủ công; CHƯA chạy lần nào (1bp-J) — `coverage.yml` |
| L7 | Chưa có Multi-ABI build đầy đủ | Đã làm | tách APK theo ABI — `build.gradle.kts` |
| L8 | Chưa có CI test trên nhiều Android version | Đã làm | ma trận emulator API 26 và 29 — `build-apk.yml`; `build-apk.yml` |
| P1 | Chưa có kênh phân phối rõ ràng | Làm một phần | phát hành qua GitHub Release có checksum/SBOM; chưa có kênh khác — `build-apk.yml` |
| P2 | Chưa có Pricing strategy | Chờ chủ dự án | chiến lược giá do chủ dự án quyết — định hướng: miễn phí giai đoạn thử nghiệm, xem xét tính phí sau; giá/đối tượng/hình thức chưa quyết |
| P3 | Chưa có License server (nếu subscription) | Không phải kỹ thuật cần áp dụng | không bán thuê bao |
| P4 | Chưa có Analytics / Telemetry | Cố ý không làm (có lý do) | cố ý KHÔNG có telemetry/analytics (quyền riêng tư) — `PRIVACY.md` |
| P5 | Chưa có Feedback loop | Chờ chủ dự án | vòng phản hồi người dùng do chủ dự án tổ chức — đã chuẩn bị chương trình thử nghiệm (docs/BETA_PROGRAM.md); chủ dự án vận hành |
| P6 | Chưa có Marketing assets | Không phải kỹ thuật cần áp dụng | tài liệu tiếp thị, ngoài phạm vi mã |
| Q1 | Chưa xử lý OEM battery killers | Đã làm | hướng dẫn theo hãng điện thoại — `OemBattery.kt` |
| Q2 | Chưa xử lý Doze mode sâu | Đã làm | xin loại khỏi tối ưu pin — `AndroidManifest.xml` |
| Q3 | Chưa xử lý App Standby Buckets | Đã làm | App Standby Bucket — `MonitorLogic.kt` |
| Q4 | Chưa xử lý Data Saver | Đã làm | Data Saver — `MonitorLogic.kt` |
| Q5 | Chưa xử lý VPN conflicts | Đã làm | VPN — `MonitorLogic.kt` |
| Q6 | Chưa xử lý Network handoff | Đã làm | đổi mạng — `ServerForegroundService.kt` |
| Q7 | Chưa xử lý Roaming | Đã làm | chuyển vùng — `MonitorLogic.kt` |
| Q8 | Chưa xử lý Split-screen / Multi-window | Cố ý không làm (có lý do) | không đặt resizeableActivity=false (tài liệu Android khuyên không) — `HANDOFF.md` |
| Q9 | Chưa xử lý Foldable | Làm một phần | lề ngang màn hình chính tăng theo bề rộng (values-w600dp/w840dp/w1200dp) để nội dung không kéo giãn quá rộng trên máy tính bảng/máy gập; chưa có bố cục hai cột [ĐÍNH CHÍNH 1bq: bảng cũ ghi "Chưa làm"] — `dimens.xml`; `dimens.xml` |
| Q10 | Chưa xử lý Android TV / DeX | Không phải kỹ thuật cần áp dụng | Android TV/DeX ngoài đối tượng dùng |
| Q11 | Chưa xử lý Storage expansion (SD card) | Làm một phần | tuỳ chọn lưu backup lên thẻ nhớ (1bp-K); CSDL/website không chuyển — `BackupDirLogic.kt` |
| Q12 | Chưa xử lý Low storage | Đã làm | cảnh báo đầy bộ nhớ — `AlertThresholds.kt`; `Monitoring.kt` |
| Q13 | Chưa xử lý RAM pressure / LMK | Đã làm | onTrimMemory — `ServerForegroundService.kt` |
| Q14 | Chưa xử lý Thermal throttling | Đã làm | nhiệt — `MonitorLogic.kt` |
| R1 | Chưa xử lý mất điện đột ngột | Làm một phần | mất điện: dọn socket cũ + MariaDB tự phục hồi InnoDB; không có cách chống mất điện thật — `start-lamp.sh` |
| R2 | Chưa xử lý app bị Force-stop | Làm một phần | force-stop: Android dừng mọi tác vụ nền đến khi mở lại app — không có cách phía app; có hướng dẫn — `FAILURE_MODES.md` |
| R3 | Chưa xử lý mất kết nối Cloudflare | Làm một phần | đổi mạng khởi động lại tunnel; cảnh báo tắt cần heartbeat ngoài — `ServerForegroundService.kt` |
| R4 | Chưa xử lý phone bị mất/trộm | Làm một phần | mất máy: bí mật mã hoá Keystore, backup ngoài máy, hướng dẫn DR; không có xoá từ xa (dùng Find My Device của hệ điều hành) — `DISASTER_RECOVERY.md` |
| R5 | Chưa xử lý chuyển máy | Đã làm | chuyển máy: xuất/nhập + quy trình — `DISASTER_RECOVERY.md` |
| R6 | Chưa xử lý SIM change | Không phải kỹ thuật cần áp dụng | đổi SIM không ảnh hưởng server (Cloudflare Tunnel không phụ thuộc IP) |
| R7 | Chưa xử lý Timezone change | Làm một phần | PHP/MariaDB dùng múi giờ cố định Asia/Ho_Chi_Minh — `php.ini.template` |
| R8 | Chưa xử lý DST (Daylight Saving Time) | Không phải kỹ thuật cần áp dụng | Việt Nam không có giờ mùa hè |
| R9 | Chưa xử lý Leap second | Không phải kỹ thuật cần áp dụng | giây nhuận: hệ điều hành xử lý |
| R10 | Chưa xử lý Year 2038 problem | Không phải kỹ thuật cần áp dụng | Android 64-bit; không có tính năng nào dùng time_t 32-bit |
| R11 | Chưa xử lý SSL cert expiry (nếu self-signed) | Không phải kỹ thuật cần áp dụng | chứng chỉ do Cloudflare cấp/gia hạn |
| R12 | Chưa xử lý Database corruption | Đã làm | kiểm tra toàn vẹn CSDL (1bp-D) — `DbCheckLogic.kt` |
| R13 | Chưa xử lý File corruption trong www/ | Làm một phần | phát hiện file lõi WordPress bị sửa/thiếu/lạ bằng checksum chính thức (không cần WP-CLI) + điểm bám trụ đổi so với mốc; chưa có checksum chính thức cho file plugin/theme (chỉ heuristic + quét lỗ hổng đã biết tùy chọn); đã kiểm trên WordPress 7.1.4 thật với checksum tự lập từ chính mã nguồn đó (chưa tải được checksum thật từ wordpress.org vì proxy chặn) — `security-scan.php`; `security-scan.php` |
| R14 | Chưa xử lý Plugin conflict | Đã làm | chế độ an toàn plugin — `admin-safe-mode.php` |
| R15 | Chưa xử lý Memory limit exceeded | Đã làm | hồ sơ PHP + cảnh báo hết bộ nhớ — `PhpTuning.kt` |
| R16 | Chưa xử lý Max execution time | Đã làm | hồ sơ PHP (max_execution_time + fastcgi_read_timeout) — `start-lamp.sh` |
| R17 | Chưa xử lý Upload size limit | Đã làm | ba tầng upload khớp — `nginx.conf.template` |
| R18 | Chưa xử lý Concurrent users | Đã làm | test tải + pm.max_children — `php-fpm.conf.template` |
| R19 | Chưa xử lý DDoS nhẹ | Đã làm | giới hạn tốc độ toàn site tuỳ chọn + tự động chặn IP quét/dò (cloud IP quét hàng loạt) + chặn crawler AI tuỳ chọn + Cloudflare phía trước; chuỗi chặn IP đã kiểm trên nginx 1.31.8 thật; không thay được DDoS mức mạng (cần Cloudflare); limit_conn không làm (qua Cloudflare mọi kết nối đến từ vài IP nên không chỉnh được nếu không có lưu lượng thật) — `nginx.conf.template`; `nginx.conf.template`; `security-guard.php` |
| R20 | Chưa xử lý Bot traffic | Đã làm | chặn User-Agent xấu (block-bots-on) + chặn crawler AI GPTBot/ClaudeBot/CCBot… (block-ai-on) + tự chấm điểm UA công cụ quét + giới hạn tốc độ; giả User-Agent vẫn qua được (đây là lớp giảm tải, không phải tường lửa) — `nginx.conf.template`; `nginx.conf.template`; `security-guard.php` |
| S1 | Chưa dùng Rust cho phần native | Cố ý không làm (có lý do) | viết lại phần native bằng Rust: không có lý do |
| S2 | Chưa dùng Kotlin Coroutines đầy đủ | Cố ý không làm (có lý do) | coroutines: tái cấu trúc không đem lợi ích người dùng (1bp-K) — `HANDOFF.md` |
| S3 | Chưa dùng Jetpack Compose | Cố ý không làm (có lý do) | Jetpack Compose: phải viết lại toàn bộ giao diện View, rủi ro lớn |
| S4 | Chưa dùng Room cho local DB | Không phải kỹ thuật cần áp dụng | không có CSDL cục bộ cần Room |
| S5 | Chưa dùng DataStore thay SharedPreferences | Cố ý không làm (có lý do) | DataStore: SharedPreferences không bị loại bỏ; đổi sang bất đồng bộ phá mã đọc đồng bộ (1bp-K) — `HANDOFF.md` |
| S6 | Chưa dùng Hilt/Koin cho DI | Không phải kỹ thuật cần áp dụng | ứng dụng nhỏ, không cần DI |
| S7 | Chưa dùng Paging 3 | Không phải kỹ thuật cần áp dụng | không có danh sách phân trang |
| S8 | Chưa dùng Baseline Profiles | Đã làm | baseline profile + profileinstaller (1bp-K) — `baseline-prof.txt` |
| S9 | Chưa dùng App Bundle | Cố ý không làm (có lý do) | đã có APK theo ABI; AAB/Play không phải kênh phân phối — `build.gradle.kts` |
| S10 | Chưa dùng R8 full mode | Cố ý không làm (có lý do) | APK ~94 MB do thư viện native; R8 chỉ thu nhỏ phần dex rất nhỏ (1bp-K) — `HANDOFF.md` |
| S11 | Chưa dùng StrictMode | Đã làm | StrictMode — `MainActivity.kt` |
| S12 | Chưa dùng Macrobenchmark | Cố ý không làm (có lý do) | cần đo trên thiết bị; chưa có báo cáo khởi động chậm — `HANDOFF.md` |
| S13 | Chưa dùng Perfetto / Systrace | Không phải kỹ thuật cần áp dụng | công cụ đo, không phải tính năng |
| T1 | Chưa có REST API | Đã làm | API trạng thái chỉ đọc cho LAN (1bp-L) — `ApiLogic.kt` |
| T2 | Chưa có Webhook out (khi có event) | Đã làm | webhook ra khi có sự kiện — `AlertWebhook.kt` |
| T3 | Chưa có Zapier/IFTTT integration | Không phải kỹ thuật cần áp dụng | webhook ra đã đủ để nối Zapier/IFTTT |
| T4 | Chưa có CLI tool | Đã làm | wppocket_cli.py: status/watch/config, --check kiểu Nagios (mã thoát 0/1/2/3), chỉ stdlib; gọi API trạng thái chỉ đọc T1 (không điều khiển được server vì API chỉ đọc); từ chối gửi token tới máy ngoài mạng nội bộ, không theo chuyển hướng, không qua proxy — `wppocket_cli.py`; `wppocket-cli-test.py`; `CLI.md` |
| T5 | Chưa có Terraform provider | Không phải kỹ thuật cần áp dụng | không áp dụng |
| T6 | Chưa có SSO / LDAP | Không phải kỹ thuật cần áp dụng | không áp dụng (một người dùng) |
| T7 | Chưa có Multi-user với role | Không phải kỹ thuật cần áp dụng | một quản trị viên |
| T8 | Chưa có White-label | Không phải kỹ thuật cần áp dụng | không áp dụng |
| U1 | "Server bỏ túi" là niche độc đáo | Không phải kỹ thuật cần áp dụng | nhận định thị trường/người dùng, không phải kỹ thuật cần áp dụng |
| U2 | Điện thoại cũ là thị trường ngách | Không phải kỹ thuật cần áp dụng | nhận định thị trường/người dùng, không phải kỹ thuật cần áp dụng |
| U3 | Pin là bottleneck lớn nhất | Không phải kỹ thuật cần áp dụng | nhận định thị trường/người dùng, không phải kỹ thuật cần áp dụng |
| U4 | Nhiệt độ là bottleneck thứ 2 | Không phải kỹ thuật cần áp dụng | nhận định thị trường/người dùng, không phải kỹ thuật cần áp dụng |
| U5 | Mạng di động VN có đặc thù | Không phải kỹ thuật cần áp dụng | nhận định thị trường/người dùng, không phải kỹ thuật cần áp dụng |
| U6 | Người dùng VN thường dùng điện thoại Android giá rẻ | Không phải kỹ thuật cần áp dụng | nhận định thị trường/người dùng, không phải kỹ thuật cần áp dụng |
| U7 | Người dùng VN thường không rành kỹ thuật | Không phải kỹ thuật cần áp dụng | nhận định thị trường/người dùng, không phải kỹ thuật cần áp dụng |
| V1 | Đã có (80%) | Không phải kỹ thuật cần áp dụng | bảng tổng hợp ưu tiên của PDF; các mục bên trong được đối chiếu riêng |
| V2 | Thiếu nghiêm trọng (phải làm ngay) | Không phải kỹ thuật cần áp dụng | bảng tổng hợp ưu tiên của PDF; các mục bên trong được đối chiếu riêng |
| V3 | Thiếu quan trọng (nên làm sớm) | Không phải kỹ thuật cần áp dụng | bảng tổng hợp ưu tiên của PDF; các mục bên trong được đối chiếu riêng |
| V4 | Nice to have (làm sau) | Không phải kỹ thuật cần áp dụng | bảng tổng hợp ưu tiên của PDF; các mục bên trong được đối chiếu riêng |
| V5 | Không nên làm | Không phải kỹ thuật cần áp dụng | bảng tổng hợp ưu tiên của PDF; các mục bên trong được đối chiếu riêng |
| Y1 | Chưa có Privacy Policy | Đã làm | chính sách riêng tư — `PRIVACY.md` |
| Y2 | Chưa có Terms of Service | Làm một phần | điều khoản dùng — bản NHÁP, chưa qua luật sư — `TERMS.md` |
| Y3 | Chưa tuân thủ Nghị định 13/2023/NĐ-CP (VN) | Làm một phần | đã tra cứu và ghi chú (KHÔNG phải tư vấn pháp lý): PDF nêu Nghị định 13/2023 nhưng đã bị THAY THẾ từ 01/01/2026 bởi Luật BVDLCN 91/2025/QH15 + Nghị định 356/2025/NĐ-CP; đối chiếu dữ liệu app xử lý với mã; danh sách câu hỏi cho luật sư. CẦN luật sư xác nhận nghĩa vụ cụ thể — `LEGAL_NOTES_VN.md`; `legal-docs-test.py` |
| Y4 | Chưa tuân thủ GDPR (nếu có user EU) | Làm một phần | PRIVACY.md/README nhắc GDPR; chưa có công cụ đồng ý cookie gói sẵn — `PRIVACY.md` |
| Y5 | Chưa có Open Source License rõ ràng | Chờ chủ dự án | chưa có LICENSE — chủ dự án phải chọn. Đã có định hướng (27/10/2026): phát hành miễn phí cho người kiểm thử trước, tính phí sau → giữ "bảo lưu mọi quyền" + giấy phép dùng thử (TERMS điều 7, bản nháp) là hướng giữ mở mọi lựa chọn; chưa chọn license, tên chủ bản quyền, năm |
| Y6 | Chưa có Attribution cho third-party | Đã làm | ghi nhận bên thứ ba — `THIRD_PARTY_NOTICES.md` |
| Y7 | Chưa có Export compliance | Làm một phần | đã ghi chú (KHÔNG phải tư vấn pháp lý): mật mã app dùng đối chiếu với mã (chỉ AES-256-GCM + PBKDF2 + Keystore); EAR — các nguồn mâu thuẫn về thủ tục thông báo nên ghi cả hai, không tự chọn; Việt Nam — Nghị định 341/2026/NĐ-CP (mật mã dân sự) mới hơn PDF, còn câu hỏi mở về Phụ lục I/II. CẦN luật sư — `LEGAL_NOTES_VN.md`; `LEGAL_NOTES_VN.md` |
| Z1 | Chưa verify binary tải từ Termux | Làm một phần | manifest + công cụ khoá bản Termux; tệp khoá thật cần mạng để sinh — `termux_lock.py` |
| Z2 | Chưa verify Adminer/Tiny File Manager | Đã làm | ghim + kiểm băm Adminer/TFM — `pins.env` |
| Z3 | Chưa verify cloudflared | Đã làm | kiểm SHA-256 cloudflared theo ghi chú phát hành — `prepare_cloudflared.sh` |
| Z4 | Chưa pin dependency versions trong Gradle | Làm một phần | đã bật khoá phụ thuộc Gradle; tệp .lockfile chưa sinh (cần mạng) — `build.gradle.kts` |
| Z5 | Chưa có reproducible builds | Đã làm | build tái lập — `reproducible_zip.sh` |
| Z6 | Chưa có dependency vulnerability scanning | Đã làm | Dependabot — `dependabot.yml` |
| Z7 | Chưa có security update mechanism | Đã làm | cơ chế cập nhật — `UpdateChecker.kt` |
| AA1 | Chưa có FMEA (Failure Mode and Effects Analysis) | Đã làm | FMEA rút gọn — `FAILURE_MODES.md` |
| AA2 | Chưa có Chaos Testing | Làm một phần | kiểm thử hỗn loạn: chaos-test.py (giết cứng/đóng băng/tệp pid hỏng/vòng lặp sập/đầy đĩa lúc khởi động trên start-generic.sh thật, seed tái lập được) tìm và sửa 2 lỗi tiến trình mồ côi; RestoreMarker phát hiện khôi phục bị gián đoạn; chaos-device.sh cho các kịch bản trên điện thoại (chưa chạy trên máy thật). CHƯA kiểm được tự động: backup bị giết giữa chừng, mysqldump đầy đĩa, rút mạng giữa upload, giết MariaDB; restore vẫn chưa nguyên tử — `chaos-test.py`; `RestoreMarker.kt`; `chaos-device.sh`; `CHAOS_TESTING.md` |
| AA3 | Chưa có RTO/RPO rõ ràng | Đã làm | RPO/RTO — `DISASTER_RECOVERY.md` |
| AA4 | Chưa có Disaster Recovery Plan | Đã làm | kế hoạch khôi phục — `DISASTER_RECOVERY.md` |
| AB1 | Chưa rõ data được lưu ở đâu | Đã làm | dữ liệu nằm đâu + dung lượng trong app — `DataLifecycle.kt` |
| AB2 | Chưa có Data Retention Policy | Đã làm | chính sách lưu giữ — `DATA_AND_SECRETS.md` |
| AB3 | Chưa có "Right to be Forgotten" trong app | Đã làm | xoá toàn bộ dữ liệu (gõ lại từ xác nhận) — `MainActivity.kt` |
| AB4 | Chưa rõ điều gì xảy ra khi gỡ app | Đã làm | điều gì xảy ra khi gỡ app — `DATA_AND_SECRETS.md` |
| AB5 | Chưa có Data Portability đầy đủ | Đã làm | di chuyển dữ liệu — `DATA_AND_SECRETS.md` |
| AC1 | Chưa rõ secrets được lưu thế nào | Đã làm | mã hoá bí mật bằng Keystore (1bp-I) — `SecretStore.kt` |
| AC2 | Chưa có Token rotation | Làm một phần | hướng dẫn thu hồi token + đổi token API trong app; chưa tự động xoay vòng — `DATA_AND_SECRETS.md` |
| AC3 | Chưa có Secrets audit | Làm một phần | che token trong log + test canh gác không đọc/ghi bí mật lách qua — `secret-store-test.py` |
| AC4 | Chưa có 2FA cho Cloudflare/Telegram | Làm một phần | danh mục bảo mật khuyến nghị bật 2FA Cloudflare/Telegram; app không thể ép — `DATA_AND_SECRETS.md` |
| AD1 | Chưa có Versioning Strategy | Đã làm | đánh số phiên bản — `RELEASE_AND_COMPATIBILITY.md` |
| AD2 | Chưa có Release Process | Đã làm | quy trình phát hành — `RELEASE_AND_COMPATIBILITY.md` |
| AD3 | Chưa có Migration Strategy | Đã làm | cập nhật APK giữ dữ liệu (1bo-A) — `UpdateMergeLogic.kt` |
| AD4 | Chưa có Deprecation Policy | Đã làm | chính sách ngừng hỗ trợ — `RELEASE_AND_COMPATIBILITY.md` |
| AD5 | Chưa có Breaking Changes log | Đã làm | nhật ký thay đổi cần chú ý — `BREAKING_CHANGES.md` |
| AE1 | Chưa có structured logging | Cố ý không làm (có lý do) | log JSON: audit log đã dạng key=value, không có công cụ gom log cần JSON (1bp-K) — `HANDOFF.md` |
| AE2 | Chưa có distributed tracing | Không phải kỹ thuật cần áp dụng | không có hệ thống phân tán |
| AE3 | Chưa có Correlation ID | Đã làm | X-Request-ID + rid trong log — `nginx.conf.template` |
| AE4 | Chưa có Metrics export | Cố ý không làm (có lý do) | Prometheus/Grafana quá nặng cho điện thoại; có API trạng thái JSON (T1) — `ApiLogic.kt` |
| AE5 | Chưa có Alerting rules engine | Đã làm | bộ quy tắc cảnh báo tự định nghĩa: mỗi dòng một quy tắc (tên: chỉ_số toán_tử giá_trị [for 5m] [cooldown 2h]), 6 chỉ số, tối đa 20 quy tắc, báo lỗi từng dòng, gửi Telegram; thay cho alerts.yaml của PDF (không thêm bộ phân tích YAML) — xem docs/ALERT_RULES.md — `AlertRules.kt`; `Monitoring.kt`; `ALERT_RULES.md` |
| AF1 | Chưa có Config versioning | Đã làm | config_version — `site.config.json` |
| AF2 | Chưa có Config validation | Đã làm | kiểm tra cấu hình — `validate_config.py` |
| AF3 | Chưa có Config presets | Đã làm | preset — `apply_preset.py` |
| AF4 | Chưa có Config drift detection | Không phải kỹ thuật cần áp dụng | cấu hình là thời điểm build, không có trôi cấu hình lúc chạy |
| AG1 | Chưa phân tích đối thủ | Đã làm | phân tích đối thủ (kèm độ tin cậy thấp) — `COMPETITIVE_ANALYSIS.md` |
| AG2 | Chưa có Unique Value Proposition rõ | Đã làm | docs/VALUE_AND_AUDIENCE.md: tuyên bố giá trị một câu + 7 tuyên bố (U1–U7) mỗi cái kèm bằng chứng trong repo và được test kiểm; khẩu hiệu chính thức để chủ dự án chọn — `VALUE_AND_AUDIENCE.md`; `value-docs-test.py` |
| AG3 | Chưa có Target Audience rõ | Đã làm | mục riêng: 5 nhóm PHÙ HỢP, 6 nhóm KHÔNG phù hợp (nói thẳng), mức kỹ thuật cần có; tóm tắt ở đầu README; chưa khảo sát người dùng thật — `VALUE_AND_AUDIENCE.md`; `README.md` |
| AH1 | Chưa có Contribution Guidelines | Đã làm | hướng dẫn đóng góp — `CONTRIBUTING.md` |
| AH2 | Chưa có Code of Conduct | Đã làm | quy tắc ứng xử — `CODE_OF_CONDUCT.md` |
| AH3 | Chưa có Governance Model | Đã làm | docs/GOVERNANCE.md: mô hình một nhà bảo trì chính (BDFL) trong giai đoạn thử nghiệm, ai quyết cái gì, đóng góp từ ngoài (CHƯA nhận mã cho đến khi chọn giấy phép/CLA), quy trình phát hành, nguồn lộ trình, bất đồng/vắng nhà bảo trì/thương mại hoá; các điểm chủ dự án phải quyết đánh dấu rõ (tên, chính sách nhận mã, người kế nhiệm, nơi phát hành) — `GOVERNANCE.md`; `GOVERNANCE.md` |
| AH4 | Chưa có Commercial vs Open Source Strategy | Chờ chủ dự án | chiến lược thương mại vs mã nguồn mở do chủ dự án quyết (gắn với LICENSE); hệ quả của từng lựa chọn lên định hướng "miễn phí thử nghiệm rồi có thể tính phí" đã viết ở docs/LICENSE_OPTIONS.md |
| AI1 | Chưa có Plugin system | Cố ý không làm (có lý do) | không làm bộ nạp plugin động trên điện thoại: PDF tự ghi "chỉ làm nếu có nhu cầu thật; thêm runtime = thêm file .sh"; nạp mã ngoài lúc chạy không kiểm chứng được và trái nguyên tắc không thêm phụ thuộc. Thay bằng docs/EXTENDING.md: các điểm mở rộng THẬT (runtime, công cụ admin, kênh thông báo) đã đối chiếu mã và có test — `EXTENDING.md`; `extending-docs-test.py` |
| AI2 | Chưa có Template marketplace | Không phải kỹ thuật cần áp dụng | chợ mẫu: ngoài phạm vi |
| AI3 | Chưa có User forum / Discord | Chờ chủ dự án | diễn đàn/Discord do chủ dự án lập |
| AJ1 | Chưa có hướng dẫn vận hành vật lý | Đã làm | hướng dẫn vận hành vật lý — `README.md` |
| AJ2 | Chưa có Battery Health tracking | Đã làm | theo dõi sức khoẻ pin — `MonitorLogic.kt` |
| AJ3 | Chưa có Temperature monitoring | Đã làm | theo dõi nhiệt — `MonitorLogic.kt` |
| AJ4 | Chưa có "Dedicated server mode" | Đã làm | chế độ máy chủ chuyên dụng — `Prefs.kt` |
| AL1 | Những gì dự án ĐÃ có (rất nhiều) | Không phải kỹ thuật cần áp dụng | phần tổng kết/lộ trình của PDF; các mục bên trong được đối chiếu riêng |
| AL2 | Những gì còn thiếu — phân loại theo mức độ | Không phải kỹ thuật cần áp dụng | phần tổng kết/lộ trình của PDF; các mục bên trong được đối chiếu riêng |
| AL3 | Roadmap 12 tháng (đầy đủ) | Không phải kỹ thuật cần áp dụng | phần tổng kết/lộ trình của PDF; các mục bên trong được đối chiếu riêng |

