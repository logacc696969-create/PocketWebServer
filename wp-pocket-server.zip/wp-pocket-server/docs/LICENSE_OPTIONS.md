# Chọn giấy phép cho dự án (tài liệu để chủ dự án quyết định)

> Đây là thông tin thực tế để bạn chọn, **không phải tư vấn pháp lý**. Dự án hiện **chưa có giấy phép nào** và người viết không chọn thay bạn.

## Định hướng chủ dự án đã nêu (27/10/2026)

> **Ứng dụng ban đầu phát hành miễn phí để người dùng đóng vai người kiểm thử** (xem phần mềm chạy có ổn định không), **sau đó mới xem xét chuyện tính phí.** Người viết **không chọn giấy phép thay bạn**; dưới đây chỉ là hệ quả của định hướng đó lên từng lựa chọn.

| Lựa chọn | Hợp với "miễn phí thử nghiệm, có thể tính phí sau"? |
|---|---|
| **Giữ "bảo lưu mọi quyền" + giấy phép dùng thử** (`TERMS.md` điều 7) | **Giữ mở mọi hướng.** Người thử chỉ có quyền dùng thử có thể thu hồi; chưa ràng buộc điều gì về sau. Cần luật sư xác nhận cơ chế thu hồi/kết thúc thử nghiệm. Đây cũng là trạng thái pháp lý **hiện tại** (chưa có `LICENSE`) cộng thêm quyền dùng thử rõ ràng. |
| **MIT / Apache-2.0 ngay bây giờ** | **Khó tính phí sau**: người đã nhận bản đó được dùng, sửa, bán lại **vĩnh viễn**; bạn không rút lại được cho các bản đã phát hành. Có thể chuyển giấy phép cho các bản *sau*, nhưng bản cũ vẫn tự do. |
| **GPL-3.0 / AGPL-3.0 ngay bây giờ** | Vẫn **bán/tính phí được** bản sao, nhưng ai nhận cũng được phân phối lại miễn phí cùng điều kiện; khó giữ độc quyền thương mại. |
| **Source-available phi thương mại** | Hợp ý "miễn phí cho cá nhân, thương mại trả phí", nhưng **không phải mã nguồn mở** (OSI), khó thực thi, **không áp dụng cho phần GPL đã đóng gói**; nên có luật sư soạn. |

**Còn phải quyết (không ai quyết thay):** (a) sau thử nghiệm tính phí **ai** (mọi người / chỉ dùng thương mại), **thế nào** (một lần / thuê bao) — mục P2/AH4 của bảng đối chiếu; (b) bản beta đã tải có tiếp tục miễn phí không; (c) tên chủ bản quyền và năm; (d) có công bố mã nguồn các thành phần GPL mỗi bản phát hành không. Phần pháp lý liên quan (dữ liệu cá nhân, mật mã/xuất khẩu): `docs/LEGAL_NOTES_VN.md`.

## Hiện trạng
- Không có tệp `LICENSE`. Theo luật bản quyền mặc định, khi tác giả chưa cấp phép thì **người khác không có quyền dùng, sao chép, sửa hay phân phối lại** mã. "Miễn phí" chỉ trở thành đúng về mặt pháp lý **sau khi bạn cấp một giấy phép cho phép điều đó**.
- `TERMS.md` (bản nháp) đang ghi: chưa chọn giấy phép, mặc định bảo lưu mọi quyền.

## Điều không đổi dù bạn chọn giấy phép nào
Dự án đóng gói các thành phần của bên thứ ba có giấy phép riêng (chi tiết: `THIRD_PARTY_NOTICES.md`): **MariaDB (GPL v2)**, **Tiny File Manager (GPL v3)**, **WordPress (GPL v2 trở lên)** là copyleft; cloudflared, AndroidX, Material, Kotlin là Apache 2.0; WP-CLI là MIT; Adminer là Apache 2.0 hoặc GPL 2; nginx là BSD-2-Clause. Khi **phân phối APK chứa các phần GPL** cho người khác, nghĩa vụ GPL (cung cấp mã nguồn tương ứng hoặc lời đề nghị, giữ thông báo bản quyền, không thêm hạn chế) áp dụng cho **chính các phần đó**. Bạn không thể biến các phần GPL thành "chỉ trả tiền mới được dùng" hay đóng mã của chúng. Mã Kotlin/PHP/shell do dự án tự viết có thể dùng giấy phép riêng nếu các phần GPL được chạy như chương trình riêng (đúng cách dự án đang làm) — điểm này nên hỏi luật sư hoặc tổ chức tư vấn giấy phép mã nguồn mở trước khi phát hành rộng.

Dịch vụ bên thứ ba (Cloudflare Tunnel, Telegram, WordPress.org) có điều khoản riêng; giấy phép của dự án không thay đổi điều đó.

## Ba hướng phổ biến
| Mục tiêu của bạn | Gợi ý | Đặc điểm |
|------------------|-------|----------|
| Ai cũng dùng miễn phí, kể cả thương mại, ít ràng buộc | **MIT** hoặc **Apache-2.0** | Rất dễ dùng. Người khác được sửa và bán lại, kể cả đóng mã bản sửa của họ. Bạn không thể về sau bắt người đã nhận bản cũ phải trả tiền. Apache-2.0 có thêm điều khoản cấp quyền bằng sáng chế. |
| Ai cũng dùng miễn phí nhưng bản sửa đổi phải giữ mở | **GPL-3.0** hoặc **AGPL-3.0** | Copyleft: ai phân phối bản sửa phải mở mã tương ứng. **AGPL** còn áp dụng khi chạy như dịch vụ qua mạng — hợp với ứng dụng máy chủ. Hạn chế một số công ty vì lo ràng buộc. |
| Miễn phí cho cá nhân/phi thương mại, thương mại phải trả phí | Giấy phép **source-available** phi thương mại (ví dụ PolyForm Noncommercial) hoặc giấy phép tự soạn | **Không phải "mã nguồn mở"** theo định nghĩa OSI. Khó kiểm soát việc thực thi; không áp dụng được cho các phần GPL đã đóng gói. Nên có luật sư soạn. |

## Việc cần từ bạn để hoàn tất
1. Chọn một hướng ở bảng trên (hoặc cho biết mục tiêu để cân nhắc thêm).
2. Cho biết **tên người/tổ chức giữ bản quyền** và **năm** để điền vào tệp `LICENSE`.
3. Quyết định có **công bố mã nguồn tương ứng** cho các thành phần GPL trong mỗi bản phát hành hay không (cách làm thường dùng: đính kèm liên kết tới mã nguồn đúng phiên bản trong ghi chú phát hành).

Sau đó mình thêm `LICENSE`, cập nhật `TERMS.md`, `THIRD_PARTY_NOTICES.md` và `README.md`.
