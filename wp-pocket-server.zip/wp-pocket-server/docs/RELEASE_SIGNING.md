# Ký bản phát hành bằng khoá riêng của chủ sở hữu

Tài liệu này dành cho **chủ dự án**. Chỉ chủ dự án làm được việc này: khoá riêng phải do chính bạn tạo và giữ, tôi (Claude) và CI không bao giờ được giữ bản gốc của nó.

## Vì sao cần

APK Android phải được ký. Hiện CI build bản **debug**, ký bằng `app/debug.keystore`. Khoá này nằm công khai trong kho mã, mật khẩu là `android`. Hệ quả:

- Ai cũng ký được một APK giả mang **đúng chữ ký đó**. Điện thoại coi nó là bản cập nhật hợp lệ và cho cài đè lên app đang giữ website, cơ sở dữ liệu và mật khẩu của người dùng.
- Với một app mà ý nghĩa chính là *chủ sở hữu nắm quyền cao nhất*, đây là lỗ hổng lớn nhất còn lại ở khâu phân phối. Mọi lớp bảo mật khác (nginx, PHP, 2FA, tường lửa) đều vô nghĩa nếu app bị thay bằng bản giả.

Sau khi có khoá riêng, chỉ người giữ khoá mới ký được bản cập nhật. Người dùng cài đè bản của bạn thì được, bản giả của người khác thì điện thoại từ chối.

## Quan trọng: đổi khoá nghĩa là cài lại một lần

Android **không cho cài đè** bản ký bằng khoá khác lên bản đang cài. Người đang dùng bản debug-ký phải:

1. Mở app, **sao lưu** (Backup) rồi chép tệp sao lưu ra ngoài máy.
2. Gỡ app cũ.
3. Cài bản phát hành mới.
4. Khôi phục (Restore) từ tệp sao lưu.

Làm việc này **một lần duy nhất**, ở lần chuyển sang khoá riêng. Từ các bản sau, cài đè bình thường và dữ liệu được giữ nguyên. Nếu app chưa có người dùng thật, chuyển càng sớm càng ít phiền.

## Cách làm (khoảng 10 phút)

### Bước 1: tạo khoá trên máy của bạn

Cần `keytool` (có sẵn trong JDK) và `openssl`. Chạy **ngoài thư mục kho mã**:

```sh
sh scripts/tools/make_release_keystore.sh ~/wppocket-release-key "Tên của bạn"
```

Script sẽ:

- tạo khoá RSA 4096 bit, hạn khoảng 30 năm, bí danh `wppocket-release`;
- sinh mật khẩu ngẫu nhiên dài;
- ghi ra thư mục đó 3 tệp (quyền chỉ chủ sở hữu đọc được): `release.jks` (khoá), `release.jks.b64` (bản mã hoá base64 để dán vào GitHub), `secrets.txt` (4 giá trị cần dán + dấu vân tay SHA-256);
- **từ chối** chạy nếu thư mục đích nằm trong một kho git hoặc đã có khoá (tránh commit nhầm hoặc ghi đè khoá cũ).

### Bước 2: thêm 4 secret vào GitHub

Vào repo → *Settings → Secrets and variables → Actions → New repository secret*, tạo đúng 4 secret với giá trị lấy từ `secrets.txt`:

| Tên secret | Giá trị |
|---|---|
| `RELEASE_KEYSTORE_B64` | nội dung `release.jks` dạng base64 |
| `RELEASE_KEYSTORE_PASSWORD` | mật khẩu kho khoá |
| `RELEASE_KEY_ALIAS` | `wppocket-release` |
| `RELEASE_KEY_PASSWORD` | mật khẩu khoá (script đặt trùng mật khẩu kho) |

### Bước 3 (nên làm): ghim dấu vân tay

Trong *Settings → Secrets and variables → Actions → Variables*, tạo biến (không phải secret) `RELEASE_CERT_SHA256` với giá trị là dòng `SHA-256` in trong `secrets.txt`. Khi có biến này, CI **từ chối** mọi APK ký bằng chứng chỉ khác. Nếu ai đó (hoặc một lỗi) làm đổi secret sang khoá khác, build dừng thay vì phát hành ra một bản người dùng không cài đè được.

### Bước 4: cất khoá an toàn rồi xoá khỏi máy làm việc

- Chép thư mục `~/wppocket-release-key` vào **ít nhất hai nơi tách biệt** (ví dụ trình quản lý mật khẩu của bạn và một ổ USB cất kỹ).
- **Mất khoá = không bao giờ cập nhật được app cho người đã cài.** Họ buộc phải gỡ rồi cài lại (sao lưu/khôi phục như trên). Không ai, kể cả Anthropic hay GitHub, khôi phục giúp được.
- Lộ khoá = ai cũng ký được bản giả. Nếu nghi ngờ bị lộ, hãy coi như khoá hỏng và lập kế hoạch đổi khoá (người dùng phải cài lại một lần).

### Bước 5: phát hành

```sh
git tag v0.2.0 && git push origin v0.2.0
```

CI sẽ:

1. build `assembleRelease`, giải mã khoá vào thư mục tạm của máy chạy CI;
2. chạy `scripts/tools/apk_signer_check.py`: APK phải có chữ ký v2/v3, mọi APK (arm64, armeabi-v7a, universal) phải cùng một chứng chỉ, chứng chỉ **không được trùng khoá debug công khai**, và nếu bạn đã ghim thì phải đúng dấu vân tay;
3. xoá tệp khoá khỏi máy CI;
4. đưa APK đã kiểm vào Release kèm `SHA256SUMS.txt`.

Dấu vân tay in ra trong phần *Summary* của lần chạy. Đối chiếu với giá trị bạn lưu lúc tạo khoá.

## Nếu chưa có khoá thì sao

- Build thường (đẩy lên `main`) vẫn chạy và vẫn ra APK debug để thử, như trước.
- Job **release (khi đẩy tag) sẽ dừng với thông báo lỗi rõ ràng** thay vì lặng lẽ phát hành bản ký bằng khoá công khai.
- Muốn tạm chấp nhận bản debug-ký cho một lần phát hành (ví dụ lần đầu thử nghiệm): đặt biến repo `ALLOW_DEBUG_SIGNED_RELEASE=1`. Release vẫn được tạo nhưng CI in cảnh báo. Đây là lối thoát tạm, không phải trạng thái nên giữ.

## Giới hạn cần biết

- Việc ký đảm bảo **người cài đúng bản của chủ dự án**; nó không thay cho việc người dùng kiểm tra `SHA256SUMS.txt` khi tải ngoài kênh chính thức.
- Khoá nằm trong GitHub Secrets nên người có quyền quản trị repo, hoặc ai chiếm được tài khoản GitHub của bạn, vẫn có thể ký. Hãy bật 2FA (khoá bảo mật phần cứng nếu có) cho tài khoản GitHub và hạn chế người có quyền *Admin*/*Write*, đặc biệt quyền sửa workflow.
- Android có cơ chế xoay khoá (APK Signature Scheme v3 với *lineage*) cho phép đổi khoá mà không bắt gỡ app. Dự án **chưa** dùng. Muốn dùng phải chuẩn bị `lineage` từ khoá cũ **trước khi** khoá cũ bị mất hoặc lộ. Đây là việc nên cân nhắc sau, không cần cho lần chuyển đầu.
- Tôi chưa chạy được `gradle assembleRelease` thật trong môi trường này (không có Gradle/Android SDK). Các phần đã kiểm bằng chạy thật: script tạo khoá (bằng `keytool` thật), công cụ kiểm chữ ký (với `apksigner` giả nhưng chứng chỉ lấy từ `keytool` thật), cú pháp YAML. Lần đẩy tag đầu tiên có khoá thật là lần kiểm cuối cùng; nếu `signingConfigs` trong `app/build.gradle.kts` có lỗi, nó hiện ngay ở bước build và không phát hành gì cả.

Các kiểm thử tự động nằm ở `scripts/tests/release-signing-test.py` (31 kiểm tra).
