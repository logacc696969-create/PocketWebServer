# Công cụ dòng lệnh `wppocket`

Chạy trên **máy tính (hoặc Termux) cùng mạng LAN** với điện thoại, đọc **API trạng thái chỉ đọc** của app (xem "Địa chỉ và token API…" trong app; API mặc định tắt, bật rồi phải khởi động lại server). Một tệp Python duy nhất, **chỉ dùng thư viện chuẩn** (Python 3.8+), không cần `pip`:

```
python3 scripts/tools/wppocket_cli.py status
```

> API là **chỉ đọc**: công cụ này giám sát và kiểm tra, **không điều khiển** được server (không bật/tắt, không backup). Điều khiển vẫn qua app hoặc Telegram.

## Cấu hình một lần

```
python3 scripts/tools/wppocket_cli.py config set --host 192.168.1.23 --port 8080 --token <64 ký tự hex>
```

Lưu vào `~/.config/wppocket/config.json` (thư mục `0700`, tệp **`0600`**; cảnh báo nếu người khác đọc được). Thứ tự ưu tiên: tham số dòng lệnh > biến môi trường (`WPPOCKET_HOST`, `WPPOCKET_PORT`, `WPPOCKET_TOKEN`, `WPPOCKET_LANG`, `WPPOCKET_CONFIG`) > tệp. Tránh `--token` trên dòng lệnh (hiện trong danh sách tiến trình). `config show` che token; `--reveal` mới in đầy đủ.

## Lệnh

| Lệnh | Việc |
|---|---|
| `status` | Tóm tắt: máy chủ chạy/không, pin (và đang sạc), bộ nhớ đã dùng, backup gần nhất, độ mới của dữ liệu |
| `status --json` | JSON nguyên vẹn (đã kiểm lược đồ `wp-pocket-status/1`) |
| `status --check …` | Kiểu Nagios: **một dòng** `OK/WARNING/CRITICAL - …` và mã thoát |
| `watch --interval 30 [--count N]` | Theo dõi liên tục, mỗi dòng có giờ |
| `config show \| set \| path` | Xem / đặt / hiện đường dẫn cấu hình |

Ngưỡng cho `--check` và `watch`: `--max-disk 90` (bộ nhớ đầy ≥ 90%), `--min-battery 15` (pin ≤ 15% **và không sạc**), `--max-backup-age 48h` (kể cả "chưa có backup"), `--max-staleness 10m` (dữ liệu cũ hơn → CRITICAL: app/điện thoại có thể bị treo). Thời lượng: `30s`, `10m`, `48h`, `2d`.

**Mã thoát:** `0` OK · `1` WARNING (vượt ngưỡng) · `2` CRITICAL (server không chạy / dữ liệu quá cũ) · `3` UNKNOWN (không kết nối được, sai token, API chưa bật…) · `64` sai cú pháp lệnh. `status` không `--check` trả `2` khi server không chạy.

Ví dụ cron trên máy tính (báo khi có vấn đề):

```
*/10 * * * * python3 /đường/dẫn/wppocket_cli.py status --check --max-disk 90 --min-battery 15 --max-backup-age 48h --max-staleness 15m || notify-send "WP Pocket Server"
```

## An toàn

- API chỉ mở cho **dải LAN** (192.168/16, 10/8, 172.16/12) và đi bằng **HTTP thường** → CLI **từ chối gửi token** tới máy không thuộc mạng nội bộ (IP riêng, loopback, link-local, IPv6 ULA, `*.local`, `*.lan`, `*.home.arpa`, tên không có dấu chấm) trừ khi `--allow-public`. Không dùng qua Internet.
- **Không theo chuyển hướng** (không lộ token sang máy khác) và **không đi qua proxy** của môi trường (`http_proxy`).
- Phản hồi giới hạn 64 KB; token **không bao giờ** in ra (lỗi, `config show`) trừ `--reveal`; không có `eval`/`exec`/shell trong công cụ.
- Token phải đúng 32–64 ký tự hex thường; sai định dạng bị từ chối trước khi gửi.

## Chưa làm

Chưa có lệnh điều khiển (cần API ghi — chưa có và có thể không nên có); chưa thử với điện thoại thật (đã kiểm bằng máy chủ giả đúng hợp đồng của `start-lamp.sh`; phần nginx thật đã kiểm riêng ở `api-status-test.py`).
