# Dữ liệu và bí mật: nằm ở đâu, giữ bao lâu, xoá thế nào

<!-- code-fact: KEEP_BACKUPS=5 -->
<!-- code-fact: ALLOW_BACKUP=false -->
<!-- code-fact: PHP_TIMEZONE=Asia/Ho_Chi_Minh -->

## 1. Dữ liệu nằm đâu
| Dữ liệu | Vị trí | Ghi chú |
|---------|--------|---------|
| Website (WordPress, ảnh, plugin, theme; SQLite ở chế độ Lite) | `filesDir/www` | Được **giữ** khi cài đè APK (từ 1bo) |
| CSDL MariaDB (chế độ Full) | `filesDir/mysql-data` | Nằm riêng, không bị thay khi cài đè |
| Nhật ký, trạng thái, tệp tạm | `filesDir/lamp-run` | Có thể xoá an toàn |
| Mật khẩu quản trị | `filesDir/admin-password.txt` | PHP cần đọc dạng rõ |
| Thiết lập app (token Telegram, URL webhook, token tunnel, cụm mật khẩu backup) | SharedPreferences của app | Riêng tư theo ứng dụng; `allowBackup="false"`; **từ 1bp-I mã hoá AES-256-GCM bằng khoá Android Keystore** (dạng lưu `enc1:…`) |
| Backup trong máy | thư mục riêng của app trên bộ nhớ ngoài (`.../files/backups`), hoặc trên **thẻ nhớ** nếu bật tuỳ chọn (từ 1bp-K) | Giữ 5 bản gần nhất, tính chung cả hai nơi |

Nút **Dữ liệu trên máy và xoá toàn bộ…** trong app hiện dung lượng từng nhóm.

## 2. Giữ bao lâu
- Backup trong máy: giữ 5 bản mới nhất, bản cũ hơn bị xoá khi có bản mới.
- Bản đã gửi lên Telegram/webhook: **app không xoá**; nằm ở dịch vụ đó cho đến khi bạn xoá.
- Nhật ký trong `lamp-run`: không có chính sách lưu trữ pháp lý; chỉ phục vụ gỡ lỗi.

## 3. Gỡ ứng dụng / xoá dữ liệu
- Gỡ cài đặt hoặc "Xoá toàn bộ dữ liệu" xoá mọi thứ ở bảng trên, **kể cả backup trong máy**. Bản trên Telegram/webhook vẫn còn.
- Xoá toàn bộ yêu cầu gõ lại từ xác nhận và không thể hoàn tác.

## 4. Bí mật: hiện trạng và rủi ro
- **Token Telegram, token Cloudflare Tunnel, URL webhook backup/cảnh báo, URL heartbeat, cụm mật khẩu mã hoá backup và token API trạng thái (T1)** được lưu dạng `enc1:…` (AES-256-GCM, khoá nằm trong Android Keystore của máy). Giá trị cũ lưu dạng rõ được tự mã hoá lại ở lần đọc đầu tiên. Mọi chỗ đọc/ghi các khoá này đi qua `SecretStore`; một bài test tĩnh chặn việc đọc/ghi lách qua.
- **Fail-open có chủ đích:** nếu Keystore không dùng được trên máy/ROM nào đó, app lưu dạng rõ như trước thay vì chặn bạn. Nếu khoá bị mất (khôi phục máy, ROM xoá Keystore) thì giá trị đã mã hoá không giải mã được và app coi như chưa cấu hình: bạn nhập lại token.
- Hạ cấp xuống bản app cũ (trước 1bp-I) sẽ **không đọc được** các giá trị đã mã hoá; nhập lại.
- Khoá Keystore **gắn với từng máy**: không chuyển sang máy khác được, càng cần ghi lại token và cụm mật khẩu ở nơi an toàn bên ngoài.
- **Vẫn ở dạng rõ, vì PHP/MariaDB phải đọc trực tiếp:** `admin-password.txt` và `wp-config.php`. Máy đã root vẫn đọc được hai tệp này.
- Nhật ký cố ý che token/URL (hàm `redactToken`/`redactUrl`).
- Chưa đo ảnh hưởng thực tế trên nhiều dòng máy; mã Kotlin phần Keystore chưa từng được biên dịch ở môi trường làm việc (xem HANDOFF.md mục 1bp-I).

## 5. Đổi/thu hồi bí mật
- **Token Telegram:** dùng BotFather để thu hồi và tạo token mới, rồi nhập lại vào app.
- **Token Cloudflare Tunnel:** tạo/đổi token trong bảng điều khiển Cloudflare rồi nhập lại.
- Nghi ngờ lộ backup mã hoá: đổi cụm mật khẩu và tạo backup mới; bản cũ vẫn mở được bằng cụm cũ nên hãy xoá chúng.

## 5b. Danh mục bảo mật cho người dùng
Bật xác thực 2 bước cho tài khoản Cloudflare và Telegram; bật 2FA cho `_admin/`; bật mã hoá backup và **ghi cụm mật khẩu ra nơi khác**; không chia sẻ token tunnel; gửi backup lên nơi bạn kiểm soát.

## 6. Di chuyển dữ liệu (không bị khoá vào app)
Backup là tệp zip thường: thư mục `www/` cộng `database.sql` (dump MariaDB tiêu chuẩn) nên có thể dựng lại trên hosting khác. Dùng **Xuất backup ra ngoài…**.
