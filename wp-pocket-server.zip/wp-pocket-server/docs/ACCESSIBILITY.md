# Trợ năng (TalkBack, cỡ chữ, vùng chạm)

PDF (mục J8) nói chưa rà trợ năng. Nút của app đều có chữ nên TalkBack đọc được mặc định, nhưng vẫn có chỗ chưa tốt. Đã rà bằng công cụ `scripts/tools/a11y_audit.py` (chỉ stdlib; `python3 scripts/tools/a11y_audit.py`, mã thoát 1 nếu có vi phạm) và sửa những gì tìm thấy.

## Quy tắc của công cụ

| Mã | Quy tắc |
|---|---|
| A1 | Ảnh (`ImageView`/`ImageButton`) có `contentDescription` hoặc `importantForAccessibility="no"` nếu chỉ trang trí |
| A2 | Vùng chạm ≥ **48dp**: không đặt `minHeight`/`minWidth` < 48dp cho nút, công tắc, view bấm được |
| A3 | Ô nhập có `hint`, `contentDescription` hoặc được `labelFor` |
| A4 | Công tắc/ô chọn có chữ hoặc `contentDescription` |
| A5 | `textSize` dùng **sp** (theo cỡ chữ người dùng chọn) |
| A6 | Trạng thái chính của server (`tvStatus`) có `accessibilityLiveRegion="polite"` để TalkBack đọc khi đổi (Đang chạy ↔ Đã dừng). **Cố ý không** đặt cho `tvDeviceStatus` (nhiệt độ/pin đổi liên tục, đọc liên tục gây ồn) và layout widget |
| A7 | Không ẩn khỏi TalkBack một view bấm được |
| A8 | `contentDescription`/`hint` là `@string/` (dịch được); gợi ý chỉ gồm số (vd `24`) được miễn |

`--self-test` kiểm chính công cụ: bắt đủ 8/8 mã trên một layout cố ý sai và không báo nhầm layout đúng.

## Đã sửa ở vòng này (do công cụ tìm thấy)

- Nút **Chia sẻ liên kết / mã QR** và **Sao chép** (mật khẩu quản trị) có vùng chạm < 48dp (`minHeight=0dp`) → 48dp.
- Ô **số phút Auto-Sleep** không có nhãn cho TalkBack → nhãn "Số phút không có ai truy cập thì ngủ" gắn bằng `labelFor`.
- Trạng thái server không được đọc khi đổi → `accessibilityLiveRegion="polite"`.
- Hộp thoại tạo bằng mã (QR, ngưỡng cảnh báo): ảnh QR có mô tả có kèm địa chỉ; mỗi ô số có `contentDescription`; lỗi nhập hiện ngay tại ô.

## Chưa kiểm (nói thẳng)

- **Chưa thử bằng TalkBack thật** trên điện thoại: thứ tự đọc, nhóm view, cử chỉ.
- **Cỡ chữ 200%**: chưa xem bố cục có vỡ/cắt chữ không.
- **Độ tương phản màu** (chữ trên nền, trạng thái lỗi/cảnh báo): chưa đo.
- Chưa thử **Switch Access**, **Voice Access**, chế độ giảm chuyển động.
- Công cụ chỉ đọc layout XML; view tạo hoàn toàn bằng mã được kiểm bằng đối chiếu văn bản trong `scripts/tests/a11y-audit-test.py`.
- Màn hình khác ngoài `activity_main.xml` và widget: công cụ có quét hết thư mục `layout*`, nhưng chưa xem từng màn hình trên máy.
