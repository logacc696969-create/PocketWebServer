# Mô hình quản trị dự án

> Bản nháp để chủ dự án xác nhận. Mục tiêu: ai quyết cái gì, đổi bằng cách nào, trong **giai đoạn thử nghiệm miễn phí** (`docs/BETA_PROGRAM.md`) và khi sau này có thể tính phí. Không phải văn bản pháp lý.

## 1. Mô hình hiện tại: một nhà bảo trì chính (BDFL)

Dự án có **một chủ dự án / nhà bảo trì chính** **[TÊN — chủ dự án điền]**. Mô hình này hợp với giai đoạn thử nghiệm: quyết định nhanh, không cần bỏ phiếu. Người thử và người báo lỗi **góp ý**, chủ dự án **quyết**.

| Việc | Ai quyết | Cách làm |
|---|---|---|
| Sửa lỗi, cải tiến kỹ thuật trong phạm vi hiện có | Nhà bảo trì | Thay đổi nhỏ, **CI xanh** (mọi kiểm thử trong `.github/workflows/build-apk.yml`), ghi `CHANGELOG.md` và `HANDOFF.md` |
| Thêm tính năng lớn / đổi hướng | Nhà bảo trì, sau khi **thu thập phản hồi** | Mở issue mô tả nhu cầu thật → thảo luận → quyết; tính năng PDF tự nhận là "chỉ làm nếu có nhu cầu" thì chờ nhu cầu |
| Từ chối có lý do | Nhà bảo trì | Ghi lý do vào mục "Cố ý không làm" của `docs/PDF_TRACEABILITY.md` / `HANDOFF.md` để không đề xuất lại |
| **Giấy phép, giá, điều khoản, quyền riêng tư** | **Chỉ chủ dự án** (và luật sư) | `docs/LICENSE_OPTIONS.md`, `TERMS.md`, `docs/LEGAL_NOTES_VN.md`; **không ai khác quyết thay** |
| Phát hành bản thử nghiệm mới | Nhà bảo trì | Xem mục 3 |
| Xử lý vi phạm quy tắc ứng xử | Nhà bảo trì | `CODE_OF_CONDUCT.md` |

## 2. Đóng góp từ bên ngoài

- **Báo lỗi và đề xuất**: luôn hoan nghênh, qua kênh do chủ dự án chọn (mẫu báo cáo ở `.github/ISSUE_TEMPLATE/beta-report.yml`). Đừng gửi token/IP/mật khẩu.
- **Gửi mã (pull request)**: **chưa nhận mã từ bên ngoài cho đến khi chủ dự án chọn giấy phép và quyết có dùng thoả thuận đóng góp (CLA) hay không.** Lý do: hiện chưa có `LICENSE` và chủ dự án có thể tính phí sau (`TERMS.md` điều 7); nhận mã của người khác khi chưa rõ quyền cấp phép lại sẽ **làm khó việc đổi giấy phép hay thương mại hoá về sau**. Tài liệu, báo lỗi, bản dịch (`values-xx/strings.xml` cần qua `i18n-parity-test.py`) vẫn nên bàn trước với chủ dự án. **[CHỦ DỰ ÁN QUYẾT: chính sách nhận mã — chưa quyết]**
- Mọi thay đổi (của ai) phải qua cùng cổng kiểm: `CONTRIBUTING.md`.

## 3. Phát hành

1. Cập nhật `CHANGELOG.md` (mục "Chưa phát hành" → số phiên bản), kiểm `THIRD_PARTY_NOTICES.md` nếu đổi thành phần bên thứ ba.
2. **CI xanh** trên commit đó; bản build do CI sinh ra (không build tay) là bản phát hành.
3. Phát hành là **bản thử nghiệm** cho đến khi chủ dự án tuyên bố kết thúc giai đoạn thử nghiệm; ghi rõ trong ghi chú phát hành đây là bản thử nghiệm (`TERMS.md` điều 7). **[CHỦ DỰ ÁN QUYẾT: phát hành ở đâu (GitHub Releases, kênh khác) — chưa quyết]**
4. Kèm liên kết mã nguồn đúng phiên bản của các thành phần GPL (MariaDB, Tiny File Manager, WordPress) nếu chủ dự án đã quyết công bố (`docs/LICENSE_OPTIONS.md`).

## 4. Nguồn của lộ trình

Danh sách việc cần làm lấy từ **`docs/PDF_TRACEABILITY.md`** (mục "Chưa làm", "Làm một phần", "Chờ chủ dự án") và từ phản hồi của người thử. Ưu tiên: **mất dữ liệu > sập/treo > cảnh báo sai > hiệu năng > giao diện**. Một mục chỉ chuyển sang "Đã làm" khi có bằng chứng trong repo (công cụ `scripts/tools/pdf_traceability.py` kiểm).

## 5. Khi bất đồng, khi nhà bảo trì vắng, khi thương mại hoá

- **Bất đồng kỹ thuật**: nêu bằng chứng (kiểm thử, số đo); nhà bảo trì quyết và ghi lý do.
- **Nhà bảo trì vắng/ngừng**: **[CHỦ DỰ ÁN QUYẾT: người kế nhiệm hoặc cách bàn giao — chưa quyết]**. Cho đến khi quyết, dự án **không bảo đảm** được bảo trì (`TERMS.md` điều 1 và 5).
- **Nếu tính phí sau này**: mô hình có thể giữ BDFL; phần việc nào miễn phí/trả phí là quyết định thương mại của chủ dự án (`docs/LICENSE_OPTIONS.md`, mục P2/AH4 của bảng đối chiếu). Quy trình ở mục 1–3 không đổi.

## 6. Điều chưa quyết (tóm tắt)

Tên nhà bảo trì chính; chính sách nhận mã và CLA; người kế nhiệm; kênh báo cáo; giấy phép; giá.
