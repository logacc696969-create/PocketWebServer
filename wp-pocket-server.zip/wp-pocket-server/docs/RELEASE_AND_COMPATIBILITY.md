# Phát hành, đánh số phiên bản, tương thích

<!-- code-fact: VERSION_CODE=1 -->
<!-- code-fact: DEFAULT_VERSION_NAME=0.1.0 -->
<!-- code-fact: MIN_SDK=26 -->
<!-- code-fact: TARGET_SDK=34 -->

## Đánh số phiên bản
- **Tên phiên bản** (`versionName`) lấy từ tag git dạng `vX.Y.Z` khi phát hành; bản build thường (không gắn tag) giữ giá trị mặc định `0.1.0`.
- **`versionCode` luôn là 1.** Hệ quả cần biết: Android cho phép cài đè giữa các bản cùng `versionCode`, nên mọi bản (kể cả cũ hơn) cài đè được lên nhau, và **app không tự chặn hạ cấp**. Hạ cấp có thể làm dữ liệu không tương thích (ví dụ CSDL đã nâng cấp) — luôn backup trước. Đây là hiện trạng của code, không phải khuyến nghị.

## Quy trình phát hành
1. Cập nhật `CHANGELOG.md` và `BREAKING_CHANGES.md`; ghi mục mới vào `HANDOFF.md`.
2. Đẩy tag `vX.Y.Z`. CI (job `release` ở cuối workflow) build và tạo bản phát hành kèm APK, `SHA256SUMS.txt` và SBOM.
3. Người dùng kiểm tra checksum trước khi cài (xem README mục chuỗi cung ứng).

## Tương thích
- Android 8.0 trở lên (`minSdk` 26), nhắm tới Android 14 (`targetSdk` 34).
- `site.config.json`: khoá `config_version` cho phép đổi định dạng sau này; công cụ build từ chối `config_version` mới hơn mức nó hiểu thay vì hiểu sai.

## Chính sách ngừng hỗ trợ (deprecation)
Một tính năng/khoá cấu hình sẽ không bị gỡ im lặng: nó được ghi vào `BREAKING_CHANGES.md` ít nhất một bản phát hành trước khi gỡ, kèm cách thay thế. Chưa có tính năng nào đang ở trạng thái ngừng hỗ trợ.
