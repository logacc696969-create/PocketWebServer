# Mở rộng dự án: các điểm mở rộng có sẵn (không có hệ thống plugin)

PDF (mục AI1) đề xuất "plugin system" cho runtime mới, công cụ quản trị mới, kênh thông báo mới, và **tự nói** là chỉ nên làm nếu có nhu cầu thật vì "thêm runtime = thêm file `.sh`". Dự án **không có bộ nạp plugin** (thêm một cơ chế động trên điện thoại là thêm bề mặt lỗi và bảo mật, không có nhu cầu nêu ra). Thay vào đó, tài liệu này liệt kê **điểm mở rộng thật** và các bước, đã đối chiếu với mã (`scripts/tests/extending-docs-test.py`).

## 1. Thêm một runtime mới (Ruby, Go…)

Hiện có `php`, `node`, `python`, `static` (`RUNTIMES` trong `scripts/tools/apply_preset.py`). Mỗi runtime là **một script** `scripts/runtimes/<tên>.sh` dùng các hàm chung `generic_*` trong `scripts/lib/generic_runtime.sh` (tải gói Termux đúng phiên bản, thu thập `.so`, sinh `runtime.json`, đóng gói `www.zip` tái lập được, cài bộ giám sát `start-generic.sh`).

1. Viết `scripts/runtimes/<tên>.sh` theo mẫu `scripts/runtimes/python.sh` (ngắn nhất): chọn gói Termux, chọn lệnh khởi chạy (`GEN_APP_BIN`, tham số), gọi `generic_install_supervisor` **trước** `make_reproducible_zip`.
2. Thêm tên vào `RUNTIMES` (`scripts/tools/apply_preset.py`) và các quy tắc kiểm cấu hình riêng nếu có (`validate`; xem cách khoá `wsgi` được thêm cho Python).
3. Thêm preset `presets/<tên>-local.json` (và `-git` nếu cần); `scripts/tests/preset-test.py` đếm số preset — cập nhật con số.
4. Thêm vào kiểm thử CI (`.github/workflows/build-apk.yml` chạy `scripts/runtimes/${RUNTIME}.sh`), kiểm thử bộ giám sát nếu runtime có hành vi riêng (`scripts/tests/generic-supervisor-test.py`).
5. Cập nhật `THIRD_PARTY_NOTICES.md` (gói Termux mới + giấy phép) — **bắt buộc** nếu đóng gói thêm binary.

## 2. Thêm một công cụ quản trị (`_admin/`)

Các công cụ là tệp PHP mẫu `scripts/runtimes/templates/admin-*.php` được `scripts/lib/admin_tools.sh` chép vào `_admin/` khi build, **luôn đứng sau** `admin-auth.php` (mật khẩu, 2FA, giới hạn IP, phiên, CSRF, nhật ký kiểm toán). Thêm công cụ: viết `admin-<tên>.php` dùng `admin-auth.php`, thêm vào danh sách chép trong `admin_tools.sh`, thêm liên kết ở trang chỉ mục, và **thêm kiểm thử bảo mật** (`scripts/tests/admin-security-test.py` kiểm mọi công cụ đều yêu cầu đăng nhập).

## 3. Thêm một kênh thông báo (Discord, Slack…)

Kênh có sẵn: **Telegram** (`TelegramNotifier.kt`), **webhook JSON** (`AlertWebhook.kt`; sự kiện hợp lệ nằm trong `ALERT_EVENTS`), **tải backup** (`WebhookUploader.kt`), và **quy tắc cảnh báo tuỳ chỉnh** (`AlertRules.kt` → Telegram; xem `docs/ALERT_RULES.md`). Cách ít việc nhất: dùng **webhook JSON** trỏ tới một dịch vụ trung gian (Discord/Slack nhận webhook) thay vì thêm mã Kotlin. Nếu cần kênh gốc: viết bộ thông báo theo mẫu `TelegramNotifier`, phần logic thuần tách riêng để kiểm được trên JVM (xem các bản `*Port.java` trong `scripts/tests/java/`).

## 4. Điều không nên làm

Không nạp mã từ bên ngoài lúc chạy (tải script/plugin rồi thực thi): không kiểm chứng được, mở đường tấn công chuỗi cung ứng, và trái nguyên tắc "không thêm phụ thuộc" của dự án (`docs/PYTHON_WSGI.md` là ví dụ chọn bản tự viết chỉ dùng thư viện chuẩn).
